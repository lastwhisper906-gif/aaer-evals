# FLEX notes — 0000866374-18-000003


## flex:InterestAndOtherNetTextBlock

[0000866374-18-000003:notes:1]
[same as prior period, unchanged from 0000866374-17-000012:notes:1]

[0000866374-18-000003:notes:2]
During the three-month and nine-month periods ended December 31, 2017, the Company recognized interest expense of $32.1 million and $90.7 million, respectively, on its debt obligations outstanding during the periods. During the three-month and nine-month periods ended December 31, 2016, the Company recognized interest expense of $26.6 million and $79.9 million, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-18-000003:notes:3]
[same as prior period, unchanged from 0000866374-17-000012:notes:5]

[0000866374-18-000003:notes:4]
[same as prior period, unchanged from 0000866374-17-000012:notes:6]

[0000866374-18-000003:notes:5]
During the nine-month period ended December 31, 2017, the Company completed two acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operation and cash flows of the Company.

[0000866374-18-000003:notes:6]
[same as prior period, unchanged from 0000866374-17-000012:notes:7]

[0000866374-18-000003:notes:7]
Additionally, in September 2017, the Company acquired a certain power modules business from Ericsson, and expanded its capabilities within the CEC segment. The Company paid $56.0 million, net of cash acquired.

[0000866374-18-000003:notes:8]
[same as prior period, unchanged from 0000866374-17-000012:notes:8]

[0000866374-18-000003:notes:9]
|  | Purchase Consideration |  | Net Tangible Assets Acquired |  | Purchased Intangible Assets |  | Goodwill |
| AGM | $ | 213,718 |  |  | $ | 56,438 |  |  | $ | 82,000 |  |  | $ | 75,280 |  |
| Power Modules Business | 56,006 |  |  | 12,332 |  |  | 34,500 |  |  | 9,174 |  |

[0000866374-18-000003:notes:10]
The Company is in the process of finalizing its valuation of the fair value of the assets and liabilities acquired. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill during the respective measurement periods.

[0000866374-18-000003:notes:11]
The results of operations of the acquisitions were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue, collectively, were immaterial to the Company's condensed consolidated financial results for the three-month and nine-month periods ended December 31, 2017. Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-18-000003:notes:12]
COMMITMENTS AND CONTINGENCIES

[0000866374-18-000003:notes:13]
Litigation and other legal matters

[0000866374-18-000003:notes:14]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The Company does not believe that the amounts accrued are material.  Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented.  Any such excess could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-18-000003:notes:15]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible loss. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-18-000003:notes:16]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 291 million Brazilian reals (approximately USD $88 million based on the exchange rate as of December 31, 2017). The assessments are in various stages of the review process at the administrative level. The Company has meritorious defenses and plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-18-000003:notes:17]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-18-000003:notes:18]
[same as prior period, unchanged from 0000866374-17-000012:notes:20]

[0000866374-18-000003:notes:19]
[same as prior period, unchanged from 0000866374-17-000012:notes:21]

[0000866374-18-000003:notes:20]
|  | Three-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |  | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |
| Other comprehensive gain (loss) before reclassifications | (4,643 | ) |  | 7,248 |  |  | 2,605 |  |  | (1,354 | ) |  | (33,770 | ) |  | (35,124 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (74 | ) |  | 244 |  |  | 170 |  |  | 1,153 |  |  | (2,642 | ) |  | (1,489 | ) |
| Net current-period other comprehensive gain (loss) | (4,717 | ) |  | 7,492 |  |  | 2,775 |  |  | (201 | ) |  | (36,412 | ) |  | (36,613 | ) |
| Ending balance | $ | (53,187 | ) |  | $ | (67,911 | ) |  | $ | (121,098 | ) |  | $ | (42,434 | ) |  | $ | (116,731 | ) |  | $ | (159,165 | ) |

[0000866374-18-000003:notes:21]
|  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |  | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |
| Other comprehensive gain (loss) before reclassifications | (5,488 | ) |  | 27,562 |  |  | 22,074 |  |  | (1,031 | ) |  | (19,471 | ) |  | (20,502 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | (15,273 | ) |  | 244 |  |  | (15,029 | ) |  | 119 |  |  | (2,867 | ) |  | (2,748 | ) |
| Net current-period other comprehensive gain (loss) | (20,761 | ) |  | 27,806 |  |  | 7,045 |  |  | (912 | ) |  | (22,338 | ) |  | (23,250 | ) |
| Ending balance | $ | (53,187 | ) |  | $ | (67,911 | ) |  | $ | (121,098 | ) |  | $ | (42,434 | ) |  | $ | (116,731 | ) |  | $ | (159,165 | ) |

[0000866374-18-000003:notes:22]
Substantially all unrealized gains relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and nine-month periods ended December 31, 2017 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-18-000003:notes:23]
[same as prior period, unchanged from 0000866374-17-000012:notes:25]

[0000866374-18-000003:notes:24]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and industrial products, from athletic shoes to electronics, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-18-000003:notes:25]
[same as prior period, unchanged from 0000866374-17-000012:notes:27]

[0000866374-18-000003:notes:26]
[same as prior period, unchanged from 0000866374-17-000012:notes:28]

[0000866374-18-000003:notes:27]
[same as prior period, unchanged from 0000866374-17-000012:notes:29]

[0000866374-18-000003:notes:28]
| • | High Reliability Solutions ("HRS"), which is comprised of medical business, including consumer health, digital health, disposables, precision plastics, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and clean technologies. |

[0000866374-18-000003:notes:29]
[same as prior period, unchanged from 0000866374-17-000012:notes:31]

[0000866374-18-000003:notes:30]
Basis of Presentation

[0000866374-18-000003:notes:31]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2017 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018.

[0000866374-18-000003:notes:32]
The first quarters for fiscal year 2018 and fiscal year 2017 ended on June 30, 2017, which is comprised of 91 days in the period, and July 1, 2016, which is comprised of 92 days in the period, respectively. The second quarters for fiscal year 2018 and fiscal year 2017 ended on September 29, 2017 and September 30, 2016, which are comprised of 91 days in both periods. The Company's third quarters end on December 31 of each year, which are comprised of 93 days and 92 days for fiscal years 2018 and 2017, respectively.

[0000866374-18-000003:notes:33]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. Noncontrolling interests are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.

[0000866374-18-000003:notes:34]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has a voting percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## us-gaap:DebtDisclosureTextBlock

[0000866374-18-000003:notes:35]
BANK BORROWINGS AND LONG TERM DEBT

[0000866374-18-000003:notes:36]
Bank borrowings and long-term debt are as follows:

[0000866374-18-000003:notes:37]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 700,000 |  |
| Term Loan, including current portion, due in installments through June 2022 | 489,938 |  |  | 502,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 596,282 |  |  | 595,979 |  |
| Other | 181,175 |  |  | 169,671 |  |
| Debt issuance costs | (14,596 | ) |  | (16,007 | ) |
| Total | $ | 2,944,674 |  |  | $ | 2,952,143 |  |

[0000866374-18-000003:notes:38]
The weighted-average interest rates for the Company’s long-term debt were 3.7% and 3.5% as of December 31, 2017 and March 31, 2017, respectively.

[0000866374-18-000003:notes:39]
On June 30, 2017, the Company entered into a five-year credit facility consisting of a $1.75 billion revolving credit facility and a $502.5 million term loan, which is due to mature on June 30, 2022 (the "2022 Credit Facility"). This 2022 Credit Facility replaced the Company's $2.1 billion credit facility, which was due to mature in March 2019. The outstanding principal of the term loan portion of the 2022 Credit Facility is repayable in quarterly installments of approximately $6.3 million from September 30, 2017 through June 30, 2020 and approximately $12.6 million from September 30, 2020 through March 31, 2022 with the remainder due upon maturity. The Company determined that effectively extending the maturity date of the revolving credit and repaying the term loan due March 2019 qualified as a debt modification and consequently all unamortized debt issuance costs related to the $2.1 billion credit facility are capitalized and will be amortized over the term of the 2022 Credit Facility.

[0000866374-18-000003:notes:40]
Borrowings under the 2022 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, which is defined as the greatest of (a) the Administrative Agent’s prime rate, (b) the federal funds effective rate, plus 0.50% and (c) the LIBOR (the London Interbank Offered Rate) rate that would be calculated as of each day in respect of a proposed LIBOR loan with a one-month interest period, plus 1.0%; plus, in the case of each of clauses (a) through (c), an applicable margin ranging from 0.125% to 0.875% per annum, based on the Company’s credit ratings (as determined by Standard & Poor’s Financial Services LLC, Moody’s Investors Service, Inc. and Fitch Ratings Inc.) or (ii) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 1.875% per annum, based on the Company’s credit ratings.

[0000866374-18-000003:notes:41]
The 2022 Credit Facility is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of significant exceptions and limitations. The 2022 Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio during the term of the 2022 Credit Facility. As of December 31, 2017, the Company was in compliance with the covenants under the 2022 Credit Facility agreement.

[0000866374-18-000003:notes:42]
The Company has three tranches of Notes, the 4.625% Notes due 2020, the 5.000% Notes due 2023 and the 4.75% Notes due 2025. These Notes are senior unsecured obligations, and prior to June 30, 2017, were guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). Upon the termination of the $2.1 billion credit facility, all guarantor subsidiaries were released from their guarantees under each indenture for each Note. As a result, the Company will no longer be providing supplemental guarantor and non-guarantor condensed consolidating financial statements.

[0000866374-18-000003:notes:43]
Repayment of the Company’s long term debt outstanding as of December 31, 2017 is as follows:

[0000866374-18-000003:notes:44]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 10,739 |  |
| 2019 | 42,934 |  |
| 2020 | 542,872 |  |
| 2021 | 115,247 |  |
| 2022 | 809,103 |  |
| Thereafter | 1,438,375 |  |
| Total | $ | 2,959,270 |  |

[0000866374-18-000003:notes:45]
_________________________________________________________

[0000866374-18-000003:notes:46]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2018. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-18-000003:notes:47]
[same as prior period, unchanged from 0000866374-17-000012:notes:44]

[0000866374-18-000003:notes:48]
[same as prior period, unchanged from 0000866374-17-000012:notes:45]

[0000866374-18-000003:notes:49]
The Company enters into forward contracts and foreign currency swap contracts primarily to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of December 31, 2017, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $8.2 billion as summarized below:

[0000866374-18-000003:notes:50]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 1,724,000 |  |  | — |  |  | $ | 262,937 |  |  | $ | — |  |
| EUR | 53,756 |  |  | 109,351 |  |  | 63,973 |  |  | 128,767 |  |
| HUF | 19,654,800 |  |  | — |  |  | 75,314 |  |  | — |  |
| ILS | 73,700 |  |  | — |  |  | 21,233 |  |  | — |  |
| INR | 1,392,540 |  |  | — |  |  | 21,200 |  |  | — |  |
| MXN | 3,072,680 |  |  | — |  |  | 154,955 |  |  | — |  |
| MYR | 173,000 |  |  | 39,500 |  |  | 42,318 |  |  | 9,662 |  |
| PLN | 87,890 |  |  | — |  |  | 24,963 |  |  | — |  |
| RON | 117,780 |  |  | — |  |  | 30,124 |  |  | — |  |
| SGD | 29,900 |  |  | — |  |  | 22,335 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 12,567 |  |  | 5,017 |  |
|  |  |  |  |  |  |  | 731,919 |  |  | 143,446 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 871,000 |  |  | — |  |  | 263,229 |  |
| CAD | 267,328 |  |  | 289,019 |  |  | 211,126 |  |  | 228,257 |  |
| CHF | 16,327 |  |  | 28,889 |  |  | 16,527 |  |  | 29,245 |  |
| CNY | 2,832,338 |  |  | — |  |  | 427,268 |  |  | — |  |
| EUR | 1,958,706 |  |  | 2,306,257 |  |  | 2,329,926 |  |  | 2,744,141 |  |
| GBP | 35,355 |  |  | 63,776 |  |  | 47,390 |  |  | 85,505 |  |
| HUF | 18,783,285 |  |  | 22,480,502 |  |  | 71,975 |  |  | 86,142 |  |
| INR | 6,222,378 |  |  | 1,252,331 |  |  | 96,829 |  |  | 19,200 |  |
| MXN | 2,254,587 |  |  | 1,374,623 |  |  | 113,699 |  |  | 69,322 |  |
| MYR | 456,260 |  |  | 247,030 |  |  | 111,607 |  |  | 60,427 |  |
| RON | 88,521 |  |  | 81,054 |  |  | 22,641 |  |  | 20,731 |  |
| SGD | 78,855 |  |  | 48,690 |  |  | 58,904 |  |  | 36,371 |  |
| Other | N/A |  |  | N/A |  |  | 114,386 |  |  | 81,631 |  |
|  |  |  |  |  |  |  | 3,622,278 |  |  | 3,724,201 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 4,354,197 |  |  | $ | 3,867,647 |  |

[0000866374-18-000003:notes:51]
As of December 31, 2017, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2017 and March 31, 2017, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were $7.2 million as of December 31, 2017, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-18-000003:notes:52]
[same as prior period, unchanged from 0000866374-17-000012:notes:49]

[0000866374-18-000003:notes:53]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31, 2017 |  | March 31, 2017 |  | Balance SheetLocation |  | December 31, 2017 |  | March 31, 2017 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 6,627 |  |  | $ | 11,936 |  |  | Other current liabilities |  | $ | 15,057 |  |  | $ | 1,814 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 14,376 |  |  | $ | 10,086 |  |  | Other current liabilities |  | $ | 10,273 |  |  | $ | 9,928 |  |

[0000866374-18-000003:notes:54]
[same as prior period, unchanged from 0000866374-17-000012:notes:51]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-18-000003:notes:55]
[same as prior period, unchanged from 0000866374-17-000012:notes:52]

[0000866374-18-000003:notes:56]
[same as prior period, unchanged from 0000866374-17-000012:notes:53]

[0000866374-18-000003:notes:57]
[same as prior period, unchanged from 0000866374-17-000012:notes:54]

[0000866374-18-000003:notes:58]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Cost of sales | $ | 5,358 |  |  | $ | 2,437 |  |  | $ | 13,662 |  |  | $ | 7,506 |  |
| Selling, general and administrative expenses | 15,400 |  |  | 18,344 |  |  | 49,356 |  |  | 59,805 |  |
| Total share-based compensation expense | $ | 20,758 |  |  | $ | 20,781 |  |  | $ | 63,018 |  |  | $ | 67,311 |  |

[0000866374-18-000003:notes:59]
Total unrecognized compensation expense related to share options under all plans was $8.9 million, and will be recognized over a weighted-average remaining vesting period of 2.2 years. As of December 31, 2017, the number of options outstanding and exercisable under all plans was 1.4 million and 0.5 million, respectively, at a weighted-average exercise price of $3.39 per share and $4.71 per share, respectively.

[0000866374-18-000003:notes:60]
During the nine-month period ended December 31, 2017, the Company granted 6.0 million unvested share bonus awards. Of this amount, approximately 4.3 million unvested share bonus awards have an average grant date price of $16.45 per share and vest over four years. Further, approximately 0.6 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $20.25 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 1.2 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. Also, an immaterial amount of options and share bonus awards were granted by the Company during the nine-month period ended December 31, 2017 under an immaterial plan.

[0000866374-18-000003:notes:61]
As of December 31, 2017, approximately 15.5 million unvested share bonus awards under all plans were outstanding, of which vesting for a targeted amount of 2.0 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.0 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2017, 1.4 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2015.

[0000866374-18-000003:notes:62]
As of December 31, 2017, total unrecognized compensation expense related to unvested share bonus awards under all plans was approximately $162.8 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-18-000003:notes:63]
[same as prior period, unchanged from 0000866374-17-000012:notes:60]

[0000866374-18-000003:notes:64]
[same as prior period, unchanged from 0000866374-17-000012:notes:61]

[0000866374-18-000003:notes:65]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 118,333 |  |  | $ | 129,469 |  |  | $ | 448,129 |  |  | $ | 232,690 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 528,405 |  |  | 539,638 |  |  | 529,984 |  |  | 542,780 |  |
| Basic earnings per share | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.85 |  |  | $ | 0.43 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 118,333 |  |  | $ | 129,469 |  |  | $ | 448,129 |  |  | $ | 232,690 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 528,405 |  |  | 539,638 |  |  | 529,984 |  |  | 542,780 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 5,947 |  |  | 5,384 |  |  | 5,988 |  |  | 5,592 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 534,352 |  |  | 545,022 |  |  | 535,972 |  |  | 548,372 |  |
| Diluted earnings per share | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.84 |  |  | $ | 0.42 |  |

[0000866374-18-000003:notes:66]
[same as prior period, unchanged from 0000866374-17-000012:notes:63]

[0000866374-18-000003:notes:67]
(1)         An immaterial amount of options and share bonus awards was excluded from the computation of diluted earnings per share during the three-month period ended December 31, 2017, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. Options to purchase ordinary shares of 0.5 million and an immaterial amount of anti-dilutive share bonus awards was excluded for the three-month period ended December 31, 2016.

[0000866374-18-000003:notes:68]
(2)         An immaterial amount of options and share bonus awards was excluded from the computation of diluted earnings per share during the nine-month period ended December 31, 2017, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. Options to purchase ordinary shares of 0.7 million and an immaterial amount of anti-dilutive share bonus awards was excluded for the nine-month period ended December 31, 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-18-000003:notes:69]
[same as prior period, unchanged from 0000866374-17-000012:notes:66]

[0000866374-18-000003:notes:70]
[same as prior period, unchanged from 0000866374-17-000012:notes:67]

[0000866374-18-000003:notes:71]
[same as prior period, unchanged from 0000866374-17-000012:notes:68]

[0000866374-18-000003:notes:72]
[same as prior period, unchanged from 0000866374-17-000012:notes:69]

[0000866374-18-000003:notes:73]
[same as prior period, unchanged from 0000866374-17-000012:notes:70]

[0000866374-18-000003:notes:74]
[same as prior period, unchanged from 0000866374-17-000012:notes:71]

[0000866374-18-000003:notes:75]
[same as prior period, unchanged from 0000866374-17-000012:notes:72]

[0000866374-18-000003:notes:76]
[same as prior period, unchanged from 0000866374-17-000012:notes:73]

[0000866374-18-000003:notes:77]
[same as prior period, unchanged from 0000866374-17-000012:notes:74]

[0000866374-18-000003:notes:78]
[same as prior period, unchanged from 0000866374-17-000012:notes:75]

[0000866374-18-000003:notes:79]
[same as prior period, unchanged from 0000866374-17-000012:notes:76]

[0000866374-18-000003:notes:80]
[same as prior period, unchanged from 0000866374-17-000012:notes:77]

[0000866374-18-000003:notes:81]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Beginning balance | $ | 17,342 |  |  | $ | 75,614 |  |  | $ | 22,426 |  |  | $ | 73,423 |  |
| Payments | (17,109 | ) |  | (40,555 | ) |  | (17,109 | ) |  | (42,776 | ) |
| Fair value adjustments | 767 |  |  | (6,997 | ) |  | (4,317 | ) |  | (2,585 | ) |
| Ending balance | $ | 1,000 |  |  | $ | 28,062 |  |  | $ | 1,000 |  |  | $ | 28,062 |  |

[0000866374-18-000003:notes:82]
In connection with the acquisition of NEXTracker, Inc. in fiscal year 2016, the Company had an obligation to pay additional cash consideration to the former shareholders contingent upon NEXTracker, Inc.'s achievement of revenue targets during the two years after acquisition (ending on September 30, 2017). During the nine-month period ended December 31, 2017, the Company paid $17.1 million of the total contingent consideration following the second year's targets achievement in accordance with the terms of the merger agreement. The payment of the contingent consideration is included in other financing activities, net, in the condensed consolidated statements of cash flows.

[0000866374-18-000003:notes:83]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2017 and December 31, 2016.

[0000866374-18-000003:notes:84]
[same as prior period, unchanged from 0000866374-17-000012:notes:82]

[0000866374-18-000003:notes:85]
[same as prior period, unchanged from 0000866374-17-000012:notes:83]

[0000866374-18-000003:notes:86]
|  | Fair Value Measurements as of December 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 424,744 |  |  | $ | — |  |  | $ | 424,744 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 21,003 |  |  | — |  |  | 21,003 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,212 |  |  | 67,503 |  |  | — |  |  | 74,715 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (25,330 | ) |  | $ | — |  |  | $ | (25,330 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (1,000 | ) |  | (1,000 | ) |
|  | Fair Value Measurements as of March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,066,841 |  |  | $ | — |  |  | $ | 1,066,841 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 22,022 |  |  | — |  |  | 22,022 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,062 |  |  | 52,680 |  |  | — |  |  | 59,742 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (11,742 | ) |  | $ | — |  |  | $ | (11,742 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (22,426 | ) |  | (22,426 | ) |

[0000866374-18-000003:notes:87]
[same as prior period, unchanged from 0000866374-17-000012:notes:85]

[0000866374-18-000003:notes:88]
[same as prior period, unchanged from 0000866374-17-000012:notes:86]

[0000866374-18-000003:notes:89]
|  | As of December 31, 2017 |  | As of March 31, 2017 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 516,925 |  |  | $ | 500,000 |  |  | $ | 526,255 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 691,875 |  |  | 693,605 |  |  | 700,000 |  |  | 699,566 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 (1) | 489,938 |  |  | 491,163 |  |  | 502,500 |  |  | 503,756 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 536,515 |  |  | 500,000 |  |  | 534,820 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,282 |  |  | 643,440 |  |  | 595,979 |  |  | 633,114 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 58,021 |  |  | 58,021 |  |  | 53,075 |  |  | 53,075 |  |  | Level 1 |
| Euro Term Loan due January 2022 | 119,786 |  |  | 119,786 |  |  | 107,357 |  |  | 107,357 |  |  | Level 1 |
| Total | $ | 2,955,902 |  |  | $ | 3,059,455 |  |  | $ | 2,958,911 |  |  | $ | 3,057,943 |  |  |  |

[0000866374-18-000003:notes:90]
[same as prior period, unchanged from 0000866374-17-000012:notes:88]

[0000866374-18-000003:notes:91]
The Company values its Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of December 31, 2017, the carrying amounts approximate fair values.

[0000866374-18-000003:notes:92]
[same as prior period, unchanged from 0000866374-17-000012:notes:90]


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-18-000003:notes:93]
[same as prior period, unchanged from 0000866374-17-000012:notes:91]

[0000866374-18-000003:notes:94]
[same as prior period, unchanged from 0000866374-17-000012:notes:92]

[0000866374-18-000003:notes:95]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements resulting in joint control of the board of directors between the Company and other non-controlling interest holders. As a result, the Company concluded it is no longer the primary beneficiary of Elementum and accordingly, deconsolidated the entity. The Company no longer recognizes the carrying value of the noncontrolling interest as a component of total shareholder’s equity resulting in a reduction of $90.6 million of noncontrolling interest from its condensed consolidated balance sheet upon deconsolidation, which was treated as a non-cash financing activity in the condensed consolidated statement of cash flows for the nine-month period ended December 31, 2017. Further, the Company derecognized approximately $72.6 million of cash of Elementum as of the date of deconsolidation which is reflected as an outflow from investing activities within other investing activities, net in the condensed consolidated statement of cash flows for the nine-month period ended December 31, 2017. There were no other material impacts to the condensed consolidated balance sheet or condensed consolidated cash flows resulting from deconsolidation of the entity. The noncontrolling interest in the operating losses of Elementum prior to deconsolidation is immaterial for all periods presented and is classified as a component of interest and other, net, in the Company's condensed consolidated statements of operations.

[0000866374-18-000003:notes:96]
The carrying amount of the Company’s variable interest in Elementum was approximately $129.7 million as of December 31, 2017, is accounted for as a cost method investment, and is included in other assets on the condensed consolidated balance sheet. The value of the Company’s variable interest on the date of deconsolidation was based on management’s estimate of the fair value of Elementum at that time. The Company concluded that the market approach was the most appropriate method to determine the fair value of the entity on the date of deconsolidation, given that Elementum raised equity funding from third-party investors around the same period. The Company recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, which is included in other charges (income), net on the condensed consolidated statement of operations. As the Company is not obligated to fund future losses of Elementum, the carrying amount is the Company’s maximum risk of loss. Pro-forma financials have not been presented because the effects were not material to the Company’s condensed consolidated financial position and results of operation for all periods presented. Elementum remains a related party to the Company after deconsolidation and transactions between the Company and Elementum during the three-month period ended December 31, 2017 are immaterial.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-18-000003:notes:97]
Recently Adopted Accounting Pronouncement

[0000866374-18-000003:notes:98]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-18-000003:notes:99]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company adopted the guidance effective April 1, 2017 and it did not have a material impact on its condensed consolidated financial statements.

[0000866374-18-000003:notes:100]
Recently Issued Accounting Pronouncements

[0000866374-18-000003:notes:101]
In August 2017, the FASB issued new guidance with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-18-000003:notes:102]
In August 2016, the FASB issued Accounting Standard Update (ASU) No. 2016-15, "Statement of Cash Flows (Topic 2030): Classification of Certain Cash Receipts and Cash Payments." The standard is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 is consistent with our current cash flow classification. However, cash receipts on the deferred purchase price as described in Note 10 will be classified as cash flow from investing activities instead of the Company's current presentation as cash flows from operations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019 and retrospectively report cash flows from operating and investing activities for all periods presented. While the Company is still quantifying the impact of adoption of this standard, it does expect the standard to result in a material increase in cash flows from investing activities and corresponding reduction in cash flows from operating activities for all periods presented.

[0000866374-18-000003:notes:103]
In February 2016, the FASB issued new guidance intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted.

[0000866374-18-000003:notes:104]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. The guidance is effective for the Company beginning in the first quarter of fiscal year 2019.

[0000866374-18-000003:notes:105]
The Company is in the process of implementation activities in accordance with the planned effective date. These activities are focused on the review of significant customer contracts, identification and development of additional systems capabilities to enable the Company to make reasonable estimates of revenue as products are manufactured, and the design and implementation of relevant internal controls. The Company has determined that the new standard will change the timing of revenue recognition for a significant portion of its business. Under the new standard, revenue for a significant majority of the manufacturing services customer contracts will be recognized earlier than under the current accounting rules (where Flex recognizes revenue based on shipping and delivery). This change will also have material impacts to the Company’s balance sheet, primarily related to a reduction in finished goods and work-in-process inventories and an increase in unbilled receivables.

[0000866374-18-000003:notes:106]
The new guidance allows for two transition methods in application - (i) retrospective to each prior reporting period presented, or (ii) prospective with the cumulative effect of adoption recognized on April 1, 2018, the first day of the Company's fiscal year 2019 (also known as the modified retrospective approach). The Company will adopt the standard using the modified retrospective approach, which will result in an adjustment to accumulated deficit for the cumulative effect of applying this guidance to contracts in process as of the adoption date. Under this approach, prior financial statements presented will not be restated. This guidance requires additional disclosures of the amount by which each financial statement line item affected in the current reporting period during fiscal year 2019 as compared to the guidance that was in effect before the change, and an explanation of the reasons for the significant changes.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-18-000003:notes:107]
[same as prior period, unchanged from 0000866374-17-000012:notes:103]


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-18-000003:notes:108]
[same as prior period, unchanged from 0000866374-17-000012:notes:109]

[0000866374-18-000003:notes:109]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 369,356 |  |  | $ | (135,411 | ) |  | $ | 233,945 |  |  | $ | 260,704 |  |  | $ | (105,912 | ) |  | $ | 154,792 |  |
| Licenses and other intangibles | 302,522 |  |  | (97,915 | ) |  | 204,607 |  |  | 283,897 |  |  | (76,508 | ) |  | 207,389 |  |
| Total | $ | 671,878 |  |  | $ | (233,326 | ) |  | $ | 438,552 |  |  | $ | 544,601 |  |  | $ | (182,420 | ) |  | $ | 362,181 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-18-000003:notes:110]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the nine-month period ended December 31, 2017:

[0000866374-18-000003:notes:111]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 420,935 |  |  | $ | 111,223 |  |  | $ | 337,707 |  |  | $ | 115,002 |  |  | $ | 984,867 |  |
| Additions (1) | 75,280 |  |  | — |  |  | — |  |  | 9,174 |  |  | 84,454 |  |
| Divestitures (2) | — |  |  | (3,475 | ) |  | — |  |  | — |  |  | (3,475 | ) |
| Purchase accounting adjustments | — |  |  | — |  |  | — |  |  | (14 | ) |  | (14 | ) |
| Foreign currency translation adjustments (3) | 38,938 |  |  | — |  |  | — |  |  | — |  |  | 38,938 |  |
| Balance, end of the period | $ | 535,153 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,162 |  |  | $ | 1,104,770 |  |

[0000866374-18-000003:notes:112]
| (1) | The goodwill generated from the Company’s acquisition of AGM Automotive ("AGM") in the HRS segment and the Company's acquisition of a Power Modules business in the CEC segment, completed during the nine-month period ended December 31, 2017, are primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0000866374-18-000003:notes:113]
| (2) | During the nine-month period ended December 31, 2017, the Company disposed of Wink Labs Inc. ("Wink"), a business within the CTG segment, and recorded an aggregate reduction of goodwill of $3.5 million accordingly, which is included as an offset to the gain on sale recorded in other charges (income), net on the condensed consolidated statement of operations. |

[0000866374-18-000003:notes:114]
| (3) | During the nine-month period ended December 31, 2017, the Company recorded $38.9 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi") and AGM, as the U.S. Dollar fluctuated against foreign currencies. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-18-000003:notes:115]
[same as prior period, unchanged from 0000866374-17-000012:notes:116]

[0000866374-18-000003:notes:116]
|  | As of December 31, 2017 |  | As of March 31, 2017 |
|  | (In thousands) |
| Raw materials | $ | 2,590,065 |  |  | $ | 2,537,623 |  |
| Work-in-progress | 446,469 |  |  | 279,493 |  |
| Finished goods | 689,109 |  |  | 579,346 |  |
|  | $ | 3,725,643 |  |  | $ | 3,396,462 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-18-000003:notes:117]
[same as prior period, unchanged from 0000866374-17-000012:notes:118]

[0000866374-18-000003:notes:118]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 1,979,045 |  |  | $ | 2,102,321 |  |  | $ | 5,853,435 |  |  | $ | 6,400,233 |  |
| Consumer Technologies Group | 2,056,801 |  |  | 1,848,970 |  |  | 5,323,913 |  |  | 4,827,488 |  |
| Industrial & Emerging Industries | 1,491,063 |  |  | 1,140,366 |  |  | 4,336,201 |  |  | 3,672,103 |  |
| High Reliability Solutions | 1,224,643 |  |  | 1,023,342 |  |  | 3,516,695 |  |  | 3,100,513 |  |
|  | $ | 6,751,552 |  |  | $ | 6,114,999 |  |  | $ | 19,030,244 |  |  | $ | 18,000,337 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 50,206 |  |  | $ | 62,109 |  |  | $ | 141,541 |  |  | $ | 176,460 |  |
| Consumer Technologies Group | 38,768 |  |  | 59,282 |  |  | 87,494 |  |  | 139,230 |  |
| Industrial & Emerging Industries | 61,328 |  |  | 39,681 |  |  | 167,650 |  |  | 127,020 |  |
| High Reliability Solutions | 100,976 |  |  | 82,729 |  |  | 283,552 |  |  | 249,972 |  |
| Corporate and Other | (31,557 | ) |  | (20,695 | ) |  | (94,273 | ) |  | (82,395 | ) |
| Total segment income | 219,721 |  |  | 223,106 |  |  | 585,964 |  |  | 610,287 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 19,588 |  |  | 18,734 |  |  | 55,865 |  |  | 62,318 |  |
| Stock-based compensation | 20,758 |  |  | 20,781 |  |  | 63,018 |  |  | 67,311 |  |
| Distressed customers asset impairments (1) | — |  |  | — |  |  | 4,753 |  |  | 92,915 |  |
| Contingencies and other (2) | — |  |  | 17,421 |  |  | 43,933 |  |  | 28,960 |  |
| Other charges (income), net | 6,865 |  |  | 3,090 |  |  | (172,467 | ) |  | 15,007 |  |
| Interest and other, net | 31,350 |  |  | 22,838 |  |  | 85,780 |  |  | 71,869 |  |
| Income before income taxes | $ | 141,160 |  |  | $ | 140,242 |  |  | $ | 505,082 |  |  | $ | 271,907 |  |

[0000866374-18-000003:notes:119]
[same as prior period, unchanged from 0000866374-17-000012:notes:120]

[0000866374-18-000003:notes:120]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the nine-month period ended December 31, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated direct costs. The total charge of $92.9 million is included in cost of sales for the nine-month period ended December 31, 2016 but is excluded from segment results above.

[0000866374-18-000003:notes:121]
(2)     During the second quarter of fiscal year 2018, the Company incurred charges in connection with the matters described in note 13, for certain loss contingencies where it believes that losses are probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted one of its China facilities.

[0000866374-18-000003:notes:122]
During fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $17.4 million and $29.0 million was recognized during the three and nine-month periods ended December 31, 2016, respectively. The plan was finalized and completed during fiscal year 2017.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-18-000003:notes:123]
[same as prior period, unchanged from 0000866374-17-000012:notes:124]

[0000866374-18-000003:notes:124]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2018 (1) | $ | 19,933 |  |
| 2019 | 74,510 |  |
| 2020 | 68,272 |  |
| 2021 | 63,839 |  |
| 2022 | 54,754 |  |
| Thereafter | 157,244 |  |
| Total amortization expense | $ | 438,552 |  |

[0000866374-18-000003:notes:125]
| (1) | Represents estimated amortization for the remaining three-month period ending March 31, 2018. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-18-000003:notes:126]
[same as prior period, unchanged from 0000866374-17-000012:notes:127]

[0000866374-18-000003:notes:127]
[same as prior period, unchanged from 0000866374-17-000012:notes:128]

[0000866374-18-000003:notes:128]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, other charges (income), net and interest and other, net.

[0000866374-18-000003:notes:129]
[same as prior period, unchanged from 0000866374-17-000012:notes:130]

[0000866374-18-000003:notes:130]
[same as prior period, unchanged from 0000866374-17-000012:notes:131]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-18-000003:notes:131]
[same as prior period, unchanged from 0000866374-17-000012:notes:132]

[0000866374-18-000003:notes:132]
[same as prior period, unchanged from 0000866374-17-000012:notes:133]

[0000866374-18-000003:notes:133]
[same as prior period, unchanged from 0000866374-17-000012:notes:134]

[0000866374-18-000003:notes:134]
The gross carrying amounts of intangible assets are removed when fully amortized. During the nine-month period ended December 31, 2017, the total value of intangible assets increased primarily as a result of the Company's estimated value of $82.0 million for customer related intangibles acquired with the AGM acquisition in the HRS segment, which will amortize over a weighted-average estimated useful life of 10 years, and $34.5 million for customer-related and licenses and other intangibles acquired with the power modules acquisition in the CEC segment, which will amortize over a weighted-average estimated useful life of 9 years. The increase was partially offset by $7.5 million for the divestiture of Wink in the CTG segment. The assigned value is subject to change as the Company completes the valuation. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-18-000003:notes:135]
[same as prior period, unchanged from 0000866374-17-000012:notes:136]

[0000866374-18-000003:notes:136]
Other current assets include approximately $420.6 million and $506.5 million as of December 31, 2017 and March 31, 2017, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0000866374-18-000003:notes:137]
[same as prior period, unchanged from 0000866374-17-000012:notes:138]

[0000866374-18-000003:notes:138]
During the first quarter of fiscal year 2018, the Company sold Wink to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59.0 million. This estimated consideration was based on the value of the acquirer as of the most recent third-party funding of which the Company participated. The Company recognized a non-cash gain on sale of $38.7 million, which is recorded in other charges (income), net on the condensed consolidated statement of operations in the nine-month period ended December 31, 2017. The contingent consideration is expected to be settled in the fourth quarter of fiscal year 2018, based on a remeasured fair value on the settlement date. As of December 31, 2017, the total investment, including working capital advances, of $76.5 million is accounted for as a cost method investment, and is included in other assets on the condensed consolidated balance sheet.

[0000866374-18-000003:notes:139]
During the second quarter of fiscal year 2018, the Company deconsolidated one of its majority owned subsidiaries, following the amendments of certain agreements that resulted in joint control of the board of directors between the Company and other non-controlling interest holders. As of December 31, 2017, this subsidiary is accounted for as a cost method investment of approximately $129.7 million and is included in other assets on the condensed consolidated balance sheet. See note 5 for additional information on the deconsolidation.

[0000866374-18-000003:notes:140]
[same as prior period, unchanged from 0000866374-17-000012:notes:141]

[0000866374-18-000003:notes:141]
Other current liabilities include customer working capital advances of $171.3 million and $231.3 million, customer-related accruals of $441.0 million and $501.9 million, and deferred revenue of $344.0 million and $280.7 million as of December 31, 2017 and March 31, 2017, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-18-000003:notes:142]
[same as prior period, unchanged from 0000866374-17-000012:notes:143]

[0000866374-18-000003:notes:143]
[same as prior period, unchanged from 0000866374-17-000012:notes:144]

[0000866374-18-000003:notes:144]
[same as prior period, unchanged from 0000866374-17-000012:notes:145]

[0000866374-18-000003:notes:145]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $950.0 million for the Global Program, of which $775.0 million is committed and $175.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-18-000003:notes:146]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and nine-month periods ended December 31, 2017 and December 31, 2016 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-18-000003:notes:147]
As of December 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $1.1 billion and deferred purchase price receivables of approximately $420.6 million. As of March 31, 2017, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.0 billion and deferred purchase price receivables of approximately $506.5 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of December 31, 2017 and March 31, 2017, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-18-000003:notes:148]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant.

[0000866374-18-000003:notes:149]
As of December 31, 2017 and March 31, 2017, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-18-000003:notes:150]
For the nine-month periods ended December 31, 2017 and December 31, 2016, cash flows from sales of receivables under the ABS Programs consisted of approximately $4.6 billion and $4.2 billion, for transfers of receivables, respectively (of which approximately $290.4 million and $315.1 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0000866374-18-000003:notes:151]
[same as prior period, unchanged from 0000866374-17-000012:notes:151]

[0000866374-18-000003:notes:152]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $233.3 million and $225.2 million as of December 31, 2017 and March 31, 2017, respectively. For the nine-month periods ended December 31, 2017 and December 31, 2016, total accounts receivable sold to certain third party banking institutions was approximately $1.0 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-18-000003:notes:153]
[same as prior period, unchanged from 0000866374-17-000012:notes:153]

[0000866374-18-000003:notes:154]
During the three-month and nine-month periods ended December 31, 2017, the Company repurchased 2.0 million shares at an aggregate purchase price of $35.0 million, and 10.8 million shares at an aggregate purchase price of $180.0 million, respectively, and retired all of these shares.

[0000866374-18-000003:notes:155]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 15, 2017. As of December 31, 2017, shares in the aggregate amount of $410.1 million were available to be repurchased under the current plan.
