# FLEX note change history — 0000866374-24-000012 → 0000866374-24-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a
  (was, 2024-02-02, similarity 0.9297):
[0000866374-24-000012:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2024-07-26):
[0000866374-24-000034:note_history:2]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2024-07-26):
[0000866374-24-000034:note_history:3]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

- added (2024-07-26):
[0000866374-24-000034:note_history:4]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. Two remain, where the Company was unsuccessful at the administrative level and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 36 million Brazilian reals (approximately USD $7 million). The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 59 million Brazilian reals (approximately USD $11 million). The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

- changed (2024-07-26):
[0000866374-24-000034:note_history:5]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.
  (was, 2024-02-02, similarity 0.9922):
[0000866374-24-000012:note_history:5]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2024-07-26):
[0000866374-24-000012:note_history:6]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $87 million based on the exchange rate as of December 31, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

- removed (2024-07-26):
[0000866374-24-000012:note_history:7]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-07-26):
[0000866374-24-000034:note_history:8]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities include design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 28, 2024, Flex's two operating and reportable segments were as follows:

- changed (2024-07-26):
[0000866374-24-000034:note_history:9]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.
  (was, 2024-02-02, similarity 0.8235):
[0000866374-24-000012:note_history:9]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

- changed (2024-07-26):
[0000866374-24-000034:note_history:10]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).
  (was, 2024-02-02, similarity 0.8839):
[0000866374-24-000012:note_history:10]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions, and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.

- changed (2024-07-26):
[0000866374-24-000034:note_history:11]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 28, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.
  (was, 2024-02-02, similarity 0.8985):
[0000866374-24-000012:note_history:11]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

- added (2024-07-26):
[0000866374-24-000034:note_history:12]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively.

- added (2024-07-26):
[0000866374-24-000034:note_history:13]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

- added (2024-07-26):
[0000866374-24-000034:note_history:14]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows

- added (2024-07-26):
[0000866374-24-000034:note_history:15]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

- changed (2024-07-26):
[0000866374-24-000034:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.
  (was, 2024-02-02, similarity 0.997):
[0000866374-24-000012:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

- added (2024-07-26):
[0000866374-24-000034:note_history:17]
Supplier Finance Programs

- changed (2024-07-26):
[0000866374-24-000034:note_history:18]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of June 28, 2024 and March 31, 2024 were $129 million and $123 million, respectively.
  (was, 2024-02-02, similarity 0.8345):
[0000866374-24-000012:note_history:18]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the nine-month period ended December 31, 2023 is as follows.

- changed (2024-07-26):
[0000866374-24-000034:note_history:19]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.
  (was, 2024-02-02, similarity 0.7617):
[0000866374-24-000012:note_history:19]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The

- changed (2024-07-26):
[0000866374-24-000034:note_history:20]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company is currently assessing the impact of ASU 2023-07 on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.
  (was, 2024-02-02, similarity 0.6814):
[0000866374-24-000012:note_history:20]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.

- removed (2024-07-26):
[0000866374-24-000012:note_history:21]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of December 31, 2023, Flex's three operating and reportable segments were as follows:

- removed (2024-07-26):
[0000866374-24-000012:note_history:22]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

- removed (2024-07-26):
[0000866374-24-000012:note_history:23]
Nextracker Spin-off

- removed (2024-07-26):
[0000866374-24-000012:note_history:24]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interests in Nextracker (the "Spin-off") to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023. Refer to note 17, “Subsequent Events” to the condensed consolidated financial statement for further details.

- removed (2024-07-26):
[0000866374-24-000012:note_history:25]
The third quarters for fiscal years 2024 and 2023 ended on December 31 of each year and are comprised of 93 and 92 days, respectively. The Company's first three quarters for fiscal years 2024 and 2023 both are comprised of 275 days.

- removed (2024-07-26):
[0000866374-24-000012:note_history:26]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of December 31, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

- removed (2024-07-26):
[0000866374-24-000012:note_history:27]
In October 2023, the FASB issued ASU 2023-06 "Disclosure Improvements - Codification Amendments in Response to the SEC's Disclosure Update and Simplification Initiative", which amends the disclosure or presentation requirements related to various subtopics in the FASB Accounting Standard Codification (the "Codification"). This ASU will become effective on the date the SEC removes the applicable disclosure from Regulation S-X or Regulation S-K, with early adoption prohibited. If by June 30, 2027, the SEC has not removed the applicable requirement from Regulation S-X or Regulation S-K, the pending content of the related amendment will be removed from the Codification and will not be become effective for any entity. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective.

- removed (2024-07-26):
[0000866374-24-000012:note_history:28]
Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

- removed (2024-07-26):
[0000866374-24-000012:note_history:29]
Recently Adopted Accounting Pronouncement

- removed (2024-07-26):
[0000866374-24-000012:note_history:30]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a rollforward of changes in those obligations, with immaterial impacts on its condensed consolidated financial statements.

- removed (2024-07-26):
[0000866374-24-000012:note_history:31]
|  | Nine-Month Period Ended |
|  | December 31, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 812 |  |
| Confirmed invoices paid during the period | (897) |  |
| Foreign currency exchange impact | 4 |  |
| Confirmed obligations outstanding at the end of the period | $ | 194 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:32]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2024 and March 31, 2024 are as follows:
  (was, 2024-02-02, similarity 0.9569):
[0000866374-24-000012:note_history:32]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2023 and March 31, 2023 are as follows:

- changed (2024-07-26):
[0000866374-24-000034:note_history:33]
|  | Maturity Date |  | As of June 28, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 543 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 681 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 680 |  |  | 681 |  |
| 3.600% HUF Bonds | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (12) |  |  | (15) |  |
|  |  |  | 3,215 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (543) |  |  | — |  |
| Non-current portion |  |  | $ | 2,672 |  |  | $ | 3,261 |  |
  (was, 2024-02-02, similarity 0.8631):
[0000866374-24-000012:note_history:33]
|  | Maturity Date |  | As of December 31, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 592 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 683 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 682 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 290 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (18) |  |  | (21) |  |
|  |  |  | 3,434 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (3) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,431 |  |  | $ | 3,691 |  |

- changed (2024-07-26):
[0000866374-24-000034:note_history:34]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations
  (was, 2024-02-02, similarity 0.9122):
[0000866374-24-000012:note_history:34]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

- changed (2024-07-26):
[0000866374-24-000034:note_history:35]
The weighted-average interest rate for the Company's long-term debt was 4.4% and 4.5% as of June 28, 2024 and March 31, 2024, respectively.
  (was, 2024-02-02, similarity 0.9603):
[0000866374-24-000012:note_history:35]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of December 31, 2023 and March 31, 2023, respectively.

- changed (2024-07-26):
[0000866374-24-000034:note_history:36]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 28, 2024 are as follows:
  (was, 2024-02-02, similarity 0.9524):
[0000866374-24-000012:note_history:36]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2023 are as follows:

- changed (2024-07-26):
[0000866374-24-000034:note_history:37]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,224 |  |
| 2027 |  | — |  |
| 2028 |  | 397 |  |
| 2029 |  | 27 |  |
| Thereafter |  | 1,579 |  |
| Total |  | $ | 3,227 |  |
  (was, 2024-02-02, similarity 0.9892):
[0000866374-24-000012:note_history:37]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | 3 |  |
| 2026 |  | 1,275 |  |
| 2027 |  | — |  |
| 2028 |  | 544 |  |
| Thereafter |  | 1,630 |  |
| Total |  | $ | 3,452 |  |

- changed (2024-07-26):
[0000866374-24-000034:note_history:38]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2025.
  (was, 2024-02-02, similarity 0.963):
[0000866374-24-000012:note_history:38]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2024.

- removed (2024-07-26):
[0000866374-24-000012:note_history:39]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

- removed (2024-07-26):
[0000866374-24-000012:note_history:40]
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:41]
|  | As of June 28, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 543 |  |  | $ | 538 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 681 |  |  | 661 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 403 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 638 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 680 |  |  | 659 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 269 |  |  | 215 |  |  | 274 |  |  | 219 |  |  | Level 2 |
  (was, 2024-02-02, similarity 0.7712):
[0000866374-24-000012:note_history:41]
|  | As of December 31, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 592 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 683 |  |  | 662 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 646 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 682 |  |  | 671 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 212 |  |  | 284 |  |  | 196 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:42]
Bank borrowings and long-term debt as of June 28, 2024 and March 31, 2024 are as follows:
  (was, 2024-02-02, similarity 0.9383):
[0000866374-24-000012:note_history:42]
Bank borrowings and long-term debt as of December 31, 2023 and March 31, 2023 are as follows:

- changed (2024-07-26):
[0000866374-24-000034:note_history:43]
|  | Maturity Date |  | As of June 28, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 543 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 681 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 680 |  |  | 681 |  |
| 3.600% HUF Bonds | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (12) |  |  | (15) |  |
|  |  |  | 3,215 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (543) |  |  | — |  |
| Non-current portion |  |  | $ | 2,672 |  |  | $ | 3,261 |  |
  (was, 2024-02-02, similarity 0.8631):
[0000866374-24-000012:note_history:43]
|  | Maturity Date |  | As of December 31, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 592 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 683 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 682 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 290 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (18) |  |  | (21) |  |
|  |  |  | 3,434 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (3) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,431 |  |  | $ | 3,691 |  |

- changed (2024-07-26):
[0000866374-24-000034:note_history:44]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations
  (was, 2024-02-02, similarity 0.9122):
[0000866374-24-000012:note_history:44]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

- removed (2024-07-26):
[0000866374-24-000012:note_history:45]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million. 
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:46]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 28, 2024 are as follows:
  (was, 2024-02-02, similarity 0.9524):
[0000866374-24-000012:note_history:46]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2023 are as follows:

- changed (2024-07-26):
[0000866374-24-000034:note_history:47]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,224 |  |
| 2027 |  | — |  |
| 2028 |  | 397 |  |
| 2029 |  | 27 |  |
| Thereafter |  | 1,579 |  |
| Total |  | $ | 3,227 |  |
  (was, 2024-02-02, similarity 0.9892):
[0000866374-24-000012:note_history:47]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | 3 |  |
| 2026 |  | 1,275 |  |
| 2027 |  | — |  |
| 2028 |  | 544 |  |
| Thereafter |  | 1,630 |  |
| Total |  | $ | 3,452 |  |

- changed (2024-07-26):
[0000866374-24-000034:note_history:48]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2025.
  (was, 2024-02-02, similarity 0.963):
[0000866374-24-000012:note_history:48]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2024.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:49]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 28, 2024 and June 30, 2023, respectively.
  (was, 2024-02-02, similarity 0.8722):
[0000866374-24-000012:note_history:49]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively.

- added (2024-07-26):
[0000866374-24-000034:note_history:50]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |
| Point in time | $ | 2,873 |  |  | $ | 3,436 |  |
| Over time | 492 |  |  | 165 |  |
| Total | 3,365 |  |  | 3,601 |  |
| FRS |  |  |  |
| Point in time | 2,633 |  |  | 3,132 |  |
| Over time | 316 |  |  | 159 |  |
| Total | 2,949 |  |  | 3,291 |  |
| Flex |  |  |  |
| Point in time | 5,506 |  |  | 6,568 |  |
| Over time | 808 |  |  | 324 |  |
| Total | $ | 6,314 |  |  | $ | 6,892 |  |

- removed (2024-07-26):
[0000866374-24-000012:note_history:51]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,152 |  |  | $ | 3,812 |  |  | $ | 9,868 |  |  | $ | 11,378 |  |
| Over time | 314 |  |  | 217 |  |  | 817 |  |  | 646 |  |
| Total | 3,466 |  |  | 4,029 |  |  | 10,685 |  |  | 12,024 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,793 |  |  | 3,038 |  |  | 9,069 |  |  | 8,938 |  |
| Over time | 163 |  |  | 187 |  |  | 492 |  |  | 555 |  |
| Total | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 8 |  |  | 33 |  |  | 41 |  |
| Over time | 704 |  |  | 508 |  |  | 1,730 |  |  | 1,343 |  |
| Total | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,922 |  |  | 6,844 |  |  | 18,871 |  |  | 20,325 |  |
| Over time | 1,181 |  |  | 912 |  |  | 3,039 |  |  | 2,544 |  |
| Total | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-26):
[0000866374-24-000034:note_history:52]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $395 million and $490 million as of June 28, 2024 and March 31, 2024, respectively, of which $355 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2024-02-02, similarity 0.9847):
[0000866374-24-000012:note_history:52]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $755 million and $885 million as of December 31, 2023 and March 31, 2023, respectively, of which $626 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2024-07-26):
[0000866374-24-000034:note_history:53]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 28, 2024 and June 30, 2023, respectively.
  (was, 2024-02-02, similarity 0.8722):
[0000866374-24-000012:note_history:53]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively.

- added (2024-07-26):
[0000866374-24-000034:note_history:54]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |
| Point in time | $ | 2,873 |  |  | $ | 3,436 |  |
| Over time | 492 |  |  | 165 |  |
| Total | 3,365 |  |  | 3,601 |  |
| FRS |  |  |  |
| Point in time | 2,633 |  |  | 3,132 |  |
| Over time | 316 |  |  | 159 |  |
| Total | 2,949 |  |  | 3,291 |  |
| Flex |  |  |  |
| Point in time | 5,506 |  |  | 6,568 |  |
| Over time | 808 |  |  | 324 |  |
| Total | $ | 6,314 |  |  | $ | 6,892 |  |

- removed (2024-07-26):
[0000866374-24-000012:note_history:55]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,152 |  |  | $ | 3,812 |  |  | $ | 9,868 |  |  | $ | 11,378 |  |
| Over time | 314 |  |  | 217 |  |  | 817 |  |  | 646 |  |
| Total | 3,466 |  |  | 4,029 |  |  | 10,685 |  |  | 12,024 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,793 |  |  | 3,038 |  |  | 9,069 |  |  | 8,938 |  |
| Over time | 163 |  |  | 187 |  |  | 492 |  |  | 555 |  |
| Total | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 8 |  |  | 33 |  |  | 41 |  |
| Over time | 704 |  |  | 508 |  |  | 1,730 |  |  | 1,343 |  |
| Total | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,922 |  |  | 6,844 |  |  | 18,871 |  |  | 20,325 |  |
| Over time | 1,181 |  |  | 912 |  |  | 3,039 |  |  | 2,544 |  |
| Total | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-07-26):
[0000866374-24-000012:note_history:56]
SUBSEQUENT EVENTS
On January 2, 2024, Flex completed the Spin-off of our remaining interests in Nextracker to Flex shareholders on a pro rata basis based on the number ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution. Under the previously disclosed terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for every Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

- removed (2024-07-26):
[0000866374-24-000012:note_history:57]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and Flex will no longer consolidate Nextracker into its future financial results. Following the Spin-off, Flex ordinary shares continue to trade on Nasdaq under the ticker symbol “FLEX” and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol “NXT”.

- removed (2024-07-26):
[0000866374-24-000012:note_history:58]
The historical results of Nextracker will be reported in Flex's consolidated financial statements as discontinued operations beginning in Flex's fourth quarter ending March 31, 2024.

- removed (2024-07-26):
[0000866374-24-000012:note_history:59]
Prior to or in connection with the Spin-off, Flex entered into various agreements to effect the Spin-off and provide a framework for the relationship between Flex and Nextracker following the Spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.
