# FLEX 8-K — 0000866374-24-000031 filed 2024-07-24

## item codes, every 8-K on or before 2024-07-26

- 2024-07-24 0000866374-24-000031 — 2.02, 5.02, 9.01
- 2024-06-14 0000866374-24-000028 — 5.02
- 2024-05-01 0000866374-24-000017 — 2.02, 2.05, 5.02, 9.01
- 2024-01-31 0000866374-24-000009 — 2.02, 9.01
- 2024-01-02 0000866374-24-000005 — 1.01, 2.01, 7.01, 9.01
- 2023-12-18 0000866374-23-000072 — 8.01, 9.01
- 2023-11-20 0000866374-23-000070 — 5.07, 8.01
- 2023-10-25 0000866374-23-000063 — 2.02, 7.01, 8.01, 9.01
- 2023-08-07 0000866374-23-000060 — 5.02, 5.07, 8.01
- 2023-07-26 0000866374-23-000054 — 2.02, 9.01
- 2023-06-30 0000866374-23-000048 — 8.01, 9.01
- 2023-06-29 0000866374-23-000043 — 8.01, 9.01
- 2023-06-26 0000866374-23-000038 — 8.01, 9.01
- 2023-06-16 0000866374-23-000035 — 5.02
- 2023-05-10 0000866374-23-000023 — 2.02, 9.01
- 2023-02-13 0001193125-23-035922 — 1.01, 9.01
- 2023-02-10 0000866374-23-000016 — 8.01, 9.01
- 2023-02-09 0000866374-23-000014 — 8.01, 9.01
- 2023-02-01 0000866374-23-000011 — 7.01, 8.01, 9.01
- 2023-01-25 0000866374-23-000004 — 2.02, 9.01
- 2022-12-07 0001104659-22-125181 — 1.01, 9.01
- 2022-12-01 0001104659-22-123665 — 8.01, 9.01
- 2022-11-17 0000866374-22-000078 — 8.01
- 2022-10-26 0000866374-22-000070 — 2.02, 9.01
- 2022-09-27 0000866374-22-000066 — 5.02, 9.01
- 2022-08-26 0000866374-22-000063 — 5.07, 8.01
- 2022-07-27 0000866374-22-000048 — 2.02, 9.01
- 2022-07-22 0000866374-22-000045 — 1.01, 1.02, 2.03, 9.01
- 2022-06-03 0000866374-22-000041 — 5.02
- 2022-05-04 0000866374-22-000030 — 2.02, 9.01
- 2022-03-30 0000866374-22-000026 — 7.01, 9.01
- 2022-03-25 0000866374-22-000022 — 5.02
- 2022-02-17 0000866374-22-000019 — 5.02
- 2022-02-02 0000866374-22-000014 — 8.01, 9.01
- 2022-01-27 0000866374-22-000010 — 5.02, 9.01
- 2022-01-26 0000866374-22-000005 — 2.02, 9.01
- 2021-12-01 0000866374-21-000065 — 7.01, 9.01
- 2021-10-27 0000866374-21-000059 — 2.02, 9.01
- 2021-10-18 0000866374-21-000054 — 7.01, 9.01
- 2021-08-05 0000866374-21-000050 — 5.07, 8.01
- 2021-07-29 0000866374-21-000040 — 2.02, 9.01
- 2021-06-15 0000866374-21-000036 — 5.02
- 2021-05-05 0000866374-21-000027 — 2.02, 9.01
- 2021-02-26 0000866374-21-000021 — 5.02
- 2021-01-28 0000866374-21-000016 — 2.02, 9.01
- 2021-01-22 0000866374-21-000012 — 5.02 — amendment of 0000866374-20-000037
- 2021-01-13 0000866374-21-000006 — 1.01, 1.02, 2.03, 9.01
- 2020-11-24 0000866374-20-000037 — 5.02, 9.01
- 2020-11-23 0000866374-20-000034 — 5.02, 7.01, 9.01
- 2020-10-29 0000866374-20-000028 — 2.02, 9.01
- 2020-09-21 0000866374-20-000021 — 5.02, 9.01
- 2020-09-18 0000866374-20-000017 — 5.02
- 2020-08-17 0001104659-20-096092 — 1.01, 8.01, 9.01
- 2020-08-11 0001104659-20-093288 — 5.02, 5.07, 9.01
- 2020-08-07 0001104659-20-092018 — 5.02, 7.01, 9.01
- 2020-07-30 0001104659-20-088503 — 2.02, 9.01
- 2020-06-09 0001104659-20-071371 — 5.02, 9.01
- 2020-06-03 0001104659-20-069435 — 5.02, 9.01
- 2020-05-12 0001104659-20-060179 — 1.01, 8.01, 9.01
- 2020-05-07 0001104659-20-058102 — 2.02, 8.01, 9.01
- 2020-04-20 0000866374-20-000005 — 5.02, 9.01 — amendment of 0001104659-20-044212
- 2020-04-07 0001104659-20-044212 — 5.02, 7.01, 9.01
- 2020-04-02 0001104659-20-042445 — 5.02, 8.01, 9.01
- 2020-03-09 0001104659-20-030489 — 7.01, 9.01
- 2020-01-30 0001104659-20-008704 — 2.02, 9.01
- 2019-11-07 0001104659-19-061133 — 8.01, 9.01
- 2019-10-24 0001104659-19-056135 — 2.02, 9.01
- 2019-08-23 0001410578-19-000891 — 3.03, 5.07, 8.01, 9.01
- 2019-08-08 0001410578-19-000722 — 8.01
- 2019-07-25 0001104659-19-041852 — 2.02, 2.05, 9.01
- 2019-06-10 0001410578-19-000371 — 5.02
- 2019-06-06 0001104659-19-034315 — 1.01, 8.01, 9.01
- 2019-05-31 0001104659-19-032835 — 8.01, 9.01
- 2019-05-30 0001104659-19-032818 — 8.01, 9.01
- 2019-05-30 0001104659-19-032593 — 8.01, 9.01
- 2019-04-30 0001104659-19-025293 — 2.02, 9.01
- 2019-03-07 0001104659-19-013420 — 5.02
- 2019-02-11 0001104659-19-006978 — 5.02, 7.01, 9.01
- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2024-07-26

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0000866374-24-000031:8k_2_02:1]
EX-99.1
2
flexex991-7242024.htm
EX-99.1

[0000866374-24-000031:8k_2_02:2]
Document

[0000866374-24-000031:8k_2_02:3]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:4]
EXHIBIT 99.1

[0000866374-24-000031:8k_2_02:5]
FLEX REPORTS FIRST QUARTER FISCAL 2025 RESULTS, 
ANNOUNCES CHIEF FINANCIAL OFFICER TRANSITION

[0000866374-24-000031:8k_2_02:6]
Austin, Texas, July 24, 2024 – Flex (NASDAQ: FLEX) today announced results for its first quarter ended June 28, 2024.

[0000866374-24-000031:8k_2_02:7]
First Quarter Fiscal Year 2025 Highlights:

[0000866374-24-000031:8k_2_02:8]
•Net Sales: $6.3 billion

[0000866374-24-000031:8k_2_02:9]
•GAAP Operating Income: $233 million

[0000866374-24-000031:8k_2_02:10]
•Adjusted Operating Income: $306 million

[0000866374-24-000031:8k_2_02:11]
•GAAP Net Income attributable to Flex Ltd: $139 million

[0000866374-24-000031:8k_2_02:12]
•Adjusted Net Income attributable to Flex Ltd: $211 million

[0000866374-24-000031:8k_2_02:13]
•GAAP Earnings Per Share: $0.34

[0000866374-24-000031:8k_2_02:14]
•Adjusted Earnings Per Share: $0.51

[0000866374-24-000031:8k_2_02:15]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0000866374-24-000031:8k_2_02:16]
"We delivered another solid quarter, including year-over-year margin expansion and EPS growth," said Revathi Advaithi, CEO of Flex. "Our results show we continue to navigate through the dynamic cycle and drive value to our stakeholders."

[0000866374-24-000031:8k_2_02:17]
Second Quarter Fiscal 2025 Guidance

[0000866374-24-000031:8k_2_02:18]
•Revenue: $6.2 billion to $6.8 billion

[0000866374-24-000031:8k_2_02:19]
•GAAP Operating Income: $257 million to $297 million

[0000866374-24-000031:8k_2_02:20]
•Adjusted Operating Income: $310 million to $350 million

[0000866374-24-000031:8k_2_02:21]
•GAAP EPS: $0.40 to $0.48.

[0000866374-24-000031:8k_2_02:22]
•Adjusted EPS: $0.52 to $0.60 which excludes $0.08 for stock-based compensation expense, $0.03 for net intangible amortization, and $0.01 for net restructuring charges

[0000866374-24-000031:8k_2_02:23]
Fiscal Year 2025 Guidance

[0000866374-24-000031:8k_2_02:24]
•Revenue: $25.4 billion to $26.4 billion

[0000866374-24-000031:8k_2_02:25]
•GAAP EPS: $1.60 to $1.80

[0000866374-24-000031:8k_2_02:26]
•Adjusted EPS: $2.30 to $2.50 which excludes $0.32 for stock-based compensation expense, $0.25 for net restructuring charges, and $0.13 for net intangible amortization

[0000866374-24-000031:8k_2_02:27]
Flex, today also announced that Paul Lundstrom will step down as Chief Financial Officer effective July 31, 2024 to pursue an opportunity outside of Flex.

[0000866374-24-000031:8k_2_02:28]
At that time, Jaime Martinez will assume the role of Interim Chief Financial Officer. Mr. Martinez has over 20 years of experience with Flex, and has held various finance leadership roles, including financial planning and analysis, commercial, and operations.

[0000866374-24-000031:8k_2_02:29]
“Paul has been a trusted partner and exceptional leader at Flex over the past four years,” said Revathi Advaithi, CEO, Flex. “He has played a key role in delivering on our strategy, driving discipline across the organization, and creating value for our shareholders. On behalf of the

[0000866374-24-000031:8k_2_02:30]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:31]
Board of Directors and our entire team, I thank him for his many contributions and wish him well in his future endeavors.”

[0000866374-24-000031:8k_2_02:32]
Flex has initiated an executive search process to identify a permanent CFO. Mr. Lundstrom has agreed to assist in the orderly transition of his CFO responsibilities to Mr. Martinez along with the seasoned Finance leadership team.

[0000866374-24-000031:8k_2_02:33]
“I would like to thank Revathi Advaithi, the Board of Directors, and the Flex employees for the opportunity to be a part of the team over the last four years,” said Paul Lundstrom, outgoing CFO, Flex. “The long-term opportunities for Flex remain significant, and I am leaving Flex in the capable hands of the Finance leadership team. I wish the company much success in the future.”

[0000866374-24-000031:8k_2_02:34]
Webcast and Conference Call

[0000866374-24-000031:8k_2_02:35]
The Flex management team will host a conference call today at 5:30 AM (PT) / 8:30 AM (ET), to review first quarter fiscal 2025 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0000866374-24-000031:8k_2_02:36]
About Flex

[0000866374-24-000031:8k_2_02:37]
Flex (Reg. No. 199002645H) is the manufacturing partner of choice that helps a diverse customer base design and build products that improve the world. Through the collective strength of a global workforce across 30 countries and responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets.

[0000866374-24-000031:8k_2_02:38]
Contacts

[0000866374-24-000031:8k_2_02:39]
Investors & Analysts

[0000866374-24-000031:8k_2_02:40]
David Rubin

[0000866374-24-000031:8k_2_02:41]
Vice President, Investor Relations

[0000866374-24-000031:8k_2_02:42]
(408) 577-4632

[0000866374-24-000031:8k_2_02:43]
David.Rubin@flex.com

[0000866374-24-000031:8k_2_02:44]
Media & Press

[0000866374-24-000031:8k_2_02:45]
Yvette Lorenz

[0000866374-24-000031:8k_2_02:46]
Director, Corporate PR and Executive Communications

[0000866374-24-000031:8k_2_02:47]
(415) 225-7315

[0000866374-24-000031:8k_2_02:48]
Yvette.Lorenz@flex.com

[0000866374-24-000031:8k_2_02:49]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:50]
Forward-Looking Statements

[0000866374-24-000031:8k_2_02:51]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our most recent Annual Report on Form 10-K and in our subsequent filings with the U.S. Securities and Exchange Commission. Flex assumes no obligation to update any forward-looking statements, which speak only as of the date they are made.

[0000866374-24-000031:8k_2_02:52]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:53]
SCHEDULE I

[0000866374-24-000031:8k_2_02:54]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | June 28, 2024 |  | June 30, 2023 |
| GAAP: |  |  |  |
|  | Net sales | $ | 6,314 |  |  | $ | 6,892 |  |
|  | Cost of sales | 5,827 |  |  | 6,399 |  |
|  | Restructuring charges | 16 |  |  | 17 |  |
|  | Gross profit | 471 |  |  | 476 |  |
|  | Selling, general and administrative expenses | 213 |  |  | 235 |  |
|  | Restructuring charges | 9 |  |  | 6 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Operating income | 233 |  |  | 215 |  |
|  | Interest expense | 56 |  |  | 56 |  |
|  | Interest income | 16 |  |  | 16 |  |
|  | Other charges, net | 1 |  |  | 11 |  |
|  | Income from continuing operations before income taxes | 192 |  |  | 164 |  |
|  | Provision for income taxes | 53 |  |  | 17 |  |
|  | Net income from continuing operations | 139 |  |  | 147 |  |
|  | Net income from discontinued operations, net of tax | — |  |  | 64 |  |
|  | Net income | $ | 139 |  |  | $ | 211 |  |
|  | Noncontrolling interest | — |  |  | 25 |  |
|  | Net income attributable to Flex Ltd. | 139 |  |  | 186 |  |
| GAAP EPS |
|  | Diluted earnings per share from continuing operations | $ | 0.34 |  |  | $ | 0.32 |  |
|  | Diluted earnings per share from discontinued operations | $ | — |  |  | $ | 0.09 |  |
|  | Diluted earnings per share attributable to the shareholders of Flex Ltd. | $ | 0.34 |  |  | $ | 0.41 |  |
|  | Diluted shares used in computing per share amounts | 411 |  |  | 455 |  |
|  | See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |

[0000866374-24-000031:8k_2_02:55]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:56]
SCHEDULE II

[0000866374-24-000031:8k_2_02:57]
| FLEX |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1) |
| (In millions, except per share amounts) |
|  |  | Three-Month Periods Ended |
|  |  | June 28, 2024 |  | June 30, 2023 |
| GAAP operating income | $ | 233 |  |  | $ | 215 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Stock-based compensation expense | 32 |  |  | 32 |  |
|  | Restructuring charges | 25 |  |  | 23 |  |
|  | Legal and other | — |  |  | 3 |  |
| Non-GAAP operating income | $ | 306 |  |  | $ | 293 |  |
| GAAP provision for income taxes | $ | 53 |  |  | $ | 17 |  |
|  | Intangible amortization benefit | 3 |  |  | 3 |  |
|  | Other tax related adjustments | (2) |  |  | 9 |  |
| Non-GAAP provision for income taxes | $ | 54 |  |  | $ | 29 |  |
| GAAP net income from continuing operations | $ | 139 |  |  | $ | 147 |  |
|  | Intangible amortization | 16 |  |  | 20 |  |
|  | Stock-based compensation expense | 32 |  |  | 32 |  |
|  | Restructuring charges | 25 |  |  | 23 |  |
|  | Legal and other | — |  |  | 3 |  |
|  | Interest and other, net | — |  |  | 1 |  |
|  | Adjustments for taxes | (1) |  |  | (12) |  |
| Non-GAAP net income from continuing operations | $ | 211 |  |  | $ | 214 |  |
| Diluted earnings per share from continuing operations: |
|  | GAAP | $ | 0.34 |  |  | $ | 0.32 |  |
|  | Non-GAAP | $ | 0.51 |  |  | $ | 0.47 |  |
|  | See the accompanying notes on Schedule V attached to this press release. |

[0000866374-24-000031:8k_2_02:58]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:59]
SCHEDULE III

[0000866374-24-000031:8k_2_02:60]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
|  |  | As of June 28, 2024 |  | As of March 31, 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
|  | Cash and cash equivalents | $ | 2,243 |  |  | $ | 2,474 |  |
|  | Accounts receivable, net of allowance for doubtful accounts | 2,952 |  |  | 3,033 |  |
|  | Contract assets | 457 |  |  | 249 |  |
|  | Inventories | 5,839 |  |  | 6,205 |  |
|  | Other current assets | 1,057 |  |  | 1,031 |  |
| Total current assets | 12,548 |  |  | 12,992 |  |
| Property and equipment, net | 2,228 |  |  | 2,269 |  |
| Operating lease right-of-use assets, net | 573 |  |  | 601 |  |
| Goodwill | 1,139 |  |  | 1,135 |  |
| Other intangible assets, net | 230 |  |  | 245 |  |
| Other non-current assets | 1,019 |  |  | 1,015 |  |
| Total assets | $ | 17,737 |  |  | $ | 18,257 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |
|  | Bank borrowings and current portion of long-term debt | $ | 543 |  |  | $ | — |  |
|  | Accounts payable | 4,726 |  |  | 4,468 |  |
|  | Accrued payroll and benefits | 428 |  |  | 488 |  |
|  | Deferred revenue and customer working capital advances | 2,265 |  |  | 2,615 |  |
|  | Other current liabilities | 1,007 |  |  | 968 |  |
| Total current liabilities | 8,969 |  |  | 8,539 |  |
| Long-term debt, net of current portion | 2,672 |  |  | 3,261 |  |
| Operating lease liabilities, non-current | 463 |  |  | 490 |  |
| Other non-current liabilities | 637 |  |  | 642 |  |
| Total liabilities | 12,741 |  |  | 12,932 |  |
| Total shareholders’ equity | 4,996 |  |  | 5,325 |  |
| Total liabilities and shareholders' equity | $ | 17,737 |  |  | $ | 18,257 |  |

[0000866374-24-000031:8k_2_02:61]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:62]
SCHEDULE IV

[0000866374-24-000031:8k_2_02:63]
| FLEX |
| UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
|  |  | Three-Month Periods Ended |
|  |  | June 28, 2024 |  | June 30, 2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
|  | Net income | $ | 139 |  |  | $ | 211 |  |
|  | Depreciation, amortization and other impairment charges | 126 |  |  | 133 |  |
|  | Changes in working capital and other, net | 75 |  |  | (338) |  |
|  | Net cash provided by operating activities | 340 |  |  | 6 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
|  | Purchases of property and equipment | (111) |  |  | (167) |  |
|  | Proceeds from the disposition of property and equipment | 3 |  |  | 11 |  |
|  | Acquisition of businesses, net of cash acquired | 2 |  |  | — |  |
|  | Other investing activities, net | 24 |  |  | 1 |  |
|  | Net cash used in investing activities | (82) |  |  | (155) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
|  | Proceeds from bank borrowings and long-term debt | — |  |  | 2 |  |
|  | Repayments of bank borrowings and long-term debt | (41) |  |  | (243) |  |
|  | Payments for repurchases of ordinary shares | (457) |  |  | (197) |  |
|  | Other financing activities, net | 30 |  |  | (48) |  |
|  | Net cash used in financing activities | (468) |  |  | (486) |  |
| Effect of exchange rates on cash and cash equivalents | (21) |  |  | 1 |  |
|  | Net decrease in cash and cash equivalents | (231) |  |  | (634) |  |
|  | Cash and cash equivalents, beginning of period | 2,474 |  |  | 3,294 |  |
|  | Cash and cash equivalents, end of period | $ | 2,243 |  |  | $ | 2,660 |  |

[0000866374-24-000031:8k_2_02:64]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:65]
SCHEDULE V

[0000866374-24-000031:8k_2_02:66]
FLEX AND SUBSIDIARIES

[0000866374-24-000031:8k_2_02:67]
NOTES TO SCHEDULES I, and II

[0000866374-24-000031:8k_2_02:68]
(1) To supplement Flex’s unaudited selected financial data presented consistent with U.S. Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges and gains, including non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share. These supplemental measures exclude certain legal and other charges, restructuring charges, customer-related asset impairments (recoveries), stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures. We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0000866374-24-000031:8k_2_02:69]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures. Also, when evaluating potential acquisitions, we exclude certain items described below from consideration of the target’s performance and valuation. Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results. We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0000866374-24-000031:8k_2_02:70]
•the ability to make more meaningful period-to-period comparisons of the Company’s ongoing operating results;

[0000866374-24-000031:8k_2_02:71]
•the ability to better identify trends in the Company’s underlying business and perform related trend analysis;

[0000866374-24-000031:8k_2_02:72]
•a better understanding of how management plans and measures the Company’s underlying business; and

[0000866374-24-000031:8k_2_02:73]
•an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0000866374-24-000031:8k_2_02:74]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0000866374-24-000031:8k_2_02:75]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of unvested restricted share unit and stock option awards granted to employees and assumed in business acquisitions. The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0000866374-24-000031:8k_2_02:76]
P R E S S   R E L E A S E

[0000866374-24-000031:8k_2_02:77]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions. The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures. The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0000866374-24-000031:8k_2_02:78]
Restructuring charges include severance charges at existing sites and corporate SG&A functions as well as asset impairment, and other charges related to the closures and consolidations of certain operating sites and targeted activities to restructure the business. These costs may vary in size based on the Company’s initiatives, are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0000866374-24-000031:8k_2_02:79]
During the three-month periods ended June 28, 2024 and June 30, 2023, the Company recognized approximately $25 million, and $23 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-24-000031:8k_2_02:80]
Legal and other consist primarily of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs. During the first quarter of fiscal year 2024, the Company accrued for certain loss contingencies where losses were considered probable and estimable. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures. No such costs were incurred in the first quarter of fiscal year 2025.

[0000866374-24-000031:8k_2_02:81]
Interest and other, net consist of various other types of items that are not directly related to ongoing or core business results, such as the gain or losses related to certain divestitures, currency translation reserve write-offs upon liquidation of certain legal entities, debt extinguishment costs and impairment charges or gains associated with certain non-core investments. The Company excludes these items because they are not related to the Company’s ongoing operating performance or do not affect core operations. Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability. No such costs were incurred in the first quarter of fiscal year 2025.

[0000866374-24-000031:8k_2_02:82]
Adjustments for taxes relate to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable. During the three-month periods ended June 28, 2024 and June 30, 2023, the Company recognized a $1 million and $12 million net tax benefit, respectively, related to the tax effects of various adjustments that are incorporated into non-GAAP measures on restructuring and other.

## item 5.02 — body, verbatim

[0000866374-24-000031:8k_body:1]
Item 5.02. Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0000866374-24-000031:8k_body:2]
On July 19, 2024, Mr. Paul R. Lundstrom, Chief Financial Officer of Flex, notified the Company that he is resigning to pursue another career opportunity, effective July 31, 2024.

[0000866374-24-000031:8k_body:3]
Jaime Martinez, Senior Vice President, Finance, Flex Reliability Solutions, will serve as the Company’s Interim Chief Financial Officer, effective August 1, 2024, as the Company conducts a search for a new chief financial officer. Mr. Martinez, age 47, has served as Senior Vice President, Finance, Reliability Solutions segment since March 2023. He has over 20 years of experience with the Company, and has held roles of increasing responsibility in the Finance function, including as Senior Vice President, Corporate Financial Planning and Analysis (“FP&A”) from July 2022 to February 2023, Vice President, FP&A from July 2020 to June 2022, Vice President, Finance, Lifestyle from January 2020 to June 2020, and Vice President, Finance, Strategic Partners Group from June 2015 to December 2019. The Company has not entered into any transactions with Mr. Martinez that would require disclosure pursuant to Item 404(a) of Regulation S-K, except that Mr. Martinez’s wife, Estela Velasco, is employed by the Company as Senior Director, Accounting and earned approximately $221,173 in total compensation during fiscal year 2024, including salary, bonus, and share awards. There are no arrangements or understandings between Mr. Martinez and any other persons pursuant to which he will become the Company’s Interim Chief Financial Officer, and there is no family relationship between Mr. Martinez and any director, executive officer, or person nominated or chosen by the Company to become a director or executive officer at the Company.
