# FLEX notes — 0000866374-24-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-24-000034:notes:1]
[same as prior period, unchanged from 0000866374-24-000012:notes:1]

[0000866374-24-000034:notes:2]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities include design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 28, 2024, Flex's two operating and reportable segments were as follows:

[0000866374-24-000034:notes:3]
[same as prior period, unchanged from 0000866374-24-000012:notes:3]

[0000866374-24-000034:notes:4]
[same as prior period, unchanged from 0000866374-24-000012:notes:4]

[0000866374-24-000034:notes:5]
[same as prior period, unchanged from 0000866374-24-000012:notes:5]

[0000866374-24-000034:notes:6]
[same as prior period, unchanged from 0000866374-24-000012:notes:6]

[0000866374-24-000034:notes:7]
[same as prior period, unchanged from 0000866374-24-000012:notes:7]

[0000866374-24-000034:notes:8]
[same as prior period, unchanged from 0000866374-24-000012:notes:8]

[0000866374-24-000034:notes:9]
[same as prior period, unchanged from 0000866374-24-000012:notes:9]

[0000866374-24-000034:notes:10]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

[0000866374-24-000034:notes:11]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-24-000034:notes:12]
[same as prior period, unchanged from 0000866374-24-000012:notes:15]

[0000866374-24-000034:notes:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three-month period ended June 28, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

[0000866374-24-000034:notes:14]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively.

[0000866374-24-000034:notes:15]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

[0000866374-24-000034:notes:16]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows

[0000866374-24-000034:notes:17]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

[0000866374-24-000034:notes:18]
[same as prior period, unchanged from 0000866374-24-000012:notes:19]

[0000866374-24-000034:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000034:notes:20]
Supplier Finance Programs

[0000866374-24-000034:notes:21]
[same as prior period, unchanged from 0000866374-24-000012:notes:28]

[0000866374-24-000034:notes:22]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of June 28, 2024 and March 31, 2024 were $129 million and $123 million, respectively.

[0000866374-24-000034:notes:23]
Recently Issued Accounting Pronouncements

[0000866374-24-000034:notes:24]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-24-000034:notes:25]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company is currently assessing the impact of ASU 2023-07 on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-24-000034:notes:26]
[same as prior period, unchanged from 0000866374-24-000012:notes:31]

[0000866374-24-000034:notes:27]
[same as prior period, unchanged from 0000866374-24-000012:notes:32]

[0000866374-24-000034:notes:28]
|  | As of June 28, 2024 |  | As of March 31, 2024 |
|  | (In millions) |
| Raw materials | $ | 4,858 |  |  | $ | 5,045 |  |
| Work-in-progress | 516 |  |  | 623 |  |
| Finished goods | 465 |  |  | 537 |  |
|  | $ | 5,839 |  |  | $ | 6,205 |  |

[0000866374-24-000034:notes:29]
[same as prior period, unchanged from 0000866374-24-000012:notes:34]

[0000866374-24-000034:notes:30]
During the three-month period ended June 28, 2024, the activity in the Company's goodwill account included approximately $4 million of foreign currency translation, offset by an approximately $8 million goodwill addition from an  acquisition in the first quarter of fiscal year 2025. For more information, see note 17 "Business Acquisition".

[0000866374-24-000034:notes:31]
[same as prior period, unchanged from 0000866374-24-000012:notes:36]

[0000866374-24-000034:notes:32]
|  | As of June 28, 2024 |  | As of March 31, 2024 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 317 |  |  | $ | (194) |  |  | $ | 123 |  |  | $ | 316 |  |  | $ | (186) |  |  | $ | 130 |  |
| Licenses and other intangibles | 296 |  |  | (189) |  |  | 107 |  |  | 298 |  |  | (183) |  |  | 115 |  |
| Total | $ | 613 |  |  | $ | (383) |  |  | $ | 230 |  |  | $ | 614 |  |  | $ | (369) |  |  | $ | 245 |  |

[0000866374-24-000034:notes:33]
[same as prior period, unchanged from 0000866374-24-000012:notes:38]

[0000866374-24-000034:notes:34]
[same as prior period, unchanged from 0000866374-24-000012:notes:39]

[0000866374-24-000034:notes:35]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | 47 |  |
| 2026 |  | 43 |  |
| 2027 |  | 36 |  |
| 2028 |  | 27 |  |
| 2029 |  | 25 |  |
| Thereafter |  | 52 |  |
| Total amortization expense |  | $ | 230 |  |

[0000866374-24-000034:notes:36]
[same as prior period, unchanged from 0000866374-24-000012:notes:41]

[0000866374-24-000034:notes:37]
(1)Represents estimated amortization for the remaining fiscal nine-month period ending March 31, 2025.

[0000866374-24-000034:notes:38]
[same as prior period, unchanged from 0000866374-24-000012:notes:43]

[0000866374-24-000034:notes:39]
Customer working capital advances were $1.9 billion and $2.2 billion, as of June 28, 2024 and March 31, 2024, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-24-000034:notes:40]
Other Non-Current Assets

[0000866374-24-000034:notes:41]
Other non-current assets include deferred tax assets of $652 million and $644 million as of June 28, 2024 and March 31, 2024, respectively.

[0000866374-24-000034:notes:42]
[same as prior period, unchanged from 0000866374-24-000012:notes:45]

[0000866374-24-000034:notes:43]
Other current liabilities include customer-related accruals of $242 million and $277 million as of June 28, 2024 and March 31, 2024, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-24-000034:notes:44]
[same as prior period, unchanged from 0000866374-24-000012:notes:47]

[0000866374-24-000034:notes:45]
[same as prior period, unchanged from 0000866374-24-000012:notes:48]

[0000866374-24-000034:notes:46]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $395 million and $490 million as of June 28, 2024 and March 31, 2024, respectively, of which $355 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-24-000034:notes:47]
[same as prior period, unchanged from 0000866374-24-000012:notes:50]

[0000866374-24-000034:notes:48]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three-month periods ended June 28, 2024 and June 30, 2023, respectively.

[0000866374-24-000034:notes:49]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |
| Point in time | $ | 2,873 |  |  | $ | 3,436 |  |
| Over time | 492 |  |  | 165 |  |
| Total | 3,365 |  |  | 3,601 |  |
| FRS |  |  |  |
| Point in time | 2,633 |  |  | 3,132 |  |
| Over time | 316 |  |  | 159 |  |
| Total | 2,949 |  |  | 3,291 |  |
| Flex |  |  |  |
| Point in time | 5,506 |  |  | 6,568 |  |
| Over time | 808 |  |  | 324 |  |
| Total | $ | 6,314 |  |  | $ | 6,892 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-24-000034:notes:50]
STOCK-BASED COMPENSATION
Equity Compensation Plan

[0000866374-24-000034:notes:51]
Flex historically maintains stock-based compensation plans at a corporate level. The Company granted equity compensation awards under its 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-24-000034:notes:52]
Stock-Based Compensation Expense

[0000866374-24-000034:notes:53]
The following table summarizes the Company's stock-based compensation expense for the 2017 Plan:

[0000866374-24-000034:notes:54]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Cost of sales | $ | 8 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 24 |  |  | 25 |  |
| Total stock-based compensation expense | $ | 32 |  |  | $ | 32 |  |

[0000866374-24-000034:notes:55]
[same as prior period, unchanged from 0000866374-24-000012:notes:59]

[0000866374-24-000034:notes:56]
During the three-month period ended June 28, 2024, the Company granted approximately 3.9 million restricted share unit ("RSU") awards. Of this amount, approximately 2.6 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $31.93 per award. In addition, approximately 0.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $31.97 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 0.6 million based on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $42.36 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. Finally, the remaining balance of approximately 0.7 million represents the number of shares issued upon the vesting of RSU awards above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal year 2022. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-24-000034:notes:57]
As of June 28, 2024, approximately 12.5 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 1.4 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 1.4 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 2.8 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 2.8 million based on the achievement levels. During the three-month period ended June 28, 2024, approximately 1.6 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2022.

[0000866374-24-000034:notes:58]
As of June 28, 2024, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan, was approximately $250 million, and will be recognized over a weighted-average remaining vesting period of 2.3 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-24-000034:notes:59]
[same as prior period, unchanged from 0000866374-24-000012:notes:69]

[0000866374-24-000034:notes:60]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |
| Net income from continuing operations | $ | 139 |  |  | $ | 147 |  |
| Net income from discontinued operations, net of tax | — |  |  | 64 |  |
| Less: Net income attributable to noncontrolling interest | — |  |  | 25 |  |
| Net income from discontinued operations attributable to Flex Ltd. | — |  |  | 39 |  |
| Total net income attributable to Flex Ltd. | $ | 139 |  |  | $ | 186 |  |
| Denominator: |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 402 |  |  | 447 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 9 |  |  | 8 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 411 |  |  | 455 |  |
| Earnings per share - basic |  |  |  |
| Continuing operations | $ | 0.35 |  |  | $ | 0.33 |  |
| Discontinued operations, net of tax | — |  |  | 0.09 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.35 |  |  | $ | 0.42 |  |
| Earnings per share - diluted |  |  |  |
| Continuing operations | $ | 0.34 |  |  | $ | 0.32 |  |
| Discontinued operations, net of tax | — |  |  | 0.09 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.34 |  |  | $ | 0.41 |  |

[0000866374-24-000034:notes:61]
(1)An immaterial amount of RSU awards for the three-month periods ended June 28, 2024 and June 30, 2023, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-24-000034:notes:62]
DISCONTINUED OPERATIONS
On January 2, 2024, the Company completed the Spin-off of its remaining interests in Nextracker. For additional details on the Spin-off, refer to Part I, Item 1, “Business” and note 1, "Organization of The Company" and note 7, “Discontinued Operations” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024. Nextracker's financial results for periods prior to the Spin-off have been reflected in our condensed consolidated statement of operations, retrospectively, as discontinued operations.

[0000866374-24-000034:notes:63]
The key components of net income from discontinued operations for the three-month period ended June 30, 2023 were as follows:

[0000866374-24-000034:notes:64]
|  |  | June 30, 2023 |
|  |  | (In millions) |
| Net sales (1) |  | $ | 444 |  |
| Cost of sales (1) |  | 333 |  |
| Gross Profit |  | 111 |  |
| Selling, general and administrative expenses |  | 35 |  |
| Operating income |  | 76 |  |
| Interest, net |  | 1 |  |
| Income before income taxes |  | 75 |  |
| Provision for income taxes |  | 11 |  |
| Net income from discontinued operations |  | 64 |  |
| Net income from discontinued operations attributable to noncontrolling interest (2) |  | 25 |  |
| Net income from discontinued operations attributable to Flex Ltd. |  | $ | 39 |  |

[0000866374-24-000034:notes:65]
(1)    Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's condensed consolidated statements of operations of approximately $36 million for the three-month period ended June 30, 2023.

[0000866374-24-000034:notes:66]
(2)    Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $29 million and of income tax expense of $4 million for the three-month period ended June 30, 2023. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $46 million for the same period.

[0000866374-24-000034:notes:67]
Details of cash flows from discontinued operations for the three-month period ended June 30, 2023 were as follows:

[0000866374-24-000034:notes:68]
|  |  | June 30, 2023 |
|  |  | (In millions) |
| Net cash provided by discontinued operations operating activities (1) |  | $ | 226 |  |
| Net cash used in discontinued operations investing activities |  | (1) |  |

[0000866374-24-000034:notes:69]
(1)    Cash flows from discontinued operations operating activities includes an inflow from intercompany transactions that were eliminated from Flex's consolidated operations of $10 million for the three-month period ended June 30, 2023.


## us-gaap:DebtDisclosureTextBlock

[0000866374-24-000034:notes:70]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2024 and March 31, 2024 are as follows:

[0000866374-24-000034:notes:71]
|  | Maturity Date |  | As of June 28, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 543 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 681 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 680 |  |  | 681 |  |
| 3.600% HUF Bonds | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (12) |  |  | (15) |  |
|  |  |  | 3,215 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (543) |  |  | — |  |
| Non-current portion |  |  | $ | 2,672 |  |  | $ | 3,261 |  |

[0000866374-24-000034:notes:72]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations

[0000866374-24-000034:notes:73]
The weighted-average interest rate for the Company's long-term debt was 4.4% and 4.5% as of June 28, 2024 and March 31, 2024, respectively.

[0000866374-24-000034:notes:74]
Scheduled repayments of the Company's bank borrowings and long-term debt as of June 28, 2024 are as follows:

[0000866374-24-000034:notes:75]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2025 (1) |  | $ | — |  |
| 2026 |  | 1,224 |  |
| 2027 |  | — |  |
| 2028 |  | 397 |  |
| 2029 |  | 27 |  |
| Thereafter |  | 1,579 |  |
| Total |  | $ | 3,227 |  |

[0000866374-24-000034:notes:76]
(1)Represents estimated repayments for the remaining fiscal nine-month period ending March 31, 2025.


## flex:InterestAndOtherNetTextBlock

[0000866374-24-000034:notes:77]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the three-month periods ended June 28, 2024 and June 30, 2023 are primarily composed of the following:

[0000866374-24-000034:notes:78]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 43 |  |  | $ | 44 |  |
| AR sale program related expenses | 13 |  |  | 12 |  |
| Interest income | (16) |  |  | (16) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-24-000034:notes:79]
[same as prior period, unchanged from 0000866374-24-000012:notes:83]

[0000866374-24-000034:notes:80]
The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and options contracts, to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and, accordingly, fair value adjustments related to the credit risk of the counterparty financial institutions were not material.

[0000866374-24-000034:notes:81]
As of June 28, 2024, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.8 billion as summarized below:

[0000866374-24-000034:notes:82]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
|  |  | (in millions) |
| Cash Flow Hedges |  |  |  |  |
| HUF |  | $ | 437 |  |  | $ | — |  |
| MXN |  | 515 |  |  | — |  |
| Other |  | 539 |  |  | 27 |  |
|  |  | 1,491 |  |  | 27 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| CNY |  | 424 |  |  | 89 |  |
| EUR |  | 1,856 |  |  | 1,705 |  |
| JPY |  | 16 |  |  | 467 |  |
| MXN |  | 429 |  |  | 383 |  |
| MYR |  | 275 |  |  | 115 |  |
| Other |  | 703 |  |  | 801 |  |
|  |  | 3,703 |  |  | 3,560 |  |
| Total Notional Contract Value in USD |  | $ | 5,194 |  |  | $ | 3,587 |  |

[0000866374-24-000034:notes:83]
As of June 28, 2024, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of June 28, 2024 and March 31, 2024, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. The deferred loss was $10 million as of June 28, 2024, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except for the USD HUF cross currency swaps.

[0000866374-24-000034:notes:84]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031. The fair value of the cross currency swaps was included in other current liabilities and other non-current liabilities as of June 28, 2024, and in other current assets and other non-current liabilities as of March 31, 2024. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-24-000034:notes:85]
[same as prior period, unchanged from 0000866374-24-000012:notes:90]

[0000866374-24-000034:notes:86]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 28,2024 |  | March 31,2024 |  | Balance SheetLocation |  | June 28,2024 |  | March 31,2024 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 7 |  |  | $ | 45 |  |  | Other current liabilities |  | $ | (29) |  |  | $ | (9) |  |
| Foreign currency contracts | Other non-current assets |  | $ | — |  |  | $ | — |  |  | Other non-current liabilities |  | $ | (31) |  |  | $ | (33) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 22 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | (27) |  |  | $ | (10) |  |

[0000866374-24-000034:notes:87]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the condensed consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company’s financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-24-000034:notes:88]
[same as prior period, unchanged from 0000866374-24-000012:notes:93]

[0000866374-24-000034:notes:89]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |  | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gain (loss) before reclassifications | (30) |  |  | (16) |  |  | (46) |  |  | 101 |  |  | (9) |  |  | 92 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 3 |  |  | — |  |  | 3 |  |  | (67) |  |  | — |  |  | (67) |  |
| Net current-period other comprehensive gain (loss) | (27) |  |  | (16) |  |  | (43) |  |  | 34 |  |  | (9) |  |  | 25 |  |
| Ending balance | $ | (23) |  |  | $ | (215) |  |  | $ | (238) |  |  | $ | 20 |  |  | $ | (189) |  |  | $ | (169) |  |

[0000866374-24-000034:notes:90]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 28, 2024 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended June 28, 2024 and June 30, 2023 were $13 million and $2 million, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-24-000034:notes:91]
TRADE RECEIVABLES SALES PROGRAMSThe Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.9 billion and $0.8 billion as of June 28, 2024 and March 31, 2024, respectively. For the three-month periods ended June 28, 2024 and June 30, 2023, total accounts receivable sold to certain third-party banking institutions was approximately $1.1 billion and $0.8 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-24-000034:notes:92]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-24-000034:notes:93]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of June 28, 2024 and March 31, 2024.

[0000866374-24-000034:notes:94]
[same as prior period, unchanged from 0000866374-24-000012:notes:103]

[0000866374-24-000034:notes:95]
[same as prior period, unchanged from 0000866374-24-000012:notes:104]

[0000866374-24-000034:notes:96]
[same as prior period, unchanged from 0000866374-24-000012:notes:105]

[0000866374-24-000034:notes:97]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-24-000034:notes:98]
[same as prior period, unchanged from 0000866374-24-000012:notes:107]

[0000866374-24-000034:notes:99]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 28, 2024 and June 30, 2023.

[0000866374-24-000034:notes:100]
[same as prior period, unchanged from 0000866374-24-000012:notes:109]

[0000866374-24-000034:notes:101]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of June 28, 2024 and March 31, 2024:

[0000866374-24-000034:notes:102]
|  | Fair Value Measurements as of June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 799 |  |  | $ | — |  |  | $ | 799 |  |
| Foreign currency contracts (Note 9) | — |  |  | 29 |  |  | — |  |  | 29 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (87) |  |  | $ | — |  |  | $ | (87) |  |
|  | Fair Value Measurements as of March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 759 |  |  | $ | — |  |  | $ | 759 |  |
| Foreign currency contracts (Note 9) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 9) | $ | — |  |  | $ | (52) |  |  | $ | — |  |  | $ | (52) |  |

[0000866374-24-000034:notes:103]
[same as prior period, unchanged from 0000866374-24-000012:notes:112]

[0000866374-24-000034:notes:104]
[same as prior period, unchanged from 0000866374-24-000012:notes:113]

[0000866374-24-000034:notes:105]
|  | As of June 28, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 543 |  |  | $ | 538 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 681 |  |  | 661 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 403 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 638 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 680 |  |  | 659 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 269 |  |  | 215 |  |  | 274 |  |  | 219 |  |  | Level 2 |

[0000866374-24-000034:notes:106]
The Notes due June 2025, February 2026, January 2028, June 2029, and May 2030 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-24-000034:notes:107]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-24-000034:notes:108]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a

[0000866374-24-000034:notes:109]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-24-000034:notes:110]
The Company is currently involved in a commercial dispute related to a construction matter with related production objectives. Management assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in Selling, general and administrative expenses in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The ultimate resolution of this dispute is uncertain, and the actual outcome may differ from the estimates made by management. Changes in circumstances or additional information may impact the Company’s assessment of its loss and could result in adjustments to the $50 million accrual, however, management currently believes that the resolution of this dispute will not have a material effect on the Company’s financial position, results of operations or cash flows. The Company will continue to monitor developments related to this matter and will adjust its accrual and disclosures accordingly in future reporting periods as additional information becomes available.

[0000866374-24-000034:notes:111]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. Two remain, where the Company was unsuccessful at the administrative level and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 36 million Brazilian reals (approximately USD $7 million). The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 59 million Brazilian reals (approximately USD $11 million). The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-24-000034:notes:112]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-24-000034:notes:113]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-24-000034:notes:114]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-24-000034:notes:115]
SHARE REPURCHASES 
During the three-month period ended June 28, 2024, the Company repurchased 15.3 million shares at an aggregate purchase price of $457 million, and retired all of these shares.

[0000866374-24-000034:notes:116]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $2.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 2, 2023. As of June 28, 2024, shares in the aggregate amount of $556 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-24-000034:notes:117]
SEGMENT REPORTING
The Company reports its financial performance based on two operating and reportable segments, Flex Agility Solutions and Flex Reliability Solutions, and analyzes operating income as the measure of segment profitability. The determination of these segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-24-000034:notes:118]
[same as prior period, unchanged from 0000866374-24-000012:notes:126]

[0000866374-24-000034:notes:119]
[same as prior period, unchanged from 0000866374-24-000012:notes:127]

[0000866374-24-000034:notes:120]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |
| Flex Agility Solutions | $ | 3,365 |  |  | $ | 3,601 |  |
| Flex Reliability Solutions | 2,949 |  |  | 3,291 |  |
|  | $ | 6,314 |  |  | $ | 6,892 |  |
| Segment income and reconciliation of income from continuing operations before income taxes: |  |  |  |
| Flex Agility Solutions | $ | 179 |  |  | $ | 146 |  |
| Flex Reliability Solutions | 147 |  |  | 165 |  |
| Corporate and Other | (20) |  |  | (18) |  |
| Total segment income | 306 |  |  | 293 |  |
| Reconciling items: |  |  |  |
| Intangible amortization | 16 |  |  | 20 |  |
| Stock-based compensation | 32 |  |  | 32 |  |
| Restructuring charges | 25 |  |  | 23 |  |
| Legal and other (1) | — |  |  | 3 |  |
| Interest expense | 56 |  |  | 56 |  |
| Interest income | 16 |  |  | 16 |  |
| Other charges (income), net | 1 |  |  | 11 |  |
| Income from continuing operations before income taxes | $ | 192 |  |  | $ | 164 |  |

[0000866374-24-000034:notes:121]
(1)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first quarter of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-24-000034:notes:122]
[same as prior period, unchanged from 0000866374-24-000012:notes:130]

[0000866374-24-000034:notes:123]
[same as prior period, unchanged from 0000866374-24-000012:notes:131]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-24-000034:notes:124]
RESTRUCTURING CHARGES
During the first quarter ended June 28, 2024, the Company committed to targeted restructuring activities to improve operational efficiencies. During the three-month period ended June 28, 2024, the Company recognized approximately $25 million of restructuring charges, most of which related to employee severance.

[0000866374-24-000034:notes:125]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of June 28, 2024 for charges incurred during the three-month period ended June 28, 2024:

[0000866374-24-000034:notes:126]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2024 | $ | 77 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 80 |  |
| Provision for charges incurred during the three-month period ended June 28, 2024 | 25 |  |  | — |  |  | — |  |  | 25 |  |
| Cash payments during the three-month period ended June 28, 2024 | (19) |  |  | — |  |  | — |  |  | (19) |  |
| Other adjustments | (1) |  |  | — |  |  | — |  |  | (1) |  |
| Balance as of June 28, 2024 | 82 |  |  | — |  |  | 3 |  |  | 85 |  |
| Less: Current portion (classified as other current liabilities) | 81 |  |  | — |  |  | 3 |  |  | 84 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-24-000034:notes:127]
BUSINESS ACQUISITION
In May 2024, the Company completed the acquisition of a business that was not significant to the consolidated financial position, result of operations and cash flows of the Company. The acquired business will expand our services for customers across multiple markets to create additional revenue streams and accelerate sustainability through second life products.

[0000866374-24-000034:notes:128]
Results of operations were included in the Company’s condensed consolidated financial results beginning on the date of acquisition and was not material to the Company’s condensed consolidated financial results for the three-month period ended June 28, 2024. The Company recorded goodwill of $8 million in relation to the transaction.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-24-000034:notes:129]
On May 21, 2024, Scott Offer, Executive Vice President and General Counsel, adopted a trading plan that provides for the sale of up to 20,000 ordinary shares of the Company. The plan will terminate on September 6, 2024, subject to early termination for certain specified events set forth in the plan.
