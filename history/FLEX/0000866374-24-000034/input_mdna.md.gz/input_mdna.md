# FLEX MD&A — 0000866374-24-000034


## mdna

[0000866374-24-000034:mdna:1]
[same as prior period, unchanged from 0000866374-24-000012:mdna:1]

[0000866374-24-000034:mdna:2]
[same as prior period, unchanged from 0000866374-24-000012:mdna:2]

[0000866374-24-000034:mdna:3]
[same as prior period, unchanged from 0000866374-24-000012:mdna:3]

[0000866374-24-000034:mdna:4]
We are the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support our customers' entire product lifecycle with a broad array of services in every major region. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. We partner with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of June 28, 2024, our two operating and reportable segments were as follows:

[0000866374-24-000034:mdna:5]
[same as prior period, unchanged from 0000866374-24-000012:mdna:5]

[0000866374-24-000034:mdna:6]
[same as prior period, unchanged from 0000866374-24-000012:mdna:6]

[0000866374-24-000034:mdna:7]
[same as prior period, unchanged from 0000866374-24-000012:mdna:7]

[0000866374-24-000034:mdna:8]
[same as prior period, unchanged from 0000866374-24-000012:mdna:8]

[0000866374-24-000034:mdna:9]
[same as prior period, unchanged from 0000866374-24-000012:mdna:9]

[0000866374-24-000034:mdna:10]
[same as prior period, unchanged from 0000866374-24-000012:mdna:10]

[0000866374-24-000034:mdna:11]
[same as prior period, unchanged from 0000866374-24-000012:mdna:11]

[0000866374-24-000034:mdna:12]
◦Industrial, including capital equipment, industrial devices, embedded and critical power offerings, and renewables and grid edge.

[0000866374-24-000034:mdna:13]
[same as prior period, unchanged from 0000866374-24-000012:mdna:14]

[0000866374-24-000034:mdna:14]
[same as prior period, unchanged from 0000866374-24-000012:mdna:15]

[0000866374-24-000034:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and

[0000866374-24-000034:mdna:16]
redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-24-000034:mdna:17]
We believe that our strategy is positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-24-000034:mdna:18]
[same as prior period, unchanged from 0000866374-24-000012:mdna:18]

[0000866374-24-000034:mdna:19]
[same as prior period, unchanged from 0000866374-24-000012:mdna:19]

[0000866374-24-000034:mdna:20]
Component shortages experienced in the recent past have largely subsided, however, logistical constraints exist which have increased freight costs. We continue to monitor potential supply chain disruptions, including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea. Refer to “Risk Factors - Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future affect, our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory.” as disclosed in Part I, "Item 1A. Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-24-000034:mdna:21]
[same as prior period, unchanged from 0000866374-24-000012:mdna:21]

[0000866374-24-000034:mdna:22]
[same as prior period, unchanged from 0000866374-24-000012:mdna:22]

[0000866374-24-000034:mdna:23]
25

[0000866374-24-000034:mdna:24]
[same as prior period, unchanged from 0000866374-24-000012:mdna:31]

[0000866374-24-000034:mdna:25]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.3 billion for the three-month period ended June 28, 2024 and $26.4 billion in the fiscal year ended March 31, 2024. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-24-000034:mdna:26]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |
| Americas | $ | 3,018 |  |  | 48 | % |  | $ | 3,033 |  |  | 44 | % |
| Asia | 1,907 |  |  | 30 | % |  | 2,322 |  |  | 34 | % |
| Europe | 1,389 |  |  | 22 | % |  | 1,537 |  |  | 22 | % |
|  | $ | 6,314 |  |  |  |  | $ | 6,892 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |
| Mexico | $ | 1,587 |  |  | 25 | % |  | $ | 1,755 |  |  | 25 | % |
| China | 1,068 |  |  | 17 | % |  | 1,419 |  |  | 21 | % |
| U.S. | 1,004 |  |  | 16 | % |  | 892 |  |  | 13 | % |
| Malaysia | 591 |  |  | 9 | % |  | 546 |  |  | 8 | % |
| Brazil | 400 |  |  | 6 | % |  | 362 |  |  | 5 | % |
| Hungary | 343 |  |  | 5 | % |  | 351 |  |  | 5 | % |
| Other | 1,321 |  |  | 22 | % |  | 1,567 |  |  | 23 | % |
|  | $ | 6,314 |  |  |  |  | $ | 6,892 |  |  |  |

[0000866374-24-000034:mdna:27]
|  | As of |  | As of |
| Property and equipment, net: | June 28, 2024 |  | March 31, 2024 |
|  | (In millions) |
| Mexico | $ | 790 |  |  | 35 | % |  | $ | 793 |  |  | 35 | % |
| U.S. | 330 |  |  | 15 | % |  | 334 |  |  | 15 | % |
| China | 284 |  |  | 13 | % |  | 307 |  |  | 14 | % |
| Malaysia | 141 |  |  | 6 | % |  | 142 |  |  | 6 | % |
| Hungary | 121 |  |  | 5 | % |  | 124 |  |  | 5 | % |
| Brazil | 87 |  |  | 4 | % |  | 88 |  |  | 4 | % |
| Other | 475 |  |  | 22 | % |  | 481 |  |  | 21 | % |
|  | $ | 2,228 |  |  |  |  | $ | 2,269 |  |  |  |

[0000866374-24-000034:mdna:28]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-24-000034:mdna:29]
[same as prior period, unchanged from 0000866374-24-000012:mdna:36]

[0000866374-24-000034:mdna:30]
•global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including arising from the ongoing conflict between Russia and Ukraine and the Israel-Hamas war);

[0000866374-24-000034:mdna:31]
[same as prior period, unchanged from 0000866374-24-000012:mdna:39]

[0000866374-24-000034:mdna:32]
[same as prior period, unchanged from 0000866374-24-000012:mdna:40]

[0000866374-24-000034:mdna:33]
[same as prior period, unchanged from 0000866374-24-000012:mdna:41]

[0000866374-24-000034:mdna:34]
•the effects on our business due to certain customers' products having short product lifecycles, our customers' ability to cancel or delay orders or change production quantities or locations, the short-term nature of our customers' commitments and rapid changes in demand;

[0000866374-24-000034:mdna:35]
[same as prior period, unchanged from 0000866374-24-000012:mdna:42]

[0000866374-24-000034:mdna:36]
•the impacts on our business due to supply chain issues, including component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea;

[0000866374-24-000034:mdna:37]
[same as prior period, unchanged from 0000866374-24-000012:mdna:48]

[0000866374-24-000034:mdna:38]
[same as prior period, unchanged from 0000866374-24-000012:mdna:49]

[0000866374-24-000034:mdna:39]
•changes in tax legislation;

[0000866374-24-000034:mdna:40]
•changes in trade regulations and treaties; and

[0000866374-24-000034:mdna:41]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by an outbreak and on the business operations of our customers and suppliers.

[0000866374-24-000034:mdna:42]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-24-000034:mdna:43]
[same as prior period, unchanged from 0000866374-24-000012:mdna:53]

[0000866374-24-000034:mdna:44]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000034:mdna:45]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements.

[0000866374-24-000034:mdna:46]
[same as prior period, unchanged from 0000866374-24-000012:mdna:56]

[0000866374-24-000034:mdna:47]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-24-000034:mdna:48]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 92.3 |  |  | 92.8 |  |
| Restructuring charges | 0.2 |  |  | 0.3 |  |
| Gross profit | 7.5 |  |  | 6.9 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.4 |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |
| Operating income | 3.7 |  |  | 3.1 |  |
| Interest expense | 0.9 |  |  | 0.8 |  |
| Interest income | 0.3 |  |  | 0.2 |  |
| Other charges (income), net | 0.1 |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 3.0 |  |  | 2.4 |  |
| Provision for income taxes | 0.8 |  |  | 0.3 |  |
| Net income from continuing operations | 2.2 |  |  | 2.1 |  |
| Net income from discontinued operations, net of tax | — |  |  | 1.0 |  |
| Net income | 2.2 |  |  | 3.1 |  |
| Net income attributable to noncontrolling interest | — |  |  | 0.4 |  |
| Net income attributable to Flex Ltd. | 2.2 | % |  | 2.7 | % |

[0000866374-24-000034:mdna:49]
[same as prior period, unchanged from 0000866374-24-000012:mdna:59]

[0000866374-24-000034:mdna:50]
[same as prior period, unchanged from 0000866374-24-000012:mdna:60]

[0000866374-24-000034:mdna:51]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,365 |  |  | 53 | % |  | $ | 3,601 |  |  | 52 | % |
| Flex Reliability Solutions | 2,949 |  |  | 47 | % |  | 3,291 |  |  | 48 | % |
|  | $ | 6,314 |  |  |  |  | $ | 6,892 |  |  |  |

[0000866374-24-000034:mdna:52]
Net sales during the three-month period ended June 28, 2024 totaled $6.3 billion, representing a decrease of approximately $0.6 billion, or 8% from $6.9 billion during the three-month period ended June 30, 2023. Net sales for our FAS segment decreased approximately $0.2 billion, or 7% from the three-month period ended June 30, 2023, primarily driven by a low double-digit percentage decrease in our Communications, Enterprise and Cloud ("CEC") business driven by difficult year-over-year comparisons and a mid single-digit percentage decrease in our Lifestyle business due to softer demand in certain markets. This was partially offset by a high-teen percentage increase in our Consumer Devices business due to higher customer demand. Net sales for our FRS segment decreased approximately $0.3 billion, or 10% from the three-month period ended June 30, 2023, primarily driven by a high-teen percentage decrease in our Industrial business and a high single-digit percentage decrease in our Health Solutions business due to difficult year-over-year comparisons and lower customer demand across various end markets. The factors described above that decreased FAS and FRS revenues were partially offset by the effect of certain customer arrangements transitioning from point in time to overtime revenue during the quarter which also contributed to an increase in contract assets at June 28, 2024. Net sales decreased $0.4 billion to $1.9 billion in Asia, decreased $0.1 billion to $1.4 billion in Europe, and were flat at $3.0 billion in the Americas.

[0000866374-24-000034:mdna:53]
[same as prior period, unchanged from 0000866374-24-000012:mdna:29]

[0000866374-24-000034:mdna:54]
Our ten largest customers during the three-month periods ended June 28, 2024 and June 30, 2023 accounted for approximately 43% and 36% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 28, 2024 or June 30, 2023.

[0000866374-24-000034:mdna:55]
[same as prior period, unchanged from 0000866374-24-000012:mdna:66]

[0000866374-24-000034:mdna:56]
[same as prior period, unchanged from 0000866374-24-000012:mdna:67]

[0000866374-24-000034:mdna:57]
Cost of sales during the three-month period ended June 28, 2024 totaled $5.8 billion, representing a decrease of approximately $0.6 billion, or 9% from $6.4 billion during the three-month period ended June 30, 2023. The lower cost of sales for the three-month period ended June 28, 2024 was primarily driven by decreased consolidated sales of $0.6 billion or 8%. Cost of sales in FAS for the three-month period ended June 28, 2024 decreased approximately $0.3 billion, or 8% from the three-month period ended June 30, 2023, which is relatively in line with the overall 7% decrease in FAS revenue during the same period primarily as a result of lower revenue in our CEC and Lifestyle businesses. Cost of sales in FRS for the three-month period ended June 28, 2024 decreased approximately $0.3 billion, or 10% from the three-month period ended June 30, 2023, which is in line with the overall decrease in FRS revenue during the same period, primarily as a result of lower revenue in our Industrial business.

[0000866374-24-000034:mdna:58]
[same as prior period, unchanged from 0000866374-24-000012:mdna:70]

[0000866374-24-000034:mdna:59]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-24-000034:mdna:60]
Gross profit during the three-month period ended June 28, 2024 decreased $5 million to $0.5 billion, or 7.5% of net sales, from $0.5 billion, or 6.9% of net sales, during the three-month period ended June 30, 2023, primarily driven by lower sales compared to the prior year period. Gross margin improved 60 basis points during the three-month period ended June 28, 2024 primarily due to favorable mix in our FAS segment combined with savings from restructuring actions.

[0000866374-24-000034:mdna:61]
[same as prior period, unchanged from 0000866374-24-000012:mdna:75]

[0000866374-24-000034:mdna:62]
[same as prior period, unchanged from 0000866374-24-000012:mdna:76]

[0000866374-24-000034:mdna:63]
[same as prior period, unchanged from 0000866374-24-000012:mdna:77]

[0000866374-24-000034:mdna:64]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 179 |  |  | 5.3 | % |  | $ | 146 |  |  | 4.1 | % |
| Flex Reliability Solutions | 147 |  |  | 5.0 | % |  | 165 |  |  | 5.0 | % |

[0000866374-24-000034:mdna:65]
FAS segment margin increased approximately 120 basis points, to 5.3%, for the three-month period ended June 28, 2024, from 4.1% for the three-month period ended June 30, 2023. The margin increase was primarily due to strong execution, product mix and cost savings actions taken.

[0000866374-24-000034:mdna:66]
FRS segment margin remained flat at 5.0% for the three-month periods ended June 28, 2024 and June 30, 2023. This was driven by improving margins in our Health Solutions business due to increased productivity offset by lower sales and operating leverage in our Industrial business.

[0000866374-24-000034:mdna:67]
[same as prior period, unchanged from 0000866374-24-000012:mdna:82]

[0000866374-24-000034:mdna:68]
We committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three-month period ended June 28, 2024, we recognized approximately $25 million of restructuring charges, primarily related to employee severance.

[0000866374-24-000034:mdna:69]
[same as prior period, unchanged from 0000866374-24-000012:mdna:84]

[0000866374-24-000034:mdna:70]
Selling, general and administrative expenses (“SG&A”) was approximately $0.2 billion, or 3.4% of net sales, during the three-month period ended June 28, 2024, decreasing $22 million from approximately $0.2 billion or 3.4% of net sales, during the three-month period ended June 30, 2023. This decrease reflects our enhanced cost control efforts to keep SG&A expenses relatively flat.

[0000866374-24-000034:mdna:71]
[same as prior period, unchanged from 0000866374-24-000012:mdna:87]

[0000866374-24-000034:mdna:72]
Amortization of intangible assets decreased to $16 million during the three-month period ended June 28, 2024, from $20 million for the three-month period ended June 30, 2023, primarily due to certain intangibles now being fully amortized.

[0000866374-24-000034:mdna:73]
Interest expense

[0000866374-24-000034:mdna:74]
Interest expense was $56 million during the three-month periods ended June 28, 2024 and June 30, 2023, as the effects of higher short term borrowings were offset by interest savings from debt repayments.

[0000866374-24-000034:mdna:75]
Interest income

[0000866374-24-000034:mdna:76]
Interest income during the three-month period ended June 28, 2024 was $16 million and was consistent with the prior year period.

[0000866374-24-000034:mdna:77]
Other charges (income), net

[0000866374-24-000034:mdna:78]
Other charges (income), net was an expense of $1 million during the three-month period ended June 28, 2024 compared to an expense of $11 million during the three-month period ended June 30, 2023, primarily due to lower foreign exchange transaction losses compared to the prior year period.

[0000866374-24-000034:mdna:79]
[same as prior period, unchanged from 0000866374-24-000012:mdna:95]

[0000866374-24-000034:mdna:80]
Certain of our subsidiaries, at various times, have been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 15 “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024 for further discussion.

[0000866374-24-000034:mdna:81]
The consolidated effective tax rates were 28% and 10% for the three-month periods ended June 28, 2024 and June 30, 2023, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended June 28, 2024 was higher than the effective tax rate for the three-month period ended June 30, 2023 primarily due to the tax accrual required for our U.S. tax group after the U.S. tax group valuation allowance release in the fiscal year ended March 31, 2024, the recognition of a withholding tax accrual on the undistributed earnings of our Chinese subsidiaries due to the decision in the fiscal year ended March 31, 2024 to not indefinitely reinvest our China earnings in China, the estimated impact of the Organization for Economic Co-operation and Development's (“OECD”) framework on base erosion profit shifting Pillar Two and unfavorable foreign exchange impacts.

[0000866374-24-000034:mdna:82]
The OECD Pillar Two Global Anti-Base Erosion (“GloBE”) model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of June 28, 2024, we recognized a nominal income tax expense for Pillar Two GloBE minimum tax. The Company is continuously monitoring the evolving application of this legislation and assessing its potential impact on our future tax liability.

[0000866374-24-000034:mdna:83]
[same as prior period, unchanged from 0000866374-24-000012:mdna:98]

[0000866374-24-000034:mdna:84]
30

[0000866374-24-000034:mdna:85]
Net income from continuing operations

[0000866374-24-000034:mdna:86]
Net income from continuing operations was $139 million during the three-month period ended June 28, 2024, compared to $147 million during the three-month period ended June 30, 2023, driven by the factors discussed above.

[0000866374-24-000034:mdna:87]
Net income from discontinued operations

[0000866374-24-000034:mdna:88]
Net income from discontinued operations was zero during the three-month period ended June 28, 2024, compared to $64 million during the three-month period ended June 30, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-24-000034:mdna:89]
Net income attributable to noncontrolling interest

[0000866374-24-000034:mdna:90]
Net income attributable to noncontrolling interest was zero during the three-month period ended June 28, 2024, compared to $25 million during the three-month period ended June 30, 2023, as Nextracker was spun off during the fourth quarter of fiscal year 2024.

[0000866374-24-000034:mdna:91]
[same as prior period, unchanged from 0000866374-24-000012:mdna:99]

[0000866374-24-000034:mdna:92]
We continuously evaluate our ability to meet our obligations over the next 12 months and beyond and proactively reset our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of June 28, 2024, we had cash and cash equivalents of approximately $2.2 billion and bank and other borrowings of approximately $3.2 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), under which we had no borrowings outstanding as of June 28, 2024. As of June 28, 2024, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-24-000034:mdna:93]
During the three-month period ended June 28, 2024, we repurchased approximately $41 million of the 4.750% Notes due 2025 under our 10b5-1 bond buyback program, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-24-000034:mdna:94]
Cash provided by operating activities was $0.3 billion during the three-month period ended June 28, 2024, primarily driven by $0.1 billion of net income for the period plus $0.2 billion of non-cash charges such as depreciation, amortization, and stock-based compensation and a reduction in net working capital as discussed below.

[0000866374-24-000034:mdna:95]
We believe net working capital ("NWC") is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased approximately $0.9 billion to $3.6 billion as of June 28, 2024, from $4.5 billion as of March 31, 2024. The decrease was primarily the result of the effect of an increase in the current portion of long-term debt of $0.5 billion and a reduction in inventory of $0.4 billion.

[0000866374-24-000034:mdna:96]
Cash used in investing activities was $0.1 billion during the three-month period ended June 28, 2024. This was primarily driven by $0.1 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our CEC, Automotive, and Industrial businesses.

[0000866374-24-000034:mdna:97]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the three-month periods ended June 28, 2024 and June 30, 2023 was an inflow of $0.2 billion and an outflow of $0.2 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-24-000034:mdna:98]
|  | Three-Month Periods Ended |
|  | June 28, 2024 |  | June 30, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 340 |  |  | $ | 6 |  |
| Purchases of property and equipment | (111) |  |  | (167) |  |
| Proceeds from the disposition of property and equipment | 3 |  |  | 11 |  |
| Adjusted free cash flow | $ | 232 |  |  | $ | (150) |  |

[0000866374-24-000034:mdna:99]
Cash used by financing activities was $0.5 billion during the three-month period ended June 28, 2024, which was primarily driven by $0.5 billion of cash paid for the repurchase of our ordinary shares.

[0000866374-24-000034:mdna:100]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond. As of June 28, 2024 and March 31, 2024, approximately 59% and 55%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.7 billion as of March 31, 2024). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-24-000034:mdna:101]
[same as prior period, unchanged from 0000866374-24-000012:mdna:113]

[0000866374-24-000034:mdna:102]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of June 28, 2024.

[0000866374-24-000034:mdna:103]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-24-000034:mdna:104]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-24-000034:mdna:105]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $2.0 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 2, 2023. During the three-month period ended June 28, 2024, we paid $457 million to repurchase shares under the current repurchase plan at an average price of $29.88 per share. As of June 28, 2024, shares in the aggregate amount of $556 million were available to be repurchased under the current plan.

[0000866374-24-000034:mdna:106]
[same as prior period, unchanged from 0000866374-24-000012:mdna:118]

[0000866374-24-000034:mdna:107]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2024.

[0000866374-24-000034:mdna:108]
There were no material changes in our contractual obligations and commitments as of June 28, 2024.
