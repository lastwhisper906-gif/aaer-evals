# FLEX 8-K — 0001104659-16-115318 filed 2016-04-28

## item codes, every 8-K on or before 2016-05-20

- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2016-05-20

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-16-115318:8k_2_02:1]
EX-99.1
2
a16-9606_1ex99d1.htm
EX-99.1

[0001104659-16-115318:8k_2_02:2]
Exhibit 99.1

[0001104659-16-115318:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-16-115318:8k_2_02:4]
| Renee Brotherton | Kevin Kessel |
| Corporate Communications | Investor Relations |
| (408) 576-7189 | (408) 576-7985 |
| renee.brotherton@flextronics.com | kevin.kessel@flextronics.com |

[0001104659-16-115318:8k_2_02:5]
FLEX REPORTS FOURTH QUARTER AND FISCAL 2016 RESULTS

[0001104659-16-115318:8k_2_02:6]
·                 Fourth quarter adjusted EPS at $0.29, up 7% year-over-year

[0001104659-16-115318:8k_2_02:7]
·                 Quarterly adjusted operating margin increased 50 basis points year-over-year

[0001104659-16-115318:8k_2_02:8]
·                 Fiscal year strong free cash flow generation of $639 million

[0001104659-16-115318:8k_2_02:9]
·                 All-time highest fiscal year adjusted EPS for the Company at $1.14

[0001104659-16-115318:8k_2_02:10]
San Jose, CA, April 28, 2016 — Flex (NASDAQ: FLEX), a leading sketch-to-scale™ solutions company that designs and builds intelligent products for a connected world, today announced results for its fourth quarter and fiscal year ended March 31, 2016:

[0001104659-16-115318:8k_2_02:11]
|  |  | Three Month Periods Ended |  | Twelve Month Periods Ended |  |
|  |  | March 31 |  | March 31 |  | March 31 |  | March 31 |  |
| (US$ in millions, except EPS) |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Net sales |  | $ | 5,773 |  | $ | 5,952 |  | $ | 24,419 |  | $ | 26,148 |  |
| Adjusted operating income |  | $ | 200 |  | $ | 178 |  | $ | 792 |  | $ | 751 |  |
| GAAP operating income |  | $ | 118 |  | $ | 164 |  | $ | 653 |  | $ | 701 |  |
| Adjusted net income |  | $ | 161 |  | $ | 157 |  | $ | 645 |  | $ | 637 |  |
| GAAP net income |  | $ | 61 |  | $ | 135 |  | $ | 444 |  | $ | 601 |  |
| Adjusted EPS |  | $ | 0.29 |  | $ | 0.27 |  | $ | 1.14 |  | $ | 1.08 |  |
| GAAP EPS |  | $ | 0.11 |  | $ | 0.23 |  | $ | 0.79 |  | $ | 1.02 |  |

[0001104659-16-115318:8k_2_02:12]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-16-115318:8k_2_02:13]
Fourth Quarter Results of Operations

[0001104659-16-115318:8k_2_02:14]
Net sales for the fourth quarter ended March 31, 2016 were $5.8 billion, at the mid-point of the revenue guidance range of $5.5 to $6.1 billion. Despite the slight decline in revenue, adjusted operating income increased 13% on a year-over-year basis to $200 million, which was above the mid-point of the guidance range. Quarterly adjusted operating margin expanded 50 basis points year-over-year to 3.5%. Adjusted net income was $161 million in the fourth quarter, increasing 2% year-over-year. Adjusted earnings per diluted share of $0.29 was up 7% from $0.27 in the year ago quarter.

[0001104659-16-115318:8k_2_02:15]
Fiscal Year 2016 Results of Operations

[0001104659-16-115318:8k_2_02:16]
Net sales for the fiscal year ended March 31, 2016 were $24.4 billion, and fiscal year 2016 adjusted operating income increased 5% to $792 million from $751 million in the prior fiscal year. Adjusted earnings per diluted share increased 6 cents to $1.14 year-over-year.

[0001104659-16-115318:8k_2_02:17]
“Fiscal 2016 profit and margin expansion continues to validate Flex’s portfolio evolution and sketch-to-scale strategy. This also marks our third consecutive year of adjusted operating profit and adjusted EPS expansion,” said Mike McNamara, chief executive officer of Flex. “We are committed to continuing this strong trend, and remain focused on driving a continuously richer mix of business across the entire Flex Platform.”

[0001104659-16-115318:8k_2_02:18]
“Cash flow generation continues to be a hallmark for Flex, and a positive reflection of our culture of discipline and focused execution,” said Chris Collier, chief financial officer at Flex. “We generated over $1.1 billion in operating cash flow and $639 million in free cash flow in fiscal 2016. This allowed us to continue fulfilling our commitment to consistently return value to our shareholders; this year we spent $420 million buying back almost 7% of our shares, representing an allocation of 66% of our fiscal 2016 free cash flow.”

[0001104659-16-115318:8k_2_02:19]
Guidance

[0001104659-16-115318:8k_2_02:20]
For the first quarter ending July 01, 2016, revenue is expected to be in the range of $5.5 to $5.9 billion and adjusted EPS is expected to be in the range of $0.25 to $0.29 per diluted share.

[0001104659-16-115318:8k_2_02:21]
GAAP earnings per share is expected to be lower than the adjusted EPS guidance provided herein by approximately $0.08 per diluted share for intangible amortization and stock-based compensation expense.

[0001104659-16-115318:8k_2_02:22]
Conference Calls and Web Casts

[0001104659-16-115318:8k_2_02:23]
A conference call hosted by the Flex management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the fourth quarter and fiscal year ended March 31, 2016. The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flextronics.com. Additional information in the form of a slide presentation may also be found on the Company’s site.  A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-16-115318:8k_2_02:24]
About Flex

[0001104659-16-115318:8k_2_02:25]
Flextronics International Ltd. (Reg. No. 199002645H) is a leading sketch-to-scale™ solutions company that designs and builds intelligent products for a connected world. With approximately 200,000 professionals across 30 countries and a promise to help the world Live smarter™, the company provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit www.flextronics.com or follow us on Twitter @Flextronics.

[0001104659-16-115318:8k_2_02:26]
# # #

[0001104659-16-115318:8k_2_02:27]
regulatory requirements; that the expected revenue and margins from recently launched programs may not be realized; that recently proposed changes in tax laws in certain jurisdictions where we operate may materially impact our tax expense, and the effects that the current macroeconomic environment could have on our business and demand for our products as well as the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations. Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-16-115318:8k_2_02:28]
SCHEDULE I

[0001104659-16-115318:8k_2_02:29]
FLEX

[0001104659-16-115318:8k_2_02:30]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-16-115318:8k_2_02:31]
(In thousands, except per share amounts)

[0001104659-16-115318:8k_2_02:32]
|  |  | Three Month Periods Ended |  |
|  |  | March 31, 2016 |  | March 31, 2015 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 5,772,698 |  | $ | 5,951,600 |  |
| Cost of sales |  | 5,366,361 |  | 5,572,783 |  |
| Gross profit |  | 406,337 |  | 378,817 |  |
| Selling, general and administrative expenses (2) |  | 288,092 |  | 214,613 |  |
| Operating income |  | 118,245 |  | 164,204 |  |
| Intangible amortization |  | 22,848 |  | 8,807 |  |
| Interest and other, net |  | 24,687 |  | 11,232 |  |
| Other charges (income), net |  | 1,481 |  | (11,707 | ) |
| Income before income taxes |  | 69,229 |  | 155,872 |  |
| Provision for income taxes |  | 7,885 |  | 20,760 |  |
| Net income |  | $ | 61,344 |  | $ | 135,112 |  |
| EPS: |  |  |  |  |  |
| Net income: |  |  |  |  |  |
| GAAP |  | $ | 0.11 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.27 |  |
| Diluted shares used in computing per share amounts |  | 552,828 |  | 581,852 |  |
| See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |  |

[0001104659-16-115318:8k_2_02:33]
FLEX

[0001104659-16-115318:8k_2_02:34]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-16-115318:8k_2_02:35]
(In thousands, except per share amounts)

[0001104659-16-115318:8k_2_02:36]
|  |  | Twelve Month Periods Ended |  |
|  |  | March 31, 2016 |  | March 31, 2015 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 24,418,885 |  | $ | 26,147,916 |  |
| Cost of sales |  | 22,810,824 |  | 24,602,576 |  |
| Gross profit |  | 1,608,061 |  | 1,545,340 |  |
| Selling, general and administrative expenses (2) |  | 954,890 |  | 844,473 |  |
| Operating income |  | 653,171 |  | 700,867 |  |
| Intangible amortization |  | 65,965 |  | 32,035 |  |
| Interest and other, net |  | 84,793 |  | 51,410 |  |
| Other charges (income), net (3)(4) |  | 47,738 |  | (53,233 | ) |
| Income before income taxes |  | 454,675 |  | 670,655 |  |
| Provision for income taxes |  | 10,594 |  | 69,854 |  |
| Net income |  | $ | 444,081 |  | $ | 600,801 |  |
| EPS: |  |  |  |  |  |
| Net income: |  |  |  |  |  |
| GAAP |  | $ | 0.79 |  | $ | 1.02 |  |
| Non-GAAP |  | $ | 1.14 |  | $ | 1.08 |  |
| Diluted shares used in computing per share amounts |  | 564,869 |  | 591,556 |  |
| See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule V attached to this press release. |  |

[0001104659-16-115318:8k_2_02:37]
SCHEDULE II

[0001104659-16-115318:8k_2_02:38]
FLEX

[0001104659-16-115318:8k_2_02:39]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-16-115318:8k_2_02:40]
(In thousands, except per share amounts)

[0001104659-16-115318:8k_2_02:41]
|  |  | Three Month Periods Ended |  |
|  |  | March 31, 2016 |  | March 31, 2015 |  |
| GAAP gross profit |  | $ | 406,337 |  | $ | 378,817 |  |
| Stock-based compensation expense |  | 2,546 |  | 1,941 |  |
| Non-GAAP gross profit |  | $ | 408,883 |  | $ | 380,758 |  |
| GAAP SG&A Expenses |  | $ | 288,092 |  | $ | 214,613 |  |
| Stock-based compensation expense |  | 18,475 |  | 11,509 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Non-GAAP SG&A Expenses |  | $ | 208,611 |  | $ | 203,104 |  |
| GAAP operating income |  | $ | 118,245 |  | $ | 164,204 |  |
| Stock-based compensation expense |  | 21,021 |  | 13,450 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Non-GAAP operating income |  | $ | 200,272 |  | $ | 177,654 |  |
| GAAP provision for income taxes |  | $ | 7,885 |  | $ | 20,760 |  |
| Intangible amortization benefit |  | 1,660 |  | 215 |  |
| Tax benefit on intangible assets |  | 3,705 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 13,250 |  | $ | 20,975 |  |
| GAAP net income |  | $ | 61,344 |  | $ | 135,112 |  |
| Stock-based compensation expense |  | 21,021 |  | 13,450 |  |
| Intangible amortization |  | 22,848 |  | 8,807 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Adjustments for taxes |  | (5,365 | ) | (215 | ) |
| Non-GAAP net income |  | $ | 160,854 |  | $ | 157,154 |  |
| EPS: |  |  |  |  |  |
| Net income: |  |  |  |  |  |
| GAAP |  | $ | 0.11 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.29 |  | $ | 0.27 |  |

[0001104659-16-115318:8k_2_02:42]
FLEX

[0001104659-16-115318:8k_2_02:43]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-16-115318:8k_2_02:44]
(In thousands, except per share amounts)

[0001104659-16-115318:8k_2_02:45]
|  |  | Twelve Month Periods Ended |  |
|  |  | March 31, 2016 |  | March 31, 2015 |  |
| GAAP gross profit |  | $ | 1,608,061 |  | $ | 1,545,340 |  |
| Stock-based compensation expense |  | 8,986 |  | 7,503 |  |
| Non-GAAP gross profit |  | $ | 1,617,047 |  | $ | 1,552,843 |  |
| GAAP SG&A Expenses |  | $ | 954,890 |  | $ | 844,473 |  |
| Stock-based compensation expense |  | 68,594 |  | 42,767 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Non-GAAP SG&A Expenses |  | $ | 825,290 |  | $ | 801,706 |  |
| GAAP operating income |  | $ | 653,171 |  | $ | 700,867 |  |
| Stock-based compensation expense |  | 77,580 |  | 50,270 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Non-GAAP operating income |  | $ | 791,757 |  | $ | 751,137 |  |
| GAAP provision for income taxes |  | $ | 10,594 |  | $ | 69,854 |  |
| Intangible amortization benefit |  | 5,404 |  | 1,783 |  |
| Tax benefit on intangible assets (5) |  | 43,029 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 59,027 |  | $ | 71,637 |  |
| GAAP net income |  | $ | 444,081 |  | $ | 600,801 |  |
| Stock-based compensation expense |  | 77,580 |  | 50,270 |  |
| Intangible amortization |  | 65,965 |  | 32,035 |  |
| Bad debt expense (2) |  | 61,006 |  | — |  |
| Other (income) charges, net (3)(4) |  | 44,415 |  | (44,009 | ) |
| Adjustments for taxes (5) |  | (48,433 | ) | (1,783 | ) |
| Non-GAAP net income |  | $ | 644,614 |  | $ | 637,314 |  |
| EPS: |  |  |  |  |  |
| Net income: |  |  |  |  |  |
| GAAP |  | $ | 0.79 |  | $ | 1.02 |  |
| Non-GAAP |  | $ | 1.14 |  | $ | 1.08 |  |

[0001104659-16-115318:8k_2_02:46]
SCHEDULE III

[0001104659-16-115318:8k_2_02:47]
FLEX

[0001104659-16-115318:8k_2_02:48]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-16-115318:8k_2_02:49]
(In thousands)

[0001104659-16-115318:8k_2_02:50]
|  |  | March 31, 2016 |  | March 31, 2015(6) |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,607,570 |  | $ | 1,628,408 |  |
| Accounts receivable, net |  | 2,044,757 |  | 2,337,515 |  |
| Inventories |  | 3,454,356 |  | 3,488,752 |  |
| Other current assets |  | 1,171,143 |  | 1,285,093 |  |
| Total current assets |  | 8,277,826 |  | 8,739,768 |  |
| Property and equipment, net |  | 2,257,633 |  | 2,092,167 |  |
| Goodwill and other intangible assets, net |  | 1,345,820 |  | 415,175 |  |
| Other assets |  | 466,402 |  | 405,781 |  |
| Total assets |  | $ | 12,347,681 |  | $ | 11,652,891 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 65,166 |  | $ | 45,030 |  |
| Accounts payable |  | 4,210,992 |  | 4,561,194 |  |
| Accrued payroll |  | 353,547 |  | 339,739 |  |
| Other current liabilities |  | 1,905,200 |  | 1,809,128 |  |
| Total current liabilities |  | 6,534,905 |  | 6,755,091 |  |
| Long-term debt, net of current portion |  | 2,709,389 |  | 2,025,970 |  |
| Other liabilities |  | 497,857 |  | 475,580 |  |
| Total shareholders’ equity |  | 2,605,530 |  | 2,396,250 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,347,681 |  | $ | 11,652,891 |  |

[0001104659-16-115318:8k_2_02:51]
SCHEDULE IV

[0001104659-16-115318:8k_2_02:52]
FLEX

[0001104659-16-115318:8k_2_02:53]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-16-115318:8k_2_02:54]
(In thousands)

[0001104659-16-115318:8k_2_02:55]
|  |  | Twelve-Month Periods Ended |  |
|  |  | March 31, 2016 |  | March 31, 2015 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 444,081 |  | $ | 600,801 |  |
| Depreciation, amortization and other impairment charges |  | 515,367 |  | 540,490 |  |
| Changes in working capital and other |  | 176,997 |  | (347,257 | ) |
| Net cash provided by operating activities |  | 1,136,445 |  | 794,034 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (510,634 | ) | (347,413 | ) |
| Proceeds from the disposition of property and equipment |  | 13,676 |  | 107,689 |  |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business |  | (910,787 | ) | (66,854 | ) |
| Other investing activities, net |  | 11,369 |  | 64,362 |  |
| Net cash used in investing activities |  | (1,396,376 | ) | (242,216 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 884,702 |  | 319,542 |  |
| Repayments of bank borrowings and long-term debt |  | (190,221 | ) | (344,156 | ) |
| Payments for repurchases of ordinary shares |  | (420,317 | ) | (415,945 | ) |
| Net proceeds from issuance of ordinary shares |  | 61,278 |  | 23,508 |  |
| Other financing activities, net |  | (85,800 | ) | (98,966 | ) |
| Net cash provided by (used in) financing activities |  | 249,642 |  | (516,017 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (10,549 | ) | (1,121 | ) |
| Net change in cash and cash equivalents |  | (20,838 | ) | 34,680 |  |
| Cash and cash equivalents, beginning of period |  | 1,628,408 |  | 1,593,728 |  |
| Cash and cash equivalents, end of period |  | $ | 1,607,570 |  | $ | 1,628,408 |  |

[0001104659-16-115318:8k_2_02:56]
SCHEDULE V

[0001104659-16-115318:8k_2_02:57]
FLEX AND SUBSIDIARIES

[0001104659-16-115318:8k_2_02:58]
NOTES TO SCHEDULES I, II, III, & IV

[0001104659-16-115318:8k_2_02:59]
(1)   To supplement Flex’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, restructuring charges, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-16-115318:8k_2_02:60]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.  We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors.  In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-16-115318:8k_2_02:61]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-16-115318:8k_2_02:62]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-16-115318:8k_2_02:63]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-16-115318:8k_2_02:64]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-16-115318:8k_2_02:65]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-16-115318:8k_2_02:66]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-16-115318:8k_2_02:67]
Bad debt expense is comprised of additional provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties.  These costs are excluded by the Company’s management in assessing its current operating performance and forecasting its earnings trends, and accordingly, are excluded by the Company from its non-GAAP measures.

[0001104659-16-115318:8k_2_02:68]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company

[0001104659-16-115318:8k_2_02:69]
believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-16-115318:8k_2_02:70]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies.

[0001104659-16-115318:8k_2_02:71]
Other (income) charges, net consists of various other types of items that are not directly related to ongoing or core business results, such as impairment charges associated with non-core investments.  We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provide investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-16-115318:8k_2_02:72]
For the twelve-month period ended March 31, 2016, Free Cash Flow was $639 million consisting of GAAP net cash flows from operating activities of $1,136 million less purchases of property and equipment net of proceeds from dispositions of $497 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”

[0001104659-16-115318:8k_2_02:73]
(2)         As was publicly announced on April 21st, SunEdison had filed for chapter 11 bankruptcy protection.  As a result, the Company has recognized a bad debt reserve charge of $61 million associated with its outstanding SunEdison receivables.

[0001104659-16-115318:8k_2_02:74]
(3)         Includes $25 million of non-cash foreign currency translation loss attributable to a non-strategic Western European manufacturing facility we sold and $22 million impairment of a non-core investment in the third quarter of fiscal 2016.

[0001104659-16-115318:8k_2_02:75]
(4)         In accordance with a manufacturing agreement, the Company recognized a $55 million charge for a contractual obligation during the quarter ended March 31, 2014. During the first quarter of fiscal 2015, an amendment was executed which included the removal of the $55 million obligation. Accordingly, the Company reversed this charge with a corresponding credit to other income, included in other (income) charges, net with no impact to cash. In addition, during the first quarter of fiscal 2015, the Company recognized a loss of $11 million in connection with the disposition of a certain European manufacturing facility, which is included in other (income) charges, net.

[0001104659-16-115318:8k_2_02:76]
(5)         Includes a $39 million benefit for the release of valuation allowances on certain of our deferred tax assets resulting from our acquisition of the NEXTracker business during the third quarter of fiscal 2016.

[0001104659-16-115318:8k_2_02:77]
(6)         In April 2015, the FASB issued new guidance which changes the presentation of debt issuance costs in financial statements. As a result of the adoption, $12.7 million of debt issuance costs associated with the Company’s bank borrowings and long-term debt as of March 31, 2015, were reclassified from other current and noncurrent assets, to short-term and long-term debt in the consolidated balance sheet.
