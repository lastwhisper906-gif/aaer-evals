# FLEX notes — 0001628280-16-016576


## flex:BasisOfPresentationAndPrinciplesOfConsolidationPolicyTextBlock

[0001628280-16-016576:notes:1]
Basis of Presentation and Principles of Consolidation

[0001628280-16-016576:notes:2]
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and year ends on March 31 of each year. The first fiscal quarter ended on June 26, 2015 and June 27, 2014, respectively, and the second fiscal quarter ended on September 25, 2015 and September 26, 2014, respectively. Amounts included in the consolidated financial statements are expressed in U.S. dollars unless otherwise designated.

[0001628280-16-016576:notes:3]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of March 31, 2016, the noncontrolling interest has been included on the consolidated balance sheets as a component of total shareholders' equity. The associated noncontrolling owners' interest in the income or losses of these companies is classified as a component of interest and other, net, in the consolidated statements of operations.

[0001628280-16-016576:notes:4]
The Company has certain non-majority-owned equity investments in non-publicly traded companies that are accounted for using the equity method of accounting. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer, or if the Company has an ownership percentage of a corporation equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The equity in earnings (losses) of equity method investees are immaterial for all of the periods presented, and are included in interest and other, net in the condensed consolidated statements of operations.


## flex:InterestAndOtherNetTextBlock

[0001628280-16-016576:notes:5]
INTEREST AND OTHER, NET

[0001628280-16-016576:notes:6]
For the fiscal years ended March 31, 2016, 2015 and 2014, the Company recognized interest income of $12.3 million, $18.7 million and $17.6 million.

[0001628280-16-016576:notes:7]
For the fiscal years ended March 31, 2016, 2015 and 2014, the Company recognized interest expense of $98.0 million, $76.4 million and $79.9 million, respectively, on its debt obligations outstanding during the period.

[0001628280-16-016576:notes:8]
For the fiscal years ended March 31, 2016, 2015 and 2014, the Company recognized gains on foreign exchange transactions of $24.4 million, $19.7 million and $11.8 million, respectively.

[0001628280-16-016576:notes:9]
For the fiscal years ended March 31, 2016, 2015 and 2014, the Company recognized $11.0 million, $9.9 million and $9.5 million of expense related to its ABS and AR Sales Programs.

[0001628280-16-016576:notes:10]
For the fiscal years ended March 31, 2016, the Company incurred $8.0 million of acquisition-related costs.


## flex:ScheduleOfShareBonusAwardsWithMarketConditionsTableTextBlock

[0001628280-16-016576:notes:11]
Of the 17.0 million unvested share bonus awards outstanding under the 2010 Plan as of the fiscal year ended 2016, approximately 3.2 million of unvested share bonus awards under the 2010 Plan represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0001628280-16-016576:notes:12]
|  |  | Targetednumber ofawards as ofMarch 31, 2016(in shares) |  |  |  |  |  | Range of sharesthat may be issued |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  | Market condition |  | Minimum |  | Maximum |  |
| Fiscal 2016 |  | 726,995 |  |  | $ | 14.96 |  |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the Standard and Poor's ("S&P") 500 Composite Index and an Extended Electronics Manufacturing Services ("EMS") Group Index. |  | — |  |  | 1,453,990 |  |  | May 2018 |
| Fiscal 2015 |  | 706,747 |  |  | $ | 14.77 |  |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the S&P 500 Composite Index and an EMS Group Index. |  | — |  |  | 1,413,494 |  |  | May 2017 |
| Fiscal 2014 |  | 1,810,000 |  |  | $ | 9.36 |  |  | Vesting ranges from zero to 200% based on measurement of Flextronics' total shareholder return against both the S&P 500 Composite Index and an EMS Group Index. |  | — |  |  | 3,620,000 |  |  | May 2016 |
| Totals |  | 3,243,742 |  |  |  |  |  |  |  |  |  |  | 6,487,484 |  |  |  |


## flex:ScheduleOfTaxLossesAndOtherCarryforwardsTableTextBlock

[0001628280-16-016576:notes:13]
These tax losses and other carryforwards will expire at various dates as follows:

[0001628280-16-016576:notes:14]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
|  | (In thousands) |
| 2017 - 2022 | $ | 558,108 |  |
| 2023 - 2028 | 742,981 |  |
| 2029 and post | 622,339 |  |
| Indefinite | 436,092 |  |
|  | $ | 2,359,520 |  |


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001628280-16-016576:notes:15]
The following table summarizes the activity in the deferred purchase price receivables account during the fiscal years ended March 31, 2016 and 2015:

[0001628280-16-016576:notes:16]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Beginning balance | $ | 600,672 |  |  | $ | 470,908 |  |
| Transfers of receivables | 3,475,400 |  |  | 3,599,768 |  |
| Collections | (3,574,975 | ) |  | (3,470,004 | ) |
| Ending balance | $ | 501,097 |  |  | $ | 600,672 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001628280-16-016576:notes:17]
SUPPLEMENTAL GUARANTOR AND NON-GUARANTOR CONSOLIDATED FINANCIAL STATEMENTS

[0001628280-16-016576:notes:18]
Flextronics International Ltd. ("Parent") has three tranches of Notes of $500 million, $500 million and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company's 100% owned subsidiaries (the "guarantor subsidiaries"). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company's Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the notes are rated investment grade.

[0001628280-16-016576:notes:19]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company's non-guarantor subsidiaries.

[0001628280-16-016576:notes:20]
During the year ended March 31, 2016, and in conjunction with the new $600 million Notes, a new entity was added as a guarantor subsidiary for all three tranches of the Notes. Accordingly, the Company recast the condensed consolidating financial statements presented below to reflect this change.

[0001628280-16-016576:notes:21]
Condensed Consolidating Balance Sheets as of March 31, 2016

[0001628280-16-016576:notes:22]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |
| Accounts receivable | — |  |  | 729,331 |  |  | 1,315,426 |  |  | — |  |  | 2,044,757 |  |
| Inventories | — |  |  | 1,482,410 |  |  | 2,009,246 |  |  | — |  |  | 3,491,656 |  |
| Inter company receivable | 9,105,728 |  |  | 5,568,392 |  |  | 12,404,722 |  |  | (27,078,842 | ) |  | — |  |
| Other current assets | 2,951 |  |  | 180,842 |  |  | 987,350 |  |  | — |  |  | 1,171,143 |  |
| Total current assets | 9,843,548 |  |  | 8,109,176 |  |  | 17,441,244 |  |  | (27,078,842 | ) |  | 8,315,126 |  |
| Property and equipment, net | — |  |  | 553,072 |  |  | 1,704,561 |  |  | — |  |  | 2,257,633 |  |
| Goodwill and other intangible assets, net | 175 |  |  | 60,895 |  |  | 1,284,750 |  |  | — |  |  | 1,345,820 |  |
| Other assets | 2,249,145 |  |  | 267,034 |  |  | 2,004,437 |  |  | (4,054,214 | ) |  | 466,402 |  |
| Investment in subsidiaries | 2,815,426 |  |  | 3,014,634 |  |  | 18,175,348 |  |  | (24,005,408 | ) |  | — |  |
| Total assets | $ | 14,908,294 |  |  | $ | 12,004,811 |  |  | $ | 40,610,340 |  |  | $ | (55,138,464 | ) |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 5,384 |  |  | $ | — |  |  | $ | 65,166 |  |
| Accounts payable | — |  |  | 1,401,835 |  |  | 2,846,457 |  |  | — |  |  | 4,248,292 |  |
| Accrued payroll | — |  |  | 114,509 |  |  | 239,038 |  |  | — |  |  | 353,547 |  |
| Inter company payable | 9,562,405 |  |  | 7,999,335 |  |  | 9,517,102 |  |  | (27,078,842 | ) |  | — |  |
| Other current liabilities | 33,008 |  |  | 869,470 |  |  | 1,002,722 |  |  | — |  |  | 1,905,200 |  |
| Total current liabilities | 9,654,249 |  |  | 10,386,095 |  |  | 13,610,703 |  |  | (27,078,842 | ) |  | 6,572,205 |  |
| Long term liabilities | 2,683,173 |  |  | 2,063,988 |  |  | 2,514,299 |  |  | (4,054,214 | ) |  | 3,207,246 |  |
| Flextronics International Ltd. shareholders' equity | 2,570,872 |  |  | (445,272 | ) |  | 24,450,680 |  |  | (24,005,408 | ) |  | 2,570,872 |  |
| Noncontrolling interests | — |  |  | — |  |  | 34,658 |  |  | — |  |  | 34,658 |  |
| Total shareholders' equity | 2,570,872 |  |  | (445,272 | ) |  | 24,485,338 |  |  | (24,005,408 | ) |  | 2,605,530 |  |
| Total liabilities and shareholders' equity | $ | 14,908,294 |  |  | $ | 12,004,811 |  |  | $ | 40,610,340 |  |  | $ | (55,138,464 | ) |  | $ | 12,384,981 |  |

[0001628280-16-016576:notes:23]
Condensed Consolidating Balance Sheets as of March 31, 2015

[0001628280-16-016576:notes:24]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |
| Accounts receivable | — |  |  | 1,208,632 |  |  | 1,128,883 |  |  | — |  |  | 2,337,515 |  |
| Inventories | — |  |  | 1,729,593 |  |  | 1,759,159 |  |  | — |  |  | 3,488,752 |  |
| Inter company receivable | 6,417,410 |  |  | 4,759,062 |  |  | 10,099,057 |  |  | (21,275,529 | ) |  | — |  |
| Other current assets | 8,143 |  |  | 202,161 |  |  | 1,075,921 |  |  | — |  |  | 1,286,225 |  |
| Total current assets | 7,034,524 |  |  | 8,067,720 |  |  | 14,914,185 |  |  | (21,275,529 | ) |  | 8,740,900 |  |
| Property and equipment, net | — |  |  | 471,052 |  |  | 1,621,115 |  |  | — |  |  | 2,092,167 |  |
| Goodwill and other intangible assets, net | 475 |  |  | 64,830 |  |  | 349,870 |  |  | — |  |  | 415,175 |  |
| Other assets | 2,210,669 |  |  | 155,172 |  |  | 2,131,523 |  |  | (4,092,715 | ) |  | 404,649 |  |
| Investment in subsidiaries | 1,799,956 |  |  | 1,654,226 |  |  | 16,640,427 |  |  | (20,094,609 | ) |  | — |  |
| Total assets | $ | 11,045,624 |  |  | $ | 10,413,000 |  |  | $ | 35,657,120 |  |  | $ | (45,462,853 | ) |  | $ | 11,652,891 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 38,868 |  |  | $ | 917 |  |  | $ | 5,245 |  |  | $ | — |  |  | $ | 45,030 |  |
| Accounts payable | — |  |  | 1,758,305 |  |  | 2,802,889 |  |  | — |  |  | 4,561,194 |  |
| Accrued payroll | — |  |  | 112,692 |  |  | 227,047 |  |  | — |  |  | 339,739 |  |
| Inter company payable | 6,559,569 |  |  | 7,250,235 |  |  | 7,465,725 |  |  | (21,275,529 | ) |  | — |  |
| Other current liabilities | 30,553 |  |  | 845,156 |  |  | 933,419 |  |  | — |  |  | 1,809,128 |  |
| Total current liabilities | 6,628,990 |  |  | 9,967,305 |  |  | 11,434,325 |  |  | (21,275,529 | ) |  | 6,755,091 |  |
| Long term liabilities | 2,055,820 |  |  | 2,102,483 |  |  | 2,435,962 |  |  | (4,092,715 | ) |  | 2,501,550 |  |
| Flextronics International Ltd. shareholders' equity | 2,360,814 |  |  | (1,656,788 | ) |  | 21,751,397 |  |  | (20,094,609 | ) |  | 2,360,814 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,436 |  |  | — |  |  | 35,436 |  |
| Total shareholders' equity | 2,360,814 |  |  | (1,656,788 | ) |  | 21,786,833 |  |  | (20,094,609 | ) |  | 2,396,250 |  |
| Total liabilities and shareholders' equity | $ | 11,045,624 |  |  | $ | 10,413,000 |  |  | $ | 35,657,120 |  |  | $ | (45,462,853 | ) |  | $ | 11,652,891 |  |

[0001628280-16-016576:notes:25]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2016

[0001628280-16-016576:notes:26]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 16,841,405 |  |  | $ | 19,286,221 |  |  | $ | (11,708,741 | ) |  | $ | 24,418,885 |  |
| Cost of sales | — |  |  | 15,278,265 |  |  | 19,241,300 |  |  | (11,708,741 | ) |  | 22,810,824 |  |
| Gross profit | — |  |  | 1,563,140 |  |  | 44,921 |  |  | — |  |  | 1,608,061 |  |
| Selling, general and administrative expenses | — |  |  | 330,194 |  |  | 624,696 |  |  | — |  |  | 954,890 |  |
| Intangible amortization | 300 |  |  | 3,598 |  |  | 62,067 |  |  | — |  |  | 65,965 |  |
| Interest and other, net | (191,859 | ) |  | 1,016,302 |  |  | (691,912 | ) |  | — |  |  | 132,531 |  |
| Income (loss) before income taxes | 191,559 |  |  | 213,046 |  |  | 50,070 |  |  | — |  |  | 454,675 |  |
| Provision for income taxes | 26 |  |  | (41,584 | ) |  | 52,152 |  |  | — |  |  | 10,594 |  |
| Equity in earnings in subsidiaries | 252,548 |  |  | (168,886 | ) |  | 397,831 |  |  | (481,493 | ) |  | — |  |
| Net income | $ | 444,081 |  |  | $ | 85,744 |  |  | $ | 395,749 |  |  | $ | (481,493 | ) |  | $ | 444,081 |  |

[0001628280-16-016576:notes:27]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2015

[0001628280-16-016576:notes:28]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 19,016,750 |  |  | $ | 19,543,163 |  |  | $ | (12,411,997 | ) |  | $ | 26,147,916 |  |
| Cost of sales | — |  |  | 17,502,863 |  |  | 19,511,710 |  |  | (12,411,997 | ) |  | 24,602,576 |  |
| Gross profit | — |  |  | 1,513,887 |  |  | 31,453 |  |  | — |  |  | 1,545,340 |  |
| Selling, general and administrative expenses | — |  |  | 258,212 |  |  | 586,261 |  |  | — |  |  | 844,473 |  |
| Intangible amortization | 300 |  |  | 3,808 |  |  | 27,927 |  |  | — |  |  | 32,035 |  |
| Interest and other, net | 10,086 |  |  | 901,059 |  |  | (912,968 | ) |  | — |  |  | (1,823 | ) |
| Income (loss) before income taxes | (10,386 | ) |  | 350,808 |  |  | 330,233 |  |  | — |  |  | 670,655 |  |
| Provision for income taxes | — |  |  | 14,143 |  |  | 55,711 |  |  | — |  |  | 69,854 |  |
| Equity in earnings in subsidiaries | 611,187 |  |  | (141,074 | ) |  | 471,575 |  |  | (941,688 | ) |  | — |  |
| Net income | $ | 600,801 |  |  | $ | 195,591 |  |  | $ | 746,097 |  |  | $ | (941,688 | ) |  | $ | 600,801 |  |

[0001628280-16-016576:notes:29]
Condensed Consolidating Statements of Operations for Fiscal Year Ended March 31, 2014

[0001628280-16-016576:notes:30]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 18,393,436 |  |  | $ | 21,569,406 |  |  | $ | (13,854,235 | ) |  | $ | 26,108,607 |  |
| Cost of sales | — |  |  | 16,961,211 |  |  | 21,502,762 |  |  | (13,854,235 | ) |  | 24,609,738 |  |
| Restructuring charges | — |  |  | 9,609 |  |  | 49,039 |  |  | — |  |  | 58,648 |  |
| Gross profit | — |  |  | 1,422,616 |  |  | 17,605 |  |  | — |  |  | 1,440,221 |  |
| Selling, general and administrative expenses | — |  |  | 250,909 |  |  | 623,887 |  |  | — |  |  | 874,796 |  |
| Intangible amortization | 300 |  |  | 4,659 |  |  | 23,933 |  |  | — |  |  | 28,892 |  |
| Restructuring charges | 800 |  |  | (271 | ) |  | 16,134 |  |  | — |  |  | 16,663 |  |
| Interest and other, net | (502,028 | ) |  | 875,119 |  |  | (253,675 | ) |  | — |  |  | 119,416 |  |
| Income (loss) before income taxes | 500,928 |  |  | 292,200 |  |  | (392,674 | ) |  | — |  |  | 400,454 |  |
| Provision for income taxes | 52 |  |  | 42,950 |  |  | (8,142 | ) |  | — |  |  | 34,860 |  |
| Equity in earnings in subsidiaries | (135,282 | ) |  | (262,871 | ) |  | 368,268 |  |  | 29,885 |  |  | — |  |
| Net income (loss) | $ | 365,594 |  |  | $ | (13,621 | ) |  | $ | (16,264 | ) |  | $ | 29,885 |  |  | $ | 365,594 |  |

[0001628280-16-016576:notes:31]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2016

[0001628280-16-016576:notes:32]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 444,081 |  |  | $ | 85,744 |  |  | $ | 395,749 |  |  | $ | (481,493 | ) |  | $ | 444,081 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 17,846 |  |  | (16,979 | ) |  | (15,735 | ) |  | 32,714 |  |  | 17,846 |  |
| Unrealized loss on derivative instruments and other, net of zero tax | 26,744 |  |  | 15,195 |  |  | 26,744 |  |  | (41,939 | ) |  | 26,744 |  |
| Comprehensive income | $ | 488,671 |  |  | $ | 83,960 |  |  | $ | 406,758 |  |  | $ | (490,718 | ) |  | $ | 488,671 |  |

[0001628280-16-016576:notes:33]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2015

[0001628280-16-016576:notes:34]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 600,801 |  |  | $ | 195,591 |  |  | $ | 746,097 |  |  | $ | (941,688 | ) |  | $ | 600,801 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (18,932 | ) |  | 256,652 |  |  | 221,418 |  |  | (478,070 | ) |  | (18,932 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (35,417 | ) |  | (33,769 | ) |  | (35,417 | ) |  | 69,186 |  |  | (35,417 | ) |
| Comprehensive income | $ | 546,452 |  |  | $ | 418,474 |  |  | $ | 932,098 |  |  | $ | (1,350,572 | ) |  | $ | 546,452 |  |

[0001628280-16-016576:notes:35]
Condensed Consolidating Statements of Comprehensive Income for Fiscal Year Ended March 31, 2014

[0001628280-16-016576:notes:36]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 365,594 |  |  | $ | (13,621 | ) |  | $ | (16,264 | ) |  | $ | 29,885 |  |  | $ | 365,594 |  |
| Other comprehensive loss: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (34,683 | ) |  | (89,282 | ) |  | (89,635 | ) |  | 178,917 |  |  | (34,683 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (13,992 | ) |  | (5,221 | ) |  | (13,993 | ) |  | 19,214 |  |  | (13,992 | ) |
| Comprehensive income (loss) | $ | 316,919 |  |  | $ | (108,124 | ) |  | $ | (119,892 | ) |  | $ | 228,016 |  |  | $ | 316,919 |  |

[0001628280-16-016576:notes:37]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2016

[0001628280-16-016576:notes:38]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 162,275 |  |  | $ | 427,259 |  |  | $ | 546,911 |  |  | $ | — |  |  | $ | 1,136,445 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (151,383 | ) |  | (345,584 | ) |  | 9 |  |  | (496,958 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (809,272 | ) |  | (101,515 | ) |  | — |  |  | (910,787 | ) |
| Investing cash flows to affiliates | (1,596,210 | ) |  | (1,609,342 | ) |  | (1,408,610 | ) |  | 4,614,162 |  |  | — |  |
| Other investing activities, net | (500 | ) |  | (31,011 | ) |  | 42,880 |  |  | — |  |  | 11,369 |  |
| Net cash used in investing activities | (1,596,710 | ) |  | (2,601,008 | ) |  | (1,812,829 | ) |  | 4,614,171 |  |  | (1,396,376 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 824,618 |  |  | — |  |  | 60,084 |  |  | — |  |  | 884,702 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (179,920 | ) |  | (3,059 | ) |  | (7,242 | ) |  |  |  |  | (190,221 | ) |
| Payments for repurchases of ordinary shares | (420,317 | ) |  | — |  |  | — |  |  | — |  |  | (420,317 | ) |
| Proceeds from exercise of stock options | 61,278 |  |  | — |  |  | — |  |  | — |  |  | 61,278 |  |
| Financing cash flows from affiliates | 1,240,145 |  |  | 2,162,840 |  |  | 1,211,186 |  |  | (4,614,171 | ) |  | — |  |
| Other financing activities, net | — |  |  | (8,800 | ) |  | (77,000 | ) |  | — |  |  | (85,800 | ) |
| Net cash provided by financing activities | 1,525,804 |  |  | 2,150,981 |  |  | 1,187,028 |  |  | (4,614,171 | ) |  | 249,642 |  |
| Effect of exchange rates on cash and cash equivalents | 34,529 |  |  | 2,697 |  |  | (47,775 | ) |  | — |  |  | (10,549 | ) |
| Net increase (decrease) in cash and cash equivalents | 125,898 |  |  | (20,071 | ) |  | (126,665 | ) |  | — |  |  | (20,838 | ) |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |

[0001628280-16-016576:notes:39]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2015

[0001628280-16-016576:notes:40]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | (73,356 | ) |  | $ | 75,775 |  |  | $ | 791,615 |  |  | $ | — |  |  | 794,034 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (85,876 | ) |  | (153,833 | ) |  | (15 | ) |  | (239,724 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (20,589 | ) |  | (46,265 | ) |  | — |  |  | (66,854 | ) |
| Investing cash flows from (to) affiliates | (1,703,983 | ) |  | (1,900,810 | ) |  | 796,493 |  |  | 2,808,300 |  |  | — |  |
| Other investing activities, net | (1,500 | ) |  | (13,821 | ) |  | 79,683 |  |  | — |  |  | 64,362 |  |
| Net cash provided by (used in) investing activities | (1,705,483 | ) |  | (2,021,096 | ) |  | 676,078 |  |  | 2,808,285 |  |  | (242,216 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 303,000 |  |  | 4,737 |  |  | 11,805 |  |  | — |  |  | 319,542 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (335,500 | ) |  | (3,127 | ) |  | (5,529 | ) |  | — |  |  | (344,156 | ) |
| Payments for early repurchase of long-term debt | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Payments for repurchases of ordinary shares | (415,945 | ) |  | — |  |  | — |  |  | — |  |  | (415,945 | ) |
| Proceeds from exercise of stock options | 23,497 |  |  | — |  |  | 11 |  |  | — |  |  | 23,508 |  |
| Financing cash flows from (to) affiliates | 2,420,952 |  |  | 1,904,164 |  |  | (1,516,831 | ) |  | (2,808,285 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (98,966 | ) |  | — |  |  | (98,966 | ) |
| Net cash provided by (used in) financing activities | 1,996,004 |  |  | 1,905,774 |  |  | (1,609,510 | ) |  | (2,808,285 | ) |  | (516,017 | ) |
| Effect of exchange rates on cash and cash equivalents | (246,908 | ) |  | (2,643 | ) |  | 248,430 |  |  | — |  |  | (1,121 | ) |
| Net increase (decrease) in cash and cash equivalents | (29,743 | ) |  | (42,190 | ) |  | 106,613 |  |  | — |  |  | 34,680 |  |
| Cash and cash equivalents, beginning of period | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |

[0001628280-16-016576:notes:41]
Condensed Consolidating Statements of Cash Flows for Fiscal Year Ended March 31, 2014

[0001628280-16-016576:notes:42]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 459,748 |  |  | $ | (126,813 | ) |  | $ | 882,974 |  |  | $ | 551 |  |  | 1,216,460 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (222,197 | ) |  | (292,221 | ) |  | (585 | ) |  | (515,003 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (61,587 | ) |  | (171,845 | ) |  | — |  |  | (233,432 | ) |
| Investing cash flows from (to) affiliates | 35,262 |  |  | (1,237,006 | ) |  | (1,075,938 | ) |  | 2,277,682 |  |  | — |  |
| Other investing activities, net | — |  |  | (10,842 | ) |  | (24,655 | ) |  | — |  |  | (35,497 | ) |
| Net cash provided by (used in) investing activities | 35,262 |  |  | (1,531,632 | ) |  | (1,564,659 | ) |  | 2,277,097 |  |  | (783,932 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 1,066,359 |  |  | 277 |  |  | 17 |  |  | — |  |  | 1,066,653 |  |
| Repayments of bank borrowings and long-term debt and capital lease obligations | (492,034 | ) |  | (525 | ) |  | (45,021 | ) |  | — |  |  | (537,580 | ) |
| Payments for early repurchase of long-term debt | (503,423 | ) |  | (41,417 | ) |  | — |  |  | — |  |  | (544,840 | ) |
| Payments for repurchases of ordinary shares | (475,314 | ) |  | — |  |  | — |  |  | — |  |  | (475,314 | ) |
| Proceeds from exercise of stock options | 28,140 |  |  | — |  |  | — |  |  | — |  |  | 28,140 |  |
| Financing cash flows from (to) affiliates | (277,594 | ) |  | 1,681,559 |  |  | 873,683 |  |  | (2,277,648 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | 52,149 |  |  | — |  |  | 52,149 |  |
| Net cash provided by (used in) financing activities | (653,866 | ) |  | 1,639,894 |  |  | 880,828 |  |  | (2,277,648 | ) |  | (410,792 | ) |
| Effect of exchange rates on cash and cash equivalents | 57,055 |  |  | 2,641 |  |  | (74,791 | ) |  | — |  |  | (15,095 | ) |
| Net increase (decrease) in cash and cash equivalents | (101,801 | ) |  | (15,910 | ) |  | 124,352 |  |  | — |  |  | 6,641 |  |
| Cash and cash equivalents, beginning of period | 740,515 |  |  | 226,372 |  |  | 620,200 |  |  | — |  |  | 1,587,087 |  |
| Cash and cash equivalents, end of period | $ | 638,714 |  |  | $ | 210,462 |  |  | $ | 744,552 |  |  | $ | — |  |  | $ | 1,593,728 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-16-016576:notes:43]
SUMMARY OF ACCOUNTING POLICIES

[0001628280-16-016576:notes:44]
Use of Estimates

[0001628280-16-016576:notes:45]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, intangible assets and goodwill; asset impairments; fair values of financial instruments including investments, notes receivable and derivative instruments; restructuring charges; contingencies; fair values of assets obtained and liabilities assumed in business combinations and the fair values of stock options and share bonus awards granted under the Company's stock-based compensation plans. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0001628280-16-016576:notes:46]
Translation of Foreign Currencies

[0001628280-16-016576:notes:47]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for any of the periods presented, and have been classified as a component of interest and other, net in the consolidated statements of operations.

[0001628280-16-016576:notes:48]
Revenue Recognition

[0001628280-16-016576:notes:49]
The Company recognizes manufacturing revenue when it ships goods or the goods are received by its customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then the Company recognizes the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of the Company's customer contracts allow the recovery of certain costs related to manufacturing services that are over and above the prices charged for the related products. The Company determines the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. The Company accrues for these commitments and obligations based on facts and circumstances and contractual terms. The Company also makes provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to the consolidated financial statements for any of the periods presented.

[0001628280-16-016576:notes:50]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The Company recognizes service revenue when the services have been performed, and the related costs are expensed as incurred. Sales for services were less than 10% of the Company's total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations. The Company recognized research and development costs primarily related to its design and innovations businesses of $75.5 million, $35.2 million, and $30.0 million for the fiscal years ended March 31, 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:51]
Concentration of Credit Risk

[0001628280-16-016576:notes:52]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, cash and cash equivalents, and derivative instruments.

[0001628280-16-016576:notes:53]
Customer Credit Risk

[0001628280-16-016576:notes:54]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0001628280-16-016576:notes:55]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2016, 2015 and 2014:

[0001628280-16-016576:notes:56]
|  | Balance atBeginningof Year |  | Charged toCosts andExpenses |  | Deductions/Write-Offs |  | Balance atEnd ofYear |
|  | (In thousands) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2014 | $ | 10,877 |  |  | $ | 2,029 |  |  | $ | (7,377 | ) |  | $ | 5,529 |  |
| Year ended March 31, 2015 | $ | 5,529 |  |  | $ | 650 |  |  | $ | (1,645 | ) |  | $ | 4,534 |  |
| Year ended March 31, 2016 | $ | 4,534 |  |  | $ | 72,295 |  |  | $ | (12,221 | ) |  | $ | 64,608 |  |

[0001628280-16-016576:notes:57]
On April 21st, 2016, one of the Company's customers, SunEdison Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. For the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables, and another charge of $10.5 million relating to a separate distressed customer which was also written-off during the year.

[0001628280-16-016576:notes:58]
One customer (including net sales from its current and former parent companies, through the dates of their respective ownership), which is within the Company's CTG segment, accounted for approximately 11%, 17%, and 13% of the Company's net sales in fiscal years 2016, 2015 and 2014, respectively, and approximately 11% and 15% of the Company's total accounts receivable balances in fiscal years 2016 and 2015, respectively. Another customer included in the Company's CEC segment, accounted for approximately 11% of the Company's total accounts receivable balance in fiscal year 2016.

[0001628280-16-016576:notes:59]
The Company's ten largest customers accounted for approximately 46%, 50% and 52%, of its net sales in fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:60]
Derivative Instruments

[0001628280-16-016576:notes:61]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 8.

[0001628280-16-016576:notes:62]
Cash and Cash Equivalents

[0001628280-16-016576:notes:63]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0001628280-16-016576:notes:64]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0001628280-16-016576:notes:65]
Cash and cash equivalents consisted of the following:

[0001628280-16-016576:notes:66]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Cash and bank balances | $ | 533,438 |  |  | $ | 953,549 |  |
| Money market funds and time deposits | 1,074,132 |  |  | 674,859 |  |
|  | $ | 1,607,570 |  |  | $ | 1,628,408 |  |

[0001628280-16-016576:notes:67]
Inventories

[0001628280-16-016576:notes:68]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of lower of cost or market write-downs, were as follows:

[0001628280-16-016576:notes:69]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Raw materials | $ | 2,234,512 |  |  | $ | 2,330,428 |  |
| Work-in-progress | 561,282 |  |  | 557,786 |  |
| Finished goods | 695,862 |  |  | 600,538 |  |
|  | $ | 3,491,656 |  |  | $ | 3,488,752 |  |

[0001628280-16-016576:notes:70]
Property and Equipment, Net

[0001628280-16-016576:notes:71]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are amortized over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment was comprised of the following:

[0001628280-16-016576:notes:72]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2016 |  | 2015 |
|  |  |  | (In thousands) |
| Machinery and equipment | 3 - 10 |  | $ | 3,187,590 |  |  | $ | 2,928,903 |  |
| Buildings | 30 |  | 1,144,798 |  |  | 1,067,837 |  |
| Leasehold improvements | up to 30 |  | 397,340 |  |  | 459,926 |  |
| Furniture, fixtures, computer equipment and software | 3 - 7 |  | 477,203 |  |  | 440,878 |  |
| Land | — |  | 127,927 |  |  | 123,633 |  |
| Construction-in-progress | — |  | 178,851 |  |  | 140,786 |  |
|  |  |  | 5,513,709 |  |  | 5,161,963 |  |
| Accumulated depreciation and amortization |  |  | (3,256,076 | ) |  | (3,069,796 | ) |
| Property and equipment, net |  |  | $ | 2,257,633 |  |  | $ | 2,092,167 |  |

[0001628280-16-016576:notes:73]
Total depreciation expense associated with property and equipment amounted to approximately $425.7 million, $496.8 million and $424.8 million in fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:74]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0001628280-16-016576:notes:75]
Deferred Income Taxes

[0001628280-16-016576:notes:76]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0001628280-16-016576:notes:77]
Accounting for Business and Asset Acquisitions

[0001628280-16-016576:notes:78]
The Company has actively pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0001628280-16-016576:notes:79]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0001628280-16-016576:notes:80]
Goodwill and Other Intangible Assets

[0001628280-16-016576:notes:81]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. If the recorded value of the assets, including goodwill, and liabilities ("net book value") of each reporting unit exceeds its fair value, an impairment loss may be required to be recognized. Further, to the extent the net book value of the Company as a whole is greater than its fair value in the aggregate, all, or a significant portion of its goodwill may be considered impaired.

[0001628280-16-016576:notes:82]
As discussed in note 19, the Company concluded that as of the fourth quarter of fiscal year 2015 it has four reportable operating segments: HRS, CTG, IEI and CEC and concluded these same four segments also represented its reporting units. The Company assessed that there was no change to its reporting units in fiscal year 2016 and performed its goodwill impairment assessment on January 1, 2016, and did not elect to perform the qualitative "Step Zero" assessment.  Instead, the Company performed a quantitative assessment of its goodwill and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0001628280-16-016576:notes:83]
The following table summarizes the activity in the Company's goodwill at the one reporting unit level through December 31, 2014, and at the four reporting unit level from January 1, 2015 through March 31, 2016 (in thousands):

[0001628280-16-016576:notes:84]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Balance, as of March 31, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 292,758 |  |
| Additions (1) | — |  |  | — |  |  | — |  |  | — |  |  | 36,467 |  |
| Purchase accounting adjustments (2) | — |  |  | — |  |  | — |  |  | — |  |  | 8,651 |  |
| Foreign currency translation adjustments | — |  |  | — |  |  | — |  |  | — |  |  | (3,393 | ) |
| Balance, as of December 31, 2014 (3) | 93,990 |  |  | 68,234 |  |  | 64,221 |  |  | 108,038 |  |  | 334,483 |  |
| Purchase accounting adjustments (2) | (656 | ) |  | — |  |  | — |  |  | — |  |  | (656 | ) |
| Foreign currency translation adjustments | (196 | ) |  | — |  |  | — |  |  | — |  |  | (196 | ) |
| Balance, as of March 31, 2015 | 93,138 |  |  | 68,234 |  |  | 64,221 |  |  | 108,038 |  |  | 333,631 |  |
| Additions (1) | 340,610 |  |  | — |  |  | 258,582 |  |  | 3,655 |  |  | 602,847 |  |
| Purchase accounting adjustments (2) | 125 |  |  | — |  |  | — |  |  | — |  |  | 125 |  |
| Foreign currency translation adjustments | 5,463 |  |  | — |  |  | — |  |  | — |  |  | 5,463 |  |
| Balance, as of March 31, 2016 | $ | 439,336 |  |  | $ | 68,234 |  |  | $ | 322,803 |  |  | $ | 111,693 |  |  | $ | 942,066 |  |

[0001628280-16-016576:notes:85]
_______________________________________________________________________________

[0001628280-16-016576:notes:86]
| (1) | The goodwill generated from the Company's business combinations completed during the fiscal years 2016 and 2015 are primarily related to value placed on the employee workforce, service offerings and capabilities and expected synergies. The goodwill is not deductible for income tax purposes. Refer to the discussion of the Company's business acquisitions in note 17. |

[0001628280-16-016576:notes:87]
| (2) | Includes adjustments based on management's estimates resulting from their review and finalization of the valuation of assets and liabilities acquired through certain business combinations completed in a period subsequent to the respective acquisition. These adjustments were not individually, nor in the aggregate, significant to the Company. |

[0001628280-16-016576:notes:88]
| (3) | Goodwill is allocated to each of the reporting units based on the relative fair values assessed in conjunction with the goodwill impairment testing conducted as of January 1, 2015. |

[0001628280-16-016576:notes:89]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2016 and concluded that such amounts continued to be recoverable.

[0001628280-16-016576:notes:90]
Intangible assets are comprised of customer-related intangible assets, that include contractual agreements and customer relationships; and licenses and other intangible assets, that are primarily comprised of licenses and also includes patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. The components of acquired intangible assets are as follows:

[0001628280-16-016576:notes:91]
|  | As of March 31, 2016 |  | As of March 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 223,046 |  |  | $ | (66,473 | ) |  | $ | 156,573 |  |  | $ | 133,853 |  |  | $ | (80,506 | ) |  | $ | 53,347 |  |
| Licenses and other intangibles | 285,053 |  |  | (37,872 | ) |  | 247,181 |  |  | 39,985 |  |  | (11,788 | ) |  | 28,197 |  |
| Total | $ | 508,099 |  |  | $ | (104,345 | ) |  | $ | 403,754 |  |  | $ | 173,838 |  |  | $ | (92,294 | ) |  | $ | 81,544 |  |

[0001628280-16-016576:notes:92]
The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2016, the gross carrying amounts of fully amortized intangible assets totaled $51.7 million. During the year ended March 31, 2016, the total value of intangible assets increased primarily in connection with the Company's acquisitions of Mirror Controls International ("MCi") and NEXTracker Inc. ("NEXTracker"). The MCi acquisition contributed an additional $75.5 million in customer-related intangible assets, and $161.3 million in licenses and other intangible assets, and the NEXTracker acquisition contributed an additional $47.3 million in customer-related intangible assets and $61.4 million in licenses and other intangible assets. Total intangible asset amortization expense recognized in operations during fiscal years 2016, 2015 and 2014 was $66.0 million, $32.0 million and $28.9 million, respectively. As of March 31, 2016, the weighted-average remaining useful lives of the Company's intangible assets were approximately 6.8 years and 7.5 years for customer-related intangibles, and licenses and other intangible assets, respectively. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0001628280-16-016576:notes:93]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 | $ | 76,921 |  |
| 2018 | 62,474 |  |
| 2019 | 55,844 |  |
| 2020 | 47,252 |  |
| 2021 | 42,961 |  |
| Thereafter | 118,302 |  |
| Total amortization expense | $ | 403,754 |  |

[0001628280-16-016576:notes:94]
Derivative Instruments and Hedging Activities

[0001628280-16-016576:notes:95]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in the spot currency rates and the change in the present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Additional information is included in note 8.

[0001628280-16-016576:notes:96]
Other Current Assets

[0001628280-16-016576:notes:97]
Other current assets include approximately $501.1 million and $600.7 million as of March 31, 2016 and 2015, respectively for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0001628280-16-016576:notes:98]
Also included in other current assets is the value of certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $83.6 million and $169.2 million as of March 31, 2016 and 2015, respectively, as further described in note 17. Additionally, other current assets as of March 31, 2016 includes an amount of $36.7 million relating to these assets that have been sold to third parties but not yet collected.

[0001628280-16-016576:notes:99]
Investments

[0001628280-16-016576:notes:100]
The Company has certain equity investments in, and notes receivable from, non-publicly traded companies which are included within other assets. The equity method of accounting is used when the Company has the ability to significantly influence the operating decisions of the issuer; otherwise the cost method is used. Non-majority-owned investments in corporations are accounted for using the equity method when the Company has an ownership percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections.

[0001628280-16-016576:notes:101]
As of March 31, 2016 and 2015, the Company's equity investments in non-majority owned companies totaled $122.9 million and $87.0 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net.

[0001628280-16-016576:notes:102]
Other Current Liabilities

[0001628280-16-016576:notes:103]
Other current liabilities include customer working capital advances of $253.7 million and $189.6 million, customer-related accruals of $479.5 million and $454.8 million, and deferred revenue of $332.3 million and $272.6 million as of March 31, 2016 and 2015, respectively. The customer working capital advances are not interest bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also included the outstanding balances due to the third party banking institution related to the financed equipment discussed above of $122.0 million and $197.7 million as of March 31, 2016 and 2015, respectively, as further described in note 17.

[0001628280-16-016576:notes:104]
Restructuring Charges

[0001628280-16-016576:notes:105]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing and administrative facilities. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0001628280-16-016576:notes:106]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans. See note 14 for additional information regarding restructuring charges.

[0001628280-16-016576:notes:107]
Recently Adopted Accounting Pronouncements

[0001628280-16-016576:notes:108]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. The Company has elected to early adopt this new guidance during the fourth quarter of fiscal year 2016 on a prospective basis as permitted under the new guidance, and the impact was not material.

[0001628280-16-016576:notes:109]
In November 2015, the FASB issued new guidance to eliminate the requirement for companies to separate deferred income tax assets and liabilities into current and noncurrent amounts on the balance sheet. Instead, companies will be required to classify all deferred tax liabilities and assets as noncurrent. The Company elected to early adopt this new guidance during the third quarter of fiscal year 2016 on a prospective basis as permitted under the new guidance, resulting in the reclassification of $66.3 million of deferred income tax assets and $9.1 million of deferred income tax liabilities from current into noncurrent as of March 31, 2016. Prior periods were not retrospectively adjusted.

[0001628280-16-016576:notes:110]
In September 2015, the FASB issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination. Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The Company has elected to early adopt this new guidance which is effective for the Company beginning the third quarter of fiscal year 2016, and the impact was not material.

[0001628280-16-016576:notes:111]
In April 2015, the FASB issued new guidance which changes the presentation of debt issuance costs in financial statements. Under the new guidance, an entity presents such costs in the balance sheet as a direct deduction from the related debt liability rather than as an asset, with amortization of the costs being reported as interest expense. The Company has elected to early adopt during the fourth quarter of fiscal year 2016, and retrospectively adjusted all prior balance sheets presented. As a result of the adoption, $12.7 million of debt issuance costs associated with the Company’s bank borrowings and long-term debt as of March 31, 2015, were reclassified from other noncurrent assets, to short-term and long-term debt in the consolidated balance sheet.

[0001628280-16-016576:notes:112]
Recently Issued Accounting Pronouncements

[0001628280-16-016576:notes:113]
In March 2016, the FASB issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company will be required to adopt the new guidance beginning with the first quarter of fiscal year 2018, with early adoption permitted. The Company is currently assessing the impact of this update and the timing of adoption.

[0001628280-16-016576:notes:114]
In February 2016, the FASB issued new guidance intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months.  The guidance will also enhance existing disclosure requirements relating to those leases. The Company will be required to adopt the new lease guidance beginning with the first quarter of fiscal year 2020, with early adoption permitted. Upon initial evaluation, the Company believes the new guidance will have a material impact on its consolidated balance sheets when adopted. The Company is currently assessing the timing of adoption.

[0001628280-16-016576:notes:115]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value. Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this update and the timing of adoption.

[0001628280-16-016576:notes:116]
In May 2014, the FASB issued new guidance which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition will include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract. In July 2015, the FASB deferred the effective date of the standard by a year, and as a result, the guidance is effective for the Company beginning in the first quarter of fiscal year 2019. The Company has assessed that the impact of the new guidance will result in a change of the Company's revenue recognition model from "point in time" upon physical delivery to an "over time" model and believes this transition will have a material impact on the Company's consolidated financial statements upon adoption.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-016576:notes:117]
BUSINESS AND ASSET ACQUISITIONS

[0001628280-16-016576:notes:118]
Business Acquisitions

[0001628280-16-016576:notes:119]
The business and asset acquisitions described below were accounted for using the purchase method of accounting, and accordingly, the fair value of the net assets acquired and the results of the acquired businesses were included in the Company's consolidated financial statements from the acquisition dates forward. The Company has not finalized the allocation of the consideration for certain of its recently completed acquisitions and completes these allocations in less than one year of the respective acquisition dates.

[0001628280-16-016576:notes:120]
Fiscal year 2016 business acquisitions

[0001628280-16-016576:notes:121]
Acquisition of Mirror Controls International

[0001628280-16-016576:notes:122]
On June 29, 2015, the Company completed its acquisition of 100% of the outstanding share capital of MCi, and paid approximately $555.2 million, net of $27.7 million of cash acquired. This acquisition expanded the Company's capabilities in the automotive market, and was included in the HRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-16-016576:notes:123]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities of MCi (in thousands):

[0001628280-16-016576:notes:124]
| Current assets: |  |
| Accounts receivable | $ | 41,559 |  |
| Inventories | 19,897 |  |
| Other current assets | 2,856 |  |
| Total current assets | 64,312 |  |
| Property and equipment, net | 38,832 |  |
| Other assets | 2,463 |  |
| Intangibles | 236,800 |  |
| Goodwill | 323,357 |  |
| Total assets | $ | 665,764 |  |
| Current liabilities: |  |
| Accounts payable | $ | 28,002 |  |
| Accrued liabilities & other current liabilities | 21,113 |  |
| Total current liabilities | 49,115 |  |
| Other liabilities | 61,492 |  |
| Total aggregate purchase price | $ | 555,157 |  |

[0001628280-16-016576:notes:125]
The intangible assets of $236.8 million is comprised of customer relationships of $75.5 million and licenses and other intangible assets of $161.3 million. Customer relationships and licenses and other intangibles are each amortized over a weighted-average estimated useful life of 10 years. In addition to net working capital, the Company acquired $38.8 million of machinery and equipment and assumed $61.5 million of other liabilities primarily comprised of deferred tax liabilities. The Company incurred $6.6 million in acquisition-related costs related to the acquisition of MCi during fiscal year 2016.

[0001628280-16-016576:notes:126]
Acquisition of a facility from Alcatel-Lucent

[0001628280-16-016576:notes:127]
On July 1, 2015, the Company acquired an optical transport facility from Alcatel-Lucent for approximately $67.5 million, which expanded its capabilities in the telecom market and was included in the CEC segment. The Company acquired primarily $55.1 million of inventory, $10.0 million of property and equipment primarily comprised of a building and land, and recorded goodwill and intangible assets for a customer relationship of $3.6 million and $2.1 million, respectively, and assumed $3.3 million in other net liabilities in connection with this acquisition. The customer relationship intangible will amortize over a weighted-average estimated useful life of 5 years.

[0001628280-16-016576:notes:128]
Acquisition of Nextracker

[0001628280-16-016576:notes:129]
On September 28, 2015, the Company acquired 100% of the outstanding share capital of NEXTracker, a provider of smart solar tracking solutions. The initial cash consideration was approximately $240.8 million, net of $13.2 million of cash acquired, with an additional $81.0 million of estimated potential contingent consideration, for a total purchase consideration of $321.8 million. At the date of the acquisition, the maximum possible consideration under the agreement was $97.2 million upon achievement of future revenue performance targets. Subsequent to the acquisition date, the Company adjusted its estimate of the contingent consideration by $3.7 million, as described further in note 11, which was recorded as an expense in the consolidated statement of operations. The Company also acquired NEXTracker’s equity incentive plan. The financial results of NEXTracker were included in the IEI segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-16-016576:notes:130]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of NEXTracker (in thousands):

[0001628280-16-016576:notes:131]
| Current assets: |  |
| Accounts receivable | $ | 60,298 |  |
| Inventories | 3,235 |  |
| Other current assets | 19,272 |  |
| Total current assets | 82,805 |  |
| Property and equipment, net | 1,382 |  |
| Other assets | 70 |  |
| Intangibles | 108,700 |  |
| Goodwill | 255,601 |  |
| Total assets | $ | 448,558 |  |
| Current liabilities: |  |
| Accounts payable | $ | 17,226 |  |
| Other current liabilities | 63,870 |  |
| Total current liabilities | 81,096 |  |
| Other liabilities | 45,712 |  |
| Total aggregate purchase price | $ | 321,750 |  |

[0001628280-16-016576:notes:132]
The intangible assets of $108.7 million is comprised of customer-related intangibles of $47.3 million and licenses and other intangible assets of $61.4 million. Customer-related intangibles are amortized over a weighted-average estimated useful life of 4 years while licenses and other intangibles are amortized over a weighted-average estimated useful life of 6 years.

[0001628280-16-016576:notes:133]
Other business acquisitions

[0001628280-16-016576:notes:134]
Additionally, during fiscal year 2016, the Company completed eight acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Four of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS segment, two of them strengthened capabilities in the consumer electronics market within the CTG segment, one strengthened the capabilities in the communications market within the CEC segment, and the last one strengthened capabilities in the household industrial and lifestyle market within the IEI segment. The Company paid $53.3 million, net of $3.7 million of cash held by the targets. The Company acquired $14.4 million of property and equipment, assumed liabilities of $17.7 million and recorded goodwill and intangibles of $57.4 million. These intangibles will amortize over a weighted-average estimated useful life of 4 years.

[0001628280-16-016576:notes:135]
The results of operations for all of the acquisitions completed in fiscal year 2016 were included in the Company’s consolidated financial results beginning on the date of each acquisition.  The total amount of net income for all of the acquisitions completed in fiscal year 2016, collectively, was $41.4 million. The total amount of revenue of these acquisitions, collectively, was not material to the Company’s consolidated financial results for the fiscal year 2016.

[0001628280-16-016576:notes:136]
On a pro-forma basis, and assuming the acquisitions occurred on the first day of the prior comparative period, or April 1, 2014, net income would have been estimated to be $410.1 million, and $586.4 million for fiscal years 2016 and 2015, respectively. The estimated pro-forma net income for all periods presented does not include the $43.0 million tax benefit for the release of the valuation allowance on deferred tax assets relating to the NEXTracker acquisition, recognized in fiscal year 2016 as discussed further in note 13, to promote comparability. Pro-forma revenue for the acquisitions in fiscal year 2016 and 2015 have not been presented because the effect, collectively, was not material to the Company’s consolidated revenues for all periods presented.

[0001628280-16-016576:notes:137]
Fiscal year 2015 business acquisitions

[0001628280-16-016576:notes:138]
During the fiscal year 2015, the Company completed four acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. All of the acquired businesses expanded the Company's capabilities in the medical devices market, particularly precision plastics, within the HRS segment. The Company paid $52.7 million net of $5.9 million of cash held by the acquired businesses, and recorded an accrual of $4.5 million for contingent consideration relating to one of the acquisitions. The Company primarily acquired $29.4 million of current assets, $9.0 million of property and equipment, recorded goodwill of $35.8 million and intangibles of $16.1 million, and assumed certain liabilities relating to payables and debt in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the date of these acquisitions. Pro-forma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results for all periods presented. The Company also paid $7.5 million as a deposit to acquire a certain business that closed in fiscal year 2016 and that strengthened capabilities in the household industrial market within the IEI segment. This deposit was included in other assets during fiscal year 2015.

[0001628280-16-016576:notes:139]
Fiscal year 2014 business acquisitions

[0001628280-16-016576:notes:140]
Acquisition of Motorola Mobility LLC from Google

[0001628280-16-016576:notes:141]
On April 16, 2013, the Company completed the acquisition of certain manufacturing operations from Google's Motorola Mobility LLC. The Company also entered into a manufacturing and services agreement with Motorola Mobility for mobile devices in conjunction with this acquisition. This acquisition expanded the Company's relationship with Google's Motorola Mobility and the Company's capabilities in the mobile devices market, within the CTG segment.

[0001628280-16-016576:notes:142]
The cash consideration for this acquisition amounted to $178.9 million. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-16-016576:notes:143]
The following represents the Company's allocation of the total purchase price to the acquired assets and liabilities assumed of Google's Motorola Mobility LLC (in thousands):

[0001628280-16-016576:notes:144]
| Current assets: |  |
| Inventories | $ | 97,740 |  |
| Other current assets | 24,280 |  |
| Total current assets | 122,020 |  |
| Property and equipment | 45,198 |  |
| Goodwill | 2,844 |  |
| Other intangible assets (useful life—6 years) | 2,948 |  |
| Other assets | 7,414 |  |
| Total assets | $ | 180,424 |  |
| Current liabilities: |  |
| Other current liabilities | $ | 317 |  |
| Total current liabilities | 317 |  |
| Other liabilities | 1,202 |  |
| Total aggregate purchase price | $ | 178,905 |  |

[0001628280-16-016576:notes:145]
Acquisition of Riwisa AG

[0001628280-16-016576:notes:146]
On November 4, 2013, the Company acquired all of the outstanding shares of Riwisa AG, a company registered in Switzerland for total cash consideration of $44.0 million, net of cash acquired of $9.4 million. This acquisition expanded the Company's capabilities in the medical devices market, particularly precision plastics within the HRS segment. The Company primarily acquired inventory, property and equipment and assumed certain liabilities relating to payables and debt. The results of operations were included in the Company's consolidated financial results beginning on the date of acquisition. Proforma results of operations for this acquisition have not been presented because the effects of the acquisition were not material to the Company's consolidated financial results.

[0001628280-16-016576:notes:147]
The initial allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. During fiscal year 2014 the Company recorded $22.7 million as intangible assets and $18.5 million as goodwill based on a preliminary assessment of fair value of assets acquired and liabilities assumed. During fiscal year 2015, the Company further adjusted the purchase allocation for the acquisition resulting in a $2.6 million increase in the total cash consideration from $44.0 million to $46.6 million, and an $8.7 million fair value adjustment for assets acquired, increasing total goodwill to $27.2 million. Intangible assets are comprised of customer-relationships of $15.8 million amortized over a period of 10 years and developed technology and trade names of $6.9 million amortized over a period of 7 years.

[0001628280-16-016576:notes:148]
Further, during fiscal year 2014, the Company completed two other acquisitions for total cash consideration of $15.1 million. Neither of these acquisitions were significant to the Company's consolidated financial position, results of operations and cash flows. These businesses expanded the Company's capabilities primarily in manufacturing operations for precision plastics, components and molds. The Company acquired primarily property and equipment and inventory and recorded goodwill amounting to $5.0 million in connection with these acquisitions. The results of operations were included in the Company's consolidated financial results beginning on the dates of these acquisitions. Proforma results of operations for these acquisitions have not been presented because the effects of the acquisitions were immaterial to the Company's consolidated financial results. Additionally, transaction costs related to all acquisitions completed during the periods presented were immaterial to the Company's financial results.

[0001628280-16-016576:notes:149]
The Company continues to evaluate certain assets and liabilities related to business combinations completed during recent periods. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Changes to amounts recorded as assets or liabilities, as a result of such additional information, may result in a corresponding adjustment to goodwill.

[0001628280-16-016576:notes:150]
The goodwill generated from the Company's business combinations completed during the fiscal year ended March 31, 2014 is primarily related to value placed on the employee workforce, service offerings and capabilities, and expected synergies and is not deductible for income tax purposes.

[0001628280-16-016576:notes:151]
In connection with one businesses acquired during fiscal year 2013, the Company entered into an agreement with an existing customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer. The manufacturing equipment was used exclusively for the benefit of this customer. The Company cannot be required to pay cash by either the customer or the third party banking institution. During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment. As a result, pursuant an agreement with the customer, the Company as an agent on behalf of the customer dispositioned the equipment via sales to third parties and used the proceeds to reduce the obligation to the third party banking institution. Accordingly, the residual value due from the customer related to the equipment financed by the third party banking institution decreased to $83.6 million from $169.2 million as of March 31, 2016 and 2015, respectively, and has been included in other current assets. The outstanding balance due to the third party banking institution related to the financed equipment correspondingly decreased to $122.0 million from $197.7 million as of March 31, 2016 and 2015, respectively, and has been included in other current liabilities. The cash inflows from the sale of the manufacturing equipment originally purchased on behalf of the customer and financed by the third party banking institution amounting to $54.3 million and $79.7 million have been included in other investing cash flows for the fiscal years ended March 31, 2016 and 2015, respectively. The cash outflows relating to the purchase of the manufacturing equipment by the Company on behalf of the customer of $37.3 million have also been included in other investing cash flows for the fiscal year ended March 31, 2014. The cash outflows to repay the third party banking institution on behalf of the customer upon cessation of manufacturing operations of $75.8 million and $88.8 million have been included in cash flows from other financing activities during the fiscal years ended March 31, 2016 and 2015, respectively. Net cash inflows amounting to $13.5 million relating to the funding of these assets by the financial institution on behalf of the customer have been included in cash flows from other financing activities during the fiscal year ended March 31, 2014.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001628280-16-016576:notes:152]
SUPPLEMENTAL CASH FLOW DISCLOSURES

[0001628280-16-016576:notes:153]
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0001628280-16-016576:notes:154]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 114,578 |  |  | $ | 87,179 |  |  | $ | 86,406 |  |
| Income taxes | $ | 105,453 |  |  | $ | 70,621 |  |  | $ | 87,561 |  |
| Non-cash investing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 93,310 |  |  | $ | 115,757 |  |  | $ | 42,902 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-016576:notes:155]
COMMITMENTS AND CONTINGENCIES

[0001628280-16-016576:notes:156]
Commitments

[0001628280-16-016576:notes:157]
Capital lease obligations of $25.0 million and $5.3 million, consisting of short-term obligations of $6.6 million and $2.8 million and long term obligations of $18.4 million and $2.5 million are included in current and non-current liabilities on the Company's balance sheets as of March 31, 2016 and 2015, respectively.

[0001628280-16-016576:notes:158]
As of March 31, 2016 and 2015, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under capital leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2035 and require the following minimum lease payments:

[0001628280-16-016576:notes:159]
| Fiscal Year Ending March 31, | Operating Lease |
|  | (In thousands) |
| 2017 | $ | 125,021 |  |
| 2018 | 106,287 |  |
| 2019 | 84,916 |  |
| 2020 | 69,194 |  |
| 2021 | 47,780 |  |
| Thereafter | 146,003 |  |
| Total minimum lease payments | $ | 579,201 |  |

[0001628280-16-016576:notes:160]
Total rent expense amounted to $124.2 million, $133.1 million and $150.1 million in fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:161]
Litigation and other legal matters

[0001628280-16-016576:notes:162]
During the fourth quarter of fiscal 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $13.8 million based on the exchange rate as of March 31, 2016) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While we believe there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these claims for several years.

[0001628280-16-016576:notes:163]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001628280-16-016576:notes:164]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company's consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-016576:notes:165]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001628280-16-016576:notes:166]
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2016, 2015 and 2014 are as follows:

[0001628280-16-016576:notes:167]
|  | Fiscal Year Ended March 31, 2016 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive loss before reclassifications | (2,199 | ) |  | (3,145 | ) |  | (5,344 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 28,943 |  |  | 20,991 |  |  | 49,934 |  |
| Net current-period other comprehensive gain | 26,744 |  |  | 17,846 |  |  | 44,590 |  |
| Ending balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |

[0001628280-16-016576:notes:168]
|  | Fiscal Year Ended March 31, 2015 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |
| Other comprehensive loss before reclassifications | (76,470 | ) |  | (9,318 | ) |  | (85,788 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 41,053 |  |  | (9,614 | ) |  | 31,439 |  |
| Net current-period other comprehensive loss | (35,417 | ) |  | (18,932 | ) |  | (54,349 | ) |
| Ending balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |

[0001628280-16-016576:notes:169]
|  | Fiscal Year Ended March 31, 2014 |
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (18,857 | ) |  | $ | (58,624 | ) |  | $ | (77,481 | ) |
| Other comprehensive loss before reclassifications | (15,851 | ) |  | (34,683 | ) |  | (50,534 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 1,859 |  |  | — |  |  | 1,859 |  |
| Net current-period other comprehensive loss | (13,992 | ) |  | (34,683 | ) |  | (48,675 | ) |
| Ending balance | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |

[0001628280-16-016576:notes:170]
Net losses reclassified from accumulated other comprehensive loss during the fiscal year 2016 relating to derivative instruments and other includes $26.9 million attributable to the Company's cash flow hedge instruments which were recognized as a component of cost of sales in the consolidated statement of operations.

[0001628280-16-016576:notes:171]
During fiscal year 2016, the Company recognized a loss of $26.8 million in connection with the disposition of a non-strategic Western European manufacturing facility, which included a $25.3 million cumulative foreign currency translation loss. This loss was offset by the release of certain cumulative foreign currency translation gains of $4.2 million, which has been reclassified from accumulated other comprehensive loss during the period and is included in other charges (income), net in consolidated statement of operations.

[0001628280-16-016576:notes:172]
During fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the consolidated statement of operations.


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-016576:notes:173]
BANK BORROWINGS AND LONG-TERM DEBT

[0001628280-16-016576:notes:174]
Bank borrowings and long-term debt are as follows:

[0001628280-16-016576:notes:175]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 577,500 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 547,500 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,589 |  |  | — |  |
| Other | 71,317 |  |  | 16,233 |  |
| Debt issuance costs | (17,351 | ) |  | (12,733 | ) |
|  | 2,774,555 |  |  | 2,071,000 |  |
| Current portion, net of debt issuance costs | (65,166 | ) |  | (45,030 | ) |
| Non-current portion | $ | 2,709,389 |  |  | $ | 2,025,970 |  |

[0001628280-16-016576:notes:176]
The weighted-average interest rates for the Company's long-term debt were 3.5% and 3.2% as of March 31, 2016 and 2015, respectively.

[0001628280-16-016576:notes:177]
Repayments of the Company's long-term debt are as follows:

[0001628280-16-016576:notes:178]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 | $ | 65,166 |  |
| 2018 | 63,522 |  |
| 2019 | 1,005,095 |  |
| 2020 | 498,287 |  |
| 2021 | 49,153 |  |
| Thereafter | 1,110,683 |  |
| Total | $ | 2,791,906 |  |

[0001628280-16-016576:notes:179]
Term Loan due August 2018

[0001628280-16-016576:notes:180]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018 and used these proceeds to repay certain term loans in full that were outstanding at that time in the amount of $544.8 million. The remaining $55.2 million was used to repay part of the term loan due March 2019 and upfront bank fees. This loan is repayable in quarterly installments of $3.75 million, which commenced in December 2014 and continue through August 2018, with the remaining amount due at maturity.

[0001628280-16-016576:notes:181]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.00% and 2.00%, based on the Company's credit ratings or (ii) the base rate (the greatest of the U.S. prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.00% and 1.00%, based on the Company's credit rating.

[0001628280-16-016576:notes:182]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, the Company was in compliance with the covenants under this term loan agreement.

[0001628280-16-016576:notes:183]
Term Loan Agreement due March 2019 and Revolving Line of Credit

[0001628280-16-016576:notes:184]
On September 30, 2015, the Company amended its former $2.0 billion credit facility ("Credit Facility") to increase the $500.0 million term loan maturing in March 2019 by $100.0 million. Quarterly repayments of principal under this term loan were amended to $7.5 million through March 31, 2016, and will be increased to $11.3 million thereafter with the remainder due upon maturity. As of March 31, 2016 the amended Credit Facility consists of a $1.5 billion revolving credit facility and a $600.0 million term loan, which is due to expire in March 2019.

[0001628280-16-016576:notes:185]
Borrowings under this facility bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating. The Company is required to pay a quarterly commitment fee ranging between 0.15% and 0.40% per annum on the daily unused amount of the $1.5 billion Revolving Credit Facility based on the Company's credit rating.

[0001628280-16-016576:notes:186]
This Credit Facility is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This Credit Facility also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, the Company was in compliance with the covenants under this loan agreement.

[0001628280-16-016576:notes:187]
Notes due February 2020 and February 2023

[0001628280-16-016576:notes:188]
On February 20, 2013, the Company issued $500.0 million of 4.625% Notes due February 15, 2020 and $500.0 million of 5.000% Notes due February 15, 2023 (collectively the "Notes") in a private offering pursuant to Rule 144A and Regulation S under the Securities Act. In July 2013, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. The Company received net proceeds of approximately $990.6 million from the issuance and used those proceeds, together with $9.4 million of cash on hand, to repay $1.0 billion of outstanding borrowings under its previous term loan that was due October 2014.

[0001628280-16-016576:notes:189]
Interest on the Notes is payable semi-annually, which commenced on August 15, 2013. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Credit Facility or the Company's Term Loan due 2018.

[0001628280-16-016576:notes:190]
At any time prior to maturity, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001628280-16-016576:notes:191]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately. As of March 31, 2016, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001628280-16-016576:notes:192]
Notes due June 2025

[0001628280-16-016576:notes:193]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, the Company exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission.

[0001628280-16-016576:notes:194]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and presented on the balance sheet as a direct deduction from the carrying amount of the Notes.

[0001628280-16-016576:notes:195]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0001628280-16-016576:notes:196]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001628280-16-016576:notes:197]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of March 31, 2016, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001628280-16-016576:notes:198]
Other Credit Lines

[0001628280-16-016576:notes:199]
On October 1, 2015, the Company borrowed €50 million (approximately $56.6 million as of March 31, 2016), under a 5-year, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on the Company’s credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity. This loan is included in the "Other" category in the table above.

[0001628280-16-016576:notes:200]
This term loan is unsecured, and is guaranteed by the Company. This term loan agreement contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, the Company was in compliance with the covenants under this term loan agreement.

[0001628280-16-016576:notes:201]
As of March 31, 2016, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $166.0 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2016 and 2015. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin, and generally have maturities that expire on various dates in future fiscal years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-016576:notes:202]
FINANCIAL INSTRUMENTS

[0001628280-16-016576:notes:203]
Foreign Currency Contracts

[0001628280-16-016576:notes:204]
The Company transacts business in various foreign countries and is therefore, exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, revenues, customer and vendor payments and inter-company balances in currencies other than the functional currency unit of the operating entity. The Company enters into short-term foreign currency forward and swap contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's forward and swap contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these forward and swap contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0001628280-16-016576:notes:205]
As of March 31, 2016, the aggregate notional amount of the Company's outstanding foreign currency forward and swap contracts was $4.3 billion as summarized below:

[0001628280-16-016576:notes:206]
|  | Foreign CurrencyAmount |  | Notional ContractValue in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| CNY | 1,076,000 |  |  | — |  |  | $ | 165,373 |  |  | $ | — |  |
| EUR | 15,030 |  |  | 75,135 |  |  | 16,977 |  |  | 85,374 |  |
| HUF | 14,759,000 |  |  | — |  |  | 53,090 |  |  | — |  |
| ILS | 122,000 |  |  | — |  |  | 32,072 |  |  | — |  |
| MXN | 1,503,000 |  |  | — |  |  | 86,823 |  |  | — |  |
| MYR | 180,000 |  |  | 18,200 |  |  | 45,023 |  |  | 4,552 |  |
| PLN | 56,400 |  |  | — |  |  | 15,004 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 40,621 |  |  | — |  |
|  |  |  |  |  | 454,983 |  |  | 89,926 |  |
| Other Forward/Swap Contracts |  |  |  |  |  |  |  |
| BRL | — |  |  | 440,000 |  |  | — |  |  | 120,892 |  |
| CHF | 8,420 |  |  | 24,760 |  |  | 8,716 |  |  | 25,629 |  |
| CNY | 885,136 |  |  | — |  |  | 135,739 |  |  | — |  |
| DKK | 203,100 |  |  | 157,200 |  |  | 30,777 |  |  | 23,821 |  |
| EUR | 959,000 |  |  | 1,213,691 |  |  | 1,080,754 |  |  | 1,364,808 |  |
| GBP | 34,693 |  |  | 58,825 |  |  | 49,810 |  |  | 84,354 |  |
| HUF | 20,063,000 |  |  | 17,734,000 |  |  | 72,169 |  |  | 63,791 |  |
| ILS | 79,900 |  |  | 69,520 |  |  | 21,004 |  |  | 18,276 |  |
| INR | 2,843,900 |  |  | 20,170 |  |  | 42,708 |  |  | 300 |  |
| MXN | 1,885,860 |  |  | 746,330 |  |  | 108,940 |  |  | 43,113 |  |
| MYR | 391,491 |  |  | 79,400 |  |  | 97,922 |  |  | 19,860 |  |
| PLN | 137,548 |  |  | 84,861 |  |  | 36,593 |  |  | 22,576 |  |
| RON | 78,424 |  |  | 66,870 |  |  | 19,836 |  |  | 16,913 |  |
| SEK | 473,954 |  |  | 821,132 |  |  | 57,697 |  |  | 99,637 |  |
| Other | N/A |  |  | N/A |  |  | 54,157 |  |  | 31,296 |  |
|  |  |  |  |  | 1,816,822 |  |  | 1,935,266 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 2,271,805 |  |  | $ | 2,025,192 |  |

[0001628280-16-016576:notes:207]
As of March 31, 2016 and 2015, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in non-functional currencies and are not accounted for as hedges under the accounting standards. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the consolidated statements of operations. As of March 31, 2016 and 2015, the Company also has included net deferred gains and losses, in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred gains totaled $2.7 million as of March 31, 2016, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal years presented and are included as a component of interest and other, net in the consolidated statements of operations.

[0001628280-16-016576:notes:208]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2016 and 2015:

[0001628280-16-016576:notes:209]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31, 2016 |  | March 31, 2015 |  | Balance SheetLocation |  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 5,510 |  |  | $ | 2,896 |  |  | Other current liabilities |  | $ | 2,446 |  |  | $ | 19,729 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 17,138 |  |  | $ | 22,933 |  |  | Other current liabilities |  | $ | 18,645 |  |  | $ | 11,328 |  |

[0001628280-16-016576:notes:210]
The Company has financial instruments subject to master netting arrangements, which provides for the net settlement of all contracts with a single counterparty. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, and as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-016576:notes:211]
SHARE-BASED COMPENSATION

[0001628280-16-016576:notes:212]
Equity Compensation Plans

[0001628280-16-016576:notes:213]
The Company's primary plan used for granting equity compensation awards is the 2010 Equity Incentive Plan (the "2010 Plan").

[0001628280-16-016576:notes:214]
During fiscal year 2016, in conjunction with the acquisition of NEXTracker, the Company assumed all of the outstanding, unvested share bonus awards and outstanding, unvested options to purchase shares of common stock of NEXTracker, and converted all these shares into Flex awards. As a result, the Company offers an additional equity compensation plan as of March 31, 2016, the 2014 NEXTracker Equity Incentive Plan (the "NEXTracker Plan").

[0001628280-16-016576:notes:215]
Further, during fiscal year 2016, the Company granted equity compensation awards under a third plan, the 2013 Elementum Plan (the "Elementum Plan"), which is administered by Elementum SCM (Cayman) Limited ("Elementum"), a majority owned subsidiary of the Company.

[0001628280-16-016576:notes:216]
Share-Based Compensation Expense

[0001628280-16-016576:notes:217]
The following table summarizes the Company's share-based compensation expense for all Equity Incentive Plans:

[0001628280-16-016576:notes:218]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Cost of sales | $ | 8,986 |  |  | $ | 7,503 |  |  | $ | 6,540 |  |
| Selling, general and administrative expenses | 68,594 |  |  | 42,767 |  |  | 33,899 |  |
| Total share-based compensation expense | $ | 77,580 |  |  | $ | 50,270 |  |  | $ | 40,439 |  |

[0001628280-16-016576:notes:219]
As required by the authoritative guidance for stock-based compensation, management made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as an analysis of actual forfeitures.

[0001628280-16-016576:notes:220]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as financing cash flows. During fiscal years 2016, 2015 and 2014, the Company did not recognize any excess tax benefits as a financing cash inflow.

[0001628280-16-016576:notes:221]
The 2010 Equity Incentive Plan

[0001628280-16-016576:notes:222]
As of March 31, 2016, the Company had approximately 27.1 million shares available for grant under the 2010 Plan. Options issued to employees under the 2010 Plan generally vest over four years and expire seven years from the date of grant. Options granted to non-employee directors expire five years from the date of grant.

[0001628280-16-016576:notes:223]
The exercise price of options granted to employees is determined by the Company's Board of Directors or the Compensation Committee and may not be less than the closing price of the Company's ordinary shares on the date of grant.

[0001628280-16-016576:notes:224]
As of March 31, 2016, the total unrecognized compensation cost, net of estimated forfeitures, related to unvested share options granted to employees under the 2010 Plan was not significant and will be amortized on a straight-line basis over a weighted-average period of approximately 2.3 years, adjusted for estimated forfeitures.

[0001628280-16-016576:notes:225]
The Company also grants share bonus awards under its equity compensation plan. Share bonus awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. Share bonus awards generally vest in installments over a three to five-year period and unvested share bonus awards are forfeited upon termination of employment.

[0001628280-16-016576:notes:226]
Vesting for certain share bonus awards is contingent upon both service and market conditions. Further, vesting for certain share bonus awards granted to certain executive officers is contingent upon meeting certain free cash flow targets.

[0001628280-16-016576:notes:227]
As of March 31, 2016, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $97.9 million, net of estimated forfeitures, under the 2010 Plan. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.5 years, adjusted for estimated forfeitures. Approximately $13.7 million of the unrecognized compensation cost related to the 2010 Plan, net of estimated forfeitures, is related to share bonus awards granted to certain key employees whereby vesting is contingent on meeting a certain market condition.

[0001628280-16-016576:notes:228]
Determining Fair Value - Options and share bonus awards

[0001628280-16-016576:notes:229]
Valuation and Amortization Method—The Company estimates the fair value of share options granted under the 2010 Plan using the Black-Scholes valuation method and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period. The fair market value of share bonus awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0001628280-16-016576:notes:230]
Expected Term—The Company's expected term used in the Black-Scholes valuation method represents the period that the Company's share options are expected to be outstanding and is determined based on historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share options.

[0001628280-16-016576:notes:231]
Expected Volatility—The Company's expected volatility used in the Black-Scholes valuation method is derived from a combination of implied volatility related to publicly traded options to purchase Flex ordinary shares and historical variability in the Company's periodic share price.

[0001628280-16-016576:notes:232]
Expected Dividend—The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0001628280-16-016576:notes:233]
Risk-Free Interest Rate—The Company bases the risk-free interest rate used in the Black-Scholes valuation method on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the option.

[0001628280-16-016576:notes:234]
There were no options granted under the 2010 Plan during fiscal years 2016 and 2014. The fair value of the Company's share options granted to employees for fiscal year 2015 was estimated using the following weighted-average assumptions:

[0001628280-16-016576:notes:235]
|  | Fiscal Year EndedMarch 31, |
|  | 2015 |
| Expected term | 6.3 years |
| Expected volatility | 46.9% |
| Expected dividends | 0.0% |
| Risk-free interest rate | 2.3% |
| Weighted-average fair value | $4.85 |

[0001628280-16-016576:notes:236]
Options granted during fiscal year 2015 had contractual lives of seven years.

[0001628280-16-016576:notes:237]
Determining Fair Value - Share bonus awards with service and market conditions

[0001628280-16-016576:notes:238]
Valuation and Amortization Method—The Company estimates the fair value of share bonus awards granted under the 2010 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0001628280-16-016576:notes:239]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the share bonus awards granted. The service period is three years for those share bonus awards granted in fiscal years 2016, 2015 and 2014.

[0001628280-16-016576:notes:240]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of both the S&P 500 index and components of an extended Electronics Manufacturing Services ("EMS") group, comprised of global competitors of the Company within the same industry, for the share bonus awards granted in fiscal years 2016, 2015 and 2014.

[0001628280-16-016576:notes:241]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to both the S&P 500 index and peers in the extended EMS group for the share bonus awards granted in fiscal years 2016, 2015 and 2014.

[0001628280-16-016576:notes:242]
Expected Dividend and Risk-Free Interest Rate assumptions—Same methodology as discussed above.

[0001628280-16-016576:notes:243]
The fair value of the Company's share-bonus awards under the 2010 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2016, 2015 and 2014 was estimated using the following weighted-average assumptions:

[0001628280-16-016576:notes:244]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected volatility | 26.0 | % |  | 29.4 | % |  | 35.9 | % |
| Average peer volatility | 23.0 | % |  | 25.9 | % |  | 35.7 | % |
| Average peer correlation | 0.6 |  |  | 0.6 |  |  | 0.4 |  |
| Expected dividends | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Risk-free interest rate | 1.2 | % |  | 0.9 | % |  | 0.4 | % |

[0001628280-16-016576:notes:245]
Share-Based Awards Activity

[0001628280-16-016576:notes:246]
The following is a summary of option activity for the Company's 2010 Plan ("Price" reflects the weighted-average exercise price):

[0001628280-16-016576:notes:247]
|  | Fiscal Year Ended March 31, |
|  | 2016 | 2015 | 2014 |
|  | Options |  | Price |  | Options |  | Price |  | Options |  | Price |
| Outstanding, beginning of fiscal year | 15,992,894 |  |  | $ | 7.81 |  |  | 23,612,872 |  |  | $ | 8.57 |  |  | 34,405,564 |  |  | $ | 8.29 |  |
| Granted | — |  |  | — |  |  | 15,000 |  |  | 11.11 |  |  | — |  |  | — |  |
| Exercised | (10,006,774 | ) |  | 6.10 |  |  | (3,600,900 | ) |  | 6.53 |  |  | (6,572,383 | ) |  | 4.28 |  |
| Forfeited | (3,616,484 | ) |  | 12.23 |  |  | (4,034,078 | ) |  | 13.17 |  |  | (4,220,309 | ) |  | 12.93 |  |
| Outstanding, end of fiscal year | 2,369,636 |  |  | $ | 8.31 |  |  | 15,992,894 |  |  | $ | 7.81 |  |  | 23,612,872 |  |  | $ | 8.57 |  |
| Options exercisable, end of fiscal year | 2,359,527 |  |  | $ | 8.30 |  |  | 15,959,173 |  |  | $ | 7.81 |  |  | 23,373,101 |  |  | $ | 8.58 |  |

[0001628280-16-016576:notes:248]
The aggregate intrinsic value of options exercised under the Company's 2010 Plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $55.3 million, $16.3 million and $24.7 million during fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:249]
Cash received from option exercises under the 2010 Plan was $61.1 million, $23.5 million and $28.1 million for fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:notes:250]
The following table presents the composition of options outstanding and exercisable under the 2010 Plan as of March 31, 2016:

[0001628280-16-016576:notes:251]
|  |  | Options Outstanding | Options Exercisable |
| Range of Exercise Prices |  | Number ofSharesOutstanding |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |  | Number ofSharesExercisable |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |
| $1.94 - $5.75 |  | 1,148,421 |  |  | 0.40 |  | $ | 5.55 |  |  | 1,148,421 |  |  | 0.40 |  | $ | 5.55 |  |
| $5.87 - $7.07 |  | 40,002 |  |  | 1.55 |  | 6.55 |  |  | 37,521 |  |  | 1.41 |  | 6.54 |  |
| $7.08 - $10.59 |  | 323,646 |  |  | 1.76 |  | 8.25 |  |  | 323,646 |  |  | 1.76 |  | 8.25 |  |
| $10.67 - $11.41 |  | 549,067 |  |  | 0.34 |  | 11.23 |  |  | 541,439 |  |  | 0.27 |  | 11.23 |  |
| $11.53 - $13.98 |  | 273,500 |  |  | 0.50 |  | 13.37 |  |  | 273,500 |  |  | 0.50 |  | 13.37 |  |
| $14.34 - $23.02 |  | 35,000 |  |  | 0.42 |  | 15.95 |  |  | 35,000 |  |  | 0.42 |  | 15.95 |  |
| $1.94 - $23.02 |  | 2,369,636 |  |  | 0.60 |  | $ | 8.31 |  |  | 2,359,527 |  |  | 0.59 |  | $ | 8.30 |  |
| Options vested and expected to vest |  | 2,368,361 |  |  | 0.60 |  | $ | 8.31 |  |  |  |  |  |  |  |  |

[0001628280-16-016576:notes:252]
As of March 31, 2016 the aggregate intrinsic value for options outstanding, options vested and expected to vest (which includes adjustments for expected forfeitures), and options exercisable under the Company's 2010 Plan, were $9.4 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2016 for the approximately 2.1 million options that were in-the-money at March 31, 2016.

[0001628280-16-016576:notes:253]
The following table summarizes the Company's share bonus award activity under the 2010 Plan ("Price" reflects the weighted-average grant-date fair value):

[0001628280-16-016576:notes:254]
|  | Fiscal Year Ended March 31, |
|  | 2016 | 2015 | 2014 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | 18,993,252 |  |  | $ | 9.01 |  |  | 21,848,120 |  |  | $ | 7.32 |  |  | 21,807,069 |  |  | $ | 6.80 |  |
| Granted | 7,619,722 |  |  | 12.23 |  |  | 6,963,125 |  |  | 11.75 |  |  | 8,978,941 |  |  | 8.07 |  |
| Vested | (8,529,378 | ) |  | 7.93 |  |  | (7,246,056 | ) |  | 6.97 |  |  | (5,481,153 | ) |  | 6.66 |  |
| Forfeited | (1,083,520 | ) |  | 9.67 |  |  | (2,571,937 | ) |  | 7.70 |  |  | (3,456,737 | ) |  | 7.07 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 17,000,076 |  |  | $ | 10.77 |  |  | 18,993,252 |  |  | $ | 9.01 |  |  | 21,848,120 |  |  | $ | 7.32 |  |

[0001628280-16-016576:notes:255]
Of the 7.6 million unvested share bonus awards granted under the 2010 Plan in fiscal year 2016, approximately 0.2 million have an average grant date price of $12.10 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. These awards ultimately vest over a range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three-years.

[0001628280-16-016576:notes:256]
Another 0.2 million of unvested share bonus awards granted in fiscal year 2016 have an average grant date price of $12.06 per share and represents the target amount of grants made to certain employees whereby vesting is contingent on meeting certain operating profit targets. These awards ultimately vest over a range from zero up to a maximum of 0.4 million of the target payments based on the operating profit achievements of a certain business unit of the Company over a four-year period. The vesting will begin on March 31, 2016 and occur every year over a period of four years contingent on meeting the agreed targets.

[0001628280-16-016576:notes:257]
Further, 0.7 million of unvested share bonus awards granted in fiscal year 2016 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards was estimated to be $14.96 per award and was calculated using a Monte Carlo simulation. Vesting information of these shares are further detailed in the table below.

[0001628280-16-016576:notes:258]
In accordance with the accounting guidance, the Company will continue to recognize share-based compensation expense for these awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2016, 2.2 million shares vested in connection with the remaining number of share bonus awards with market conditions granted in fiscal year 2013, and 0.5 million shares vested in connection with half of the share bonus awards with market conditions granted in fiscal year 2012.

[0001628280-16-016576:notes:259]
The total intrinsic value of share bonus awards vested under the Company's 2010 Plan was $103.2 million, $79.0 million and $42.4 million during fiscal years 2016, 2015 and 2014, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0001628280-16-016576:notes:260]
The 2014 NEXTracker Equity Incentive Plan

[0001628280-16-016576:notes:261]
All shares granted during fiscal year 2016 under the NEXTracker plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition. No additional grants will be made out of this plan in the future and therefore there are no shares available for grant under the NEXTracker Plan as of March 31, 2016. Options issued to employees under the NEXTracker Plan generally have a vesting period of two to four years from vesting commencement date and expire ten years from the date of grant.

[0001628280-16-016576:notes:262]
The exercise price of options granted to employees was determined by the Company based on a conversion rate agreed upon in the purchase agreement of NEXTracker.

[0001628280-16-016576:notes:263]
As of March 31, 2016, the total unrecognized compensation cost, net of estimated forfeitures, related to unvested share options granted to employees under the NEXTracker Plan was $18.2 million and will be amortized on a straight-line basis over a weighted-average period of approximately 2.8 years, adjusted for estimated forfeitures.

[0001628280-16-016576:notes:264]
The Company also granted share bonus awards under the NEXTracker Plan. These share bonus awards vest in installments over a three to five-year period from vesting commencement date, and unvested share bonus awards are forfeited upon termination of employment. Vesting for certain of these share bonus awards is contingent on meeting certain performance targets over a three-year period commencing October 1, 2015.

[0001628280-16-016576:notes:265]
As of March 31, 2016, the total unrecognized compensation cost related to unvested share bonus awards granted to employees was approximately $19.1 million under the NEXTracker Plan. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.4 years, adjusted for estimated forfeitures.

[0001628280-16-016576:notes:266]
Determining Fair Value

[0001628280-16-016576:notes:267]
The fair value of the Company's share options granted to employees under the NEXTracker Plan for fiscal year 2016 was estimated using the following weighted-average assumptions:

[0001628280-16-016576:notes:268]
|  | Fiscal Year EndedMarch 31, 2016 |
| Expected term | 2.9 years |
| Expected volatility | 28.8% |
| Expected dividends | 0.0% |
| Risk-free interest rate | 0.9% |
| Weighted-average fair value | $7.76 |

[0001628280-16-016576:notes:269]
The following is a summary of option activity for the NEXTracker Plan ("Price" reflects the weighted-average exercise price):

[0001628280-16-016576:notes:270]
|  | Fiscal Year Ended March 31, |
|  | 2016 |
|  | Options |  | Price |
| Outstanding, beginning of fiscal year | — |  |  | $ | — |  |
| Granted | 3,205,806 |  |  | 3.28 |  |
| Exercised | (237,380 | ) |  | 0.99 |  |
| Forfeited | (226,572 | ) |  | 3.75 |  |
| Outstanding, end of fiscal year | 2,741,854 |  |  | $ | 3.44 |  |
| Options exercisable, end of fiscal year | 223,869 |  |  | $ | 4.95 |  |

[0001628280-16-016576:notes:271]
Of the 3.2 million unvested share-based awards granted under the NEXTracker Plan in fiscal year 2016, approximately 0.5 million of unvested share-based awards have an average grant date price of $7.76 per share and represents the number of grants made to certain NEXTracker employees whereby the right to exercise is contingent on meeting certain performance targets over a three-year period commencing October 1, 2015.

[0001628280-16-016576:notes:272]
The aggregate intrinsic value of options exercised under the NEXTracker plan (calculated as the difference between the exercise price of the underlying award and the price of the Company's ordinary shares determined as of the time of option exercise for options exercised in-the-money) was $2.32 million as of March 31, 2016.

[0001628280-16-016576:notes:273]
Cash received from option exercises under the NEXTracker Plan was $0.2 million for fiscal year 2016.

[0001628280-16-016576:notes:274]
The following table presents the composition of options outstanding and exercisable under the NEXTracker Plan as of March 31, 2016:

[0001628280-16-016576:notes:275]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofSharesOutstanding |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |  | Number ofSharesExercisable |  | WeightedAverageRemainingContractualLife(In Years) |  | WeightedAverageExercisePrice |
| $0.08 - $5.24 |  | 2,088,258 |  |  | 9.49 |  | $ | 1.19 |  |  | 129,376 |  |  | 9.49 |  | $ | 0.79 |  |
| $5.25 - $10.65 |  | 653,596 |  |  | 9.49 |  | 10.65 |  |  | 94,493 |  |  | 9.49 |  | 10.65 |  |
| $0.08 - $10.65 |  | 2,741,854 |  |  | 9.49 |  | $ | 3.44 |  |  | 223,869 |  |  | 9.49 |  | $ | 4.95 |  |
| Options vested and expected to vest |  | 2,741,854 |  |  | 9.49 |  | $ | 3.44 |  |  |  |  |  |  |  |  |  |

[0001628280-16-016576:notes:276]
As of March 31, 2016 the aggregate intrinsic value, for options outstanding, options vested and expected to vest (which includes adjustments for expected forfeitures), and options exercisable under the Company's NEXTracker Plan, were $23.6 million, $23.6 million, and $1.59 million, respectively. The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares as of March 31, 2016 for the approximately 2.7 million options under the NEXTracker Plan that were in-the-money at March 31, 2016.

[0001628280-16-016576:notes:277]
The following table summarizes the Company's share bonus award activity under the NEXTracker Plan ("Price" reflects the weighted-average grant-date fair value):

[0001628280-16-016576:notes:278]
|  | Fiscal Year Ended March 31, |
|  | 2016 |
|  | Shares |  | Price |
| Unvested share bonus awards outstanding, beginning of fiscal year | — |  |  | $ | — |  |
| Granted | 2,393,195 |  |  | 10.27 |  |
| Vested | (31,925 | ) |  | 10.27 |  |
| Forfeited | (52,174 | ) |  | 10.27 |  |
| Unvested share bonus awards outstanding, end of fiscal year | 2,309,096 |  |  | $ | 10.27 |  |

[0001628280-16-016576:notes:279]
Of the 2.4 million unvested share bonus awards granted under the NEXTracker Plan as of the fiscal year ended 2016, approximately 0.9 million of unvested shares bonus awards represents the target amount of grants made to certain NEXTracker employees whereby vesting is contingent on meeting certain performance targets over a three-year period commencing October 1, 2015.

[0001628280-16-016576:notes:280]
The total intrinsic value of share bonus awards vested under the Company's NEXTracker Plan was $0.35 million during fiscal year 2016, based on the closing price of the Company's ordinary shares on the date vested.

[0001628280-16-016576:notes:281]
The 2013 Equity Incentive Plan of Elementum SCM (Cayman) Ltd.

[0001628280-16-016576:notes:282]
As of March 31, 2016 Elementum had approximately 5.4 million shares available for future grants under the 2013 Elementum Plan. Options to purchase shares in Elementum issued to employees under the Elementum Plan have a vesting period of two to four years and expire ten years from the grant date. As of March 31, 2016 there were 26.2 million of options outstanding at a weighted average exercise price of $0.35 per option. Cash received from option exercises under the Elementum Plan was $0.5 million for fiscal year 2016. Total unrecognized compensation expenses relating to stock options granted to certain employees under the Elementum Plan as of March 31, 2016 is $5.2 million, and will be recognized over a weighted average period of 2.7 years.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-016576:notes:283]
EARNINGS PER SHARE

[0001628280-16-016576:notes:284]
Basic earnings per share excludes dilution and are computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0001628280-16-016576:notes:285]
Diluted earnings per share reflects the potential dilution from stock options and share bonus awards. The potential dilution from stock options exercisable into ordinary share equivalents and share bonus awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0001628280-16-016576:notes:286]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0001628280-16-016576:notes:287]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands, exceptper share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 444,081 |  |  | $ | 600,801 |  |  | $ | 365,594 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 557,667 |  |  | 579,981 |  |  | 610,497 |  |
| Basic earnings per share | $ | 0.80 |  |  | $ | 1.04 |  |  | $ | 0.60 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 444,081 |  |  | $ | 600,801 |  |  | $ | 365,594 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 557,667 |  |  | 579,981 |  |  | 610,497 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) | 7,202 |  |  | 11,575 |  |  | 12,982 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 564,869 |  |  | 591,556 |  |  | 623,479 |  |
| Diluted earnings per share | $ | 0.79 |  |  | $ | 1.02 |  |  | $ | 0.59 |  |

[0001628280-16-016576:notes:288]
_________________________________________________________________________

[0001628280-16-016576:notes:289]
| (1) | Options to purchase ordinary shares of 2.0 million, 6.2 million and 17.1 million during fiscal years 2016, 2015 and 2014, respectively, and share bonus awards of less than 0.1 million during fiscal year 2015, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents. There were no anti-dilutive share bonus awards in fiscal year 2016 and 2014. |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0001628280-16-016576:notes:290]
The Company has certain long-lived assets that are measured at fair value on a nonrecurring basis, and are as follows:

[0001628280-16-016576:notes:291]
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Assets held for sale | $ | — |  |  | $ | 5,576 |  |  | $ | — |  |  | $ | 5,576 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-016576:notes:292]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES

[0001628280-16-016576:notes:293]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0001628280-16-016576:notes:294]
Level 1—Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0001628280-16-016576:notes:295]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other noncurrent assets on the consolidated balance sheets and include investments in equity securities that are valued using active market prices.

[0001628280-16-016576:notes:296]
Level 2—Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model- derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0001628280-16-016576:notes:297]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0001628280-16-016576:notes:298]
The Company's cash equivalents are comprised of bank deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0001628280-16-016576:notes:299]
The Company's deferred compensation plan assets also include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0001628280-16-016576:notes:300]
Level 3—Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0001628280-16-016576:notes:301]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs.

[0001628280-16-016576:notes:302]
The Company accrued $84.3 million of contingent consideration, of which $81.0 million related to the acquisition of NEXTracker on the date of acquisition. Additionally, an incremental fair value adjustment of $3.7 million also related to NEXTracker, was recorded in the consolidated statement of operations during fiscal year 2016. The Company reduced the accrual by $19.0 million for a contractual release from the obligation executed subsequent to the acquisition. The fair value of the liability was estimated using a simulation-based measurement technique with significant inputs that are not observable in the market and thus represents a level 3 fair value measurement. The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the Merger Agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0001628280-16-016576:notes:303]
During fiscal year 2015, the Company paid $11.3 million of contingent consideration related to the acquisition of Saturn Electronics and Engineering Inc. The following table summarizes the activities related to contingent consideration:

[0001628280-16-016576:notes:304]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Beginning balance | $ | 4,500 |  |  | $ | 11,300 |  |
| Additions to accrual | 84,261 |  |  | 4,500 |  |
| Payments and settlements | (19,008 | ) |  | (11,300 | ) |
| Fair value adjustments | 3,670 |  |  | — |  |
| Ending balance | $ | 73,423 |  |  | $ | 4,500 |  |

[0001628280-16-016576:notes:305]
The Company values deferred purchase price receivables relating to its Asset-Backed Securitization Program based on a discounted cash flow analysis using unobservable inputs (i.e. level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, their fair value approximates carrying value. Significant increases in either of the significant unobservable inputs (credit spread or risk free interest rate) in isolation would result in lower fair value estimates, however the impact is insignificant. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable.

[0001628280-16-016576:notes:306]
There were no transfers between levels in the fair value hierarchy during fiscal years 2016 and 2015.

[0001628280-16-016576:notes:307]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0001628280-16-016576:notes:308]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2016 and 2015:

[0001628280-16-016576:notes:309]
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,074,132 |  |  | $ | — |  |  | $ | 1,074,132 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 501,097 |  |  | 501,097 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 22,648 |  |  | — |  |  | 22,648 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 9,228 |  |  | 40,556 |  |  | — |  |  | 49,784 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (21,091 | ) |  | $ | — |  |  | $ | (21,091 | ) |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (73,423 | ) |  | (73,423 | ) |

[0001628280-16-016576:notes:310]
|  | Fair Value Measurements as of March 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 674,859 |  |  | $ | — |  |  | $ | 674,859 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 600,672 |  |  | 600,672 |  |
| Foreign exchange forward contracts (Note 8) | — |  |  | 25,829 |  |  | — |  |  | 25,829 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | 9,068 |  |  | 37,041 |  |  | — |  |  | 46,109 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts (Note 8) | $ | — |  |  | $ | (31,057 | ) |  | $ | — |  |  | $ | (31,057 | ) |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |

[0001628280-16-016576:notes:311]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001628280-16-016576:notes:312]
Assets held for sale

[0001628280-16-016576:notes:313]
Assets held for sale are recorded at the lesser of the carrying value or fair value, which is based on comparable sales from prevailing market data (level 2 inputs). During fiscal year 2016, the Company transferred $5.6 million of assets to assets held for sale, relating to a building and land which has been identified to be sold.

[0001628280-16-016576:notes:314]
Disposals of assets held for sale totaled $0.3 million and $41.5 million during fiscal year 2016 and 2015, respectively, which resulted in an immaterial loss in fiscal year 2016, and a gain of $12.1 million in fiscal year 2015 that was included as a component of cost of sales in the consolidated statement of operations. No impairment charges were recorded for assets held for sale during fiscal years 2016 and 2015. Assets held for sale as of the fiscal years 2016 and 2015 were not significant.

[0001628280-16-016576:notes:315]
There were no material fair value adjustments or other transfers between levels in the fair value hierarchy for these long-lived assets during the fiscal years 2016 and 2015.

[0001628280-16-016576:notes:316]
Other financial instruments

[0001628280-16-016576:notes:317]
The following table presents the Company's liabilities not carried at fair value as at March 31, 2016 and 2015:

[0001628280-16-016576:notes:318]
|  | As of March 31, 2016 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In thousands) |  | (In thousands) |  |  |
| Term Loan, including current portion, due in installments through August 2018 | $ | 577,500 |  |  | $ | 573,533 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 547,500 |  |  | 542,709 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 524,735 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 507,500 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,589 |  |  | 604,926 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |

[0001628280-16-016576:notes:319]
The term loans and Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.

[0001628280-16-016576:notes:320]
The Company values its €50 million (approximately $56.6 million as of March 31, 2016), 5-year, unsecured, term-loan due September 30, 2020 based on the current market rate, and as of March 31, 2016, the carrying amount approximates fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-016576:notes:321]
INCOME TAXES

[0001628280-16-016576:notes:322]
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0001628280-16-016576:notes:323]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Domestic | $ | 199,283 |  |  | $ | 67,482 |  |  | $ | 314,639 |  |
| Foreign | 255,392 |  |  | 603,173 |  |  | 85,815 |  |
| Total | $ | 454,675 |  |  | $ | 670,655 |  |  | $ | 400,454 |  |

[0001628280-16-016576:notes:324]
The provision for income taxes consisted of the following:

[0001628280-16-016576:notes:325]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Domestic | $ | 56 |  |  | $ | 87 |  |  | $ | (681 | ) |
| Foreign | 74,706 |  |  | 129,863 |  |  | 73,992 |  |
|  | 74,762 |  |  | 129,950 |  |  | 73,311 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 3,779 |  |  | (4,734 | ) |  | 9 |  |
| Foreign | (67,947 | ) |  | (55,362 | ) |  | (38,460 | ) |
|  | (64,168 | ) |  | (60,096 | ) |  | (38,451 | ) |
| Provision for income taxes | $ | 10,594 |  |  | $ | 69,854 |  |  | $ | 34,860 |  |

[0001628280-16-016576:notes:326]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2016, 2015 and 2014. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0001628280-16-016576:notes:327]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Income taxes based on domestic statutory rates | $ | 77,295 |  |  | $ | 114,011 |  |  | $ | 68,077 |  |
| Effect of tax rate differential | (73,286 | ) |  | (80,842 | ) |  | (68,654 | ) |
| Intangible amortization | 11,214 |  |  | 5,143 |  |  | 4,750 |  |
| Change in liability for uncertain tax positions | (13,724 | ) |  | 29,729 |  |  | (2,178 | ) |
| Change in valuation allowance | 1,049 |  |  | 2,495 |  |  | 26,838 |  |
| Other | 8,046 |  |  | (682 | ) |  | 6,027 |  |
| Provision for income taxes | $ | 10,594 |  |  | $ | 69,854 |  |  | $ | 34,860 |  |

[0001628280-16-016576:notes:328]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2016, 2015 and 2014 was $6.6 million, $9.8 million and $15.2 million, respectively. For fiscal year ended March 31, 2016, the effect on basic and diluted earnings per share was $0.01 and $0.01, respectively, and the effect on basic and diluted earnings per share during fiscal years 2015 and 2014, were $0.02 and $0.02 and $0.02 and $0.02, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in the fiscal year ending March 31, 2017 through fiscal year 2022.

[0001628280-16-016576:notes:329]
For fiscal years ended March 31, 2016, 2015 and 2014, the Company released valuation allowances totaling $63.3 million, $55.0 million and $37.4 million, respectively.  These valuation allowance releases were primarily related to our operations that were deemed to be more likely than not to realize the respective deferred tax assets due to the increased profitability during the prior three fiscal years as well as continued forecasted profitability of that subsidiary. During fiscal year ended March 31, 2016, $43.0 million of the valuation allowance release was related to the recording of deferred tax liabilities in the US related to intangibles acquired during fiscal year 2016. However, these valuation allowance eliminations were offset by other current period valuation allowance movements primarily related to current period valuation allowance additions due to increased deferred tax assets related to current period losses in legal entities with existing full valuation allowance positions, and to a lesser extent, current period changes in valuation allowance positions due to increased negative evidence during the period in legal entities which did not previously have valuation allowance recorded. For fiscal years ended March 31, 2016, 2015 and 2014, the offsetting amounts totaled $64.3 million, $57.5 million and $64.2 million, respectively.

[0001628280-16-016576:notes:330]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years 2016, 2015 and 2014 were $36.6 million, $0.0 million and $51.5 million, respectively.

[0001628280-16-016576:notes:331]
The components of deferred income taxes are as follows:

[0001628280-16-016576:notes:332]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (74,316 | ) |  | $ | (73,327 | ) |
| Intangible assets | (88,760 | ) |  | — |  |
| Others | (29,472 | ) |  | (44,603 | ) |
| Total deferred tax liabilities | (192,548 | ) |  | (117,930 | ) |
| Deferred tax assets: |  |  |  |
| Fixed assets | 65,004 |  |  | 80,370 |  |
| Intangible assets | 3,795 |  |  | 28,954 |  |
| Deferred compensation | 15,892 |  |  | 13,618 |  |
| Inventory valuation | 10,124 |  |  | 11,864 |  |
| Provision for doubtful accounts | 1,300 |  |  | 3,149 |  |
| Net operating loss and other carryforwards | 2,332,894 |  |  | 2,394,456 |  |
| Others | 271,272 |  |  | 264,781 |  |
|  | 2,700,281 |  |  | 2,797,192 |  |
| Valuation allowances | (2,385,489 | ) |  | (2,521,763 | ) |
| Net deferred tax assets | 314,792 |  |  | 275,429 |  |
| Net deferred tax asset | $ | 122,244 |  |  | $ | 157,499 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Current asset (classified as other current assets) | $ | — |  |  | $ | 63,910 |  |
| Long-term asset | 222,772 |  |  | 211,519 |  |
| Long-term liability | (100,528 | ) |  | (117,930 | ) |
| Total | $ | 122,244 |  |  | $ | 157,499 |  |

[0001628280-16-016576:notes:333]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision. Approximately $34.0 million of the valuation allowance relates to income tax benefits arising from the exercise of stock options, which if realized will be credited directly to shareholders’ equity and will not be available to benefit the income tax provision in any future period.

[0001628280-16-016576:notes:334]
The Company has recorded deferred tax assets of approximately $2.4 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $79.3 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0001628280-16-016576:notes:335]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0001628280-16-016576:notes:336]
The Company does not provide for income taxes on approximately $916.0 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. Determination of the amount of the unrecognized deferred tax liability on these undistributed earnings is not practicable. During the fiscal year 2015, we changed our intent with regard to the indefinite reinvestment of foreign earnings from certain of our Chinese subsidiaries which are scheduled to be de-registrated or liquidated in the near future. As a result, as of March 31, 2016, we have provided for applicable foreign withholding taxes on $106.7 million of undistributed foreign earnings, and recorded a deferred tax liability of approximately $11.2 million.

[0001628280-16-016576:notes:337]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0001628280-16-016576:notes:338]
|  | Fiscal Year EndedMarch 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Balance, beginning of fiscal year | $ | 222,373 |  |  | $ | 243,864 |  |
| Additions based on tax position related to the current year | 21,273 |  |  | 27,048 |  |
| Additions for tax positions of prior years | 20,453 |  |  | 24,354 |  |
| Reductions for tax positions of prior years | (9,578 | ) |  | (16,388 | ) |
| Reductions related to lapse of applicable statute of limitations | (22,312 | ) |  | (11,891 | ) |
| Settlements | (12,797 | ) |  | (24,049 | ) |
| Impact from foreign exchange rates fluctuation | (7,086 | ) |  | (20,565 | ) |
| Balance, end of fiscal year | $ | 212,326 |  |  | $ | 222,373 |  |

[0001628280-16-016576:notes:339]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an estimated range of an additional $13.0 million to $41.0 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0001628280-16-016576:notes:340]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2006.

[0001628280-16-016576:notes:341]
Of the $212.3 million of unrecognized tax benefits at March 31, 2016, $185.7 million will affect the annual effective tax rate ("ETR") if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0001628280-16-016576:notes:342]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company's tax expense. During the fiscal years ended March 31, 2016, 2015 and 2014, the Company recognized interest and penalties of approximately ($2.4) million and $2.5 million and $8.4 million, respectively. The Company had approximately $14.6 million, $17.0 million and $15.6 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2016, 2015 and 2014, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001628280-16-016576:notes:343]
NONCONTROLLING INTERESTS

[0001628280-16-016576:notes:344]
During fiscal year 2014, a previously wholly-owned subsidiary of the Company received $38.6 million in exchange for issuing a noncontrolling equity interest to certain third party investors for an ownership interest of less than 20% of the outstanding shares in the subsidiary. The Company continues to own a majority of the subsidiary's outstanding equity and also controls the subsidiary's board of directors. Accordingly, the consolidated financial statements include the financial position and results of operations of this subsidiary as of March 31, 2016 and for the year then ended.

[0001628280-16-016576:notes:345]
The Company has recognized the carrying value of the noncontrolling interest as a component of total shareholders' equity. The operating results of the subsidiary attributable to the noncontrolling interest were losses of $6.7 million, $4.3 million, and $0.4 million for fiscal years 2016, 2015 and 2014, respectively, which were classified as a component of interest and other, net, in the Company's consolidated statements of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-16-016576:notes:346]
ORGANIZATION OF THE COMPANY

[0001628280-16-016576:notes:347]
Flextronics International Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computer ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), which was formerly referred to as Integrated Network Solutions (“INS”), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-16-016576:notes:348]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-16-016576:notes:349]
OTHER CHARGES (INCOME), NET

[0001628280-16-016576:notes:350]
During fiscal year 2016, the Company incurred net losses of $47.7 million primarily due to $26.8 million loss on disposition of a non-strategic Western European manufacturing facility which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by currency translation gains of $4.2 million.

[0001628280-16-016576:notes:351]
During fiscal year 2015, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed this charge with a corresponding credit to other charges (income), net in the consolidated statement of operations. Additionally, during fiscal year 2015, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of estimated transaction costs, partially offset by a gain of $9.3 million for the release of cumulative foreign currency translation gains triggered by the disposition.

[0001628280-16-016576:notes:352]
During fiscal year 2014, the Company recognized $55.0 million of other charges for the contractual obligation to reimburse a customer for certain performance provisions as described above. Additionally, the Company exercised warrants to purchase common shares of a certain supplier and sold the underlying shares for total proceeds of $67.3 million resulting in a loss of $7.1 million. Further, the Company recognized a gain of $4.6 million on the sale of certain investments.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-16-016576:notes:353]
QUARTERLY FINANCIAL DATA (UNAUDITED)

[0001628280-16-016576:notes:354]
The following table contains unaudited quarterly financial data for fiscal years 2016 and 2015.

[0001628280-16-016576:notes:355]
|  | Fiscal Year Ended March 31, 2016 |  | Fiscal Year Ended March 31, 2015 |
|  | First |  | Second |  | Third |  | Fourth |  | First |  | Second |  | Third |  | Fourth |
| Net sales | $ | 5,566,248 |  |  | $ | 6,316,762 |  |  | $ | 6,763,177 |  |  | $ | 5,772,698 |  |  | $ | 6,642,745 |  |  | $ | 6,528,517 |  |  | $ | 7,025,054 |  |  | $ | 5,951,600 |  |
| Gross profit | 352,341 |  |  | 396,916 |  |  | 452,467 |  |  | 406,337 |  |  | 380,785 |  |  | 377,081 |  |  | 408,657 |  |  | 378,817 |  |
| Net income | 110,850 |  |  | 122,977 |  |  | 148,910 |  |  | 61,344 |  |  | 173,887 |  |  | 138,903 |  |  | 152,899 |  |  | 135,112 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.20 |  |  | $ | 0.22 |  |  | $ | 0.27 |  |  | $ | 0.11 |  |  | $ | 0.30 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.19 |  |  | $ | 0.22 |  |  | $ | 0.27 |  |  | $ | 0.11 |  |  | $ | 0.29 |  |  | $ | 0.23 |  |  | $ | 0.26 |  |  | $ | 0.23 |  |

[0001628280-16-016576:notes:356]
| (1) | Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-16-016576:notes:357]
RESTRUCTURING CHARGES

[0001628280-16-016576:notes:358]
The Company initiated certain restructuring activities during fiscal year 2014 intended to improve its operational efficiencies by reducing excess workforce and capacity and realign the corporate cost structure. There were no material restructuring activities during fiscal years 2016 and 2015. Restructuring charges are recorded based upon employee termination dates, site closure and consolidation plans generally in conjunction with an overall corporate initiative to drive cost reduction and realign the Company's global footprint.

[0001628280-16-016576:notes:359]
Fiscal Year 2014

[0001628280-16-016576:notes:360]
During the fiscal year ended March 31, 2014, the Company recognized restructuring charges of approximately $75.3 million. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations. Pre-tax restructuring charges comprised $73.4 million of cash charges predominantly related to employee severance and $1.9 million of non-cash charges related to impairment of long-lived assets. Employee severance costs were associated with the terminations of 6,758 identified employees. The identified employee terminations by reportable geographic region amounted to approximately 5,073, 1,482 and 203 for Asia, the Americas and Europe, respectively.

[0001628280-16-016576:notes:361]
The components of the restructuring charges by geographic region incurred in fiscal year 2014 are as follows:

[0001628280-16-016576:notes:362]
|  | FirstQuarter |  | FourthQuarter |  | Total |
|  | (In thousands) |
| Americas: |  |  |  |  |  |
| Severance | $ | 11,331 |  |  | $ | 11,290 |  |  | $ | 22,621 |  |
| Other exit costs | 2,248 |  |  | — |  |  | 2,248 |  |
| Total restructuring charges | 13,579 |  |  | 11,290 |  |  | 24,869 |  |
| Asia: |  |  |  |  |  |
| Severance | 16,205 |  |  | 13,214 |  |  | 29,419 |  |
| Long-lived asset impairment | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs | 3,157 |  |  | — |  |  | 3,157 |  |
| Total restructuring charges | 21,262 |  |  | 13,214 |  |  | 34,476 |  |
| Europe: |  |  |  |  |  |
| Severance | 4,631 |  |  | 10,047 |  |  | 14,678 |  |
| Other exit costs | 1,288 |  |  | — |  |  | 1,288 |  |
| Total restructuring charges | 5,919 |  |  | 10,047 |  |  | 15,966 |  |
| Total |  |  |  |  |  |
| Severance | 32,167 |  |  | 34,551 |  |  | 66,718 |  |
| Long-lived asset impairment | 1,900 |  |  | — |  |  | 1,900 |  |
| Other exit costs | 6,693 |  |  | — |  |  | 6,693 |  |
| Total restructuring charges | $ | 40,760 |  |  | $ | 34,551 |  |  | $ | 75,311 |  |

[0001628280-16-016576:notes:363]
During the fiscal year ended March 31, 2014, the Company recognized approximately $66.7 million of severance costs related to employee terminations of which approximately $50.2 million was recognized in cost of sales.

[0001628280-16-016576:notes:364]
During the fiscal year ended March 31, 2014, the Company recognized approximately $1.9 million for the write-down of property and equipment, and was classified as a component of cost of sales. The property and equipment were sold as of March 31, 2014.

[0001628280-16-016576:notes:365]
During the fiscal year ended March 31, 2014, the Company recognized approximately $6.7 million of other exit costs, which primarily were comprised of $3.8 million related to personnel costs and $2.9 million of contractual obligations that resulted from facility closures. The majority of these costs were classified as a component of cost of sales.

[0001628280-16-016576:notes:366]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of March 31, 2016 for charges incurred in fiscal years 2016, 2015 and 2014 and prior periods:

[0001628280-16-016576:notes:367]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2013 | $ | 83,689 |  |  | $ | — |  |  | $ | 14,211 |  |  | $ | 97,900 |  |
| Provision for charges incurred in fiscal year 2014 | 66,718 |  |  | 1,900 |  |  | 6,693 |  |  | 75,311 |  |
| Cash payments for charges incurred in fiscal year 2014 | (40,273 | ) |  | — |  |  | (4,296 | ) |  | (44,569 | ) |
| Cash payments for charges incurred in fiscal year 2013 | (71,470 | ) |  | — |  |  | (8,755 | ) |  | (80,225 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior | (2,171 | ) |  | — |  |  | (1,950 | ) |  | (4,121 | ) |
| Non-cash charges incurred in fiscal year 2014 | — |  |  | (1,900 | ) |  | — |  |  | (1,900 | ) |
| Balance as of March 31, 2014 | 36,493 |  |  | — |  |  | 5,903 |  |  | 42,396 |  |
| Cash payments for charges incurred in fiscal year 2014 | (18,558 | ) |  | — |  |  | (2,212 | ) |  | (20,770 | ) |
| Cash payments for charges incurred in fiscal year 2013 | (4,560 | ) |  | — |  |  | (1,685 | ) |  | (6,245 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior | (12 | ) |  | — |  |  | (312 | ) |  | (324 | ) |
| Balance as of March 31, 2015 | 13,363 |  |  | — |  |  | 1,694 |  |  | 15,057 |  |
| Cash payments for charges incurred in fiscal year 2014 | (290 | ) |  | — |  |  | — |  |  | (290 | ) |
| Cash payments for charges incurred in fiscal year 2013 | (1,168 | ) |  | — |  |  | (185 | ) |  | (1,353 | ) |
| Cash payments for charges incurred in fiscal year 2010 and prior | — |  |  | — |  |  | (174 | ) |  | (174 | ) |
| Balance as of March 31, 2016 | 11,905 |  |  | — |  |  | 1,335 |  |  | 13,240 |  |
| Less: Current portion (classified as other current liabilities) | 2,212 |  |  | — |  |  | 248 |  |  | 2,460 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | 9,693 |  |  | $ | — |  |  | $ | 1,087 |  |  | $ | 10,780 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001628280-16-016576:notes:368]
|  | As of March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Asia | $ | 1,013,317 |  |  | 45 | % |  | $ | 997,806 |  |  | 48 | % |
| Americas | 886,305 |  |  | 39 | % |  | 782,839 |  |  | 37 | % |
| Europe | 358,011 |  |  | 16 | % |  | 311,522 |  |  | 15 | % |
|  | $ | 2,257,633 |  |  |  |  | $ | 2,092,167 |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-016576:notes:369]
Geographic information is as follows:

[0001628280-16-016576:notes:370]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 11,788,992 |  |  | 48 | % |  | $ | 12,953,004 |  |  | 50 | % |  | $ | 13,714,187 |  |  | 53 | % |
| Americas | 8,347,514 |  |  | 34 | % |  | 8,897,868 |  |  | 34 | % |  | 8,189,414 |  |  | 31 | % |
| Europe | 4,282,379 |  |  | 18 | % |  | 4,297,044 |  |  | 16 | % |  | 4,205,006 |  |  | 16 | % |
|  | $ | 24,418,885 |  |  |  |  | $ | 26,147,916 |  |  |  |  | $ | 26,108,607 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-016576:notes:371]
Selected financial information by segment is as follows:

[0001628280-16-016576:notes:372]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 8,841,642 |  |  | $ | 9,191,211 |  |  | $ | 9,688,023 |  |
| Consumer Technologies Group | 6,997,526 |  |  | 8,940,043 |  |  | 9,357,635 |  |
| Industrial & Emerging Industries | 4,680,718 |  |  | 4,459,351 |  |  | 3,787,838 |  |
| High Reliability Solutions | 3,898,999 |  |  | 3,557,311 |  |  | 3,275,111 |  |
|  | $ | 24,418,885 |  |  | $ | 26,147,916 |  |  | $ | 26,108,607 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 265,076 |  |  | $ | 257,323 |  |  | $ | 259,329 |  |
| Consumer Technologies Group | 163,677 |  |  | 218,251 |  |  | 125,171 |  |
| Industrial & Emerging Industries | 157,588 |  |  | 131,956 |  |  | 127,085 |  |
| High Reliability Solutions | 294,635 |  |  | 227,595 |  |  | 221,402 |  |
| Corporate and Other | (89,219 | ) |  | (83,988 | ) |  | (68,475 | ) |
| Total income | 791,757 |  |  | 751,137 |  |  | 664,512 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 65,965 |  |  | 32,035 |  |  | 28,892 |  |
| Stock-based compensation | 77,580 |  |  | 50,270 |  |  | 40,439 |  |
| Restructuring charges (2) | — |  |  | — |  |  | 75,311 |  |
| Bad debt charge (1) | 61,006 |  |  | — |  |  | — |  |
| Other charges (income), net | 47,738 |  |  | (53,233 | ) |  | 57,512 |  |
| Interest and other, net | 84,793 |  |  | 51,410 |  |  | 61,904 |  |
| Income before income taxes | $ | 454,675 |  |  | $ | 670,655 |  |  | $ | 400,454 |  |

[0001628280-16-016576:notes:373]
| (1) | During fiscal year 2016, the Company incurred a charge of $61.0 million related to SunEdison which had declared bankruptcy. This charge is included in selling, general and administrative expenses in the consolidated statement of operations but is excluded from the measurement of the Company's operating segment's performance. Refer to note 2 for additional information regarding this charge. |

[0001628280-16-016576:notes:374]
| (2) | During the fiscal year ended March 31, 2014, the Company recognized restructuring charges of approximately $75.3 million. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations. Refer to note 14 for additional information regarding this charge. |

[0001628280-16-016576:notes:375]
During fiscal year 2016, 2015 and 2014, depreciation expense included in the segment's measure of operating performance above is as follows:

[0001628280-16-016576:notes:376]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Depreciation expense |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 117,710 |  |  | $ | 130,311 |  |  | $ | 131,807 |  |
| Consumer Technologies Group | 123,139 |  |  | 203,808 |  |  | 160,684 |  |
| Industrial & Emerging Industries | 72,415 |  |  | 64,541 |  |  | 55,692 |  |
| High Reliability Solutions | 80,935 |  |  | 62,831 |  |  | 50,296 |  |
| Corporate and Other | 31,530 |  |  | 35,334 |  |  | 26,359 |  |
| Total depreciation expense | $ | 425,729 |  |  | $ | 496,825 |  |  | $ | 424,838 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-016576:notes:377]
SEGMENT REPORTING

[0001628280-16-016576:notes:378]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the Chief Operating Decision Maker ("CODM"), or a decision making group, in deciding how to allocate resources and in assessing performance. Resource allocation decisions and the Company's performance are assessed by its Chief Executive Officer ("CEO"), with support from his direct staff who oversee certain operations of the business, collectively identified as the CODM or the decision making group.

[0001628280-16-016576:notes:379]
During the fourth quarter of fiscal year 2015, the Company concluded it has four reportable operating segments: HRS, CTG, IEI, and CEC. The Company assessed that there was no change to its operating segments in fiscal year 2016. These segments represent components of the Company for which separate financial information is available that is utilized on a regular basis by the CODM. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 to the financial statements for a description of the various product categories manufactured under each of these segments.

[0001628280-16-016576:notes:380]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, restructuring charges, certain bad debt charges, other charges (income), net and interest and other, net.

[0001628280-16-016576:notes:381]
Corporate and other primarily includes corporate services costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0001628280-16-016576:notes:382]
Property and equipment on a segment basis is not disclosed as it is not separately identified and is not internally reported by segment to the Company's CODM. During fiscal year 2016, 2015 and 2014, depreciation expense included in the segment's measure of operating performance above is as follows:

[0001628280-16-016576:notes:383]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0001628280-16-016576:notes:384]
During fiscal years 2016, 2015 and 2014, net sales generated from Singapore, the principal country of domicile, were approximately $519.1 million, $553.4 million and $504.6 million, respectively.

[0001628280-16-016576:notes:385]
During fiscal year 2016, China, Mexico, and the United States accounted for approximately 35%, 15%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2016.

[0001628280-16-016576:notes:386]
During fiscal year 2015, China, Mexico, and the United States accounted for approximately 37%, 13%, and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2015.

[0001628280-16-016576:notes:387]
During fiscal year 2014, China, Mexico, and the United States accounted for approximately 40%, 14% and 11% of consolidated net sales, respectively. No other country accounted for more than 10% of net sales in fiscal year 2014.

[0001628280-16-016576:notes:388]
As of March 31, 2016 and 2015, property and equipment, net held in Singapore were approximately $13.4 million and $19.3 million, respectively.

[0001628280-16-016576:notes:389]
As of March 31, 2016, China, Mexico and the United States accounted for approximately 35%, 19% and 15%, respectively, of property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2016.

[0001628280-16-016576:notes:390]
As of March 31, 2015, China, Mexico and the United States accounted for approximately 37%, 17% and 15%, respectively, of consolidated property and equipment, net. No other country accounted for more than 10% of property and equipment, net as of March 31, 2015.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001628280-16-016576:notes:391]
TRADE RECEIVABLES SECURITIZATION

[0001628280-16-016576:notes:392]
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0001628280-16-016576:notes:393]
Asset-Backed Securitization Programs

[0001628280-16-016576:notes:394]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the "Global Program") and its North American Asset-Backed Securitization Agreement (the "North American Program," collectively, the "ABS Programs") to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $700.0 million for the Global Program, of which $600.0 million is committed and $100.0 million is uncommitted, and $265.0 million for the North American Program, of which $225.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001628280-16-016576:notes:395]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the fiscal years ended March 31, 2016, 2015 and 2014 were not material and are included in interest and other, net within the consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0001628280-16-016576:notes:396]
As of March 31, 2016 and 2015, the accounts receivable balances that were sold under the ABS Programs were removed from the consolidated balance sheets and the net cash proceeds received by the Company during fiscal years ended March 31, 2016, 2015 and 2014 were included as cash provided by operating activities in the consolidated statements of cash flows.

[0001628280-16-016576:notes:397]
As of March 31, 2016, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of $880.8 million and deferred purchase price receivables of $501.1 million. As of March 31, 2015, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $740.7 million and deferred purchase price receivables of $600.7 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of March 31, 2016 and 2015, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the consolidated statements of operations; such amounts were $9.2 million for the fiscal year ended March 31, 2016, and $7.1 million for both fiscal years ended March 31, 2015 and 2014.

[0001628280-16-016576:notes:398]
For the fiscal years ended March 31, 2016, 2015 and 2014, cash flows from sales of receivables under the ABS Programs consisted of approximately $5.2 billion, $4.3 billion and $4.2 billion, respectively, for transfers of receivables (of which approximately $0.4 billion, $0.3 billion and $0.4 billion, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving period transfers).

[0001628280-16-016576:notes:399]
Trade Accounts Receivable Sale Programs

[0001628280-16-016576:notes:400]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $339.4 million and $485.6 million as of March 31, 2016 and 2015, respectively. For the years ended March 31, 2016, 2015 and 2014, total accounts receivables sold to certain third party banking institutions was approximately $2.3 billion, $4.2 billion and $3.4 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and were reflected as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001628280-16-016576:notes:401]
SHARE REPURCHASE PLAN

[0001628280-16-016576:notes:402]
During fiscal year 2016, the Company repurchased approximately 37.3 million shares for an aggregate purchase value of approximately $412.8 million under two separate repurchase plans as further discussed below.

[0001628280-16-016576:notes:403]
During the second quarter of fiscal year 2016, the Company repurchased the entire remaining amount under a prior share repurchase plan that was approved by the Company's Board of Directors on August 28, 2014 and the Company's shareholders at the 2014 Extraordinary General Meeting held on August 28, 2014, or approximately 13.2 million shares for an aggregate purchase value of approximately $154.9 million, and retired all of these shares.

[0001628280-16-016576:notes:404]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 20, 2015. During fiscal year 2016, the Company repurchased approximately 24.1 million shares for an aggregate purchase value of approximately $257.9 million under this plan, including amounts accrued but not paid, and retired all of these shares. As of March 31, 2016, shares in the aggregate amount of $242.1 million were available to be repurchased under the current plan.
