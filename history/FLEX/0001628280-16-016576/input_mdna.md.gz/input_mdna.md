# FLEX MD&A — 0001628280-16-016576


## mdna

[0001628280-16-016576:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-16-016576:mdna:2]
OVERVIEW

[0001628280-16-016576:mdna:3]
We are a globally-recognized, leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through our activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of our medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electronics, connectivity, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which

[0001628280-16-016576:mdna:4]
includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computer ("PC"), tablets, and printers; in addition, our CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), formerly referred to as Integrated Network Solutions (“INS”), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions.

[0001628280-16-016576:mdna:5]
On July 23, 2015, we introduced our new brand and website to help us more efficiently manage our business opportunities and explain our new product and service offerings. We shortened our brand name from Flextronics to “Flex” to signify that our business continues to evolve past the boundaries and confines of electronics alone. Our new tag line, “Live Smarter” highlights our belief that all devices are becoming intelligent and that value will ultimately be created in the “intelligence of things” and the convergence of technologies and digitization of products across multiple industries and market segments.

[0001628280-16-016576:mdna:6]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our OEM customers. This enables our OEM customers to leverage our supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-16-016576:mdna:7]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solutions requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0001628280-16-016576:mdna:8]
We use a portfolio approach to manage our extensive service offerings. As our OEM customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0001628280-16-016576:mdna:9]
During the past few years, we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher margins such as reflected in our IEI and HRS businesses. During the last two fiscal years, we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. Some of these programs have started to yield better results, as demonstrated by our segment operating margin improvement while our sales decreased compared to the prior year. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0001628280-16-016576:mdna:10]
We believe that our business transformation has strategically positioned us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services, which remain strong.

[0001628280-16-016576:mdna:11]
We are one of the world's largest providers of global supply chain solutions, with revenues of $24.4 billion in fiscal year 2016. We have established an extensive network of manufacturing facilities in the world's major consumer electronics and industrial markets (Asia, the Americas, and Europe) in order to serve the growing outsourcing needs of both multinational and regional OEMs. We design, build, ship, and service consumer electronics and industrial products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. As of March 31, 2016, our total manufacturing capacity was approximately 26.0 million square feet. In fiscal year 2016, our net sales in Asia, the Americas and Europe represented approximately 48%, 34% and 18%, respectively, of our total net sales, based on the location of the manufacturing site. The following tables set forth net sales and net property and equipment, by country, based on the location of our manufacturing sites and the relative percentages:

[0001628280-16-016576:mdna:12]
|  | Fiscal Year Ended March 31, |
| Net sales: | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| China | $ | 8,471,036 |  |  | 35 | % |  | $ | 9,550,837 |  |  | 37 | % |  | $ | 10,521,169 |  |  | 40 | % |
| Mexico | 3,645,432 |  |  | 15 | % |  | 3,512,767 |  |  | 13 | % |  | 3,565,803 |  |  | 14 | % |
| U.S. | 2,767,641 |  |  | 11 | % |  | 2,876,359 |  |  | 11 | % |  | 2,829,807 |  |  | 11 | % |
| Malaysia | 2,241,645 |  |  | 9 | % |  | 2,300,579 |  |  | 9 | % |  | 2,142,437 |  |  | 8 | % |
| Brazil | 1,839,395 |  |  | 8 | % |  | 2,474,291 |  |  | 9 | % |  | 1,699,209 |  |  | 6 | % |
| Other | 5,453,736 |  |  | 22 | % |  | 5,433,083 |  |  | 21 | % |  | 5,350,182 |  |  | 21 | % |
|  | $ | 24,418,885 |  |  |  |  | $ | 26,147,916 |  |  |  |  |  | $ | 26,108,607 |  |  |  |  |

[0001628280-16-016576:mdna:13]
|  | Fiscal Year Ended March 31, |
| Property and equipment, net: | 2016 |  | 2015 |
|  | (In thousands) |
| China | $ | 789,571 |  |  | 35 | % |  | $ | 776,914 |  |  | 37 | % |
| Mexico | 429,989 |  |  | 19 | % |  | 364,435 |  |  | 17 | % |
| U.S. | 330,778 |  |  | 15 | % |  | 314,613 |  |  | 15 | % |
| Malaysia | 159,787 |  |  | 7 | % |  | 165,779 |  |  | 8 | % |
| Brazil | 121,949 |  |  | 5 | % |  | 103,496 |  |  | 5 | % |
| Other | 425,559 |  |  | 19 | % |  | 366,930 |  |  | 18 | % |
|  | $ | 2,257,633 |  |  |  |  | $ | 2,092,167 |  |  |  |

[0001628280-16-016576:mdna:14]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and industrial campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer electronics and industrial products for leading multinational and regional OEMs. Specifically, we have launched multiple product innovation centers ("PIC") focused exclusively on offering our customers the ability to simplify their global product development, manufacturing process, and after sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0001628280-16-016576:mdna:15]
Our operating results are affected by a number of factors, including the following:

[0001628280-16-016576:mdna:16]
| • | changes in the macro-economic environment and related changes in consumer demand; |

[0001628280-16-016576:mdna:17]
| • | the mix of the manufacturing services we are providing, the number and size of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0001628280-16-016576:mdna:18]
| • | the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance; |

[0001628280-16-016576:mdna:19]
| • | our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our OEM customers; |

[0001628280-16-016576:mdna:20]
| • | the effects on our business due to our customers' products having short product life cycles; |

[0001628280-16-016576:mdna:21]
| • | our customers' ability to cancel or delay orders or change production quantities; |

[0001628280-16-016576:mdna:22]
| • | our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0001628280-16-016576:mdna:23]
| • | our exposure to financially troubled customers; |

[0001628280-16-016576:mdna:24]
| • | integration of acquired businesses and facilities; |

[0001628280-16-016576:mdna:25]
| • | increased labor costs due to adverse labor conditions in the markets we operate; and |

[0001628280-16-016576:mdna:26]
32

[0001628280-16-016576:mdna:27]
| • | changes in tax legislation. |

[0001628280-16-016576:mdna:28]
We also are subject to other risks as outlined in Item 1A, "Risk Factors."

[0001628280-16-016576:mdna:29]
Net sales for fiscal year 2016 declined from the prior year, decreasing by 6.6% or $1.7 billion to $24.4 billion. The decrease was primarily due to a $1.9 billion decrease in our CTG segment as well as a $0.3 billion decrease in our CEC segment, partially offset by increases in our HRS segment by $0.3 billion and our IEI segment by $0.2 billion. Our fiscal year 2016 gross profit totaled $1.6 billion, representing an increase of $62.7 million, or 4.1%, which reflects a richer mix of business driven primarily from our HRS and IEI segments and improved operational execution while ramping new customers and programs during fiscal year 2016. Our net income totaled $444.1 million, representing a decrease of $156.7 million, or 26.1%, compared to fiscal year 2015. The decrease in net income during fiscal year 2016 is primarily due to an increase in stock-based compensation expense, incremental costs associated with our acquisitions of MCi and NEXTracker, and a bad debt expense charge related to the SunEdison bankruptcy announcement.

[0001628280-16-016576:mdna:30]
Cash provided by operations increased approximately $0.3 billion to $1.1 billion for the fiscal year 2016 compared with $0.8 billion for the fiscal year 2015 primarily due to favorable changes in operating assets and liabilities. Cash used in investing activities increased approximately $1.2 billion to $1.4 billion for fiscal year 2016 compared with $0.2 billion for fiscal year 2015 primarily from $916.5 million paid for the acquisition of eleven businesses completed during fiscal year 2016. Our average net working capital, defined as accounts receivable, including deferred purchase price receivable from our asset-backed securitization programs plus inventory less accounts payable, as a percentage of annualized sales decreased by 0.1% to 7.7%. Our free cash flow, which we define as cash from operating activities less net purchases of property and equipment, was $639.5 million for fiscal year 2016 compared to $554.3 million for fiscal year 2015. The increase in free cash flow is primarily due to higher cash flows from operations offset by higher net expenditures during fiscal year 2016 as we thoughtfully invested in capabilities and capacity in advance of revenue to reinforce our growing automotive, medical, and energy businesses, as well as support our innovation and sketch-to-scale offering. Refer to the Liquidity and Capital Resources section for the free cash flows reconciliation to our most directly comparable GAAP financial measure of cash flows from operations. Cash provided by financing activities amounted to $249.6 million during fiscal year 2016 which was primarily the result of net proceeds from bank borrowings and long-term debt of $694.5 million mainly resulting from our new debt issuance discussed further in note 7 to the consolidated financial statements, offset by the repurchases of approximately 37.9 million ordinary shares at an aggregate purchase value of $420.3 million.

[0001628280-16-016576:mdna:31]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001628280-16-016576:mdna:32]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results may differ from those estimates and assumptions.

[0001628280-16-016576:mdna:33]
We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0001628280-16-016576:mdna:34]
Revenue Recognition

[0001628280-16-016576:mdna:35]
We recognize manufacturing revenue when we ship goods or the goods are received by our customer, title and risk of ownership have passed, the price to the buyer is fixed or determinable and recoverability is reasonably assured. Generally, there are no formal substantive customer acceptance requirements or further obligations related to manufacturing services. If such requirements or obligations exist, then we recognize the related revenues at the time when such requirements are completed and the obligations are fulfilled. Some of our customer contracts allow us to recover certain costs related to manufacturing services that are over and above the prices we charge for the related products. We determine the amount of costs that are recoverable based on historical experiences and agreements with those customers. Also, certain customer contracts may contain certain commitments and obligations that may result in additional expenses or decrease in revenue. We accrue for these commitments and obligations based on facts and circumstances and contractual terms. We also make provisions for estimated sales returns and other adjustments at the time revenue is recognized based upon contractual terms and an analysis of historical returns. Provisions for sales returns and other adjustments were not material to our consolidated financial statements for any of the periods presented.

[0001628280-16-016576:mdna:36]
We provide a comprehensive suite of services for our customers that range from advanced product design to manufacturing and logistics to after-sales services. We recognize service revenue when the services have been performed, and

[0001628280-16-016576:mdna:37]
the related costs are expensed as incurred. Our net sales for services were less than 10% of our total sales for all periods presented, and accordingly, are included in net sales in the consolidated statements of operations.

[0001628280-16-016576:mdna:38]
Customer Credit Risk

[0001628280-16-016576:mdna:39]
We have an established customer credit policy through which we manage customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. We perform ongoing credit evaluations of our customers' financial condition and make provisions for doubtful accounts based on the outcome of those credit evaluations. We evaluate the collectability of accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent we identify exposures as a result of credit or customer evaluations, we also review other customer related exposures, including but not limited to inventory and related contractual obligations. On April 21, 2016, one of our customers, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison"), filed a petition for reorganization under bankruptcy law. For the fiscal year ended March 31, 2016, we recognized approximately $61.0 million in charges for provisions of accounts receivable associated with our outstanding SunEdison receivables. The estimates underlying our recorded provisions, as well as consideration of other potential customer bankruptcy-related contingencies associated with the SunEdison bankruptcy proceedings, are based on the facts currently known to us. If these facts change, the provisions are subject to change or we could recognize additional charges, either of which could be material.

[0001628280-16-016576:mdna:40]
Restructuring Charges

[0001628280-16-016576:mdna:41]
We recognize restructuring charges related to our plans to close or consolidate excess manufacturing and administrative facilities and to realign our corporate cost structure. In connection with these activities, we recognize restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0001628280-16-016576:mdna:42]
The recognition of these restructuring charges requires that we make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent our actual results differ from our estimates and assumptions, we may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, we evaluate the remaining accrued balances to ensure that no excess accruals are retained and the utilization of the provisions are for their intended purpose in accordance with developed exit plans.

[0001628280-16-016576:mdna:43]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0001628280-16-016576:mdna:44]
Carrying Value of Long-Lived Assets

[0001628280-16-016576:mdna:45]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset may not be recoverable. An impairment loss is recognized when the carrying amount of these long-lived assets exceeds their fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such assets are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, general business environment and other factors. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize additional impairment charges in the future.

[0001628280-16-016576:mdna:46]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. The Company performed its goodwill impairment assessment on January 1, 2016 and determined that no impairment existed as of the date of the impairment test because the fair value of each reporting unit exceeded its carrying value.

[0001628280-16-016576:mdna:47]
Inventory Valuation

[0001628280-16-016576:mdna:48]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If

[0001628280-16-016576:mdna:49]
34

[0001628280-16-016576:mdna:50]
actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regard to inventory procured to fulfill customer demand.

[0001628280-16-016576:mdna:51]
Contingent Liabilities

[0001628280-16-016576:mdna:52]
We may be exposed to certain liabilities relating to our business operations, acquisitions of businesses and assets and other activities. We make provisions for such liabilities when it is probable that the settlement of the liability will result in an outflow of economic resources or the impairment of an asset. We make these assessments based on facts and circumstances that may change in the future resulting in additional expenses.

[0001628280-16-016576:mdna:53]
Income Taxes

[0001628280-16-016576:mdna:54]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0001628280-16-016576:mdna:55]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 13 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0001628280-16-016576:mdna:56]
Translation of Foreign Currencies

[0001628280-16-016576:mdna:57]
The financial position and results of operations for certain of our subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive loss, a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in operating results.

[0001628280-16-016576:mdna:58]
35

[0001628280-16-016576:mdna:59]
RESULTS OF OPERATIONS

[0001628280-16-016576:mdna:60]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." The data below, and discussion that follows, represents our results from operations.

[0001628280-16-016576:mdna:61]
|  | Fiscal Year EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.4 |  |  | 94.1 |  |  | 94.3 |  |
| Restructuring charges | — |  |  | — |  |  | 0.2 |  |
| Gross profit | 6.6 |  |  | 5.9 |  |  | 5.5 |  |
| Selling, general and administrative expenses | 3.9 |  |  | 3.2 |  |  | 3.4 |  |
| Intangible amortization | 0.3 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |
| Other charges (income), net | 0.2 |  |  | (0.2 | ) |  | 0.2 |  |
| Interest and other, net | 0.3 |  |  | 0.2 |  |  | 0.2 |  |
| Income before income taxes | 1.9 |  |  | 2.6 |  |  | 1.5 |  |
| Provision for income taxes | — |  |  | 0.3 |  |  | 0.1 |  |
| Net Income | 1.9 | % |  | 2.3 | % |  | 1.4 | % |

[0001628280-16-016576:mdna:62]
Net sales

[0001628280-16-016576:mdna:63]
Net sales during fiscal year 2016 totaled $24.4 billion, representing a decrease of $1.7 billion, or 6.6%, from $26.1 billion during fiscal year 2015. During fiscal year 2016, net sales decreased $1.2 billion in Asia, $0.6 billion in the Americas, and $14.7 million in Europe.

[0001628280-16-016576:mdna:64]
Net sales during fiscal year 2015 totaled $26.1 billion, representing an increase of $39.3 million, or 0.2%, from $26.1 billion during fiscal year 2014. During fiscal year 2015, net sales increased $0.7 billion in the Americas and $0.1 billion in Europe, offset by a decrease of $0.8 billion in Asia.

[0001628280-16-016576:mdna:65]
The following table sets forth net sales by segments and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0001628280-16-016576:mdna:66]
|  | Fiscal Year Ended March 31, |
| Segments: | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Communications & Enterprise Compute | $ | 8,841,642 |  |  | 36 | % |  | $ | 9,191,211 |  |  | 35 | % |  | $ | 9,688,023 |  |  | 37 | % |
| Consumer Technologies Group | 6,997,526 |  |  | 29 | % |  | 8,940,043 |  |  | 34 | % |  | 9,357,635 |  |  | 36 | % |
| Industrial & Emerging Industries | 4,680,718 |  |  | 19 | % |  | 4,459,351 |  |  | 17 | % |  | 3,787,838 |  |  | 15 | % |
| High Reliability Solutions | 3,898,999 |  |  | 16 | % |  | 3,557,311 |  |  | 14 | % |  | 3,275,111 |  |  | 13 | % |
|  | $ | 24,418,885 |  |  |  |  |  | $ | 26,147,916 |  |  |  |  |  | $ | 26,108,607 |  |  |  |  |

[0001628280-16-016576:mdna:67]
Net sales during fiscal year 2016 decreased $1.9 billion or 21.7% in the CTG segment and $349.6 million or 3.8% in the CEC segment. The drop in CTG was due to a decline in demand from our largest customer in our mobile business offset by expansion across wearables, connected home and gaming markets. The decrease in CEC is primarily attributable to lower sales within our server and storage business. These decreases were partially offset by a $341.7 million or 9.6% increase in sales from our HRS segment, and by a $221.4 million or 5.0% increase in sales from our IEI segment. These increases in HRS and IEI were attributable to an increase across multiple product categories and customers, most notably in our household, energy, automotive, and medical businesses primarily as a result of our strategic acquisitions in both segments referred to below.

[0001628280-16-016576:mdna:68]
36

[0001628280-16-016576:mdna:69]
Net sales during fiscal year 2015 increased $0.7 billion or 17.7% in the IEI segment and $0.3 billion or 8.6% in the HRS segment. The increase in revenue from our IEI segment is primarily attributable to a broad increase across multiple product categories and customers, most notably in our energy and our household industrial and lifestyle businesses. The increased revenue from our HRS segment is primarily due to a higher demand from our medical customers, and greater sales to our automotive customers as a result of an increased use of electronics throughout vehicles in areas such as in-car connectivity, LED lighting, and power management. The increase in these segments was partially offset by a $0.5 billion or 5.1% decrease in sales from our CEC segment, and by a $0.4 billion or 4.5% decrease in sales from our CTG segment. The decrease in revenue in our CEC segment is primarily attributable to broad softness in our telecom businesses directly due to decreased demand for our customer products from North American carriers. The decrease in revenue in our CTG segment is primarily due to softness in our personal computing business.

[0001628280-16-016576:mdna:70]
Our ten largest customers during fiscal years 2016, 2015 and 2014 accounted for approximately 46%, 50% and 52% of net sales, respectively. During fiscal years 2016, 2015 and 2014, only Lenovo/Motorola (including net sales from its former parent, Google, up to the point in time when Motorola Mobility was acquired by Lenovo and including net sales from Lenovo thereafter), which is reflected in our CTG segment, accounted for greater than 10% of net sales. Going forward, we do not expect Motorola Mobility to account for greater than 10% of our net sales.

[0001628280-16-016576:mdna:71]
Gross profit

[0001628280-16-016576:mdna:72]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion and consolidation of manufacturing facilities. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0001628280-16-016576:mdna:73]
Gross profit during fiscal year 2016 increased $62.7 million to $1.6 billion from $1.5 billion during fiscal year 2015 reflecting a richer mix of business and improved operational execution while ramping new customers and programs during fiscal year 2016. Gross margin increased to 6.6% of net sales in fiscal year 2016 as compared with 5.9% of net sales in fiscal year 2015. Gross margins improved 70 basis points in fiscal year 2016 compared to that of fiscal year 2015 due to proportionate increased share of our total revenue attributable to our HRS and IEI segments coupled with their increased profitability primarily driven by our acquisitions of Mirror Controls International ("MCi") and NEXTracker Inc. ("NEXTracker").

[0001628280-16-016576:mdna:74]
Gross profit during fiscal year 2015 increased $105.1 million to $1.5 billion from $1.4 billion during fiscal year 2014. Gross margin increased to 5.9% of net sales in fiscal year 2015 as compared with 5.5% of net sales in fiscal year 2014. Gross margins improved 40 basis points in fiscal year 2015 compared to that of fiscal year 2014 due to restructuring charges in fiscal year 2014 in the amount of $58.6 million, or 20 basis points included in cost of sales. There were no restructuring charges in fiscal year 2015. Further, gross margin in fiscal year 2015 improved as a result of increased revenue from our IEI and HRS segments as a percentage of our total revenues overall, which yield higher margins than our CTG and CEC segments, and better than expected execution on certain products, some of which were reaching end of life.

[0001628280-16-016576:mdna:75]
Segment income

[0001628280-16-016576:mdna:76]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock based compensation, restructuring charges, certain bad debt charges, other charges (income), net and interest and other, net. A portion of amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0001628280-16-016576:mdna:77]
The following table sets forth segment income and margins. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0001628280-16-016576:mdna:78]
37

[0001628280-16-016576:mdna:79]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |
| CEC | $ | 265,076 |  |  | 3.0 | % |  | $ | 257,323 |  |  | 2.8 | % |  | $ | 259,329 |  |  | 2.7 | % |
| CTG | 163,677 |  |  | 2.3 | % |  | 218,251 |  |  | 2.4 | % |  | 125,171 |  |  | 1.3 | % |
| IEI | 157,588 |  |  | 3.4 | % |  | 131,956 |  |  | 3.0 | % |  | 127,085 |  |  | 3.4 | % |
| HRS | 294,635 |  |  | 7.6 | % |  | 227,595 |  |  | 6.4 | % |  | 221,402 |  |  | 6.8 | % |
| Corporate and Other | (89,219 | ) |  |  |  | (83,988 | ) |  |  |  | (68,475 | ) |  |  |
| Total segment income | 791,757 |  |  | 3.2 | % |  | 751,137 |  |  | 2.9 | % |  | 664,512 |  |  | 2.5 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 65,965 |  |  |  |  | 32,035 |  |  |  |  | 28,892 |  |  |  |
| Stock-based compensation | 77,580 |  |  |  |  | 50,270 |  |  |  |  | 40,439 |  |  |  |
| Restructuring charges (2) | — |  |  |  |  | — |  |  |  |  | 75,311 |  |  |  |
| Bad debt charge (1) | 61,006 |  |  |  |  | — |  |  |  |  | — |  |  |  |
| Other charges (income), net | 47,738 |  |  |  |  | (53,233 | ) |  |  |  | 57,512 |  |  |  |
| Interest and other, net | 84,793 |  |  |  |  | 51,410 |  |  |  |  | 61,904 |  |  |  |
| Income before income taxes | $ | 454,675 |  |  |  |  | $ | 670,655 |  |  |  |  | $ | 400,454 |  |  |  |

[0001628280-16-016576:mdna:80]
| (1) | On April 21, 2016, one of our customers, SunEdison, filed a petition for reorganization under bankruptcy law. During the fiscal year ended March 31, 2016, we recognized a bad debt reserve charge of $61.0 million associated with our outstanding SunEdison receivables. This charge is included in selling, general and administrative expenses in the consolidated statement of operations but is excluded from the measurement of the Company's operating segment's performance. Refer to note 2 to the consolidated financial statements for additional information regarding this charge. |

[0001628280-16-016576:mdna:81]
| (2) | During the fiscal year ended March 31, 2014, the Company recognized restructuring charges of approximately $75.3 million. The costs associated with these restructuring activities include employee severance, other personnel costs, non-cash impairment charges on equipment no longer in use and to be disposed of, and other exit related costs due to facility closures or rationalizations. Refer to note 14 to the consolidated financial statements for additional information regarding these charges. |

[0001628280-16-016576:mdna:82]
CEC segment margin increased 20 basis points, for fiscal year 2016, from 2.8% during fiscal year 2015. The improvements are driven by favorable product mix changes from new program offerings, higher utilization levels and strong operational execution across multiple customers and facilities, offset by incremental engineering spend as we continue to invest in expanding our capabilities. CEC segment margin increased 10 basis points, for fiscal year 2015, from 2.7% during fiscal year 2014, also as a result of favorable product mix changes during fiscal 2015.

[0001628280-16-016576:mdna:83]
CTG segment margin slightly decreased 10 basis points for fiscal year 2016, from 2.4% during fiscal year 2015, due primarily to the soft macro economy, notably in Brazil, which impacted consumer business, partially offset by a portfolio shift within the CTG product mix focusing on higher margin consumer electronic products. CTG segment margin increased 110 basis points for fiscal year 2015, from 1.3% during fiscal year 2014, primarily attributable to a portfolio shift within the CTG product mix coupled with better execution on certain products some of which were going end of life.

[0001628280-16-016576:mdna:84]
IEI segment margin increased 40 basis points to 3.4% for fiscal year 2016, from 3.0% during fiscal year 2015. This is primarily due to strong operational execution and higher utilization levels coupled with contribution from our NEXTracker acquisition that contributed higher margins for the second half of fiscal year 2016. Fiscal year 2015 also included underperformance of certain programs, delayed and inefficient ramps for new programs. IEI segment margin decreased 40 basis points to 3.0% for fiscal year 2015, from 3.4% during fiscal year 2014 due to operational challenges and underperformance of certain programs during fiscal year 2015 as mentioned above.

[0001628280-16-016576:mdna:85]
HRS segment margin increased 120 basis points to 7.6% for fiscal year 2016, from 6.4% during fiscal year 2015. The improvements are primarily due to additional flow through from the increase in revenue from new programs and contribution from our MCi acquisition starting in our second quarter of fiscal year 2016 in addition to greater value-added business engagements due to greater design and engineering solutions as part of our sketch to scaletm offering. HRS segment margin

[0001628280-16-016576:mdna:86]
38

[0001628280-16-016576:mdna:87]
decreased 40 basis points to 6.4% for fiscal year 2015, from 6.8% for fiscal year 2014 primarily as a result of comparatively higher ramp costs for new programs during fiscal 2015.

[0001628280-16-016576:mdna:88]
Restructuring charges

[0001628280-16-016576:mdna:89]
In response to a challenging macroeconomic environment, we initiated certain restructuring activities in fiscal year 2014 to improve our operational efficiencies by reducing excess workforce and capacity. There were no material restructuring activities during fiscal years 2016 and 2015. The fiscal year 2014 restructuring activities were intended to realign our corporate cost structure, and rationalize our global manufacturing capacity and infrastructure which will further shift manufacturing capacity to locations with higher efficiencies.

[0001628280-16-016576:mdna:90]
During fiscal year 2014, we recognized $75.3 million of pre-tax restructuring charges comprised of $73.4 million of cash charges predominantly related to employee severance costs and $1.9 million of non-cash charges related to asset impairment. The restructuring charges by geographic region amounted to $34.5 million in Asia, $24.9 million in the Americas and $15.9 million in Europe. We classified $58.6 million of the charges incurred in fiscal year 2014 as a component of cost of sales and $16.7 million as a component of selling, general and administrative expenses.

[0001628280-16-016576:mdna:91]
As of March 31, 2014 all plans had been completed. As of March 31, 2016, accrued costs relating to restructuring charges were $13.2 million of which $2.5 million was classified as a current obligation. As of March 31, 2015, accrued costs relating to restructuring charges were $15.1 million of which $3.5 million was classified as a current obligation.

[0001628280-16-016576:mdna:92]
Refer to note 14 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0001628280-16-016576:mdna:93]
Selling, general and administrative expenses

[0001628280-16-016576:mdna:94]
Selling, general and administrative expenses ("SG&A") totaled $954.9 million or 3.9% of net sales, during fiscal year 2016, compared to $844.5 million, or 3.2% of net sales, during fiscal year 2015, increasing by $110.4 million or 13.1%. The increase in SG&A in dollars and as a percentage of net sales is primarily the result of an increase in costs associated with research, development and design activities, as we continued to deploy resources to meet the needs of our customers and explore new product innovations, increases in stock-based compensation expense, incremental costs associated with our acquisitions of MCi and NEXTracker both of which drive a higher proportional SG&A level, and a bad debt reserve charge associated with our outstanding SunEdison receivables of $61.0 million as a result of SunEdison's bankruptcy filing.

[0001628280-16-016576:mdna:95]
SG&A totaled $844.5 million or 3.2% of net sales, during fiscal year 2015, compared to $874.8 million, or 3.4% of net sales, during fiscal year 2014, decreasing by $30.3 million or 3.5%. The decrease in SG&A in dollars and as a percentage of net sales is primarily the result of our cost reduction measures that we undertook in fiscal year 2015 and rationalization efforts carried out in fiscal year 2014, partially offset by an approximate $8.9 million increase in non-cash stock-based compensation.

[0001628280-16-016576:mdna:96]
We recognized research and development costs primarily related to our design and innovations businesses of $75.5 million, $35.2 million, and $30.0 million for the fiscal years ended March 31, 2016, 2015 and 2014, respectively.

[0001628280-16-016576:mdna:97]
Intangible amortization

[0001628280-16-016576:mdna:98]
Amortization of intangible assets in fiscal year 2016 increased by $33.9 million to $66.0 million from $32.0 million in fiscal year 2015, primarily as a result of incremental amortization expense on intangibles assets relating to our acquisitions completed during the fiscal year 2016.

[0001628280-16-016576:mdna:99]
Amortization of intangible assets in fiscal year 2015 increased by $3.1 million to $32.0 million from $28.9 million in fiscal year 2014, primarily as a result of customer-related intangibles in connection with our acquisitions and the purchase of certain technology rights during the fiscal year 2015.

[0001628280-16-016576:mdna:100]
Other charges (income), net

[0001628280-16-016576:mdna:101]
During fiscal year 2016, we recognized other charges of $47.7 million primarily due to a $26.8 million loss on the disposition of a non-strategic Western European manufacturing facility which included a non cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by a non-cash foreign currency translation gain of $4.2 million, as further discussed in note 15 to the consolidated financial statements.

[0001628280-16-016576:mdna:102]
During fiscal year 2015, we recognized other income of $53.2 million principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fiscal year 2014 in the amount of $55.0 million. We executed an amendment to the customer contract during fiscal year 2015 which relieved us of commitment performance as was defined in an existing customer manufacturing agreement. We also recognized an $11.0 million loss in connection with the

[0001628280-16-016576:mdna:103]
disposition of a manufacturing facility in Western Europe. Further, we recognized a net gain for the sale of a certain investment, which primarily comprises the balance for other income in fiscal year 2015 net of the above items.

[0001628280-16-016576:mdna:104]
During fiscal year 2014, we recognized other charges of $57.5 million primarily due to the contractual obligation of $55.0 million discussed above. Additionally, we exercised warrants to purchase common shares of a supplier and sold the underlying shares for a loss of $7.1 million, offset by a gain of $4.6 million recognized in connection with the sales of certain investments.

[0001628280-16-016576:mdna:105]
Interest and other, net

[0001628280-16-016576:mdna:106]
Interest and other, net was $84.8 million during fiscal year 2016 compared to $51.4 million during fiscal year 2015. The increase in interest and other, net of $33.4 million was primarily due to a $23.5 million increase of interest expense from the 4.750% Notes issued during the current year as further discussed in note 7 to the consolidated financial statements, as well as $8.0 million of acquisition-related costs incurred during fiscal year 2016, primarily for our acquisition of MCi.

[0001628280-16-016576:mdna:107]
Interest and other, net was $51.4 million during fiscal year 2015 compared to $61.9 million during fiscal year 2014. The decrease in interest and other, net was primarily due to a gain associated with minority interest from an investment, an increase in foreign currency gains relating to the Chinese RMB, and a decrease in interest expense as a result of refinancing of certain debt facilities during the latter part of fiscal year 2014.

[0001628280-16-016576:mdna:108]
Income taxes

[0001628280-16-016576:mdna:109]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 2.3%, 10.4% and 8.7% for the fiscal years 2016, 2015 and 2014, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0001628280-16-016576:mdna:110]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  | 17.0 | % |
| Effect of tax rate differential | (16.1 | ) |  | (12.1 | ) |  | (17.1 | ) |
| Intangible amortization | 2.4 |  |  | 0.8 |  |  | 1.2 |  |
| Change in liability for uncertain tax positions | (3.0 | ) |  | 4.4 |  |  | (0.5 | ) |
| Change in valuation allowance | 0.2 |  |  | 0.4 |  |  | 6.7 |  |
| Other | 1.8 |  |  | (0.1 | ) |  | 1.4 |  |
| Provision for income taxes | 2.3 | % |  | 10.4 | % |  | 8.7 | % |

[0001628280-16-016576:mdna:111]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia and Israel of $6.6 million, $9.8 million and $15.2 million in fiscal years 2016, 2015 and 2014, respectively.  Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of ($13.7) million, $29.7 million, and ($2.2) million and changes in our valuation allowances on deferred tax assets of $1.0 million, $2.5 million and $26.8 million in fiscal years 2016, 2015 and 2014, respectively.  We generate most of our revenues and profits from operations outside of Singapore.

[0001628280-16-016576:mdna:112]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions and around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examinations, there could be a material adverse effect on our tax position, operating results, financial position and cash flows.

[0001628280-16-016576:mdna:113]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2016, we released valuation allowances totaling $20.3 million primarily related to our operations in Malaysia as these amounts were deemed to be more likely than not to be realized due to the increased profitability of the Malaysian subsidiary during the past three fiscal years following a period of losses as well as continued forecasted profitability of that subsidiary. In addition, we had a $43.0 million credit to tax expense related to the partial release of valuation allowance on our US operations due to the recording of deferred tax liabilities related to intangibles acquired during fiscal year 2016.  However, these valuation allowance eliminations were offset by other current period valuation allowance movements primarily related to current period valuation allowance additions due to increased deferred tax assets related to current period losses in legal entities with existing full valuation allowance positions, and to a lesser extent, current period changes in valuation

[0001628280-16-016576:mdna:114]
40

[0001628280-16-016576:mdna:115]
allowance positions due to increased negative evidence during the period in legal entities which did not previously have valuation allowance recorded.

[0001628280-16-016576:mdna:116]
See note 13, "Income Taxes," to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data" for further discussion.

[0001628280-16-016576:mdna:117]
LIQUIDITY AND CAPITAL RESOURCES

[0001628280-16-016576:mdna:118]
As of March 31, 2016, we had cash and cash equivalents of $1.6 billion and bank and other borrowings of $2.8 billion. We have a $1.5 billion revolving credit facility, under which we had no borrowings outstanding as of March 31, 2016.

[0001628280-16-016576:mdna:119]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2016, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $916.0 million as of March 31, 2016). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001628280-16-016576:mdna:120]
Fiscal Year 2016

[0001628280-16-016576:mdna:121]
Cash provided by operating activities was $1.1 billion during fiscal year 2016. This resulted primarily from $444.1 million of net income for the period plus $625.4 million of non-cash charges such as depreciation, amortization, other impairment charges, provision for doubtful accounts and stock-based compensation expense that are included in the determination of net income. Depreciation expense comprised $425.7 million of those non-cash charges, which was relatively consistent with our normal annual run rate of approximately $425.0 million. We generated $66.9 million in cash as a result of changes in our operating assets and liabilities, driven primarily by a $423.6 million reduction in accounts receivable due to improved collection efforts and lower business levels, offset by a $365.1 million reduction in accounts payable. Net working capital ("NWC"), defined as net accounts receivable, including deferred purchase price receivables, plus inventory less accounts payable decreased by $37.7 million primarily due to lower business levels during the fourth quarter of fiscal year 2016 as compared to the same quarter of fiscal year 2015, which resulted in slightly lower levels of investments in NWC.

[0001628280-16-016576:mdna:122]
Cash used in investing activities was $1.4 billion during fiscal year 2016. This resulted primarily from $916.5 million for the acquisition of eleven businesses completed during fiscal year 2016, including approximately $555.2 million, net of cash acquired, related to the acquisition of MCi, $240.8 million, net of cash acquired, related to the acquisition of NEXTracker, and approximately $67.5 million to acquire an optical transport facility from Alcatel-Lucent. We also paid $510.6 million in gross capital expenditures for property and equipment to support certain programs, offset by $13.7 million of proceeds from the sale of certain buildings and machinery and equipment. Other investing activities also includes $44.7 million paid for the purchase of certain investments, offset by $54.3 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution, as further discussed in note 17 to the consolidated financial statements.

[0001628280-16-016576:mdna:123]
Cash provided by financing activities was $249.6 million during fiscal year 2016, which was primarily the result of net proceeds from bank borrowings and long-term debt of $694.5 million mainly resulting from our new debt issuance discussed further in note 7 to the consolidated financial statements, and $61.3 million from the issuance of our shares for option exercises. These cash inflows were partially offset by $420.3 million of cash paid for the repurchase of our ordinary shares, and $75.8 million of cash paid to a third party banking institution for certain assets that were financed by the third party banking institution on behalf of a customer, which is included in other financing activities.

[0001628280-16-016576:mdna:124]
Fiscal Year 2015

[0001628280-16-016576:mdna:125]
Cash provided by operating activities was $794.0 million during fiscal year 2015. This resulted primarily from $600.8 million of net income for the period plus $510.9 million of non-cash charges such as depreciation, amortization, other impairment charges and stock-based compensation expense that are included in the determination of net income. Depreciation expense comprised $496.8 million of those non-cash charges, which was higher than our normal annual run rate of approximately $425.0 million due to accelerated depreciation recognized for fixed assets directly associated with certain product exits during the year. These were offset by $317.6 million from changes in our operating assets and liabilities, driven primarily by a $565.1 million reduction in customer deposits that were received in prior periods to support increased working capital requirements in those periods. NWC decreased by $212.5 million primarily due to lower business levels during the

[0001628280-16-016576:mdna:126]
fourth quarter of fiscal year 2015 as compared to the same quarter of fiscal year 2014, which resulted in lower levels of investments in NWC.

[0001628280-16-016576:mdna:127]
Cash used in investing activities amounted to $242.2 million during fiscal year 2015. This resulted primarily from $347.4 million in gross capital expenditures for property and equipment to support certain programs, offset by $107.7 million of proceeds from the sale of certain buildings and machinery and equipment. We also paid $52.7 million for the acquisition of four businesses completed during fiscal year 2015. Other investing activities also includes $79.7 million of proceeds from the sale of manufacturing equipment originally purchased on behalf of a customer and financed by a third party banking institution, as further discussed in note 17 to the consolidated financial statements, partially offset by $15.7 million paid for the purchase of certain technology rights as further discussed in note 2 to the consolidated financial statements.

[0001628280-16-016576:mdna:128]
Cash used in financing activities was $516.0 million during fiscal year 2015, which was primarily the result of cash paid for the repurchase of our ordinary shares in the amount of $415.9 million and net repayment of debt in the amount of $24.6 million. Included in other financing activities is $88.8 million of cash paid to a third party banking institution for certain manufacturing equipment that was financed by the third party banking institution on behalf of a customer and $11.3 million of cash paid for contingent consideration related to our acquisition of Saturn Electronics and Engineering Inc. The aforementioned cash outflows were partially offset by proceeds from the issuance of our shares for option exercises amounting to $23.5 million.

[0001628280-16-016576:mdna:129]
Fiscal Year 2014

[0001628280-16-016576:mdna:130]
Cash provided by operating activities was $1.2 billion during fiscal year 2014, which resulted primarily from $365.6 million of net income for the period plus $450.0 million of non-cash charges such as depreciation, amortization, impairment charges and stock-based compensation expense that are included in the determination of net income. We generated $400.9 million in cash as a result of decreases in net operating assets. NWC increased by $233.7 million primarily to support the increase in our customers' forecasted business levels. The increases in accounts receivable and inventory are primarily as a result of the increase in sales in our CTG business, which generally carry higher volumes than our other complex segments. The cash outflows to support NWC were offset by $540.6 million of cash received from certain customers as advances during the period. In certain instances, the level of inventory reduction or consumption was lower than expected causing an increase to inventory and usage of cash. In response, we worked with these customers to fund the elevated inventory balances we held on their behalf. We have recorded these advances as other current liabilities in the consolidated balance sheet as of March 31, 2014 and expect these amounts to decrease as we produce or sell the associated inventory in the future.

[0001628280-16-016576:mdna:131]
Cash used in investing activities during fiscal year 2014 was $783.9 million. This resulted primarily from $515.0 million in capital expenditures for equipment, net of proceeds on sales. Our capital expenditures were related to investments to support innovation, expanding design capabilities, and improving our mechanicals and automation capabilities. Additionally, we paid $238.0 million for the acquisition of four businesses during the fiscal year, of which the majority relates to the acquisition of certain manufacturing operations from Google's Motorola Mobility LLC for $178.9 million and the acquisition of all outstanding shares of Riwisa AG for a total cash consideration of $44.0 million, net of cash acquired amounting to $9.4 million. Refer to note 17 to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data".

[0001628280-16-016576:mdna:132]
Cash used in financing activities amounted to $410.8 million during fiscal year 2014, which was primarily attributable to the repurchase of approximately 60.7 million shares for an aggregate purchase value of approximately $475.3 million. Other financing cash inflows of $52.1 million includes $38.6 million received from certain third parties for the noncontrolling interest in one of our subsidiaries as further discussed in note 5 to the consolidated financial statements included in Item 8, "Financial Statements and Supplementary Data." Additionally, we entered into a $600.0 million term loan agreement due August 30, 2018 and used all of the proceeds to repay the outstanding balances of our term loan due October 2014 and other term loans in full amounting to $170.3 million and $374.5 million, respectively, and part of the term loan due March 2019.

[0001628280-16-016576:mdna:133]
Key Liquidity Metrics

[0001628280-16-016576:mdna:134]
Free Cash flow

[0001628280-16-016576:mdna:135]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow, which is calculated as cash provided by operations less net purchases of property and equipment, was $639.5 million, $554.3 million and $701.5 million for fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-016576:mdna:136]
Free cash flow is not a measure of liquidity under generally accepted accounting principles in the United States, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001628280-16-016576:mdna:137]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 1,136,445 |  |  | $ | 794,034 |  |  | $ | 1,216,460 |  |
| Purchases of property and equipment | (510,634 | ) |  | (347,413 | ) |  | (609,643 | ) |
| Proceeds from the disposition of property and equipment | 13,676 |  |  | 107,689 |  |  | 94,640 |  |
| Free cash flow | $ | 639,487 |  |  | $ | 554,310 |  |  | $ | 701,457 |  |

[0001628280-16-016576:mdna:138]
Cash Conversion Cycle

[0001628280-16-016576:mdna:139]
|  | Fiscal Year Ended March 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Days in trade accounts receivable | 45 days |  | 46 days |  | 42 days |
| Days in inventory | 59 days |  | 58 days |  | 54 days |
| Days in accounts payable | 77 days |  | 77 days |  | 70 days |
| Cash conversion cycle | 27 days |  | 27 days |  | 26 days |

[0001628280-16-016576:mdna:140]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarter, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the fiscal year ended March 31, 2016, days in trade accounts receivable decreased by 1 day to 45 days compared to the fiscal year ended March 31, 2015 primarily due to some improvements in collection efforts, and to a lesser extent, due to the decline in net sales. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $501.1 million, $600.7 million and $470.9 million for the years ended March 31, 2016, 2015 and 2014, respectively. Deferred purchase price receivables were recorded in other current assets in the consolidated balance sheets.

[0001628280-16-016576:mdna:141]
Days in inventory was calculated as average inventory for the current and prior quarter divided by annualized cost of sales for the current quarter by day. During the fiscal year ended March 31, 2016, days in inventory increased by 1 day to 59 days as compared to the fiscal year ended March 31, 2015. The increase was primarily due to timing of demand from certain customers which was pushed out thus resulting in prepositioned raw materials and higher levels of stalled finished goods.

[0001628280-16-016576:mdna:142]
Days in accounts payable was calculated as average accounts payable for the current and prior quarter divided by annualized cost of sales for the current quarter by day. During the fiscal year ended March 31, 2016, days in accounts payable remained consistent at 77 days compared to the fiscal year ended March 31, 2015.

[0001628280-16-016576:mdna:143]
Our cash conversion cycle was calculated as days in trade receivables plus days in inventory, minus days in accounts payable and is a measure of how efficient we are at managing our working capital. Our cash conversion cycle remained consistent at 27 days for the fiscal year ended March 31, 2016 compared to that of fiscal year 2015 due to the factors affecting each of the components in the calculation discussed above.

[0001628280-16-016576:mdna:144]
Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Cash balances are generated and held in many locations throughout the world. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months.

[0001628280-16-016576:mdna:145]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0001628280-16-016576:mdna:146]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. During fiscal years 2016, 2015 and 2014 we received approximately $5.2 billion, $4.3 billion and $4.2 billion, respectively from sales of receivables under our ABS programs, and $2.3 billion, $4.2

[0001628280-16-016576:mdna:147]
billion and $3.4 billion, respectively from other sales of receivables. As of March 31, 2016 and 2015, the outstanding balance on receivables sold for cash was $1.2 billion, under all our accounts receivable sales programs, which are removed from accounts receivable balances in our consolidated balance sheets.

[0001628280-16-016576:mdna:148]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0001628280-16-016576:mdna:149]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001628280-16-016576:mdna:150]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. On June 8, 2015, we issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213% of face value, and an effective yield of approximately 4.850%. We received net proceeds of approximately $595.3 million from the issuance which was used for general corporate purposes. During January 2016, we exchanged these notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. Further on March 31, 2014, the maturity date of our former $2.0 billion credit facility ("Credit Facility") which was due to expire in October 2016, was extended to March 2019. We also extended the balance of our term loan associated to the Credit Facility as further described in our Contractual Obligations and Commitments section.

[0001628280-16-016576:mdna:151]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 20, 2015. During fiscal year 2016, we paid $420.3 million to repurchase shares (under the current and prior repurchase plans) at an average price of $11.09 per share. As of March 31, 2016, shares in the aggregate amount of $242.1 million were available to be repurchased under the current plan.

[0001628280-16-016576:mdna:152]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0001628280-16-016576:mdna:153]
On September 30, 2015, we amended our former $2.0 billion credit facility ("Credit Facility") to increase the $500.0 million term loan maturing in March 2019 by $100.0 million. Quarterly repayments of principal under this term loan were amended to $7.5 million through March 31, 2016, and will be increased to $11.3 million thereafter with the remainder due upon maturity. As of March 31, 2016, the amended Credit Facility consists of a $1.5 billion revolving credit facility, for which there were no borrowings outstanding, and a $600.0 million term loan, which is due to expire in March 2019.

[0001628280-16-016576:mdna:154]
The credit facility requires that we maintain a maximum ratio of total indebtedness to earnings before interest expense, taxes, depreciation and amortization ("EBITDA"), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, we were in compliance with these covenants. Borrowings under this credit facility bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating. The Company is required to pay a quarterly commitment fee ranging between 0.15% and 0.40% per annum on the daily unused amount of the $1.5 billion Revolving Credit Facility based on the Company's credit rating.

[0001628280-16-016576:mdna:155]
In addition, on June 8, 2015, we issued $600 million of 4.750% Notes (the "4.750% Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at 99.213%, of face value, and an effective yield of approximately 4.850%. We received net proceeds of approximately $595.3 million from the issuance which has been used for general corporate purposes. During January 2016, we exchanged these 4.750% Notes for new notes with substantially similar terms and completed the registration of these 4.750% Notes with the Securities and Exchange Commission. These 4.750% Notes are governed by the same terms and covenants as for the $1.0 billion notes, consisting of a $500 million 4.625% note and an additional $500 million 5.000% note (the "Previously Issued Notes"), which are described below.

[0001628280-16-016576:mdna:156]
Further, we have a $600 million term loan agreement which matures in August 2018. This loan is repayable in quarterly installments of $3.75 million, which commenced in December 2014 through August 2018, with the remaining amount due at maturity. This term loan agreement also requires that we maintain a maximum ratio of total indebtedness to EBITDA, and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, we were in compliance with the

[0001628280-16-016576:mdna:157]
covenants under this term loan agreement. Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.00% and 2.00%, based on the Company's credit ratings or (ii) the base rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.00% and 1.00%, based on the Company's credit rating.

[0001628280-16-016576:mdna:158]
Further, during fiscal year 2013, we issued an aggregate amount of $1.0 billion in the Previously Issued Notes which are senior unsecured obligations, rank equally with all of our other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of our 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, our Credit Facility or our $600.0 million term loan facility due August 30, 2018. In July 2013, we exchanged these Previously Issued Notes for new notes with substantially similar terms and completed the registration of these notes with the Securities and Exchange Commission. As of March 31, 2016, we were in compliance with the covenants under these credit facilities. Interest on the these Previously Issued Notes is payable semi-annually, which commenced on August 15, 2013.

[0001628280-16-016576:mdna:159]
On October 1, 2015, we borrowed €50 million (approximately $56.6 million as of March 31, 2016), under a 5-year, unsecured, term-loan agreement due September 30, 2020. Borrowings under this term loan bear interest at EURIBOR plus the applicable margin ranging between 0.80% and 2.00%, based on our credit ratings. The loan is repayable beginning December 30, 2016 in quarterly payments of €312,500 through June 30, 2020 with the remainder due upon maturity. This term loan agreement is unsecured, and is guaranteed by the Company. This term contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. This term loan agreement also requires that we maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of March 31, 2016, we were in compliance with the covenants under this term loan agreement.

[0001628280-16-016576:mdna:160]
As of March 31, 2016, we and certain of our subsidiaries had various uncommitted revolving credit facilities, lines of credit and other loans in the amount of $166.0 million in the aggregate under which there were no borrowings outstanding as of that date.

[0001628280-16-016576:mdna:161]
Refer to the discussion in note 7, "Bank Borrowings and Long-Term Debt" to the consolidated financial statements for further details of our debt obligations.

[0001628280-16-016576:mdna:162]
We have purchase obligations that arise in the normal course of business, primarily consisting of binding purchase orders for inventory related items and capital expenditures. Additionally, we have leased certain of our property and equipment under capital lease commitments, and certain of our facilities and equipment under operating lease commitments.

[0001628280-16-016576:mdna:163]
Future payments due under our purchase obligations, debt including capital leases and related interest obligations and operating lease:

[0001628280-16-016576:mdna:164]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In thousands) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase obligations | $ | 3,213,500 |  |  | $ | 3,213,500 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt and capital lease obligations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt | 2,791,906 |  |  | 65,166 |  |  | 1,068,617 |  |  | 547,440 |  |  | 1,110,683 |  |
| Capital lease | 25,054 |  |  | 6,640 |  |  | 10,302 |  |  | 8,112 |  |  | — |  |
| Interest on long-term debt obligations | 673,622 |  |  | 101,460 |  |  | 207,519 |  |  | 191,982 |  |  | 172,661 |  |
| Operating leases, net of subleases | 579,201 |  |  | 125,021 |  |  | 191,203 |  |  | 116,974 |  |  | 146,003 |  |
| Restructuring costs | 13,240 |  |  | 2,460 |  |  | 10,780 |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 7,296,523 |  |  | $ | 3,514,247 |  |  | $ | 1,488,421 |  |  | $ | 864,508 |  |  | $ | 1,429,347 |  |

[0001628280-16-016576:mdna:165]
We have excluded $212.3 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 13, "Income Taxes" to the consolidated financial statements for further details.

[0001628280-16-016576:mdna:166]
Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0001628280-16-016576:mdna:167]
OFF-BALANCE SHEET ARRANGEMENTS

[0001628280-16-016576:mdna:168]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of March 31, 2016 and 2015, the fair value of our deferred purchase price receivable was approximately $501.1 million and $600.7 million, respectively. As of March 31, 2016 and 2015, the outstanding balance on receivables sold for cash was $1.2 billion, under all our accounts receivable sales programs, which were removed from accounts receivable balances in our consolidated balance sheets. For further information, see note 10 to the consolidated financial statements.

[0001628280-16-016576:mdna:169]
RECENT ACCOUNTING PRONOUNCEMENTS

[0001628280-16-016576:mdna:170]
Refer to note 2 to the consolidated financial statements for recent accounting pronouncements.
