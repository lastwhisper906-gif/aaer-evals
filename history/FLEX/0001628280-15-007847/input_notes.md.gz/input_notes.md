# FLEX notes — 0001628280-15-007847


## flex:InterestAndOtherNetTextBlock

[0001628280-15-007847:notes:1]
[same as prior period, unchanged from 0001628280-15-005450:notes:1]

[0001628280-15-007847:notes:2]
During the three-month and six-month periods ended September 25, 2015, the Company recognized interest expense of $25.1 million and $45.2 million, respectively, on its debt obligations outstanding during the periods. During the three-month and six-month periods ended September 26, 2014, the Company recognized interest expense of $19.0 million and $37.5 million, respectively.

[0001628280-15-007847:notes:3]
During the three-month and six-month periods ended September 25, 2015, the Company recognized interest income of $4.3 million and $7.8 million, respectively. During the three-month and six-month periods ended September 26, 2014, the Company recognized interest income of $4.8 million and $10.1 million, respectively.

[0001628280-15-007847:notes:4]
During the three-month and six-month periods ended September 25, 2015, the Company recognized gains on foreign exchange transactions of $12.4 million and $14.6 million, respectively.  During the three-month and six-month periods ended September 26, 2014, the Company recognized gains on foreign exchange transactions of $6.8 million and $5.4 million, respectively.

[0001628280-15-007847:notes:5]
During the three-month and six-month periods ended September 25, 2015, the Company incurred $8.1 million of acquisition-related costs.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0001628280-15-007847:notes:6]
[same as prior period, unchanged from 0001628280-15-005450:notes:4]

[0001628280-15-007847:notes:7]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |
| Beginning balance | $ | 516,287 |  |  | $ | 463,124 |  |  | $ | 600,672 |  |  | $ | 470,908 |  |
| Transfers of receivables | 983,677 |  |  | 720,921 |  |  | 1,750,725 |  |  | 1,499,781 |  |
| Collections | (962,345 | ) |  | (757,988 | ) |  | (1,813,778 | ) |  | (1,544,632 | ) |
| Ending balance | $ | 537,619 |  |  | $ | 426,057 |  |  | $ | 537,619 |  |  | $ | 426,057 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0001628280-15-007847:notes:8]
[same as prior period, unchanged from 0001628280-15-005450:notes:6]

[0001628280-15-007847:notes:9]
Flextronics International Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade.

[0001628280-15-007847:notes:10]
In lieu of providing separate financial statements for the guarantor subsidiaries, the Company has included the accompanying condensed consolidating financial statements, which are presented using the equity method of accounting. The principal elimination entries relate to investment in subsidiaries and intercompany balances and transactions, including transactions with the Company’s non-guarantor subsidiaries. During the three-month period ended September 25, 2015, and in conjunction with the new $600 million Notes, a new entity was added as a guarantor subsidiary for all three tranches of the Notes. Accordingly, the Company recast the condensed consolidating financial statements presented below to reflect this change.

[0001628280-15-007847:notes:11]
Condensed Consolidating Balance Sheets as of September 25, 2015

[0001628280-15-007847:notes:12]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 517,631 |  |  | $ | 226,469 |  |  | $ | 924,327 |  |  | $ | — |  |  | $ | 1,668,427 |  |
| Accounts receivable | — |  |  | 1,352,781 |  |  | 1,194,029 |  |  | — |  |  | 2,546,810 |  |
| Inventories | — |  |  | 1,494,305 |  |  | 2,067,021 |  |  | — |  |  | 3,561,326 |  |
| Inter company receivable | 8,919,282 |  |  | 5,578,552 |  |  | 12,359,980 |  |  | (26,857,814 | ) |  | — |  |
| Other current assets | 3,749 |  |  | 202,794 |  |  | 1,002,388 |  |  | — |  |  | 1,208,931 |  |
| Total current assets | 9,440,662 |  |  | 8,854,901 |  |  | 17,547,745 |  |  | (26,857,814 | ) |  | 8,985,494 |  |
| Property and equipment, net | — |  |  | 506,394 |  |  | 1,711,636 |  |  | — |  |  | 2,218,030 |  |
| Goodwill and other intangible assets, net | 325 |  |  | 62,580 |  |  | 918,933 |  |  | — |  |  | 981,838 |  |
| Other assets | 2,259,454 |  |  | 198,711 |  |  | 2,139,936 |  |  | (4,123,124 | ) |  | 474,977 |  |
| Investment in subsidiaries | 1,654,260 |  |  | 2,412,432 |  |  | 16,883,121 |  |  | (20,949,813 | ) |  | — |  |
| Total assets | $ | 13,354,701 |  |  | $ | 12,035,018 |  |  | $ | 39,201,371 |  |  | $ | (51,930,751 | ) |  | $ | 12,660,339 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 43,125 |  |  | $ | 941 |  |  | $ | 3,906 |  |  | $ | — |  |  | $ | 47,972 |  |
| Accounts payable | — |  |  | 1,514,042 |  |  | 3,273,899 |  |  | — |  |  | 4,787,941 |  |
| Accrued payroll | — |  |  | 121,059 |  |  | 279,941 |  |  | — |  |  | 401,000 |  |
| Inter company payable | 8,213,861 |  |  | 8,993,273 |  |  | 9,650,680 |  |  | (26,857,814 | ) |  | — |  |
| Other current liabilities | 30,642 |  |  | 855,909 |  |  | 909,316 |  |  | — |  |  | 1,795,867 |  |
| Total current liabilities | 8,287,628 |  |  | 11,485,224 |  |  | 14,117,742 |  |  | (26,857,814 | ) |  | 7,032,780 |  |
| Long term liabilities | 2,646,945 |  |  | 2,109,106 |  |  | 2,539,057 |  |  | (4,123,124 | ) |  | 3,171,984 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,420,128 |  |  | (1,559,312 | ) |  | 22,509,125 |  |  | (20,949,813 | ) |  | 2,420,128 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,447 |  |  | — |  |  | 35,447 |  |
| Total shareholders’ equity (deficit) | 2,420,128 |  |  | (1,559,312 | ) |  | 22,544,572 |  |  | (20,949,813 | ) |  | 2,455,575 |  |
| Total liabilities and shareholders’ equity | $ | 13,354,701 |  |  | $ | 12,035,018 |  |  | $ | 39,201,371 |  |  | $ | (51,930,751 | ) |  | $ | 12,660,339 |  |

[0001628280-15-007847:notes:13]
[same as prior period, unchanged from 0001628280-15-005450:notes:11]

[0001628280-15-007847:notes:14]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 608,971 |  |  | $ | 168,272 |  |  | $ | 851,165 |  |  | $ | — |  |  | $ | 1,628,408 |  |
| Accounts receivable | — |  |  | 1,208,632 |  |  | 1,128,883 |  |  | — |  |  | 2,337,515 |  |
| Inventories | — |  |  | 1,729,593 |  |  | 1,759,159 |  |  | — |  |  | 3,488,752 |  |
| Inter company receivable | 6,417,410 |  |  | 4,759,062 |  |  | 10,099,057 |  |  | (21,275,529 | ) |  | — |  |
| Other current assets | 8,143 |  |  | 202,161 |  |  | 1,075,921 |  |  | — |  |  | 1,286,225 |  |
| Total current assets | 7,034,524 |  |  | 8,067,720 |  |  | 14,914,185 |  |  | (21,275,529 | ) |  | 8,740,900 |  |
| Property and equipment, net | — |  |  | 471,052 |  |  | 1,621,115 |  |  | — |  |  | 2,092,167 |  |
| Goodwill and other intangible assets, net | 475 |  |  | 64,831 |  |  | 349,869 |  |  | — |  |  | 415,175 |  |
| Other assets | 2,223,402 |  |  | 155,172 |  |  | 2,131,523 |  |  | (4,092,715 | ) |  | 417,382 |  |
| Investment in subsidiaries | 1,799,956 |  |  | 1,681,521 |  |  | 16,641,212 |  |  | (20,122,689 | ) |  | — |  |
| Total assets | $ | 11,058,357 |  |  | $ | 10,440,296 |  |  | $ | 35,657,904 |  |  | $ | (45,490,933 | ) |  | $ | 11,665,624 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 40,000 |  |  | $ | 917 |  |  | $ | 5,245 |  |  | $ | — |  |  | $ | 46,162 |  |
| Accounts payable | — |  |  | 1,758,305 |  |  | 2,802,889 |  |  | — |  |  | 4,561,194 |  |
| Accrued payroll | — |  |  | 112,692 |  |  | 227,047 |  |  | — |  |  | 339,739 |  |
| Inter company payable | 6,559,569 |  |  | 7,250,235 |  |  | 7,465,725 |  |  | (21,275,529 | ) |  | — |  |
| Other current liabilities | 30,553 |  |  | 845,156 |  |  | 933,419 |  |  | — |  |  | 1,809,128 |  |
| Total current liabilities | 6,630,122 |  |  | 9,967,305 |  |  | 11,434,325 |  |  | (21,275,529 | ) |  | 6,756,223 |  |
| Long term liabilities | 2,067,421 |  |  | 2,102,483 |  |  | 2,435,962 |  |  | (4,092,715 | ) |  | 2,513,151 |  |
| Flextronics International Ltd. shareholders’ equity (deficit) | 2,360,814 |  |  | (1,629,492 | ) |  | 21,752,181 |  |  | (20,122,689 | ) |  | 2,360,814 |  |
| Noncontrolling interests | — |  |  | — |  |  | 35,436 |  |  | — |  |  | 35,436 |  |
| Total shareholders’ equity (deficit) | 2,360,814 |  |  | (1,629,492 | ) |  | 21,787,617 |  |  | (20,122,689 | ) |  | 2,396,250 |  |
| Total liabilities and shareholders’ equity | $ | 11,058,357 |  |  | $ | 10,440,296 |  |  | $ | 35,657,904 |  |  | $ | (45,490,933 | ) |  | $ | 11,665,624 |  |

[0001628280-15-007847:notes:15]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 25, 2015

[0001628280-15-007847:notes:16]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,482,213 |  |  | $ | 5,514,535 |  |  | $ | (3,679,986 | ) |  | $ | 6,316,762 |  |
| Cost of sales | — |  |  | 4,141,254 |  |  | 5,458,578 |  |  | (3,679,986 | ) |  | 5,919,846 |  |
| Gross profit | — |  |  | 340,959 |  |  | 55,957 |  |  | — |  |  | 396,916 |  |
| Selling, general and administrative expenses | — |  |  | 66,682 |  |  | 150,114 |  |  | — |  |  | 216,796 |  |
| Intangible amortization | 75 |  |  | 960 |  |  | 15,092 |  |  | — |  |  | 16,127 |  |
| Interest and other, net | (132,637 | ) |  | 277,355 |  |  | (121,005 | ) |  | — |  |  | 23,713 |  |
| Income (loss) from continuing operations before income taxes | 132,562 |  |  | (4,038 | ) |  | 11,756 |  |  | — |  |  | 140,280 |  |
| Provision for income taxes | — |  |  | (5,658 | ) |  | 22,961 |  |  | — |  |  | 17,303 |  |
| Equity in earnings in subsidiaries | (9,585 | ) |  | (33,969 | ) |  | 16,621 |  |  | 26,933 |  |  | — |  |
| Net income (loss) | $ | 122,977 |  |  | $ | (32,349 | ) |  | $ | 5,416 |  |  | $ | 26,933 |  |  | $ | 122,977 |  |

[0001628280-15-007847:notes:17]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended September 26, 2014

[0001628280-15-007847:notes:18]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,732,749 |  |  | $ | 5,184,889 |  |  | $ | (3,389,121 | ) |  | $ | 6,528,517 |  |
| Cost of sales | — |  |  | 4,403,702 |  |  | 5,136,855 |  |  | (3,389,121 | ) |  | 6,151,436 |  |
| Gross profit | — |  |  | 329,047 |  |  | 48,034 |  |  | — |  |  | 377,081 |  |
| Selling, general and administrative expenses | — |  |  | 62,825 |  |  | 141,765 |  |  | — |  |  | 204,590 |  |
| Intangible amortization | 75 |  |  | 834 |  |  | 7,323 |  |  | — |  |  | 8,232 |  |
| Interest and other, net | (68,309 | ) |  | 288,590 |  |  | (210,359 | ) |  | — |  |  | 9,922 |  |
| Income (loss) from continuing operations before income taxes | 68,234 |  |  | (23,202 | ) |  | 109,305 |  |  | — |  |  | 154,337 |  |
| Provision for income taxes | — |  |  | 8,142 |  |  | 7,292 |  |  | — |  |  | 15,434 |  |
| Equity in earnings in subsidiaries | 70,669 |  |  | (50,729 | ) |  | 50,147 |  |  | (70,087 | ) |  | — |  |
| Net income (loss) | $ | 138,903 |  |  | $ | (82,073 | ) |  | $ | 152,160 |  |  | $ | (70,087 | ) |  | $ | 138,903 |  |

[0001628280-15-007847:notes:19]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 25, 2015

[0001628280-15-007847:notes:20]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 8,528,598 |  |  | $ | 9,450,050 |  |  | $ | (6,095,638 | ) |  | $ | 11,883,010 |  |
| Cost of sales | — |  |  | 7,785,313 |  |  | 9,444,078 |  |  | (6,095,638 | ) |  | 11,133,753 |  |
| Gross profit | — |  |  | 743,285 |  |  | 5,972 |  |  | — |  |  | 749,257 |  |
| Selling, general and administrative expenses | — |  |  | 130,238 |  |  | 295,943 |  |  | — |  |  | 426,181 |  |
| Intangible amortization | 150 |  |  | 1,921 |  |  | 21,727 |  |  | — |  |  | 23,798 |  |
| Interest and other, net | (398,020 | ) |  | 613,767 |  |  | (175,365 | ) |  | — |  |  | 40,382 |  |
| Income (loss) from continuing operations before income taxes | 397,870 |  |  | (2,641 | ) |  | (136,333 | ) |  | — |  |  | 258,896 |  |
| Provision for income taxes | — |  |  | 3,441 |  |  | 21,628 |  |  | — |  |  | 25,069 |  |
| Equity in earnings in subsidiaries | (164,043 | ) |  | (52,516 | ) |  | 52,584 |  |  | 163,975 |  |  | — |  |
| Net income (loss) | $ | 233,827 |  |  | $ | (58,598 | ) |  | $ | (105,377 | ) |  | $ | 163,975 |  |  | $ | 233,827 |  |

[0001628280-15-007847:notes:21]
Condensed Consolidating Statements of Operations for the Six-Month Period Ended September 26, 2014

[0001628280-15-007847:notes:22]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 9,537,544 |  |  | $ | 9,961,077 |  |  | $ | (6,327,359 | ) |  | $ | 13,171,262 |  |
| Cost of sales | — |  |  | 8,859,138 |  |  | 9,881,617 |  |  | (6,327,359 | ) |  | 12,413,396 |  |
| Gross profit | — |  |  | 678,406 |  |  | 79,460 |  |  | — |  |  | 757,866 |  |
| Selling, general and administrative expenses | — |  |  | 124,627 |  |  | 289,240 |  |  | — |  |  | 413,867 |  |
| Intangible amortization | 150 |  |  | 1,687 |  |  | 13,346 |  |  | — |  |  | 15,183 |  |
| Interest and other, net | (51,777 | ) |  | 547,193 |  |  | (510,866 | ) |  | — |  |  | (15,450 | ) |
| Income from continuing operations before income taxes | 51,627 |  |  | 4,899 |  |  | 287,740 |  |  | — |  |  | 344,266 |  |
| Provision for income taxes | — |  |  | 14,789 |  |  | 16,687 |  |  | — |  |  | 31,476 |  |
| Equity in earnings in subsidiaries | 261,163 |  |  | 13,647 |  |  | 86,579 |  |  | (361,389 | ) |  | — |  |
| Net income | $ | 312,790 |  |  | $ | 3,757 |  |  | $ | 357,632 |  |  | $ | (361,389 | ) |  | $ | 312,790 |  |

[0001628280-15-007847:notes:23]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 25, 2015

[0001628280-15-007847:notes:24]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 122,977 |  |  | $ | (32,349 | ) |  | $ | 5,416 |  |  | $ | 26,933 |  |  | $ | 122,977 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (30,267 | ) |  | (33,696 | ) |  | (30,633 | ) |  | 64,329 |  |  | (30,267 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (5,544 | ) |  | 1,160 |  |  | (5,544 | ) |  | 4,384 |  |  | (5,544 | ) |
| Comprehensive income (loss) | $ | 87,166 |  |  | $ | (64,885 | ) |  | $ | (30,761 | ) |  | $ | 95,646 |  |  | $ | 87,166 |  |

[0001628280-15-007847:notes:25]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended September 26, 2014

[0001628280-15-007847:notes:26]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 138,903 |  |  | $ | (82,073 | ) |  | $ | 152,160 |  |  | $ | (70,087 | ) |  | $ | 138,903 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (5,683 | ) |  | 77,712 |  |  | 65,611 |  |  | (143,323 | ) |  | (5,683 | ) |
| Unrealized loss on derivative instruments and other, net of zero tax | (2,433 | ) |  | (2,058 | ) |  | (2,433 | ) |  | 4,491 |  |  | (2,433 | ) |
| Comprehensive income (loss) | $ | 130,787 |  |  | $ | (6,419 | ) |  | $ | 215,338 |  |  | $ | (208,919 | ) |  | $ | 130,787 |  |

[0001628280-15-007847:notes:27]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 25, 2015

[0001628280-15-007847:notes:28]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 233,827 |  |  | $ | (58,598 | ) |  | $ | (105,377 | ) |  | $ | 163,975 |  |  | $ | 233,827 |  |
| Other comprehensive income (loss): | 0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (27,484 | ) |  | (57,186 | ) |  | (51,530 | ) |  | 108,716 |  |  | (27,484 | ) |
| Unrealized gain on derivative instruments and other, net of zero tax | 7,285 |  |  | 5,785 |  |  | 7,285 |  |  | (13,070 | ) |  | 7,285 |  |
| Comprehensive income (loss) | $ | 213,628 |  |  | $ | (109,999 | ) |  | $ | (149,622 | ) |  | $ | 259,621 |  |  | $ | 213,628 |  |

[0001628280-15-007847:notes:29]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Six-Month Period Ended September 26, 2014

[0001628280-15-007847:notes:30]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income | $ | 312,790 |  |  | $ | 3,757 |  |  | $ | 357,632 |  |  | $ | (361,389 | ) |  | $ | 312,790 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (9,828 | ) |  | 93,662 |  |  | 71,337 |  |  | (164,999 | ) |  | (9,828 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | 8,292 |  |  | (228 | ) |  | 8,292 |  |  | (8,064 | ) |  | 8,292 |  |
| Comprehensive income | $ | 311,254 |  |  | $ | 97,191 |  |  | $ | 437,261 |  |  | $ | (534,452 | ) |  | $ | 311,254 |  |

[0001628280-15-007847:notes:31]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 25, 2015

[0001628280-15-007847:notes:32]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 389,949 |  |  | $ | (247,462 | ) |  | $ | 519,508 |  |  | $ | — |  |  | $ | 661,995 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (88,699 | ) |  | (205,330 | ) |  | 11 |  |  | (294,018 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (559,442 | ) |  | (82,471 | ) |  | — |  |  | (641,913 | ) |
| Investing cash flows to affiliates | (1,326,493 | ) |  | (836,415 | ) |  | (1,193,747 | ) |  | 3,356,655 |  |  | — |  |
| Other investing activities, net | — |  |  | (22,822 | ) |  | 12,306 |  |  | — |  |  | (10,516 | ) |
| Net cash used in investing activities | (1,326,493 | ) |  | (1,507,378 | ) |  | (1,469,242 | ) |  | 3,356,666 |  |  | (946,447 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 595,309 |  |  | 209 |  |  | 35 |  |  | — |  |  | 595,553 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (17,507 | ) |  | (1,039 | ) |  | (2,544 | ) |  | — |  |  | (21,090 | ) |
| Payments for repurchases of ordinary shares | (241,978 | ) |  | — |  |  | — |  |  | — |  |  | (241,978 | ) |
| Net proceeds from issuance of ordinary shares | 49,074 |  |  | — |  |  | — |  |  | — |  |  | 49,074 |  |
| Financing cash flows from affiliates | 435,540 |  |  | 1,810,912 |  |  | 1,110,214 |  |  | (3,356,666 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (37,872 | ) |  | — |  |  | (37,872 | ) |
| Net cash provided by financing activities | 820,438 |  |  | 1,810,082 |  |  | 1,069,833 |  |  | (3,356,666 | ) |  | 343,687 |  |
| Effect of exchange rates on cash and cash equivalents | 24,766 |  |  | 2,955 |  |  | (46,937 | ) |  | — |  |  | (19,216 | ) |
| Net increase (decrease) in cash and cash equivalents | (91,340 | ) |  | 58,197 |  |  | 73,162 |  |  | — |  |  | 40,019 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 517,631 |  |  | $ | 226,469 |  |  | $ | 924,327 |  |  | $ | — |  |  | $ | 1,668,427 |  |

[0001628280-15-007847:notes:33]
Condensed Consolidating Statements of Cash Flows for the Six-Month Period Ended September 26, 2014

[0001628280-15-007847:notes:34]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 24,949 |  |  | $ | (200,703 | ) |  | $ | 481,999 |  |  | $ | — |  |  | $ | 306,245 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (73,455 | ) |  | (64,929 | ) |  | (11 | ) |  | (138,395 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | — |  |  | (38,082 | ) |  | — |  |  | (38,082 | ) |
| Investing cash flows from (to) affiliates | (833,951 | ) |  | (924,184 | ) |  | 255,111 |  |  | 1,503,024 |  |  | — |  |
| Other investing activities, net | — |  |  | (6,134 | ) |  | (22,721 | ) |  | — |  |  | (28,855 | ) |
| Net cash provided by (used in) investing activities | (833,951 | ) |  | (1,003,773 | ) |  | 129,379 |  |  | 1,503,013 |  |  | (205,332 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | — |  |  | — |  |  | 11,387 |  |  | — |  |  | 11,387 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (6,250 | ) |  | (888 | ) |  | (2,047 | ) |  | — |  |  | (9,185 | ) |
| Payments for repurchases of ordinary shares | (206,771 | ) |  | — |  |  | — |  |  | — |  |  | (206,771 | ) |
| Net proceeds from issuance of ordinary shares | 11,412 |  |  | — |  |  | — |  |  | — |  |  | 11,412 |  |
| Financing cash flows from (to) affiliates | 925,410 |  |  | 1,317,706 |  |  | (740,103 | ) |  | (1,503,013 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | 3,382 |  |  | — |  |  | 3,382 |  |
| Net cash provided by (used in) financing activities | 723,801 |  |  | 1,316,818 |  |  | (727,381 | ) |  | (1,503,013 | ) |  | (189,775 | ) |
| Effect of exchange rates on cash and cash equivalents | (83,374 | ) |  | (1,139 | ) |  | 93,999 |  |  | — |  |  | 9,486 |  |
| Net decrease (increase) in cash and cash equivalents | (168,575 | ) |  | 111,203 |  |  | (22,004 | ) |  | — |  |  | (79,376 | ) |
| Cash and cash equivalents, beginning of period | 638,714 |  |  | 210,462 |  |  | 744,552 |  |  | — |  |  | 1,593,728 |  |
| Cash and cash equivalents, end of period | $ | 470,139 |  |  | $ | 321,665 |  |  | $ | 722,548 |  |  | $ | — |  |  | $ | 1,514,352 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-15-007847:notes:35]
[same as prior period, unchanged from 0001628280-15-005450:notes:25]

[0001628280-15-007847:notes:36]
Acquisition of Mirror Controls International

[0001628280-15-007847:notes:37]
On June 29, 2015, the Company completed its acquisition of MCi, and paid approximately $555.2 million, net of $27.7 million of cash acquired. This acquisition expanded the Company's capabilities in the automotive market, and was included in the HRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill.

[0001628280-15-007847:notes:38]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of MCi (in thousands):

[0001628280-15-007847:notes:39]
| Current assets: |  |
| Accounts receivable | $ | 41,392 |  |
| Inventories | 19,169 |  |
| Other current assets | 2,790 |  |
| Total current assets | 63,351 |  |
| Property and equipment, net | 39,256 |  |
| Other assets | 942 |  |
| Intangibles | 280,000 |  |
| Goodwill | 290,478 |  |
| Total assets | $ | 674,027 |  |
| Current liabilities: |  |
| Accounts payable | $ | 28,002 |  |
| Accrued liabilities & other current liabilities | 20,677 |  |
| Total current liabilities | 48,679 |  |
| Other liabilities | 70,190 |  |
| Total aggregate purchase price | $ | 555,158 |  |

[0001628280-15-007847:notes:40]
The intangible assets of $280.0 million is comprised of customer relationships of $131.4 million and licenses and other intangibles assets of $148.6 million. Customer relationships are amortized over a weighted-average estimated useful life of 8 years and licenses and other intangibles assets are amortized over a weighted-average estimated useful life of 10 years. In addition to accounts receivable and inventories, the Company acquired $39.3 million of machinery and equipment and assumed $70.2 million of other liabilities primarily comprised of deferred tax liabilities. The Company incurred $6.7 million in acquisition-related costs related to the acquisition of MCi during the three-month period ended September 25, 2015.

[0001628280-15-007847:notes:41]
Acquisition of a facility from Alcatel-Lucent

[0001628280-15-007847:notes:42]
On July 1, 2015, the Company acquired an optical transport facility from Alcatel-Lucent for approximately $67.5 million, which expanded its capabilities in the telecom market and was included in the INS segment. The Company acquired primarily $55.0 million of inventory, $10.0 million of property and equipment primarily comprised of a building and land, and recorded goodwill and intangible assets for a customer relationship of $3.6 million and $2.1 million, respectively, and assumed $3.2 million in other net liabilities in connection with this acquisition. The customer relationship intangible will amortize over a weighted-average estimated useful life of 5 years. Acquisition-related costs for this acquisition were immaterial.

[0001628280-15-007847:notes:43]
Other business acquisitions

[0001628280-15-007847:notes:44]
Additionally, during the six-month period ended September 25, 2015, the Company completed three acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company.  Two of the acquired businesses expanded the Company’s capabilities in the medical devices market, particularly precision plastics and molding within the HRS segment, and the other strengthened capabilities in the household industrial market within the IEI segment. The Company paid $15.3 million, net of $0.1 million of cash held by the acquirees. The Company primarily acquired $2.0 million of property and equipment, assumed liabilities of $0.6 million and recorded goodwill and intangibles of $18.9 million.

[0001628280-15-007847:notes:45]
The results of operations for each of the acquisitions in fiscal year 2016 were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the amount of revenue and earnings of the acquisitions, collectively, were immaterial to the Company’s consolidated financial results for all periods presented. Proforma results of operations for the acquisitions in fiscal year 2016 have not been presented because the effects of the acquisitions, collectively, were immaterial to the Company’s consolidated financial results for all periods presented.

[0001628280-15-007847:notes:46]
[same as prior period, unchanged from 0001628280-15-005450:notes:27]

[0001628280-15-007847:notes:47]
On September 28, 2015, the Company completed the acquisition of NEXTracker and paid approximately $245.0 million net of cash acquired, with potential contingent consideration of up to a maximum of $97.2 million upon achievement of future revenue performance targets. The financial results of NEXTracker will be included in the consolidated financial statements of the Company as part of the IEI segment beginning in the third quarter of fiscal year 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-007847:notes:48]
COMMITMENTS AND CONTINGENCIES

[0001628280-15-007847:notes:49]
Litigation and other legal matters

[0001628280-15-007847:notes:50]
On December 11, 2013, Xilinx, Inc. (plaintiff) filed a lawsuit in Santa Clara County, California, Superior Court against Flextronics International Ltd.; Flextronics International USA, Inc.; and Flextronics Corporation (Case No. 113CV257431). The complaint asserted various claims, including fraud, negligent misrepresentation, breach of contract, and unfair competition, based on specific alleged incidents concerning our purchases and sales of Xilinx products. The plaintiff sought an unspecified amount of compensatory, statutory, punitive, and other forms of damages, injunctive relief, and attorneys' fees and costs. The parties settled this action in August 2015 and it has been dismissed; the terms of the settlement were not material to the Company’s financial statements as a whole.

[0001628280-15-007847:notes:51]
During the fourth quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice is for nine months of calendar year 2010 for an alleged amount of 50 million Brazilian reals (approximately $12 million based on the exchange rate as of September 25, 2015) plus interest. This assessment is in the second stage of the review process at the administrative level, and the Company plans to continue to vigorously oppose it as well as any future assessments. The Company is, however, unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on these matters for several years.

[0001628280-15-007847:notes:52]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately $100 million related to income and social contribution taxes, interest and penalties. The Company believes there is no legal basis for the assessment and expects that any losses are remote. The Company plans to vigorously defend itself through the administrative and judicial processes.

[0001628280-15-007847:notes:53]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-15-007847:notes:54]
[same as prior period, unchanged from 0001628280-15-005450:notes:36]

[0001628280-15-007847:notes:55]
[same as prior period, unchanged from 0001628280-15-005450:notes:37]

[0001628280-15-007847:notes:56]
|  | Three-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (55,437 | ) |  | $ | (109,456 | ) |  | $ | (164,893 | ) |  | $ | (22,124 | ) |  | $ | (97,452 | ) |  | $ | (119,576 | ) |
| Other comprehensive loss before reclassifications | (13,818 | ) |  | (30,267 | ) |  | (44,085 | ) |  | (2,965 | ) |  | (3,099 | ) |  | (6,064 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 8,274 |  |  | — |  |  | 8,274 |  |  | 532 |  |  | (2,584 | ) |  | (2,052 | ) |
| Net current-period other comprehensive loss | (5,544 | ) |  | (30,267 | ) |  | (35,811 | ) |  | (2,433 | ) |  | (5,683 | ) |  | (8,116 | ) |
| Ending balance | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |  | $ | (24,557 | ) |  | $ | (103,135 | ) |  | $ | (127,692 | ) |

[0001628280-15-007847:notes:57]
|  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |  | $ | (32,849 | ) |  | $ | (93,307 | ) |  | $ | (126,156 | ) |
| Other comprehensive gain (loss) before reclassifications | (14,419 | ) |  | (27,636 | ) |  | (42,055 | ) |  | (1,965 | ) |  | 2,008 |  |  | 43 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 21,704 |  |  | 152 |  |  | 21,856 |  |  | 10,257 |  |  | (11,836 | ) |  | (1,579 | ) |
| Net current-period other comprehensive gain (loss) | 7,285 |  |  | (27,484 | ) |  | (20,199 | ) |  | 8,292 |  |  | (9,828 | ) |  | (1,536 | ) |
| Ending balance | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |  | $ | (24,557 | ) |  | $ | (103,135 | ) |  | $ | (127,692 | ) |

[0001628280-15-007847:notes:58]
Net losses reclassified from accumulated other comprehensive loss during the six-month period ended September 25, 2015 relating to derivative instruments and other includes $20.7 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations.

[0001628280-15-007847:notes:59]
During the six-month period ended September 26, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. This loss includes the settlement of unrealized losses of $4.2 million on an insignificant defined benefit plan associated with the disposed facility offset by the release of cumulative foreign currency translation gains of $9.3 million, both of which have been reclassified from accumulated other comprehensive loss during the period. The loss on sale is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-15-007847:notes:60]
Additionally, net gains reclassified from accumulated other comprehensive loss during the six-month period ended September 26, 2014 includes $2.6 million in connection with cumulative translation gains related to the liquidation of a foreign entity, which is included in other charges (income), net in the condensed consolidated statement of operations.

[0001628280-15-007847:notes:61]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and six-month periods ended September 26, 2014, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-007847:notes:62]
BANK BORROWINGS AND LONG TERM DEBT

[0001628280-15-007847:notes:63]
Bank borrowings and long-term debt are as follows:

[0001628280-15-007847:notes:64]
|  | As of September 25, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 588,750 |  |  | $ | 592,500 |  |
| Term Loan, including current portion, due in installments through March 2019 | 468,750 |  |  | 475,000 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.750% Notes due June 2025 | 595,402 |  |  | — |  |
| Other | 13,248 |  |  | 16,233 |  |
| Total | $ | 2,666,150 |  |  | $ | 2,083,733 |  |

[0001628280-15-007847:notes:65]
The weighted-average interest rates for the Company’s long-term debt were 3.5% and 3.2% as of September 25, 2015 and March 31, 2015, respectively,

[0001628280-15-007847:notes:66]
On June 8, 2015, the Company issued $600 million of 4.750% Notes ("Notes") due June 15, 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%, and an effective rate of approximately 4.850%. The Company received net proceeds of approximately $595.3 million from the issuance which will be used for general corporate purposes.

[0001628280-15-007847:notes:67]
The Company incurred approximately $7.9 million of costs in conjunction with the issuance of the Notes. The issuance costs were capitalized and will be amortized over the life of the Notes.

[0001628280-15-007847:notes:68]
Interest on the Notes is payable semi-annually, commencing on December 15, 2015. The Notes are senior unsecured obligations of the Company, rank equally with all of the Company's other existing and future senior and unsecured debt obligations, and are guaranteed, jointly and severally, fully and unconditionally on an unsecured basis, by each of the Company's 100% owned subsidiaries that guarantees indebtedness under, or is a borrower under, the Company's Term Loan Agreement and Revolving Line of Credit.

[0001628280-15-007847:notes:69]
At any time prior to March 15, 2025, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus an applicable premium and accrued and unpaid interest, if any, to the applicable redemption date. Upon the occurrence of a change of control repurchase event (as defined in the Notes indenture), the Company must offer to repurchase the Notes at a repurchase price equal to 101% of the principal amount of the Notes repurchased, plus accrued and unpaid interest, if any, to the applicable repurchase date.

[0001628280-15-007847:notes:70]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; create, incur, issue, assume or guarantee any funded debt; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the agreement occurs or is continuing, the applicable trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare all of the Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of September 25, 2015, the Company was in compliance with the covenants in the indenture governing the Notes.

[0001628280-15-007847:notes:71]
In connection with the issuance of the Notes, the Company entered into a registration rights agreement under which it has agreed to consummate an offer registered with the Securities and Exchange Commission to issue new notes having terms substantially identical to the Notes (except that the new notes will not be subject to restrictions on transfer) in exchange for outstanding Notes. In some circumstances, the Company may be required to file a shelf registration statement to cover resale of the Notes. If the Company fails to satisfy these obligations, the Company may be required to pay additional interest to holders of the Notes under certain circumstances.

[0001628280-15-007847:notes:72]
Repayment of the Company’s long term debt outstanding as of September 25, 2015 is as follows:

[0001628280-15-007847:notes:73]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 30,000 |  |
| 2017 | 52,500 |  |
| 2018 | 52,500 |  |
| 2019 | 922,500 |  |
| 2020 | 500,000 |  |
| Thereafter | 1,108,650 |  |
| Total | $ | 2,666,150 |  |

[0001628280-15-007847:notes:74]
____________________________________________________________

[0001628280-15-007847:notes:75]
| (1) | Represents scheduled repayment for the remaining six-month period ending March 31, 2016. |

[0001628280-15-007847:notes:76]
On September 30, 2015, the Company amended its $2.0 billion credit facility to increase the $500 million term loan maturing in March 2019 by an additional borrowing of $100.0 million. All other terms remained unchanged.

[0001628280-15-007847:notes:77]
On October 1, 2015, the Company entered into a €50 million (approximately $56.0 million as of September 25, 2015), 5-year, unsecured, term-loan agreement due September 30, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-15-007847:notes:78]
[same as prior period, unchanged from 0001628280-15-005450:notes:56]

[0001628280-15-007847:notes:79]
[same as prior period, unchanged from 0001628280-15-005450:notes:57]

[0001628280-15-007847:notes:80]
The Company primarily enters into forward contracts and foreign currency swap contracts to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of September 25, 2015, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.9 billion as summarized below:

[0001628280-15-007847:notes:81]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 1,543,000 |  |  | — |  |  | $ | 241,709 |  |  | $ | — |  |
| EUR |  | 4,790 |  |  | 60,780 |  |  | 5,367 |  |  | 69,534 |  |
| HUF |  | 13,758,000 |  |  | — |  |  | 49,370 |  |  | — |  |
| ILS |  | 176,700 |  |  | — |  |  | 44,759 |  |  | — |  |
| MXN |  | 1,414,000 |  |  | — |  |  | 82,580 |  |  | — |  |
| MYR |  | 196,000 |  |  | — |  |  | 45,094 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 52,524 |  |  | 500 |  |
|  |  |  |  |  |  |  |  | 521,403 |  |  | 70,034 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 686,000 |  |  | — |  |  | 165,929 |  |
| CAD |  | 19,200 |  |  | 12,500 |  |  | 14,403 |  |  | 9,377 |  |
| CHF |  | 16,919 |  |  | 43,701 |  |  | 17,320 |  |  | 44,712 |  |
| CNY |  | 4,719,018 |  |  | 3,236,303 |  |  | 738,966 |  |  | 512,000 |  |
| DKK |  | 197,200 |  |  | 155,700 |  |  | 29,614 |  |  | 23,382 |  |
| EUR |  | 597,631 |  |  | 1,007,752 |  |  | 670,293 |  |  | 1,130,041 |  |
| GBP |  | 32,393 |  |  | 59,840 |  |  | 49,449 |  |  | 91,382 |  |
| HUF |  | 20,332,000 |  |  | 20,408,000 |  |  | 72,961 |  |  | 73,234 |  |
| ILS |  | 62,000 |  |  | 85,100 |  |  | 15,705 |  |  | 21,556 |  |
| JPY |  | 2,256,614 |  |  | 1,700,061 |  |  | 18,807 |  |  | 14,079 |  |
| MXN |  | 1,473,560 |  |  | 331,830 |  |  | 86,059 |  |  | 19,380 |  |
| MYR |  | 384,331 |  |  | 94,650 |  |  | 88,423 |  |  | 21,776 |  |
| SEK |  | 474,290 |  |  | 886,483 |  |  | 56,315 |  |  | 105,026 |  |
| SGD |  | 43,268 |  |  | 8,348 |  |  | 30,353 |  |  | 5,856 |  |
| Other |  | N/A |  |  | N/A |  |  | 91,499 |  |  | 52,884 |  |
|  |  |  |  |  |  |  |  | 1,980,167 |  |  | 2,290,614 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,501,570 |  |  | $ | 2,360,648 |  |

[0001628280-15-007847:notes:82]
As of September 25, 2015, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of September 25, 2015 and March 31, 2015, the Company also has included net deferred losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to the effective portion of changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses totaled $9.7 million as of September 25, 2015, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0001628280-15-007847:notes:83]
[same as prior period, unchanged from 0001628280-15-005450:notes:61]

[0001628280-15-007847:notes:84]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | September 25, 2015 |  | March 31, 2015 |  | Balance SheetLocation |  | September 25, 2015 |  | March 31, 2015 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 2,507 |  |  | $ | 2,896 |  |  | Other current liabilities |  | $ | 11,923 |  |  | $ | 19,729 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 17,119 |  |  | $ | 22,933 |  |  | Other current liabilities |  | $ | 14,581 |  |  | $ | 11,328 |  |

[0001628280-15-007847:notes:85]
[same as prior period, unchanged from 0001628280-15-005450:notes:63]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-007847:notes:86]
[same as prior period, unchanged from 0001628280-15-005450:notes:64]

[0001628280-15-007847:notes:87]
[same as prior period, unchanged from 0001628280-15-005450:notes:65]

[0001628280-15-007847:notes:88]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |
| Cost of sales | $ | 2,015 |  |  | $ | 1,868 |  |  | $ | 4,033 |  |  | $ | 3,478 |  |
| Selling, general and administrative expenses | 14,185 |  |  | 9,051 |  |  | 28,293 |  |  | 19,122 |  |
| Total share-based compensation expense | $ | 16,200 |  |  | $ | 10,919 |  |  | $ | 32,326 |  |  | $ | 22,600 |  |

[0001628280-15-007847:notes:89]
Total unrecognized compensation expense related to share options is not significant. As of September 25, 2015, the number of options outstanding and exercisable was 5.8 million at a weighted-average exercise price of $5.44 per share.

[0001628280-15-007847:notes:90]
During the six-month period ended September 25, 2015, the Company granted 6.1 million unvested share bonus awards under the Company's 2010 Equity Incentive Plan. Of this amount, approximately 5.2 million unvested share bonus awards have an average grant date price of $11.97 per share. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $14.96 per award and was calculated using a Monte Carlo simulation. The remaining 0.2 million of unvested shares bonus awards have an average grant date price of $12.10 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0001628280-15-007847:notes:91]
As of September 25, 2015, approximately 17.3 million unvested share bonus awards were outstanding, of which vesting for a targeted amount of 3.7 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.4 million based on the achievement levels of the respective conditions. During the six-month period ended September 25, 2015, 2.2 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2013, and 0.5 million shares vested in connection with the share bonus awards with market conditions granted in fiscal year 2012.

[0001628280-15-007847:notes:92]
As of September 25, 2015, total unrecognized compensation expense related to unvested share bonus awards is $122.5 million, net of estimated forfeitures, and will be recognized over a weighted-average remaining vesting period of 2.76 years. Approximately $20.0 million of the total unrecognized compensation cost, net of estimated forfeitures, is related to awards whereby vesting is contingent on meeting certain market conditions.

[0001628280-15-007847:notes:93]
Subsequent to September 25, 2015, in conjunction with the acquisition of NEXTracker Inc. ("NEXTracker"), the Company agreed to assume all of the outstanding, unvested restricted stock units and outstanding, unvested options to purchase shares of common stock of NEXTracker.


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-007847:notes:94]
[same as prior period, unchanged from 0001628280-15-005450:notes:71]

[0001628280-15-007847:notes:95]
[same as prior period, unchanged from 0001628280-15-005450:notes:72]

[0001628280-15-007847:notes:96]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 122,977 |  |  | $ | 138,903 |  |  | $ | 233,827 |  |  | $ | 312,790 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 563,333 |  |  | 585,760 |  |  | 564,417 |  |  | 586,497 |  |
| Basic earnings per share | 0.22 |  |  | 0.24 |  |  | 0.41 |  |  | 0.53 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 122,977 |  |  | $ | 138,903 |  |  | $ | 233,827 |  |  | $ | 312,790 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 563,333 |  |  | 585,760 |  |  | 564,417 |  |  | 586,497 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 6,322 |  |  | 10,111 |  |  | 8,871 |  |  | 12,089 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 569,655 |  |  | 595,871 |  |  | 573,288 |  |  | 598,586 |  |
| Diluted earnings per share | 0.22 |  |  | 0.23 |  |  | 0.41 |  |  | 0.52 |  |

[0001628280-15-007847:notes:97]
(1)         Options to purchase ordinary shares of 1.1 million and 7.0 million during the three-month periods ended September 25, 2015 and September 26, 2014, respectively, and share bonus awards of 5.3 million and 0.8 million for the three-month periods ended September 25, 2015 and September 26, 2014, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.

[0001628280-15-007847:notes:98]
(2)         Options to purchase ordinary shares of 1.2 million and 12.1 million during the six-month periods ended September 25, 2015 and September 26, 2014, respectively, and share bonus awards of 2.9 million and 0.4 million for the six-month periods ended September 25, 2015 and September 26, 2014, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-007847:notes:99]
[same as prior period, unchanged from 0001628280-15-005450:notes:75]

[0001628280-15-007847:notes:100]
[same as prior period, unchanged from 0001628280-15-005450:notes:76]

[0001628280-15-007847:notes:101]
[same as prior period, unchanged from 0001628280-15-005450:notes:77]

[0001628280-15-007847:notes:102]
[same as prior period, unchanged from 0001628280-15-005450:notes:78]

[0001628280-15-007847:notes:103]
[same as prior period, unchanged from 0001628280-15-005450:notes:79]

[0001628280-15-007847:notes:104]
[same as prior period, unchanged from 0001628280-15-005450:notes:80]

[0001628280-15-007847:notes:105]
[same as prior period, unchanged from 0001628280-15-005450:notes:81]

[0001628280-15-007847:notes:106]
[same as prior period, unchanged from 0001628280-15-005450:notes:82]

[0001628280-15-007847:notes:107]
[same as prior period, unchanged from 0001628280-15-005450:notes:83]

[0001628280-15-007847:notes:108]
During the three-month period ended September 26, 2014, the Company accrued for certain contingent consideration in connection with its business acquisitions, which is measured at fair value based on internal cash flow models and other inputs. During the six-month period ended September 25, 2015, no additions to accrual, payments or fair value adjustments were incurred. The following table summarizes the activities related to contingent consideration:

[0001628280-15-007847:notes:109]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |
| Beginning balance | $ | 4,500 |  |  | $ | 11,300 |  |  | $ | 4,500 |  |  | $ | 11,300 |  |
| Additions to accrual | — |  |  | 4,500 |  |  | — |  |  | 4,500 |  |
| Payments | — |  |  | — |  |  | — |  |  | — |  |
| Fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |
| Ending balance | $ | 4,500 |  |  | $ | 15,800 |  |  | $ | 4,500 |  |  | $ | 15,800 |  |

[0001628280-15-007847:notes:110]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the three-month and six-month periods ended September 25, 2015 and September 26, 2014.

[0001628280-15-007847:notes:111]
There were no transfers between levels in the fair value hierarchy during the three-month and six-month periods ended September 25, 2015 and September 26, 2014.

[0001628280-15-007847:notes:112]
[same as prior period, unchanged from 0001628280-15-005450:notes:87]

[0001628280-15-007847:notes:113]
[same as prior period, unchanged from 0001628280-15-005450:notes:88]

[0001628280-15-007847:notes:114]
|  | Fair Value Measurements as of September 25, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 447,217 |  |  | $ | — |  |  | $ | 447,217 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 537,619 |  |  | 537,619 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 19,626 |  |  | — |  |  | 19,626 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 8,939 |  |  | 37,676 |  |  | — |  |  | 46,615 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (26,504 | ) |  | $ | — |  |  | $ | (26,504 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |
|  | Fair Value Measurements as of March 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 674,859 |  |  | $ | — |  |  | $ | 674,859 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 600,672 |  |  | 600,672 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 25,829 |  |  | — |  |  | 25,829 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,068 |  |  | 37,041 |  |  | — |  |  | 46,109 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (31,057 | ) |  | $ | — |  |  | $ | (31,057 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (4,500 | ) |  | (4,500 | ) |

[0001628280-15-007847:notes:115]
[same as prior period, unchanged from 0001628280-15-005450:notes:90]

[0001628280-15-007847:notes:116]
[same as prior period, unchanged from 0001628280-15-005450:notes:91]

[0001628280-15-007847:notes:117]
|  | As of September 25, 2015 |  | As of March 31, 2015 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 588,750 |  |  | $ | 586,177 |  |  | $ | 592,500 |  |  | $ | 582,131 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 468,750 |  |  | 466,992 |  |  | 475,000 |  |  | 465,500 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 520,625 |  |  | 500,000 |  |  | 523,750 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 502,750 |  |  | 500,000 |  |  | 543,150 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,402 |  |  | 585,000 |  |  | — |  |  | — |  |  | Level 1 |
| Total | $ | 2,652,902 |  |  | $ | 2,661,544 |  |  | $ | 2,067,500 |  |  | $ | 2,114,531 |  |  |  |

[0001628280-15-007847:notes:118]
[same as prior period, unchanged from 0001628280-15-005450:notes:93]


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-15-007847:notes:119]
[same as prior period, unchanged from 0001628280-15-005450:notes:94]

[0001628280-15-007847:notes:120]
[same as prior period, unchanged from 0001628280-15-005450:notes:95]

[0001628280-15-007847:notes:121]
Flextronics International Ltd. ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following reportable segments: High Reliability Solutions ("HRS"), which is comprised of medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group ("CTG"), which includes mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computing, tablets, and printers; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions ("INS"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables our OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0001628280-15-007847:notes:122]
[same as prior period, unchanged from 0001628280-15-005450:notes:97]

[0001628280-15-007847:notes:123]
[same as prior period, unchanged from 0001628280-15-005450:notes:98]

[0001628280-15-007847:notes:124]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2015 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 25, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016.

[0001628280-15-007847:notes:125]
The first quarters for fiscal year 2016 and fiscal year 2015 ended on June 26, 2015 and June 27, 2014, respectively. The second quarters for fiscal year 2016 and fiscal year 2015 ended on September 25, 2015 and September 26, 2014, respectively.

[0001628280-15-007847:notes:126]
[same as prior period, unchanged from 0001628280-15-005450:notes:101]

[0001628280-15-007847:notes:127]
[same as prior period, unchanged from 0001628280-15-005450:notes:102]

[0001628280-15-007847:notes:128]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued new guidance to simplify the accounting for adjustments made to provisional amounts recognized in a business combination.  Under previous guidance, the acquirer retrospectively adjusted the provisional amounts recognized at the acquisition date with a corresponding adjustment to goodwill, and would have to revise comparative information for prior periods presented in financial statements as needed. The update requires an entity to present separately on the face of the income statement or disclose in the notes the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. The new guidance is effective for the Company beginning fiscal year 2017, with early application permitted. The Company is currently assessing the impact of this update and the timing of adoption.

[0001628280-15-007847:notes:129]
In July 2015, the FASB issued new guidance to simplify the measurement of inventory, by requiring that inventory be measured at the lower of cost and net realizable value.  Prior to the issuance of the new guidance, inventory was measured at the lower of cost or market. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this update and the timing of adoption.

[0001628280-15-007847:notes:130]
[same as prior period, unchanged from 0001628280-15-005450:notes:103]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-15-007847:notes:131]
[same as prior period, unchanged from 0001628280-15-005450:notes:104]

[0001628280-15-007847:notes:132]
During the three-month and six-month periods ended September 25, 2015, the Company incurred expenses of $1.6 million related to a refund in connection with the disposition of a certain manufacturing facility in Western Europe.

[0001628280-15-007847:notes:133]
During the six-month period ended September 26, 2014, an amendment to a customer contract to reimburse a customer for certain performance provisions was executed which included the removal of a $55.0 million contractual obligation recognized during fiscal year 2014. Accordingly, the Company reversed the charge recognized in fiscal year 2014 with a corresponding credit to other charges (income), net in the consolidated statement of operations.

[0001628280-15-007847:notes:134]
Further, during the six-month period ended September 26, 2014, the Company recognized a loss of $11.0 million in connection with the disposition of a manufacturing facility in Western Europe. The Company received $11.5 million in cash for the sale of $27.2 million in net assets of the facility. The loss also includes $4.6 million of transaction costs, partially offset by a credit of $9.3 million for the release of cumulative foreign translation gains triggered by the disposition.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-15-007847:notes:135]
[same as prior period, unchanged from 0001628280-15-005450:notes:107]

[0001628280-15-007847:notes:136]
|  | As of September 25, 2015 |  | As of March 31, 2015 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 279,204 |  |  | $ | (93,401 | ) |  | $ | 185,803 |  |  | $ | 133,853 |  |  | $ | (80,506 | ) |  | $ | 53,347 |  |
| Licenses and other intangibles | 190,742 |  |  | (22,066 | ) |  | 168,676 |  |  | 39,985 |  |  | (11,788 | ) |  | 28,197 |  |
| Total | $ | 469,946 |  |  | $ | (115,467 | ) |  | $ | 354,479 |  |  | $ | 173,838 |  |  | $ | (92,294 | ) |  | $ | 81,544 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001628280-15-007847:notes:137]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the six-month period ended September 25, 2015:

[0001628280-15-007847:notes:138]
|  |  | HRS |  | CTG |  | IEI |  | INS |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 93,138 |  |  | $ | 68,234 |  |  | $ | 64,221 |  |  | $ | 108,038 |  |  | $ | 333,631 |  |
| Additions (1) |  | 292,608 |  |  | — |  |  | 2,982 |  |  | 3,575 |  |  | 299,165 |  |
| Purchase accounting adjustments (2) |  | 125 |  |  | — |  |  | — |  |  | — |  |  | 125 |  |
| Foreign currency translation adjustments |  | (5,562 | ) |  | — |  |  | — |  |  | — |  |  | (5,562 | ) |
| Balance, end of the period |  | $ | 380,309 |  |  | $ | 68,234 |  |  | $ | 67,203 |  |  | $ | 111,613 |  |  | $ | 627,359 |  |

[0001628280-15-007847:notes:139]
| (1) | The goodwill generated from the Company’s business combinations completed during the six-month period ended September 25, 2015 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0001628280-15-007847:notes:140]
[same as prior period, unchanged from 0001628280-15-005450:notes:112]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-15-007847:notes:141]
[same as prior period, unchanged from 0001628280-15-005450:notes:113]

[0001628280-15-007847:notes:142]
|  | As of September 25, 2015 |  | As of March 31, 2015 |
|  | (In thousands) |
| Raw materials | $ | 2,265,927 |  |  | $ | 2,330,428 |  |
| Work-in-progress | 669,280 |  |  | 557,786 |  |
| Finished goods | 626,119 |  |  | 600,538 |  |
|  | $ | 3,561,326 |  |  | $ | 3,488,752 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-15-007847:notes:143]
[same as prior period, unchanged from 0001628280-15-005450:notes:115]

[0001628280-15-007847:notes:144]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Integrated Network Solutions | $ | 2,204,966 |  |  | $ | 2,340,707 |  |  | $ | 4,171,528 |  |  | $ | 4,781,133 |  |
| Consumer Technology Group | 2,011,089 |  |  | 2,209,543 |  |  | 3,576,052 |  |  | 4,431,683 |  |
| Industrial & Emerging Industries | 1,145,842 |  |  | 1,097,202 |  |  | 2,275,981 |  |  | 2,221,668 |  |
| High Reliability Solutions | 954,865 |  |  | 881,065 |  |  | 1,859,449 |  |  | 1,736,778 |  |
|  | $ | 6,316,762 |  |  | $ | 6,528,517 |  |  | $ | 11,883,010 |  |  | $ | 13,171,262 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Integrated Network Solutions | $ | 65,758 |  |  | $ | 57,643 |  |  | $ | 122,822 |  |  | $ | 130,354 |  |
| Consumer Technology Group | 41,170 |  |  | 53,336 |  |  | 80,013 |  |  | 83,200 |  |
| Industrial & Emerging Industries | 32,268 |  |  | 35,582 |  |  | 61,268 |  |  | 82,906 |  |
| High Reliability Solutions | 71,199 |  |  | 48,801 |  |  | 131,085 |  |  | 102,944 |  |
| Corporate and Other | (14,075 | ) |  | (11,952 | ) |  | (39,786 | ) |  | (32,805 | ) |
| Total segment income | 196,320 |  |  | 183,410 |  |  | 355,402 |  |  | 366,599 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16,127 |  |  | 8,232 |  |  | 23,798 |  |  | 15,183 |  |
| Stock-based compensation | 16,200 |  |  | 10,919 |  |  | 32,326 |  |  | 22,600 |  |
| Other charges (income), net | 1,678 |  |  | (2,584 | ) |  | 1,842 |  |  | (46,593 | ) |
| Interest and other, net | 22,035 |  |  | 12,506 |  |  | 38,540 |  |  | 31,143 |  |
| Income before income taxes | $ | 140,280 |  |  | $ | 154,337 |  |  | $ | 258,896 |  |  | $ | 344,266 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001628280-15-007847:notes:145]
[same as prior period, unchanged from 0001628280-15-005450:notes:117]

[0001628280-15-007847:notes:146]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2016 (1) | $ | 30,583 |  |
| 2017 | 54,734 |  |
| 2018 | 48,934 |  |
| 2019 | 44,593 |  |
| 2020 | 39,971 |  |
| Thereafter | 135,664 |  |
| Total amortization expense | $ | 354,479 |  |

[0001628280-15-007847:notes:147]
| (1) | Represents estimated amortization for the remaining six-month period ending March 31, 2016. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-007847:notes:148]
[same as prior period, unchanged from 0001628280-15-005450:notes:120]

[0001628280-15-007847:notes:149]
The Company has four reportable segments: HRS, CTG, IEI, and INS. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0001628280-15-007847:notes:150]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, other charges (income), net and interest and other, net.

[0001628280-15-007847:notes:151]
[same as prior period, unchanged from 0001628280-15-005450:notes:123]

[0001628280-15-007847:notes:152]
[same as prior period, unchanged from 0001628280-15-005450:notes:124]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-007847:notes:153]
[same as prior period, unchanged from 0001628280-15-005450:notes:125]

[0001628280-15-007847:notes:154]
[same as prior period, unchanged from 0001628280-15-005450:notes:126]

[0001628280-15-007847:notes:155]
Goodwill and Other Intangible Assets

[0001628280-15-007847:notes:156]
The gross carrying amounts of intangible assets are removed when the recorded amounts have been fully amortized.  During the six-month period ended September 25, 2015, the total value of intangibles assets increased primarily in connection with the Company's acquisition of Mirror Controls International ("MCi"). This acquisition contributed an additional $131.4 million in customer-related intangible assets, and $148.6 million in licenses and other intangibles assets. See note 12 for additional information. The estimated future annual amortization expense for intangible assets is as follows:

[0001628280-15-007847:notes:157]
[same as prior period, unchanged from 0001628280-15-005450:notes:129]

[0001628280-15-007847:notes:158]
Other current assets includes approximately $537.6 million and $600.7 million as of September 25, 2015 and March 31, 2015, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0001628280-15-007847:notes:159]
In connection with a prior acquisition, the Company entered into an agreement with a customer and a third party banking institution to procure certain manufacturing equipment that was financed by the third party banking institution, acting as an agent of the customer.  The manufacturing equipment was used exclusively for the benefit of this customer.  The Company cannot be required to pay cash by either the customer or the third party banking institution.

[0001628280-15-007847:notes:160]
During fiscal year 2015, the Company ceased manufacturing of the product related to the financed equipment.  As a result, the Company as an agent on behalf of the customer is in the process of dispositioning the equipment and forwarding the proceeds to the third party banking institution reducing the outstanding obligation. Included in other current assets is the value of the certain assets purchased on behalf of a customer and financed by a third party banking institution in the amounts of $83.7 million and $169.2 million as of September 25, 2015 and March 31, 2015, respectively.  Additionally, other current assets as of September 25, 2015 includes an amount of $73.6 million relating to these assets that have been sold to third parties but not yet collected.

[0001628280-15-007847:notes:161]
During the six-month period ended September 25, 2015, the Company disposed of all of the assets and the remaining amount of $83.7 million  reflects the shortfall between the original purchase price of these assets and the amount recovered by selling them to third parties. The Company expects this amount to be funded by the customer, which in turn would be paid back to the third party banking institution.

[0001628280-15-007847:notes:162]
[same as prior period, unchanged from 0001628280-15-005450:notes:134]

[0001628280-15-007847:notes:163]
Other current liabilities includes customer working capital advances of $147.1 million and $189.6 million, customer-related accruals of $506.2 million and $454.8 million, and deferred revenue of $278.4 million and $272.6 million as of September 25, 2015 and March 31, 2015, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Other current liabilities also includes the outstanding balance due to the third party banking institution related to the financed equipment discussed above, that amounted to $161.5 million and $197.7 million as of September 25, 2015 and March 31, 2015, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001628280-15-007847:notes:164]
[same as prior period, unchanged from 0001628280-15-005450:notes:136]

[0001628280-15-007847:notes:165]
[same as prior period, unchanged from 0001628280-15-005450:notes:137]

[0001628280-15-007847:notes:166]
[same as prior period, unchanged from 0001628280-15-005450:notes:138]

[0001628280-15-007847:notes:167]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $700.0 million for the Global Program, of which $600.0 million is committed and $100.0 million is uncommitted, and $265.0 million for the North American Program, of which $225.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0001628280-15-007847:notes:168]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and six-month periods ended September 25, 2015 and September 26, 2014 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0001628280-15-007847:notes:169]
As of September 25, 2015, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $890.0 million and deferred purchase price receivables of approximately $537.6 million. As of March 31, 2015, approximately $1.3 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $740.7 million and deferred purchase price receivables of approximately $600.7 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of September 25, 2015 and March 31, 2015, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0001628280-15-007847:notes:170]
As of September 25, 2015 and March 31, 2015, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0001628280-15-007847:notes:171]
For the six-month periods ended September 25, 2015 and September 26, 2014, cash flows from sales of receivables under the ABS Programs consisted of approximately $2.4 billion and $2.1 billion, for transfers of receivables, respectively (of which approximately $255.3 million and $76.5 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0001628280-15-007847:notes:172]
[same as prior period, unchanged from 0001628280-15-005450:notes:144]

[0001628280-15-007847:notes:173]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $339.1 million and $485.6 million as of September 25, 2015 and March 31, 2015, respectively. For the six-month periods ended September 25, 2015 and September 26, 2014, total accounts receivable sold to certain third party banking institutions was approximately $1.2 billion and $2.3 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001628280-15-007847:notes:174]
[same as prior period, unchanged from 0001628280-15-005450:notes:146]

[0001628280-15-007847:notes:175]
During the three-month and six-month periods ended September 25, 2015, the Company repurchased 12.8 million shares at an aggregate purchase price of $138.0 million, and 20.6 million shares at an aggregate purchase price of $232.4 million, respectively, and retired all of these shares.

[0001628280-15-007847:notes:176]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Extraordinary General Meeting held on August 20, 2015. As of September 25, 2015, shares in the aggregate amount of $422.5 million were available to be repurchased under the current plan.
