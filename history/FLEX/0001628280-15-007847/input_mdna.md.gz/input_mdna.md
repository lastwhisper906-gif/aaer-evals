# FLEX MD&A — 0001628280-15-007847


## mdna

[0001628280-15-007847:mdna:1]
[same as prior period, unchanged from 0001628280-15-005450:mdna:1]

[0001628280-15-007847:mdna:2]
Unless otherwise specifically stated, references in this report to “Flex,” “the Company,” “we,” “us,” “our” and similar terms mean Flextronics International Ltd. and its subsidiaries.

[0001628280-15-007847:mdna:3]
[same as prior period, unchanged from 0001628280-15-005450:mdna:3]

[0001628280-15-007847:mdna:4]
We are a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scale; from conceptual sketch to full-scale production. We design, build, ship, and service complete packaged consumer electronics and industrial products for original equipment manufacturers (“OEMs”), through our activities in the following segments: High Reliability Solutions (“HRS”), which is comprised of our medical business including medical equipment, disposables, drug delivery, and diagnostics; our automotive business, including automotive electronics, automotive lighting, and power electronics; and our defense and aerospace businesses focused on defense, civil aviation, and homeland security; Consumer Technology Group (“CTG”), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics, digital health, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computing, tablets and printers; Industrial and Emerging Industries (“IEI”), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Integrated Network Solutions (“INS”), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video network; server and storage platforms for both enterprise and cloud based deployments; next generation storage and security appliance products and rack level solutions, converged infrastructure and software-defined product solutions.

[0001628280-15-007847:mdna:5]
[same as prior period, unchanged from 0001628280-15-005450:mdna:5]

[0001628280-15-007847:mdna:6]
[same as prior period, unchanged from 0001628280-15-005450:mdna:6]

[0001628280-15-007847:mdna:7]
[same as prior period, unchanged from 0001628280-15-005450:mdna:7]

[0001628280-15-007847:mdna:8]
34

[0001628280-15-007847:mdna:9]
We use a portfolio approach to manage our extensive service offerings. As our OEM customers change the way they go to market, we are able to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet a specific customer's supply chain solutions needs across all of the markets we serve and earn a return on our invested capital above the weighted-average cost of that capital.

[0001628280-15-007847:mdna:10]
During the past few years we have made significant efforts to evolve our long-term portfolio towards a higher mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. During the last two fiscal years we launched several programs broadly across our portfolio of services and in some instances we deployed certain new technologies. Some of these programs have started to yield better results, as demonstrated by our segment operating margin improvement while our sales decreased compared to the prior year. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers.

[0001628280-15-007847:mdna:11]
[same as prior period, unchanged from 0001628280-15-005450:mdna:10]

[0001628280-15-007847:mdna:12]
We are one of the world's largest providers of global supply chain solutions, with revenues of $11.9 billion for the six-month period ended September 25, 2015 and $26.1 billion in fiscal year 2015. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0001628280-15-007847:mdna:13]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Net sales: |  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  |  | (In thousands) |
| China |  | $ | 2,340,475 |  |  | 37 | % |  | $ | 2,476,736 |  |  | 38 | % |  | $ | 4,176,663 |  |  | 35 | % |  | $ | 5,026,967 |  |  | 38 | % |
| Mexico |  | 943,624 |  |  | 15 | % |  | 876,339 |  |  | 13 | % |  | 1,850,503 |  |  | 16 | % |  | 1,725,937 |  |  | 13 | % |
| U.S. |  | 627,757 |  |  | 10 | % |  | 689,737 |  |  | 11 | % |  | 1,270,346 |  |  | 11 | % |  | 1,444,457 |  |  | 11 | % |
| Malaysia |  | 566,919 |  |  | 9 | % |  | 560,849 |  |  | 9 | % |  | 1,112,289 |  |  | 9 | % |  | 1,101,961 |  |  | 8 | % |
| Brazil |  | 498,697 |  |  | 8 | % |  | 545,384 |  |  | 8 | % |  | 982,827 |  |  | 8 | % |  | 1,142,031 |  |  | 9 | % |
| Other |  | 1,339,290 |  |  | 21 | % |  | 1,379,472 |  |  | 21 | % |  | 2,490,382 |  |  | 21 | % |  | 2,729,909 |  |  | 21 | % |
|  |  | $ | 6,316,762 |  |  |  |  |  | $ | 6,528,517 |  |  |  |  |  | $ | 11,883,010 |  |  |  |  |  | $ | 13,171,262 |  |  |  |  |

[0001628280-15-007847:mdna:14]
|  |  | As of |  | As of |
| Property and equipment, net: |  | September 25, 2015 |  | March 31, 2015 |
|  |  | (In thousands) |
| China |  | $ | 810,340 |  |  | 37 | % |  | $ | 776,914 |  |  | 37 | % |
| Mexico |  | 390,167 |  |  | 18 | % |  | 364,435 |  |  | 17 | % |
| U.S |  | 316,337 |  |  | 14 | % |  | 314,613 |  |  | 15 | % |
| Malaysia |  | 162,560 |  |  | 7 | % |  | 165,779 |  |  | 8 | % |
| Brazil |  | 108,577 |  |  | 5 | % |  | 103,496 |  |  | 5 | % |
| Other |  | 430,049 |  |  | 19 | % |  | 366,930 |  |  | 18 | % |
|  |  | $ | 2,218,030 |  |  |  |  |  | $ | 2,092,167 |  |  |  |  |

[0001628280-15-007847:mdna:15]
[same as prior period, unchanged from 0001628280-15-005450:mdna:14]

[0001628280-15-007847:mdna:16]
[same as prior period, unchanged from 0001628280-15-005450:mdna:66]

[0001628280-15-007847:mdna:17]
[same as prior period, unchanged from 0001628280-15-005450:mdna:16]

[0001628280-15-007847:mdna:18]
[same as prior period, unchanged from 0001628280-15-005450:mdna:17]

[0001628280-15-007847:mdna:19]
[same as prior period, unchanged from 0001628280-15-005450:mdna:18]

[0001628280-15-007847:mdna:20]
[same as prior period, unchanged from 0001628280-15-005450:mdna:19]

[0001628280-15-007847:mdna:21]
[same as prior period, unchanged from 0001628280-15-005450:mdna:20]

[0001628280-15-007847:mdna:22]
[same as prior period, unchanged from 0001628280-15-005450:mdna:21]

[0001628280-15-007847:mdna:23]
[same as prior period, unchanged from 0001628280-15-005450:mdna:22]

[0001628280-15-007847:mdna:24]
[same as prior period, unchanged from 0001628280-15-005450:mdna:23]

[0001628280-15-007847:mdna:25]
[same as prior period, unchanged from 0001628280-15-005450:mdna:24]

[0001628280-15-007847:mdna:26]
[same as prior period, unchanged from 0001628280-15-005450:mdna:25]

[0001628280-15-007847:mdna:27]
[same as prior period, unchanged from 0001628280-15-005450:mdna:26]

[0001628280-15-007847:mdna:28]
[same as prior period, unchanged from 0001628280-15-005450:mdna:27]

[0001628280-15-007847:mdna:29]
[same as prior period, unchanged from 0001628280-15-005450:mdna:28]

[0001628280-15-007847:mdna:30]
[same as prior period, unchanged from 0001628280-15-005450:mdna:29]

[0001628280-15-007847:mdna:31]
[same as prior period, unchanged from 0001628280-15-005450:mdna:30]

[0001628280-15-007847:mdna:32]
[same as prior period, unchanged from 0001628280-15-005450:mdna:31]

[0001628280-15-007847:mdna:33]
[same as prior period, unchanged from 0001628280-15-005450:mdna:32]

[0001628280-15-007847:mdna:34]
36

[0001628280-15-007847:mdna:35]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.7 |  |  | 94.2 |  |  | 93.7 |  |  | 94.2 |  |
| Gross profit | 6.3 |  |  | 5.8 |  |  | 6.3 |  |  | 5.8 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.1 |  |  | 3.6 |  |  | 3.1 |  |
| Intangible amortization | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Interest and other, net | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.2 |  |
| Other charges (income), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | (0.3 | ) |
| Income before income taxes | 2.3 |  |  | 2.4 |  |  | 2.2 |  |  | 2.7 |  |
| Provision for income taxes | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Net income | 2.0 | % |  | 2.2 | % |  | 2.0 | % |  | 2.5 | % |

[0001628280-15-007847:mdna:36]
[same as prior period, unchanged from 0001628280-15-005450:mdna:34]

[0001628280-15-007847:mdna:37]
The following table sets forth our net sales by segment and their relative percentages. Historical information has been recast to reflect realignment of customers and/or products between segments to ensure comparability:

[0001628280-15-007847:mdna:38]
|  |  | Three-Month Periods Ended |  | Six-Month Periods Ended |
| Segments: |  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  |  | (In thousands) |
| INS |  | $ | 2,204,966 |  |  | 35 | % |  | $ | 2,340,707 |  |  | 36 | % |  | $ | 4,171,528 |  |  | 35 | % |  | $ | 4,781,133 |  |  | 36 | % |
| CTG |  | 2,011,089 |  |  | 32 | % |  | 2,209,543 |  |  | 34 | % |  | 3,576,052 |  |  | 30 | % |  | 4,431,683 |  |  | 34 | % |
| IEI |  | 1,145,842 |  |  | 18 | % |  | 1,097,202 |  |  | 17 | % |  | 2,275,981 |  |  | 19 | % |  | 2,221,668 |  |  | 17 | % |
| HRS |  | 954,865 |  |  | 15 | % |  | 881,065 |  |  | 13 | % |  | 1,859,449 |  |  | 16 | % |  | 1,736,778 |  |  | 13 | % |
|  |  | $ | 6,316,762 |  |  |  |  |  | $ | 6,528,517 |  |  |  |  |  | $ | 11,883,010 |  |  |  |  |  | $ | 13,171,262 |  |  |  |  |

[0001628280-15-007847:mdna:39]
Net sales during the three-month period ended September 25, 2015 totaled $6.3 billion, representing a decrease of approximately $0.2 billion, or 3.2% from $6.5 billion during the three-month period ended September 26, 2014. The decline in net sales was primarily due to $0.2 billion and $0.1 billion decreases in our CTG and INS segments, respectively. The decline in CTG was due to a decline in demand from our largest customer in our mobile business. The decline in INS was the result of broad declines in our server and storage, as well as our telecom and networking businesses. These decreases were offset by small increases of $73.8 million in our HRS segment and $48.6 million in our IEI segment, attributable to higher sales to our automotive, medical, appliances and energy customers. Net sales decreased $0.1 billion to $3.2 billion in Asia, $47.3 million to $2.1 billion in the Americas and $25.1 million to $1.1 billion in Europe, respectively.

[0001628280-15-007847:mdna:40]
Net sales during the six-month period ended September 25, 2015 totaled $11.9 billion, representing a decrease of approximately $1.3 billion, or 9.8% from $13.2 billion during the six-month period ended September 26, 2014. The decline in net sales was primarily due to softness in demand from our CTG and INS segments, primarily as a result of the same drivers listed above. These decreases were offset by increases in our HRS and IEI segments attributable to an increase across multiple product categories and customers, most notably in our medical, automotive, energy, and household businesses. Net sales decreased $0.9 billion to $5.8 billion in Asia, $0.2 billion to $4.1 billion in the Americas and $0.2 billion to $2.0 billion in Europe, respectively.

[0001628280-15-007847:mdna:41]
Our ten largest customers, during the three-month and six-month periods ended September 25, 2015, accounted for approximately 47% and 46% of net sales, respectively. Motorola Mobility (including net sales from its parent Lenovo) accounted for more than 10% of net sales during the three and six-month periods ended September 25, 2015.

[0001628280-15-007847:mdna:42]
37

[0001628280-15-007847:mdna:43]
Our ten largest customers, during the three-month and six-month periods ended September 26, 2014, accounted for approximately 51% and 52% of net sales, respectively. Motorola Mobility (including net sales from its former parent Google at that time) accounted for more than 10% of net sales during the three-month and six-month periods ended September 26, 2014.

[0001628280-15-007847:mdna:44]
[same as prior period, unchanged from 0001628280-15-005450:mdna:39]

[0001628280-15-007847:mdna:45]
[same as prior period, unchanged from 0001628280-15-005450:mdna:40]

[0001628280-15-007847:mdna:46]
Gross profit during the three-month period ended September 25, 2015 increased $19.8 million to $396.9 million, or 6.3% of net sales, from $377.1 million, or 5.8% of net sales, during the three-month period ended September 26, 2014. Gross profit during the six-month period ended September 25, 2015 decreased $8.6 million to $749.3 million, or 6.3% of net sales from $757.9 million, or 5.8% of net sales, during the six-month period ended September 26, 2014. The decline in net sales due to the reduced demand from our CTG and INS segments for both the three-month and six-month periods ended September 25, 2015, noted above negatively impacted gross profit, however this decline was offset by overall higher margins due to mix shifts in our business as further explained below.

[0001628280-15-007847:mdna:47]
Gross margins improved 50 basis points in both the three-month and six-month periods ended September 25, 2015 compared to that of the three-month and six-month periods ended September 26, 2014. Our overall improved margins are the result of our strategic objective to move our long-term portfolio towards a greater mix of businesses that have longer product lifecycles and higher margins across all our segments. The increase from the prior three and six month periods are due primarily to increased profitability in our HRS and INS segments.  See below for further discussion on segment profitability.

[0001628280-15-007847:mdna:48]
Segment Income

[0001628280-15-007847:mdna:49]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock‑based compensation, other charges (income), net and interest and other, net. A portion of amortization and depreciation is allocated to the respective segment together with other general corporate research and development and administrative expenses.

[0001628280-15-007847:mdna:50]
The following table sets forth segment income and margins. Historical information has been recast to reflect realignment of customers and/or products between segments:

[0001628280-15-007847:mdna:51]
38

[0001628280-15-007847:mdna:52]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |  |  |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INS | $ | 65,758 |  |  | 3.0 | % |  | $ | 57,643 |  |  | 2.5 | % |  | $ | 122,822 |  |  | 2.9 | % |  | $ | 130,354 |  |  | 2.7 | % |
| CTG | 41,170 |  |  | 2.0 | % |  | 53,336 |  |  | 2.4 | % |  | 80,013 |  |  | 2.2 | % |  | 83,200 |  |  | 1.9 | % |
| IEI | 32,268 |  |  | 2.8 | % |  | 35,582 |  |  | 3.2 | % |  | 61,268 |  |  | 2.7 | % |  | 82,906 |  |  | 3.7 | % |
| HRS | 71,199 |  |  | 7.5 | % |  | 48,801 |  |  | 5.5 | % |  | 131,085 |  |  | 7.0 | % |  | 102,944 |  |  | 5.9 | % |
| Corporate and Other | (14,075 | ) |  |  |  | (11,952 | ) |  |  |  | (39,786 | ) |  |  |  | (32,805 | ) |  |  |
| Total segment income | 196,320 |  |  | 3.1 | % |  | 183,410 |  |  | 2.8 | % |  | 355,402 |  |  | 3.0 | % |  | 366,599 |  |  | 2.8 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 16,127 |  |  |  |  | 8,232 |  |  |  |  | 23,798 |  |  |  |  | 15,183 |  |  |  |
| Stock-based compensation | 16,200 |  |  |  |  | 10,919 |  |  |  |  | 32,326 |  |  |  |  | 22,600 |  |  |  |
| Other charges (income), net | 1,678 |  |  |  |  | (2,584 | ) |  |  |  | 1,842 |  |  |  |  | (46,593 | ) |  |  |
| Interest and other, net | 22,035 |  |  |  |  | 12,506 |  |  |  |  | 38,540 |  |  |  |  | 31,143 |  |  |  |
| Income before income taxes | $ | 140,280 |  |  |  |  | $ | 154,337 |  |  |  |  | $ | 258,896 |  |  |  |  | $ | 344,266 |  |  |  |

[0001628280-15-007847:mdna:53]
INS segment margin increased 50 and 20 basis points, respectively, for the three-month and six-month periods ended September 25, 2015, from 2.5% and 2.7% during the three-month and six-month periods ended September 26, 2014, respectively. The improvements are driven by improved operational execution and higher utilization levels across multiple customers and facilities.

[0001628280-15-007847:mdna:54]
CTG segment margin decreased 40 basis points for the three-month period ended September 25, 2015, from 2.4% during the three-month period ended September 26, 2014, primarily driven by change in product mix as well as cost incurred for certain new program ramps in the consumer electronics market and further impacted by charges related to a distressed customer. CTG segment margin increased 30 basis points for the six-month period ended September 25, 2015, from 1.9% during the six-month period ended September 26, 2014, due to a portfolio shift within the CTG product mix focusing on higher margin consumer electronic products including wearables, coupled with operational efficiencies due to better execution in programs, offset by a charge related to a distressed customer and lower contribution from our mobile business.

[0001628280-15-007847:mdna:55]
IEI segment margin decreased 40 and 100 basis points, respectively, for the three-month and six-month periods ended September 25, 2015, from 3.2% and 3.7% during the three-month and six-month periods ended September 26, 2014, respectively. The decreases are due to underperformance of certain customer programs, delayed and inefficient ramps for new programs, and to a lesser extent product mix changes.

[0001628280-15-007847:mdna:56]
HRS segment margin increased 200 and 110 basis points, respectively, for the three-month and six-month periods ended September 25, 2015, from 5.5% and 5.9% during the three-month and six-month periods ended September 26, 2014, respectively. The improvements are primarily due to the contribution from our recent acquisition of MCi, and improved operational execution as the first six months of fiscal year 2015 saw comparatively higher ramp costs for new programs.

[0001628280-15-007847:mdna:57]
[same as prior period, unchanged from 0001628280-15-005450:mdna:43]

[0001628280-15-007847:mdna:58]
Selling, general and administrative expenses (“SG&A”) amounted to $216.8 million, or 3.4% of net sales, during the three-month period ended September 25, 2015, increasing $12.2 million from $204.6 million, or 3.1% of net sales, during the three-month period ended September 26, 2014. SG&A was $426.2 million, or 3.6% of net sales, during the six-month period ended September 25, 2015, increasing $12.3 million from $413.9 million, or 3.1% of net sales, during the six-month period ended September 26, 2014. The increase in SG&A expenses compared to the prior year is primarily due to increases in stock-based compensation expense, incremental costs associated with our MCi acquisition, and to a lesser extent charges related to a distressed customer.

[0001628280-15-007847:mdna:59]
[same as prior period, unchanged from 0001628280-15-005450:mdna:45]

[0001628280-15-007847:mdna:60]
[same as prior period, unchanged from 0001628280-15-005450:mdna:46]

[0001628280-15-007847:mdna:61]
Amortization of intangible assets increased by $7.9 million during the three-month period ended September 25, 2015 to $16.1 million from $8.2 million for the three-month period ended September 26, 2014, and increased by $8.6 million during the six-month period ended September 25, 2015 to $23.8 million from $15.2 million during the six-month period ended September 26, 2014. The increase is primarily due to incremental amortization expense on intangible assets relating to our acquisitions completed during the first part of fiscal year 2016.

[0001628280-15-007847:mdna:62]
We expect intangible amortization to increase in subsequent periods as we integrate new acquisitions.

[0001628280-15-007847:mdna:63]
[same as prior period, unchanged from 0001628280-15-005450:mdna:48]

[0001628280-15-007847:mdna:64]
Interest and other, net was $22.0 million during the three-month period ended September 25, 2015 compared to $12.5 million during the three-month period ended September 26, 2014. The increase in interest and other, net of $9.5 million was primarily due to $8.1 million of acquisition-related costs incurred during the current period, primarily for MCi, and $6.1 million of interest expense primarily from the new 4.750% Notes due June 15, 2025 as further discussed in note 5 to the condensed consolidated financial statements. These were offset by an increase in foreign currency gains in the current period of $5.6 million.

[0001628280-15-007847:mdna:65]
Interest and other, net was $38.5 million during the six-month period ended September 25, 2015 compared to $31.1 million during the six-month period ended September 26, 2014. The increase in interest and other, net of $7.4 million was primarily as a result of the same factors listed above.

[0001628280-15-007847:mdna:66]
[same as prior period, unchanged from 0001628280-15-005450:mdna:50]

[0001628280-15-007847:mdna:67]
Other charges (income), net was $46.6 million of other income during the six-month period ended September 26, 2014 principally as a result of the reversal of a contractual obligation with a certain customer recognized during the fourth quarter of fiscal year 2014 in the amount of $55.0 million. This was partially offset by an $11.0 million loss in connection with the disposition of a manufacturing facility in Western Europe.

[0001628280-15-007847:mdna:68]
[same as prior period, unchanged from 0001628280-15-005450:mdna:52]

[0001628280-15-007847:mdna:69]
[same as prior period, unchanged from 0001628280-15-005450:mdna:53]

[0001628280-15-007847:mdna:70]
[same as prior period, unchanged from 0001628280-15-005450:mdna:54]

[0001628280-15-007847:mdna:71]
The consolidated effective tax rate was 12.3% and 9.7% for the three-month and six-month periods ended September 25, 2015, and 10.0% and 9.1% for the three-month and six-month periods ended September 26, 2014, respectively, and varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions, operating loss carryforwards, income tax credits, previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. We generate most of our revenues and profits from operations outside of Singapore. The effective tax rate for the six-month period ended September 25, 2015 of 9.7% was relatively consistent with the effective tax rate for the six-month period ended September 26, 2014 of 9.1%. The slight increase of 0.6% was primarily due to the MCi acquisition and impacts from foreign currency which increased the effective rate in fiscal year 2016.  Additionally, the effective tax rate in fiscal year 2015 was lower as it included other income of $55.0 million for which no tax expense was recorded due to the nature of the income.

[0001628280-15-007847:mdna:72]
[same as prior period, unchanged from 0001628280-15-005450:mdna:57]

[0001628280-15-007847:mdna:73]
As of September 25, 2015, we had cash and cash equivalents of approximately $1.7 billion and bank and other borrowings of approximately $2.7 billion. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of September 25, 2015, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0001628280-15-007847:mdna:74]
Cash provided by operating activities was $662.0 million during the six-month period ended September 25, 2015. This resulted primarily from $233.8 million of net income for the period plus adjustments for $230.9 million of non-cash charges

[0001628280-15-007847:mdna:75]
such as depreciation, amortization, and other impairment charges, and $197.3 million from changes in our operating assets and liabilities. These changes were mainly related to an increase in accounts payable due to timing of payments to suppliers, offset by an increase in accounts receivable driven by the increase in sales activity.

[0001628280-15-007847:mdna:76]
[same as prior period, unchanged from 0001628280-15-005450:mdna:60]

[0001628280-15-007847:mdna:77]
|  | Three-Month Periods Ended |
|  | September 25, 2015 |  | March 31, 2015 |  | September 26, 2014 |
| Days in trade accounts receivable | 41 days |  | 46 days |  | 44 days |
| Days in inventory | 54 days |  | 58 days |  | 53 days |
| Days in accounts payable | 70 days |  | 77 days |  | 70 days |
| Cash conversion cycle | 25 days |  | 27 days |  | 27 days |

[0001628280-15-007847:mdna:78]
Days in trade accounts receivable was calculated as average accounts receivable for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended September 25, 2015, days in trade accounts receivable decreased by 3 days compared to the three-month period ended September 26, 2014 largely due to timing of invoicing customers during the current period. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $537.6 million, $600.7 million, and $426.1 million for the quarters ended September 25, 2015, March 31, 2015 and September 26, 2014, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0001628280-15-007847:mdna:79]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory increased by 1 day during the three-month period ended September 25, 2015 compared to the three-month period ended September 26, 2014 primarily as a result of lower sales activity in the current quarter.

[0001628280-15-007847:mdna:80]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable remained constant at 70 days during the three-month period ended September 25, 2015, compared to the three-month period ended September 26, 2014.

[0001628280-15-007847:mdna:81]
Our cash conversion cycle was calculated as the sum of days of inventory and days of accounts receivables outstanding less days payable outstanding. Our cash conversion cycle decreased by 2 days during the three-month period ended September 25, 2015, compared to the three-month period ended September 26, 2014, due to the factors for each of the components in the calculation discussed above.

[0001628280-15-007847:mdna:82]
Cash used in investing activities amounted to $946.4 million during the six-month period ended September 25, 2015. This resulted primarily from $640.1 million paid for the acquisition of five businesses completed during the six-month period ended September 25, 2015, including approximately $555.2 million, net of cash acquired, related to the acquisition of MCi, and approximately $67.5 million to acquire an optical transport facility from Alcatel-Lucent. Investing activities also reflects $294.0 million of net capital expenditures for property and equipment to support certain programs. Other investing activities includes $35.4 million paid for the purchase of certain investments, offset by $23.7 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0001628280-15-007847:mdna:83]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the six-month period ended September 25, 2015 was $368.0 million compared to $167.9 million for the six-month period ended September 26, 2014. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0001628280-15-007847:mdna:84]
|  | Six-Month Periods Ended |
|  | September 25, 2015 |  | September 26, 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 661,995 |  |  | $ | 306,245 |  |
| Purchases of property and equipment | (296,401 | ) |  | (167,204 | ) |
| Proceeds from the disposition of property and equipment | 2,383 |  |  | 28,809 |  |
| Free cash flow | $ | 367,977 |  |  | $ | 167,850 |  |

[0001628280-15-007847:mdna:85]
Cash provided by financing activities was $343.7 million during the six-month period ended September 25, 2015, which was primarily for net proceeds from bank borrowings and long-term debt of $595.6 million mainly resulting from our new debt issuance discussed further in note 5 to the condensed consolidated financial statements, and $49.1 million from the issuance of our shares for option exercises. These cash inflows were partially offset by cash paid for the repurchase of our ordinary shares in the amount of $242.0 million.

[0001628280-15-007847:mdna:86]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of September 25, 2015 and March 31, 2015, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $800.0 million as of March 31, 2015). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0001628280-15-007847:mdna:87]
[same as prior period, unchanged from 0001628280-15-005450:mdna:72]

[0001628280-15-007847:mdna:88]
[same as prior period, unchanged from 0001628280-15-005450:mdna:73]

[0001628280-15-007847:mdna:89]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0001628280-15-007847:mdna:90]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 20, 2015. During the six-month period ended September 25, 2015, we paid $242.0 million to repurchase shares (under the current and prior repurchase plans) at an average price of $11.35 per share. As of September 25, 2015, shares in the aggregate amount of $422.5 million were available to be repurchased under the current plan.

[0001628280-15-007847:mdna:91]
[same as prior period, unchanged from 0001628280-15-005450:mdna:76]

[0001628280-15-007847:mdna:92]
[same as prior period, unchanged from 0001628280-15-005450:mdna:77]

[0001628280-15-007847:mdna:93]
[same as prior period, unchanged from 0001628280-15-005450:mdna:78]

[0001628280-15-007847:mdna:94]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of September 25, 2015 and March 31, 2015, the fair values of our deferred purchase price receivable were approximately $537.6 million and $600.7 million, respectively. As of September 25, 2015 and March 31, 2015, the outstanding balances on receivables sold for cash were $1.4 billion and $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information see note 10 to the condensed consolidated financial statements.
