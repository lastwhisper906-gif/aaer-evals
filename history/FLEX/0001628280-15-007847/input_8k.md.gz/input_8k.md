# FLEX 8-K — 0001104659-15-071373 filed 2015-10-19

## item codes, every 8-K on or before 2015-10-26

- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2015-10-26

- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-15-071373:8k_2_02:1]
EX-99.1
2
a15-21238_1ex99d1.htm
EX-99.1

[0001104659-15-071373:8k_2_02:2]
Exhibit 99.1

[0001104659-15-071373:8k_2_02:3]
P R E S S   R E L E A S E

[0001104659-15-071373:8k_2_02:4]
| Renee Brotherton | Kevin Kessel |
| Corporate Communications | Investor Relations |
| (408) 576-7189 | (408) 576-7985 |
| renee.brotherton@flextronics.com | kevin.kessel@flextronics.com |

[0001104659-15-071373:8k_2_02:5]
FLEX REPORTS SECOND QUARTER FISCAL 2016 RESULTS

[0001104659-15-071373:8k_2_02:6]
·                  Adjusted operating margin continues to expand at 3.1%, increasing 30 basis points year-over-year

[0001104659-15-071373:8k_2_02:7]
·                  Adjusted EPS at $0.27, GAAP EPS at $0.22

[0001104659-15-071373:8k_2_02:8]
·                  Strong free cash flow generation of $143 million

[0001104659-15-071373:8k_2_02:9]
·                  Maintains commitment to return value to shareholders

[0001104659-15-071373:8k_2_02:10]
San Jose, CA, October 19, 2015 — Flex (NASDAQ: FLEX), a leading sketch-to-scale™ solutions company that designs and builds intelligent products for a connected world, today announced results for its second quarter ended September 25, 2015:

[0001104659-15-071373:8k_2_02:11]
|  |  | Three Month Periods Ended |  |
|  |  | September 25 |  | June 26 |  | September 26 |  |
| (US$ in millions, except EPS) |  | 2015 |  | 2015 |  | 2014 |  |
| Net sales |  | $ | 6,317 |  | $ | 5,566 |  | $ | 6,529 |  |
| Adjusted operating income |  | $ | 196 |  | $ | 159 |  | $ | 183 |  |
| GAAP operating income |  | $ | 180 |  | $ | 143 |  | $ | 172 |  |
| Adjusted net income |  | $ | 153 |  | $ | 134 |  | $ | 157 |  |
| GAAP net income |  | $ | 123 |  | $ | 111 |  | $ | 139 |  |
| Adjusted EPS |  | $ | 0.27 |  | $ | 0.23 |  | $ | 0.26 |  |
| GAAP EPS |  | $ | 0.22 |  | $ | 0.19 |  | $ | 0.23 |  |

[0001104659-15-071373:8k_2_02:12]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedule II attached to this press release.

[0001104659-15-071373:8k_2_02:13]
Second Quarter Fiscal 2016 Results of Operations

[0001104659-15-071373:8k_2_02:14]
Flex’s net sales for the second quarter ended September 25, 2015 were just over $6.3 billion, above the mid-point of its previously provided revenue guidance of $5.9 billion to $6.5 billion. The Company’s adjusted earnings per diluted share of $0.27 was towards the high end of the Company’s previously provided guidance of $0.22 to $0.28.

[0001104659-15-071373:8k_2_02:15]
Second quarter adjusted operating income increased 7% year-over-year to $196 million and was above the midpoint of the guidance range of $165 to $205 million. Adjusted operating margin expanded 30 basis points year-over-year to 3.1%.

[0001104659-15-071373:8k_2_02:16]
“Our strong performance this quarter was reflected in our quarterly revenue growth, improved operating margins and our continued ability to operate with discipline,” said Mike McNamara, chief executive officer at Flex. “We remain committed to our strategy of expanding our sketch-to-scale offering to include exciting new partnerships such as NIKE and others that clearly demonstrate Flex’s ability to  provide innovative solutions for many product categories that go beyond electronics.”

[0001104659-15-071373:8k_2_02:17]
“We generated $300 million in cash flow from operations and $143 million in free cash flow during the quarter,” said Chris Collier, chief financial officer at Flex. “Our consistent free cash flow generation reflects our strong discipline and execution and enables our shareholder return commitment. During the quarter we invested $142 million to repurchase almost 13 million shares, or over 2% of our ordinary shares.”

[0001104659-15-071373:8k_2_02:18]
Guidance

[0001104659-15-071373:8k_2_02:19]
For the third quarter ending December 31, 2015, revenue is expected to be in the range of $6.2 to $6.8 billion and adjusted EPS is expected to be in the range of $0.28 to $0.34 per diluted share.

[0001104659-15-071373:8k_2_02:20]
GAAP earnings per share is expected to be lower than the adjusted EPS guidance provided herein by approximately $0.06 per diluted share for estimated intangible amortization and stock-based compensation expense.

[0001104659-15-071373:8k_2_02:21]
Conference Calls and Web Casts

[0001104659-15-071373:8k_2_02:22]
A conference call hosted by Flex’s management team will be held today at 2:00 PM (PT) / 5:00 PM (ET) to discuss the Company’s financial results for the second quarter ended September 25, 2015. The conference call will be broadcast via the Internet and may be accessed by logging on to the Company’s website at www.flextronics.com. Additional information in the form of a slide presentation may also be found on the Company’s site.  A replay of the broadcast will remain available on the Company’s website afterwards.

[0001104659-15-071373:8k_2_02:23]
About Flex

[0001104659-15-071373:8k_2_02:24]
Flextronics International Ltd. (“Flex” or the “Company”) Reg. No. 199002645H, is a leading sketch-to-scale™ solutions company that designs and builds intelligent products for a connected world. With approximately 200,000 professionals across 30 countries and a promise to help the world Live smarter™, the company provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit www.flextronics.com or follow us on Twitter @Flextronics.

[0001104659-15-071373:8k_2_02:25]
# # #

[0001104659-15-071373:8k_2_02:26]
materially impact our tax expense, and the effects that the current macroeconomic environment could have on our business and demand for our products as well as the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations. Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-15-071373:8k_2_02:27]
SCHEDULE I

[0001104659-15-071373:8k_2_02:28]
FLEX

[0001104659-15-071373:8k_2_02:29]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-15-071373:8k_2_02:30]
(In thousands, except per share amounts)

[0001104659-15-071373:8k_2_02:31]
|  |  | Three Month Periods Ended |  |
|  |  | September 25, 2015 |  | June 26, 2015 |  | September 26, 2014 |  |
| GAAP: |  |  |  |  |  |  |  |
| Net sales |  | $ | 6,316,762 |  | $ | 5,566,248 |  | $ | 6,528,517 |  |
| Cost of sales |  | 5,919,846 |  | 5,213,907 |  | 6,151,436 |  |
| Gross profit |  | 396,916 |  | 352,341 |  | 377,081 |  |
| Selling, general and administrative expenses |  | 216,796 |  | 209,385 |  | 204,590 |  |
| Operating income |  | 180,120 |  | 142,956 |  | 172,491 |  |
| Intangible amortization |  | 16,127 |  | 7,671 |  | 8,232 |  |
| Interest and other, net |  | 22,035 |  | 16,505 |  | 12,506 |  |
| Other charges (income), net |  | 1,678 |  | 164 |  | (2,584 | ) |
| Income before income taxes |  | 140,280 |  | 118,616 |  | 154,337 |  |
| Provision for income taxes |  | 17,303 |  | 7,766 |  | 15,434 |  |
| Net income |  | $ | 122,977 |  | $ | 110,850 |  | $ | 138,903 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.22 |  | $ | 0.19 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.23 |  | $ | 0.26 |  |
| Diluted shares used in computing per share amounts |  | 569,655 |  | 577,997 |  | 595,871 |  |

[0001104659-15-071373:8k_2_02:32]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures. See the accompanying notes on Schedule IV attached to this press release.

[0001104659-15-071373:8k_2_02:33]
SCHEDULE II

[0001104659-15-071373:8k_2_02:34]
FLEX

[0001104659-15-071373:8k_2_02:35]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-15-071373:8k_2_02:36]
(In thousands, except per share amounts)

[0001104659-15-071373:8k_2_02:37]
|  |  | Three Month Periods Ended |  |
|  |  | September 25, 2015 |  | June 26, 2015 |  | September 26, 2014 |  |
| GAAP gross profit |  | $ | 396,916 |  | $ | 352,341 |  | $ | 377,081 |  |
| Stock-based compensation expense |  | 2,015 |  | 2,018 |  | 1,868 |  |
| Non-GAAP gross profit |  | $ | 398,931 |  | $ | 354,359 |  | $ | 378,949 |  |
| GAAP SG&A Expenses |  | $ | 216,796 |  | $ | 209,385 |  | $ | 204,590 |  |
| Stock-based compensation expense |  | 14,185 |  | 14,108 |  | 9,051 |  |
| Non-GAAP SG&A Expenses |  | $ | 202,611 |  | $ | 195,277 |  | $ | 195,539 |  |
| GAAP operating income |  | $ | 180,120 |  | $ | 142,956 |  | $ | 172,491 |  |
| Stock-based compensation expense |  | 16,200 |  | 16,126 |  | 10,919 |  |
| Non-GAAP operating income |  | $ | 196,320 |  | $ | 159,082 |  | $ | 183,410 |  |
| GAAP provision for income taxes |  | $ | 17,303 |  | $ | 7,766 |  | $ | 15,434 |  |
| Intangible amortization benefit |  | 2,355 |  | 258 |  | 1,177 |  |
| Non-GAAP provision for income taxes |  | $ | 19,658 |  | $ | 8,024 |  | $ | 16,611 |  |
| GAAP net income |  | $ | 122,977 |  | $ | 110,850 |  | $ | 138,903 |  |
| Stock-based compensation expense |  | 16,200 |  | 16,126 |  | 10,919 |  |
| Intangible amortization |  | 16,127 |  | 7,671 |  | 8,232 |  |
| Adjustments for taxes |  | (2,355 | ) | (258 | ) | (1,177 | ) |
| Non-GAAP net income |  | $ | 152,949 |  | $ | 134,389 |  | $ | 156,877 |  |
| EPS: |  |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.22 |  | $ | 0.19 |  | $ | 0.23 |  |
| Non-GAAP |  | $ | 0.27 |  | $ | 0.23 |  | $ | 0.26 |  |

[0001104659-15-071373:8k_2_02:38]
SCHEDULE III

[0001104659-15-071373:8k_2_02:39]
FLEX

[0001104659-15-071373:8k_2_02:40]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-15-071373:8k_2_02:41]
(In thousands)

[0001104659-15-071373:8k_2_02:42]
|  |  | September 25, 2015 |  | March 31, 2015 |  |
| ASSETS |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,668,427 |  | $ | 1,628,408 |  |
| Accounts receivable, net |  | 2,546,810 |  | 2,337,515 |  |
| Inventories |  | 3,561,326 |  | 3,488,752 |  |
| Other current assets |  | 1,208,931 |  | 1,286,225 |  |
| Total current assets |  | 8,985,494 |  | 8,740,900 |  |
| Property and equipment, net |  | 2,218,030 |  | 2,092,167 |  |
| Goodwill and other intangible assets, net |  | 981,838 |  | 415,175 |  |
| Other assets |  | 474,977 |  | 417,382 |  |
| Total assets |  | $ | 12,660,339 |  | $ | 11,665,624 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 47,972 |  | $ | 46,162 |  |
| Accounts payable |  | 4,787,941 |  | 4,561,194 |  |
| Other current liabilities |  | 2,196,867 |  | 2,148,867 |  |
| Total current liabilities |  | 7,032,780 |  | 6,756,223 |  |
| Long-term debt, net of current portion: |  |  |  |  |  |
| Revolving credit facility |  | — |  | — |  |
| 4.625% Notes (due 2020) |  | 500,000 |  | 500,000 |  |
| 5.000% Notes (due 2023) |  | 500,000 |  | 500,000 |  |
| 4.750% Notes (due 2025) (2) |  | 595,402 |  | — |  |
| Term Loans |  | 1,014,375 |  | 1,027,500 |  |
| Other long-term debt |  | 8,401 |  | 10,071 |  |
| Other liabilities |  | 553,806 |  | 475,580 |  |
| Total shareholders’ equity |  | 2,455,575 |  | 2,396,250 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,660,339 |  | $ | 11,665,624 |  |

[0001104659-15-071373:8k_2_02:43]
SCHEDULE IV

[0001104659-15-071373:8k_2_02:44]
FLEX AND SUBSIDIARIES

[0001104659-15-071373:8k_2_02:45]
NOTES TO SCHEDULES I, II, & III

[0001104659-15-071373:8k_2_02:46]
(1)   To supplement Flex’s unaudited selected financial data presented on a basis consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP selling, general and administrative expenses, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies. We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures. The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-15-071373:8k_2_02:47]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance.  We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors.  In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-15-071373:8k_2_02:48]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-15-071373:8k_2_02:49]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-15-071373:8k_2_02:50]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-15-071373:8k_2_02:51]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-15-071373:8k_2_02:52]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-15-071373:8k_2_02:53]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types. In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-15-071373:8k_2_02:54]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-15-071373:8k_2_02:55]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies.

[0001104659-15-071373:8k_2_02:56]
For the second quarter ended September 25, 2015, Free Cash Flow was $143 million consisting of GAAP net cash flows from operating activities of $300 million less purchases of property and equipment, net of proceeds from dispositions, of $157 million. We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash flows provided by operating activities.”

[0001104659-15-071373:8k_2_02:57]
(2) During the first quarter of fiscal 2016, the Company issued $600 million of 4.750% Notes due in 2025 in a private offering pursuant to Rule 144A and Regulation S under the Securities Act, at a discount of 99.213%.
