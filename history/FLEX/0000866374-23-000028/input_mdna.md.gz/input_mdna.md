# FLEX MD&A — 0000866374-23-000028


## mdna

[0000866374-23-000028:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-23-000028:mdna:2]
OVERVIEW

[0000866374-23-000028:mdna:3]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support the entire product lifecycle with advanced manufacturing solutions and operate one of the most trusted global supply chains. We also provide additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. We support a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of March 31, 2023, our three operating and reportable segments were as follows:

[0000866374-23-000028:mdna:4]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-23-000028:mdna:5]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-23-000028:mdna:6]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-23-000028:mdna:7]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-23-000028:mdna:8]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-23-000028:mdna:9]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-23-000028:mdna:10]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-23-000028:mdna:11]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-23-000028:mdna:12]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-23-000028:mdna:13]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-23-000028:mdna:14]
Over the past few years, we have seen an increased level of diversification by many companies, primarily in the technology sector. Some companies that have historically identified themselves as software providers, Internet service providers or e-commerce retailers have entered the highly competitive and rapidly evolving technology hardware markets, such as mobile devices, home entertainment and wearable devices. This trend has resulted in a significant change in the manufacturing and supply chain solution requirements of such companies. While the products have become more complex, the supply chain solutions required by such companies have become more customized and demanding, and it has changed the manufacturing and supply chain landscape significantly.

[0000866374-23-000028:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-23-000028:mdna:16]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-23-000028:mdna:17]
Nextracker IPO

[0000866374-23-000028:mdna:18]
On February 13, 2023, our subsidiary, Nextracker completed an IPO of 30,590,000 shares of its Class A common stock at a public offering price of $24.00 per share, less underwriting discounts and commissions. Upon the closing of the IPO, Flex beneficially owned 61.4% of the total outstanding shares of Nextracker’s capital stock and received net proceeds of approximately $694 million, after deducting approximately $40 million in underwriting discounts. Refer to "Risk Factors - We may not achieve some or all of the intended benefits of Nextracker being a separate, publicly-traded company, which could negatively impact our business, financial condition and results of operations."

[0000866374-23-000028:mdna:19]
Following Nextracker's IPO and a series of reorganization transactions, Nextracker now operates under an umbrella partnership C corporation ("Up-C") structure, in which all of the business and affairs of Nextracker LLC (the "LLC") are operated and controlled by Nextracker. See note 1 to the consolidated financial statements in Item 8, “Financial Statements and Supplementary Data” for further information.

[0000866374-23-000028:mdna:20]
Update on the Impact of COVID-19, Component Shortages and Logistical Constraints on our Business

[0000866374-23-000028:mdna:21]
With the series of waves of the global pandemic including follow-on variants of COVID-19, renewed disease control measures were taken during fiscal year 2023 to limit the spread including movement bans and shelter-in-place orders. Although not materially impacting our results in fiscal year 2023, with the lockdowns in China in the first half of fiscal year 2023 and COVID-19 outbreaks in China in the second half of fiscal year 2023, we experienced temporary plant closures and/or restrictions at certain of our manufacturing facilities in China. We continue to closely monitor the situation in all the locations where we operate. Our priority remains the welfare of our employees. Component shortages and logistical constraints improved as the year progressed, however, we continue to see constraints in large-node semiconductors. We continue to carefully monitor potential supply chain disruptions. Refer to “Risk Factors - The COVID-19 pandemic has had, and may in the future again have, a material adverse effect on our business, results of operations and financial condition.” and "— Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future, affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components."

[0000866374-23-000028:mdna:22]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-23-000028:mdna:23]
Russian Invasion of Ukraine

[0000866374-23-000028:mdna:24]
We are monitoring and responding to the conflict in Ukraine and the associated sanctions and other restrictions. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine. The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflict and its impact on regional and global economic conditions. We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-23-000028:mdna:25]
Business Overview

[0000866374-23-000028:mdna:26]
We are one of the world's largest providers of global supply chain solutions, with revenues of $30.3 billion in the fiscal year ended March 31, 2023. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. We also provide intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. As of March 31, 2023, our total manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-23-000028:mdna:27]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 13,773 |  |  | 45 | % |  | $ | 10,839 |  |  | 42 | % |  |  |  |  |
| Asia | 10,361 |  |  | 34 | % |  | 9,601 |  |  | 37 | % |  |  |  |  |
| Europe | 6,212 |  |  | 21 | % |  | 5,601 |  |  | 21 | % |  |  |  |  |
|  | $ | 30,346 |  |  |  |  | $ | 26,041 |  |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,589 |  |  | 22 | % |  | $ | 5,059 |  |  | 19 | % |  |  |  |  |
| China | 6,539 |  |  | 22 | % |  | 6,146 |  |  | 24 | % |  |  |  |  |
| U.S. | 5,020 |  |  | 17 | % |  | 3,690 |  |  | 14 | % |  |  |  |  |
| Malaysia | 2,448 |  |  | 8 | % |  | 1,866 |  |  | 7 | % |  |  |  |  |
| Brazil | 2,046 |  |  | 7 | % |  | 2,022 |  |  | 8 | % |  |  |  |  |
| Hungary | 1,310 |  |  | 4 | % |  | 1,230 |  |  | 5 | % |  |  |  |  |
| Other | 6,394 |  |  | 20 | % |  | 6,028 |  |  | 23 | % |  |  |  |  |
|  | $ | 30,346 |  |  |  |  | $ | 26,041 |  |  |  |  |  |  |  |

[0000866374-23-000028:mdna:28]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 763 |  |  | 32 | % |  | $ | 626 |  |  | 29 | % |
| U.S. | 365 |  |  | 16 | % |  | 354 |  |  | 17 | % |
| China | 338 |  |  | 14 | % |  | 299 |  |  | 14 | % |
| Malaysia | 152 |  |  | 6 | % |  | 110 |  |  | 5 | % |
| Hungary | 140 |  |  | 6 | % |  | 118 |  |  | 6 | % |
| India | 96 |  |  | 4 | % |  | 129 |  |  | 6 | % |
| Other | 495 |  |  | 22 | % |  | 489 |  |  | 23 | % |
|  | $ | 2,349 |  |  |  |  | $ | 2,125 |  |  |  |

[0000866374-23-000028:mdna:29]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-23-000028:mdna:30]
Our operating results are affected by a number of factors, including the following:

[0000866374-23-000028:mdna:31]
•weak global economic conditions, including inflationary pressures, currency volatility, slower growth or recession, higher interest rates, and geopolitical uncertainty (including the ongoing conflict between Russia and Ukraine);

[0000866374-23-000028:mdna:32]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-23-000028:mdna:33]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-23-000028:mdna:34]
37

[0000866374-23-000028:mdna:35]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-23-000028:mdna:36]
•the effects that current credit and market conditions (including as a result of the ongoing conflict between Russia and Ukraine) could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-23-000028:mdna:37]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including as a result of the COVID-19 global pandemic;

[0000866374-23-000028:mdna:38]
•the remaining effects of the COVID-19 global pandemic on our business and results of operations;

[0000866374-23-000028:mdna:39]
•the effects on our business due to certain customers' products having short product lifecycles;

[0000866374-23-000028:mdna:40]
•our customers' ability to cancel or delay orders or change production quantities;

[0000866374-23-000028:mdna:41]
•our customers' decisions to choose internal manufacturing instead of outsourcing for their product requirements;

[0000866374-23-000028:mdna:42]
•integration of acquired businesses and facilities;

[0000866374-23-000028:mdna:43]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-23-000028:mdna:44]
•changes in tax legislation; and

[0000866374-23-000028:mdna:45]
•changes in trade regulations and treaties.

[0000866374-23-000028:mdna:46]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-23-000028:mdna:47]
Net sales for fiscal year 2023 increased approximately 17%, or $4.3 billion, to $30.3 billion from the prior year. The increase in sales was notable in all three segments. Net sales for our FAS segment increased $1.7 billion, or 12%, from the prior year, driven by strong growth in our CEC business and, to a lesser extent, an increase in our Lifestyle business. These increases were driven by a reduced impact from COVID-19 production pressures during the current year versus the prior year, coupled with new program wins, ramps, and clear-to-build improvement. The increases noted in FAS during fiscal year 2023 were partially offset by a decrease in our Consumer Devices business primarily due to relatively softer market demand and planned project completions in fiscal year 2022. Net sales for our FRS segment increased $2.1 billion, or 20%, from the prior year, primarily driven by strong increases in sales from our Industrial and Automotive businesses and, to a lesser extent, an increase in our Health Solutions business due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition and the recovery of inflationary costs, despite continued supply constraints. Net sales for our Nextracker segment increased $0.4 billion, or 31%, from the prior year, primarily driven by an increase in gigawatts delivered and, to a lesser extent, an increased average selling price which was in part driven by an increase in recovered logistics costs. Our fiscal year 2023 gross profit totaled $2.3 billion, representing an increase of $0.3 billion, or 17%, from the prior year. The increase was primarily driven by the overall strong customer demand across various end markets which allowed for improved fixed cost absorption, despite continued margin pressures from component shortages, logistics constraints and the pass-through effect of inflationary cost recoveries. Our net income totaled $1.0 billion, representing an increase of $0.1 billion, or 10%, compared to fiscal year 2022, due to the factors explained above along with lower income taxes in fiscal year 2023, offset by the absence of an approximate $150 million non-cash gain recorded in fiscal year 2022 related to certain tax credits in Brazil and higher interest expense in fiscal year 2023.

[0000866374-23-000028:mdna:48]
Cash provided by operations decreased by approximately $0.1 billion primarily driven by the $0.2 billion decrease in changes in working capital and other, net offset by $0.1 billion increase in net income. Refer to "Liquidity and Capital Resources" section for further details of changes in working capital and other, net.

[0000866374-23-000028:mdna:49]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. Our adjusted free cash flow was $0.3 billion and $0.6 billion for fiscal years 2023 and 2022, respectively. Refer to the Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from

[0000866374-23-000028:mdna:50]
operations. Cash used in investing activities decreased by approximately $0.3 billion to a cash outflow of $0.6 billion for fiscal year 2023, compared with a cash outflow of $1.0 billion for fiscal year 2022, primarily due to $0.5 billion of cash paid for the acquisition of Anord Mardix in fiscal year 2022 offset by an increase of approximately $0.2 billion of cash paid for purchases of property and equipment in fiscal year 2023. Cash provided by financing activities decreased by approximately $0.3 billion primarily driven by a $0.8 billion increase in net debt repayment partially offset by $0.3 billion in lower share repurchases and a net $0.2 billion increase in Nextracker related proceeds associated with Nextracker’s IPO in fiscal year 2023, compared to the proceeds received from the sale of Nextracker redeemable preferred units in fiscal year 2022.

[0000866374-23-000028:mdna:51]
CRITICAL ACCOUNTING ESTIMATES

[0000866374-23-000028:mdna:52]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to the COVID-19 pandemic and its long-term impacts and the ongoing conflict between Russia and Ukraine, there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from those estimates and assumptions.

[0000866374-23-000028:mdna:53]
We believe the following critical accounting estimates affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-23-000028:mdna:54]
Revenue Recognition

[0000866374-23-000028:mdna:55]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-23-000028:mdna:56]
Customer Contracts and Related Obligations

[0000866374-23-000028:mdna:57]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-23-000028:mdna:58]
Inventory Valuation

[0000866374-23-000028:mdna:59]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand and anticipated component shortages, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable

[0000866374-23-000028:mdna:60]
than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-23-000028:mdna:61]
Carrying Value of Long-Lived Assets

[0000866374-23-000028:mdna:62]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, the general business environment and other factors including future developments of the remaining effects of the COVID-19 pandemic and the ongoing conflict between Russia and Ukraine, which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize material impairment charges in the future.

[0000866374-23-000028:mdna:63]
Goodwill

[0000866374-23-000028:mdna:64]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-23-000028:mdna:65]
Noncontrolling Interest

[0000866374-23-000028:mdna:66]
Interests held by third parties in a consolidated majority-owned subsidiary are presented as noncontrolling interest, which represents the noncontrolling equity holders' interest in the underlying net assets of our consolidated majority-owned subsidiary. Noncontrolling interest, where we may be required to repurchase the noncontrolling interest under a contractual redemption requirement, is reported in the consolidated balance sheets between liabilities and equity, as redeemable noncontrolling interest (“RNCI”). Refer to note 7 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion.

[0000866374-23-000028:mdna:67]
Income Taxes

[0000866374-23-000028:mdna:68]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-23-000028:mdna:69]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-23-000028:mdna:70]
RESULTS OF OPERATIONS

[0000866374-23-000028:mdna:71]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data." As further discussed in note 2 to the consolidated financial statements in Item 8, the prior year amounts related to equity in earnings from our unconsolidated investments previously was included in the "other charges (income), net" caption and are now presented separately under "equity in earnings of unconsolidated affiliates" in the consolidated statements of operations. For comparability purposes, the prior periods have been recast to conform to the current presentation. The reclassifications had no effect on the previously reported results of operations.

[0000866374-23-000028:mdna:72]
For a discussion of our results of operations for the fiscal year ended March 31, 2022 compared to the fiscal year ended March 31, 2021, refer to Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-23-000028:mdna:73]
The data below, and discussion that follows, represents our results from operations, and relative percentages.

[0000866374-23-000028:mdna:74]
|  | Fiscal Year EndedMarch 31, |
|  | 2023 |  | 2022 |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |
| Cost of sales | 92.4 |  |  | 92.5 |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  |  |
| Gross profit | 7.5 |  |  | 7.4 |  |  |  |
| Selling, general and administrative expenses | 3.3 |  |  | 3.4 |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  |  |
| Restructuring charges | — |  |  | — |  |  |  |
| Operating income | 3.9 |  |  | 3.7 |  |  |  |
| Interest, net | 0.7 |  |  | 0.6 |  |  |  |
| Other charges (income), net | — |  |  | (0.7) |  |  |  |
| Equity in earnings (losses) of unconsolidated affiliates | — |  |  | (0.2) |  |  |  |
| Income before income taxes | 3.2 |  |  | 4.0 |  |  |  |
| Provision for (benefit from) income taxes | (0.2) |  |  | 0.4 |  |  |  |
| Net income | 3.4 | % |  | 3.6 | % |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 0.8 |  |  | — |  |  |  |
| Net income attributable to Flex Ltd. | 2.6 | % |  | 3.6 | % |  |  |

[0000866374-23-000028:mdna:75]
Net sales

[0000866374-23-000028:mdna:76]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-23-000028:mdna:77]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  |  |
| Net sales: | (In millions) |
| Flex Agility Solutions | $ | 15,769 |  |  | 52 | % |  | $ | 14,027 |  |  | 54 | % |  |  |  |  |
| Flex Reliability Solutions | 12,733 |  |  | 42 | % |  | 10,603 |  |  | 41 | % |  |  |  |  |
| Nextracker | 1,903 |  |  | 6 | % |  | 1,458 |  |  | 6 | % |  |  |  |  |
| Intersegment eliminations | (59) |  |  | — | % |  | (47) |  |  | — | % |  |  |  |  |
|  | $ | 30,346 |  |  |  |  | $ | 26,041 |  |  |  |  |  |  |  |

[0000866374-23-000028:mdna:78]
Net sales for the fiscal year ended March 31, 2023 totaled $30.3 billion, representing an increase of approximately $4.3 billion, or 17%, from $26.0 billion for the fiscal year ended March 31, 2022. Net sales for our FAS segment increased $1.7 billion, or 12%, from the prior year, mainly due to an increase in net sales of 30% in our CEC business and 2% in our Lifestyle business due to new ramps, customer expansion, along with some effect from inflation pass-through while overcoming challenges from supply constraints. These increases in FAS were offset by a 19% decrease in net sales in our Consumer

[0000866374-23-000028:mdna:79]
41

[0000866374-23-000028:mdna:80]
Devices business due to relatively softer market demand and a planned project completion in the fiscal year ended 2022. Net sales in our FRS segment increased $2.1 billion, or 20%, driven primarily by an increase of 24% in net sales in our Industrial business, a 22% increase in our Automotive business, and a 9% increase in our Health Solutions business from the prior year due to strong customer demand and ramps across various end markets coupled with incremental revenues from our Anord Mardix acquisition and the recovery of inflationary costs, despite continued supply constraints. Net sales for our Nextracker segment increased $0.4 billion, or 31%, from the prior year driven by an increase in gigawatts delivered and, to a lesser extent, an increased average selling price which was in part driven by an increase in recovered logistics costs.

[0000866374-23-000028:mdna:81]
Net sales increased across all regions with a $2.9 billion increase to $13.8 billion in the Americas, a $0.8 billion increase to $10.4 billion in Asia, and a $0.6 billion increase to $6.2 billion in Europe.

[0000866374-23-000028:mdna:82]
Our ten largest customers during fiscal years 2023 and 2022 accounted for approximately 34% of net sales. We have made substantial efforts to diversify our portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal years 2023 or 2022.

[0000866374-23-000028:mdna:83]
Cost of sales

[0000866374-23-000028:mdna:84]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-23-000028:mdna:85]
Cost of sales during fiscal year 2023 totaled $28.1 billion, representing an increase of approximately $4.0 billion, or 16% from $24.1 billion during fiscal year 2022. The increase in cost of sales is most notable in our FRS segment. Cost of sales in FRS for fiscal year 2023 increased $2.0 billion, or approximately 21% from fiscal year 2022, which is in line with the 20% increase in revenue, primarily as a result of higher revenue in our Industrial and Automotive businesses. Cost of sales in FAS increased $1.6 billion, or approximately 12%, from fiscal year 2022, which is relatively consistent with the 12% increase in revenue, primarily as a result of higher revenue in our CEC and Lifestyle businesses, and partially offset by improved efficiencies. Cost of sales in our Nextracker segment increased $0.3 billion, or approximately 23% from fiscal year 2022, primarily due to the 31% increase in sales noted above, partially offset by improved recovery on freight and logistics cost increases.

[0000866374-23-000028:mdna:86]
Gross profit

[0000866374-23-000028:mdna:87]
Gross profit is affected by a fluctuation in costs of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-23-000028:mdna:88]
Gross profit during fiscal year 2023 increased $0.3 billion to $2.3 billion, or 7.5% of net sales, from $1.9 billion, or 7.4% of net sales, during fiscal year 2022. The increase in gross profit during fiscal year 2023 primarily resulted from the overall stronger customer demand across various end markets which allowed for improved fixed cost absorption, despite continued pressure on margins from component shortages, logistics constraints and the pass-through effect of inflationary cost recoveries, compared to the prior year.

[0000866374-23-000028:mdna:89]
Segment income

[0000866374-23-000028:mdna:90]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset recoveries, restructuring charges, legal and other, interest, net, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-23-000028:mdna:91]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding.

[0000866374-23-000028:mdna:92]
42

[0000866374-23-000028:mdna:93]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 694 |  |  | 4.4 | % |  | $ | 605 |  |  | 4.3 | % |  |  |  |  |
| Flex Reliability Solutions | 607 |  |  | 4.8 | % |  | 546 |  |  | 5.1 | % |  |  |  |  |
| Nextracker | 203 |  |  | 10.7 | % |  | 90 |  |  | 6.2 | % |  |  |  |  |

[0000866374-23-000028:mdna:94]
FAS segment margin increased 10 basis points, to 4.4% for fiscal year 2023, from 4.3% for fiscal year 2022. The margin increase during the period was driven by strong execution against new project ramps and product mix, partially offset by elevated costs due to component shortages and logistics constraints and the effect of certain inflation pass-through recoveries.

[0000866374-23-000028:mdna:95]
FRS segment margin decreased 30 basis points, to 4.8% for fiscal year 2023, from 5.1% for fiscal year 2022. The margin decrease in the FRS segment was primarily driven by component shortage-related production disruptions, inflationary cost pressures as well as program investments impacting our Automotive and Health Solutions businesses during fiscal year 2023.

[0000866374-23-000028:mdna:96]
Nextracker segment margin increased 450 basis points, to 10.7% for fiscal year 2023, from 6.2% for fiscal year 2022 driven primarily by improved pricing and better cost controls and better cost absorption with increased revenue.

[0000866374-23-000028:mdna:97]
Restructuring charges

[0000866374-23-000028:mdna:98]
We continued to identify certain structural changes to restructure the business throughout fiscal year 2023. During fiscal year 2023, we recognized approximately $27 million of restructuring charges, primarily related to employee severance. During fiscal year 2022, we recognized approximately $15 million of restructuring charges, primarily related to employee severance.

[0000866374-23-000028:mdna:99]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-23-000028:mdna:100]
Selling, general and administrative expenses

[0000866374-23-000028:mdna:101]
Selling, general and administrative expenses ("SG&A") totaled $1.0 billion, or 3.3% of net sales, during fiscal year 2023, compared to $0.9 billion, or 3.4% of net sales, during fiscal year 2022, increasing by $103 million or 12%, which reflects our enhanced cost control efforts to support higher revenue growth while keeping our SG&A expenses relatively flat.

[0000866374-23-000028:mdna:102]
Intangible amortization

[0000866374-23-000028:mdna:103]
Amortization of intangible assets in fiscal years 2023 and 2022 were $82 million and $68 million, respectively, representing an increase of $14 million, from fiscal year 2022, primarily due to amortization expense related to new intangible assets from the Anord Mardix acquisition completed in December 2021, partially offset by certain intangible assets being fully amortized during fiscal year 2023.

[0000866374-23-000028:mdna:104]
Interest, net

[0000866374-23-000028:mdna:105]
Interest, net was $201 million during fiscal year 2023, compared to $152 million during fiscal year 2022, increasing $49 million primarily due to higher variable interest expense during fiscal year 2023.

[0000866374-23-000028:mdna:106]
Other charges (income), net

[0000866374-23-000028:mdna:107]
During fiscal year 2023, we recorded $5 million of other charges, net, compared to $164 million of other income, net, in fiscal year 2022, which was primarily driven by a $150 million gain related to a Brazilian tax credit recognized in fiscal year 2022 coupled with $25 million reduction in foreign exchange transaction gains compared to fiscal year 2022.

[0000866374-23-000028:mdna:108]
Refer to note 17 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net.

[0000866374-23-000028:mdna:109]
Equity in earnings (losses) of unconsolidated affiliates

[0000866374-23-000028:mdna:110]
During fiscal year 2023, we recorded $4 million of equity in losses of unconsolidated affiliates, compared to $61 million of equity in earnings of unconsolidated affiliates during fiscal year 2022. The decrease during fiscal year 2023 was primarily due to lower investment fund gains versus fiscal year 2022, resulting from discrete market events such as initial public offerings and financing rounds completed by certain companies included in those funds.

[0000866374-23-000028:mdna:111]
Income taxes

[0000866374-23-000028:mdna:112]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were (6.1)% and 10.0% for the fiscal years 2023 and 2022, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-23-000028:mdna:113]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  |  |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  |  |
| Effect of jurisdictional tax rate differential | 0.5 |  |  | (10.9) |  |  |  |
| Change in unrecognized tax benefit | (0.7) |  |  | 1.1 |  |  |  |
| Change in valuation allowance | (4.8) |  |  | 1.1 |  |  |  |
| Foreign exchange movement on prior year taxes recoverable | 0.4 |  |  | (0.9) |  |  |  |
| Tax impacts related to sale of Nextracker | 1.6 |  |  | 1.2 |  |  |  |
| APB 23 tax liability | — |  |  | 0.1 |  |  |  |
| Restructuring of Nextracker LLC interest | (20.0) |  |  | — |  |  |  |
| Other | (0.1) |  |  | 1.3 |  |  |  |
| Provision for (benefit from) income taxes | (6.1) | % |  | 10.0 | % |  |  |

[0000866374-23-000028:mdna:114]
The variation in our effective tax rate each year is primarily a result of recognition of earnings in foreign jurisdictions which are taxed at rates lower than the Singapore statutory rate including the effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Costa Rica, Netherlands and Israel of $14 million and $23 million in fiscal years 2023 and 2022, respectively. The primary driver of the negative effective tax rate for fiscal year 2023 relates to the recording of a $195 million deferred tax asset, with an offsetting entry to income tax benefit fully attributable to noncontrolling interest in connection with the Nextracker IPO whereby Nextracker Inc. purchased Nextracker LLC units from a related Flex U.S. subsidiary. Additionally, our effective tax rate is impacted by changes in our liabilities for uncertain tax positions of ($7) million, and $12 million and changes in our valuation allowances on deferred tax assets of ($47) million and $12 million in fiscal years 2023 and 2022, respectively. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-23-000028:mdna:115]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our effective tax rate, tax position, operating results, financial position and cash flows.

[0000866374-23-000028:mdna:116]
We provide a valuation allowance against deferred tax assets that in our estimation are not more likely than not to be realized. During fiscal year 2023, we released valuation allowances totaling $12 million, which related primarily to certain operations in Australia, and the Netherlands, as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those operations. During fiscal year 2023, we also added $12 million in valuation allowances primarily for the deferred tax assets related to operations in Hungary, Canada, and Switzerland. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances, and increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions.

[0000866374-23-000028:mdna:117]
Net income attributable to noncontrolling interest and redeemable noncontrolling interest

[0000866374-23-000028:mdna:118]
Net income attributable to noncontrolling interest and redeemable noncontrolling interest was $240 million during fiscal year 2023, compared to $4 million during fiscal year 2022, increasing $236 million primarily due to the Nextracker IPO during fiscal year 2023.

[0000866374-23-000028:mdna:119]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-23-000028:mdna:120]
In response to the recent challenging environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources, are adequate to fund current and future commitments. As of March 31, 2023, we had cash and cash equivalents of approximately $3.3 billion and bank and other borrowings of approximately $3.8 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), under which we had no borrowings outstanding as of March 31, 2023. In fiscal year 2023, we also entered into a $450 million delayed draw term loan credit agreement, under which $300 million was repaid during fiscal year 2023, and we had $150 million of borrowings outstanding as of March 31, 2023. During fiscal year 2023, we also issued $400 million of 6.000% Notes due January 2028. The proceeds obtained, together with cash on hand, were used for general corporate purposes, which included redeeming $500 million in aggregate principal amount of our 5.000% notes due 2023 on December 20, 2022 and for working capital requirements. We also borrowed €250 million, under a one-year term-loan agreement. The proceeds of the term loan were used to repay the outstanding €250 million Euro term loan due on December 9, 2022. During fiscal year 2023, the Company repaid all outstanding Euro term loans. Nextracker also entered into a new $500 million revolving credit facility agreement (the "Nextracker Revolver") and borrowed $150 million under a five-year term loan facility in fiscal year 2023 that is due to mature in February 2028. There were no borrowings outstanding under the $500 million Nextracker Revolver as of March 31, 2023. Refer to note 9 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details. As of March 31, 2023, we were in compliance with the covenants under all of our credit facilities and indentures, we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-23-000028:mdna:121]
As described in Note 1 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data",  our subsidiary Nextracker completed its IPO on February 13, 2023. We received $694 million in net proceeds from the offering, which includes the underwriters’ full exercise of their over-allotment option, after deducting approximately $40 million in underwriting discounts. We currently do not expect Nextracker to declare or pay any cash dividends for the foreseeable future, other than tax distributions and certain cash distributions related to the impact of taxes pursuant to the tax receivable agreement by and among Nextracker, Nextracker LLC, Yuma, Inc., a Delaware corporation and our indirect wholly-owned subsidiary (“Yuma”), Yuma Subsidiary, Inc., a Delaware corporation and a wholly-owned subsidiary of Yuma, TPG Rise Flash, L.P., ("TPG Rise"), an affiliate of the private equity firm TPG (“TPG”), and the following affiliates of TPG: TPG Rise Climate Flash Cl BDH, L.P., TPG Rise Climate BDH, L.P. and The Rise Fund II BDH, L.P. If Nextracker discontinues the payment of, or is unable to pay, such distributions to us, this will reduce our available liquidity. Furthermore, the terms of indebtedness incurred by Nextracker may, and the terms of the Nextracker Revolver will, limit the ability of Nextracker to pay dividends or make other distributions to us, or to amend the agreements between Nextracker and us and our other subsidiaries. In fiscal year 2023, the amount of dividends declared and paid by Nextracker to TPG Rise was $22 million.

[0000866374-23-000028:mdna:122]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2023, approximately 27% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.9 billion as of March 31, 2023). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-23-000028:mdna:123]
The following is a discussion of our cash flows for the fiscal years ended March 31, 2023 and March 31, 2022. For a discussion of our cash flows for the fiscal years ended March 31, 2022 and March 31, 2021, please refer to Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0000866374-23-000028:mdna:124]
Fiscal Year 2023

[0000866374-23-000028:mdna:125]
Cash provided by operating activities was $1.0 billion during fiscal year 2023. The total cash provided by operating activities resulted primarily from $1.0 billion of net income for the period plus $0.5 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.6 billion primarily driven by changes in net working capital as discussed below.

[0000866374-23-000028:mdna:126]
45

[0000866374-23-000028:mdna:127]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased by $1.6 billion to $5.2 billion as of March 31, 2023, from $3.6 billion as of March 31, 2022. This increase was primarily driven by a $0.9 billion increase in inventories due to strong demand, coupled with increased buffer stock to address continued component shortages and logistics constraints, clear-to build constraints and logistics challenges and increases in inventory pricing, an $0.8 billion decrease in bank borrowings and current portion of long-term debt due to debt repayments, a $0.4 billion increase in accounts receivable, net and a $0.3 billion decrease in accounts payable, partially offset by a $1.1 billion increase in deferred revenue and customer working capital advances due to advances from customers to offset required investments in inventory.

[0000866374-23-000028:mdna:128]
Cash used in investing activities totaled $0.6 billion during fiscal year 2023. This was primarily driven by $0.6 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding  CEC, Industrial, Health Solutions and Automotive businesses.

[0000866374-23-000028:mdna:129]
Cash provided by financing activities was $2 million during fiscal year 2023. This was primarily driven by $0.7 billion of net proceeds received from the sale of Nextracker Class A common stock through the IPO and $0.7 billion of proceeds from bank borrowings and long-term debt, partially offset by $1.0 billion net cash for repayments of bank borrowings and long-term debt, and $0.3 billion of cash paid for the repurchase of our ordinary shares. Refer to note 9 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-23-000028:mdna:130]
Fiscal Year 2022

[0000866374-23-000028:mdna:131]
Cash provided by operating activities was $1.0 billion during fiscal year 2022. The total cash provided by operating activities resulted primarily from $0.9 billion of net income for the period plus $0.6 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, provision for doubtful accounts, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.5 billion primarily driven by changes in net working capital, partially offset by an increase in cash from other current liabilities of $1.1 billion primarily attributed to customer advances received.

[0000866374-23-000028:mdna:132]
Cash used in investing activities totaled $1.0 billion during fiscal year 2022. This was primarily driven by approximately $0.5 billion of cash paid for the acquisition of Anord Mardix in December 2021, net of cash acquired, and approximately $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding Lifestyle, Automotive, and Industrial businesses.

[0000866374-23-000028:mdna:133]
Cash provided by financing activities was $0.3 billion during fiscal year 2022. This was primarily driven by $0.7 billion of proceeds received in aggregate, after premiums, following the issuance of the HUF 100 billion Bonds due December 2031 and the €350 million term loan due December 2022, and $0.5 billion of proceeds received from the sale of Nextracker redeemable preferred units, partially offset by $0.7 billion of cash paid for the repurchase of our ordinary shares and $0.2 billion of cash paid for the repayment of the Euro term loan due January 2022.

[0000866374-23-000028:mdna:134]
Adjusted Free Cash Flow

[0000866374-23-000028:mdna:135]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow was $0.3 billion and $0.6 billion for fiscal years 2023 and 2022, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-23-000028:mdna:136]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  |  |
|  | (In millions) |
| Net cash provided by operating activities | $ | 950 |  |  | $ | 1,024 |  |  |  |
| Purchases of property and equipment | (635) |  |  | (443) |  |  |  |
| Proceeds from the disposition of property and equipment | 20 |  |  | 11 |  |  |  |
| Adjusted free cash flow | $ | 335 |  |  | $ | 593 |  |  |  |

[0000866374-23-000028:mdna:137]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond.

[0000866374-23-000028:mdna:138]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volume of customer orders.

[0000866374-23-000028:mdna:139]
We maintain global paying service agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. During fiscal years ended March 31, 2023 and 2022, the cumulative payments due to suppliers participating in the programs amounted to approximately $1.4 billion and $1.3 billion, respectively. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-23-000028:mdna:140]
In addition, we maintain various uncommitted short-term financing facilities including but not limited to a commercial paper program, and a revolving sale and repurchase of subordinated notes established under the securitization facility, under which there were no borrowings outstanding as of March 31, 2023.

[0000866374-23-000028:mdna:141]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of debt securities, bank debt and lease financings. We also have the ability to sell a designated pool of trade receivables under asset-backed securitization programs (the "ABS programs") and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed.

[0000866374-23-000028:mdna:142]
During fiscal year 2023, no accounts receivable had been sold under our ABS programs and we received approximately $3.5 billion from other sales of receivables under our factoring program. During fiscal year 2022, no accounts receivable had been sold under our ABS programs and we received approximately $1.6 billion from other sales of receivables under our factoring program. As of March 31, 2023 and 2022, the outstanding balance on receivables sold for cash was $0.8 billion and $0.6 billion, respectively, under our accounts receivable factoring programs, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-23-000028:mdna:143]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit.

[0000866374-23-000028:mdna:144]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-23-000028:mdna:145]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 25, 2022. During fiscal year 2023, we paid $337 million to repurchase shares under the current and prior repurchase plans at an average price of $17.06 per share. As of March 31, 2023, shares in the aggregate amount of $893 million were available to be repurchased under the current plan.

[0000866374-23-000028:mdna:146]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-23-000028:mdna:147]
Refer to the note 9 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of our debt obligations.

[0000866374-23-000028:mdna:148]
In addition. we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments. Future payments due under our debt including finance leases and related interest obligations and operating leases are as follows (amounts may not sum due to rounding):

[0000866374-23-000028:mdna:149]
|  | Total |  | Less Than1 Year |  | 1 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | $ | 3,862 |  |  | $ | 150 |  |  | $ | 1,538 |  |  | $ | 546 |  |  | $ | 1,628 |  |
| Finance leases | 2 |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Interest on long-term debt obligations | 736 |  |  | 149 |  |  | 366 |  |  | 169 |  |  | 52 |  |
| Operating leases, net of subleases | 719 |  |  | 147 |  |  | 234 |  |  | 160 |  |  | 178 |  |
| Restructuring costs | 50 |  |  | 50 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 5,369 |  |  | $ | 497 |  |  | $ | 2,139 |  |  | $ | 875 |  |  | $ | 1,858 |  |

[0000866374-23-000028:mdna:150]
We have excluded $268 million of liabilities for unrecognized tax benefits from the contractual obligations table as we cannot make a reasonably reliable estimate of the periodic settlements with the respective taxing authorities. See note 15, "Income Taxes" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-23-000028:mdna:151]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory, which are not included in the table above. The majority of the purchase obligations are generally short-term in nature. We generally do not enter into non-cancelable purchase orders for materials until we receive a corresponding production forecast from our customers. Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-23-000028:mdna:152]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-23-000028:mdna:153]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.
