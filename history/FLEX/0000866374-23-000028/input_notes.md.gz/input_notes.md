# FLEX notes — 0000866374-23-000028


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-23-000028:notes:1]
| Document |  | Parts into Which Incorporated |
| Proxy Statement to be delivered to shareholders in connection with the Registrant's 2023 Annual General Meeting of Shareholders |  | Part III |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-23-000028:notes:2]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of March 31, 2023, Flex's three operating and reportable segments were as follows:

[0000866374-23-000028:notes:3]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-23-000028:notes:4]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-23-000028:notes:5]
◦Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-23-000028:notes:6]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-23-000028:notes:7]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-23-000028:notes:8]
◦Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-23-000028:notes:9]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-23-000028:notes:10]
◦Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-23-000028:notes:11]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-23-000028:notes:12]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers). The Company also provides intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world.

[0000866374-23-000028:notes:13]
Nextracker Inc. Initial Public Offering

[0000866374-23-000028:notes:14]
On February 13, 2023, the Company’s subsidiary Nextracker Inc. ("Nextracker") completed an initial public offering (“IPO”) of 30,590,000 shares of its Class A common stock, representing in the aggregate 21.06% of its total outstanding shares of common stock. As a result of the IPO, the Company received net proceeds of approximately $694 million, after deducting approximately $40 million in underwriting discounts.

[0000866374-23-000028:notes:15]
Nextracker, a Delaware corporation, was formed on December 19, 2022. Prior to the IPO, Nextracker's business operations were conducted through Nextracker LLC (the "LLC") and its direct and indirect subsidiaries. In the fourth quarter of fiscal year 2022, Flex sold redeemable preferred units (“Series A Preferred Units”) of the LLC representing a 16.67% interest in the LLC to an unrelated third party; TPG Rise Flash, L.P. ("TPG Rise"), resulting in TPG Rise holding all of the outstanding LLC Series A Preferred Units and subsidiaries of Flex holding all of the outstanding LLC common units. Immediately prior to the IPO, as a result of accrued distributions paid in kind in respect of TPG Rise's outstanding LLC Series A Preferred Units, TPG Rise held Series A Preferred Units representing an interest of 17.37% in the LLC while Flex held LLC common units representing a controlling interest of 82.63%. As the Series A Preferred Units were redeemable upon the occurrence of conditions not solely within the control of the Company, Flex classified TPG Rise’s redeemable noncontrolling interest as temporary equity on the Company’s consolidated balance sheets. TPG Rise received a pro-rated 5% annual preferred dividend-

[0000866374-23-000028:notes:16]
in-kind on its investment amounting to $21 million and $4 million in fiscal years 2023 and 2022, respectively, for the period prior to the IPO. In connection with the IPO, all of the Series A Preferred Units of the LLC were automatically converted into an equal number of LLC common units. TPG Rise and the Flex subsidiaries holding LLC common units also subscribed for an equal number of non-economic, voting Class B common shares of Nextracker. The common units of the LLC, together with a corresponding number of shares of Nextracker Class B common stock are exchangeable at any time at the option of the holder for shares of Nextracker Class A common stock on a one-for-one basis or for cash, at the option of Nextracker and upon such exchange, a corresponding number of such holder's LLC Class B common stock will be cancelled. Following the IPO, the noncontrolling interest in Nextracker comprise the Class A common stock of Nextracker (31.8% of Nextracker’s total common stock) and 6.77% respectively of Nextracker’s Class B common stock and LLC’s common units, held by TPG Rise.

[0000866374-23-000028:notes:17]
Since the IPO, Nextracker has two classes of common stock - Class A common stock, which is traded on the Nasdaq Global Select Market under the symbol “NXT,” and Class B common stock. On all matters submitted to a vote of Nextracker stockholders, each share of Class A and Class B common stock entitles its owners to one vote per share. Class A common stock participates in earnings of Nextracker and Class B common stock does not participate in earnings of Nextracker. As of March 31, 2023, Flex owned 88,457,619 shares of Class B common stock, representing approximately 61.4% of the total outstanding shares of Nextracker’s outstanding common stock. In addition, Flex retains a 61.4% direct ownership of the LLC common units outstanding and participates proportionately in the earnings of the LLC.

[0000866374-23-000028:notes:18]
The corporate structure of the transactions effected in relation to the IPO is an umbrella partnership C corporation structure, commonly referred to as an “Up‑C” structure, which is often used by partnerships and limited liability companies when they undertake an initial public offering of their business. The Up‑C structure allows us to continue to realize tax benefits associated with owning interests in an entity that is treated as a partnership, or “pass-through” entity, for income tax purposes following the IPO.

[0000866374-23-000028:notes:19]
Following the IPO, both Flex and Nextracker are U.S. public company registrants. Nextracker has entered into various agreements to provide a framework for its relationship with Flex after the IPO, including a transition services agreement, an employee matters agreement and a registration rights agreement. These agreements provide for the allocation between Nextracker and Flex of Flex’s employees, liabilities and obligations attributable to periods prior to, at and after the IPO and govern certain relationships between Nextracker and Flex after the IPO.

[0000866374-23-000028:notes:20]
In conjunction with the Nextracker IPO, Nextracker made a distribution in an aggregate amount of $175 million (the “Distribution”). With respect to such Distribution, $22 million was distributed to TPG Rise with the remainder distributed to Flex and its subsidiaries. The Distribution was financed, in part, with net proceeds from the $150 million term loan under a credit agreement entered into by Nextracker.

[0000866374-23-000028:notes:21]
In connection with the IPO, Nextracker entered into a Tax Receivable Agreement (‘TRA’) with Flex and TPG Rise wherein 85% of the tax benefits realized in relation to the IPO would be paid to those parties. Separately, a deferred tax asset of $249 million has been booked reflecting Nextracker's outside basis difference in the Nextracker LLC units.

[0000866374-23-000028:notes:22]
Variable Interest Entities

[0000866374-23-000028:notes:23]
Flex controls Nextracker through its holding of Class B common stock that do not participate in the earnings of Nextracker. As such, the shareholders of the equity at risk in Nextracker (the Class A common stock shareholders) do not have the power to direct the key activities of Nextracker and consequently Nextracker is a variable interest entity ("VIE"). Flex has the ability to control Nextracker's activities through its control of 61.4% of the voting rights of Nextracker as of the IPO. Flex also has the ability to receive significant benefits from the VIE (through its ability to convert its investments in Nextracker and Nextracker LLC into Class A common stock of Nextracker or cash) and as such Flex has been determined to be the primary beneficiary of the VIE. As such, Flex continues to consolidate Nextracker and the interests in Nextracker held by third parties are presented as a noncontrolling interest. Evaluation of the VIE model and identification of the primary beneficiary requires significant judgements to be made regarding which entities can control the activities of a VIE, who can receive benefits or absorb losses from the VIE and the significance of those benefits and losses to the VIE.

[0000866374-23-000028:notes:24]
As Flex continues to consolidate Nextracker, it is exposed to potentially significant gains and losses from the Nextracker business. While a portion of these gains and losses will be attributed to noncontrolling interests, Flex’s revenues, operating earnings, cash flows, earnings per share and statements of financial position will all fluctuate as a result of the performance of the Nextracker business. Nextracker, as a separate public company, is expected to operate largely independently of Flex, subject to Flex’s ability to control the activities of Nextracker and certain agreements to provide ongoing services to Nextracker as part of the separation of the business. Nextracker is not expected to make distributions to Flex (outside of those required by the tax receivable agreement) and Flex is not expected to have to make contributions to Nextracker to fund its operations. As a legacy

[0000866374-23-000028:notes:25]
of Nextracker’s operations from prior to the IPO, Flex provided limited parent company guarantees to certain of Nextracker’s customers to guarantee Nextracker’s contractual obligations. These guarantees all expire by fiscal year 2025 and will not be renewed. No liability to Flex is expected to arise from the provision of these guarantees. Nextracker’s borrowing facility has no recourse to Flex. Flex does not have right to use Nextracker's assets to settle Flex's liabilities, and Nextracker's assets can only be used to settle Nextracker's liabilities and to support Nextracker's own business.

[0000866374-23-000028:notes:26]
The carrying amounts and classification of the VIE's external assets and liabilities included in the consolidated balance sheets are as follows:

[0000866374-23-000028:notes:27]
|  | Fiscal Year Ended March 31, 2023 |
|  | (In millions) |
| Assets |  |
| Current assets: |  |
| Cash | $ | 130 |  |
| Accounts receivable, net | 271 |  |
| Contract assets | 298 |  |
| Inventories | 138 |  |
| Other current assets | 35 |  |
| Total current assets | 872 |  |
| Property and equipment, net | 7 |  |
| Goodwill | 265 |  |
| Other intangible assets, net | 1 |  |
| Other assets | 275 |  |
| Total assets | $ | 1,420 |  |
| Liabilities |  |
| Current liabilities: |  |
| Accounts payable | $ | 211 |  |
| Accrued expenses | 60 |  |
| Deferred revenue | 176 |  |
| Other current liabilities | 49 |  |
| Total current liabilities | 496 |  |
| Long-term debt | 147 |  |
| Other liabilities | 280 |  |
| Total liabilities | $ | 923 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-23-000028:notes:28]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-23-000028:notes:29]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may also exist in  variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of March 31, 2023, we

[0000866374-23-000028:notes:30]
presented noncontrolling interest as permanent equity in the consolidated balance sheets, reflecting the equity held by other parties. As of March 31, 2022, noncontrolling interest that is redeemable upon the occurrence of conditions outside of the control of the Company is reported as temporary equity in the consolidated balance sheets. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the consolidated statements of operations. Refer to note 7 "Noncontrolling Interest" for additional information.

[0000866374-23-000028:notes:31]
Certain prior period presentations and disclosures were reclassified to ensure comparability with the current period presentation. In fiscal year 2023, equity in earnings of unconsolidated affiliates previously presented as part of other charges (income), net are now being separately presented on the consolidated statements of operations. The Company reclassified $61 million and $83 million of equity in earnings of unconsolidated affiliates from other charges (income), net for fiscal years 2022 and 2021 in order to align with current year presentation.

[0000866374-23-000028:notes:32]
Use of Estimates

[0000866374-23-000028:notes:33]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to the COVID-19 pandemic and geopolitical conflicts (including the Russian invasion of Ukraine), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the COVID-19 pandemic and the Russian invasion of Ukraine. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-23-000028:notes:34]
Translation of Foreign Currencies

[0000866374-23-000028:notes:35]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity. Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in the Company's consolidated results of operations. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of other charges (income), net in the consolidated statements of operations.

[0000866374-23-000028:notes:36]
Revenue Recognition

[0000866374-23-000028:notes:37]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the

[0000866374-23-000028:notes:38]
performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 "Revenue" for further details.

[0000866374-23-000028:notes:39]
Government Incentives and Grants

[0000866374-23-000028:notes:40]
The Company receives incentives from federal, state and local governments in different regions of the world that primarily encourage the Company to establish, maintain, or increase investment, employment, or production in the regions. The Company accounts for government incentives as a reduction in the cost of the capital investment or a reduction of expense, based on the substance of the incentives received. Benefits are generally recorded when all conditions attached to the incentive have been met and there is reasonable assurance of receipt. The Company records capital-related incentives as a reduction to Property and equipment, net on the consolidated balance sheets and recognizes a reduction to depreciation and amortization expense over the useful life of the corresponding acquired asset. The Company records operating grants as a reduction to expense in the same line item on the consolidated statements of operations as the expenditure for which the grant is intended to compensate. Government incentives and grants transactions are not material to the Company's financial position, results of operations or cash flows.

[0000866374-23-000028:notes:41]
Concentration of Credit Risk

[0000866374-23-000028:notes:42]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-23-000028:notes:43]
Customer Credit Risk

[0000866374-23-000028:notes:44]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-23-000028:notes:45]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2023, 2022 and 2021:

[0000866374-23-000028:notes:46]
|  | Balance atBeginningof Year |  | Charges (Recoveries) to Costs and Expenses(1) |  | Deductions/Write-Offs (2) |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2021 | $ | 96 |  |  | $ | 5 |  |  | $ | (40) |  |  | $ | 61 |  |
| Year ended March 31, 2022 | 61 |  |  | (3) |  |  | (2) |  |  | 56 |  |
| Year ended March 31, 2023 | 56 |  |  | 3 |  |  | (51) |  |  | 8 |  |

[0000866374-23-000028:notes:47]
(1)Charges and recoveries incurred during fiscal years 2023, 2022 and 2021 are primarily for costs and expenses or bad debt recoveries related to various distressed customers.

[0000866374-23-000028:notes:48]
(2)Deductions and write-offs during fiscal year 2023 is primarily as a result of a settlement reached with a certain former customer.

[0000866374-23-000028:notes:49]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2023, 2022 and 2021. No customer accounted for greater than 10% of the Company's total balance of accounts receivable, net as of fiscal year ended

[0000866374-23-000028:notes:50]
March 31, 2023 and March 31, 2022. One customer within the Company's FAS segment accounted for approximately 11% of the Company's total balance of accounts receivable, net as of the fiscal year ended March 31, 2021.

[0000866374-23-000028:notes:51]
The Company's ten largest customers accounted for approximately 34%, 34% and 36%, of its net sales in fiscal years 2023, 2022 and 2021, respectively.

[0000866374-23-000028:notes:52]
Derivative Instruments

[0000866374-23-000028:notes:53]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 10.

[0000866374-23-000028:notes:54]
Cash and Cash Equivalents

[0000866374-23-000028:notes:55]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-23-000028:notes:56]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-23-000028:notes:57]
Cash and cash equivalents consisted of the following:

[0000866374-23-000028:notes:58]
|  | As of March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Cash and bank balances | $ | 970 |  |  | $ | 679 |  |
| Money market funds and time deposits | 2,324 |  |  | 2,285 |  |
|  | $ | 3,294 |  |  | $ | 2,964 |  |

[0000866374-23-000028:notes:59]
Inventories

[0000866374-23-000028:notes:60]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-23-000028:notes:61]
|  | As of March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Raw materials | $ | 6,140 |  |  | $ | 5,290 |  |
| Work-in-progress | 709 |  |  | 602 |  |
| Finished goods | 681 |  |  | 688 |  |
|  | $ | 7,530 |  |  | $ | 6,580 |  |

[0000866374-23-000028:notes:62]
Property and Equipment, Net

[0000866374-23-000028:notes:63]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-23-000028:notes:64]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2023 |  | 2022 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 3,737 |  |  | $ | 3,540 |  |
| Buildings | 30 |  | 1,162 |  |  | 1,123 |  |
| Leasehold improvements | Shorter of lease term or useful life of the improvement |  | 590 |  |  | 564 |  |
| Furniture, fixtures, computer equipment and software, and other | 3 - 7 |  | 553 |  |  | 503 |  |
| Land | — |  | 124 |  |  | 113 |  |
| Construction-in-progress | — |  | 400 |  |  | 261 |  |
|  |  |  | 6,566 |  |  | 6,104 |  |
| Accumulated depreciation and amortization |  |  | (4,217) |  |  | (3,979) |  |
| Property and equipment, net |  |  | $ | 2,349 |  |  | $ | 2,125 |  |

[0000866374-23-000028:notes:65]
Total depreciation expense associated with property and equipment was approximately $414 million, $409 million and $422 million in fiscal years 2023, 2022 and 2021, respectively.

[0000866374-23-000028:notes:66]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-23-000028:notes:67]
Deferred Income Taxes

[0000866374-23-000028:notes:68]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-23-000028:notes:69]
Accounting for Business and Asset Acquisitions

[0000866374-23-000028:notes:70]
The Company has strategically pursued business and asset acquisitions, which are accounted for using the acquisition method of accounting. The fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill.

[0000866374-23-000028:notes:71]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-23-000028:notes:72]
Goodwill

[0000866374-23-000028:notes:73]
The Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. The Company performed its annual goodwill impairment assessment on January 1, 2023 and as a result of the quantitative assessment of its goodwill, the Company determined that no impairment existed as of the date of the impairment test because the fair value of each one of its reporting units exceeded its respective carrying value.

[0000866374-23-000028:notes:74]
Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market valuations, market multiples for comparable companies as well as a discounted cash flow analysis. Certain of these approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-23-000028:notes:75]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized.

[0000866374-23-000028:notes:76]
The following table summarizes the activity in the Company's goodwill during fiscal years 2023 and 2022:

[0000866374-23-000028:notes:77]
|  |  | FAS |  | FRS |  | Nextracker |  | Total |
|  |  | (In millions) |
| Balance at March 31, 2021 |  | $ | 371 |  |  | $ | 719 |  |  | $ | — |  |  | $ | 1,090 |  |
| Reporting unit reallocation |  | — |  |  | (204) |  |  | 204 |  |  | — |  |
| Acquisitions |  | — |  |  | 272 |  |  | — |  |  | 272 |  |
| Foreign currency translation adjustments |  | — |  |  | (20) |  |  | — |  |  | (20) |  |
| Balance at March 31, 2022 |  | 371 |  |  | 767 |  |  | 204 |  |  | 1,342 |  |
| Acquisitions (1) |  | — |  |  | (2) |  |  | — |  |  | (2) |  |
| Foreign currency translation adjustments |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Balance at March 31, 2023 |  | $ | 371 |  |  | $ | 768 |  |  | $ | 204 |  |  | $ | 1,343 |  |

[0000866374-23-000028:notes:78]
(1)Represents purchase price adjustment for the acquisition of Anord Mardix in the fiscal year of 2023.

[0000866374-23-000028:notes:79]
Other Intangible Assets

[0000866374-23-000028:notes:80]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2023 and concluded that such amounts continued to be recoverable.

[0000866374-23-000028:notes:81]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses, patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability.

[0000866374-23-000028:notes:82]
The components of acquired intangible assets are as follows:

[0000866374-23-000028:notes:83]
|  | As of March 31, 2023 |  | As of March 31, 2022 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 6.5 |  | $ | 373 |  |  | $ | (204) |  |  | $ | 169 |  |  | $ | 385 |  |  | $ | (157) |  |  | $ | 228 |  |
| Licenses and other intangibles | 6.1 |  | 299 |  |  | (152) |  |  | 147 |  |  | 319 |  |  | (136) |  |  | 183 |  |
| Total |  |  | $ | 672 |  |  | $ | (356) |  |  | $ | 316 |  |  | $ | 704 |  |  | $ | (293) |  |  | $ | 411 |  |

[0000866374-23-000028:notes:84]
Total intangible asset amortization expense recognized in operations during fiscal years 2023, 2022 and 2021 was $82 million, $68 million and $62 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2023, the gross carrying amounts of fully amortized intangible assets totaled $14 million. The Company also recorded $15 million of foreign currency translation adjustments during fiscal year 2023, as the U.S. dollar fluctuated against foreign currencies for certain intangibles. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-23-000028:notes:85]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2024 | $ | 70 |  |
| 2025 | 63 |  |
| 2026 | 43 |  |
| 2027 | 36 |  |
| 2028 | 27 |  |
| Thereafter | 77 |  |
| Total amortization expense | $ | 316 |  |

[0000866374-23-000028:notes:86]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has implemented appropriate policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers. As of March 31, 2023 and 2022, the carrying value of the Company's intellectual property was not material.

[0000866374-23-000028:notes:87]
Derivative Instruments and Hedging Activities

[0000866374-23-000028:notes:88]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows. Additional information is included in note 10.

[0000866374-23-000028:notes:89]
Investments

[0000866374-23-000028:notes:90]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2023, and March 31, 2022, the Company's investments in non-consolidated companies totaled $115 million and $131 million, respectively.

[0000866374-23-000028:notes:91]
The Company recognized $4 million of net equity in losses and $61 million of equity in earnings, associated with its equity method investments, in equity in earnings of unconsolidated affiliates on the consolidated statement of operations during fiscal years 2023 and 2022, respectively.

[0000866374-23-000028:notes:92]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-23-000028:notes:93]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-23-000028:notes:94]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-23-000028:notes:95]
Customer Working Capital Advances

[0000866374-23-000028:notes:96]
Customer working capital advances were $2.3 billion and $1.4 billion, as of March 31, 2023 and 2022, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-23-000028:notes:97]
Other Current Liabilities

[0000866374-23-000028:notes:98]
Other current liabilities include customer-related accruals of $313 million and $227 million as of March 31, 2023 and 2022, respectively.

[0000866374-23-000028:notes:99]
Leases

[0000866374-23-000028:notes:100]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the Company has the right to control the use of the identified asset. The Company recognizes a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed

[0000866374-23-000028:notes:101]
payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-23-000028:notes:102]
As of March 31, 2023 and 2022, current operating lease liabilities were $126 million and $132 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-23-000028:notes:103]
Restructuring Charges

[0000866374-23-000028:notes:104]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and rationalize administrative functions. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-23-000028:notes:105]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 16 for additional information regarding restructuring charges.

[0000866374-23-000028:notes:106]
Recently Adopted Accounting Pronouncements

[0000866374-23-000028:notes:107]
In December 2022, the FASB issued ASU 2022-06 "Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848", which defers the sunset date of ASC 848 from December 31, 2022 to December 31, 2024. ASC 848 provides relief for companies preparing for the discontinuation of interest rates, such as LIBOR. Entities that apply ASC 848 can continue to do so until December 31, 2024. The Company adopted the guidance during the third quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

[0000866374-23-000028:notes:108]
In November 2021, the FASB issued ASU 2021-10 "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance", which requires entities to provide disclosures on material government assistance transactions for annual reporting periods. The disclosures include information around the nature of the assistance, the related accounting policies used to account for government assistance, the effect of government assistance on the entity’s financial statements and any significant terms and conditions of the agreements, including commitments and contingencies. The Company adopted the guidance during the fourth quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

[0000866374-23-000028:notes:109]
In July 2021, the FASB issued ASU 2021-05 "Leases (Topic 842): Lessors - Certain Leases with Variable Lease Payments", which requires a lessor to classify a lease with variable lease payments that don’t depend on an index or a rate as an operating lease on the commencement date of the lease if specified criteria are met. The guidance is effective for the Company beginning in the first quarter of fiscal year 2023 with early adoption permitted. The Company adopted the guidance during the first quarter of fiscal year 2023 with an immaterial impact on its consolidated financial statements.

[0000866374-23-000028:notes:110]
Recently Issued Accounting Pronouncements

[0000866374-23-000028:notes:111]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance programs. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on roll-forward information which is effective in fiscal year 2025, with early adoption permitted. The Company expects the new 
guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the first quarter of fiscal year 2024.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-23-000028:notes:112]
Derivative InstrumentsThe amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.Derivative Instruments and Hedging ActivitiesAll derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-23-000028:notes:113]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its consolidated financial statements. Leases have remaining lease terms ranging from approximately 1 year to 17 years.

[0000866374-23-000028:notes:114]
The components of lease cost recognized were as follow (in millions):

[0000866374-23-000028:notes:115]
| Lease cost | Fiscal Year Ended |
|  | March 31, 2023 |  | March 31, 2022 |
| Operating lease cost | $ | 151 |  |  | $ | 156 |  |

[0000866374-23-000028:notes:116]
Amounts reported in the consolidated balance sheet as of the fiscal years ended March 31, 2023 and 2022 were (in millions, except weighted average lease term and discount rate):

[0000866374-23-000028:notes:117]
|  | As of March 31, 2023 |  | As of March 31, 2022 |
| Operating Leases: |  |  |  |
| Operating lease right of use assets | $ | 608 |  | $ | 637 |
| Operating lease liabilities | 632 |  | 683 |
| Weighted-average remaining lease term (In years) |  |  |  |
| Operating leases | 6.6 |  | 7.1 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 4.2 | % |  | 3.6 | % |

[0000866374-23-000028:notes:118]
Other information related to leases was as follow (in millions):

[0000866374-23-000028:notes:119]
|  | Fiscal Year Ended |
|  | March 31, 2023 |  | March 31, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 151 |  |  | $ | 158 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities |  |  |  |
| Operating Lease | $ | 119 |  |  | $ | 78 |  |

[0000866374-23-000028:notes:120]
Future lease payments under non-cancellable leases as of March 31, 2023 were as follows (in millions):

[0000866374-23-000028:notes:121]
| Fiscal Year Ended March 31, | Operating Leases |
| 2024 | $ | 150 |  |
| 2025 | 130 |  |
| 2026 | 104 |  |
| 2027 | 86 |  |
| 2028 | 74 |  |
| Thereafter | 178 |  |
| Total undiscounted lease payments | 722 |  |
| Less: imputed interest | 90 |  |
| Total lease liabilities | $ | 632 |  |

[0000866374-23-000028:notes:122]
Total rent expense amounted to $185 million, $180 million, and $180 million in fiscal years 2023, 2022 and 2021, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-23-000028:notes:123]
REVENUE
Revenue Recognition

[0000866374-23-000028:notes:124]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSAs”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, emails or other communications that embody the commitment by the customer.

[0000866374-23-000028:notes:125]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer.

[0000866374-23-000028:notes:126]
Customer Contracts and Related Obligations

[0000866374-23-000028:notes:127]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be

[0000866374-23-000028:notes:128]
recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-23-000028:notes:129]
Performance Obligations

[0000866374-23-000028:notes:130]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-23-000028:notes:131]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-23-000028:notes:132]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-23-000028:notes:133]
Contract Balances

[0000866374-23-000028:notes:134]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

[0000866374-23-000028:notes:135]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $885 million and $704 million as of March 31, 2023 and 2022, respectively, of which $795 million and $616 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-23-000028:notes:136]
Disaggregation of Revenue

[0000866374-23-000028:notes:137]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time for the fiscal years ended March 31, 2023, 2022 and 2021:

[0000866374-23-000028:notes:138]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |
| Point in time | $ | 14,942 |  |  | $ | 13,288 |  |  | $ | 12,058 |  |
| Over time | 827 |  |  | 739 |  |  | 1,435 |  |
| Total | 15,769 |  |  | 14,027 |  |  | 13,493 |  |
| FRS |  |  |  |  |  |
| Point in time | 12,004 |  |  | 9,904 |  |  | 7,667 |  |
| Over time | 729 |  |  | 699 |  |  | 1,828 |  |
| Total | 12,733 |  |  | 10,603 |  |  | 9,495 |  |
| Nextracker |  |  |  |  |  |
| Point in time | 51 |  |  | 128 |  |  | 66 |  |
| Over time | 1,852 |  |  | 1,330 |  |  | 1,129 |  |
| Total | 1,903 |  |  | 1,458 |  |  | 1,195 |  |
| Intersegment eliminations |  |  |  |  |  |
| Point in time | (59) |  |  | (47) |  |  | (59) |  |
| Over time | — |  |  | — |  |  | — |  |
| Total | (59) |  |  | (47) |  |  | (59) |  |
| Flex |  |  |  |  |  |
| Point in time | 26,938 |  |  | 23,273 |  |  | 19,732 |  |
| Over time | 3,408 |  |  | 2,768 |  |  | 4,392 |  |
| Total | $ | 30,346 |  |  | $ | 26,041 |  |  | $ | 24,124 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-23-000028:notes:139]
SHARE-BASED COMPENSATION
Equity Compensation Plans

[0000866374-23-000028:notes:140]
Flex historically maintains stock-based compensation plans at a corporate level. The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan"). During fiscal year 2023, Nextracker granted equity compensation awards to Nextracker employees under the First Amended and Restated 2022 Nextracker LLC Equity Incentive Plan (the "2022 Nextracker Plan"), which is administered by Nextracker, a majority owned subsidiary of the Company.

[0000866374-23-000028:notes:141]
Share-Based Compensation Expense

[0000866374-23-000028:notes:142]
The following table summarizes the Company's share-based compensation expense for all equity incentive plans:

[0000866374-23-000028:notes:143]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Cost of sales | $ | 38 |  |  | $ | 24 |  |  | $ | 20 |  |
| Selling, general and administrative expenses | 95 |  |  | 67 |  |  | 59 |  |
| Total share-based compensation expense | $ | 133 |  |  | $ | 91 |  |  | $ | 79 |  |

[0000866374-23-000028:notes:144]
Cash flows resulting from excess tax benefits (tax benefits related to the excess of proceeds from employee exercises of share options over the share-based compensation cost recognized for those options) are classified as operating cash flows. During fiscal years 2023, 2022 and 2021, the Company did not recognize any excess tax benefits as an operating cash inflow.

[0000866374-23-000028:notes:145]
The 2017 Equity Incentive Plan (the "2017 Plan")

[0000866374-23-000028:notes:146]
As of March 31, 2023, the Company had approximately 11.8 million shares available for grant under the 2017 Plan. The Company no longer issues options to employees under the 2017 Plan. The number of outstanding and exercisable options are immaterial and the compensation cost related to options granted to employees under the 2017 Plan has been fully recognized as of March 31, 2023.

[0000866374-23-000028:notes:147]
The Company also grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over a two to four-year period and unvested RSU awards are generally forfeited upon termination of employment.

[0000866374-23-000028:notes:148]
Vesting for certain RSU awards is contingent upon both service and market conditions or both service and performance conditions.

[0000866374-23-000028:notes:149]
As of March 31, 2023, the total unrecognized compensation cost related to unvested RSU awards under the 2017 Plan was approximately $162 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately 2.0 years. Approximately $14 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain market conditions. Approximately $9 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain performance conditions.

[0000866374-23-000028:notes:150]
Determining Fair Value - RSU awards

[0000866374-23-000028:notes:151]
Valuation and Amortization Method—The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-23-000028:notes:152]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-23-000028:notes:153]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-23-000028:notes:154]
Expected volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2023, 2022, and 2021.

[0000866374-23-000028:notes:155]
Average peer volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of Flex's peer companies for the RSU awards granted in fiscal years 2023 and 2022, and volatility used in a Monte Carlo simulation is derived from the historical volatility of the Standard and Poor's ("S&P") 500 index for the RSU awards granted in fiscal year 2021.

[0000866374-23-000028:notes:156]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to Flex's peer companies for the RSU awards granted in fiscal years 2023 and 2022, and correlation coefficients were used to model the movement of Flex's stock price relative to the S&P 500 index for the RSU awards granted in fiscal year 2021.

[0000866374-23-000028:notes:157]
Expected Dividend —The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-23-000028:notes:158]
Risk-Free Interest Rate assumptions—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the RSU awards.

[0000866374-23-000028:notes:159]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2023, 2022, and 2021 was estimated using the following weighted-average assumptions:

[0000866374-23-000028:notes:160]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Expected volatility | 49.0 | % |  | 54.6 | % |  | 52.8 | % |
| Average peer volatility | 41.4 | % |  | 39.8 | % |  | 35.9 | % |
| Average peer correlation | 0.4 |  |  | 0.4 |  |  | 0.7 |  |
| Expected dividends | — | % |  | — | % |  | — | % |
| Risk-free interest rate | 3.0 | % |  | 0.3 | % |  | 0.3 | % |

[0000866374-23-000028:notes:161]
Share-Based Awards Activity

[0000866374-23-000028:notes:162]
Option activity for the 2017 Plan is immaterial for all periods presented.

[0000866374-23-000028:notes:163]
Cash received from option exercises under the 2017 Plan, which was reflected within other financing activities in the consolidated statement of cash flows, was immaterial for fiscal years 2023, 2022, and 2021.

[0000866374-23-000028:notes:164]
The following table summarizes the Company's RSU award activity under the 2017 Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-23-000028:notes:165]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 17,019,559 |  |  | $ | 14.13 |  |  | 17,308,625 |  |  | $ | 11.14 |  |  | 16,050,640 |  |  | $ | 11.87 |  |
| Granted (1) | 8,416,650 |  |  | 18.22 |  |  | 7,276,643 |  |  | 18.48 |  |  | 10,982,109 |  |  | 11.04 |  |
| Vested (1) | (9,229,198) |  |  | 12.51 |  |  | (5,933,605) |  |  | 10.87 |  |  | (5,520,005) |  |  | 11.64 |  |
| Forfeited | (858,396) |  |  | 15.31 |  |  | (1,632,104) |  |  | 12.42 |  |  | (4,204,119) |  |  | 11.92 |  |
| Unvested RSU awards outstanding, end of fiscal year | 15,348,615 |  |  | $ | 16.79 |  |  | 17,019,559 |  |  | $ | 14.13 |  |  | 17,308,625 |  |  | $ | 11.14 |  |

[0000866374-23-000028:notes:166]
(1)Included in the fiscal year 2023 amounts are 1.2 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market conditions for awards granted in the fiscal year 2020. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-23-000028:notes:167]
Of the 8.4 million unvested RSU awards granted in fiscal year 2023, approximately 6.1 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $17.89 per share. Further, approximately 0.5 million of these unvested RSU awards granted in fiscal year 2023 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $23.45 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-23-000028:notes:168]
Of the 15.3 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2023, approximately 2.1 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-23-000028:notes:169]
|  |  | Targetednumber ofawards as ofMarch 31, 2023(in shares) |  |  |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2023 |  | 533,946 |  |  | $ | 23.45 |  |  |  |  | — |  |  | 1,067,892 |  |  | June 2025 |
| Fiscal 2022 |  | 378,588 |  |  | 25.86 |  |  |  |  | — |  |  | 757,176 |  |  | June 2024 |
| Fiscal 2021 |  | 1,168,426 |  |  | 15.03 |  |  |  |  | — |  |  | 2,336,852 |  |  | June 2023 |
| Totals |  | 2,080,960 |  |  |  |  |  |  |  |  | 4,161,920 |  |  |  |

[0000866374-23-000028:notes:170]
(1)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal years 2023 and 2022 and based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index for RSU awards granted in fiscal year 2021.

[0000866374-23-000028:notes:171]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2023, 2.4 million shares vested in connection with the awards with market conditions granted in fiscal year 2020.

[0000866374-23-000028:notes:172]
Approximately 0.5 million of these unvested RSU awards granted in fiscal year 2023 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $16.52 per share. Vesting information for these shares is further detailed in the table below.

[0000866374-23-000028:notes:173]
Of the 15.3 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2023, approximately 0.9 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:

[0000866374-23-000028:notes:174]
|  |  | Targetednumber ofawards as ofMarch 31, 2023(in shares) |  |  |  |  |  | Range of sharesthat may be issued (1) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment date |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2023 |  | 533,946 |  |  | $ | 16.52 |  |  |  |  | — |  |  | 1,067,892 |  |  | Mar 2026 |
| Fiscal 2022 |  | 378,586 |  |  | $ | 18.24 |  |  |  |  | — |  |  | 757,172 |  |  | Mar 2025 |
| Totals |  | 912,532 |  |  |  |  |  |  |  |  | 1,825,064 |  |  |  |

[0000866374-23-000028:notes:175]
(1)    Vesting ranges from zero to 200% based on performance of Flex's average earnings per share growth.

[0000866374-23-000028:notes:176]
The total intrinsic value of RSU awards vested under all the Company's 2017 Plan was $148 million, $108 million and $69 million during fiscal years 2023, 2022 and 2021, respectively, based on the closing price of the Company's ordinary shares on the date vested.

[0000866374-23-000028:notes:177]
The 2022 Nextracker Equity Incentive Plan

[0000866374-23-000028:notes:178]
During fiscal year 2023, Nextracker awarded 5.7 million equity-based compensation awards to its employees under the 2022 Nextracker Plan, which included approximately 2.8 million options awards, 2.2 million RSU ("NRSU") awards and 0.7 million performance-based restricted share unit awards (“NPSU”). Out of the 0.7 million shares of NPSUs awarded, only 0.2 million shares met the criteria for a grant date under ASC 718 as of March 31, 2023. Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and certain performance conditions, including a liquidity event such as the IPO. Upon the completion of the IPO, the awards were modified to vest in Class A common stock of Nextracker instead of common units of Nextracker LLC. Nextracker recorded $28 million of cumulative stock-based compensation expense following the IPO in fiscal year 2023. The incremental cost recognized resulting from the modification was immaterial in fiscal year 2023.

[0000866374-23-000028:notes:179]
The fair value of the Company's awards granted under the 2022 Nextracker Plan was estimated based on the following assumptions:

[0000866374-23-000028:notes:180]
|  | Fiscal year ended March 31, 2023 |
| Expected volatility | 65.0% |
| Expected dividends | —% |
| Risk-free interest rate | 2.5% - 2.7% |

[0000866374-23-000028:notes:181]
The following table summarizes the options awards, NRSU awards and NPSU awards activity under the Nextracker 2022 Plan for the fiscal year ended March 31, 2023:

[0000866374-23-000028:notes:182]
|  | Fiscal year ended March 31, 2023 |
|  | Options (2) |  | NRSU |  | NPSU (3) |
|  | Shares |  | Weighted average fair value per share |  | Shares |  | Weighted average fair value per share |  | Shares |  | Weighted average fair value per share |
| Unvested awards outstanding, beginning of fiscal year | — |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Granted | 2,806,905 |  |  | 6.30 |  |  | 2,172,234 |  |  | 20.40 |  |  | 219,713 |  |  | 23.01 |  |
| Vested | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Forfeited (1) | (114,286) |  |  | 6.30 |  |  | (169,815) |  |  | 20.40 |  |  | — |  |  | — |  |
| Unvested awards outstanding, end of fiscal year | 2,692,619 |  |  | $ | 6.30 |  |  | 2,002,419 |  |  | $ | 20.40 |  |  | 219,713 |  |  | $ | 23.01 |  |

[0000866374-23-000028:notes:183]
(1)    Awards forfeited due to employee terminations.

[0000866374-23-000028:notes:184]
(2)    Vesting ranges from zero to 100% based on the achievement levels of Nextracker's compounded annual growth rate over the performance period.

[0000866374-23-000028:notes:185]
(3)    Vesting ranges from zero to 200% based on the achievement levels of Nextracker's total shareholder return over the performance period.

[0000866374-23-000028:notes:186]
As of March 31, 2023, total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $46 million, which is expected to be recognized over a weighted-average expected vesting period of 2.3 years.


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000866374-23-000028:notes:187]
(1)Included in the fiscal year 2023 amounts are 1.2 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market conditions for awards granted in the fiscal year 2020. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.
The following table summarizes the options awards, NRSU awards and NPSU awards activity under the Nextracker 2022 Plan for the fiscal year ended March 31, 2023:


## us-gaap:ScheduleOfNonvestedShareActivityTableTextBlock

[0000866374-23-000028:notes:188]
(1)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal years 2023 and 2022 and based on measurement of Flex's total shareholder return against the Standard and Poor's ("S&P") 500 Composite Index for RSU awards granted in fiscal year 2021.
Of the 15.3 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2023, approximately 0.9 million unvested RSU awards represent the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:


## us-gaap:EarningsPerShareTextBlock

[0000866374-23-000028:notes:189]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-23-000028:notes:190]
Diluted earnings per share reflects the potential dilution from share-based compensation awards. The potential dilution from stock options exercisable into ordinary share equivalents and restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-23-000028:notes:191]
The following table reflects the basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted income per share:

[0000866374-23-000028:notes:192]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |
| Net income | $ | 1,033 |  |  | $ | 940 |  |  | $ | 613 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 240 |  |  | 4 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 793 |  |  | $ | 936 |  |  | $ | 613 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 454 |  |  | 476 |  |  | 499 |  |
| Basic earnings per share | $ | 1.75 |  |  | $ | 1.97 |  |  | $ | 1.23 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |
| Net income | $ | 1,033 |  |  | $ | 940 |  |  | $ | 613 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 240 |  |  | 4 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 793 |  |  | $ | 936 |  |  | $ | 613 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 454 |  |  | 476 |  |  | 499 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 8 |  |  | 7 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 462 |  |  | 483 |  |  | 506 |  |
| Diluted earnings per share | $ | 1.72 |  |  | $ | 1.94 |  |  | $ | 1.21 |  |

[0000866374-23-000028:notes:193]
_________________________________________________________________________
(1)An immaterial amount RSU awards during fiscal years 2023, 2022, and 2021, respectively were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-23-000028:notes:194]
NONCONTROLLING INTEREST
Nextracker Inc.

[0000866374-23-000028:notes:195]
In the fourth quarter of fiscal year 2023, Nextracker completed an IPO through a series of reorganization transactions that resulted in Nextracker having an Up-C structure.

[0000866374-23-000028:notes:196]
Prior to the IPO, TPG Rise held preferred units representing an interest of 17.37% in the LLC. This was presented as a redeemable noncontrolling interest on Flex’s consolidated balance sheets. TPG Rise received a pro-rated 5% annual preferred dividend on its investment for the period prior to the IPO. In connection with the IPO, all of the preferred units of the LLC were automatically converted into an equal number of common units of the LLC. TPG Rise and the Flex subsidiaries holding LLC common units also subscribed for an equal number of non-economic, voting Class B common shares of Nextracker Inc. The common units of the LLC, together with a corresponding number of shares of Class B common stock are exchangeable at any time at the option of the holder for shares of Nextracker Inc. Class A common stock on a one-for-one basis or for cash, at the option of Nextracker Inc. and upon such exchange, a corresponding number of such holder's Class B common stock will be cancelled. Following the IPO, the noncontrolling interest in Nextracker comprise the Class A common stock of Nextracker (31.8% of Nextracker’s total common stock) and 6.77% respectively of Nextracker’s Class B common stock and the LLC’s common units, held by TPG Rise.

[0000866374-23-000028:notes:197]
The LLC also made a distribution in an aggregate amount of $175 million in advance of the IPO. With respect to such distribution, $50 million was distributed to Flex and the remaining $125 million to Flex's subsidiaries and TPG Rise, pro-rata in relation to their respective holdings. $22 million of the $125 million was distributed to TPG Rise in relation to their preferred units and this distribution is presented within income attributable to noncontrolling interest in the consolidated statements of operations. The distribution was financed in part with net proceeds from a $150 million term loan under a credit agreement entered into by the LLC (the “2023 Credit Agreement”). Refer to note 9 for further discussion of our debt activities.

[0000866374-23-000028:notes:198]
Flex recorded the noncontrolling interest in Nextracker as 38.6% of Nextracker's post IPO book value, with a corresponding offset to additional paid-in capital of Flex. On a subsequent measurement basis, the carrying value is adjusted for earnings attributable to the noncontrolling interest.

[0000866374-23-000028:notes:199]
As of March 31, 2023 and 2022, noncontrolling interest was $355 million and zero, and redeemable noncontrolling interest was zero and $78 million, respectively. As a result of the IPO, the noncontrolling interest previously determined redeemable prior to the IPO did not exist as of March 31, 2023. Net income attributable to noncontrolling interest and redeemable noncontrolling interest was $240 million and $4 million in fiscal years 2023 and 2022, respectively.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-23-000028:notes:200]
SUPPLEMENTAL CASH FLOW DISCLOSURESThe following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-23-000028:notes:201]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 227 |  |  | $ | 169 |  |  | $ | 147 |  |
| Income taxes | 124 |  |  | 122 |  |  | 105 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 184 |  |  | $ | 126 |  |  | $ | 102 |  |
| Pre-IPO paid-in-kind dividend to redeemable noncontrolling interest | 21 |  |  | 4 |  |  | — |  |
| Finance lease for Bright Machines assets | — |  |  | — |  |  | 4 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-23-000028:notes:202]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-23-000028:notes:203]
|  | Maturity Date |  | As of March 31, |
|  |  |  | 2023 |  | 2022 |
|  |  |  | (In millions) |
| 5.000% Notes ("2023 Notes") (1)(2)(3) | February 2023 |  | $ | — |  |  | $ | 500 |  |
| 4.750% Notes ("2025 Notes") (1)(2) | June 2025 |  | 599 |  |  | 598 |  |
| 3.750% Notes ("2026 Notes") (1)(2) | February 2026 |  | 686 |  |  | 690 |  |
| 6.000% Notes ("2028 Notes") (1)(2)(3) | January 2028 |  | 396 |  |  | — |  |
| 4.875% Notes ("2029 Notes") (1)(2) | June 2029 |  | 658 |  |  | 659 |  |
| 4.875% Notes ("2030 Notes") (1)(2) | May 2030 |  | 685 |  |  | 690 |  |
| Euro Term Loans (4) | December 2023 |  | — |  |  | 389 |  |
| JPY Term Loan (5) | April 2024 |  | 253 |  |  | 273 |  |
| Delayed Draw Term Loan (6) | November 2023 |  | 150 |  |  | — |  |
| Nextracker Term Loan (7) | February 2028 |  | 150 |  |  | — |  |
| 3.600% HUF Bonds (8) | December 2031 |  | 284 |  |  | 301 |  |
| India Facilities (9) | May 2023 and June 2023 |  | — |  |  | 84 |  |
| Other |  |  | 1 |  |  | 31 |  |
| Debt issuance costs |  |  | (21) |  |  | (18) |  |
|  |  |  | 3,841 |  |  | 4,197 |  |
| Current portion, net of debt issuance costs |  |  | (150) |  |  | (949) |  |
| Non-current portion |  |  | $ | 3,691 |  |  | $ | 3,248 |  |

[0000866374-23-000028:notes:204]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs.

[0000866374-23-000028:notes:205]
(2)The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-23-000028:notes:206]
(3)In December 2022, the Company issued $400 million of 6.000% Notes due 2028. The Company received proceeds of approximately $396 million, net of discount, from the issuance which were used, together with cash on hand, for general corporate purposes, which included redeeming its 2023 notes in December 2022, and for working capital requirements.

[0000866374-23-000028:notes:207]
(4)In December 2021, the Company borrowed €350 million under a 1-year term loan agreement. The proceeds of the term loan were used to refinance certain other outstanding debt and for other general corporate purposes. During fiscal year 2023, the Company repaid all outstanding Euro term loans.

[0000866374-23-000028:notes:208]
(5)In April 2019, the Company entered into a JPY 33.5 billion term loan agreement at three-month TIBOR plus 0.430%, which was then swapped to U.S. dollars. The term loan, which is subject to quarterly interest payments, was used to fund general operations and refinance certain other outstanding debt.

[0000866374-23-000028:notes:209]
(6)In September 2022, the Company entered into a $450 million delayed draw term loan credit agreement, under which $300 million was repaid during fiscal year 2023, and $150 million of borrowings was outstanding as of March 31, 2023. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. Interest is based on either (a) a Term SOFR-based formula plus a margin of 100.0 basis points to 162.5 basis points, depending on the Company's credit ratings, or (b) a Base Rate (the greatest of the agent's prime rate, the federal funds rate plus 0.50%, and the Term SOFR plus 1.00%) formula plus a margin of 0.0 basis point to 62.5 basis points, depending on the Company's credit ratings.

[0000866374-23-000028:notes:210]
(7)In February 2023, Nextracker LLC borrowed $150 million under a five-year term loan credit facility to finance the cash distribution in connection with the initial public offering of the Nextracker Inc. $3 million in debt issuance costs were incurred to obtain the term loan financing. The Nextracker term loan requires quarterly principal payments beginning on June 30, 2024 in an amount equal to 0.625% of the original aggregate principal amount of the Nextracker term loan. From June 30, 2025, the quarterly principal payment will increase to 1.25% of the original aggregate principal amount of the Nextracker term loan. The remaining balance of the Nextracker term loan will be repayable on February 11, 2028. The interest rate of the Nextracker term loan is 5.12% (SOFR rate of 3.49% plus a margin of 1.63%).

[0000866374-23-000028:notes:211]
(8)In December 2021, the Company issued HUF 100 billion (approximately $284 million as of March 31, 2023) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations. The outstanding principal amount of the bonds bear interest at 3.60% per annum. The proceeds of the bonds were used for general corporate purposes.

[0000866374-23-000028:notes:212]
(9)In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "India Facilities"). The India Facility was used to fund capital expenditures to support the Company's expansion plans for India. The Company repaid all outstanding borrowings during fiscal year 2023.

[0000866374-23-000028:notes:213]
Revolving Credit Facilities:

[0000866374-23-000028:notes:214]
In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026. As of March 31, 2023 and 2022, no borrowings were outstanding.

[0000866374-23-000028:notes:215]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate, plus 1.0%; plus, an applicable margin ranging from 0.125% to 0.750% per annum, based on the Company’s credit ratings or (ii) Term SOFR (or (x) the “Alternative Currency Term Rate”, which is defined as, depending on the applicable currency at issue, either the Euro Interbank Offered Rate, Tokyo Interbank Offer Rate, or such other term rate per annum as designated with respect to such alternative currency or (y) the “Alternative Currency Daily Rate”, which is defined as, in the case of Sterling, the rate per annum equal to Sterling Overnight Index Average, and for any other alternative currency, such other term rate per annum as designated with respect to such alternative currency) plus the applicable margin for Term SOFR rate (or the Alternative Currency Term Rate) loans ranging between 1.125% and 1.750% per annum, based on the Company’s credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or the Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on the Company’s credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the Company’s credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-23-000028:notes:216]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-23-000028:notes:217]
In February 2023, Nextracker Inc., and the LLC, as the borrower, entered into a senior credit facility with a syndicate of banks (the “2023 Credit Agreement”) comprised of (i) a term loan in the aggregate principal amount of $150 million (the “Term Loan”), and (ii) a revolving credit facility in an aggregate principal amount of $500 million (the “RCF”). The LLC borrowed $150 million under the Term Loan, and used the proceeds to finance, in part, the Distribution. The RCF is available in U.S. dollars, euros and such currencies as mutually agreed on a revolving basis during the five-year period through February 11, 2028 and is available to fund working capital and other general corporate purposes. A portion of the RCF not to exceed $300 million is available for the issuance of letters of credit. A portion of the RCF not to exceed $50 million is available for swing line loans.

[0000866374-23-000028:notes:218]
Borrowings in U.S. dollars under the 2023 Credit Agreement bear interest at a rate based on either (a) a term secured overnight financing rate (“SOFR”) based formula (including a credit spread adjustment of 10 basis points) plus a margin of 162.5 basis points to 200 basis points, depending on the LLC’s total net leverage ratio, or (b) a Base Rate formula plus a margin of 62.5 basis point to 100 basis points, depending on the LLC’s total net leverage ratio. Borrowings under the RCF in euros will bear interest based on the adjusted EURIBOR rate plus a margin of 162.5 basis points to 200 basis points, depending on the LLC’s total net leverage ratio. The LLC will also be required to pay a quarterly commitment fee on the undrawn portion of the

[0000866374-23-000028:notes:219]
RCF of 20 basis points to 35 basis points, depending on the LLC’s total net leverage ratio. The interest rate for the Term Loan is 5.12% (SOFR rate of 3.49% plus a margin of 1.63%).

[0000866374-23-000028:notes:220]
The 2023 Credit Agreement contains certain affirmative and negative covenants that, among other things and subject to certain exceptions, limit the ability of the LLC and its restricted subsidiaries to incur additional indebtedness or liens, to dispose of assets, change their fiscal year or lines of business, pay dividends and other restricted payments, make investments and other acquisitions, make optional payments of subordinated and junior lien debt, enter into transactions with affiliates and enter into restrictive agreements. In addition, the 2023 Credit Agreement requires the LLC to maintain a maximum consolidated total net leverage ratio.

[0000866374-23-000028:notes:221]
As of March 31, 2023, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities in the amount of $317 million in the aggregate. There were no borrowings outstanding under these facilities as of March 31, 2023 and 2022. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.

[0000866374-23-000028:notes:222]
Debt Covenants:

[0000866374-23-000028:notes:223]
Borrowings under the Company’s debt agreements are subject to various covenants that limit the Company’s ability to incur additional indebtedness, sell assets, effect mergers and certain transactions, and effect certain transactions with subsidiaries and affiliates. In addition, the 2027 Credit Facility, and the Delayed Draw Term Loan also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. The Company is also subject to certain covenants requiring the Company to offer to repurchase the 2025 Notes, 2026 Notes, 2028 Notes, 2029 Notes, and 2030 Notes (collectively the “Notes”) upon a change of control. As of March 31, 2023 and 2022, the Company was in compliance with its debt covenants.

[0000866374-23-000028:notes:224]
The weighted-average interest rates for the Company's long-term debt were 4.7% and 4.0% as of March 31, 2023 and 2022, respectively.

[0000866374-23-000028:notes:225]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-23-000028:notes:226]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2024 | $ | 150 |  |
| 2025 | 253 |  |
| 2026 | 1,285 |  |
| 2027 | — |  |
| 2028 | 546 |  |
| Thereafter | 1,628 |  |
| Total | $ | 3,862 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-23-000028:notes:227]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-23-000028:notes:228]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, forecasted sales and cost of sales, and monetary assets and liabilities in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and option contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-23-000028:notes:229]
As of March 31, 2023, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $11.1 billion as summarized below:

[0000866374-23-000028:notes:230]
|  |  |  | Notional ContractValue in USD |
| Currency |  |  |  |  | Buy |  | Sell |
|  |  |  |  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| HUF |  |  |  |  | $ | 418 |  |  | $ | — |  |
| JPY |  |  |  |  | 300 |  |  | — |  |
| MXN |  |  |  |  | 448 |  |  |  |
| Other |  |  |  |  | 641 |  |  | 69 |  |
|  |  |  |  |  | 1,807 |  |  | 69 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| CNY |  |  |  |  | 677 |  |  | 89 |  |
| EUR |  |  |  |  | 2,273 |  |  | 2,466 |  |
| GBP |  |  |  |  | 289 |  |  | 323 |  |
| MXN |  |  |  |  | 595 |  |  | 452 |  |
| MYR |  |  |  |  | 437 |  |  | 243 |  |
| Other |  |  |  |  | 779 |  |  | 609 |  |
|  |  |  |  |  | 5,050 |  |  | 4,182 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 6,857 |  |  | $ | 4,251 |  |

[0000866374-23-000028:notes:231]
As of March 31, 2023 and 2022, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were immaterial as of March 31, 2023, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap and the USD HUF cross currency swaps, which are further discussed below.

[0000866374-23-000028:notes:232]
The Company entered into a USD JPY cross currency swap in April 2019 to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in current and long-term other liabilities as of March 31, 2023, and March 31, 2022, respectively. The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current assets and long-term other liabilities as of March 31, 2023, and March 31, 2022, respectively. The changes in fair value of the USD JPY cross currency swap and the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurements of the underlying JPY loan principal and HUF bond principal, which also impact the same line.

[0000866374-23-000028:notes:233]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2023 and 2022:

[0000866374-23-000028:notes:234]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2023 |  | March 31,2022 |  | Balance SheetLocation |  | March 31,2023 |  | March 31,2022 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 46 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 22 |  |  | $ | 35 |  |
| Foreign currency contracts | Other assets |  | — |  |  | — |  |  | Other liabilities |  | 88 |  |  | 61 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 26 |  |  | $ | 21 |  |  | Other current liabilities |  | $ | 19 |  |  | $ | 26 |  |

[0000866374-23-000028:notes:235]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-23-000028:notes:236]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2023, 2022 and 2021 are as follows:

[0000866374-23-000028:notes:237]
|  | Unrealized loss onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance on March 31, 2020 | $ | (82) |  |  | $ | (133) |  |  | $ | (215) |  |
| Other comprehensive gain before reclassifications | 48 |  |  | 56 |  |  | 104 |  |
| Net gains reclassified from accumulated other comprehensive loss | (8) |  |  | — |  |  | (8) |  |
| Net current-period other comprehensive gain | 40 |  |  | 56 |  |  | 96 |  |
| Ending balance on March 31, 2021 | $ | (42) |  |  | $ | (77) |  |  | $ | (119) |  |
| Other comprehensive loss before reclassifications | (49) |  |  | (44) |  |  | (93) |  |
| Net losses reclassified from accumulated other comprehensive loss | 25 |  |  | 5 |  |  | 30 |  |
| Net current-period other comprehensive loss | (24) |  |  | (39) |  |  | (63) |  |
| Ending balance on March 31, 2022 | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive loss before reclassifications | (25) |  |  | (67) |  |  | (92) |  |
| Net losses reclassified from accumulated other comprehensive loss | 77 |  |  | 3 |  |  | 80 |  |
| Net current-period other comprehensive gain (loss) | 52 |  |  | (64) |  |  | (12) |  |
| Ending balance on March 31, 2023 | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |

[0000866374-23-000028:notes:238]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the fiscal year 2023 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the consolidated statement of operations, which primarily relate to the Company's foreign currency contracts accounted for as cash flow hedges. Net (gains) losses reclassified from accumulated other 
comprehensive loss were $80 million and $30 million loss during fiscal year 2023 and 2022, respectively, and were immaterial during fiscal year 2021.The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-23-000028:notes:239]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-23-000028:notes:240]
Asset-Backed Securitization Programs

[0000866374-23-000028:notes:241]
The Company maintains asset-backed securitization programs (the “ABS Programs”) under which it has the ability to sell pools of trade receivables to affiliated special purpose entities, each of which in turn can sell the receivables to unaffiliated financial institutions, based on the Company's requirements. Under these programs, the entire purchase price of sold receivables are paid in cash. The ABS Programs contain guarantees of payment by the special purpose entities, in amounts equal to approximately the net cash proceeds under the programs, and are collateralized by certain receivables held by the special purpose entities. The fair value of the guarantee obligation was zero as of both March 31, 2023 and March 31, 2022.

[0000866374-23-000028:notes:242]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are legally isolated from the Company and its affiliates. Upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, the receivables are derecognized from our consolidated balance sheet as effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Accounts receivable balances sold under the ABS Programs are included as cash provided by operating activities in the consolidated statement of cash flow. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors.

[0000866374-23-000028:notes:243]
As of March 31, 2023 and March 31, 2022, no accounts receivable were sold under the ABS programs.

[0000866374-23-000028:notes:244]
For the fiscal year ended March 31, 2021, cash flows from sales of receivables from the special purpose entities to unaffiliated financial institutions during fiscal year 2021 totaled approximately $0.6 billion.

[0000866374-23-000028:notes:245]
Trade Accounts Receivable Sale Programs

[0000866374-23-000028:notes:246]
The Company also sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.8 billion and $0.6 billion as of March 31, 2023 and 2022, respectively. For the fiscal years ended March 31, 2023, 2022 and 2021, total accounts receivable sold to certain third party banking institutions was approximately $3.5 billion, $1.6 billion and $0.8 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received was included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-23-000028:notes:247]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-23-000028:notes:248]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of March 31, 2023.

[0000866374-23-000028:notes:249]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-23-000028:notes:250]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-23-000028:notes:251]
The Company's cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-23-000028:notes:252]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-23-000028:notes:253]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-23-000028:notes:254]
There were no transfers between levels in the fair value hierarchy during fiscal years 2023 and 2022.

[0000866374-23-000028:notes:255]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-23-000028:notes:256]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2023 and 2022:

[0000866374-23-000028:notes:257]
|  | Fair Value Measurements as of March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 2,324 |  |  | $ | — |  |  | $ | 2,324 |  |
| Foreign currency contracts (Note 10) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |

[0000866374-23-000028:notes:258]
|  | Fair Value Measurements as of March 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 2,285 |  |  | $ | — |  |  | $ | 2,285 |  |
| Foreign currency contracts (Note 10) | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (122) |  |  | $ | — |  |  | $ | (122) |  |

[0000866374-23-000028:notes:259]
Other financial instruments

[0000866374-23-000028:notes:260]
The following table presents the Company's major debts not carried at fair value as of March 31, 2023 and 2022:

[0000866374-23-000028:notes:261]
|  | As of March 31, 2023 |  | As of March 31, 2022 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| 5.000% Notes due February 2023 | $ | — |  |  | $ | — |  |  | $ | 500 |  |  | $ | 511 |  |  | Level 1 |
| JPY Term Loan due April 2024 - three-month TIBOR plus 0.430% | 253 |  |  | 253 |  |  | 273 |  |  | 273 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 599 |  |  | 590 |  |  | 598 |  |  | 615 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 686 |  |  | 657 |  |  | 690 |  |  | 690 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 396 |  |  | 399 |  |  | — |  |  | — |  |  | Level 1 |
| 4.875% Notes due June 2029 | 658 |  |  | 631 |  |  | 659 |  |  | 687 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 685 |  |  | 661 |  |  | 690 |  |  | 713 |  |  | Level 1 |
| Euro Term Loans | — |  |  | — |  |  | 389 |  |  | 389 |  |  | Level 2 |
| Delayed Draw Term Loan | 150 |  |  | 150 |  |  | — |  |  | — |  |  | Level 2 |
| Nextracker Term Loan | 150 |  |  | 150 |  |  | — |  |  | — |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 284 |  |  | 196 |  |  | 301 |  |  | 301 |  |  | Level 2 |
| India Facilities | — |  |  | — |  |  | 84 |  |  | 84 |  |  | Level 2 |

[0000866374-23-000028:notes:262]
The Notes due June 2025, February 2026, January 2028, June 2029 and May 2030 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.
The JPY Term Loan due April 2024, Delayed Draw Term Loan, and Nextracker Term Loan bear interest at floating interest rates, and therefore, as of March 31, 2023, the carrying amounts approximate fair values.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-23-000028:notes:263]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-23-000028:notes:264]
As of March 31, 2023 and 2022, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2040. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-23-000028:notes:265]
Litigation and other legal matters

[0000866374-23-000028:notes:266]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-23-000028:notes:267]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in the Company's favor. Additionally,

[0000866374-23-000028:notes:268]
litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-23-000028:notes:269]
From time to time, the Company enters into intellectual property licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third-party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome.

[0000866374-23-000028:notes:270]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $81 million based on the exchange rate as of March 31, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $12 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $51 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes there is no legal basis for any of these assessments and that it has meritorious defenses. The Company will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-23-000028:notes:271]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter.  On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000028:notes:272]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $167 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2019. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-23-000028:notes:273]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-23-000028:notes:274]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-23-000028:notes:275]
INCOME TAXES
The domestic (Singapore) and foreign components of income before income taxes were comprised of the following:

[0000866374-23-000028:notes:276]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Domestic | $ | 99 |  |  | $ | 352 |  |  | $ | 242 |  |
| Foreign | 875 |  |  | 693 |  |  | 472 |  |
| Total | $ | 974 |  |  | $ | 1,045 |  |  | $ | 714 |  |

[0000866374-23-000028:notes:277]
The provision for income taxes consisted of the following:

[0000866374-23-000028:notes:278]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 6 |  |  | $ | 3 |  |  | $ | 1 |  |
| Foreign | 136 |  |  | 146 |  |  | 105 |  |
|  | 142 |  |  | 149 |  |  | 106 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 1 |  |  | — |  |  | 1 |  |
| Foreign | (202) |  |  | (44) |  |  | (6) |  |
|  | (201) |  |  | (44) |  |  | (5) |  |
| Provision for (benefit from) income taxes | $ | (59) |  |  | $ | 105 |  |  | $ | 101 |  |

[0000866374-23-000028:notes:279]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2023, 2022 and 2021. The reconciliation of the income tax expense expected based on domestic statutory income tax rates to the expense for income taxes included in the consolidated statements of operations is as follows:

[0000866374-23-000028:notes:280]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Income taxes based on domestic statutory rates | $ | 166 |  |  | $ | 178 |  |  | $ | 121 |  |
| Effect of jurisdictional tax rate differential | 5 |  |  | (114) |  |  | (82) |  |
| Change in unrecognized tax benefit | (7) |  |  | 12 |  |  | 11 |  |
| Change in valuation allowance | (47) |  |  | 12 |  |  | 35 |  |
| Foreign exchange movement on prior year taxes recoverable | 4 |  |  | (9) |  |  | 5 |  |
| Tax impacts related to sale of Nextracker | 16 |  |  | 13 |  |  | — |  |
| APB23 tax liability | — |  |  | 1 |  |  | 1 |  |
| Restructuring of Nextracker LLC interest | (195) |  |  | — |  |  | — |  |
| Other | (1) |  |  | 12 |  |  | 10 |  |
| Provision for (benefit from) income taxes | $ | (59) |  |  | $ | 105 |  |  | $ | 101 |  |

[0000866374-23-000028:notes:281]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2023, 2022 and 2021 was $14 million, $23 million and $21 million, respectively. For the fiscal year ended March 31, 2023, the effect on basic and diluted earnings per share was $0.03 and $0.03, respectively, and the effects on basic and diluted earnings per share during fiscal years 2022 and 2021 were $0.05 and $0.05, and $0.04 and $0.04, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years

[0000866374-23-000028:notes:282]
through the end of fiscal year 2028. The primary driver of the negative effective tax rate for fiscal year 2023 relates to the recording of a $195 million deferred tax asset, with an offset entry to income tax benefit fully attributable to noncontrolling interest in connection with the Nextracker IPO whereby Nextracker Inc. purchased Nextracker LLC units from a related Flex U.S. subsidiary.

[0000866374-23-000028:notes:283]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal year 2023, 2022 and 2021, the Company released valuation allowances totaling $12 million, $26 million and $25 million, respectively. For fiscal year 2023, $12 million valuation allowance release was mainly related to certain operations in Australia, and the Netherlands as these amounts were deemed to be more likely than not to be realized due to the sustained profitability during the past three fiscal years as well as continued forecasted profitability of those operations. During fiscal year 2023, the Company also added $12 million in valuation allowance primarily for the deferred tax assets related to operations in Hungary, Canada, and Switzerland. Various other valuation allowance positions were also reduced due to varying factors such as recognition of uncertain tax positions impacting deferred tax assets, one-time income recognition in loss entities, and foreign exchange impacts on deferred tax balances, and increased deferred tax assets as a result of current period losses in legal entities with existing full valuation allowance positions. For fiscal years ended March 31, 2023, 2022 and 2021, the offsetting amounts totaled $(48) million, $39 million and $60 million, respectively.

[0000866374-23-000028:notes:284]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effect of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2023, 2022 and 2021 were $31 million, $105 million and $57 million, respectively.

[0000866374-23-000028:notes:285]
The components of deferred income taxes are as follows:

[0000866374-23-000028:notes:286]
|  | As of March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (63) |  |  | $ | (49) |  |
| Intangible assets | (71) |  |  | (89) |  |
| Others | (38) |  |  | (14) |  |
| Total deferred tax liabilities | (172) |  |  | (152) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 77 |  |  | 72 |  |
| Intangible assets | 5 |  |  | 6 |  |
| Deferred compensation | 27 |  |  | 22 |  |
| Inventory valuation | 24 |  |  | 26 |  |
| Provision for doubtful accounts | 3 |  |  | 5 |  |
| Net operating loss and other carryforwards | 1,359 |  |  | 1,542 |  |
| Investment in Nextracker LLC | 249 |  |  | — |  |
| Others | 136 |  |  | 201 |  |
| Total deferred tax assets | 1,880 |  |  | 1,874 |  |
| Valuation allowances | (1,373) |  |  | (1,631) |  |
| Total deferred tax assets, net of valuation allowances | 507 |  |  | 243 |  |
| Net deferred tax asset | $ | 335 |  |  | $ | 91 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 412 |  |  | $ | 177 |  |
| Long-term liability | (77) |  |  | (86) |  |
| Total | $ | 335 |  |  | $ | 91 |  |

[0000866374-23-000028:notes:287]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate

[0000866374-23-000028:notes:288]
sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-23-000028:notes:289]
The Company has recorded deferred tax assets of approximately $1.5 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $62 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-23-000028:notes:290]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
| Fiscal year | (In millions) |
| 2024 - 2029 | $ | 415 |  |
| 2030 - 2035 | 232 |  |
| 2036 and post | 78 |  |
| Indefinite | 743 |  |
|  | $ | 1,468 |  |

[0000866374-23-000028:notes:291]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-23-000028:notes:292]
The Company does not provide for income taxes on approximately $1.9 billion of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $169 million. As a result, as of March 31, 2023, the Company has concluded for all earnings in foreign subsidiaries are considered to be indefinitely reinvested and therefore zero deferred tax liabilities were recorded.

[0000866374-23-000028:notes:293]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-23-000028:notes:294]
|  | Fiscal Year EndedMarch 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 282 |  |  | $ | 266 |  |
| Additions based on tax position related to the current year | 15 |  |  | 27 |  |
| Additions for tax positions of prior years | 8 |  |  | 15 |  |
| Reductions for tax positions of prior years | (5) |  |  | (7) |  |
| Reductions related to lapse of applicable statute of limitations | (13) |  |  | (16) |  |
| Settlements | (7) |  |  | — |  |
| Impact from foreign exchange rates fluctuation | (12) |  |  | (3) |  |
| Balance, end of fiscal year | $ | 268 |  |  | $ | 282 |  |

[0000866374-23-000028:notes:295]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $84 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-23-000028:notes:296]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2008.

[0000866374-23-000028:notes:297]
Of the $268 million of unrecognized tax benefits at March 31, 2023, $185 million will affect the annual effective tax rate (ETR) if the benefits are eventually recognized. The amount that doesn’t impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-23-000028:notes:298]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2023, 2022 and 2021, the Company recognized interest and penalties of approximately ($1) million, $2 million and $2 million, respectively. The Company had approximately $15 million, $16 million and $14 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2023, 2022 and 2021, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-23-000028:notes:299]
RESTRUCTURING CHARGES
Fiscal Year 2023

[0000866374-23-000028:notes:300]
The Company continued to identify certain structural changes to restructure its business throughout fiscal year 2023. During fiscal year 2023, the Company recognized approximately $27 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income, as disclosed further in note 21.

[0000866374-23-000028:notes:301]
Fiscal Year 2022

[0000866374-23-000028:notes:302]
The Company identified certain structural changes to restructure its business throughout fiscal year 2022. During fiscal year 2022, the Company recognized approximately $15 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income.

[0000866374-23-000028:notes:303]
Fiscal Year 2021

[0000866374-23-000028:notes:304]
In order to support the Company’s strategy and build a sustainable organization, and after considering that the economic recovery from the COVID-19 pandemic would be slower than anticipated, the Company identified certain structural changes to restructure its business. These restructuring actions eliminated non-core activities primarily within the Company’s corporate function, aligned the Company’s cost structure with its reorganizing and optimizing of its operations model along its reporting segments, and further sharpened its focus to winning business in end markets where it has competitive advantages and deep domain expertise. During fiscal year 2021, the Company recognized approximately $101 million of restructuring charges, most of which related to employee severance.

[0000866374-23-000028:notes:305]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2020 | $ | 19 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 23 |  |
| Provision for charges incurred in fiscal year 2021 | 89 |  |  | 8 |  |  | 4 |  |  | 101 |  |
| Cash payments for charges incurred in fiscal year 2020 and prior | (14) |  |  | — |  |  | — |  |  | (14) |  |
| Cash payments for charges incurred in fiscal year 2021 | (49) |  |  | — |  |  | (1) |  |  | (50) |  |
| Non-cash charges incurred in fiscal year 2021 | — |  |  | (8) |  |  | 1 |  |  | (7) |  |
| Balance as of March 31, 2021 | 45 |  |  | — |  |  | 8 |  |  | 53 |  |
| Provision for charges incurred in fiscal year 2022 | 11 |  |  | 1 |  |  | 3 |  |  | 15 |  |
| Cash payments for charges incurred in fiscal year 2021 and prior | (15) |  |  | — |  |  | — |  |  | (15) |  |
| Cash payments for charges incurred in fiscal year 2022 | (6) |  |  | — |  |  | — |  |  | (6) |  |
| Non-cash charges incurred in fiscal year 2022 | — |  |  | (1) |  |  | (3) |  |  | (4) |  |
| Balance as of March 31, 2022 | 35 |  |  | — |  |  | 8 |  |  | 43 |  |
| Provision for charges incurred in fiscal year 2023 | 27 |  |  | — |  |  | — |  |  | 27 |  |
| Cash payments for charges incurred in fiscal year 2022 and prior | (7) |  |  | — |  |  | — |  |  | (7) |  |
| Cash payments for charges incurred in fiscal year 2023 | (11) |  |  | — |  |  | — |  |  | (11) |  |
| Non-cash charges incurred in fiscal year 2023 | — |  |  | — |  |  | (2) |  |  | (2) |  |
| Balance as of March 31, 2023 | 44 |  |  | — |  |  | 6 |  |  | 50 |  |
| Less: Current portion (classified as other current liabilities) | 44 |  |  | — |  |  | 6 |  |  | 50 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-23-000028:notes:306]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2023, 2022 and 2021 are primarily comprised of the following:

[0000866374-23-000028:notes:307]
|  | Fiscal Year Ended March 31 |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Gain on foreign exchange transactions | $ | (7) |  |  | $ | (32) |  |  | $ | (21) |  |
| Investment impairments (1) | — |  |  | 3 |  |  | 37 |  |
| Brazil tax credit (2) | — |  |  | (150) |  |  | — |  |

[0000866374-23-000028:notes:308]
(1)During fiscal years 2022 and 2021, and in connection with the Company’s ongoing assessment of recoverability of its investment portfolio, the Company concluded that the carrying amounts of certain non-core investments were other than temporarily impaired and recognized $3 million and $37 million of total impairment charges, respectively (See note 2 for additional information). 
(2)The Company recognized a $150 million gain related to a certain tax credit upon approval of a "Credit Habilitation" request by the relevant Brazil tax authorities for fiscal year 2022.


## flex:InterestAndOtherNetTextBlock

[0000866374-23-000028:notes:309]
INTEREST, NETInterest, net for the fiscal years ended March 31, 2023, 2022 and 2021 are primarily comprised of the following:

[0000866374-23-000028:notes:310]
|  | Fiscal Year Ended March 31 |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 187 |  |  | $ | 153 |  |  | $ | 150 |  |
| Interest income | (30) |  |  | (14) |  |  | (14) |  |
| ABS and AR sales programs related expenses | 39 |  |  | 5 |  |  | 11 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000866374-23-000028:notes:311]
BUSINESS AND ASSET ACQUISITIONS & DIVESTITURES
Fiscal 2023 Divestitures

[0000866374-23-000028:notes:312]
During the fiscal year ended March 31, 2023, the Company disposed of a non-strategic business within the FRS segment. The Company received approximately $4 million of proceeds. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The net gain on dispositions was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for the fiscal year 2023.

[0000866374-23-000028:notes:313]
Fiscal 2022 Business acquisition

[0000866374-23-000028:notes:314]
On December 1, 2021, the Company completed the business acquisition of Anord Mardix, a global leader in critical power solutions for an initial purchase consideration of $523 million, net of $25 million cash acquired, with an additional $17 million deferred purchase price paid out in the fourth quarter of fiscal year 2022, for a total purchase consideration of $539 million. The acquisition added to the Company's portfolio of Power products and expanded its offering in the data center market. For reporting purposes, Anord Mardix was included in the Industrial reporting unit within the FRS segment. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill. The results of operations of the acquisition were included in the Company’s consolidated financial results beginning on the date of acquisition, and the total amount of net income and revenue were not material to the Company's consolidated financial results for fiscal year 2022.

[0000866374-23-000028:notes:315]
The intangible assets of $273 million are comprised of customer related intangible assets of $147 million and licenses and other intangible assets such as trade names and developed technology of $126 million. Customer related assets are amortized over a weighted-average estimated useful life of 8.7 years while licensed and other intangibles are amortized over a weighted-average estimated useful life of 8.9 years.


## us-gaap:TreasuryStockTextBlock

[0000866374-23-000028:notes:316]
SHARE REPURCHASE PLAN
During fiscal year 2023, the Company repurchased approximately 19.8 million shares for an aggregate purchase price of approximately $337 million and retired all of these shares.

[0000866374-23-000028:notes:317]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 25, 2022. As of March 31, 2023, shares in the aggregate amount of $893 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-23-000028:notes:318]
SEGMENT REPORTING
The Company's Chief Executive Officer is our Chief Operating Decision Maker ("CODM") who evaluates how we allocate resources, assesses performance and make strategic and operational decisions. Based on such evaluation, the Company determined as of and for the period ended March 31, 2023, that Flex has three operating and reportable segments.

[0000866374-23-000028:notes:319]
The FAS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. FAS is comprised of the following end markets that represent reporting units:

[0000866374-23-000028:notes:320]
•Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

[0000866374-23-000028:notes:321]
•Lifestyle, including appliances, consumer packaging, floorcare, micro mobility and audio

[0000866374-23-000028:notes:322]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-23-000028:notes:323]
The FRS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models and critical environments. FRS is comprised of the following end markets that represent reporting units:

[0000866374-23-000028:notes:324]
•Automotive, including next generation mobility, autonomous, connectivity, electrification, and smart technologies

[0000866374-23-000028:notes:325]
•Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-23-000028:notes:326]
•Industrial, including capital equipment, industrial devices, and renewables and grid edge.

[0000866374-23-000028:notes:327]
The Nextracker segment provides solar tracker technologies that optimize and increase energy production while reducing costs for significant plant return on investment:

[0000866374-23-000028:notes:328]
The determination of the separate operating and reporting segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-23-000028:notes:329]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset recoveries, restructuring charges, legal and other, interest, net, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-23-000028:notes:330]
Selected financial information by segment is in the table below.

[0000866374-23-000028:notes:331]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |
| Flex Agility Solutions | $ | 15,769 |  |  | $ | 14,027 |  |  | $ | 13,493 |  |
| Flex Reliability Solutions | 12,733 |  |  | 10,603 |  |  | 9,495 |  |
| Nextracker | 1,903 |  |  | 1,458 |  |  | 1,195 |  |
| Intersegment eliminations | (59) |  |  | (47) |  |  | (59) |  |
|  | $ | 30,346 |  |  | $ | 26,041 |  |  | $ | 24,124 |  |
| Segment income and reconciliation of income before income taxes: |  |  |  |  |  |
| Flex Agility Solutions | $ | 694 |  |  | $ | 605 |  |  | $ | 449 |  |
| Flex Reliability Solutions | 607 |  |  | 546 |  |  | 484 |  |
| Nextracker | 203 |  |  | 90 |  |  | 178 |  |
| Corporate and Other | (62) |  |  | (72) |  |  | (80) |  |
| Total segment income | 1,442 |  |  | 1,169 |  |  | 1,031 |  |
| Reconciling items: |  |  |  |  |  |
| Intangible amortization | 82 |  |  | 68 |  |  | 62 |  |
| Stock-based compensation | 133 |  |  | 91 |  |  | 79 |  |
| Customer related asset recoveries | — |  |  | — |  |  | (7) |  |
| Restructuring charges (Note 16) | 27 |  |  | 15 |  |  | 101 |  |
| Legal and other (1) | 16 |  |  | 23 |  |  | 1 |  |
| Interest, net | 201 |  |  | 152 |  |  | 148 |  |
| Other charges (income), net | 5 |  |  | (164) |  |  | 16 |  |
| Equity in earnings (losses) of unconsolidated affiliates | (4) |  |  | 61 |  |  | 83 |  |
| Income before income taxes | $ | 974 |  |  | $ | 1,045 |  |  | $ | 714 |  |

[0000866374-23-000028:notes:332]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-23-000028:notes:333]
During the fiscal year 2022, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims.

[0000866374-23-000028:notes:334]
Legal and other during fiscal year 2021 primarily consists of costs accrued for certain loss contingencies where losses are considered probable and estimable, offset by a gain on the sale of real estate in the fourth quarter of fiscal year 2021 exited as a result of the disengagement of a certain customer in fiscal year 2020.

[0000866374-23-000028:notes:335]
Corporate and Other primarily includes corporate service costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-23-000028:notes:336]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-23-000028:notes:337]
Property and equipment on a segment basis is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2023, 2022 and 2021, depreciation expense included in the segments' measure of operating performance above is as follows.

[0000866374-23-000028:notes:338]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Flex Agility Solutions | $ | 177 |  |  | $ | 184 |  |  | $ | 185 |  |
| Flex Reliability Solutions | 217 |  |  | 204 |  |  | 210 |  |
| Nextracker | 4 |  |  | 3 |  |  | 2 |  |
| Corporate and Other | 16 |  |  | 18 |  |  | 25 |  |
| Total depreciation expense | $ | 414 |  |  | $ | 409 |  |  | $ | 422 |  |

[0000866374-23-000028:notes:339]
Geographic information of net sales is as follows:

[0000866374-23-000028:notes:340]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 13,773 |  |  | 45 | % |  | $ | 10,839 |  |  | 42 | % |  | $ | 9,672 |  |  | 40 | % |
| Asia | 10,361 |  |  | 34 | % |  | 9,601 |  |  | 37 | % |  | 9,326 |  |  | 39 | % |
| Europe | 6,212 |  |  | 21 | % |  | 5,601 |  |  | 21 | % |  | 5,126 |  |  | 21 | % |
|  | $ | 30,346 |  |  |  |  | $ | 26,041 |  |  |  |  | $ | 24,124 |  |  |  |

[0000866374-23-000028:notes:341]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-23-000028:notes:342]
During fiscal years 2023, 2022 and 2021, net sales generated from Singapore, the country of domicile, were approximately $552 million, $519 million and $507 million, respectively.

[0000866374-23-000028:notes:343]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2023, 2022, and 2021:

[0000866374-23-000028:notes:344]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,589 |  |  | 22 | % |  | $ | 5,059 |  |  | 19 | % |  | $ | 4,413 |  |  | 18 | % |
| China | 6,539 |  |  | 22 | % |  | 6,146 |  |  | 24 | % |  | 6,147 |  |  | 25 | % |
| U.S. | 5,020 |  |  | 17 | % |  | 3,690 |  |  | 14 | % |  | 3,648 |  |  | 15 | % |

[0000866374-23-000028:notes:345]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-23-000028:notes:346]
Geographic information of property and equipment, net is as follows:

[0000866374-23-000028:notes:347]
|  | As of March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,221 |  |  | 52 | % |  | $ | 1,075 |  |  | 51 | % |
| Asia | 618 |  |  | 26 | % |  | 561 |  |  | 26 | % |
| Europe | 510 |  |  | 22 | % |  | 489 |  |  | 23 | % |
|  | $ | 2,349 |  |  |  |  | $ | 2,125 |  |  |  |

[0000866374-23-000028:notes:348]
As of March 31, 2023 and 2022, property and equipment, net held in Singapore was approximately $5 million and $5 million, respectively.

[0000866374-23-000028:notes:349]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal year 2023 and 2022:

[0000866374-23-000028:notes:350]
|  | Fiscal Year Ended March 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 763 |  |  | 32 | % |  | $ | 626 |  |  | 29 | % |
| U.S. | 365 |  |  | 16 | % |  | 354 |  |  | 17 | % |
| China | 338 |  |  | 14 | % |  | 299 |  |  | 14 | % |

[0000866374-23-000028:notes:351]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-23-000028:notes:352]
During the fiscal year 2022, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims. 
Legal and other during fiscal year 2021 primarily consists of costs accrued for certain loss contingencies where losses are considered probable and estimable, offset by a gain on the sale of real estate in the fourth quarter of fiscal year 2021 exited as a result of the disengagement of a certain customer in fiscal year 2020.  During fiscal years 2023, 2022 and 2021, depreciation expense included in the segments' measure of operating performance above is as follows.
