# FLEX 8-K — 0001104659-19-004485 filed 2019-01-30

## item codes, every 8-K on or before 2019-02-06

- 2019-02-06 0001104659-19-005884 — 5.02
- 2019-01-30 0001104659-19-004485 — 2.02, 9.01
- 2019-01-18 0001104659-19-002495 — 5.02
- 2018-12-28 0001104659-18-075143 — 5.02
- 2018-12-11 0001104659-18-072382 — 5.02
- 2018-11-15 0001104659-18-068678 — 5.02, 9.01
- 2018-10-25 0001104659-18-063948 — 2.02, 9.01
- 2018-10-25 0001104659-18-063944 — 5.02, 9.01
- 2018-08-21 0001104659-18-053031 — 5.07, 8.01, 9.01
- 2018-07-26 0001104659-18-047422 — 2.02, 9.01
- 2018-07-02 0001104659-18-043330 — 8.01
- 2018-06-29 0001104659-18-043222 — 5.02 — amendment of 0001104659-18-001263
- 2018-06-29 0001104659-18-043220 — 5.02
- 2018-06-20 0001104659-18-041299 — 5.02
- 2018-04-26 0001104659-18-027175 — 2.02, 9.01
- 2018-03-27 0001104659-18-020211 — 7.01, 9.01
- 2018-01-25 0001104659-18-004007 — 2.02, 2.05, 9.01
- 2018-01-08 0001104659-18-001263 — 5.02, 9.01
- 2017-10-26 0001104659-17-064047 — 2.02, 9.01
- 2017-08-18 0001104659-17-052657 — 5.02, 5.07, 8.01, 9.01
- 2017-07-27 0001104659-17-047407 — 2.02, 9.01
- 2017-06-30 0001104659-17-042966 — 5.02
- 2017-06-30 0001104659-17-042960 — 1.01, 1.02, 2.03, 5.02, 8.01, 9.01
- 2017-04-27 0001104659-17-026949 — 2.02, 9.01
- 2017-01-26 0001104659-17-004318 — 2.02, 9.01
- 2016-12-01 0001104659-16-160122 — 1.01, 1.02, 2.03, 9.01
- 2016-10-27 0001104659-16-152593 — 2.02, 9.01
- 2016-08-29 0001104659-16-141914 — 5.07, 8.01, 9.01
- 2016-07-21 0001104659-16-133707 — 2.02, 9.01
- 2016-06-20 0001104659-16-128351 — 5.02
- 2016-06-20 0001104659-16-128332 — 5.02
- 2016-04-28 0001104659-16-115318 — 2.02, 9.01
- 2016-01-28 0001104659-16-092129 — 2.02, 9.01
- 2015-10-21 0001104659-15-071927 — 5.02
- 2015-10-19 0001104659-15-071373 — 2.02, 9.01
- 2015-08-24 0001104659-15-061501 — 5.07, 8.01, 9.01
- 2015-07-23 0001104659-15-052878 — 2.02, 9.01
- 2015-06-16 0001104659-15-045690 — 5.02
- 2015-06-08 0001104659-15-044024 — 1.01, 2.03, 9.01
- 2015-06-03 0001104659-15-043222 — 8.01, 9.01
- 2015-04-29 0001104659-15-031659 — 2.02, 7.01, 9.01
- 2015-01-28 0001104659-15-005046 — 2.02, 9.01
- 2014-10-29 0001104659-14-074842 — 2.02, 9.01
- 2014-09-02 0001104659-14-064280 — 5.07, 8.01, 9.01
- 2014-07-24 0001104659-14-053288 — 2.02, 9.01
- 2014-07-02 0001104659-14-049953 — 5.02
- 2014-04-30 0001104659-14-032734 — 2.02, 9.01
- 2014-04-01 0001104659-14-024875 — 1.01, 1.02, 2.03, 9.01
- 2014-03-27 0001104659-14-023335 — 5.02
- 2014-03-24 0001104659-14-022271 — 5.02, 9.01
- 2014-01-29 0001104659-14-004859 — 2.02, 9.01
- 2014-01-10 0001104659-14-001731 — 5.02, 9.01
- 2013-10-29 0001104659-13-078782 — 2.02, 5.02, 9.01
- 2013-09-04 0001104659-13-067976 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058962 — 5.07
- 2013-07-25 0001104659-13-056675 — 2.02, 5.02, 8.01, 9.01
- 2013-06-12 0001104659-13-048654 — 5.02
- 2013-05-03 0001104659-13-036849 — 5.02, 9.01
- 2013-04-30 0001104659-13-035300 — 2.02, 9.01
- 2013-03-25 0001104659-13-024148 — 8.01
- 2013-02-22 0001104659-13-013284 — 1.01, 2.03, 9.01
- 2013-02-13 0001104659-13-009857 — 8.01, 9.01
- 2013-01-24 0001104659-13-004399 — 2.02, 2.05, 9.01
- 2012-11-05 0001104659-12-074181 — 5.02, 9.01
- 2012-10-18 0001104659-12-069883 — 2.02, 9.01
- 2012-09-17 0001104659-12-063654 — 8.01, 9.01
- 2012-09-05 0001104659-12-061702 — 5.07
- 2012-07-25 0001104659-12-050990 — 2.02, 9.01
- 2012-05-29 0001104659-12-040174 — 2.02, 9.01
- 2012-05-23 0001104659-12-039519 — 5.02
- 2012-05-01 0001104659-12-031399 — 2.02, 9.01
- 2012-03-14 0001104659-12-018277 — 5.02, 9.01
- 2012-01-19 0001104659-12-002882 — 2.02, 9.01
- 2011-12-22 0001104659-11-070952 — 8.01, 9.01
- 2011-12-20 0001104659-11-070389 — 5.02
- 2011-10-24 0001104659-11-057420 — 1.01, 2.03, 9.01
- 2011-10-20 0001104659-11-056974 — 2.02, 9.01
- 2011-08-29 0001104659-11-049247 — 5.07 — amendment of 0001104659-11-041159
- 2011-07-27 0001104659-11-041159 — 5.07
- 2011-07-21 0001104659-11-040160 — 2.02, 8.01, 9.01
- 2011-05-20 0001104659-11-030591 — 5.02
- 2011-04-27 0001104659-11-022969 — 2.02, 8.01, 9.01
- 2011-01-20 0000950123-11-004142 — 2.02, 9.01
- 2010-11-15 0000950123-10-105754 — 8.01, 9.01
- 2010-10-27 0000950123-10-096687 — 2.02, 9.01
- 2010-09-03 0000950123-10-083855 — 5.02, 9.01
- 2010-08-16 0000950123-10-077936 — 8.01, 9.01
- 2010-08-16 0000950123-10-077934 — 8.01, 9.01
- 2010-07-28 0000950123-10-068885 — 5.02, 5.07, 9.01
- 2010-07-22 0000950123-10-067306 — 2.02, 9.01
- 2010-06-02 0000950123-10-055226 — 5.02
- 2010-05-28 0000950123-10-053923 — 8.01, 9.01
- 2010-04-27 0000950123-10-038853 — 2.02, 9.01
- 2010-02-16 0000950123-10-013339 — 8.01, 9.01
- 2010-01-27 0000950123-10-005722 — 2.02, 9.01
- 2009-10-26 0000950123-09-053161 — 2.02, 9.01
- 2009-07-29 0000950123-09-027048 — 2.02, 9.01
- 2009-07-14 0000950123-09-021926 — 5.02, 8.01, 9.01
- 2009-07-01 0000950123-09-019481 — 8.01, 9.01
- 2009-06-22 0000950123-09-015575 — 1.01, 8.01, 9.01
- 2009-06-19 0000950123-09-015281 — 5.02, 9.01
- 2009-06-17 0000950123-09-014539 — 8.01, 9.01
- 2009-06-12 0000950123-09-013512 — 8.01, 9.01
- 2009-05-29 0001362310-09-008332 — 8.01, 9.01
- 2009-05-20 0001362310-09-007972 — 5.02
- 2009-05-20 0001362310-09-007969 — 2.05, 2.06 — amendment of 0001362310-09-003506
- 2009-04-29 0001362310-09-006059 — 2.02, 9.01
- 2009-04-15 0001362310-09-005364 — 5.02, 9.01
- 2009-03-10 0001362310-09-003506 — 2.05, 2.06, 9.01
- 2009-02-10 0000950134-09-002330 — 8.01, 9.01
- 2009-01-28 0000950134-09-001270 — 2.02, 9.01
- 2008-12-05 0000950134-08-021728 — 5.02
- 2008-10-23 0000950134-08-018373 — 2.02, 9.01
- 2008-10-17 0000950134-08-018101 — 5.02, 9.01
- 2008-10-02 0000950134-08-017490 — 5.02, 9.01
- 2008-07-24 0000950134-08-013256 — 2.02, 8.01, 9.01
- 2008-06-25 0001035704-08-000295 — 5.02
- 2008-06-05 0000950134-08-010827 — 5.02 — amendment of 0000950134-08-010826
- 2008-06-05 0000950134-08-010826 — 5.02
- 2008-05-16 0001035704-08-000230 — 5.02, 9.01
- 2008-05-06 0000950134-08-008565 — 5.02
- 2008-04-29 0000950134-08-007771 — 2.02, 9.01
- 2008-01-29 0001035704-08-000044 — 2.02, 9.01
- 2008-01-14 0001035704-08-000016 — 5.02, 9.01
- 2007-10-23 0000950134-07-021746 — 2.02, 9.01
- 2007-10-05 0001035704-07-000693 — 1.01, 2.01, 2.03, 2.04, 9.01
- 2007-10-03 0001035704-07-000688 — 8.01, 9.01
- 2007-10-03 0001035704-07-000687 — 5.02, 9.01
- 2007-10-01 0001035704-07-000683 — 8.01, 9.01
- 2007-09-28 0001035704-07-000682 — 8.01, 9.01
- 2007-07-26 0001035704-07-000538 — 2.02, 9.01
- 2007-06-04 0001035704-07-000455 — 1.01, 8.01, 9.01
- 2007-05-15 0001035704-07-000397 — 1.01, 1.02, 9.01
- 2007-05-04 0001035704-07-000351 — 5.02
- 2007-04-26 0001035704-07-000309 — 2.02, 9.01
- 2007-04-05 0000950134-07-007608 — 5.02
- 2007-01-30 0001035704-07-000111 — 2.02, 9.01
- 2006-11-07 0000950134-06-020749 — 1.01
- 2006-10-24 0000950134-06-019565 — 2.02, 9.01
- 2006-10-11 0000950123-06-012472 — 1.01, 3.03, 9.01
- 2006-09-18 0001035704-06-000670 — 2.05, 2.06
- 2006-09-08 0000950134-06-017501 — 2.01, 9.01
- 2006-09-06 0000950123-06-011282 — 8.01, 9.01
- 2006-09-05 0000950123-06-011215 — 8.01, 9.01
- 2006-08-24 0001193125-06-179001 — 1.01, 9.01
- 2006-07-25 0001193125-06-152609 — 2.02, 9.01
- 2006-07-18 0001193125-06-147851 — 1.01, 3.03, 9.01
- 2006-07-07 0001193125-06-143220 — 1.01, 9.01
- 2006-04-27 0001193125-06-091011 — 2.02, 9.01
- 2006-04-21 0001193125-06-085534 — 1.01, 9.01
- 2006-04-19 0001193125-06-083297 — 1.01, 9.01
- 2006-02-13 0001193125-06-028549 — 5.02, 9.01
- 2006-02-03 0001193125-06-019242 — 3.03, 5.03, 9.01
- 2006-01-31 0001193125-06-016147 — 2.02, 9.01
- 2005-12-23 0001193125-05-248604 — 1.01, 9.01
- 2005-12-01 0001193125-05-235113 — 1.01, 5.02, 9.01 — amendment, the index does not say of what
- 2005-11-04 0001181431-05-059714 — 5.02 — amendment, the index does not say of what
- 2005-10-28 0001181431-05-058301 — 3.01
- 2005-10-25 0001193125-05-207833 — 2.02, 9.01
- 2005-10-24 0001193125-05-206867 — 5.02 — amendment of 0001193125-05-205021
- 2005-10-20 0001193125-05-205021 — 5.02, 9.01
- 2005-07-26 0001193125-05-148995 — 2.02, 9.01
- 2005-07-13 0001193125-05-141381 — 1.01, 9.01
- 2005-06-21 0001193125-05-128063 — 1.01, 9.01 — amendment of 0001193125-05-119385
- 2005-06-03 0001193125-05-119385 — 1.01, 9.01
- 2005-05-18 0001193125-05-110571 — 1.01, 5.02, 9.01
- 2005-04-28 0001193125-05-088564 — 2.02, 9.01
- 2005-04-01 0001193125-05-067374 — 1.01, 9.01
- 2005-01-25 0001193125-05-011427 — 2.02, 9.01
- 2005-01-21 0001193125-05-009819 — 1.01
- 2004-12-23 0000950134-04-019845 — 1.01
- 2004-12-17 0000950134-04-019520 — 5.02
- 2004-11-19 0001193125-04-200645 — 1.01, 2.03, 9.01
- 2004-11-12 0001193125-04-193938 — 8.01, 9.01
- 2004-10-28 0001181431-04-049331 — 3.02
- 2004-10-28 0001181431-04-049218 — 7.01, 9.01
- 2004-10-25 0001181431-04-048620 — 2.02, 9.01
- 2004-08-27 0000950134-04-012924 — 1.01
- 2004-07-26 0000891618-04-001144 — 5, 7
- 2004-07-22 0000891618-04-001133 — 9
- 2004-07-19 0000891618-04-001113 — 12, 7
- 2004-04-27 0000891618-04-000923 — 12, 7
- 2004-01-27 0000891618-04-000320 — 12, 7
- 2003-12-01 0000891618-03-006138 — 5, 7
- 2003-10-22 0000891618-03-005400 — 12, 7
- 2003-10-01 0000891618-03-005024 — 5
- 2003-08-04 0000891618-03-004105 — 5, 7
- 2003-07-24 0000891618-03-003866 — 7, 9
- 2003-04-24 0000891618-03-002050 — 7, 9
- 2002-08-29 0000891618-02-004143 — 4, 5, 7 — amendment of 0000891618-02-002217
- 2002-05-08 0000891618-02-002217 — 4, 7
- 2002-01-11 0000891618-02-000089 — 5, 7
- 2001-02-08 0001095811-01-000846 — 7 — amendment of 0001095811-01-000584
- 2001-02-01 0001095811-01-000584 — 5, 7
- 2001-01-29 0001095811-01-000458 — 5, 7
- 2000-11-14 0000891618-00-005110 — 7 — amendment, the index does not say of what
- 2000-09-20 0001095811-00-003467 — 5, 7
- 2000-09-20 0000891618-00-004656 — 5, 7
- 2000-09-15 0001095811-00-003404 — 2, 7
- 2000-06-27 0000891618-00-003591 — 5, 7
- 2000-06-22 0000891618-00-003511 — 5, 7
- 2000-06-19 0000891618-00-003426 — 7 — amendment of 0000891554-00-001074
- 2000-06-13 0000891618-00-003325 — 5, 7
- 2000-04-18 0000891554-00-001074 — 2, 7
- 2000-02-29 0000891618-00-001171 — 5, 7
- 1999-12-23 0000891554-99-002376 — 5, 7
- 1999-12-06 0000891554-99-002273 — 5, 7
- 1999-10-29 0000891618-99-004773 — 5, 7
- 1999-03-22 0000891554-99-000558 — 2, 7
- 1998-12-10 0000891618-98-005275 — 5, 7
- 1998-01-13 0000891618-98-000108 — 7 — amendment of 0000891618-97-004386
- 1997-11-06 0000891618-97-004386 — 2, 7
- 1997-10-23 0000891618-97-004224 — 5, 7
- 1997-10-22 0000891618-97-004206 — 5, 7
- 1997-10-20 0000891618-97-004177 — 4, 7 — amendment of 0000891618-97-003315
- 1997-09-29 0000891618-97-003924 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-27 0000891618-97-003607 — 7 — amendment, the index does not say of what
- 1997-08-18 0000891618-97-003517 — 4, 7 — amendment of 0000891618-97-003315
- 1997-08-11 0000891618-97-003315 — 4
- 1997-04-11 0000891618-97-001704 — 2, 5, 7
- 1997-03-12 0000891618-97-001139 — 5
- 1996-12-13 0000891618-96-003051 — 5, 7

## late-filing notifications on or before 2019-02-06

- 2018-05-30 0001104659-18-036719 — NT 10-K, for the period ended 2018-03-31
- 1997-08-14 0000891618-97-003483 — NT 10-Q, for the period ended 1997-06-30
- 1997-06-27 0000891618-97-002762 — NT 10-K, for the period ended 1997-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-19-004485:8k_2_02:1]
EX-99.1
2
a19-3576_1ex99d1.htm
EX-99.1

[0001104659-19-004485:8k_2_02:2]
Exhibit 99.1

[0001104659-19-004485:8k_2_02:3]
FLEX REPORTS THIRD QUARTER FISCAL 2019 RESULTS

[0001104659-19-004485:8k_2_02:4]
San Jose, CA, January 30, 2019 — Flex (NASDAQ: FLEX) today announced results for its third quarter ended December 31, 2018.

[0001104659-19-004485:8k_2_02:5]
“During the quarter, we grew revenues, improved the quality of our sales mix, expanded margins, returned to free cash flow generation, and streamlined our investment portfolio,” said Michael Capellas, Chairman of Flex. “These results reflect our intense focus on execution in our core businesses.”

[0001104659-19-004485:8k_2_02:6]
Third Quarter Fiscal 2019 Highlights:

[0001104659-19-004485:8k_2_02:7]
·                  Net Sales: $6.9 billion, year over year growth of 3 percent

[0001104659-19-004485:8k_2_02:8]
·                  Communications and Enterprise Compute: year over year revenue growth of 14 percent

[0001104659-19-004485:8k_2_02:9]
·                  Industrial and Emerging Industries: year over year revenue growth of 11 percent

[0001104659-19-004485:8k_2_02:10]
·                  High Reliability Solutions: year over year revenue down 1 percent with strong growth in Health Solutions offset by weakness in Automotive

[0001104659-19-004485:8k_2_02:11]
·                  Consumer Technologies Group: year over year revenue down 12 percent

[0001104659-19-004485:8k_2_02:12]
·                  GAAP Loss Before Income Taxes: $32 million

[0001104659-19-004485:8k_2_02:13]
·                  Adjusted Operating Income: $256 million, year over year growth of 17 percent

[0001104659-19-004485:8k_2_02:14]
·                  GAAP Net Loss: $45 million

[0001104659-19-004485:8k_2_02:15]
·                  Adjusted Net Income: $181 million, year over year growth of 10 percent

[0001104659-19-004485:8k_2_02:16]
·                  GAAP Net Loss Per Share: $0.09

[0001104659-19-004485:8k_2_02:17]
·                  Adjusted EPS: $0.34

[0001104659-19-004485:8k_2_02:18]
An explanation and reconciliation of non-GAAP financial measures to GAAP financial measures is presented in Schedules II and V attached to this press release.

[0001104659-19-004485:8k_2_02:19]
Balance Sheet and Other Financial Highlights

[0001104659-19-004485:8k_2_02:20]
Flex ended the quarter with approximately $1.5 billion of cash on hand and total debt of approximately $2.9 billion.

[0001104659-19-004485:8k_2_02:21]
Adjusted cash flow from operations and free cash flow was $274 million and $119 million, respectively, for the three-month period ended December 31, 2018, and $379 million and negative $126 million, respectively, for the nine-month period ended December 31, 2018.  Cash flow from operations was negative $621 million and negative $2.3 billion for the three-month and nine-month periods ended December 31, 2018, respectively, as cash collections for certain receivables sold under our ABS programs are reported as investing activities.

[0001104659-19-004485:8k_2_02:22]
The Company remains committed to return over 50% of annual free cash flow to its shareholders as it repurchased ordinary shares for approximately $64 million and $124 million during the three-month and nine-month periods ended December 31, 2018.

[0001104659-19-004485:8k_2_02:23]
“We are pleased with the results of our third quarter, which exceeded expectations on multiple levels. Our core business remains sound and is performing very well, and our balance sheet is positioned to support the business over the long term,” said Chris Collier, Chief Financial Officer.

[0001104659-19-004485:8k_2_02:24]
Fourth Quarter Fiscal 2019 Guidance

[0001104659-19-004485:8k_2_02:25]
·                  Revenue $6.2 billion to $6.6 billion

[0001104659-19-004485:8k_2_02:26]
·                  GAAP Income Before Income Taxes $110 million to $140 million

[0001104659-19-004485:8k_2_02:27]
·                  Adjusted Operating Income $195 million to $225 million

[0001104659-19-004485:8k_2_02:28]
·                  GAAP EPS $0.18 to $0.21 which includes stock-based compensation expense and intangible amortization

[0001104659-19-004485:8k_2_02:29]
·                  Adjusted EPS $0.25 to $0.28

[0001104659-19-004485:8k_2_02:30]
Webcast and Conference Call

[0001104659-19-004485:8k_2_02:31]
The Flex management team will host a conference call today at 2:00 PM (PT) / 5:00 PM (ET), to review third quarter fiscal 2019 results. A live webcast of the event and slides will be available on the Flex Investor Relations website at http://investors.flex.com. An audio replay and transcript will also be available after the event on the Flex Investor Relations website.

[0001104659-19-004485:8k_2_02:32]
About Flex

[0001104659-19-004485:8k_2_02:33]
Flex Ltd. (Reg. No. 199002645H) is the Sketch-to-Scale® solutions provider that designs and builds Intelligent Products for a Connected World®. With approximately 200,000 professionals across 30 countries, Flex provides innovative design, engineering, manufacturing, real-time supply chain insight and logistics services to companies of all sizes in various industries and end-markets. For more information, visit flex.com or follow us on Twitter @Flexintl. Flex — Live Smarter™

[0001104659-19-004485:8k_2_02:34]
Contacts

[0001104659-19-004485:8k_2_02:35]
Kevin Kessel, CFA

[0001104659-19-004485:8k_2_02:36]
Vice President, Investor Relations

[0001104659-19-004485:8k_2_02:37]
(408) 576-7985

[0001104659-19-004485:8k_2_02:38]
kevin.kessel@flex.com

[0001104659-19-004485:8k_2_02:39]
Forward-Looking Statements

[0001104659-19-004485:8k_2_02:40]
Additional information concerning these and other risks is described under “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our reports on Forms 10-K and 10-Q that we file with the U.S. Securities and Exchange Commission. The forward-looking statements in this press release are based on current expectations and Flex assumes no obligation to update these forward-looking statements. Our share repurchase program does not obligate the Company to repurchase a specific number of shares and may be suspended or terminated at any time without prior notice.

[0001104659-19-004485:8k_2_02:41]
SCHEDULE I

[0001104659-19-004485:8k_2_02:42]
FLEX

[0001104659-19-004485:8k_2_02:43]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-19-004485:8k_2_02:44]
(In thousands, except per share amounts)

[0001104659-19-004485:8k_2_02:45]
|  |  | Three-Month Periods Ended |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 6,944,827 |  | $ | 6,751,552 |  |
| Cost of sales |  | 6,527,067 |  | 6,305,224 |  |
| Restructuring charges |  | 60,435 |  | — |  |
| Gross profit |  | 357,325 |  | 446,328 |  |
| Selling, general and administrative expenses |  | 237,556 |  | 247,365 |  |
| Intangible amortization |  | 20,308 |  | 19,588 |  |
| Restructuring charges |  | 5,408 |  | — |  |
| Interest and other, net |  | 54,087 |  | 31,350 |  |
| Other charges, net |  | 71,879 |  | 6,865 |  |
| Income (loss) before income taxes |  | (31,913 | ) | 141,160 |  |
| Provision for income taxes |  | 13,256 |  | 22,827 |  |
| Net income (loss) |  | $ | (45,169 | ) | $ | 118,333 |  |
| Earnings (losses) per share: |  |  |  |  |  |
| GAAP |  | $ | (0.09 | ) | $ | 0.22 |  |
| Non-GAAP |  | $ | 0.34 |  | $ | 0.31 |  |
| Basic shares used in computing per share amounts (2) |  | 524,876 |  | 528,405 |  |
| Diluted shares used in computing per share amounts (2) |  | 524,876 |  | 534,352 |  |

[0001104659-19-004485:8k_2_02:46]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures.

[0001104659-19-004485:8k_2_02:47]
FLEX

[0001104659-19-004485:8k_2_02:48]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-19-004485:8k_2_02:49]
(In thousands, except per share amounts)

[0001104659-19-004485:8k_2_02:50]
|  |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  |
| GAAP: |  |  |  |  |  |
| Net sales |  | $ | 20,079,387 |  | $ | 19,030,244 |  |
| Cost of sales |  | 18,852,395 |  | 17,775,678 |  |
| Restructuring charges |  | 89,512 |  | 7,981 |  |
| Gross profit |  | 1,137,480 |  | 1,246,585 |  |
| Selling, general and administrative expenses |  | 722,608 |  | 772,325 |  |
| Intangible amortization |  | 57,059 |  | 55,865 |  |
| Restructuring charges |  | 10,921 |  | — |  |
| Interest and other, net |  | 136,889 |  | 85,780 |  |
| Other income, net |  | (8,515 | ) | (172,467 | ) |
| Income before income taxes |  | 218,518 |  | 505,082 |  |
| Provision for income taxes |  | 60,767 |  | 56,953 |  |
| Net income |  | $ | 157,751 |  | $ | 448,129 |  |
| Earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.30 |  | $ | 0.84 |  |
| Non-GAAP |  | $ | 0.87 |  | $ | 0.81 |  |
| Diluted shares used in computing per share amounts |  | 532,308 |  | 535,972 |  |

[0001104659-19-004485:8k_2_02:51]
See Schedule II for the reconciliation of GAAP to non-GAAP financial measures.

[0001104659-19-004485:8k_2_02:52]
SCHEDULE II

[0001104659-19-004485:8k_2_02:53]
FLEX

[0001104659-19-004485:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-19-004485:8k_2_02:55]
(In thousands, except per share amounts)

[0001104659-19-004485:8k_2_02:56]
|  |  | Three-Month Periods Ended |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  |
| GAAP gross profit |  | $ | 357,325 |  | $ | 446,328 |  |
| Stock-based compensation expense |  | 4,769 |  | 5,358 |  |
| Customer related asset impairments (3) |  | 29,491 |  | — |  |
| Restructuring charges (4) |  | 60,435 |  | — |  |
| Contingencies and other (5) |  | 1,174 |  | — |  |
| Non-GAAP gross profit |  | $ | 453,194 |  | $ | 451,686 |  |
| GAAP income (loss) before income taxes |  | $ | (31,913 | ) | $ | 141,160 |  |
| Intangible amortization |  | 20,308 |  | 19,588 |  |
| Stock-based compensation expense |  | 21,027 |  | 20,758 |  |
| Customer related asset impairments (3) |  | 50,153 |  | — |  |
| Restructuring charges (4) |  | 65,843 |  | — |  |
| Contingencies and other (5) |  | 4,994 |  | — |  |
| Other charges, net (6) |  | 71,879 |  | 6,865 |  |
| Interest and other, net |  | 54,087 |  | 31,350 |  |
| Non-GAAP operating income |  | $ | 256,378 |  | $ | 219,721 |  |
| GAAP provision for income taxes |  | $ | 13,256 |  | $ | 22,827 |  |
| Intangible amortization benefit |  | 2,185 |  | 2,185 |  |
| Tax impact on tax receivable, net (7) |  | 2,218 |  | — |  |
| Other adjustments for taxes (7) |  | 5,058 |  | — |  |
| Non-GAAP provision for income taxes |  | $ | 22,717 |  | $ | 25,012 |  |
| GAAP net income (loss) |  | $ | (45,169 | ) | $ | 118,333 |  |
| Intangible amortization |  | 20,308 |  | 19,588 |  |
| Stock-based compensation expense |  | 21,027 |  | 20,758 |  |
| Restructuring charges (4) |  | 65,843 |  | — |  |
| Customer related asset impairments (3) |  | 50,153 |  | — |  |
| Contingencies and other (5) |  | 4,994 |  | — |  |
| Other charges, interest and other, net (6) |  | 72,903 |  | 7,892 |  |
| Adjustments for taxes (7) |  | (9,461 | ) | (2,185 | ) |
| Non-GAAP net income |  | $ | 180,598 |  | $ | 164,386 |  |
| Diluted earnings (losses) per share (2): |  |  |  |  |  |
| GAAP |  | $ | (0.09 | ) | $ | 0.22 |  |
| Non-GAAP |  | $ | 0.34 |  | $ | 0.31 |  |

[0001104659-19-004485:8k_2_02:57]
See the accompanying notes on Schedule V attached to this press release.

[0001104659-19-004485:8k_2_02:58]
FLEX

[0001104659-19-004485:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES (1)

[0001104659-19-004485:8k_2_02:60]
(In thousands, except per share amounts)

[0001104659-19-004485:8k_2_02:61]
|  |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  |
| GAAP gross profit |  | $ | 1,137,480 |  | $ | 1,246,585 |  |
| Stock-based compensation expense |  | 14,940 |  | 13,662 |  |
| Customer related asset impairments (3) |  | 41,843 |  | — |  |
| Restructuring charges (4) |  | 89,512 |  | 7,981 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 6,409 |  | 10,952 |  |
| Non-GAAP gross profit |  | $ | 1,299,475 |  | $ | 1,279,180 |  |
| GAAP income before income taxes |  | $ | 218,518 |  | $ | 505,082 |  |
| Intangible amortization |  | 57,059 |  | 55,865 |  |
| Stock-based compensation expense |  | 61,061 |  | 63,018 |  |
| Customer related asset impairments (3) |  | 67,517 |  | 4,753 |  |
| Restructuring charges (4) |  | 100,433 |  | 7,981 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 25,363 |  | 35,952 |  |
| Other income, net (6) |  | (8,515 | ) | (172,467 | ) |
| Interest and other, net |  | 136,889 |  | 85,780 |  |
| Non-GAAP operating income |  | $ | 667,616 |  | $ | 585,964 |  |
| GAAP provision for income taxes |  | $ | 60,767 |  | $ | 56,953 |  |
| Intangible amortization benefit |  | 6,702 |  | 6,201 |  |
| Tax impact on tax receivable, net (7) |  | (4,799 | ) | — |  |
| Other adjustments for taxes (7) |  | 4,366 |  | 2,738 |  |
| Non-GAAP provision for income taxes |  | $ | 67,036 |  | $ | 65,892 |  |
| GAAP net income |  | $ | 157,751 |  | $ | 448,129 |  |
| Intangible amortization |  | 57,059 |  | 55,865 |  |
| Stock-based compensation expense |  | 61,061 |  | 63,018 |  |
| Restructuring charges (4) |  | 100,433 |  | 7,981 |  |
| Customer related asset impairments (3) |  | 67,517 |  | 4,753 |  |
| New revenue standard adoption impact (8) |  | 9,291 |  | — |  |
| Contingencies and other (5) |  | 25,363 |  | 35,952 |  |
| Other charges, interest and other, net (6) |  | (10,313 | ) | (171,440 | ) |
| Adjustments for taxes (7) |  | (6,269 | ) | (8,939 | ) |
| Non-GAAP net income |  | $ | 461,893 |  | $ | 435,319 |  |
| Diluted earnings per share: |  |  |  |  |  |
| GAAP |  | $ | 0.30 |  | $ | 0.84 |  |
| Non-GAAP |  | $ | 0.87 |  | $ | 0.81 |  |

[0001104659-19-004485:8k_2_02:62]
See the accompanying notes on Schedule V attached to this press release.

[0001104659-19-004485:8k_2_02:63]
SCHEDULE III

[0001104659-19-004485:8k_2_02:64]
FLEX

[0001104659-19-004485:8k_2_02:65]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-19-004485:8k_2_02:66]
(In thousands)

[0001104659-19-004485:8k_2_02:67]
|  |  | As of December 31, 2018 |  | As of March 31, 2018 |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,503,368 |  | $ | 1,472,424 |  |
| Accounts receivable, net of allowance for doubtful accounts |  | 2,861,830 |  | 2,517,695 |  |
| Contract assets |  | 298,451 |  | — |  |
| Inventories |  | 3,897,891 |  | 3,799,829 |  |
| Other current assets |  | 930,376 |  | 1,380,466 |  |
| Total current assets |  | 9,491,916 |  | 9,170,414 |  |
| Property and equipment, net |  | 2,214,148 |  | 2,239,506 |  |
| Goodwill |  | 1,078,834 |  | 1,121,170 |  |
| Other intangible assets, net |  | 349,645 |  | 424,433 |  |
| Other assets |  | 840,542 |  | 760,332 |  |
| Total assets |  | $ | 13,975,085 |  | $ | 13,715,855 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt |  | $ | 43,249 |  | $ | 43,011 |  |
| Accounts payable |  | 5,543,349 |  | 5,122,303 |  |
| Accrued payroll |  | 389,746 |  | 383,332 |  |
| Other current liabilities |  | 1,527,276 |  | 1,719,418 |  |
| Total current liabilities |  | 7,503,620 |  | 7,268,064 |  |
| Long-term debt, net of current portion |  | 2,906,251 |  | 2,897,631 |  |
| Other liabilities |  | 486,886 |  | 531,587 |  |
| Total shareholders’ equity |  | 3,078,328 |  | 3,018,573 |  |
| Total liabilities and shareholders’ equity |  | $ | 13,975,085 |  | $ | 13,715,855 |  |

[0001104659-19-004485:8k_2_02:68]
SCHEDULE IV

[0001104659-19-004485:8k_2_02:69]
FLEX

[0001104659-19-004485:8k_2_02:70]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-19-004485:8k_2_02:71]
(In thousands)

[0001104659-19-004485:8k_2_02:72]
|  |  | Nine-Month Periods Ended |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income |  | $ | 157,751 |  | $ | 448,129 |  |
| Depreciation, amortization and other impairment charges |  | 507,164 |  | 400,015 |  |
| Gain from deconsolidation of Bright Machines |  | (86,614 | ) | — |  |
| Gain from deconsolidation of Elementum |  | — |  | (151,574 | ) |
| Changes in working capital and other |  | (2,906,906 | ) | (3,804,156 | ) |
| Net cash used in operating activities |  | (2,328,605 | ) | (3,107,586 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property and equipment |  | (592,092 | ) | (432,897 | ) |
| Proceeds from the disposition of property and equipment |  | 86,724 |  | 43,653 |  |
| Acquisition of businesses, net of cash acquired |  | (12,796 | ) | (269,724 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses |  | 267,147 |  | (2,949 | ) |
| Cash collections of deferred purchase price |  | 2,707,562 |  | 3,538,604 |  |
| Other investing activities, net |  | 14,687 |  | (120,934 | ) |
| Net cash provided by investing activities |  | 2,471,232 |  | 2,755,753 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt |  | 2,481,407 |  | 866,000 |  |
| Repayments of bank borrowings and long-term debt |  | (2,447,873 | ) | (907,930 | ) |
| Payments for repurchases of ordinary shares |  | (123,979 | ) | (180,050 | ) |
| Net proceeds from issuance of ordinary shares |  | 195 |  | 2,063 |  |
| Other financing activities, net |  | 9,689 |  | 46,482 |  |
| Net cash used in financing activities |  | (80,561 | ) | (173,435 | ) |
| Effect of exchange rates on cash and cash equivalents |  | (31,122 | ) | (14,224 | ) |
| Net change in cash and cash equivalents |  | 30,944 |  | (539,492 | ) |
| Cash and cash equivalents, beginning of period |  | 1,472,424 |  | 1,830,675 |  |
| Cash and cash equivalents, end of period |  | $ | 1,503,368 |  | $ | 1,291,183 |  |

[0001104659-19-004485:8k_2_02:73]
SCHEDULE V

[0001104659-19-004485:8k_2_02:74]
FLEX AND SUBSIDIARIES

[0001104659-19-004485:8k_2_02:75]
NOTES TO SCHEDULE II

[0001104659-19-004485:8k_2_02:76]
(1)   To supplement Flex’s unaudited selected financial data presented consistent with Generally Accepted Accounting Principles (“GAAP”), the Company discloses certain non-GAAP financial measures that exclude certain charges, including non-GAAP gross profit, non-GAAP operating income, non-GAAP net income and non-GAAP net income per diluted share.  These supplemental measures exclude restructuring charges, stock-based compensation expense, intangible amortization, other discrete events as applicable and the related tax effects. These non-GAAP measures are not in accordance with or an alternative for GAAP, and may be different from non-GAAP measures used by other companies.  We believe that these non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Flex’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Flex’s results of operations in conjunction with the corresponding GAAP measures.  The presentation of this additional information is not meant to be considered in isolation or as a substitute for the most directly comparable GAAP measures.  We compensate for the limitations of non-GAAP financial measures by relying upon GAAP results to gain a complete picture of the Company’s performance.

[0001104659-19-004485:8k_2_02:77]
In calculating non-GAAP financial measures, we exclude certain items to facilitate a review of the comparability of the Company’s operating performance on a period-to-period basis because such items are not, in our view, related to the Company’s ongoing operational performance. We use non-GAAP measures to evaluate the operating performance of our business, for comparison with forecasts and strategic plans, for calculating return on investment, and for benchmarking performance externally against competitors. In addition, management’s incentive compensation is determined using certain non-GAAP measures.  Also, when evaluating potential acquisitions, we exclude certain of the items described below from consideration of the target’s performance and valuation.  Since we find these measures to be useful, we believe that investors benefit from seeing results “through the eyes” of management in addition to seeing GAAP results.  We believe that these non-GAAP measures, when read in conjunction with the Company’s GAAP financials, provide useful information to investors by offering:

[0001104659-19-004485:8k_2_02:78]
·                  the ability to make more meaningful period-to-period comparisons of the Company’s on-going operating results;

[0001104659-19-004485:8k_2_02:79]
·                  the ability to better identify trends in the Company’s underlying business and perform related trend analyses;

[0001104659-19-004485:8k_2_02:80]
·                  a better understanding of how management plans and measures the Company’s underlying business; and

[0001104659-19-004485:8k_2_02:81]
·                  an easier way to compare the Company’s operating results against analyst financial models and operating results of competitors that supplement their GAAP results with non-GAAP financial measures.

[0001104659-19-004485:8k_2_02:82]
The following are explanations of each of the adjustments that we incorporate into non-GAAP measures, as well as the reasons for excluding each of these individual items in the reconciliations of these non-GAAP financial measures:

[0001104659-19-004485:8k_2_02:83]
Stock-based compensation expense consists of non-cash charges for the estimated fair value of stock options and unvested restricted share unit awards granted to employees and assumed in business acquisitions.  The Company believes that the exclusion of these charges provides for more accurate comparisons of its operating results to peer companies due to the varying available valuation methodologies, subjective assumptions and the variety of award types.  In addition, the Company believes it is useful to investors to understand the specific impact stock-based compensation expense has on its operating results.

[0001104659-19-004485:8k_2_02:84]
Intangible amortization consists primarily of non-cash charges that can be impacted by, among other things, the timing and magnitude of acquisitions.  The Company considers its operating results without these charges when evaluating its ongoing performance and forecasting its earnings trends, and therefore excludes such charges when presenting non-GAAP financial measures.  The Company believes that the assessment of its operations excluding these costs is relevant to its assessment of internal operations and comparisons to the performance of its competitors.

[0001104659-19-004485:8k_2_02:85]
Customer related asset impairments consist primarily of non-cash impairments of certain property and equipment to estimated fair value for customers we are in the process of disengaging as well as additional

[0001104659-19-004485:8k_2_02:86]
provisions for doubtful accounts receivable for customers that are experiencing significant financial difficulties. Certain inventory on hand could be subject to impairment to net realizable value for these customers as well. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-004485:8k_2_02:87]
Contingencies and other consists primarily of costs not directly related to ongoing or core business results such as (1) costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors completed in June 2018, (2) certain charges related to Multek China that was divested in the second quarter of fiscal year 2019, (3) damages incurred from a typhoon that impacted a China facility in the second quarter of fiscal year 2018, and (4) certain legal matters for which loss contingencies are believed to be probable and estimable in the second quarter of fiscal year 2018. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-004485:8k_2_02:88]
Restructuring charges include severance for rationalization at existing sites and corporate SG&A functions as well as asset impairment, lease termination, and other charges relate to the closures and consolidations of certain operating sites. These costs may vary in size based on the Company’s initiatives and are not directly related to ongoing or core business results, and do not reflect expected future operating expenses. These costs are excluded by the Company’s management in assessing current operating performance and forecasting its earnings trends and are therefore excluded by the Company from its non-GAAP measures.

[0001104659-19-004485:8k_2_02:89]
Other charges (income), net consists of various other types of items that are not directly related to ongoing or core business results, such as the gain or loss from certain divestitures, gain from deconsolidation of certain entities, and impairment charges associated with non-core investments. We exclude these items because they are not related to the Company’s ongoing operating performance or do not affect core operations.  Excluding these amounts provides investors with a basis to compare Company performance against the performance of other companies without this variability.

[0001104659-19-004485:8k_2_02:90]
Adjustment for taxes relates to the tax effects of the various adjustments that we incorporate into non-GAAP measures in order to provide a more meaningful measure on non-GAAP net income and certain adjustments related to non-recurring settlements of tax contingencies or other non-recurring tax charges, when applicable.

[0001104659-19-004485:8k_2_02:91]
Adjustment for operating cash flows and free cash flow metrics due to a recently issued accounting standard.   In Q1 fiscal year 2019, the adoption of the new cash flow accounting standard resulted in a reclassification of cash flows related to the collection of certain receivables sold through the Company’s asset-backed receivable securitization program from operating activities to investing activities. The Company utilizes net cash flow from its various A/R sales programs as a low-cost source to fund operations and as a critical net working capital management tool.  Cash flow from operations is also a critical metric that investors use to evaluate a company’s earnings power. The Company views and manages all collections under the program similarly without bifurcation and accordingly provides the adjustment to reflect cash flows from operations inclusive of all collections of receivables sold through the programs.

[0001104659-19-004485:8k_2_02:92]
In addition, we define our free cash flow metric to be GAAP net cash flows from operating activities, plus cash collection of deferred purchase price, less purchases of property and equipment net of proceeds from dispositions to reflect this change and present cash flows on a consistent basis for investor transparency.  We believe Free Cash Flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions and for certain other activities. Since Free Cash Flow includes investments in operating assets, we believe this non-GAAP liquidity measure is useful in addition to the most directly comparable GAAP measure — “net cash used in operating activities.” See below for the three and nine-month periods ended December 31, 2018 reconciliation of GAAP to   Non-GAAP measures:

[0001104659-19-004485:8k_2_02:93]
|  |  | Three-Month Period Ended |  | Nine-Month Period Ended |  |
|  |  | December 31, 2018 |  | December 31, 2018 |  |
| Net cash used in operating activities |  | $ | (621,009 | ) | $ | (2,328,605 | ) |
| Cash collections of deferred purchase price |  | 894,617 |  | 2,707,562 |  |
| Adjusted net cash provided by operating activities |  | 273,608 |  | 378,957 |  |
| Net Capital Expenditures |  | (154,968 | ) | (505,368 | ) |
| Free Cash Flow |  | $ | 118,640 |  | $ | (126,411 | ) |

[0001104659-19-004485:8k_2_02:94]
(2) Basic shares were used in calculating diluted GAAP EPS for the quarter ended December 31, 2018 due to the net loss recognized during the period. Diluted shares for Q3 fiscal 2019 were 526,801 thousand which were used in calculating diluted non-GAAP EPS for the quarter.

[0001104659-19-004485:8k_2_02:95]
(3) Customer related asset impairments for the three-month and nine-month periods ended December 31, 2018 primarily relate to additional provisions for doubtful accounts receivable, inventory and impairment of property and equipment for certain customers experiencing significant financial difficulties and /or we are disengaging from.

[0001104659-19-004485:8k_2_02:96]
(4) We completed the wind-down of our Nike operations in Mexico in Q3 fiscal year 2019 and recognized in total $36 million and $66 million for the three-month and nine-month periods ended December 31, 2018. The charge primarily consisted of non-cash asset impairments.

[0001104659-19-004485:8k_2_02:97]
For the three-month period ended December 31, 2018, the Company also incurred certain restructuring charges primarily related to severance for rationalization at certain existing operating and design sites and corporate functions as well as asset impairment charges related to exit of certain immaterial businesses.

[0001104659-19-004485:8k_2_02:98]
(5) Contingencies and other during the three and nine-month periods ended December 31, 2018 primarily consist of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, for the nine month period ended December 31, 2018, it also includes certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019.

[0001104659-19-004485:8k_2_02:99]
During the second quarter of fiscal year 2018, the Company incurred charges in connection with certain legal matters where it believed losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility.

[0001104659-19-004485:8k_2_02:100]
(6) During the third quarter of fiscal year 2019, the Company recorded a $70 million impairment charge related to one of its non-core cost method investments due to limited funding the investee has received and its deteriorating operating performance.

[0001104659-19-004485:8k_2_02:101]
During the first quarter of fiscal year 2019, the Company transferred employees and equipment along with certain related software and IP, into Bright Machines which later received additional equity funding from third party investors and changed the composition of the Board of directors removing Flex’s control.  As such, we deconsolidated the entity and recognized a gain of approximately $92 million in other income, net for the quarter ended June 29, 2018. During the second quarter of fiscal year 2019, the Company reduced the gain recognized in the first quarter by $4 million based on the final fair value provided by an independent valuation firm.

[0001104659-19-004485:8k_2_02:102]
The Company sold its Wink business during the first quarter of fiscal year 2018 to an unrelated third-party venture backed company in exchange for contingent consideration fair valued at $59 million and recognized a gain on sale of $38.7 million.

[0001104659-19-004485:8k_2_02:103]
During the second quarter of fiscal year 2018, the Company and other minority shareholders of Elementum amended certain agreements and as a result, the Company concluded it no longer had majority control and

[0001104659-19-004485:8k_2_02:104]
accordingly, deconsolidated the entity. As part of the deconsolidation, the Company recognized a gain of $151.6 million.

[0001104659-19-004485:8k_2_02:105]
(7) Primarily related to adjustment for exchange rate fluctuation on income tax receivable position of an operating subsidiary recognized in a prior period and tax effects of the various adjustments that we incorporate into Non-GAAP measures.

[0001104659-19-004485:8k_2_02:106]
(8) During the first quarter of fiscal year 2019, the Company amended certain non-substantive terms of its existing contracts for its smaller customers. The amendments removed the consideration regarding over-time recognition under ASC 606. Accordingly, these customer contracts are now accounted for consistent with prior accounting and revenue is recognized upon shipment of product.
