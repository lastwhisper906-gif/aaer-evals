# FLEX MD&A — 0000866374-19-000003


## mdna

[0000866374-19-000003:mdna:1]
[same as prior period, unchanged from 0000866374-18-000013:mdna:1]

[0000866374-19-000003:mdna:2]
[same as prior period, unchanged from 0000866374-18-000013:mdna:2]

[0000866374-19-000003:mdna:3]
[same as prior period, unchanged from 0000866374-18-000013:mdna:18]

[0000866374-19-000003:mdna:4]
Condition and Results of Operations” in our Annual Report on Form 10-K for the year ended March 31, 2018. In addition, new risks emerge from time to time and it is not possible for management to predict all such risk factors or to assess the impact of such risk factors on our business. Accordingly, our future results may differ materially from historical results or from those discussed or implied by these forward-looking statements. Given these risks and uncertainties, the reader should not place undue reliance on these forward-looking statements.

[0000866374-19-000003:mdna:5]
[same as prior period, unchanged from 0000866374-18-000013:mdna:3]

[0000866374-19-000003:mdna:6]
[same as prior period, unchanged from 0000866374-18-000013:mdna:4]

[0000866374-19-000003:mdna:7]
[same as prior period, unchanged from 0000866374-18-000013:mdna:5]

[0000866374-19-000003:mdna:8]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in connected living, audio and consumer power electronics, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-19-000003:mdna:9]
[same as prior period, unchanged from 0000866374-18-000013:mdna:7]

[0000866374-19-000003:mdna:10]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including consumer health, digital health, medical disposables, drug delivery, and medical equipment; our automotive business, including vehicle electrification, connectivity, autonomous vehicles, and smart technologies. |

[0000866374-19-000003:mdna:11]
[same as prior period, unchanged from 0000866374-18-000013:mdna:11]

[0000866374-19-000003:mdna:12]
[same as prior period, unchanged from 0000866374-18-000013:mdna:12]

[0000866374-19-000003:mdna:13]
[same as prior period, unchanged from 0000866374-18-000013:mdna:13]

[0000866374-19-000003:mdna:14]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. Since the beginning of fiscal year 2016, we have launched several programs broadly across our portfolio of services and in some instances, we have deployed certain new technologies. We continue to invest in innovation and we have expanded our design and engineering relationships through our product innovation centers and global design centers.

[0000866374-19-000003:mdna:15]
During the quarter, we took action to revise our go-to-market strategy within our CTG business, where we are actively managing under-performing accounts and are focused on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements.

[0000866374-19-000003:mdna:16]
We continue to invest in the capital expenditures necessary to support underlying higher margin, long-term programs in our IEI and HRS businesses as well as building out capacity in India. During our third quarter of fiscal year 2019, we developed a sustainable operating plan for India and will have our regional build-out in India mostly completed in the fourth quarter of

[0000866374-19-000003:mdna:17]
[same as prior period, unchanged from 0000866374-18-000013:mdna:37]

[0000866374-19-000003:mdna:18]
fiscal year 2019. We also completed the wind down of our NIKE operations in Mexico, and made progress in streamlining our third-party investments.

[0000866374-19-000003:mdna:19]
[same as prior period, unchanged from 0000866374-18-000013:mdna:15]

[0000866374-19-000003:mdna:20]
We are one of the world's largest providers of global supply chain solutions, with revenues of $20.1 billion for the nine-month period ended December 31, 2018 and $25.4 billion in fiscal year 2018. On April 1, 2018, we adopted the new revenue standard and as a result we recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information has not been restated and continues to be reported under the accounting standards in effect at the time. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-19-000003:mdna:21]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Net sales: |  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  |  | (In millions) |
| China |  | $ | 1,779 |  |  | 26 | % |  | $ | 1,996 |  |  | 30 | % |  | $ | 5,179 |  |  | 26 | % |  | $ | 5,493 |  |  | 29 | % |
| Mexico |  | 1,187 |  |  | 17 | % |  | 1,183 |  |  | 18 | % |  | 3,506 |  |  | 17 | % |  | 3,302 |  |  | 17 | % |
| U.S. |  | 886 |  |  | 13 | % |  | 723 |  |  | 11 | % |  | 2,173 |  |  | 11 | % |  | 2,157 |  |  | 11 | % |
| Malaysia |  | 548 |  |  | 8 | % |  | 507 |  |  | 8 | % |  | 1,586 |  |  | 8 | % |  | 1,527 |  |  | 8 | % |
| Brazil |  | 512 |  |  | 7 | % |  | 729 |  |  | 11 | % |  | 1,632 |  |  | 8 | % |  | 1,969 |  |  | 10 | % |
| India |  | 463 |  |  | 7 | % |  | 190 |  |  | 3 | % |  | 1,372 |  |  | 7 | % |  | 445 |  |  | 2 | % |
| Other |  | 1,570 |  |  | 22 | % |  | 1,424 |  |  | 19 | % |  | 4,631 |  |  | 23 | % |  | 4,137 |  |  | 23 | % |
|  |  | $ | 6,945 |  |  |  |  |  | $ | 6,752 |  |  |  |  |  | $ | 20,079 |  |  |  |  |  | $ | 19,030 |  |  |  |  |

[0000866374-19-000003:mdna:22]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2018 |  | March 31, 2018 |
|  | (In millions) |
| China | $ | 507 |  |  | 23 | % |  | $ | 492 |  |  | 22 | % |
| Mexico | 498 |  |  | 22 | % |  | 587 |  |  | 26 | % |
| U.S. | 345 |  |  | 16 | % |  | 305 |  |  | 14 | % |
| India | 181 |  |  | 8 | % |  | 78 |  |  | 3 | % |
| Malaysia | 144 |  |  | 7 | % |  | 153 |  |  | 7 | % |
| Brazil | 97 |  |  | 4 | % |  | 108 |  |  | 5 | % |
| Other | 442 |  |  | 20 | % |  | 517 |  |  | 23 | % |
|  | $ | 2,214 |  |  |  |  |  | $ | 2,240 |  |  |  |  |

[0000866374-19-000003:mdna:23]
[same as prior period, unchanged from 0000866374-18-000013:mdna:20]

[0000866374-19-000003:mdna:24]
[same as prior period, unchanged from 0000866374-18-000013:mdna:21]

[0000866374-19-000003:mdna:25]
[same as prior period, unchanged from 0000866374-18-000013:mdna:22]

[0000866374-19-000003:mdna:26]
[same as prior period, unchanged from 0000866374-18-000013:mdna:23]

[0000866374-19-000003:mdna:27]
33

[0000866374-19-000003:mdna:28]
[same as prior period, unchanged from 0000866374-18-000013:mdna:24]

[0000866374-19-000003:mdna:29]
[same as prior period, unchanged from 0000866374-18-000013:mdna:25]

[0000866374-19-000003:mdna:30]
[same as prior period, unchanged from 0000866374-18-000013:mdna:26]

[0000866374-19-000003:mdna:31]
[same as prior period, unchanged from 0000866374-18-000013:mdna:27]

[0000866374-19-000003:mdna:32]
[same as prior period, unchanged from 0000866374-18-000013:mdna:28]

[0000866374-19-000003:mdna:33]
[same as prior period, unchanged from 0000866374-18-000013:mdna:29]

[0000866374-19-000003:mdna:34]
[same as prior period, unchanged from 0000866374-18-000013:mdna:30]

[0000866374-19-000003:mdna:35]
[same as prior period, unchanged from 0000866374-18-000013:mdna:31]

[0000866374-19-000003:mdna:36]
[same as prior period, unchanged from 0000866374-18-000013:mdna:32]

[0000866374-19-000003:mdna:37]
| • | the impacts on our business due to component shortages or other supply chain related constraints; |

[0000866374-19-000003:mdna:38]
[same as prior period, unchanged from 0000866374-18-000013:mdna:34]

[0000866374-19-000003:mdna:39]
[same as prior period, unchanged from 0000866374-18-000013:mdna:35]

[0000866374-19-000003:mdna:40]
[same as prior period, unchanged from 0000866374-18-000013:mdna:36]

[0000866374-19-000003:mdna:41]
[same as prior period, unchanged from 0000866374-18-000013:mdna:38]

[0000866374-19-000003:mdna:42]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 606, as discussed below. In addition, due to the recent stock price decline, we believe the significant drop in market value constitutes a "triggering event" in accordance with the applicable accounting literature, and accordingly completed an interim impairment test as noted below.

[0000866374-19-000003:mdna:43]
[same as prior period, unchanged from 0000866374-18-000013:mdna:40]

[0000866374-19-000003:mdna:44]
[same as prior period, unchanged from 0000866374-18-000013:mdna:41]

[0000866374-19-000003:mdna:45]
Valuation of Private Company Investments

[0000866374-19-000003:mdna:46]
We assess our investments for impairment whenever events or changes in circumstances indicate that the assets may be impaired. The factors we consider in our evaluation of potential impairment of our investments, include, but are not limited to a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. The carrying value of certain of our investments are individually material, thus there is the potential for material charges in future periods if we determine that those investments are impaired.

[0000866374-19-000003:mdna:47]
The Company is currently assessing its strategy with respect to its investment portfolio including its investment in Elementum as well as certain investment funds. As of the date of the filing of this Form 10-Q, no decisions have been made by management. Accordingly, management has not identified any impairment indicators with respect to these investments as of December 31, 2018. However, upon completion by management of its evaluations and decisions, the Company may incur impairment charges, which could be material.

[0000866374-19-000003:mdna:48]
[same as prior period, unchanged from 0000866374-18-000013:mdna:42]

[0000866374-19-000003:mdna:49]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. Due to the decline in the Company's market capitalization during the quarter ended December 31, 2018, we believe this constituted a "triggering event" in accordance with the applicable accounting literature and accordingly completed an interim impairment test that includes comparing the fair value of a reporting unit with its carrying amount, including goodwill. Based on the results, the Company determined that no impairment existed as of the date of the impairment test as the fair value of each one of our reporting units exceeded its respective carrying values.  As of the date of the impairment test, all reporting units' fair values were more than 25% over their respective carrying values, with the exception of the CTG reporting unit which was 23% in excess of its carrying value. The estimated future results for CTG used in the impairment analysis reflect the Company’s revised strategy including the wind down of our NIKE operations in Mexico, further restrictions on capital expenditures related to our expansion into India and our focus on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements. If we are not successful in driving improved results in our CTG segment it is reasonably possible that material goodwill impairment charges could be recorded in future periods. Refer to note 2 to the condensed consolidated financial statements for further details.

[0000866374-19-000003:mdna:50]
[same as prior period, unchanged from 0000866374-18-000013:mdna:44]

[0000866374-19-000003:mdna:51]
[same as prior period, unchanged from 0000866374-18-000013:mdna:45]

[0000866374-19-000003:mdna:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 94.0 |  |  | 93.4 |  |  | 93.9 |  |  | 93.4 |  |
| Restructuring charges | 0.9 |  |  | 0.0 |  |  | 0.4 |  |  | 0.0 |  |
| Gross profit | 5.1 |  |  | 6.6 |  |  | 5.7 |  |  | 6.6 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 3.7 |  |  | 3.6 |  |  | 4.1 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | 0.0 |  |  | 0.1 |  |  | 0.0 |  |
| Interest and other, net | 0.8 |  |  | 0.5 |  |  | 0.7 |  |  | 0.5 |  |
| Other charges (income), net | 1.0 |  |  | 0.1 |  |  | 0.0 |  |  | (0.9 | ) |
| Income (loss) before income taxes | (0.5 | ) |  | 2.0 |  |  | 1.0 |  |  | 2.6 |  |
| Provision for income taxes | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Net income (loss) | (0.7 | )% |  | 1.7 | % |  | 0.7 | % |  | 2.3 | % |

[0000866374-19-000003:mdna:53]
[same as prior period, unchanged from 0000866374-18-000013:mdna:47]

[0000866374-19-000003:mdna:54]
[same as prior period, unchanged from 0000866374-18-000013:mdna:48]

[0000866374-19-000003:mdna:55]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Segments: | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  | (In millions) |  |  |
| Communications & Enterprise Compute | $ | 2,260 |  |  | 33 | % |  | $ | 1,979 |  |  | 29 | % |  | $ | 6,355 |  |  | 32 | % |  | $ | 5,853 |  |  | 31 | % |
| Consumer Technologies Group | 1,819 |  |  | 26 | % |  | 2,057 |  |  | 30 | % |  | 5,423 |  |  | 27 | % |  | 5,324 |  |  | 28 | % |
| Industrial & Emerging Industries | 1,659 |  |  | 24 | % |  | 1,491 |  |  | 22 | % |  | 4,671 |  |  | 23 | % |  | 4,336 |  |  | 23 | % |
| High Reliability Solutions | 1,207 |  |  | 17 | % |  | 1,225 |  |  | 19 | % |  | 3,630 |  |  | 18 | % |  | 3,517 |  |  | 18 | % |
|  | $ | 6,945 |  |  |  |  | $ | 6,752 |  |  |  |  | $ | 20,079 |  |  |  |  | $ | 19,030 |  |  |  |

[0000866374-19-000003:mdna:56]
Net sales during the three-month period ended December 31, 2018 totaled $6.9 billion, representing an increase of approximately $193 million, or 3% from $6.8 billion during the three-month period ended December 31, 2017. The overall increase in sales was driven by increases in our CEC and IEI segments offset by a decline in sales in our CTG and HRS segments. Our CEC segment increased $281 million, driven by momentum from our cloud and data center business as well as the expansion of network infrastructure programs to support 5G technology, offset by declines in our legacy communications business. Our IEI segment increased $168 million, mainly driven by new programs and customer launches within our industrial, home and lifestyle business, offset by declines in our capital equipment and energy businesses. Our CTG segment decreased $237 million, primarily within the legacy consumer sectors of the segment and also resulting from our intentions of actively managing underperforming customers and categories. Our HRS segment decreased $18 million primarily due to market softness in our automotive businesses offset by strengthening demand in our health solutions business. Net sales increased $66 million to $3.0 billion in Asia, $167 million to $1.3 billion in Europe, offset by a modest decline of $40 million to $2.6 billion in the Americas.

[0000866374-19-000003:mdna:57]
Net sales during the nine-month period ended December 31, 2018 totaled $20.1 billion, representing an increase of approximately $1.1 billion, or 6% from $19.0 billion during the nine-month period ended December 31, 2017. The increase in net sales during the period was notable across all of our segments, driven by a $0.5 billion increase in CEC and a $0.3 billion increase in IEI due to the same factors described above. The HRS increase of $113 million during the period was primarily due to higher sales in our health solutions businesses. The CTG increase of $99 million during the period was the result of higher sale in our mobile devices businesses offset by declines in our consumer businesses. Net sales was higher across all our regions with increases of $7 million to $7.5 billion in the Americas, $595 million to $8.9 billion in Asia, and $447 million to $3.7 billion in Europe.

[0000866374-19-000003:mdna:58]
Our ten largest customers, during the three and nine-month periods ended December 31, 2018, accounted for approximately 43% of net sales. Our ten largest customers, during the three and nine-month periods ended December 31, 2017, accounted for approximately 43% and 42% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2018 or December 31, 2017.

[0000866374-19-000003:mdna:59]
[same as prior period, unchanged from 0000866374-18-000013:mdna:53]

[0000866374-19-000003:mdna:60]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities including specific restructuring activities from time to time. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-19-000003:mdna:61]
Gross profit during the three-month period ended December 31, 2018 decreased $89 million to $357 million, or 5.1% of net sales, from $446 million, or 6.6% of net sales, during the three-month period ended December 31, 2017. Gross profit during the nine-month period ended December 31, 2018 decreased $109 million to $1.1 billion, or 5.7% of net sales, from $1.2 billion, or 6.6% of net sales, during the nine-month period ended December 31, 2017. Gross margin deteriorated 150 basis points and 90

[0000866374-19-000003:mdna:62]
[same as prior period, unchanged from 0000866374-18-000013:mdna:73]

[0000866374-19-000003:mdna:63]
basis points during the three-month and nine-month periods ended December 31, 2018, respectively. The decrease in both gross profit and gross margin is primarily due to revenue reductions in some of our higher margin businesses, such as automotive and semi-cap equipment, combined with the $60 million, or 0.9% of net sales, and $90 million, or 0.4% of net sales, for restructuring charges recorded in the three-month and nine-month periods ended December 31, 2018, respectively.

[0000866374-19-000003:mdna:64]
[same as prior period, unchanged from 0000866374-18-000013:mdna:56]

[0000866374-19-000003:mdna:65]
An operating segment’s performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments, restructuring charges, the new revenue standard adoption impact, contingencies and other, other charges (income), net and interest and other, net. A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-19-000003:mdna:66]
[same as prior period, unchanged from 0000866374-18-000013:mdna:58]

[0000866374-19-000003:mdna:67]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  | (In millions) |  |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 63 |  |  | 2.8 | % |  | $ | 50 |  |  | 2.5 | % |  | 171 |  |  | 2.7 | % |  | $ | 142 |  |  | 2.4 | % |
| Consumer Technologies Group | 39 |  |  | 2.1 | % |  | 39 |  |  | 1.9 | % |  | 97 |  |  | 1.8 | % |  | 87 |  |  | 1.6 | % |
| Industrial & Emerging Industries | 79 |  |  | 4.7 | % |  | 61 |  |  | 4.1 | % |  | 196 |  |  | 4.2 | % |  | 168 |  |  | 3.9 | % |
| High Reliability Solutions | 96 |  |  | 7.9 | % |  | 101 |  |  | 8.2 | % |  | 279 |  |  | 7.7 | % |  | 283 |  |  | 8.1 | % |
| Corporate and Other | (20 | ) |  |  |  | (32 | ) |  |  |  | (76 | ) |  |  |  | (94 | ) |  |  |
| Total segment income | 256 |  |  | 3.7 | % |  | 220 |  |  | 3.3 | % |  | 668 |  |  | 3.3 | % |  | 586 |  |  | 3.1 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 20 |  |  |  |  | 20 |  |  |  |  | 57 |  |  |  |  | 56 |  |  |  |
| Stock-based compensation | 21 |  |  |  |  | 21 |  |  |  |  | 61 |  |  |  |  | 63 |  |  |  |
| Customer related asset impairments (1) | 50 |  |  |  |  | — |  |  |  |  | 68 |  |  |  |  | 5 |  |  |  |
| Restructuring charges (Note 17) | 66 |  |  |  |  | — |  |  |  |  | 100 |  |  |  |  | 8 |  |  |  |
| New revenue standard adoption impact (Note 1 & Note 3) | — |  |  |  |  | — |  |  |  |  | 9 |  |  |  |  | — |  |  |  |
| Contingencies and other (2) | 5 |  |  |  |  | — |  |  |  |  | 25 |  |  |  |  | 36 |  |  |  |
| Other charges (income), net (Note 8) | 72 |  |  |  |  | 7 |  |  |  |  | (9 | ) |  |  |  | (173 | ) |  |  |
| Interest and other, net | 54 |  |  |  |  | 31 |  |  |  |  | 137 |  |  |  |  | 86 |  |  |  |
| Income (loss) before income taxes | $ | (32 | ) |  |  |  | $ | 141 |  |  |  |  | $ | 219 |  |  |  |  | $ | 505 |  |  |  |
| Amounts may not sum due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-19-000003:mdna:68]
| (1) | Customer related asset impairments for the three and nine-month periods ended December 31, 2018 relate to additional provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or we are disengaging from. |

[0000866374-19-000003:mdna:69]
| (2) | Contingencies and other during the three and nine-month periods ended December 31, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, for the nine-month period ended December 31, 2018, Contingencies and other also includes certain charges of the China based Multek operation that was divested in the second quarter of fiscal year 2019. |

[0000866374-19-000003:mdna:70]
During the nine-month period ended December 31, 2017, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, along with certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions.

[0000866374-19-000003:mdna:71]
CEC segment margin increased 30 basis points, to 2.8% for the three-month period ended December 31, 2018, from 2.5% during the three-month period ended December 31, 2017. CEC segment margin increased 30 basis points, to 2.7% for the nine-month period ended December 31, 2018, from 2.4% for the nine-month period ended December 31, 2017. The increase in

[0000866374-19-000003:mdna:72]
CEC's margin during the periods is primarily due to better absorption of its cost structure from higher revenue as well as an improved margin mix with greater concentration of cloud data center solutions and 5G related programs.

[0000866374-19-000003:mdna:73]
CTG segment margin increased 20 basis points to 2.1% for the three-month period ended December 31, 2018, from 1.9% during the three-month period ended December 31, 2017 as a result of lower ramp up costs for a certain mobile customer as well as lower losses from our NIKE operations in Mexico compared to the same period in the prior year. CTG segment margin increased 20 basis points, to 1.8% for the nine-month period ended December 31, 2018, from 1.6% for the nine-month period ended December 31, 2017 primarily due to lower losses from our NIKE operations compared to the same period in the prior year.

[0000866374-19-000003:mdna:74]
IEI segment margin increased 60 basis points, to 4.7% for the three-month period ended December 31, 2018, from 4.1% during the three-month period ended December 31, 2017 as a result of improved overhead absorption benefits from the increased revenues across multiple new programs ramping in our industrial, home and lifestyle business offset by reduced demand in capital equipment. IEI segment margin increased 30 basis points, to 4.2% for the nine-month period ended December 31, 2018, from 3.9% for the nine-month period ended December 31, 2017. The increase in IEI's margin during the period is due to the same factors described above, offset by reduced demand in our energy businesses.

[0000866374-19-000003:mdna:75]
HRS segment margin decreased 30 basis points, to 7.9% for the three-month period ended December 31, 2018, from 8.2% during the three-month period ended December 31, 2017. HRS segment margin decreased 40 basis points, to 7.7% for the nine-month period ended December 31, 2018, from 8.1% for the nine-month period ended December 31, 2017 primarily as a result of the reduced revenues and margin pressure in certain parts of our automotive business offset by increases in our health solutions business.

[0000866374-19-000003:mdna:76]
Restructuring charges

[0000866374-19-000003:mdna:77]
During our third quarter of fiscal year 2019, we took focused actions to optimize our portfolio, most notably within CTG. We completed the wind down of our NIKE operations in Mexico and we recognized charges of $36 million and $66 million for the three and nine-month periods ended December 31, 2018, respectively, primarily for non-cash asset impairments.

[0000866374-19-000003:mdna:78]
In total, the Company recognized pre-tax restructuring charges of approximately $66 million and $100 million during the three and nine-month periods ended December 31, 2018, respectively. In addition to the charges related to our NIKE operations in Mexico, the Company executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total charges, approximately $60 million and $90 million was recognized as a component of cost of sales during the three and nine-month periods ended December 31, 2018, respectively. The Company continues to evaluate its existing footprint and cost structure and may determine that further reductions are required, and if executed, additional restructuring charges could have a material impact on the financial statements.

[0000866374-19-000003:mdna:79]
Of the total restructuring charges recognized during the three and nine-month periods ended December 31, 2018, $39 million and $73 million respectively, were non-cash charges primarily related to asset impairment charges. There were no material restructuring charges incurred during the three and nine-month periods ended December 31, 2017.

[0000866374-19-000003:mdna:80]
[same as prior period, unchanged from 0000866374-18-000013:mdna:69]

[0000866374-19-000003:mdna:81]
Selling, general and administrative expenses (“SG&A”) was $238 million, or 3.4% of net sales, during the three-month period ended December 31, 2018, decreasing $9 million from $247 million, or 3.7% of net sales, during the three-month period ended December 31, 2017. SG&A was $723 million, or 3.6% of net sales, during the nine-month period ended December 31, 2018, decreasing $49 million from $772 million, or 4.1% of net sales, during the nine-month period ended December 31, 2017. This decrease was primarily due to lesser incremental costs from acquisitions compared to those incurred during fiscal year 2018 as well as additional benefits realized in the three and nine-month periods ended December 31, 2018, from reduced headcount costs resulting from prior restructuring programs.

[0000866374-19-000003:mdna:82]
[same as prior period, unchanged from 0000866374-18-000013:mdna:71]

[0000866374-19-000003:mdna:83]
Amortization of intangible assets for the three-month periods ended December 31, 2018 and December 31, 2017 remained consistent at approximately $20 million.  Amortization of intangible assets marginally increased during the nine-month period ended December 31, 2018 to $57 million, from $56 million for the three-month period ended December 31, 2017 primarily due to incremental amortization expenses on intangible assets relating to our acquisition completed during the latter part of fiscal year 2018.

[0000866374-19-000003:mdna:84]
[same as prior period, unchanged from 0000866374-18-000013:mdna:74]

[0000866374-19-000003:mdna:85]
Interest and other, net was $54 million during the three-month period ended December 31, 2018 compared to $31 million during the three-month period ended December 31, 2017, and $137 million during the nine-month period ended December 31, 2018 compared to $86 million during the nine-month period ended December 31, 2017. The increase in interest and other, net was primarily a result of higher interest expense due to higher interest rates and higher average borrowing levels, and increases in net foreign exchange losses, coupled with a higher realization of losses associated with certain of our strategic investments in privately held companies accounted for under the equity method of accounting.

[0000866374-19-000003:mdna:86]
[same as prior period, unchanged from 0000866374-18-000013:mdna:76]

[0000866374-19-000003:mdna:87]
Other charges (income), net was $72 million of net expense during the three-month period ended December 31, 2018 compared to $7 million of net expense during the three-month period ended December 31, 2017. The increase in net expense is primarily the result of a $70 million charge during the period for the portion of our investment in an unrelated third-party venture backed company, determined to be impaired. Refer to note 2 to the condensed financial statements for more details on the impairment charge.

[0000866374-19-000003:mdna:88]
Other charges (income), net was $9 million of net income during the nine-month period ended December 31, 2018, compared to $172 million of income during the nine-month period ended December 31, 2017. The decrease in net income is primarily due to a lower non-cash gain recognized in fiscal year 2019 as a result of the deconsolidation of Bright Machines (formally known as AutoLab AI), or $87 million. This decline was offset by the $70 million charge on investment impairment discussed above, compared to the $152 million non-cash gain recognized during fiscal year 2018 as a result of the deconsolidation of Elementum SCM (Cayman) Ltd. Also offsetting the decrease in net income is a $39 million gain recognized from the disposition of Wink during the first quarter of fiscal year 2018. For further description on the deconsolidation of Bright Machines, refer to note 2 to the condensed consolidated financial statements.

[0000866374-19-000003:mdna:89]
[same as prior period, unchanged from 0000866374-18-000013:mdna:78]

[0000866374-19-000003:mdna:90]
[same as prior period, unchanged from 0000866374-18-000013:mdna:79]

[0000866374-19-000003:mdna:91]
[same as prior period, unchanged from 0000866374-18-000013:mdna:80]

[0000866374-19-000003:mdna:92]
The consolidated effective tax rate was (41.5)% and 27.8% for the three and nine-month periods ended December 31, 2018 and 16.2% and 11.3% for the three and nine-month periods ended December 31, 2017. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, the Netherlands and Israel. The effective tax rate for the three-month period ended December 31, 2018 is significantly lower than the effective tax rate for the three-month period ended December 31, 2017, due to a changing jurisdictional mix of income, and the Company's recognition of approximately $194 million in restructuring charges, impairment of non-core investment, and customer related asset impairments with minimal associated tax benefits. This results in tax expense recorded on a US GAAP loss for the period.

[0000866374-19-000003:mdna:93]
[same as prior period, unchanged from 0000866374-18-000013:mdna:82]

[0000866374-19-000003:mdna:94]
As of December 31, 2018, we had cash and cash equivalents of approximately $1.5 billion and bank and other borrowings of approximately $2.9 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We have also entered into a $200 million term loan facility in July 2018, under which there was $52 million borrowings outstanding as of the end of the quarter. Refer to note 6 to the condensed consolidated financial statement for details. As of December 31, 2018, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-19-000003:mdna:95]
Cash used in operating activities was $2.3 billion during the nine-month period ended December 31, 2018. As further discussed below, cash collections from the deferred purchase price on our ABS sales program of $2.7 billion are included in cash from investing activities in accordance with new accounting guidance. Overall, the Company's net operating assets, primarily accounts receivable, inventory and contract assets, have increased to support increased operations and new production ramps. The increased asset base has not been fully offset by the increase in accounts payable. The increased net

[0000866374-19-000003:mdna:96]
39

[0000866374-19-000003:mdna:97]
asset position, further discussed below, was partially offset by $158 million of net income for the period plus $567 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation, net of an $87 million gain from the deconsolidation of Bright Machines, which is included in the determination of net income.

[0000866374-19-000003:mdna:98]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure the Company’s liquidity. As of March 31, 2018, net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories, less accounts payable. As part of the adoption of ASC 606, as further described in note 1 to the condensed consolidated financial statements, we expanded net working capital to include contract assets on a going forward basis. Net working capital increased $193 million to $1.8 billion as of December 31, 2018, from $1.6 billion as of March 31, 2018. This increase is primarily driven by (i) an increase of $298 million in contract assets upon adoption of ASC 606, (ii) a $217 million increase in accounts receivable adding back reductions from non-cash accounts receivable sales, and (iii) a $98 million increase in our inventory levels from March 31, 2018, offset by approximately $421 million increase in accounts payable. Despite the increase in our net working capital position from March 31, 2018, current quarter net working capital as a percentage of annualized net sales for the quarter then ended improved slightly at 6.6% as compared to 6.8% of annualized net sales for the quarter ended December 31, 2017. The Company generally operates in a net working capital targeted range between 6%-8% of annualized revenue for the quarter.

[0000866374-19-000003:mdna:99]
Cash provided by investing activities was $2.5 billion during the nine-month period ended December 31, 2018. This was primarily driven by the impact of our adoption of ASU 2016-15 during the current fiscal year, which requires us to classify cash collections on deferred purchase price from our ABS programs that were previously classified as operating cash inflows as cash flows from investing activities. Refer to note 1 to the condensed consolidated financial statements for further description of the ASU. In addition, we received $267 million of proceeds, net of cash held, in connection with the divestitures of our China-based Multek operations as further described in note 13 to the condensed consolidated financial statements. During the nine-month period ended December 31, 2018, we also invested $505 million of net capital expenditures for property and equipment to expand capabilities and capacity in support of our expanding IEI and HRS businesses as well as building out capacity in India, which was higher by $116 million from the same period in the prior year, and will be substantially complete during the fiscal year 2019. We further paid approximately $13 million, net of cash acquired, for the acquisition of a business that expanded the Company's capabilities in the telecom market within the CEC segment.

[0000866374-19-000003:mdna:100]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Upon adoption of ASU 2016-15 during the first quarter of fiscal year 2019, our free cash flow is redefined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present cash flows on a consistent basis for investor transparency. Our free cash flows for the nine-month period ended December 31, 2018 was a use of $126 million compared to an inflow of $42 million for the nine-month period ended December 31, 2017. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-19-000003:mdna:101]
|  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |
|  | (In millions) |
| Net cash used in operating activities | $ | (2,329 | ) |  | $ | (3,108 | ) |
| Cash collection of deferred purchase price | 2,708 |  |  | 3,539 |  |
| Purchases of property and equipment | (592 | ) |  | (433 | ) |
| Proceeds from the disposition of property and equipment | 87 |  |  | 44 |  |
| Free cash flow | $ | (126 | ) |  | $ | 42 |  |

[0000866374-19-000003:mdna:102]
Cash used in financing activities was $81 million during the nine-month period ended December 31, 2018, which was primarily for the repurchase of our ordinary shares in the amount of $124 million offset by the $52 million proceeds from our India term loan as described in note 6.

[0000866374-19-000003:mdna:103]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our

[0000866374-19-000003:mdna:104]
existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2018, and March 31, 2018, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2018). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-19-000003:mdna:105]
[same as prior period, unchanged from 0000866374-18-000013:mdna:95]

[0000866374-19-000003:mdna:106]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements. To a lesser degree, our vendors participate in our supplier financing programs, which amounts have been immaterial to date.

[0000866374-19-000003:mdna:107]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-19-000003:mdna:108]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 16, 2018. During the nine-month period ended December 31, 2018, the Company paid $124 million to repurchase shares under the current and prior repurchase plans at an average price of $11.12 per share. As of December 31, 2018, shares in the aggregate amount of $390 million were available to be repurchased under the current plan.

[0000866374-19-000003:mdna:109]
[same as prior period, unchanged from 0000866374-18-000013:mdna:99]

[0000866374-19-000003:mdna:110]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2018. There have been no material changes in our contractual obligations and commitments since March 31, 2018, except for a 20-year lease we entered into for a certain new China facility. The total amount of future minimum lease payments is estimated to be $82 million.

[0000866374-19-000003:mdna:111]
[same as prior period, unchanged from 0000866374-18-000013:mdna:101]

[0000866374-19-000003:mdna:112]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of December 31, 2018, and March 31, 2018, the fair values of our deferred purchase price receivable were approximately $319 million and $445 million, respectively. As of December 31, 2018, and March 31, 2018, the outstanding balance on receivables sold for cash was $1.5 billion and $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 11 to the condensed consolidated financial statements.
