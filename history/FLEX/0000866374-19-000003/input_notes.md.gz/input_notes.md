# FLEX notes — 0000866374-19-000003


## flex:InterestAndOtherNetTextBlock

[0000866374-19-000003:notes:1]
[same as prior period, unchanged from 0000866374-18-000013:notes:1]

[0000866374-19-000003:notes:2]
During the three and nine-month periods ended December 31, 2018, the Company recognized interest expense of $38.8 million and $107.5 million, respectively, on its debt obligations outstanding during the periods. During the three and nine-month periods ended December 31, 2017, the Company recognized interest expense of $32.1 million and $90.7 million, respectively, on its debt obligations outstanding during the periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-19-000003:notes:3]
BUSINESS ACQUISITIONS AND DIVESTITURES

[0000866374-19-000003:notes:4]
In October 2018, the Company completed the acquisition of a business that was not significant to the consolidated financial position, result of operations and cash flows of the Company.  The acquired business expanded the Company's design capabilities in the telecom market within the CEC segment. The assets acquired and liabilities assumed were not material to the Company's consolidated financial results. Results of operations were included in the Company’s condensed consolidated financial results beginning on the date of acquisition, and were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-19-000003:notes:5]
During the third quarter of fiscal year 2019, the Company disposed of an immaterial non-strategic business in Brazil that operated across all of its segments. The net loss on disposition was not material to the Company's consolidated financial results, and was included in other charges (income), net in the condensed consolidated statement of operation for the three and nine-month periods ended December 31, 2018.

[0000866374-19-000003:notes:6]
Further, during the second quarter of fiscal year 2019, the Company divested its China-based Multek operations, for proceeds of approximately $267.1 million, net of cash. The Company transferred approximately $231.4 million of net assets, primarily property and equipment, accounts receivable, and accounts payable. Further, the Company incurred various selling transaction costs as part of this divestiture and allocated approximately $19.0 million of goodwill to the divested business. This transaction resulted in the recognition of an immaterial loss which is included in other charges (income), net in the condensed consolidated statements of operations for the three and nine-month periods ended December 31, 2018.

[0000866374-19-000003:notes:7]
Pro-forma results of operations for these divestitures have not been presented because the effects were not individually, nor in the aggregate, material to the Company's consolidated financial results for all periods presented.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-19-000003:notes:8]
COMMITMENTS AND CONTINGENCIES

[0000866374-19-000003:notes:9]
Litigation and other legal matters

[0000866374-19-000003:notes:10]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-19-000003:notes:11]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-19-000003:notes:12]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-19-000003:notes:13]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On January 8, 2019, another shareholder filed a motion to intervene in the case for the purposes of vacating the Court’s October 1, 2018 order and reopening the lead plaintiff process; that motion is set for hearing on April 4, 2019. On January 15, 2019, the Court issued an order providing that defendants need not file any motion to dismiss until after the motion to intervene is decided. In addition, the Court has set a case management conference for April 24, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-19-000003:notes:14]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-19-000003:notes:15]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $88.6 million based on the exchange rate as of December 31, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-19-000003:notes:16]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-19-000003:notes:17]
[same as prior period, unchanged from 0000866374-18-000013:notes:15]

[0000866374-19-000003:notes:18]
[same as prior period, unchanged from 0000866374-18-000013:notes:16]

[0000866374-19-000003:notes:19]
|  | Three-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (55,574 | ) |  | $ | (100,807 | ) |  | $ | (156,381 | ) |  | $ | (48,470 | ) |  | $ | (75,403 | ) |  | $ | (123,873 | ) |
| Other comprehensive gain (loss) before reclassifications | (14,683 | ) |  | (7,777 | ) |  | (22,460 | ) |  | (4,643 | ) |  | 7,248 |  |  | 2,605 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 19,318 |  |  | — |  |  | 19,318 |  |  | (74 | ) |  | 244 |  |  | 170 |  |
| Net current-period other comprehensive gain (loss) | 4,635 |  |  | (7,777 | ) |  | (3,142 | ) |  | (4,717 | ) |  | 7,492 |  |  | 2,775 |  |
| Ending balance | $ | (50,939 | ) |  | $ | (108,584 | ) |  | $ | (159,523 | ) |  | $ | (53,187 | ) |  | $ | (67,911 | ) |  | $ | (121,098 | ) |

[0000866374-19-000003:notes:20]
|  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |  | $ | (32,426 | ) |  | $ | (95,717 | ) |  | $ | (128,143 | ) |
| Other comprehensive gain (loss) before reclassifications | (55,396 | ) |  | (58,485 | ) |  | (113,881 | ) |  | (5,488 | ) |  | 27,562 |  |  | 22,074 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 40,203 |  | — |  | — |  |  | 40,203 |  |  | (15,273 | ) |  | 244 |  |  | (15,029 | ) |
| Net current-period other comprehensive gain (loss) | (15,193 | ) |  | (58,485 | ) |  | (73,678 | ) |  | (20,761 | ) |  | 27,806 |  |  | 7,045 |  |
| Ending balance | $ | (50,939 | ) |  | $ | (108,584 | ) |  | $ | (159,523 | ) |  | $ | (53,187 | ) |  | $ | (67,911 | ) |  | $ | (121,098 | ) |

[0000866374-19-000003:notes:21]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2018 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-19-000003:notes:22]
[same as prior period, unchanged from 0000866374-18-000013:notes:20]

[0000866374-19-000003:notes:23]
[same as prior period, unchanged from 0000866374-18-000013:notes:21]

[0000866374-19-000003:notes:24]
[same as prior period, unchanged from 0000866374-18-000013:notes:22]

[0000866374-19-000003:notes:25]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, audio, consumer power electronics, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

[0000866374-19-000003:notes:26]
[same as prior period, unchanged from 0000866374-18-000013:notes:24]

[0000866374-19-000003:notes:27]
| • | High Reliability Solutions ("HRS"), which is comprised of health solutions business, including consumer health, digital health, medical disposables, drug delivery, and medical equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and smart technologies. |

[0000866374-19-000003:notes:28]
[same as prior period, unchanged from 0000866374-18-000013:notes:26]

[0000866374-19-000003:notes:29]
[same as prior period, unchanged from 0000866374-18-000013:notes:27]

[0000866374-19-000003:notes:30]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.

[0000866374-19-000003:notes:31]
The first quarters for fiscal years 2019 and 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively. The second quarters for fiscal years 2019 and 2018 ended on September 28, 2018 and September 29, 2017, which are comprised of 91 days in both periods. The Company's third quarters ends on December 31 of each year, which are comprised of 94 days and 93 days for fiscal years 2019 and 2018, respectively.

[0000866374-19-000003:notes:32]
[same as prior period, unchanged from 0000866374-18-000013:notes:30]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000866374-19-000003:notes:33]
The following table summarizes the activity in the Company's contract assets during the nine-month period ended December 31, 2018 (in thousands):

[0000866374-19-000003:notes:34]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 5,483,688 |  |
| Amounts collected or invoiced | (5,598,024 | ) |
| Ending balance, December 31, 2018 | $ | 298,451 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-19-000003:notes:35]
BANK BORROWINGS AND LONG-TERM DEBT

[0000866374-19-000003:notes:36]
India Term Loan

[0000866374-19-000003:notes:37]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "Facility"), under which there was $52 million in borrowings outstanding as of December 31, 2018. The Facility will be used to fund capital expenditure to support the Company's expansion plan for India. The availability period during which drawdowns can be made will be from the date of the agreement to and including June 30, 2019. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any future drawdown under the Facility will be June 30, 2024. Borrowings under this term loan bear interest at LIBOR plus a margin of 1.15%. The Facility is unsecured, guaranteed by the Company, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to certain exceptions and limitations. This Facility agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2018, the Company was in compliance with the covenants under this term loan agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-19-000003:notes:38]
[same as prior period, unchanged from 0000866374-18-000013:notes:36]

[0000866374-19-000003:notes:39]
[same as prior period, unchanged from 0000866374-18-000013:notes:37]

[0000866374-19-000003:notes:40]
[same as prior period, unchanged from 0000866374-18-000013:notes:38]

[0000866374-19-000003:notes:41]
As of December 31, 2018, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.7 billion as summarized below:

[0000866374-19-000003:notes:42]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 2,195,500 |  |  | — |  |  | $ | 319,564 |  |  | $ | — |  |
| EUR | 57,903 |  |  | 12,413 |  |  | 66,456 |  |  | 14,384 |  |
| HUF | 26,817,000 |  |  | — |  |  | 95,318 |  |  | — |  |
| ILS | 180,000 |  |  | 2,625 |  |  | 47,738 |  |  | 696 |  |
| MXN | 3,907,000 |  |  | — |  |  | 198,453 |  |  | — |  |
| MYR | 288,800 |  |  | 51,100 |  |  | 69,010 |  |  | 12,211 |  |
| RON | 171,000 |  |  | — |  |  | 41,884 |  |  | — |  |
| SGD | 47,100 |  |  | — |  |  | 34,353 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 32,692 |  |  | — |  |
|  |  |  |  |  |  |  | 905,468 |  |  | 27,291 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| CAD | 413,508 |  |  | 446,691 |  |  | 303,203 |  |  | 327,534 |  |
| CNY | 3,569,739 |  |  | 1,097,810 |  |  | 517,310 |  |  | 160,000 |  |
| EUR | 1,943,263 |  |  | 2,058,119 |  |  | 2,215,448 |  |  | 2,346,054 |  |
| GBP | 72,112 |  |  | 65,663 |  |  | 91,160 |  |  | 83,067 |  |
| HUF | 135,200,211 |  |  | 130,812,582 |  |  | 480,555 |  |  | 464,960 |  |
| ILS | 238,075 |  |  | 121,000 |  |  | 63,140 |  |  | 32,090 |  |
| INR | 6,147,046 |  |  | 19,872,836 |  |  | 87,298 |  |  | 281,278 |  |
| MXN | 3,332,861 |  |  | 2,727,145 |  |  | 169,290 |  |  | 138,523 |  |
| MYR | 933,930 |  |  | 647,400 |  |  | 223,167 |  |  | 154,699 |  |
| SEK | 552,834 |  |  | 637,284 |  |  | 61,263 |  |  | 70,646 |  |
| SGD | 91,830 |  |  | 50,580 |  |  | 66,978 |  |  | 36,891 |  |
| Other | N/A |  |  | N/A |  |  | 119,052 |  |  | 317,735 |  |
|  |  |  |  |  |  |  | 4,397,864 |  |  | 4,413,477 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 5,303,332 |  |  | $ | 4,440,768 |  |

[0000866374-19-000003:notes:43]
As of December 31, 2018, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2018, and March 31, 2018, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were $7.4 million as of December 31, 2018, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-19-000003:notes:44]
[same as prior period, unchanged from 0000866374-18-000013:notes:42]

[0000866374-19-000003:notes:45]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31, 2018 |  | March 31, 2018 |  | Balance SheetLocation |  | December 31, 2018 |  | March 31, 2018 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 7,049 |  |  | $ | 19,422 |  |  | Other current liabilities |  | $ | 14,377 |  |  | $ | 7,065 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 21,567 |  |  | $ | 23,912 |  |  | Other current liabilities |  | $ | 21,708 |  |  | $ | 18,246 |  |

[0000866374-19-000003:notes:46]
[same as prior period, unchanged from 0000866374-18-000013:notes:44]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000866374-19-000003:notes:47]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month and nine-month periods ended December 31, 2018 (in thousands), respectively:

[0000866374-19-000003:notes:48]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,235,712 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 5,027,281 |  |
| Over time | 276,714 |  |  | 583,610 |  |  | 460,256 |  |  | 596,966 |  |  | 1,917,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,819,322 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 6,944,827 |  |

[0000866374-19-000003:notes:49]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,740,045 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 14,595,699 |  |
| Over time | 801,790 |  |  | 1,683,094 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 5,483,688 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 5,423,139 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 20,079,387 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-19-000003:notes:50]
[same as prior period, unchanged from 0000866374-18-000013:notes:48]

[0000866374-19-000003:notes:51]
[same as prior period, unchanged from 0000866374-18-000013:notes:49]

[0000866374-19-000003:notes:52]
[same as prior period, unchanged from 0000866374-18-000013:notes:50]

[0000866374-19-000003:notes:53]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Cost of sales | $ | 4,769 |  |  | $ | 5,358 |  |  | $ | 14,940 |  |  | $ | 13,662 |  |
| Selling, general and administrative expenses | 16,258 |  |  | 15,400 |  |  | 46,121 |  |  | 49,356 |  |
| Total share-based compensation expense | $ | 21,027 |  |  | $ | 20,758 |  |  | $ | 61,061 |  |  | $ | 63,018 |  |

[0000866374-19-000003:notes:54]
Total unrecognized compensation expense related to share options under all plans was $3.1 million and will be recognized over a weighted-average remaining vesting period of 1.8 years. As of December 31, 2018, the number of options outstanding and exercisable under all plans was 1.0 million and 0.6 million, respectively, at a weighted-average exercise price of $3.67 per share and $4.69 per share, respectively.

[0000866374-19-000003:notes:55]
During the nine-month period ended December 31, 2018, the Company granted 6.3 million unvested restricted share unit awards. Of this amount, approximately 4.6 million are plain-vanilla unvested restricted share unit awards with no performance or market conditions with an average grant date price of $13.53 per award and will vest over four years. Further, approximately 1.3 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $14.00 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 2.6 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-19-000003:notes:56]
As of December 31, 2018, approximately 14.5 million unvested restricted share unit awards under all plans were outstanding, of which vesting for a targeted amount of 2.6 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 5.2 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2018, 0.6 million shares vested in connection with the restricted share unit awards with market conditions granted in fiscal year 2016.

[0000866374-19-000003:notes:57]
As of December 31, 2018, total unrecognized compensation expense related to unvested restricted share unit awards under all plans was approximately $144.7 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-19-000003:notes:58]
[same as prior period, unchanged from 0000866374-18-000013:notes:56]

[0000866374-19-000003:notes:59]
[same as prior period, unchanged from 0000866374-18-000013:notes:57]

[0000866374-19-000003:notes:60]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  | (In thousands, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (45,169 | ) |  | $ | 118,333 |  |  | $ | 157,751 |  |  | $ | 448,129 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 524,876 |  |  | 528,405 |  |  | 528,528 |  |  | 529,984 |  |
| Basic earnings (losses) per share | (0.09 | ) |  | 0.22 |  |  | 0.30 |  |  | 0.85 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (45,169 | ) |  | $ | 118,333 |  |  | $ | 157,751 |  |  | $ | 448,129 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 524,876 |  |  | 528,405 |  |  | 528,528 |  |  | 529,984 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | — |  |  | 5,947 |  |  | 3,780 |  |  | 5,988 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 524,876 |  |  | 534,352 |  |  | 532,308 |  |  | 535,972 |  |
| Diluted earnings (losses) per share | (0.09 | ) |  | 0.22 |  |  | 0.30 |  |  | 0.84 |  |

[0000866374-19-000003:notes:61]
[same as prior period, unchanged from 0000866374-18-000013:notes:59]

[0000866374-19-000003:notes:62]
| (1) | An immaterial amount of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three-month and nine-month periods ended December 31, 2018 and December 31, 2017, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-19-000003:notes:63]
| (2) | Restricted share unit awards of 6.6 million for the nine-month period ended December 31, 2018, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive restricted share unit awards was excluded for the three-month and nine-month periods ended December 31, 2017. |


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-19-000003:notes:64]
[same as prior period, unchanged from 0000866374-18-000013:notes:62]

[0000866374-19-000003:notes:65]
[same as prior period, unchanged from 0000866374-18-000013:notes:63]

[0000866374-19-000003:notes:66]
[same as prior period, unchanged from 0000866374-18-000013:notes:64]

[0000866374-19-000003:notes:67]
[same as prior period, unchanged from 0000866374-18-000013:notes:65]

[0000866374-19-000003:notes:68]
[same as prior period, unchanged from 0000866374-18-000013:notes:66]

[0000866374-19-000003:notes:69]
[same as prior period, unchanged from 0000866374-18-000013:notes:67]

[0000866374-19-000003:notes:70]
[same as prior period, unchanged from 0000866374-18-000013:notes:68]

[0000866374-19-000003:notes:71]
[same as prior period, unchanged from 0000866374-18-000013:notes:69]

[0000866374-19-000003:notes:72]
[same as prior period, unchanged from 0000866374-18-000013:notes:70]

[0000866374-19-000003:notes:73]
[same as prior period, unchanged from 0000866374-18-000013:notes:71]

[0000866374-19-000003:notes:74]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2018 and December 31, 2017.

[0000866374-19-000003:notes:75]
[same as prior period, unchanged from 0000866374-18-000013:notes:73]

[0000866374-19-000003:notes:76]
[same as prior period, unchanged from 0000866374-18-000013:notes:74]

[0000866374-19-000003:notes:77]
|  | Fair Value Measurements as of December 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 594,814 |  |  | $ | — |  |  | $ | 594,814 |  |
| Foreign exchange contracts (Note 9) | — |  |  | 28,616 |  |  | — |  |  | 28,616 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 2,535 |  |  | 74,237 |  |  | — |  |  | 76,772 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0.003 |  |
| Foreign exchange contracts (Note 9) | $ | — |  |  | $ | (36,085 | ) |  | $ | — |  |  | $ | (36,085 | ) |
|  | Fair Value Measurements as of March 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 452,622 |  |  | $ | — |  |  | $ | 452,622 |  |
| Foreign exchange contracts (Note 9) | — |  |  | 43,334 |  |  | — |  |  | 43,334 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 7,196 |  |  | 67,532 |  |  | — |  |  | 74,728 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 9) | $ | — |  |  | $ | (25,311 | ) |  | $ | — |  |  | $ | (25,311 | ) |

[0000866374-19-000003:notes:78]
[same as prior period, unchanged from 0000866374-18-000013:notes:76]

[0000866374-19-000003:notes:79]
[same as prior period, unchanged from 0000866374-18-000013:notes:77]

[0000866374-19-000003:notes:80]
|  | As of December 31, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 502,475 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 675,625 |  |  | 664,646 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 464,813 |  |  | 464,525 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,760 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,706 |  |  | 587,724 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 53,806 |  |  | 53,806 |  |  | 59,443 |  |  | 59,443 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 113,814 |  |  | 113,814 |  |  | 123,518 |  |  | 123,518 |  |  | Level 2 |
| India Term Loan | 51,901 |  |  | 51,901 |  |  | — |  |  | — |  |  | Level 2 |
| Total | $ | 2,956,665 |  |  | $ | 2,939,651 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |

[0000866374-19-000003:notes:81]
The Company values its Euro Term Loans due September 2020 and January 2022, and India Term Loan based on the current market rate, and as of December 31, 2018, the carrying amounts approximate fair values.

[0000866374-19-000003:notes:82]
[same as prior period, unchanged from 0000866374-18-000013:notes:80]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-19-000003:notes:83]
Recently Adopted Accounting Pronouncement

[0000866374-19-000003:notes:84]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no acquisitions during the period of adoption.

[0000866374-19-000003:notes:85]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company adopted the guidance during the third quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no identified impairments during the period.

[0000866374-19-000003:notes:86]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 was consistent with the Company's current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 11 are now classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 using a monthly approach to track cash flows on deferred purchase price and retrospectively adjusted cash flows from operating and investing activities for fiscal year 2018. Commencing with the second quarter of fiscal year 2019, the Company changed to a method based on daily activity and the amounts presented for operating and investing activities for the nine-month period ended December 31, 2018 reflect the use of this method for the entire period. The Company recorded $2.7 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the nine-month period ended December 31, 2018 and reclassified $3.5 billion of cash receipts on the deferred purchase price for the nine-month period ended December 31, 2017, from cash flows from operating activities to cash flows from investing activities.

[0000866374-19-000003:notes:87]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an immaterial impact on the Company's financial position, results of operations or cash flows.

[0000866374-19-000003:notes:88]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01 which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company adopted this guidance during the second quarter of fiscal year 2019 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000003:notes:89]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")) which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract.

[0000866374-19-000003:notes:90]
The Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

[0000866374-19-000003:notes:91]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress, inventory will be recognized over time (i.e., as the Company manufactures the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

[0000866374-19-000003:notes:92]
The cumulative effect of change made to our April 1, 2018 consolidated balance sheet for the adoption of ASC 606 was as follows:

[0000866374-19-000003:notes:93]
| Condensed Consolidated Balance Sheet |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | Balance at March 31, 2018 | Adjustments | Balance at April 1, 2018 |
| ASSETS |  |  |  |
| Contract assets | — |  | 412,787 |  | 412,787 |  |
| Inventories | 3,799,829 |  | (409,252 | ) | 3,390,577 |  |
| Other current assets | 1,380,466 |  | (51,479 | ) | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,719,418 |  | (87,897 | ) | 1,631,521 |  |
| Other liabilities | 531,587 |  | 2,098 |  | 533,685 |  |
| Accumulated deficit | (3,144,114 | ) | (37,855 | ) | (3,181,969 | ) |

[0000866374-19-000003:notes:94]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The increase in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current assets reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

[0000866374-19-000003:notes:95]
The following tables summarize the impacts of ASC 606 adoption on the Company’s condensed consolidated balance sheets and condensed consolidated statements of operations:

[0000866374-19-000003:notes:96]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of December 31, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 298,451 |  | (298,451 | ) | — |  |
| Inventories | 3,897,891 |  | 315,780 |  | 4,213,671 |  |
| Other current assets | 930,376 |  | 10,044 |  | 940,420 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,527,276 |  | 51,294 |  | 1,578,570 |  |
| Accumulated deficit | (2,947,661 | ) | (36,498 | ) | (2,984,159 | ) |

[0000866374-19-000003:notes:97]
| Condensed Consolidated Statement of Operations |  |  |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | Three-Month Period Ended December 31, 2018 |  | Nine-Month Period Ended December 31, 2018 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |  | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,944,827 |  | $ | (4,885 | ) | $ | 6,939,942 |  |  | $ | 20,079,387 |  | $ | (32,122 | ) | $ | 20,047,265 |  |
| Cost of sales | 6,587,502 |  | (6,907 | ) | 6,580,595 |  |  | 18,941,907 |  | (33,479 | ) | 18,908,428 |  |
| Gross profit | 357,325 |  | 2,022 |  | 359,347 |  |  | 1,137,480 |  | 1,357 |  | 1,138,837 |  |

[0000866374-19-000003:notes:98]
To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, in the first quarter of fiscal year 2019, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications resulted in revenue from these customers being recognized upon shipment of products, rather than over time (i.e., as the Company manufactures products) as further explained in note 3. The result of the modifications for the nine-month period ended December 31, 2018, was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had the Company not amended the contracts, and (ii) had the Company not adopted ASC 606.

[0000866374-19-000003:notes:99]
The impacts to revenue and gross profit as a result of the adoption of ASC 606 are driven by a number of factors including the timing of inventory levels for over time ("OT") customers at the end of each reporting period and the mix of customer profitability. These impacts were not material for the three-month period ended December 31, 2018.

[0000866374-19-000003:notes:100]
For the nine-month period ended December 31, 2018 the as reported revenue was approximately $32.1 million higher and the gross profit approximately $1.4 million lower than it would have been without the adoption of ASC 606. Additional revenue of $164.8 million was reported under ASC 606 due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition and revenue recognized for certain contracts that no longer qualify for net revenue treatment. Approximately $7.9 million of additional gross profit was recognized on the customers qualifying for accelerated revenue recognition. These increases were offset by reductions of $132.7 million of revenue and $9.3 million of gross profit respectively, as a result of the waiver of contract rights noted above. There was no material tax impact for the three and nine-month periods ended December 31, 2018 from the adoption of ASC 606.

[0000866374-19-000003:notes:101]
The Company applies the following practical expedients:

[0000866374-19-000003:notes:102]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected duration of one year or less. |

[0000866374-19-000003:notes:103]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

[0000866374-19-000003:notes:104]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

[0000866374-19-000003:notes:105]
Recently Issued Accounting Pronouncements

[0000866374-19-000003:notes:106]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000003:notes:107]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provides a new private company variable interest entity exemption and changes how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000003:notes:108]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000003:notes:109]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000003:notes:110]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000003:notes:111]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000003:notes:112]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

[0000866374-19-000003:notes:113]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. In January 2018, the FASB issued ASU 2018-01, “Land Easement Practical Expedient for Transition to Topic 842”, which permits an entity to elect an optional transition practical expedient to not evaluate under Topic 842 land easements that exist or expired before the entity’s adoption of Topic 842 and that were not previously accounted for as leases under Topic 840. In July 2018, the FASB issued ASU 2018-11, "Leases (Topic 842): Targeted Improvements", which provides entities with relief from the costs of implementing certain aspects of the new leasing standard, ASC 842. Specifically, under the amendments in ASU 2018-11, (1) entities may elect not to recast the comparative periods presented when transitioning to ASC 842 and (2) lessors may elect not to separate lease and nonlease components when certain conditions are met. Also in July 2018, the FASB issued ASU 2018-10, "Codification Improvements to Topic 842, Leases", which clarifies how to apply certain aspects of the new leases standard, ASC 842. The amendments address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. In December 2018, the FASB issued ASU 2018-20 “Leases (Topic 842): Narrow-Scope Improvements for Lessors” to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing transactions. The amendments have the same effective date and transition requirements as the new lease standard. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach as described in the new transition option above under ASU 2018-11. In conjunction, the Company intends to elect the package of practical expedients offered, which would allow entities to not i) reassess whether any expired or existing contracts contain leases in accordance with the new guidance, ii) reassess lease classifications, and iii) reassess whether initial direct costs capitalized under ASC 840 continue to meet the definition of initial direct costs under the new guidance. While the Company continues to evaluate the effect of adopting the new lease guidance on its consolidated financial statement and related disclosures, the new guidance is expected to have a material impact on the Company’s consolidated balance sheets upon adoption. The Company expect all of its leases including its operating leases will be subject to the new standard. The Company will recognize right-of-use assets and operating lease liabilities on the consolidated balance sheets upon adoption which will increase total assets and liabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-19-000003:notes:114]
[same as prior period, unchanged from 0000866374-18-000013:notes:109]

[0000866374-19-000003:notes:115]
In December 2017, the Securities and Exchange Commission ("SEC") staff issued Staff Accounting Bulletin No. 118 (SAB 118), Income Tax Accounting Implications of the Tax Cuts and Jobs Act ("Tax Act"), which allowed the Company to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As of December 31, 2018, the Company has finalized all provisional amounts related to the Tax Act. Finalizing provisional adjustments related to the Tax Act did not have a material impact on our consolidated financial statements as of December 31, 2018. The Company expects further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-19-000003:notes:116]
[same as prior period, unchanged from 0000866374-18-000013:notes:110]

[0000866374-19-000003:notes:117]
During the three-month period ended December 31, 2018, the Company recognized other charges of $71.9 million, primarily driven by a $70.1 million charge related to the impairment of a certain investment in an unrelated third-party venture backed company. Refer to note 2 for further details on the investment impairment. During the nine-month period ended December 31, 2018, the Company recognized other income of $8.5 million, primarily driven by an $87.3 million gain on the deconsolidation of Bright Machines, offset by the $70.1 million impairment charge discussed above. Refer to note 2 for further details of the deconsolidation.

[0000866374-19-000003:notes:118]
During the nine-month period ended December 31, 2017, the Company deconsolidated Elementum SCM (Cayman) Ltd and recognized a gain on deconsolidation of approximately $151.6 million with no related tax impact, coupled with a $39 million gain recognized for the disposition of Wink, which are both included in other charges (income), net on the condensed consolidated statement of operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-19-000003:notes:119]
RESTRUCTURING CHARGES

[0000866374-19-000003:notes:120]
During the nine-month period ended December 31, 2018, the Company took focused actions to optimize its portfolio, most notably within CTG. The Company completed the wind down of its NIKE operations in Mexico in the third quarter of fiscal year 2019 and recognized charges of $36 million and $66 million for the three and nine-month periods ended December 31, 2018 primarily for non-cash asset impairments. The remaining carrying value of the assets impaired at December 31, 2018, was immaterial and was determined using Level 2 inputs in the fair value hierarchy, such as quoted prices from vendors for similar assets.

[0000866374-19-000003:notes:121]
In total, the Company recognized restructuring charges of approximately $65.8 million and $100.4 million during the three and nine-month periods ended December 31, 2018, respectively. In addition to the charges related to its NIKE operations in Mexico, the Company executed targeted head-count reductions at existing operating and design sites and corporate functions and exited certain immaterial businesses. Of these total charges, approximately $60.4 million and $89.5 million was recognized as a component of cost of sales during the three and nine-month periods ended December 31, 2018, respectively. The Company continues to evaluate its existing footprint and cost structure and may determine that further reductions are required, and if executed, additional restructuring charges could have a material impact on the financial statements.

[0000866374-19-000003:notes:122]
There were no material restructuring activities during the three and nine-month periods ended December 31, 2017.

[0000866374-19-000003:notes:123]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of December 31, 2018 for charges incurred in the nine-month period ended December 31, 2018:

[0000866374-19-000003:notes:124]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2018 | $ | 48,006 |  |  | $ | — |  |  | $ | 13,338 |  |  | $ | 61,344 |  |
| Provision for charges incurred during the nine-month period ended December 31, 2018 | 25,407 |  |  | 46,365 |  |  | 28,661 |  |  | 100,433 |  |
| Cash payments for charges incurred in the fiscal year 2018 and prior | (37,930 | ) |  | — |  |  | (3,355 | ) |  | (41,285 | ) |
| Cash payments for charges incurred during the nine-month period ended December 31, 2018 | (12,921 | ) |  | — |  |  | — |  |  | (12,921 | ) |
| Non-cash charges incurred during the nine-month period ended December 31, 2018 | — |  |  | (46,365 | ) |  | (26,282 | ) |  | (72,647 | ) |
| Balance as of December 31, 2018 | 22,562 |  |  | — |  |  | 12,362 |  |  | 34,924 |  |
| Less: Current portion (classified as other current liabilities) | 22,562 |  |  | — |  |  | 12,362 |  |  | 34,924 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-19-000003:notes:125]
[same as prior period, unchanged from 0000866374-18-000013:notes:113]

[0000866374-19-000003:notes:126]
[same as prior period, unchanged from 0000866374-18-000013:notes:114]

[0000866374-19-000003:notes:127]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-19-000003:notes:128]
[same as prior period, unchanged from 0000866374-18-000013:notes:116]

[0000866374-19-000003:notes:129]
[same as prior period, unchanged from 0000866374-18-000013:notes:117]

[0000866374-19-000003:notes:130]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued upon shipment for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer related accruals in note 2.

[0000866374-19-000003:notes:131]
[same as prior period, unchanged from 0000866374-18-000013:notes:119]

[0000866374-19-000003:notes:132]
[same as prior period, unchanged from 0000866374-18-000013:notes:120]

[0000866374-19-000003:notes:133]
[same as prior period, unchanged from 0000866374-18-000013:notes:121]

[0000866374-19-000003:notes:134]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-19-000003:notes:135]
[same as prior period, unchanged from 0000866374-18-000013:notes:123]

[0000866374-19-000003:notes:136]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the nine-month period ended December 31, 2018 (in thousands):

[0000866374-19-000003:notes:137]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $308.0 million and $265.3 million as of December 31, 2018 and April 1, 2018, respectively.

[0000866374-19-000003:notes:138]
[same as prior period, unchanged from 0000866374-18-000013:notes:126]


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-19-000003:notes:139]
[same as prior period, unchanged from 0000866374-18-000013:notes:127]

[0000866374-19-000003:notes:140]
|  | As of December 31, 2018 |  | As of March 31, 2018 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 297,563 |  |  | $ | (105,000 | ) |  | $ | 192,563 |  |  | $ | 306,943 |  |  | $ | (79,051 | ) |  | $ | 227,892 |  |
| Licenses and other intangibles | 276,844 |  |  | (119,762 | ) |  | 157,082 |  |  | 304,007 |  |  | (107,466 | ) |  | 196,541 |  |
| Total | $ | 574,407 |  |  | $ | (224,762 | ) |  | $ | 349,645 |  |  | $ | 610,950 |  |  | $ | (186,517 | ) |  | $ | 424,433 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-19-000003:notes:141]
The following table summarizes the activity in the Company’s goodwill account for each of its four reporting units (which align to the Company's reportable segments) during the nine-month period ended December 31, 2018:

[0000866374-19-000003:notes:142]
|  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year | $ | 550,983 |  |  | $ | 107,748 |  |  | $ | 337,707 |  |  | $ | 124,732 |  |  | $ | 1,121,170 |  |
| Additions (1) | — |  |  | — |  |  | — |  |  | 10,984 |  |  | 10,984 |  |
| Divestitures (2) | (5,303 | ) |  | (4,484 | ) |  | (4,450 | ) |  | (6,391 | ) |  | (20,628 | ) |
| Foreign currency translation adjustments (3) | (32,692 | ) |  | — |  |  | — |  |  | — |  |  | (32,692 | ) |
| Balance, end of the period | $ | 512,988 |  |  | $ | 103,264 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 1,078,834 |  |

[0000866374-19-000003:notes:143]
| (1) | The goodwill generated during the nine-month period ended December 31, 2018, is primarily related to value placed on the acquired employee workforce, service offerings and capabilities of the acquired business which may change as the Company is still in the process of evaluating the fair value of the assets and liabilities related to business combination completed during the recent period. The goodwill is not deductible for income tax purposes. See note 13 for additional information. |

[0000866374-19-000003:notes:144]
| (2) | During the nine-month period ended December 31, 2018, the Company divested its China-based Multek operations along with another non-strategic immaterial business, and as a result, recorded an aggregate reduction of goodwill of $20.6 million. See note 13 for additional information. |

[0000866374-19-000003:notes:145]
| (3) | During the nine-month period ended December 31, 2018, the Company recorded $32.7 million of foreign currency translation adjustments primarily related to the goodwill associated with historical acquisitions, as the U.S. Dollar fluctuated against foreign currencies. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-19-000003:notes:146]
[same as prior period, unchanged from 0000866374-18-000013:notes:133]

[0000866374-19-000003:notes:147]
|  | As of December 31, 2018 |  | As of March 31, 2018 |
|  | (In thousands) |
| Raw materials | $ | 3,069,688 |  |  | $ | 2,760,410 |  |
| Work-in-progress | 354,294 |  |  | 450,569 |  |
| Finished goods | 473,909 |  |  | 588,850 |  |
|  | $ | 3,897,891 |  |  | $ | 3,799,829 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-19-000003:notes:148]
Selected financial information by segment is in the table below. For the nine-month period ended December 31, 2018, the Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings, as further described in note 1 to the condensed consolidated financial statements. The comparative information for the three and nine-month periods ended December 31, 2017 has not been restated and continues to be reported under the accounting standards in effect at the time:

[0000866374-19-000003:notes:149]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 2,260,228 |  |  | $ | 1,979,045 |  |  | $ | 6,355,311 |  |  | $ | 5,853,435 |  |
| Consumer Technologies Group | 1,819,322 |  |  | 2,056,801 |  |  | 5,423,139 |  |  | 5,323,913 |  |
| Industrial & Emerging Industries | 1,658,925 |  |  | 1,491,063 |  |  | 4,671,188 |  |  | 4,336,201 |  |
| High Reliability Solutions | 1,206,352 |  |  | 1,224,643 |  |  | 3,629,749 |  |  | 3,516,695 |  |
|  | $ | 6,944,827 |  |  | $ | 6,751,552 |  |  | $ | 20,079,387 |  |  | $ | 19,030,244 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 62,590 |  |  | $ | 50,206 |  |  | $ | 171,463 |  |  | $ | 141,541 |  |
| Consumer Technologies Group | 39,023 |  |  | 38,768 |  |  | 96,792 |  |  | 87,494 |  |
| Industrial & Emerging Industries | 78,782 |  |  | 61,328 |  |  | 196,000 |  |  | 167,650 |  |
| High Reliability Solutions | 95,751 |  |  | 100,976 |  |  | 278,874 |  |  | 283,552 |  |
| Corporate and Other | (19,768 | ) |  | (31,557 | ) |  | (75,513 | ) |  | (94,273 | ) |
| Total segment income | 256,378 |  |  | 219,721 |  |  | 667,616 |  |  | 585,964 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 20,308 |  |  | 19,588 |  |  | 57,059 |  |  | 55,865 |  |
| Stock-based compensation | 21,027 |  |  | 20,758 |  |  | 61,061 |  |  | 63,018 |  |
| Customer related asset impairments (1) | 50,153 |  |  | — |  |  | 67,517 |  |  | 4,753 |  |
| Restructuring charges (Note 17) | 65,843 |  |  | — |  |  | 100,433 |  |  | 7,981 |  |
| New revenue standard adoption impact (Note 1 & Note 3) | — |  |  | — |  |  | 9,291 |  |  | — |  |
| Contingencies and other (2) | 4,994 |  |  | — |  |  | 25,363 |  |  | 35,952 |  |
| Other charges (income), net (Note 8) | 71,879 |  |  | 6,865 |  |  | (8,515 | ) |  | (172,467 | ) |
| Interest and other, net | 54,087 |  |  | 31,350 |  |  | 136,889 |  |  | 85,780 |  |
| Income (loss) before income taxes | $ | (31,913 | ) |  | $ | 141,160 |  |  | $ | 218,518 |  |  | $ | 505,082 |  |

[0000866374-19-000003:notes:150]
| (1) | Customer related asset impairments for the three and nine-month periods ended December 31, 2018 relate to provision for doubtful accounts receivable, inventory and impairment of other assets for certain customers experiencing significant financial difficulties and/or the Company is disengaging from. |

[0000866374-19-000003:notes:151]
| (2) | Contingencies and other during the three and nine-month periods ended December 31, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018. In addition, for the nine-month period ended December 31, 2018, Contingencies and other also includes certain charges of the China based Multek operations that was divested in the second quarter of fiscal year 2019. |

[0000866374-19-000003:notes:152]
During the nine-month period ended December 31, 2017, the Company incurred charges in connection with certain legal matters, for loss contingencies where it believed that losses were probable and estimable. Additionally, the Company incurred various other charges predominately related to damages incurred from a typhoon that impacted a China facility, along with certain restructuring charges primarily related to severance for rationalization at existing sites and corporate functions.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-19-000003:notes:153]
[same as prior period, unchanged from 0000866374-18-000013:notes:140]

[0000866374-19-000003:notes:154]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2019 (1) | $ | 17,436 |  |
| 2020 | 65,155 |  |
| 2021 | 60,826 |  |
| 2022 | 52,290 |  |
| 2023 | 44,553 |  |
| Thereafter | 109,385 |  |
| Total amortization expense | $ | 349,645 |  |

[0000866374-19-000003:notes:155]
| (1) | Represents estimated amortization for the remaining three-month period ending March 31, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-19-000003:notes:156]
[same as prior period, unchanged from 0000866374-18-000013:notes:143]

[0000866374-19-000003:notes:157]
[same as prior period, unchanged from 0000866374-18-000013:notes:144]

[0000866374-19-000003:notes:158]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments charges, restructuring charges, the new revenue standard adoption impact, contingencies and other, other charges (income), net and interest and other, net.

[0000866374-19-000003:notes:159]
[same as prior period, unchanged from 0000866374-18-000013:notes:146]

[0000866374-19-000003:notes:160]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled on the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segments nor reported by segment to the Company's CODM.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-19-000003:notes:161]
[same as prior period, unchanged from 0000866374-18-000013:notes:148]

[0000866374-19-000003:notes:162]
[same as prior period, unchanged from 0000866374-18-000013:notes:149]

[0000866374-19-000003:notes:163]
Due to the adoption of ASC 606, amounts that would have been reported as inventory under prior guidance are now included in contract assets or liabilities, depending on the net position of the contract, as disclosed in note 1. As a result of this accounting change, work-in-progress and finished goods as of December 31, 2018 are $315.8 million less than they would have been, had the Company not adopted ASC 606. The comparative information as of March 31, 2018, has not been restated and continues to be reported under the accounting standards in effect at that time.

[0000866374-19-000003:notes:164]
[same as prior period, unchanged from 0000866374-18-000013:notes:151]

[0000866374-19-000003:notes:165]
In accordance with accounting guidance on goodwill and other intangible assets, the Company evaluates goodwill for impairment at the reporting unit level annually, and whenever circumstances occur indicating that goodwill might be impaired. The performance of the test involves comparing the fair value of each of the Company's reporting units with the reporting unit's carrying amount, including goodwill. Upon adoption of  ASU 2017-04, the Company now recognizes an impairment charge (not to exceed the total amount of goodwill allocated to the reporting units) for the amount by which the carrying amount of a reporting unit exceeds the reporting unit's fair value.

[0000866374-19-000003:notes:166]
During the quarter ended December 31, 2018, the Company's market capitalization declined significantly. The Company believed the significant drop in market value constituted a “triggering event” in accordance with the applicable accounting literature, and accordingly completed an interim impairment test as of December 31, 2018. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill.

[0000866374-19-000003:notes:167]
Based on the latest assessment as of December 31, 2018, no impairment existed as of the date of the impairment test as the fair value of each reporting unit exceeds its carrying value. As of the date of the impairment test, all reporting units' fair values were more than 25% over their respective carrying values, with the exception of the CTG reporting unit which was 23% in excess of its carrying value. The estimated future results for CTG used in the impairment analysis reflect the Company’s revised strategy including the wind down of its NIKE operations in Mexico, further restrictions on capital expenditures related to its expansion into India and its focus on partnering with well-funded, leading multi-national brands that control multiple categories of products and have regional demand requirements.

[0000866374-19-000003:notes:168]
[same as prior period, unchanged from 0000866374-18-000013:notes:155]

[0000866374-19-000003:notes:169]
[same as prior period, unchanged from 0000866374-18-000013:notes:156]

[0000866374-19-000003:notes:170]
Other current assets include approximately $318.5 million and $445.4 million as of December 31, 2018 and March 31, 2018, respectively, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 11 for additional information. Assets held for sale related to the China-based Multek operations previously recorded in other current assets have been removed from the condensed consolidated balance sheet as of December 31, 2018, following the execution of the divestiture during the Company's second quarter of fiscal year 2019. See note 13 for additional information.

[0000866374-19-000003:notes:171]
[same as prior period, unchanged from 0000866374-18-000013:notes:158]

[0000866374-19-000003:notes:172]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. The primary purpose of these investments is to create an ecosystem of partnerships with customers developing emerging technologies aligned to the Company's corporate strategy with bringing in future opportunities for exclusive manufacturing. As of December 31, 2018, and March 31, 2018, the Company's investments in non-consolidated companies totaled $441.4 million and $411.1 million, respectively. The equity in the earnings or losses of the Company's equity method investments was not material to the consolidated results of operations for any period presented and is included in interest and other, net. The Company is currently assessing its strategy with respect to its investment portfolio including its investment in Elementum as well as certain investment funds. As of the date of the filing of this Form 10-Q, no decisions have been made by management. Accordingly, management has not identified any impairment indicators with respect to these investments as of December 31, 2018. However, upon completion by management of its evaluations and decisions, the Company may incur impairment charges, which could be material.

[0000866374-19-000003:notes:173]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage equal to or generally greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments which the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-19-000003:notes:174]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, primarily comparable company multiples and discounted cash flow projections. For investments accounted for under cost method that do not have readily determinable fair values, the Company has elected, per ASU 2016-01, to measure them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-19-000003:notes:175]
Joint Venture with RIB Software AG

[0000866374-19-000003:notes:176]
During the third quarter of fiscal year 2019, the Company sold its non-controlling interest in the joint venture with RIB Software AG, a provider of technology for the construction industry, to its former joint venture partner, for a total consideration of approximately $48.4 million. The Company recognized an immaterial gain on sale, which is recorded in other charges (income), net on the condensed consolidated statement of operations for the three and nine-month periods ended December 31, 2018. The cash inflows received as part of the selling consideration have been included in cash flows from other investing activities during the nine-month period ended December 31, 2018.

[0000866374-19-000003:notes:177]
Investment in Unrelated Third-party Company

[0000866374-19-000003:notes:178]
During the three-month period ended December 31, 2018, the Company noted, as part of the evaluation of its investment portfolio, a significant deterioration in a certain investee's performance and near-term projections. Additionally, the Company identified certain risks around that investee's capability to acquire additional funding to support its operation in the near term. The Company considered these noted facts as triggering events for impairment evaluations, and as a result recognized a $70.1 million impairment charge, during the three and nine-month periods ended December 31, 2018, which is included in other charges (income), net on the condensed consolidated statement of operations. The remaining carrying value of this investment at December 31, 2018 was immaterial, and was determined using a discounted cash flow approach which relied on inputs that would be considered Level 3 inputs in the fair value hierarchy.

[0000866374-19-000003:notes:179]
Bright Machines (formerly known as AutoLab AI)

[0000866374-19-000003:notes:180]
During the first quarter of fiscal year 2019, the Company transferred existing employees and equipment with a net book value of approximately $40 million along with certain related software and Intellectual Property ("IP"), into the newly created Bright Machines, in exchange for shares of preferred stock and a controlling financial interest in Bright Machines. Bright Machines is a privately held software-as-a service (SaaS) and hardware company focused on developing and deploying an automation solution worldwide. The Company has concluded that Bright Machines does not qualify as a variable interest entity for purposes of evaluating whether it has a controlling financial interest.

[0000866374-19-000003:notes:181]
Subsequent to the initial formation and prior to June 29, 2018, Bright Machines received equity funding from third party investors and expanded the board of directors, resulting in dilution of the Company's voting interest below 50%. As a result, the Company concluded it no longer held a controlling financial interest in Bright Machines and accordingly, deconsolidated the entity.

[0000866374-19-000003:notes:182]
The fair value of the Company’s non-controlling interest in Bright Machines upon deconsolidation was approximately $127.6 million as of the date of deconsolidation. The Company accounts for its investment in Bright Machines under the equity method, with the carrying amount included in other assets on the condensed consolidated balance sheet. The value of the Company’s interest on the date of deconsolidation was based on management’s estimate of the fair value of Bright Machines at that time. Management relied on a multi-stage process which involved calculating the enterprise and equity value of Bright Machines, then allocating the equity value of the entity to the Company’s securities. The enterprise value of Bright Machines was estimated based on the value implied by the equity funding Bright Machines received from third parties in the same period (i.e., level 2 inputs). The Company recognized a gain on deconsolidation of approximately $87.3 million with no material tax impact, which is included in other charges (income), net on the condensed consolidated statement of operations.

[0000866374-19-000003:notes:183]
In addition, during the first quarter of fiscal year 2019, the Company leased approximately $76.5 million of fixed assets to Bright Machines under a five-year lease term based on an interest rate of 4.20% per year. The leases were concluded to be sales-type leases and as such, the Company derecognized the associated assets from property and equipment, net and recorded a total net investment in the lease of $88.2 million in other current assets and other assets, based on the present value of lease receivables. The Company recorded an immaterial gain related to this leasing transaction, which is included in cost of sales on the condensed consolidated statement of operations.

[0000866374-19-000003:notes:184]
Pro-forma financials have not been presented because the effects were not material to the Company’s condensed consolidated financial position and results of operation for all periods presented. Bright Machines became a related party to the Company starting on the date of deconsolidation. The Company has engaged Bright Machines as a strategic partner to develop and deploy automation solutions for Flex and has entered into a 5-year subscription agreement. Subscription fees under the Bright Machines agreement were immaterial for the nine-month period ended December 31, 2018.

[0000866374-19-000003:notes:185]
[same as prior period, unchanged from 0000866374-18-000013:notes:169]

[0000866374-19-000003:notes:186]
Other current liabilities include customer working capital advances of $235.9 million and $153.6 million, customer-related accruals of $300.5 million and $439.0 million, and deferred revenue of $308.0 million and $329.0 million as of December 31, 2018 and March 31, 2018, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Liabilities held for sale related to the China-based Multek operations previously recorded in other current liabilities have been removed from the condensed consolidated balance sheet as of December 31, 2018, following the execution of the divestiture. See note 13 for additional information.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-19-000003:notes:187]
[same as prior period, unchanged from 0000866374-18-000013:notes:171]

[0000866374-19-000003:notes:188]
[same as prior period, unchanged from 0000866374-18-000013:notes:172]

[0000866374-19-000003:notes:189]
[same as prior period, unchanged from 0000866374-18-000013:notes:173]

[0000866374-19-000003:notes:190]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables, which are included in other current assets as of December 31, 2018 and March 31, 2018, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-19-000003:notes:191]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $900.0 million for the Global Program, of which $725.0 million is committed and $175.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-19-000003:notes:192]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and nine-month periods ended December 31, 2018, and December 31, 2017 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-19-000003:notes:193]
[same as prior period, unchanged from 0000866374-18-000013:notes:177]

[0000866374-19-000003:notes:194]
As of December 31, 2018, and March 31, 2018, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company during the nine-month periods ended December 31, 2018 and December 31, 2017 were included as cash provided by operating activities in the condensed consolidated statements of cash flows. The Company recognizes these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles the Company to certain collections on the receivable. The Company recognizes the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows as cash collections of deferred purchase price.

[0000866374-19-000003:notes:195]
As of December 31, 2018, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $929.5 million and deferred purchase price receivables of $318.5 million. As of March 31, 2018, approximately $1.5 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $1.1 billion and deferred purchase price receivables of $445.4 million. The deferred purchase price balances as of December 31, 2018 and March 31, 2018, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-19-000003:notes:196]
For the nine-month periods ended December 31, 2018 and December 31, 2017, cash flows from sales of receivables under the ABS Programs consisted of approximately $5.2 billion and $5.9 billion, respectively, for transfers of receivables, and approximately $2.7 billion and $3.5 billion, respectively, for collection on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-19-000003:notes:197]
[same as prior period, unchanged from 0000866374-18-000013:notes:181]

[0000866374-19-000003:notes:198]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $521.0 million and $286.4 million as of December 31, 2018 and March 31, 2018, respectively. For the nine-month periods ended December 31, 2018 and December 31, 2017, total accounts receivable sold to certain third-party banking institutions was approximately $2.1 billion and $1.0 billion, respectively, primarily due to certain customers transferring from the ABS Programs to the Trade Account Receivable Sale Program. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-19-000003:notes:199]
[same as prior period, unchanged from 0000866374-18-000013:notes:183]

[0000866374-19-000003:notes:200]
During the three-month and nine-month periods ended December 31, 2018, the Company repurchased 6.7 million shares at an aggregate purchase price of $64.0 million, and 11.2 million shares at an aggregate purchase price of $124.0 million, respectively, and retired all of these shares.

[0000866374-19-000003:notes:201]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 16, 2018. As of December 31, 2018, shares in the aggregate amount of $389.5 million were available to be repurchased under the current plan.
