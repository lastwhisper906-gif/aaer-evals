# FLEX 10-Q controls and the auditor's report


## item_4_controls

[0000866374-19-000003:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000866374-19-000003:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0000866374-19-000003:item_4_controls:3]
The Company's management, with the participation of the acting Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) as of December 31, 2018. Based on that evaluation, the Company's acting Chief Executive Officer and Chief Financial Officer concluded that, as of December 31, 2018, the Company's disclosure controls and procedures were not effective, as a result of the material weaknesses described in Part II, “Item 9A. Controls and Procedures” in our Annual Report on Form 10-K for the year ended March 31, 2018, in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Securities Exchange Act of 1934, as amended, is (i) recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000866374-19-000003:item_4_controls:4]
(b) Additional Analysis, Procedures and Remediation Efforts

[0000866374-19-000003:item_4_controls:5]
We have undertaken, and will continue to undertake, steps to improve our internal control over financial reporting to address and remediate the material weaknesses identified by management and described in greater detail in Part II, “Item 9A. Controls and Procedures” in our Annual Report on Form 10-K for the year ended March 31, 2018. Our remediation initiatives include:

[0000866374-19-000003:item_4_controls:6]
| • | Designing and implementing additional site level controls related to accounting for customer contractual obligations including criteria for effective contract reviews and approvals and documentation to evidence judgments and estimates. |

[0000866374-19-000003:item_4_controls:7]
| • | Designing and implementing a centralized Contract Management Office to determine the appropriate accounting and provide evidence of review for each material contract. |

[0000866374-19-000003:item_4_controls:8]
| • | Designing and implementing systematic centralized reporting controls that provide enhanced visibility to the accounting for customer contracts, which improve monitoring controls that are designed to prevent or detect material errors and help ensure that proper oversight is being provided related to certain decentralized activities. |

[0000866374-19-000003:item_4_controls:9]
| • | Enhancing the quality and frequency of training across all levels to improve awareness of Company policies and knowledge of the expected standards of conduct. |

[0000866374-19-000003:item_4_controls:10]
While these remediation plans are being executed, the Company has also engaged and will continue to engage additional external resources to support and supplement the Company’s existing internal resources. Many of our remediation efforts have been implemented or are in the process of implementation. Although we intend to complete the remediation process with respect to these material weaknesses as quickly as possible, we cannot at this time estimate how long full remediation will take. The actions that we are taking to remediate these material weaknesses are subject to ongoing review by management, as well as Audit Committee oversight.

[0000866374-19-000003:item_4_controls:11]
The material weaknesses in our internal control over financial reporting will not be considered remediated until the remediated controls operate for a sufficient period and management has concluded, through testing, that these controls are operating effectively. We are working to have the material weaknesses remediated as soon as possible. As we continue to evaluate and improve our internal control over financial reporting, we may take additional measures to address control deficiencies in the areas affected by the material weaknesses or modify or change the proposed remediation measures described above and in our Annual Report on Form 10-K for the year ended March 31, 2018. Accordingly, until these weaknesses are remediated, we plan to perform additional analysis and other procedures to ensure that our condensed consolidated financial statements are prepared in accordance with GAAP.

[0000866374-19-000003:item_4_controls:12]
(c) Changes in Internal Control Over Financial Reporting

[0000866374-19-000003:item_4_controls:13]
Other than the material weaknesses remediation efforts that we have undertaken to date, there were no changes in our internal control over financial reporting that occurred during our third quarter of fiscal year 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-19-000003:item_4_controls:14]
42
