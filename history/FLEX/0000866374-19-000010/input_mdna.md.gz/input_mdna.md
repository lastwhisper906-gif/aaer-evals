# FLEX MD&A — 0000866374-19-000010


## mdna

[0000866374-19-000010:mdna:1]
[same as prior period, unchanged from 0000866374-19-000003:mdna:1]

[0000866374-19-000010:mdna:2]
[same as prior period, unchanged from 0000866374-19-000003:mdna:2]

[0000866374-19-000010:mdna:3]
[same as prior period, unchanged from 0000866374-19-000003:mdna:5]

[0000866374-19-000010:mdna:4]
[same as prior period, unchanged from 0000866374-19-000003:mdna:6]

[0000866374-19-000010:mdna:5]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient |

[0000866374-19-000010:mdna:6]
30

[0000866374-19-000010:mdna:7]
mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies;

[0000866374-19-000010:mdna:8]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-19-000010:mdna:9]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-19-000010:mdna:10]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-19-000010:mdna:11]
[same as prior period, unchanged from 0000866374-19-000003:mdna:11]

[0000866374-19-000010:mdna:12]
[same as prior period, unchanged from 0000866374-19-000003:mdna:12]

[0000866374-19-000010:mdna:13]
[same as prior period, unchanged from 0000866374-19-000003:mdna:13]

[0000866374-19-000010:mdna:14]
During the past several years, we have evolved our long-term portfolio towards a mix of businesses which possess longer product life cycles and higher segment operating margins such as reflected in our IEI and HRS businesses. We have expanded our design and engineering relationships through our product innovation centers and global design centers.

[0000866374-19-000010:mdna:15]
During fiscal year 2019, we took focused actions to optimize our portfolio, most notably within CTG. During the first quarter of fiscal year 2020, as a result of recent geopolitical developments and uncertainties, primarily impacting one customer in China, we have seen a reduction in demand for products assembled for that customer. Due to these circumstances, we have decided to accelerate our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. We recognized $56 million of charges during the first quarter of fiscal year 2020, comprised of approximately $31 million of cash charges predominantly for employee severance, and $25 million of non-cash charges related to impairment of equipment and inventory.

[0000866374-19-000010:mdna:16]
We expect to incur additional restructuring and other charges throughout fiscal year 2020 currently estimated in the range of $145 million to $265 million. The Company expects to complete these activities during fiscal year 2020.

[0000866374-19-000010:mdna:17]
We believe that our continued business transformation is strategically positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-19-000010:mdna:18]
[same as prior period, unchanged from 0000866374-19-000003:mdna:3]

[0000866374-19-000010:mdna:19]
We are one of the world's largest providers of global supply chain solutions, with revenues of $6.2 billion for the three-month period ended June 28, 2019 and $26.2 billion in fiscal year 2019. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-19-000010:mdna:20]
|  | Three-Month Periods Ended |
| Net sales: | June 28, 2019 |  | June 29, 2018 |
|  | (In millions) |
| China | $ | 1,450 |  |  | 23 | % |  | $ | 1,669 |  |  | 26 | % |
| Mexico | 1,079 |  |  | 17 | % |  | 1,111 |  |  | 17 | % |
| U.S. | 804 |  |  | 13 | % |  | 635 |  |  | 10 | % |
| Brazil | 555 |  |  | 9 | % |  | 587 |  |  | 9 | % |
| India | 488 |  |  | 8 | % |  | 464 |  |  | 7 | % |
| Malaysia | 427 |  |  | 7 | % |  | 468 |  |  | 7 | % |
| Other | 1,373 |  |  | 23 | % |  | 1,465 |  |  | 24 | % |
|  | $ | 6,176 |  |  |  |  |  | $ | 6,399 |  |  |  |  |

[0000866374-19-000010:mdna:21]
Amounts may not sum due to rounding.

[0000866374-19-000010:mdna:22]
As previously disclosed, we have made certain immaterial corrections to net sales previously reported for the first quarter of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month period ended June 29, 2018 are $25 million lower than previously reported for the first quarter of fiscal year 2019. These corrections had no impact on gross profit, segment income or net income for the period presented.

[0000866374-19-000010:mdna:23]
|  | As of |  | As of |
| Property and equipment, net: | June 28, 2019 |  | March 31, 2019 |
|  | (In millions) |
| Mexico | $ | 542 |  |  | 23 | % |  | $ | 537 |  |  | 23 | % |
| China | 493 |  |  | 21 | % |  | 523 |  |  | 22 | % |
| U.S. | 383 |  |  | 17 | % |  | 361 |  |  | 15 | % |
| India | 225 |  |  | 10 | % |  | 219 |  |  | 9 | % |
| Malaysia | 131 |  |  | 6 | % |  | 138 |  |  | 6 | % |
| Hungary | 101 |  |  | 4 | % |  | 103 |  |  | 4 | % |
| Other | 435 |  |  | 19 | % |  | 454 |  |  | 21 | % |
|  | $ | 2,310 |  |  |  |  |  | $ | 2,336 |  |  |  |  |

[0000866374-19-000010:mdna:24]
Amounts may not sum due to rounding.

[0000866374-19-000010:mdna:25]
We believe that the combination of our design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing consumer and enterprise products for leading multinational and regional customers.

[0000866374-19-000010:mdna:26]
[same as prior period, unchanged from 0000866374-19-000003:mdna:24]

[0000866374-19-000010:mdna:27]
[same as prior period, unchanged from 0000866374-19-000003:mdna:25]

[0000866374-19-000010:mdna:28]
| • | the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, shortages of components and other factors; |

[0000866374-19-000010:mdna:29]
[same as prior period, unchanged from 0000866374-19-000003:mdna:28]

[0000866374-19-000010:mdna:30]
[same as prior period, unchanged from 0000866374-19-000003:mdna:29]

[0000866374-19-000010:mdna:31]
| • | the effects on our business due to certain customers’ products having short product life cycles; |

[0000866374-19-000010:mdna:32]
[same as prior period, unchanged from 0000866374-19-000003:mdna:31]

[0000866374-19-000010:mdna:33]
| • | our customers’ decisions to choose internal manufacturing instead of outsourcing for their product requirements; |

[0000866374-19-000010:mdna:34]
[same as prior period, unchanged from 0000866374-19-000003:mdna:33]

[0000866374-19-000010:mdna:35]
[same as prior period, unchanged from 0000866374-19-000003:mdna:34]

[0000866374-19-000010:mdna:36]
[same as prior period, unchanged from 0000866374-19-000003:mdna:35]

[0000866374-19-000010:mdna:37]
[same as prior period, unchanged from 0000866374-19-000003:mdna:37]

[0000866374-19-000010:mdna:38]
[same as prior period, unchanged from 0000866374-19-000003:mdna:38]

[0000866374-19-000010:mdna:39]
[same as prior period, unchanged from 0000866374-19-000003:mdna:39]

[0000866374-19-000010:mdna:40]
[same as prior period, unchanged from 0000866374-19-000003:mdna:40]

[0000866374-19-000010:mdna:41]
[same as prior period, unchanged from 0000866374-19-000003:mdna:41]

[0000866374-19-000010:mdna:42]
Refer to the accounting policies under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019, where we discuss our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 842, as discussed below.

[0000866374-19-000010:mdna:43]
Leases

[0000866374-19-000010:mdna:44]
We are a lessee with several noncancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. We determine if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the customer has the right to control the use of the identified asset.

[0000866374-19-000010:mdna:45]
Beginning with the adoption of ASC 842 on April 1, 2019, we recognize a right-of-use (“ROU”) asset and a lease liability at the lease commencement date for our operating leases. For operating leases, the lease liability is initially and subsequently measured at the present value of the unpaid lease payments at the lease commencement date. We have elected the short term lease recognition and measurement exemption for all classes of assets, which allows us to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option we are reasonably certain of exercising. We have also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As we cannot determine the interest rate implicit in the lease for our leases, as such we use our estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. Our estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of our leases includes the noncancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that we are reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-19-000010:mdna:46]
[same as prior period, unchanged from 0000866374-19-000003:mdna:50]

[0000866374-19-000010:mdna:47]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales. The financial information and the discussion below should be read together with the condensed consolidated financial statements and notes thereto included in this document. In addition, reference should be made to our audited consolidated financial statements and notes thereto and related Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our 2019 Annual Report on Form 10-K.

[0000866374-19-000010:mdna:48]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.5 |  |  | 94.1 |  |
| Restructuring charges | 0.8 |  |  | 0.0 |  |
| Gross profit | 5.7 |  |  | 5.9 |  |
| Selling, general and administrative expenses | 3.4 |  |  | 4.1 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.1 |  |  | 0.0 |  |
| Interest and other, net | 0.9 |  |  | 0.6 |  |
| Other charges (income), net | 0.0 |  |  | (1.4 | ) |
| Income before income taxes | 1.0 |  |  | 2.3 |  |
| Provision for income taxes | 0.3 |  |  | 0.4 |  |
| Net income | 0.7 | % |  | 1.9 | % |

[0000866374-19-000010:mdna:49]
[same as prior period, unchanged from 0000866374-19-000003:mdna:53]

[0000866374-19-000010:mdna:50]
The following table sets forth our net sales by segment and their relative percentages:

[0000866374-19-000010:mdna:51]
|  | Three-Month Periods Ended |
| Segments: | June 28, 2019 |  | June 29, 2018 |
|  | (In millions) |
| High Reliability Solutions | $ | 1,178 |  |  | 19 | % |  | $ | 1,215 |  |  | 19 | % |
| Industrial & Emerging Industries | 1,637 |  |  | 27 | % |  | 1,446 |  |  | 23 | % |
| Communications & Enterprise Compute | 1,859 |  |  | 30 | % |  | 1,954 |  |  | 31 | % |
| Consumer Technologies Group | 1,502 |  |  | 24 | % |  | 1,783 |  |  | 27 | % |
|  | $ | 6,176 |  |  |  |  | $ | 6,399 |  |  |  |

[0000866374-19-000010:mdna:52]
Amounts may not sum due to rounding.

[0000866374-19-000010:mdna:53]
Net sales during the three-month period ended June 28, 2019 totaled $6.2 billion, representing a decrease of approximately $223 million, or 3% from $6.4 billion during the three-month period ended June 29, 2018. The decrease in sales was driven by softness across our segments with the exception of our IEI segment. Our CTG segment decreased $281 million, primarily resulting from our continued active pruning of underperforming customers and product categories coupled with lower demand with legacy customer sector. Our CEC segment decreased $95 million, driven by reduced demand in our networking and telecommunication business. Our HRS segment decreased $37 million primarily due to market softness, most notably in China, in our automotive businesses offset by strengthening demand in our health solutions business. These declines were offset by a $191 million increase in our IEI segment, mainly driven by strong sales within our industrial, home and lifestyle business in addition to growth in our solar energy business that more than offset declines in capital equipment demand. Net sales decreased $295 million to $2.6 billion in Asia, $40 million to $1.1 billion in Europe, offset by a modest increase of $112 million to $2.5 billion in the Americas.

[0000866374-19-000010:mdna:54]
Our ten largest customers, during the three-month periods ended June 28, 2019 and June 29, 2018, accounted for approximately 42% and 44% of net sales, respectively. No customer accounted for more than 10% of net sales during the three-month periods ended June 28, 2019 or June 29, 2018.

[0000866374-19-000010:mdna:55]
[same as prior period, unchanged from 0000866374-19-000003:mdna:59]

[0000866374-19-000010:mdna:56]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead

[0000866374-19-000010:mdna:57]
absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-19-000010:mdna:58]
Gross profit during the three-month period ended June 28, 2019 decreased $25 million to $353 million, or 5.7% of net sales, from $378 million, or 5.9% of net sales, during the three-month period ended June 29, 2018. Gross margin deteriorated 20 basis points during the three-month ended June 28, 2019. The decrease in both gross profit and gross margin is primarily due to the geopolitical challenges and uncertainties which impacted specific customers coupled with restructuring charges recorded in the current quarter offset by the favorable product mix and the increased revenues from our IEI segment, the wind-down of our NIKE Mexico operations in the second half of fiscal year 2019, and benefits realized from our restructuring activities initiated in fiscal year 2019.

[0000866374-19-000010:mdna:59]
[same as prior period, unchanged from 0000866374-19-000003:mdna:64]

[0000866374-19-000010:mdna:60]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.  A portion of depreciation is allocated to the respective segment, together with other general corporate research and development and administrative expenses.

[0000866374-19-000010:mdna:61]
[same as prior period, unchanged from 0000866374-19-000003:mdna:66]

[0000866374-19-000010:mdna:62]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In millions) |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| High Reliability Solutions | $ | 87 |  |  | 7.4 | % |  | $ | 94 |  |  | 7.7 | % |
| Industrial & Emerging Industries | 95 |  |  | 5.8 | % |  | 51 |  |  | 3.6 | % |
| Communications & Enterprise Compute | 26 |  |  | 1.4 | % |  | $ | 46 |  |  | 2.4 | % |
| Consumer Technologies Group | 30 |  |  | 2.0 | % |  | 27 |  |  | 1.5 | % |
| Corporate and Other | (31 | ) |  |  |  | (30 | ) |  |  |
| Total segment income | 208 |  |  | 3.4 | % |  | 188 |  |  | 2.9 | % |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 17 |  |  |  |  | 19 |  |  |  |
| Stock-based compensation | 15 |  |  |  |  | 21 |  |  |  |
| Customer related asset impairments (1) | — |  |  |  |  | 17 |  |  |  |
| Restructuring charges (Note 17) | 56 |  |  |  |  | 9 |  |  |  |
| New revenue standard adoption impact (Note 4) | — |  |  |  |  | 9 |  |  |  |
| Legal and other (2) | 2 |  |  |  |  | 16 |  |  |  |
| Interest and other, net | 52 |  |  |  |  | 42 |  |  |  |
| Other charges (income), net (Note 9) | 1 |  |  |  |  | (87 | ) |  |  |
| Income (loss) before income taxes | $ | 64 |  |  |  |  | $ | 142 |  |  |  |
| Amounts may not sum due to rounding. |  |  |  |  |  |  |  |

[0000866374-19-000010:mdna:63]
| (1) | Customer related asset impairments for the three-month period ended June 29, 2018 primarily relate to additional provision for doubtful accounts receivable, and excess and obsolete inventory for certain customers experiencing significant financial difficulties and/or we are disengaging from. |

[0000866374-19-000010:mdna:64]
| (2) | Legal and other during the three-month period ended June 29, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges not directly related to ongoing or core business. |

[0000866374-19-000010:mdna:65]
HRS segment margin decreased 30 basis points, to 7.4% for the three-month period ended June 28, 2019, from 7.7% during the three-month period ended June 29, 2018 primarily due to an unfavorable mix resulting from automotive demand softness, most notably in China, which directly impacted our largest automotive customers.

[0000866374-19-000010:mdna:66]
IEI segment margin increased 220 basis points, to 5.8% for the three-month period ended June 28, 2019, from 3.6% during the three-month period ended June 29, 2018 mainly due to a favorable mix resulting from operational execution on the new business that is ramping particularly in Energy and Home & Lifestyle and from greater levels of design and engineering led engagements.

[0000866374-19-000010:mdna:67]
CEC segment margin decreased 100 basis points, to 1.4% for the three-month period ended June 28, 2019, from 2.4% during the three-month period ended June 29, 2018 primarily due to geopolitical challenges and uncertainties which impacted demand from specific customers and created elevated levels of unabsorbed manufacturing overhead costs.

[0000866374-19-000010:mdna:68]
CTG segment margin increased 50 basis points to 2.0% for the three-month period ended June 28, 2019, from 1.5% during the three-month period ended June 29, 2018. The increase in CTG's margin during the period reflected lesser losses from our former strategic partnership with NIKE versus the three-month period ended June 29, 2018 and mix improvements as we continued to rationalize and prune underperforming accounts to improve the portfolio.

[0000866374-19-000010:mdna:69]
[same as prior period, unchanged from 0000866374-19-000003:mdna:76]

[0000866374-19-000010:mdna:70]
During fiscal year 2019, we took focused actions to optimize our portfolio, most notably within CTG. During the first quarter of fiscal year 2020, as a result of recent geopolitical developments and uncertainties, primarily impacting one customer in China, we have seen a reduction in demand for products assembled for that customer. Due to these circumstances, we have decided to accelerate our strategic decision to reduce our exposure to certain high-volatility products in both China and India. We also initiated targeted activities to restructure our business to further reduce and streamline our cost structure. We recognized $56 million of charges during the first quarter of fiscal year 2020, comprised of approximately $31 million of cash charges predominantly for employee severance, and $25 million of non-cash charges related to impairment of equipment and inventory.

[0000866374-19-000010:mdna:71]
We expect to incur additional restructuring and other charges throughout fiscal year 2020 currently estimated in the range of  $145 million to $265 million. The Company expects to complete these activities during fiscal year 2020.

[0000866374-19-000010:mdna:72]
There were no material restructuring charges incurred during the three-month period ended June 29, 2018.

[0000866374-19-000010:mdna:73]
[same as prior period, unchanged from 0000866374-19-000003:mdna:80]

[0000866374-19-000010:mdna:74]
Selling, general and administrative expenses (“SG&A”) was $210 million, or 3.4% of net sales, during the three-month period ended June 28, 2019, decreasing $53 million from $263 million, or 4.1% of net sales, during the three-month period ended June 29, 2018. This decrease was primarily due to strong cost discipline focused on driving further productivity improvements and a refined cost structure benefiting from prior restructuring initiatives.

[0000866374-19-000010:mdna:75]
[same as prior period, unchanged from 0000866374-19-000003:mdna:82]

[0000866374-19-000010:mdna:76]
Amortization of intangible assets marginally declined during the three-month period ended June 28, 2019 to $17 million, from $19 million for the three-month period ended June 29, 2018 primarily due to certain intangibles now being fully amortized.

[0000866374-19-000010:mdna:77]
[same as prior period, unchanged from 0000866374-19-000003:mdna:84]

[0000866374-19-000010:mdna:78]
Interest and other, net was $52 million during the three-month period ended June 28, 2019 compared to $42 million during the three-month period ended June 29, 2018. The increase in interest and other, net was primarily a result of higher expenses from our asset-backed securitization programs, coupled with incremental interest expenses from our new borrowings.

[0000866374-19-000010:mdna:79]
[same as prior period, unchanged from 0000866374-19-000003:mdna:86]

[0000866374-19-000010:mdna:80]
Other charges (income), net was $1 million of net expense during the three-month period ended June 28, 2019 compared to $87 million of income during the three-month period ended June 29, 2018, primarily a result of the non-cash gain from the deconsolidation of Bright Machines recognized in fiscal year 2019

[0000866374-19-000010:mdna:81]
[same as prior period, unchanged from 0000866374-19-000003:mdna:89]

[0000866374-19-000010:mdna:82]
Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. Refer to note 13, “Income Taxes” of the notes to the consolidated financial statements in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019 for further discussion.

[0000866374-19-000010:mdna:83]
[same as prior period, unchanged from 0000866374-19-000003:mdna:91]

[0000866374-19-000010:mdna:84]
The consolidated effective tax rate was 30% and 18% for the three-month periods ended June 28, 2019 and June 29, 2018. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, Costa Rica, India, the Netherlands and Israel. The effective tax rate for the three-month period ended June 28, 2019 is higher than the effective tax rate for the three-month period ended June 29, 2018, due to a changing jurisdictional mix of income, and our recognition of approximately $56 million in restructuring charges, with minimal associated tax benefits.

[0000866374-19-000010:mdna:85]
[same as prior period, unchanged from 0000866374-19-000003:mdna:93]

[0000866374-19-000010:mdna:86]
As of June 28, 2019, we had cash and cash equivalents of approximately $1.9 billion and bank and other borrowings of approximately $3.2 billion. We have a $1.75 billion revolving credit facility that expires in June 2022, under which there were no borrowings outstanding as of the end of the quarter. We also entered into a JPY 33.525 billion term loan due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars, as well as issued $450 million of 4.875% Notes in June 2019. Part of the proceeds obtained were used to repay $250 million of our existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. Refer to note 7 to the condensed consolidated financial statement for details. As of June 28, 2019, we were in compliance with the covenants under all of our credit facilities and indentures.

[0000866374-19-000010:mdna:87]
Cash used in operating activities was $0.7 billion during the three-month period ended June 28, 2019, primarily driven by cash outflows related to accounts receivable. Cash collections from the deferred purchase price on our ABS sales program of $0.9 billion are now included in cash from investing activities. This was partially offset by $45 million of net income for the period plus $192 million of non-cash charges such as depreciation, amortization, restructuring and impairment charges, and stock-based compensation.

[0000866374-19-000010:mdna:88]
We believe net working capital and net working capital as a percentage of annualized net sales are key metrics that measure our liquidity. Net working capital position was calculated as current quarter accounts receivable, net of allowance for doubtful accounts, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, plus inventories and contract assets, less accounts payable and certain other current liabilities related to vendor financing programs. Net working capital slightly increased $7 million as of June 28, 2019, from $1.7 billion as of March 31, 2019. This increase is primarily driven by a $23 million increase in our inventory levels from March 31, 2019 and a $24 million increase in contract assets, offset by an approximately $46 million increase in accounts payable. Our current quarter net working capital as a percentage of annualized net sales for the quarter ended June 28, 2019, increased slightly to 6.8% from 6.7% of annualized net sales for the quarter ended March 31, 2019. We generally operate in a net working capital targeted range between 6% to 8% of annualized revenue for the quarter.

[0000866374-19-000010:mdna:89]
Cash provided by investing activities was $0.8 billion during the three-month period ended June 28, 2019. This was primarily driven by $0.9 billion of cash collections on deferred purchase price from our ABS programs during the three-month period ended June 28, 2019, offset by approximately $123 million of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our expanding IEI and HRS businesses.

[0000866374-19-000010:mdna:90]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is defined as cash from operations, plus cash collections of deferred purchase price, less net purchases of property and equipment to present cash flows on a consistent basis for investor transparency. We also excluded the impact to cash flows related to certain vendor programs that is required for US GAAP presentation. Our free cash flows for the three-month period ended June 28, 2019 was $114 million compared to a use of $185 million for the three-month period ended June 29, 2018. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-19-000010:mdna:91]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In millions) |
| Net cash used in operating activities (1) | (657 | ) |  | $ | (943 | ) |
| Cash collection of deferred purchase price and other | 894 |  |  | 928 |  |
| Purchases of property and equipment | (162 | ) |  | (172 | ) |
| Proceeds from the disposition of property and equipment | 39 |  |  | 2 |  |
| Free cash flow | $ | 114 |  |  | $ | (185 | ) |

[0000866374-19-000010:mdna:92]
| (1) | As disclosed in the Company’s prior year filings, during the first quarter of fiscal year 2019, the Company utilized a monthly approach to track cash flows on deferred purchase price. Commencing with the quarter ended September 28, 2018, the Company changed to a method based on daily activity for both the three-month and six-month periods ended September 28, 2018. As a result, the Company has retrospectively adjusted cash flows from operating and investing activities for the three-months ended June 29, 2018 from amounts previously reported. This resulted in an increase of approximately $271 million to cash provided by investing activities, and a corresponding decrease to cash flow from operating activities on the consolidated statement of cash flows for the three-months ended June 29, 2018. |

[0000866374-19-000010:mdna:93]
Cash provided by financing activities was $106 million during the three-month period ended June 28, 2019, which was primarily driven by $448 million of proceeds, net of discount, received following the issuance of the 2029 Notes, $300 million of proceeds following the execution of our term loan agreement due April 2024 during the quarter, coupled with $23 million of proceeds from a drawdown from our India term loan facility. For further information on the 2029 Notes and the Term Loan due 2024, see note 7 to the condensed consolidated financial statements. Partially offsetting the proceeds described were i) $250 million of cash paid for the partial repurchase of our 4.625% Notes due February 2020, ii) $250 million of cash paid for the partial prepayment of the term loan due November 2021, iii) $91 million of cash paid for the outstanding balance of our short-term bank borrowings facility in India, and iv) $52 million of cash paid for the repurchase of our ordinary shares.

[0000866374-19-000010:mdna:94]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of June 28, 2019, and March 31, 2019, over half of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.6 billion as of March 31, 2019). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-19-000010:mdna:95]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volumes of customer orders.

[0000866374-19-000010:mdna:96]
We maintain global paying services agreements with several financial institutions. Under these agreements, the financial institutions act as our paying agents with respect to accounts payable due to our suppliers who elect to participate in the program. The agreements allow our suppliers to sell their receivables to one of the participating financial institutions at the discretion of both parties on terms that are negotiated between the supplier and the respective financial institution. Our obligations to our suppliers, including the amounts due and scheduled payment dates, are not impacted by our suppliers’ decisions to sell their receivables under this program. For the periods ended June 28, 2019 and June 29, 2018, the cumulative payments due to suppliers participating in the programs amounted to approximately $0.1 billion. Pursuant to their agreement with one of the financial institutions, certain suppliers may elect to be paid early at their discretion. We are not always notified when our suppliers sell receivables under these programs. The available capacity under these programs can vary based on the number of investors and/or financial institutions participating in these programs at any point in time.

[0000866374-19-000010:mdna:97]
38

[0000866374-19-000010:mdna:98]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of equity and debt securities, bank debt and lease financings. We also sell a designated pool of trade receivables under asset-backed securitization ("ABS") programs and sell certain trade receivables, which are in addition to the trade receivables sold in connection with these securitization agreements.

[0000866374-19-000010:mdna:99]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth.

[0000866374-19-000010:mdna:100]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-19-000010:mdna:101]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 16, 2018. During the three-month period ended June 28, 2019, we paid $52.0 million to repurchase shares under the current repurchase plans at an average price of $10.35 per share. As of June 28, 2019, shares in the aggregate amount of $273 million were available to be repurchased under the current plan.

[0000866374-19-000010:mdna:102]
[same as prior period, unchanged from 0000866374-19-000003:mdna:109]

[0000866374-19-000010:mdna:103]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2019.

[0000866374-19-000010:mdna:104]
During the first quarter of fiscal year 2020, we entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. In addition, we issued $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay $250 million of our existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. Refer to the discussion in note 7 to the condensed consolidated financial statements for further details on our debt obligations.

[0000866374-19-000010:mdna:105]
Other than the changes discussed above, there were no material changes in our contractual obligations and commitments since March 31, 2019.

[0000866374-19-000010:mdna:106]
[same as prior period, unchanged from 0000866374-19-000003:mdna:111]

[0000866374-19-000010:mdna:107]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of June 28, 2019, and March 31, 2019, the fair values of our deferred purchase price receivable were approximately $335 million and $293 million, respectively. As of June 28, 2019, and March 31, 2019, the outstanding balance on receivables sold for cash was $1.3 billion, respectively, under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 12 to the condensed consolidated financial statements.
