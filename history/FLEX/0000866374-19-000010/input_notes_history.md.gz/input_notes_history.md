# FLEX note change history — 0000866374-19-000003 → 0000866374-19-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-07-26):
[0000866374-19-000010:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.
  (was, 2019-02-06, similarity 0.9986):
[0000866374-19-000003:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims has been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- added (2019-07-26):
[0000866374-19-000010:note_history:2]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have

- added (2019-07-26):
[0000866374-19-000010:note_history:3]
licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

- changed (2019-07-26):
[0000866374-19-000010:note_history:4]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process.   A hearing on the motions to serve as lead plaintiff is scheduled for September 26, 2019. A case management conference is scheduled for October 9, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.
  (was, 2019-02-06, similarity 0.6527):
[0000866374-19-000003:note_history:4]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On January 8, 2019, another shareholder filed a motion to intervene in the case for the purposes of vacating the Court’s October 1, 2018 order and reopening the lead plaintiff process; that motion is set for hearing on April 4, 2019. On January 15, 2019, the Court issued an order providing that defendants need not file any motion to dismiss until after the motion to intervene is decided. In addition, the Court has set a case management conference for April 24, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

- changed (2019-07-26):
[0000866374-19-000010:note_history:5]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $93.6 million based on the exchange rate as of June 28, 2019). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2019-02-06, similarity 0.9912):
[0000866374-19-000003:note_history:5]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 346 million Brazilian reals (approximately USD $88.6 million based on the exchange rate as of December 31, 2018). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

- added (2019-07-26):
[0000866374-19-000010:note_history:6]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter. The matter is at a very preliminary stage. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

- added (2019-07-26):
[0000866374-19-000010:note_history:7]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which

- added (2019-07-26):
[0000866374-19-000010:note_history:8]
may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2019-07-26):
[0000866374-19-000003:note_history:9]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable our use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g. base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-26):
[0000866374-19-000010:note_history:10]
ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION
Organization of the Company
  (was, 2019-02-06, similarity 0.791):
[0000866374-19-000003:note_history:10]
ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION

- changed (2019-07-26):
[0000866374-19-000010:note_history:11]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scale®  services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and manages complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud and data center solutions for companies of all sizes in various industries and end-markets, through its activities in the following segments:
  (was, 2019-02-06, similarity 0.9074):
[0000866374-19-000003:note_history:11]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scaletm services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer and enterprise products, for companies of all sizes in various industries and end-markets, through its activities in the following segments:

- added (2019-07-26):
[0000866374-19-000010:note_history:12]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

- added (2019-07-26):
[0000866374-19-000010:note_history:13]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

- changed (2019-07-26):
[0000866374-19-000010:note_history:14]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |
  (was, 2019-02-06, similarity 0.7481):
[0000866374-19-000003:note_history:14]
| • | Communications & Enterprise Compute ("CEC"), which includes telecom business of radio access base stations, remote radio heads, and small cells for wireless infrastructure; networking business which includes optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions; |

- changed (2019-07-26):
[0000866374-19-000010:note_history:15]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |
  (was, 2019-02-06, similarity 0.6887):
[0000866374-19-000003:note_history:15]
| • | Consumer Technologies Group ("CTG"), which includes consumer-related businesses in connected living, audio, consumer power electronics, and mobile devices; and including various supply chain solutions for notebook personal computers, tablets, and printers; |

- changed (2019-07-26):
[0000866374-19-000010:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 28, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.
  (was, 2019-02-06, similarity 0.9891):
[0000866374-19-000003:note_history:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2018 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three and nine-month periods ended December 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019.

- added (2019-07-26):
[0000866374-19-000010:note_history:17]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively.

- changed (2019-07-26):
[0000866374-19-000010:note_history:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these
  (was, 2019-02-06, similarity 0.851):
[0000866374-19-000003:note_history:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2019-07-26):
[0000866374-19-000010:note_history:19]
companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

- added (2019-07-26):
[0000866374-19-000010:note_history:20]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first quarter of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month period ended June 29, 2018 are $25 million lower than previously reported for the first quarter of fiscal year 2019. These corrections had no impact on gross profit, segment income or net income for the period presented. Amounts presented for the first quarter of fiscal year 2019 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

- added (2019-07-26):
[0000866374-19-000010:note_history:21]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, Leases, and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

- added (2019-07-26):
[0000866374-19-000010:note_history:22]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before our adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date).As the Company cannot determine the interest rate implicit in the lease for its leases, as such the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the noncancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

- added (2019-07-26):
[0000866374-19-000010:note_history:23]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of income or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of new ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

- added (2019-07-26):
[0000866374-19-000010:note_history:24]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $705 million with a corresponding ROU asset of $669 million and a deferred gain of $22 million for sale leaseback transactions to prior year retained earnings.

- changed (2019-07-26):
[0000866374-19-000010:note_history:25]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.
  (was, 2019-02-06, similarity 0.6949):
[0000866374-19-000003:note_history:25]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- changed (2019-07-26):
[0000866374-19-000010:note_history:26]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.
  (was, 2019-02-06, similarity 0.6134):
[0000866374-19-000003:note_history:26]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- added (2019-07-26):
[0000866374-19-000010:note_history:27]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for

- added (2019-07-26):
[0000866374-19-000010:note_history:28]
nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

- changed (2019-07-26):
[0000866374-19-000010:note_history:29]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.
  (was, 2019-02-06, similarity 0.656):
[0000866374-19-000003:note_history:29]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- changed (2019-07-26):
[0000866374-19-000010:note_history:30]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.
  (was, 2019-02-06, similarity 0.6889):
[0000866374-19-000003:note_history:30]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

- changed (2019-07-26):
[0000866374-19-000010:note_history:31]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and change how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.
  (was, 2019-02-06, similarity 0.9984):
[0000866374-19-000003:note_history:31]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provides a new private company variable interest entity exemption and changes how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

- changed (2019-07-26):
[0000866374-19-000010:note_history:32]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects to early adopt the guidance, during fiscal year 2020, and does not expect a material impact to its condensed consolidated financial statements.
  (was, 2019-02-06, similarity 0.8627):
[0000866374-19-000003:note_history:32]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company is still evaluating the impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- removed (2019-07-26):
[0000866374-19-000003:note_history:33]
Organization of the Company

- removed (2019-07-26):
[0000866374-19-000003:note_history:34]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, electric vehicle infrastructure, smart solar energy, semiconductor and capital equipment, office solutions, industrial, home and lifestyle, industrial automation, and kiosks; and |

- removed (2019-07-26):
[0000866374-19-000003:note_history:35]
| • | High Reliability Solutions ("HRS"), which is comprised of health solutions business, including consumer health, digital health, medical disposables, drug delivery, and medical equipment; automotive business, including vehicle electrification, connectivity, autonomous vehicles, and smart technologies. |

- removed (2019-07-26):
[0000866374-19-000003:note_history:36]
The first quarters for fiscal years 2019 and 2018 ended on June 29, 2018, which is comprised of 90 days in the period, and June 30, 2017, which is comprised of 91 days in the period, respectively. The second quarters for fiscal years 2019 and 2018 ended on September 28, 2018 and September 29, 2017, which are comprised of 91 days in both periods. The Company's third quarters ends on December 31 of each year, which are comprised of 94 days and 93 days for fiscal years 2019 and 2018, respectively.

- removed (2019-07-26):
[0000866374-19-000003:note_history:37]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update (ASU) No. 2017-01 “Business Combinations (Topic 805): Clarifying the Definition of a Business” to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The Company adopted the guidance on a prospective basis during the first quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no acquisitions during the period of adoption.

- removed (2019-07-26):
[0000866374-19-000003:note_history:38]
In January 2017, the FASB issued ASU 2017-04 "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment" to simplify the subsequent measurement of goodwill by eliminating step 2 from the goodwill impairment test. This guidance requires that the change be applied on a prospective basis, and it is effective for the Company beginning in the first quarter of fiscal year 2021, with early application permitted. The Company adopted the guidance during the third quarter of fiscal year 2019, which did not have a material impact to its financial position as there were no identified impairments during the period.

- removed (2019-07-26):
[0000866374-19-000003:note_history:39]
In August 2016, the FASB issued ASU 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force)." The ASU is intended to address specific cash flow issues with the objective of reducing the existing diversity in practice and provide guidance on how certain cash receipts and payments are presented and classified in the statement of cash flows. The majority of the guidance in ASU 2016-15 was consistent with the Company's current cash flow classification. However, cash receipts on the deferred purchase price from the Company's asset-backed securitization programs described in note 11 are now classified as cash flows from investing activities instead of the Company's former presentation as cash flows from operations. The Company adopted the guidance during the first quarter of fiscal year 2019 using a monthly approach to track cash flows on deferred purchase price and retrospectively adjusted cash flows from operating and investing activities for fiscal year 2018. Commencing with the second quarter of fiscal year 2019, the Company changed to a method based on daily activity and the amounts presented for operating and investing activities for the nine-month period ended December 31, 2018 reflect the use of this method for the entire period. The Company recorded $2.7 billion of cash receipts on the deferred purchase price from the Company's asset-backed securitization programs for the nine-month period ended December 31, 2018 and reclassified $3.5 billion of cash receipts on the deferred purchase price for the nine-month period ended December 31, 2017, from cash flows from operating activities to cash flows from investing activities.

- removed (2019-07-26):
[0000866374-19-000003:note_history:40]
In January 2016, the FASB issued ASU 2016-01 "Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This guidance generally requires equity investments, except those accounted for under the equity method of accounting or those that result in consolidation of the investee, to be measured at fair value with changes in fair value recognized in net income. This guidance also requires the separate presentation of financial assets and financial liabilities by measurement category and form of financial asset on the balance sheet or in the accompanying notes to the financial statements. The Company adopted this guidance on April 1, 2018 with an immaterial impact on the Company's financial position, results of operations or cash flows.

- removed (2019-07-26):
[0000866374-19-000003:note_history:41]
In February 2018, the FASB issued ASU 2018-03 "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." This standard comes as an addition to ASU 2016-01 which the Company adopted in the first quarter of fiscal year 2019.  This update includes amendments to clarify certain aspects of the guidance issued in Update 2016-01. The Company adopted this guidance during the second quarter of fiscal year 2019 with an immaterial impact on its consolidated financial statements.

- removed (2019-07-26):
[0000866374-19-000003:note_history:42]
In May 2014, the FASB issued ASU 2014-09 "Revenue from Contracts with Customers (Topic 606)" (also referred to as Accounting Standard Codification 606 ("ASC 606")) which requires an entity to recognize revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the entity expects to be entitled in exchange for such goods or services. In order to meet this requirement, the entity must apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, disclosures required for revenue recognition include qualitative and quantitative information about contracts with customers, significant judgments and changes in judgments, and assets recognized from costs to obtain or fulfill a contract.

- removed (2019-07-26):
[0000866374-19-000003:note_history:43]
The Company adopted the standard on April 1, 2018 using the modified retrospective approach by applying the guidance to all open contracts at the adoption date and has implemented revised accounting policies, new operational and financial reporting processes, enhanced systems capabilities and relevant internal controls.

- removed (2019-07-26):
[0000866374-19-000003:note_history:44]
As part of adopting ASC 606, revenue for certain customer contracts where the Company is manufacturing products for which there is no alternative use and the Company has an enforceable right to payment including a reasonable profit for work-in-progress, inventory will be recognized over time (i.e., as the Company manufactures the product) instead of upon shipment of products.  In addition to the following disclosures, note 3 provides further disclosures required by the new standard.

- removed (2019-07-26):
[0000866374-19-000003:note_history:45]
The cumulative effect of change made to our April 1, 2018 consolidated balance sheet for the adoption of ASC 606 was as follows:

- removed (2019-07-26):
[0000866374-19-000003:note_history:46]
| Condensed Consolidated Balance Sheet |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | Balance at March 31, 2018 | Adjustments | Balance at April 1, 2018 |
| ASSETS |  |  |  |
| Contract assets | — |  | 412,787 |  | 412,787 |  |
| Inventories | 3,799,829 |  | (409,252 | ) | 3,390,577 |  |
| Other current assets | 1,380,466 |  | (51,479 | ) | 1,328,987 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,719,418 |  | (87,897 | ) | 1,631,521 |  |
| Other liabilities | 531,587 |  | 2,098 |  | 533,685 |  |
| Accumulated deficit | (3,144,114 | ) | (37,855 | ) | (3,181,969 | ) |

- removed (2019-07-26):
[0000866374-19-000003:note_history:47]
The adoption of ASC 606 resulted in the establishment of contract asset and contract liability balance sheet accounts and in the reclassification to these new accounts from certain asset and liability accounts, primarily inventories. The increase in accumulated deficit in the table above reflects $37.9 million of net adjustments to the balance sheet as of April 1, 2018, resulting from the adoption of ASC 606 primarily related to certain customer contracts requiring an over-time method of revenue recognition. The declines in inventories and other current assets reflect reclassifications to contract assets due to the earlier recognition of certain costs of products sold for over-time contracts. The decline in other current liabilities is primarily due to the reclassification of payments from customers in advance of work performed to contract assets to reflect the net position of the related over-time contracts.

- removed (2019-07-26):
[0000866374-19-000003:note_history:48]
The following tables summarize the impacts of ASC 606 adoption on the Company’s condensed consolidated balance sheets and condensed consolidated statements of operations:

- removed (2019-07-26):
[0000866374-19-000003:note_history:49]
| Condensed Consolidated Balance Sheet |  |  |  |
| As of December 31, 2018 |  |  |  |
|  | Impact of Adopting ASC 606 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |
| ASSETS |  |  |  |
| Contract assets | 298,451 |  | (298,451 | ) | — |  |
| Inventories | 3,897,891 |  | 315,780 |  | 4,213,671 |  |
| Other current assets | 930,376 |  | 10,044 |  | 940,420 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |
| Other current liabilities | 1,527,276 |  | 51,294 |  | 1,578,570 |  |
| Accumulated deficit | (2,947,661 | ) | (36,498 | ) | (2,984,159 | ) |

- removed (2019-07-26):
[0000866374-19-000003:note_history:50]
| Condensed Consolidated Statement of Operations |  |  |  |  |  |  |  |
|  | Impact of Adopting ASC 606 |
|  | Three-Month Period Ended December 31, 2018 |  | Nine-Month Period Ended December 31, 2018 |
| (In thousands)(Unaudited) | As Reported | Adjustments | Balance without ASC 606 Adoption |  | As Reported | Adjustments | Balance without ASC 606 Adoption |
| Net sales | $ | 6,944,827 |  | $ | (4,885 | ) | $ | 6,939,942 |  |  | $ | 20,079,387 |  | $ | (32,122 | ) | $ | 20,047,265 |  |
| Cost of sales | 6,587,502 |  | (6,907 | ) | 6,580,595 |  |  | 18,941,907 |  | (33,479 | ) | 18,908,428 |  |
| Gross profit | 357,325 |  | 2,022 |  | 359,347 |  |  | 1,137,480 |  | 1,357 |  | 1,138,837 |  |

- removed (2019-07-26):
[0000866374-19-000003:note_history:51]
To align contractual terms across the vast majority of customers to allow the Company to efficiently and accurately manage its contracts, in the first quarter of fiscal year 2019, the Company waived certain contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. These modifications resulted in revenue from these customers being recognized upon shipment of products, rather than over time (i.e., as the Company manufactures products) as further explained in note 3. The result of the modifications for the nine-month period ended December 31, 2018, was to reduce revenue and gross profit by approximately $132.7 million and $9.3 million, respectively, compared to amounts that would have been reported both (i) under ASC 606 had the Company not amended the contracts, and (ii) had the Company not adopted ASC 606.

- removed (2019-07-26):
[0000866374-19-000003:note_history:52]
The impacts to revenue and gross profit as a result of the adoption of ASC 606 are driven by a number of factors including the timing of inventory levels for over time ("OT") customers at the end of each reporting period and the mix of customer profitability. These impacts were not material for the three-month period ended December 31, 2018.

- removed (2019-07-26):
[0000866374-19-000003:note_history:53]
For the nine-month period ended December 31, 2018 the as reported revenue was approximately $32.1 million higher and the gross profit approximately $1.4 million lower than it would have been without the adoption of ASC 606. Additional revenue of $164.8 million was reported under ASC 606 due to the accelerated timing of recognition of revenue for contracts which meet the criteria for over-time recognition and revenue recognized for certain contracts that no longer qualify for net revenue treatment. Approximately $7.9 million of additional gross profit was recognized on the customers qualifying for accelerated revenue recognition. These increases were offset by reductions of $132.7 million of revenue and $9.3 million of gross profit respectively, as a result of the waiver of contract rights noted above. There was no material tax impact for the three and nine-month periods ended December 31, 2018 from the adoption of ASC 606.

- removed (2019-07-26):
[0000866374-19-000003:note_history:54]
The Company applies the following practical expedients:

- removed (2019-07-26):
[0000866374-19-000003:note_history:55]
| • | The Company elected to not disclose information about remaining performance obligations as its performance obligations generally have an expected duration of one year or less. |

- removed (2019-07-26):
[0000866374-19-000003:note_history:56]
| • | In accordance with ASC 606-10-25-18B the Company will account for certain shipping and handling as activities to fulfill the promise to transfer the good, instead of a promised service to its customer. |

- removed (2019-07-26):
[0000866374-19-000003:note_history:57]
| • | In accordance with ASC 606-10-32-18 the Company elected to not adjust the promised amount of consideration for the effects of a significant financing component as the Company expects, at contract inception, that the period between when the entity transfers a promised good or service to a customer and when the customer pays for that good or service will generally be one year or less. |

- removed (2019-07-26):
[0000866374-19-000003:note_history:58]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for nonemployee share-based payment transactions in current GAAP. The guidance is effective for the Company beginning in the first quarter of fiscal year 2020 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2020.

- removed (2019-07-26):
[0000866374-19-000003:note_history:59]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" intended to improve financial reporting on leasing transactions. The new lease guidance will require entities that lease assets to recognize on the balance sheet the assets and liabilities for the rights and obligations created by those leases with lease terms of more than 12 months. The guidance will also enhance existing disclosure requirements relating to those leases. In January 2018, the FASB issued ASU 2018-01, “Land Easement Practical Expedient for Transition to Topic 842”, which permits an entity to elect an optional transition practical expedient to not evaluate under Topic 842 land easements that exist or expired before the entity’s adoption of Topic 842 and that were not previously accounted for as leases under Topic 840. In July 2018, the FASB issued ASU 2018-11, "Leases (Topic 842): Targeted Improvements", which provides entities with relief from the costs of implementing certain aspects of the new leasing standard, ASC 842. Specifically, under the amendments in ASU 2018-11, (1) entities may elect not to recast the comparative periods presented when transitioning to ASC 842 and (2) lessors may elect not to separate lease and nonlease components when certain conditions are met. Also in July 2018, the FASB issued ASU 2018-10, "Codification Improvements to Topic 842, Leases", which clarifies how to apply certain aspects of the new leases standard, ASC 842. The amendments address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. In December 2018, the FASB issued ASU 2018-20 “Leases (Topic 842): Narrow-Scope Improvements for Lessors” to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing transactions. The amendments have the same effective date and transition requirements as the new lease standard. The Company intends to adopt the new lease guidance when it becomes effective in the first quarter of fiscal year 2020 using a modified retrospective approach as described in the new transition option above under ASU 2018-11. In conjunction, the Company intends to elect the package of practical expedients offered, which would allow entities to not i) reassess whether any expired or existing contracts contain leases in accordance with the new guidance, ii) reassess lease classifications, and iii) reassess whether initial direct costs capitalized under ASC 840 continue to meet the definition of initial direct costs under the new guidance. While the Company continues to evaluate the effect of adopting the new lease guidance on its consolidated financial statement and related disclosures, the new guidance is expected to have a material impact on the Company’s consolidated balance sheets upon adoption. The Company expect all of its leases including its operating leases will be subject to the new standard. The Company will recognize right-of-use assets and operating lease liabilities on the consolidated balance sheets upon adoption which will increase total assets and liabilities.

- removed (2019-07-26):
[0000866374-19-000003:note_history:60]
In December 2017, the Securities and Exchange Commission ("SEC") staff issued Staff Accounting Bulletin No. 118 (SAB 118), Income Tax Accounting Implications of the Tax Cuts and Jobs Act ("Tax Act"), which allowed the Company to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As of December 31, 2018, the Company has finalized all provisional amounts related to the Tax Act. Finalizing provisional adjustments related to the Tax Act did not have a material impact on our consolidated financial statements as of December 31, 2018. The Company expects further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-07-26):
[0000866374-19-000010:note_history:61]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2019 are as follows:

- added (2019-07-26):
[0000866374-19-000010:note_history:62]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | — |  |
| 4.75% Notes due June 2025 | 596,925 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,232 |  |  | — |  |
| India Facilities (1) | 102,108 |  |  | 170,206 |  |
| Other | 169,385 |  |  | 168,039 |  |
| Debt issuance costs | (14,195 | ) |  | (10,639 | ) |
|  | 3,237,731 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (275,937 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,961,794 |  |  | $ | 2,421,904 |  |

- added (2019-07-26):
[0000866374-19-000010:note_history:63]
| (1) | The balance as of June 28, 2019 reflects the outstanding drawdown from the $200 million term loan facility entered in July 2018. There was no outstanding balance as of June 28, 2019 related to the short-term bank borrowings facility entered in February 2019. |

- added (2019-07-26):
[0000866374-19-000010:note_history:64]
The weighted-average interest rate for the Company's long-term debt was 4.2% as of June 28, 2019 and March 31, 2019.

- added (2019-07-26):
[0000866374-19-000010:note_history:65]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay $250 million of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month period ended June 28, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

- added (2019-07-26):
[0000866374-19-000010:note_history:66]
Scheduled repayments of the Company's long-term debt as of June 28, 2019 are as follows:

- added (2019-07-26):
[0000866374-19-000010:note_history:67]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 269,918 |  |
| 2021 | 100,761 |  |
| 2022 | 603,979 |  |
| 2023 | 857,571 |  |
| 2024 | 60,438 |  |
| Thereafter | 1,359,259 |  |
| Total | $ | 3,251,926 |  |

- added (2019-07-26):
[0000866374-19-000010:note_history:68]
| (1) | Represents estimated repayments for the remaining nine-month period ending March 31, 2020. |

- added (2019-07-26):
[0000866374-19-000010:note_history:69]
Term Loan due April 2024

- added (2019-07-26):
[0000866374-19-000010:note_history:70]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is

- added (2019-07-26):
[0000866374-19-000010:note_history:71]
denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

- added (2019-07-26):
[0000866374-19-000010:note_history:72]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term.

- added (2019-07-26):
[0000866374-19-000010:note_history:73]
Notes due June 2029

- added (2019-07-26):
[0000866374-19-000010:note_history:74]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “2029 Notes”), at 99.607% of face value. The Company received proceeds of approximately $448.2 million, net of discount, from the issuance which was used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $4.3 million of costs in conjunction with the issuance of the 2029 Notes.

- added (2019-07-26):
[0000866374-19-000010:note_history:75]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

- added (2019-07-26):
[0000866374-19-000010:note_history:76]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of June 28, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.

- removed (2019-07-26):
[0000866374-19-000003:note_history:77]
BANK BORROWINGS AND LONG-TERM DEBT

- removed (2019-07-26):
[0000866374-19-000003:note_history:78]
India Term Loan

- removed (2019-07-26):
[0000866374-19-000003:note_history:79]
In July 2018, a subsidiary of the Company entered into a $200 million term loan facility (the "Facility"), under which there was $52 million in borrowings outstanding as of December 31, 2018. The Facility will be used to fund capital expenditure to support the Company's expansion plan for India. The availability period during which drawdowns can be made will be from the date of the agreement to and including June 30, 2019. The maximum maturity of each drawdown will be 5 years from the funded Capex shipment date. As a result, the longest maturity date of any future drawdown under the Facility will be June 30, 2024. Borrowings under this term loan bear interest at LIBOR plus a margin of 1.15%. The Facility is unsecured, guaranteed by the Company, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to certain exceptions and limitations. This Facility agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term. As of December 31, 2018, the Company was in compliance with the covenants under this term loan agreement.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-07-26):
[0000866374-19-000010:note_history:80]
|  | As of June 28, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 252,819 |  |  | $ | 500,000 |  |  | $ | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 424,725 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 454,511 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 526,881 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | 311,455 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 596,925 |  |  | 619,267 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,232 |  |  | 455,449 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 102,108 |  |  | 102,108 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 52,972 |  |  | 52,972 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 113,766 |  |  | 113,766 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,249,279 |  |  | $ | 3,313,953 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |

- removed (2019-07-26):
[0000866374-19-000003:note_history:81]
|  | As of December 31, 2018 |  | As of March 31, 2018 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 500,000 |  |  | $ | 502,475 |  |  | $ | 500,000 |  |  | $ | 513,596 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 | 675,625 |  |  | 664,646 |  |  | 687,813 |  |  | 689,966 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 464,813 |  |  | 464,525 |  |  | 483,656 |  |  | 485,470 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,760 |  |  | 500,000 |  |  | 525,292 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 596,706 |  |  | 587,724 |  |  | 596,387 |  |  | 627,407 |  |  | Level 1 |
| Euro Term Loan due September 2020 | 53,806 |  |  | 53,806 |  |  | 59,443 |  |  | 59,443 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 113,814 |  |  | 113,814 |  |  | 123,518 |  |  | 123,518 |  |  | Level 2 |
| India Term Loan | 51,901 |  |  | 51,901 |  |  | — |  |  | — |  |  | Level 2 |
| Total | $ | 2,956,665 |  |  | $ | 2,939,651 |  |  | $ | 2,950,817 |  |  | $ | 3,024,692 |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2019-07-26):
[0000866374-19-000010:note_history:82]
Bank borrowings and long-term debt as of June 28, 2019 are as follows:

- added (2019-07-26):
[0000866374-19-000010:note_history:83]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | — |  |
| 4.75% Notes due June 2025 | 596,925 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,232 |  |  | — |  |
| India Facilities (1) | 102,108 |  |  | 170,206 |  |
| Other | 169,385 |  |  | 168,039 |  |
| Debt issuance costs | (14,195 | ) |  | (10,639 | ) |
|  | 3,237,731 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (275,937 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,961,794 |  |  | $ | 2,421,904 |  |

- added (2019-07-26):
[0000866374-19-000010:note_history:84]
(1)

- added (2019-07-26):
[0000866374-19-000010:note_history:85]
The balance as of June 28, 2019 reflects the outstanding drawdown from the $200 million term loan facility entered in July 2018. There was no outstanding balance as of June 28, 2019 related to the short-term bank borrowings facility entered in February 2019.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2019-07-26):
[0000866374-19-000010:note_history:86]
Scheduled repayments of the Company's long-term debt as of June 28, 2019 are as follows:

- added (2019-07-26):
[0000866374-19-000010:note_history:87]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 269,918 |  |
| 2021 | 100,761 |  |
| 2022 | 603,979 |  |
| 2023 | 857,571 |  |
| 2024 | 60,438 |  |
| Thereafter | 1,359,259 |  |
| Total | $ | 3,251,926 |  |

- added (2019-07-26):
[0000866374-19-000010:note_history:88]
(1)

- added (2019-07-26):
[0000866374-19-000010:note_history:89]
Represents estimated repayments for the remaining nine-month period ending March 31, 2020.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-26):
[0000866374-19-000010:note_history:90]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 28, 2019 and June 29, 2018 (in thousands), respectively.
  (was, 2019-02-06, similarity 0.8357):
[0000866374-19-000003:note_history:90]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month and nine-month periods ended December 31, 2018 (in thousands), respectively:

- changed (2019-07-26):
[0000866374-19-000010:note_history:91]
|  | Three-Month Period Ended June 28, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 923,727 |  |  | $ | 1,115,059 |  |  | $ | 1,359,365 |  |  | $ | 1,024,626 |  |  | $ | 4,422,777 |  |
| Over time | 254,316 |  |  | 521,855 |  |  | 499,484 |  |  | 477,507 |  |  | 1,753,162 |  |
| Total segment | $ | 1,178,043 |  |  | $ | 1,636,914 |  |  | $ | 1,858,849 |  |  | $ | 1,502,133 |  |  | $ | 6,175,939 |  |
  (was, 2019-02-06, similarity 0.9333):
[0000866374-19-000003:note_history:91]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,235,712 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 5,027,281 |  |
| Over time | 276,714 |  |  | 583,610 |  |  | 460,256 |  |  | 596,966 |  |  | 1,917,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,819,322 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 6,944,827 |  |

- changed (2019-07-26):
[0000866374-19-000010:note_history:92]
|  | Three-Month Period Ended June 29, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 1,298,137 |  |  | $ | 4,860,722 |  |
| Over time | 210,245 |  |  | 382,413 |  |  | 460,779 |  |  | 484,797 |  |  | 1,538,234 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 1,782,934 |  |  | $ | 6,398,956 |  |
  (was, 2019-02-06, similarity 0.8191):
[0000866374-19-000003:note_history:92]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,740,045 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 14,595,699 |  |
| Over time | 801,790 |  |  | 1,683,094 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 5,483,688 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 5,423,139 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 20,079,387 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-26):
[0000866374-19-000010:note_history:93]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.
  (was, 2019-02-06, similarity 0.9996):
[0000866374-19-000003:note_history:93]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that create enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

- changed (2019-07-26):
[0000866374-19-000010:note_history:94]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to
  (was, 2019-02-06, similarity 0.9172):
[0000866374-19-000003:note_history:94]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises).  The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

- added (2019-07-26):
[0000866374-19-000010:note_history:95]
transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).

- changed (2019-07-26):
[0000866374-19-000010:note_history:96]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional.
  (was, 2019-02-06, similarity 0.7948):
[0000866374-19-000003:note_history:96]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional. The following table summarizes the activity in the Company's contract assets during the nine-month period ended December 31, 2018 (in thousands):

- changed (2019-07-26):
[0000866374-19-000010:note_history:97]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $329.8 million and $271.8 million as of June 28, 2019 and March 31, 2019, respectively.
  (was, 2019-02-06, similarity 0.934):
[0000866374-19-000003:note_history:97]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $308.0 million and $265.3 million as of December 31, 2018 and April 1, 2018, respectively.

- changed (2019-07-26):
[0000866374-19-000010:note_history:98]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 28, 2019 and June 29, 2018 (in thousands), respectively.
  (was, 2019-02-06, similarity 0.8357):
[0000866374-19-000003:note_history:98]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month and nine-month periods ended December 31, 2018 (in thousands), respectively:

- changed (2019-07-26):
[0000866374-19-000010:note_history:99]
|  | Three-Month Period Ended June 28, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 923,727 |  |  | $ | 1,115,059 |  |  | $ | 1,359,365 |  |  | $ | 1,024,626 |  |  | $ | 4,422,777 |  |
| Over time | 254,316 |  |  | 521,855 |  |  | 499,484 |  |  | 477,507 |  |  | 1,753,162 |  |
| Total segment | $ | 1,178,043 |  |  | $ | 1,636,914 |  |  | $ | 1,858,849 |  |  | $ | 1,502,133 |  |  | $ | 6,175,939 |  |
  (was, 2019-02-06, similarity 0.9333):
[0000866374-19-000003:note_history:99]
|  | Three-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 929,638 |  |  | $ | 1,235,712 |  |  | $ | 1,198,669 |  |  | $ | 1,663,262 |  |  | $ | 5,027,281 |  |
| Over time | 276,714 |  |  | 583,610 |  |  | 460,256 |  |  | 596,966 |  |  | 1,917,546 |  |
| Total segment | $ | 1,206,352 |  |  | $ | 1,819,322 |  |  | $ | 1,658,925 |  |  | $ | 2,260,228 |  |  | $ | 6,944,827 |  |

- changed (2019-07-26):
[0000866374-19-000010:note_history:100]
|  | Three-Month Period Ended June 29, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 1,298,137 |  |  | $ | 4,860,722 |  |
| Over time | 210,245 |  |  | 382,413 |  |  | 460,779 |  |  | 484,797 |  |  | 1,538,234 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 1,782,934 |  |  | $ | 6,398,956 |  |
  (was, 2019-02-06, similarity 0.8191):
[0000866374-19-000003:note_history:100]
|  | Nine-Month Period Ended December 31, 2018 |
|  | HRS |  | CTG |  | IEI |  | CEC |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 2,827,959 |  |  | $ | 3,740,045 |  |  | $ | 3,351,886 |  |  | $ | 4,675,809 |  |  | $ | 14,595,699 |  |
| Over time | 801,790 |  |  | 1,683,094 |  |  | 1,319,302 |  |  | 1,679,502 |  |  | 5,483,688 |  |
| Total segment | $ | 3,629,749 |  |  | $ | 5,423,139 |  |  | $ | 4,671,188 |  |  | $ | 6,355,311 |  |  | $ | 20,079,387 |  |

- removed (2019-07-26):
[0000866374-19-000003:note_history:101]
|  | Contract Assets |
| Beginning balance, April 1, 2018 | $ | — |  |
| Cumulative effect adjustment at April 1, 2018 | 412,787 |  |
| Revenue recognized | 5,483,688 |  |
| Amounts collected or invoiced | (5,598,024 | ) |
| Ending balance, December 31, 2018 | $ | 298,451 |  |
