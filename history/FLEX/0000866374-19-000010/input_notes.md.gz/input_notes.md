# FLEX notes — 0000866374-19-000010


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-19-000010:notes:1]
ORGANIZATION OF THE COMPANY AND BASIS OF PRESENTATION
Organization of the Company

[0000866374-19-000010:notes:2]
Flex Ltd. ("Flex" or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized, provider of Sketch-to-Scale®  services - innovative design, engineering, manufacturing, and supply chain services and solutions - from conceptual sketch to full-scale production. The Company designs, builds, ships and manages complete packaged consumer and enterprise products, from medical devices and connected automotive systems to sustainable lighting and cloud and data center solutions for companies of all sizes in various industries and end-markets, through its activities in the following segments:

[0000866374-19-000010:notes:3]
| • | High Reliability Solutions ("HRS"), which is comprised of our health solutions business, including surgical equipment, drug delivery, diagnostics, telemedicine, disposable devices, imaging and monitoring, patient mobility and ophthalmology; and our automotive business, including vehicle electrification, connectivity, autonomous, and smart technologies; |

[0000866374-19-000010:notes:4]
| • | Industrial and Emerging Industries ("IEI"), which is comprised of energy including advanced metering infrastructure, energy storage, smart lighting, smart solar energy; and industrial, including semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks; |

[0000866374-19-000010:notes:5]
| • | Communications & Enterprise Compute ("CEC"), which includes our telecom business of radio access base stations, remote radio heads and small cells for wireless infrastructure; our networking business, which includes optical, routing, and switching products for data and video networks; our server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack-level solutions, converged infrastructure and software-defined product solutions; and |

[0000866374-19-000010:notes:6]
| • | Consumer Technologies Group ("CTG"), which includes our consumer-related businesses in IoT enabled devices, audio and consumer power electronics, mobile devices; and various supply chain solutions for consumer, computing and printing devices. |

[0000866374-19-000010:notes:7]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-19-000010:notes:8]
Basis of Presentation

[0000866374-19-000010:notes:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2019 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month periods ended June 28, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020.

[0000866374-19-000010:notes:10]
The first quarters for fiscal years 2020 and 2019 ended on June 28, 2019, which is comprised of 89 days in the period, and June 29, 2018, which is comprised of 90 days in the period, respectively.

[0000866374-19-000010:notes:11]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. The associated noncontrolling owners' interest in the income or losses of these

[0000866374-19-000010:notes:12]
companies is not material to the Company's results of operations for all periods presented, and is classified as a component of interest and other, net, in the condensed consolidated statements of operations.

[0000866374-19-000010:notes:13]
As previously disclosed, the Company has made certain immaterial corrections to net sales previously reported for the first quarter of fiscal year 2019 primarily to reflect revenue from certain contracts with customers on a net basis. As a result, net sales and cost of sales in the accompanying Condensed Consolidated Statement of Operations for the three-month period ended June 29, 2018 are $25 million lower than previously reported for the first quarter of fiscal year 2019. These corrections had no impact on gross profit, segment income or net income for the period presented. Amounts presented for the first quarter of fiscal year 2019 related to the disaggregation of revenue in the CTG segment in Note 4, and CTG segment net sales and total net sales in Note 16, have also been restated accordingly. The Company evaluated these corrections, considering both qualitative and quantitative factors, and concluded they are immaterial to the previously issued financial statements.

[0000866374-19-000010:notes:14]
Recently Adopted Accounting Pronouncement

[0000866374-19-000010:notes:15]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU No. 2016-02, Leases, and subsequent updates (collectively, referred to as Accounting Standard Codification 842 or “ASC 842”). ASC 842 requires a lessee to recognize a right of use (“ROU”) asset and lease liability. Leases will be classified as finance or operating, with classification affecting the recognition of expense and presentation in the income statement.

[0000866374-19-000010:notes:16]
The Company adopted ASC 842 on April 1, 2019 using the modified retrospective method on the effective date. As a result, the Company was not required to adjust its comparative period financial information for effects of the standard or make the new required lease disclosures for periods before our adoption date. The Company has elected to adopt the package of transition practical expedients and, therefore, has not reassessed (1) whether existing or expired contracts contain a lease, (2) lease classification for existing or expired leases or (3) the accounting for initial direct costs that were previously capitalized. In addition, the Company has elected the short term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and nonlease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date).As the Company cannot determine the interest rate implicit in the lease for its leases, as such the Company uses its estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company’s estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company’s leases includes the noncancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-19-000010:notes:17]
The adoption of ASC 842 had a material impact to the Company’s consolidated balance sheet, but did not materially impact the consolidated statement of income or consolidated statement of cash flows. The most significant changes to the consolidated balance sheet relate to the recognition of new ROU assets and lease liabilities for operating leases. The Company’s accounting for finance leases remains substantially unchanged and the balances are not material for any periods presented.

[0000866374-19-000010:notes:18]
As a result of adopting ASC 842 as of April 1, 2019, the Company recognized additional operating liabilities of $705 million with a corresponding ROU asset of $669 million and a deferred gain of $22 million for sale leaseback transactions to prior year retained earnings.

[0000866374-19-000010:notes:19]
In October 2018, the FASB issued ASU 2018-16 “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” to expand the lists of eligible benchmark interest rates to include OIS based on SOFR to facilitate the marketplace transition from LIBOR. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-19-000010:notes:20]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement”, which amends ASC 820 to add, remove, and modify fair value measurement disclosure requirements. The Company adopted the guidance during the first quarter of fiscal year 2020 with an immaterial impact on the Company's financial position, results of operations and cash flows.

[0000866374-19-000010:notes:21]
In June 2018, the FASB issued ASU 2018-07 "Compensation - Stock Compensation (Topic 718): Improvement to Nonemployee Share-Based Payment Accounting" with the objective of simplifying several aspects of the accounting for

[0000866374-19-000010:notes:22]
nonemployee share-based payment transactions in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000010:notes:23]
In August 2017, the FASB issued ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" with the objective of improving the financial reporting of hedging relationships and simplifying the application of the hedge accounting guidance in current GAAP. The Company adopted this guidance during the first quarter of fiscal year 2020 with an immaterial impact on its consolidated financial statements.

[0000866374-19-000010:notes:24]
Recently Issued Accounting Pronouncements

[0000866374-19-000010:notes:25]
In November 2018, the FASB issued ASU 2018-19 “Codification Improvements to Topic 326: Financial Instruments - Credit Losses” to introduce an expected credit loss methodology for the impairment of financial assets measured at amortized cost basis. That methodology replaces the probable, incurred loss model for those assets. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company is currently assessing and expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000010:notes:26]
In October 2018, the FASB issued ASU 2018-17 “Consolidation (Topic 810): Targeted Improvements to Related Party Guidance for Variable Interest Entities” to provide a new private company variable interest entity exemption and change how decision makers apply the variable interest criteria. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2021.

[0000866374-19-000010:notes:27]
In August 2018, the FASB issued ASU 2018-15 "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” to provide guidance on a customer's accounting for implementation, set-up, and other upfront costs incurred in a cloud computing arrangement that is hosted by the vendor, i.e., a service contract. Under the new guidance, customers will apply the same criteria for capitalizing implementation costs as they would for an arrangement that has a software license. The new guidance also prescribes the balance sheet, income statement, and cash flow classification of the capitalized implementation costs and related amortization expense, as well as requires additional quantitative and qualitative disclosures. The guidance is effective for the Company beginning in the first quarter of fiscal year 2021 with early adoption permitted. The Company expects to early adopt the guidance, during fiscal year 2020, and does not expect a material impact to its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-19-000010:notes:28]
[same as prior period, unchanged from 0000866374-19-000003:notes:161]

[0000866374-19-000010:notes:29]
[same as prior period, unchanged from 0000866374-19-000003:notes:162]

[0000866374-19-000010:notes:30]
The components of inventories, net of applicable lower of cost and net realizable value write-downs, were as follows:

[0000866374-19-000010:notes:31]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| Raw materials | $ | 2,897,291 |  |  | $ | 2,922,101 |  |
| Work-in-progress | 383,473 |  |  | 366,135 |  |
| Finished goods | 464,936 |  |  | 434,618 |  |
|  | $ | 3,745,700 |  |  | $ | 3,722,854 |  |

[0000866374-19-000010:notes:32]
[same as prior period, unchanged from 0000866374-19-000003:notes:164]

[0000866374-19-000010:notes:33]
The following table summarizes the activity in the Company’s goodwill account for each of its four reporting units (which align to the Company's reportable segments) during the three-month period ended June 28, 2019:

[0000866374-19-000010:notes:34]
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
|  | (In thousands) |
| Balance, beginning of the year | $ | 507,209 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,073,055 |  |
| Divestitures | (1,102 | ) |  | — |  |  | — |  |  | — |  |  | (1,102 | ) |
| Foreign currency translation adjustments | 5,278 |  |  | — |  |  | — |  |  | — |  |  | 5,278 |  |
| Balance, end of the period | $ | 511,385 |  |  | $ | 333,257 |  |  | $ | 129,325 |  |  | $ | 103,264 |  |  | $ | 1,077,231 |  |

[0000866374-19-000010:notes:35]
The components of acquired intangible assets are as follows:

[0000866374-19-000010:notes:36]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 297,389 |  |  | $ | (122,884 | ) |  | $ | 174,505 |  |  | $ | 297,306 |  |  | $ | (113,627 | ) |  | $ | 183,679 |  |
| Licenses and other intangibles | 266,493 |  |  | (126,282 | ) |  | 140,211 |  |  | 274,604 |  |  | (127,288 | ) |  | 147,316 |  |
| Total | $ | 563,882 |  |  | $ | (249,166 | ) |  | $ | 314,716 |  |  | $ | 571,910 |  |  | $ | (240,915 | ) |  | $ | 330,995 |  |

[0000866374-19-000010:notes:37]
[same as prior period, unchanged from 0000866374-19-000003:notes:168]

[0000866374-19-000010:notes:38]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 47,807 |  |
| 2021 | 60,793 |  |
| 2022 | 52,261 |  |
| 2023 | 44,529 |  |
| 2024 | 42,964 |  |
| Thereafter | 66,362 |  |
| Total amortization expense | $ | 314,716 |  |

[0000866374-19-000010:notes:39]
____________________________________________________________

[0000866374-19-000010:notes:40]
| (1) | Represents estimated amortization for the remaining nine-month period ending March 31, 2020. |

[0000866374-19-000010:notes:41]
[same as prior period, unchanged from 0000866374-19-000003:notes:169]

[0000866374-19-000010:notes:42]
Other current assets include approximately $335.1 million and $292.5 million as of June 28, 2019 and March 31, 2019, respectively, for the deferred purchase price receivable from the Company's Asset-Backed Securitization programs. See note 12 for additional information.

[0000866374-19-000010:notes:43]
[same as prior period, unchanged from 0000866374-19-000003:notes:185]

[0000866374-19-000010:notes:44]
Other current liabilities include customer working capital advances of $264.5 million and $266.3 million, customer-related accruals of $253.4 million and $260.1 million, and deferred revenue of $329.8 million and $271.8 million, as of June 28, 2019 and March 31, 2019, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. Following the adoption of ASC 842, current operating lease liabilities were $135.2 million as of June 28, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-19-000010:notes:45]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a minimal number of finance leases with an immaterial impact on its condensed financial statements. Leases have initial lease terms ranging from 1 year to 23 years.

[0000866374-19-000010:notes:46]
The components of lease cost for the quarter ended June 28, 2019 were (in thousands):

[0000866374-19-000010:notes:47]
| Lease cost | Three-Month Period Ended |
|  | June 28, 2019 |
| Operating lease cost | $ | 45,704 |  |
| Total lease cost | $ | 45,704 |  |

[0000866374-19-000010:notes:48]
Amounts reported in the Consolidated Balance Sheet as of the quarter ended June 28, 2019 were (in thousands, except weighted average lease term and discount rate):

[0000866374-19-000010:notes:49]
|  | As of June 28, 2019 |
| Operating Leases: |  |
| Operating lease right of use assets | $ | 656,267 |  |
| Operating lease liabilities | (690,241 | ) |
| Weighted-average remaining lease term (In years) |  |
| Operating leases | 7 |  |
| Weighted-average discount rate |  |
| Operating leases | 4.0 | % |

[0000866374-19-000010:notes:50]
Other information related to leases as of the quarter ended June 28, 2019 was (in thousands):

[0000866374-19-000010:notes:51]
| Cash paid for amounts included in the measurement of lease liabilities: |  |
| Operating cash flows from operating leases | $ | 43,040 |  |

[0000866374-19-000010:notes:52]
Future lease payments under non-cancellable leases as of June 28, 2019 are as follows (in thousands):

[0000866374-19-000010:notes:53]
| Fiscal Year Ended March 31, | Operating Leases |
| 2020 (1) | $ | 124,615 |  |
| 2021 | 130,200 |  |
| 2022 | 109,199 |  |
| 2023 | 92,762 |  |
| 2024 | 78,452 |  |
| Thereafter | 262,057 |  |
| Total undiscounted lease payments | 797,285 |  |
| Less: imputed interest | 107,044 |  |
| Total lease liabilities | $ | 690,241 |  |

[0000866374-19-000010:notes:54]
| (1) | Represents estimated lease payments for the remaining nine-month period ending March 31, 2020. |

[0000866374-19-000010:notes:55]
As previously disclosed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019 and under the previous lease accounting standard ASC 840, the aggregate future non-cancellable minimum rental payments on our operating lease, as of March 31, 2019, are as follows:

[0000866374-19-000010:notes:56]
| Fiscal Year Ending March 31, | Operating Leases |
|  | (In thousands) |
| 2020 | $ | 155,391 |  |
| 2021 | 113,245 |  |
| 2022 | 93,777 |  |
| 2023 | 81,335 |  |
| 2024 | 67,341 |  |
| Thereafter | 171,828 |  |
| Total minimum lease payments | $ | 682,917 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-19-000010:notes:57]
[same as prior period, unchanged from 0000866374-19-000003:notes:125]

[0000866374-19-000010:notes:58]
[same as prior period, unchanged from 0000866374-19-000003:notes:126]

[0000866374-19-000010:notes:59]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements (“MSA”) with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addenda, emails or other communications that embody the commitment by the customer.

[0000866374-19-000010:notes:60]
[same as prior period, unchanged from 0000866374-19-000003:notes:128]

[0000866374-19-000010:notes:61]
[same as prior period, unchanged from 0000866374-19-000003:notes:129]

[0000866374-19-000010:notes:62]
[same as prior period, unchanged from 0000866374-19-000003:notes:130]

[0000866374-19-000010:notes:63]
[same as prior period, unchanged from 0000866374-19-000003:notes:131]

[0000866374-19-000010:notes:64]
[same as prior period, unchanged from 0000866374-19-000003:notes:132]

[0000866374-19-000010:notes:65]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to

[0000866374-19-000010:notes:66]
transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g.: procurement of materials and standard workmanship warranty).

[0000866374-19-000010:notes:67]
[same as prior period, unchanged from 0000866374-19-000003:notes:134]

[0000866374-19-000010:notes:68]
[same as prior period, unchanged from 0000866374-19-000003:notes:135]

[0000866374-19-000010:notes:69]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to receivables when rights to payment become unconditional.

[0000866374-19-000010:notes:70]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance and is included in other current liabilities on the condensed consolidated balance sheets. Contract liabilities were $329.8 million and $271.8 million as of June 28, 2019 and March 31, 2019, respectively.

[0000866374-19-000010:notes:71]
[same as prior period, unchanged from 0000866374-19-000003:notes:138]

[0000866374-19-000010:notes:72]
The following table presents the Company’s revenue disaggregated based on timing of transfer - point in time and over time - for the three-month periods ended June 28, 2019 and June 29, 2018 (in thousands), respectively.

[0000866374-19-000010:notes:73]
|  | Three-Month Period Ended June 28, 2019 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 923,727 |  |  | $ | 1,115,059 |  |  | $ | 1,359,365 |  |  | $ | 1,024,626 |  |  | $ | 4,422,777 |  |
| Over time | 254,316 |  |  | 521,855 |  |  | 499,484 |  |  | 477,507 |  |  | 1,753,162 |  |
| Total segment | $ | 1,178,043 |  |  | $ | 1,636,914 |  |  | $ | 1,858,849 |  |  | $ | 1,502,133 |  |  | $ | 6,175,939 |  |

[0000866374-19-000010:notes:74]
|  | Three-Month Period Ended June 29, 2018 |
|  | HRS |  | IEI |  | CEC |  | CTG |  | Total |
| Timing of Transfer |  |  |  |  |  |  |  |  |  |
| Point in time | $ | 1,005,180 |  |  | $ | 1,063,898 |  |  | $ | 1,493,507 |  |  | $ | 1,298,137 |  |  | $ | 4,860,722 |  |
| Over time | 210,245 |  |  | 382,413 |  |  | 460,779 |  |  | 484,797 |  |  | 1,538,234 |  |
| Total segment | $ | 1,215,425 |  |  | $ | 1,446,311 |  |  | $ | 1,954,286 |  |  | $ | 1,782,934 |  |  | $ | 6,398,956 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-19-000010:notes:75]
SHARE-BASED COMPENSATION
The Company's primary plan used for granting equity compensation awards is the 2017 Equity Incentive Plan (the "2017 Plan").

[0000866374-19-000010:notes:76]
[same as prior period, unchanged from 0000866374-19-000003:notes:52]

[0000866374-19-000010:notes:77]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In thousands) |
| Cost of sales | $ | 2,940 |  |  | $ | 5,404 |  |
| Selling, general and administrative expenses | 12,287 |  |  | 15,549 |  |
| Total share-based compensation expense | $ | 15,227 |  |  | $ | 20,953 |  |

[0000866374-19-000010:notes:78]
Total unrecognized compensation expense related to share options under all plans was $1.5 million and will be recognized over a weighted-average remaining vesting period of 1.7 years. As of June 28, 2019, the number of options outstanding and exercisable under all plans was 0.7 million and 0.5 million, respectively, at a weighted-average exercise price of $4.38 per share and $5.36 per share, respectively.

[0000866374-19-000010:notes:79]
During the three-month period ended June 28, 2019, the Company granted 7.8 million unvested restricted share unit ("RSU") awards. Of this amount, approximately 6.1 million are plain-vanilla unvested RSU awards that vest over four years, with no performance or market conditions, and with an average grant date price of $9.16 per award. Further, approximately 1.7 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The expense for these awards contingent on certain market conditions is immaterial for the three-month period ended June 28, 2019 as the awards were granted close to the quarter end. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of 3.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index, and will cliff vest after a period of three years, to the extent such market conditions have been met.

[0000866374-19-000010:notes:80]
As of June 28, 2019, approximately 18.9 million unvested RSU awards under all plans were outstanding, of which vesting for a targeted amount of 3.5 million awards is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 7.0 million based on the achievement levels of the respective conditions. During the three-month period ended June 28, 2019, no shares vested in connection with the awards with market conditions granted in fiscal year 2017.

[0000866374-19-000010:notes:81]
As of June 28, 2019, total unrecognized compensation expense related to unvested RSU awards under all plans was approximately $181.3 million, and will be recognized over a weighted-average remaining vesting period of 2.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000866374-19-000010:notes:82]
EARNINGS PER SHARE 
The following table reflects basic weighted-average ordinary shares outstanding and diluted weighted-average ordinary share equivalents used to calculate basic and diluted earnings per share attributable to the shareholders of Flex Ltd.:

[0000866374-19-000010:notes:83]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In thousands, except per share amounts) |
| Basic earnings per share: |  |  |  |  |  |
| Net income | $ | 44,872 |  |  | $ | 116,035 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 514,238 |  |  | 529,380 |  |
| Basic earnings per share | $ | 0.09 |  |  | $ | 0.22 |  |
| Diluted earnings per share: |  |  |  |  |  |
| Net income | $ | 44,872 |  |  | $ | 116,035 |  |
| Shares used in computation: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 514,238 |  |  | 529,380 |  |
| Weighted-average ordinary share equivalents from stock options and restricted share unit awards (1) (2) | 3,312 |  |  | 6,074 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 517,550 |  |  | 535,454 |  |
| Diluted earnings per share | $ | 0.09 |  |  | $ | 0.22 |  |

[0000866374-19-000010:notes:84]
| (1) | An immaterial number of options to purchase ordinary shares were excluded from the computation of diluted earnings per share during the three-month periods ended June 28, 2019 and June 29, 2018, respectively, due to their anti-dilutive impact on the weighted-average ordinary share equivalents. |

[0000866374-19-000010:notes:85]
(2)

[0000866374-19-000010:notes:86]
Restricted share unit awards of 6.1 million and 3.3 million for the three-month periods ended June 28, 2019 and June 29, 2018, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-19-000010:notes:87]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of June 28, 2019 are as follows:

[0000866374-19-000010:notes:88]
|  | As of June 28, 2019 |  | As of March 31, 2019 |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 500,000 |  |
| Term Loan due November 2021 | 421,563 |  |  | 671,563 |  |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 458,531 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | — |  |
| 4.75% Notes due June 2025 | 596,925 |  |  | 596,815 |  |
| 4.875% Notes due June 2029 | 448,232 |  |  | — |  |
| India Facilities (1) | 102,108 |  |  | 170,206 |  |
| Other | 169,385 |  |  | 168,039 |  |
| Debt issuance costs | (14,195 | ) |  | (10,639 | ) |
|  | 3,237,731 |  |  | 3,054,515 |  |
| Current portion, net of debt issuance costs | (275,937 | ) |  | (632,611 | ) |
| Non-current portion | $ | 2,961,794 |  |  | $ | 2,421,904 |  |

[0000866374-19-000010:notes:89]
| (1) | The balance as of June 28, 2019 reflects the outstanding drawdown from the $200 million term loan facility entered in July 2018. There was no outstanding balance as of June 28, 2019 related to the short-term bank borrowings facility entered in February 2019. |

[0000866374-19-000010:notes:90]
The weighted-average interest rate for the Company's long-term debt was 4.2% as of June 28, 2019 and March 31, 2019.

[0000866374-19-000010:notes:91]
During the first quarter of fiscal year 2020, and as further discussed below, the Company entered into a JPY33.525 billion term loan agreement due April 2024, in addition to issuing $450 million of 4.875% Notes due June 15, 2029. Part of the proceeds obtained were used to repay $250 million of the Company's existing 4.625% Notes due February 2020, and $250 million of the Term Loan due November 2021. As both transactions were determined to fall under extinguishment accounting, the Company recognized an immaterial loss on extinguishment during the three-month period ended June 28, 2019, which was recorded in interest and other, net on the condensed consolidated statements of operations during the period.

[0000866374-19-000010:notes:92]
Scheduled repayments of the Company's long-term debt as of June 28, 2019 are as follows:

[0000866374-19-000010:notes:93]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2020 (1) | $ | 269,918 |  |
| 2021 | 100,761 |  |
| 2022 | 603,979 |  |
| 2023 | 857,571 |  |
| 2024 | 60,438 |  |
| Thereafter | 1,359,259 |  |
| Total | $ | 3,251,926 |  |

[0000866374-19-000010:notes:94]
| (1) | Represents estimated repayments for the remaining nine-month period ending March 31, 2020. |

[0000866374-19-000010:notes:95]
Term Loan due April 2024

[0000866374-19-000010:notes:96]
In April 2019, the Company entered into a JPY 33.525 billion term loan agreement due April 2024, at three-month Yen LIBOR plus 0.50%, which was then swapped to U.S. dollars. The term loan, which is due at maturity and subject to quarterly interest payments, is used to fund general operations and refinance certain other outstanding debts. As the term loan is

[0000866374-19-000010:notes:97]
denominated in Japanese Yen, the debt balance is remeasured to USD at end of each reporting period. Foreign currency contracts have been entered into with respect to this Japanese yen denominated term loan. Refer to note 10 for additional details.

[0000866374-19-000010:notes:98]
This term loan is unsecured, and contains customary restrictions on the ability of the Company and its subsidiaries to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term.

[0000866374-19-000010:notes:99]
Notes due June 2029

[0000866374-19-000010:notes:100]
In June 2019, the Company issued $450 million of 4.875% Notes due June 15, 2029 (the “2029 Notes”), at 99.607% of face value. The Company received proceeds of approximately $448.2 million, net of discount, from the issuance which was used, together with available cash, to refinance certain other outstanding debt. The Company incurred and capitalized as a direct reduction to the carrying amount of the notes presented on the balance sheet approximately $4.3 million of costs in conjunction with the issuance of the 2029 Notes.

[0000866374-19-000010:notes:101]
Interest on the 2029 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2019. The 2029 Notes are senior unsecured obligations of the Company and rank equally with all of the Company’s other existing and future senior and unsecured indebtedness.

[0000866374-19-000010:notes:102]
The Indenture governing the 2029 Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries. In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding 2029 Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding 2029 Notes may declare all of the 2029 Notes to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the 2029 Notes. As of June 28, 2019, the Company was in compliance with the covenants in the indenture governing the 2029 Notes.


## flex:InterestAndOtherNetTextBlock

[0000866374-19-000010:notes:103]
INTEREST AND OTHER, NET 
Interest and other, net for the three-month periods ended June 28, 2019 and June 29, 2018 are primarily composed of the following:

[0000866374-19-000010:notes:104]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In thousands) |
| Interest expenses on debt obligations (1) | $ | 40,428 |  |  | $ | 33,517 |  |
| ABS and AR sales programs related expenses | 12,981 |  |  | 9,480 |  |
| Interest income | (4,592 | ) |  | (5,121 | ) |
| Gain (Loss) on foreign exchange transactions | (886 | ) |  | 2,057 |  |

[0000866374-19-000010:notes:105]
(1)

[0000866374-19-000010:notes:106]
Interest expenses on debt obligations for the three-month period ended June 28, 2019 includes debt extinguishment cost of $4.1 million related to the partial repayments of the Notes due February 2020 and Term Loan due November 2021.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-19-000010:notes:107]
OTHER CHARGES (INCOME), NET 
During the three-month period ended June 29, 2018, the Company recognized other income of $86.9 million, primarily driven by a $91.8 million gain on the deconsolidation of Bright Machines.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-19-000010:notes:108]
[same as prior period, unchanged from 0000866374-19-000003:notes:38]

[0000866374-19-000010:notes:109]
[same as prior period, unchanged from 0000866374-19-000003:notes:39]

[0000866374-19-000010:notes:110]
The Company enters into short-term and long-term foreign currency derivatives contracts, including forward, swap, and options contracts to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable and accounts payable, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-19-000010:notes:111]
As of June 28, 2019, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $8.1 billion as summarized below:

[0000866374-19-000010:notes:112]
|  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency | Buy |  | Sell |  | Buy |  | Sell |
|  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |
| CNY | 1,741,500 |  |  | — |  |  | $ | 252,923 |  |  | $ | — |  |
| EUR | 45,320 |  |  | — |  |  | 51,279 |  |  | — |  |
| HUF | 34,791,000 |  |  | — |  |  | 122,360 |  |  | — |  |
| ILS | 191,000 |  |  | — |  |  | 53,226 |  |  | — |  |
| JPY | 33,525,000 |  |  | — |  |  | 300,000 |  |  | — |  |
| MXN | 4,564,000 |  |  | — |  |  | 238,323 |  |  | — |  |
| MYR | 265,000 |  |  | 43,000 |  |  | 63,940 |  |  | 10,375 |  |
| PLN | 162,000 |  |  | — |  |  | 43,262 |  |  | — |  |
| RON | 247,000 |  |  | — |  |  | 59,518 |  |  | — |  |
| Other | N/A |  |  | N/A |  |  | 42,325 |  |  | 3,640 |  |
|  |  |  |  |  |  |  | 1,227,156 |  |  | 14,015 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |
| BRL | — |  |  | 721,000 |  |  | — |  |  | 187,448 |  |
| CAD | 76,286 |  |  | 53,135 |  |  | 58,052 |  |  | 40,435 |  |
| CNY | 3,294,464 |  |  | 553,285 |  |  | 477,927 |  |  | 80,355 |  |
| EUR | 1,793,083 |  |  | 2,068,220 |  |  | 2,038,027 |  |  | 2,348,603 |  |
| GBP | 38,873 |  |  | 51,524 |  |  | 49,287 |  |  | 65,328 |  |
| HUF | 59,355,877 |  |  | 56,809,178 |  |  | 208,756 |  |  | 199,799 |  |
| ILS | 162,500 |  |  | 25,400 |  |  | 45,284 |  |  | 7,078 |  |
| INR | 8,058,300 |  |  | 7,262,247 |  |  | 116,523 |  |  | 104,995 |  |
| JPY | 3,006,895 |  |  | 4,989,750 |  |  | 27,880 |  |  | 46,307 |  |
| MXN | 3,059,758 |  |  | 2,119,949 |  |  | 159,774 |  |  | 110,699 |  |
| MYR | 724,260 |  |  | 386,510 |  |  | 174,752 |  |  | 93,259 |  |
| SEK | 399,558 |  |  | 457,749 |  |  | 42,538 |  |  | 49,440 |  |
| SGD | 57,378 |  |  | 34,869 |  |  | 42,402 |  |  | 25,768 |  |
| Other | N/A |  |  | N/A |  |  | 59,544 |  |  | 41,126 |  |
|  |  |  |  |  |  |  | 3,500,746 |  |  | 3,400,640 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  | $ | 4,727,902 |  |  | $ | 3,414,655 |  |

[0000866374-19-000010:notes:113]
As of June 28, 2019, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional

[0000866374-19-000010:notes:114]
currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of June 28, 2019, and March 31, 2019, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gains were immaterial as of June 28, 2019, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period, except for the USD JPY cross currency swap, which is further discussed below.

[0000866374-19-000010:notes:115]
The Company entered into a USD JPY cross currency swap to hedge the foreign currency risk on the JPY term loan due April 2024, and the fair value of the cross currency swap was included in other assets as of June 28, 2019. The changes in fair value of  the USD JPY cross currency swap are reported in accumulated other comprehensive loss, with the impact of the excluded component reported in interest and other, net. In addition, a corresponding amount is reclassified out of accumulated other comprehensive loss to interest and other, net to offset the remeasurement of the underlying JPY loan principal which also impacts the same line.

[0000866374-19-000010:notes:116]
[same as prior period, unchanged from 0000866374-19-000003:notes:44]

[0000866374-19-000010:notes:117]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | June 28, 2019 |  | March 31, 2019 |  | Balance SheetLocation |  | June 28, 2019 |  | March 31, 2019 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 7,720 |  |  | $ | 10,503 |  |  | Other current liabilities |  | $ | 14,291 |  |  | $ | 10,282 |  |
| Foreign currency contracts | Other assets |  | $ | 18,454 |  |  | $ | — |  |  | Other liabilities |  | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 20,883 |  |  | $ | 16,774 |  |  | Other current liabilities |  | $ | 20,405 |  |  | $ | 17,144 |  |

[0000866374-19-000010:notes:118]
[same as prior period, unchanged from 0000866374-19-000003:notes:46]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-19-000010:notes:119]
ACCUMULATED OTHER COMPREHENSIVE LOSS 
The changes in accumulated other comprehensive loss by component, net of tax, are as follows:

[0000866374-19-000010:notes:120]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,556 | ) |  | $ | (109,607 | ) |  | $ | (151,163 | ) |  | $ | (35,746 | ) |  | $ | (50,099 | ) |  | $ | (85,845 | ) |
| Other comprehensive gain (loss) before reclassifications | (6,068 | ) |  | 4,404 |  |  | (1,664 | ) |  | (41,659 | ) |  | (44,086 | ) |  | (85,745 | ) |
| Net losses reclassified from accumulated other comprehensive loss | 593 |  |  | — |  |  | 593 |  |  | 756 |  |  | — |  |  | 756 |  |
| Net current-period other comprehensive gain (loss) | (5,475 | ) |  | 4,404 |  |  | (1,071 | ) |  | (40,903 | ) |  | (44,086 | ) |  | (84,989 | ) |
| Ending balance | $ | (47,031 | ) |  | $ | (105,203 | ) |  | $ | (152,234 | ) |  | $ | (76,649 | ) |  | $ | (94,185 | ) |  | $ | (170,834 | ) |

[0000866374-19-000010:notes:121]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month period ended June 28, 2019 were recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-19-000010:notes:122]
TRADE RECEIVABLES SECURITIZATION
The Company sells trade receivables under two asset-backed securitization programs and an accounts receivable factoring program.

[0000866374-19-000010:notes:123]
[same as prior period, unchanged from 0000866374-19-000003:notes:189]

[0000866374-19-000010:notes:124]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables, which are included in other current assets as of June 28, 2019 and March 31, 2019, were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables, and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-19-000010:notes:125]
Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $900 million for the Global Program, of which $725 million is committed and $175 million is uncommitted, and $250 million for the North American Program, of which $210 million is committed and $40 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-19-000010:notes:126]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month periods ended June 28, 2019 and June 29, 2018 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets or liabilities are recognized.

[0000866374-19-000010:notes:127]
The Company's deferred purchase price receivables relating to its asset-backed securitization program are recorded initially at fair value based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not material. The interrelationship between these inputs is also insignificant.

[0000866374-19-000010:notes:128]
As of June 28, 2019 and March 31, 2019, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company during the three-month periods ended June 28, 2019 and June 29, 2018 were included as cash provided by operating activities in the condensed consolidated statements of cash flows. The Company recognizes these proceeds net of the deferred purchase price, consisting of a receivable from the purchasers that entitles the Company to certain collections on the receivable. The Company recognizes the collection of the deferred purchase price in net cash provided by investing activities in the condensed consolidated statements of cash flows separately as cash collections of deferred purchase price. As disclosed in the Company’s prior year filings, during the first quarter of fiscal year 2019, the Company utilized a monthly approach to track cash flows on deferred purchase price. Commencing with the quarter ended September 28, 2018, the Company changed to a method based on daily activity for both the three-month and six-month periods ended September 28, 2018. As a result, the Company has retrospectively adjusted cash flows from operating and investing activities for the three-months ended June 29, 2018 from amounts previously reported. This resulted in an increase of approximately $271 million to cash provided by investing activities, and a corresponding decrease to cash flow from operating activities on the consolidated statement of cash flows for the three-months ended June 29, 2018.

[0000866374-19-000010:notes:129]
As of June 28, 2019, approximately $1.1 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $0.8 billion and deferred purchase price receivables of $0.3 billion. As of March 31, 2019, approximately $1.2 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $0.9 billion and deferred purchase price receivables of $0.3 billion. The deferred purchase price balances as of June 28, 2019 and March 31, 2019, also represent the non-cash beneficial interest obtained in exchange for securitized receivables.

[0000866374-19-000010:notes:130]
For the three-month periods ended June 28, 2019 and June 29, 2018, cash flows from sales of receivables under the ABS Programs consisted of approximately $1.6 billion and $1.8 billion, respectively, for transfers of receivables, and approximately  $0.9 billion, respectively, for collections on deferred purchase price receivables. The Company's cash flows from transfer of receivables consist primarily of proceeds from collections reinvested in revolving-period transfers. Cash flows from new transfers were not significant for all periods presented.

[0000866374-19-000010:notes:131]
Trade Accounts Receivable Sale Programs
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.5 billion as of June 28, 2019 and March 31, 2019, respectively. For the three-month periods ended June 28, 2019 and June 29, 2018, total accounts receivable sold to certain third party banking institutions was approximately $0.5 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-19-000010:notes:132]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-19-000010:notes:133]
[same as prior period, unchanged from 0000866374-19-000003:notes:66]

[0000866374-19-000010:notes:134]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant’s investment manager. The Company’s deferred compensation plan assets are included in other noncurrent assets on the condensed consolidated balance sheets and include investments in equity securities that are valued using active market prices. There were no investment balance classified as level 1 in the fair value hierarchy as of June 28, 2019.

[0000866374-19-000010:notes:135]
[same as prior period, unchanged from 0000866374-19-000003:notes:68]

[0000866374-19-000010:notes:136]
[same as prior period, unchanged from 0000866374-19-000003:notes:69]

[0000866374-19-000010:notes:137]
[same as prior period, unchanged from 0000866374-19-000003:notes:70]

[0000866374-19-000010:notes:138]
[same as prior period, unchanged from 0000866374-19-000003:notes:71]

[0000866374-19-000010:notes:139]
[same as prior period, unchanged from 0000866374-19-000003:notes:72]

[0000866374-19-000010:notes:140]
The Company has accrued for contingent consideration in connection with its business acquisitions as applicable, which is measured at fair value based on certain internal models and unobservable inputs. There were no contingent consideration liabilities outstanding as of June 28, 2019.

[0000866374-19-000010:notes:141]
There were no transfers between levels in the fair value hierarchy during the three-month periods ended June 28, 2019 and June 29, 2018.

[0000866374-19-000010:notes:142]
[same as prior period, unchanged from 0000866374-19-000003:notes:75]

[0000866374-19-000010:notes:143]
[same as prior period, unchanged from 0000866374-19-000003:notes:76]

[0000866374-19-000010:notes:144]
|  | Fair Value Measurements as of June 28, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 945,578 |  |  | $ | — |  |  | $ | 945,578 |  |
| Foreign exchange contracts (Note 10) | — |  |  | 47,057 |  |  | — |  |  | 47,057 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 82,430 |  |  | — |  |  | 82,430 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0.003 |  |
| Foreign exchange contracts (Note 10) | $ | — |  |  | $ | (34,696 | ) |  | $ | — |  |  | $ | (34,696 | ) |
|  | Fair Value Measurements as of March 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 473,888 |  |  | $ | — |  |  | $ | 473,888 |  |
| Foreign exchange contracts (Note 10) | — |  |  | 27,277 |  |  | — |  |  | 27,277 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 2,845 |  |  | 76,852 |  |  | — |  |  | 79,697 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 10) | $ | — |  |  | $ | (27,426 | ) |  | $ | — |  |  | $ | (27,426 | ) |

[0000866374-19-000010:notes:145]
[same as prior period, unchanged from 0000866374-19-000003:notes:78]

[0000866374-19-000010:notes:146]
[same as prior period, unchanged from 0000866374-19-000003:notes:79]

[0000866374-19-000010:notes:147]
|  | As of June 28, 2019 |  | As of March 31, 2019 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| 4.625% Notes due February 2020 | $ | 250,008 |  |  | $ | 252,819 |  |  | $ | 500,000 |  |  | $ | 499,950 |  |  | Level 1 |
| Term Loan due November 2021 | 421,563 |  |  | 424,725 |  |  | 671,563 |  |  | 670,724 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through June 2022 | 452,250 |  |  | 454,511 |  |  | 458,531 |  |  | 457,958 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 526,881 |  |  | 500,000 |  |  | 499,950 |  |  | Level 1 |
| Term Loan due April 2024 - three-month Yen LIBOR plus 0.50% | 311,455 |  |  | 311,455 |  |  | — |  |  | — |  |  | Level 2 |
| 4.750% Notes due June 2025 | 596,925 |  |  | 619,267 |  |  | 596,815 |  |  | 599,940 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 448,232 |  |  | 455,449 |  |  | — |  |  | — |  |  | Level 1 |
| India Facilities | 102,108 |  |  | 102,108 |  |  | 170,206 |  |  | 170,206 |  |  | Level 2 |
| Euro Term Loan due September 2020 | 52,972 |  |  | 52,972 |  |  | 52,746 |  |  | 52,746 |  |  | Level 2 |
| Euro Term Loan due January 2022 | 113,766 |  |  | 113,766 |  |  | 112,524 |  |  | 112,524 |  |  | Level 2 |
| Total | $ | 3,249,279 |  |  | $ | 3,313,953 |  |  | $ | 3,062,385 |  |  | $ | 3,063,998 |  |  |  |

[0000866374-19-000010:notes:148]
The Company values its Term Loan due April 2024, India Facilities, and Euro Term Loans due September 2020 and January 2022 based on the current market rate, and as of June 28, 2019, the carrying amounts approximate fair values.
The Term Loans due November 2021 and June 2022, and the Notes due February 2020, February 2023, June 2025 and June 2029 are valued based on broker trading prices in active markets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-19-000010:notes:149]
COMMITMENTS AND CONTINGENCIES

[0000866374-19-000010:notes:150]
Litigation and other legal matters

[0000866374-19-000010:notes:151]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. The amounts accrued are not material. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, except as discussed below, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material adverse effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-19-000010:notes:152]
In addition, the Company provides design and engineering services to its customers and also designs and makes its own products. As a consequence of these activities, its customers are requiring the Company to take responsibility for intellectual property to a greater extent than in its manufacturing and assembly businesses. Although the Company believes that its intellectual property assets and licenses are sufficient for the operation of its business as it currently conducts it, from time to time third parties do assert patent infringement claims against the Company or its customers. If and when third parties make assertions regarding the ownership or right to use intellectual property, the Company could be required to either enter into licensing arrangements or to resolve the issue through litigation. Such license rights might not be available to the Company on commercially acceptable terms, if at all, and any such litigation might not be resolved in its favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. The Company also could be required to incur substantial costs to redesign a product or re-perform design services.

[0000866374-19-000010:notes:153]
From time to time, the Company enters into IP licenses (e.g., patent licenses and software licenses) with third parties which obligate the Company to report covered behavior to the licensor and pay license fees to the licensor for certain activities or products, or that enable the Company's use of third party technologies. The Company may also decline to enter into licenses for intellectual property that it does not think is useful for or used in its operations, or for which its customers or suppliers have

[0000866374-19-000010:notes:154]
licenses or have assumed responsibility. Given the diverse and varied nature of its business and the location of its business around the world, certain activities the Company performs, such as providing assembly services in China and India, may fall outside the scope of those licenses or may not be subject to the applicable intellectual property rights. The Company's licensors may disagree and claim royalties are owed for such activities. In addition, the basis (e.g., base price) for any royalty amounts owed are audited by licensors and may be challenged. Some of these disagreements may lead to claims and litigation that might not be resolved in the Company's favor. Additionally, litigation could be lengthy and costly and could materially harm the Company's financial condition regardless of the outcome. In March 2018, the Company received an inquiry from a licensor referencing its patent license agreement with the Company, and requesting information relating to royalties for products that the Company assembles for a customer in China. The Company and licensor have had subsequent discussions, during which the licensor claimed that the Company owes a material amount under the patent license agreement, which the Company disputes and would contest vigorously. While the Company cannot predict the outcome with respect to this claim or estimate an amount or reasonable range of loss, a material loss is reasonably possible.

[0000866374-19-000010:notes:155]
On May 8, 2018, a putative class action was filed in the Northern District of California against the Company and certain officers alleging violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5, promulgated thereunder, alleging misstatements and/or omissions in certain of the Company’s financial results, press releases and SEC filings made during the putative class period of January 26, 2017 through April 26, 2018. On October 1, 2018, the Court appointed lead plaintiff and lead plaintiff’s counsel in the case. On November 28, 2018, lead plaintiff filed an amended complaint alleging misstatements and/or omissions in certain of the Company’s SEC filings, press releases, earnings calls, and analyst and investor conferences and expanding the putative class period through October 25, 2018. On April 3, 2019, the Court vacated its prior order appointing lead plaintiff and lead plaintiff’s counsel and reopened the lead plaintiff appointment process.   A hearing on the motions to serve as lead plaintiff is scheduled for September 26, 2019. A case management conference is scheduled for October 9, 2019. The Company believes that the claims are without merit and intends to vigorously defend this case.

[0000866374-19-000010:notes:156]
On April 21, 2016, SunEdison, Inc. (together with certain of its subsidiaries, "SunEdison") filed for protection under Chapter 11 of the U.S. Bankruptcy Code. During the fiscal year ended March 31, 2016, the Company recognized a bad debt reserve charge of $61.0 million associated with its outstanding SunEdison receivables and accepted return of previously shipped inventory of approximately $90.0 million. SunEdison stated in schedules filed with the Bankruptcy Court that, within the 90 days preceding SunEdison's bankruptcy filing, the Company received approximately $98.6 million of inventory and cash transfers of $69.2 million, which in aggregate represents the Company's estimate of the maximum reasonably possible contingent loss. On April 15, 2018, a subsidiary of the Company together with its subsidiaries and affiliates, entered into a tolling agreement with the trustee of the SunEdison Litigation Trust to toll any applicable statute of limitations or other time-related defense that might exist in regards to any potential claims that either party might be able to assert against the other for a period that will end at the earlier to occur of: (a) 60 days after a party provides written notice of termination; (b) six years from the effective date of April 15, 2018; or (c) such other date as the parties may agree in writing. No preference claims have been asserted against the Company and consideration has been given to the related contingencies based on the facts currently known. The Company has a number of affirmative and direct defenses to any potential claims for recovery and intends to vigorously defend any such claim, if asserted.

[0000866374-19-000010:notes:157]
One of the Company's Brazilian subsidiaries has received related assessments for certain sales and import taxes. There are six tax assessments totaling 360 million Brazilian reals (approximately USD $93.6 million based on the exchange rate as of June 28, 2019). The assessments are in various stages of the review process at the administrative level and no tax proceeding has been finalized yet. The Company believes there is no legal basis for these assessments and has meritorious defenses and will continue to vigorously oppose all of these assessments, as well as any future assessments. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-19-000010:notes:158]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. The Company has initiated an internal investigation regarding this matter. The matter is at a very preliminary stage. The Company cannot predict how long it will take to complete the investigation or to what extent the Company could be subject to penalties.

[0000866374-19-000010:notes:159]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $94 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2018. The assessed amounts related to the denial of certain deductible intercompany payments. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes. As the final resolution of the assessment remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which

[0000866374-19-000010:notes:160]
may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-19-000010:notes:161]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-19-000010:notes:162]
SHARE REPURCHASES 
During the three-month period ended June 28, 2019, the Company repurchased 5.0 million shares at an aggregate purchase price of $52.0 million, and retired all of these shares.

[0000866374-19-000010:notes:163]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 16, 2018. As of June 28, 2019, shares in the aggregate amount of $272.5 million were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-19-000010:notes:164]
SEGMENT REPORTING
The Company has four reportable segments: HRS, IEI, CEC and CTG. These segments are determined based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics. Refer to note 1 for a description of the various product categories manufactured under each of these segments.

[0000866374-19-000010:notes:165]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, customer related asset impairments charges, restructuring charges, the new revenue standard adoption impact, legal and other, interest and other, net and other charges (income), net.

[0000866374-19-000010:notes:166]
Selected financial information by segment is in the table below.

[0000866374-19-000010:notes:167]
|  | Three-Month Periods Ended |
|  | June 28, 2019 |  | June 29, 2018 |
|  | (In thousands) |
| Net sales: |  |  |  |
| High Reliability Solutions | $ | 1,178,043 |  |  | $ | 1,215,425 |  |
| Industrial & Emerging Industries | 1,636,914 |  |  | 1,446,311 |  |
| Communications & Enterprise Compute | 1,858,849 |  |  | 1,954,286 |  |
| Consumer Technologies Group | 1,502,133 |  |  | 1,782,934 |  |
|  | $ | 6,175,939 |  |  | $ | 6,398,956 |  |
| Segment income and reconciliation of income before tax: |  |  |  |
| High Reliability Solutions | $ | 87,232 |  |  | $ | 93,534 |  |
| Industrial & Emerging Industries | 95,457 |  |  | 51,361 |  |
| Communications & Enterprise Compute | 26,147 |  |  | 46,017 |  |
| Consumer Technologies Group | 30,116 |  |  | 26,557 |  |
| Corporate and Other | (31,092 | ) |  | (29,761 | ) |
| Total segment income | 207,860 |  |  | 187,708 |  |
| Reconciling items: |  |  |  |
| Intangible amortization | 17,082 |  |  | 18,517 |  |
| Stock-based compensation | 15,227 |  |  | 20,953 |  |
| Customer related asset impairments (1) | 483 |  |  | 17,364 |  |
| Restructuring charges (Note 17) | 56,192 |  |  | 8,817 |  |
| New revenue standard adoption impact (Note 4) | — |  |  | 9,291 |  |
| Legal and other (2) | 1,610 |  |  | 16,311 |  |
| Interest and other, net | 51,694 |  |  | 41,742 |  |
| Other charges (income), net (Note 9) | 1,463 |  |  | (86,924 | ) |
| Income (loss) before income taxes | $ | 64,109 |  |  | $ | 141,637 |  |

[0000866374-19-000010:notes:168]
| (1) | Customer related asset impairments for the three-month period ended June 29, 2018 primarily relate to additional provision for doubtful accounts receivable, and excess and obsolete inventory for certain customers experiencing significant financial difficulties and/or the Company is disengaging from. |

[0000866374-19-000010:notes:169]
| (2) | Legal and other during the three-month period ended June 29, 2018 primarily consists of costs incurred relating to the independent investigation undertaken by the Audit Committee of the Company’s Board of Directors which was completed in June 2018 and certain charges not directly related to ongoing or core business. |

[0000866374-19-000010:notes:170]
[same as prior period, unchanged from 0000866374-19-000003:notes:159]

[0000866374-19-000010:notes:171]
[same as prior period, unchanged from 0000866374-19-000003:notes:160]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-19-000010:notes:172]
RESTRUCTURING CHARGES
During fiscal year 2019, the Company took focused actions to optimize its portfolio, most notably within CTG. During the first quarter of fiscal year 2020, as a result of recent geopolitical developments and uncertainties, primarily impacting one customer in China, the Company has seen a reduction in demand for products assembled for that customer. Due to these circumstances, the Company has decided to accelerate its strategic decision to reduce its exposure to certain high-volatility products in both China and India. The Company also initiated targeted activities to restructure its business to further reduce and

[0000866374-19-000010:notes:173]
streamline its cost structure. The Company recognized $56.2 million of charges during the first quarter of fiscal year 2020, comprised of approximately $30.8 million of cash charges predominantly for employee severance, and $25.4 million of non-cash charges related to impairment of equipment and inventory. The Company expects to complete these activities during fiscal year 2020.

[0000866374-19-000010:notes:174]
There were no material restructuring charges incurred during the three-month period ended June 29, 2018.

[0000866374-19-000010:notes:175]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of June 28, 2019 for charges incurred during the three-month period ended June 28, 2019:

[0000866374-19-000010:notes:176]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In thousands) |
| Balance as of March 31, 2019 | $ | 23,234 |  |  | $ | — |  |  | $ | 9,200 |  |  | $ | 32,434 |  |
| Provision for charges incurred during the three-month period ended June 28, 2019 | 21,018 |  |  | 17,820 |  |  | 17,354 |  |  | 56,192 |  |
| Cash payments for charges incurred in the fiscal year 2019 and prior | (7,408 | ) |  | — |  |  | (1,650 | ) |  | (9,058 | ) |
| Cash payments for charges incurred during the three-month period ended June 28, 2019 | (2,755 | ) |  | — |  |  | — |  |  | (2,755 | ) |
| Non-cash charges incurred during the three-month period ended June 28, 2019 | — |  |  | (17,820 | ) |  | (7,794 | ) |  | (25,614 | ) |
| Balance as of June 28, 2019 | 34,089 |  |  | — |  |  | 17,110 |  |  | 51,199 |  |
| Less: Current portion (classified as other current liabilities) | 34,089 |  |  | — |  |  | 17,110 |  |  | 51,199 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
