# FLEX notes — 0000866374-25-000027


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000866374-25-000027:notes:1]
| Document |  | Parts into Which Incorporated |
| Proxy Statement to be delivered to shareholders in connection with the Registrant's 2025 Annual General Meeting of Shareholders |  | Part III |


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000866374-25-000027:notes:2]
Our cybersecurity risk management program is intended to protect the confidentiality, integrity, and availability of our critical information technology ("IT") systems and information. Our program is integrated into, and among the risks evaluated and considered by, our broader enterprise risk management program, which is designed to identify, assess, prioritize and mitigate risks across the organization to enhance our resilience and support the achievement of our strategic objectives. We designed and assess our cybersecurity risk management program based on multiple cybersecurity frameworks, such as the National Institute of Standards and Technology Cybersecurity Framework, as well as information security standards issued by the International Organization for Standardization, including ISO 27001, which we use as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business. Our global information security management program is ISO 27001:2022 certified.

[0000866374-25-000027:notes:3]
Our cybersecurity risk management program is led by our Chief Information Security Officer ("CISO"), who manages our security team principally responsible for managing our cybersecurity risk assessment processes, our security controls, and our detection and response to cybersecurity incidents. Our program includes protocols for preventing, detecting and responding to cybersecurity incidents, and cross-functional coordination and governance of business continuity and disaster recovery plans. Components of our program include:

[0000866374-25-000027:notes:4]
•risk assessments designed to help identify cybersecurity threats to our critical IT systems, information, and our broader enterprise IT environment;

[0000866374-25-000027:notes:5]
•the periodic engagement of independent security firms and other third-party experts, where appropriate, to assess, test, and certify components of our cybersecurity program, and to otherwise assist with aspects of our cybersecurity processes and controls;

[0000866374-25-000027:notes:6]
•annual cybersecurity awareness training for our employees;

[0000866374-25-000027:notes:7]
•regular assessments of the design and operational effectiveness of the program’s key processes and controls by our internal audit team as well as external consultants; and

[0000866374-25-000027:notes:8]
•a risk management process for third-party service providers and vendors that includes due diligence in the selection process and periodic monitoring regarding adherence to applicable cybersecurity standards.

[0000866374-25-000027:notes:9]
We also have a cybersecurity incident response plan to assess and manage cybersecurity incidents, which includes escalation procedures based on the nature and severity of the incident including, where appropriate, escalation to the Audit Committee and the Board. We periodically (at least annually) perform tabletop exercises to test our incident response procedures, identify gaps and improvement opportunities and exercise team preparedness.

[0000866374-25-000027:notes:10]
As part of our overall risk mitigation strategy, we maintain insurance coverage that is intended to address certain aspects of cybersecurity risks; however, such insurance may not be sufficient in type or amount to cover us against claims related to cybersecurity breaches, cyberattacks and other related breaches.

[0000866374-25-000027:notes:11]
As of the date of this report, we do not believe that any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, have materially affected or are reasonably likely to materially affect our Company, including our business strategy, results of operations or financial condition. Despite our security measures, however, there can be no assurance that we, or third parties with which we interact, will not experience a cybersecurity incident in the future that will materially affect us. For more information on our cybersecurity related risks, see Item IA,, "Risk Factors - "A breach of our IT or physical security systems, or violation of data privacy laws, may cause us to incur significant legal and financial exposure and adversely affect our operations."


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000866374-25-000027:notes:12]
The Audit Committee of our Board of Directors has primary responsibility for overseeing our cybersecurity risks and other information technology risks, including our plans to mitigate cybersecurity risks and to respond to data breaches.

[0000866374-25-000027:notes:13]
The Audit Committee receives regular reports (at least quarterly) from our CISO on cybersecurity matters. These reports include a range of topics, including our cybersecurity risk profile, the current cybersecurity and emerging threat landscape, the status of ongoing cybersecurity initiatives, incident reports, and the results of internal and external assessments of our information systems. The Audit Committee also annually reviews the adequacy and effectiveness of our information and technology security policies and the internal controls regarding information and technology security and cybersecurity, and periodically receives updates from our internal audit function on the results of our cybersecurity audits and related mitigation activities. The Chair of the Audit Committee reports to the full Board on these discussions as appropriate.

[0000866374-25-000027:notes:14]
The full Board also receives briefings from our CISO on cybersecurity matters annually. In addition, Board members periodically receive presentations on cybersecurity matters from external experts as part of the Board’s continuing education and overall risk oversight.

[0000866374-25-000027:notes:15]
At the management level, our CISO leads our enterprise-wide cybersecurity program, and is responsible for assessing and managing our material risks from cybersecurity threats. In performing his role, our CISO is informed about and monitors the prevention, detection, mitigation, and remediation of cybersecurity risks and incidents through the management of, and participation in, the cybersecurity risk management and strategy processes described above, including the operation of our incident response plan. Our CISO reports to our Interim Chief Information Officer who, in turn, reports to our Chief Operating Officer and member of our executive leadership team.
Our CISO is an experienced cybersecurity executive with more than 20 years of experience building and leading cybersecurity, risk management, and information technology teams. Our CISO holds industry-recognized cybersecurity certifications, including having held Certified Information Systems Security Professional (CISSP) certification.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-25-000027:notes:16]
ORGANIZATION OF THE COMPANY
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex delivers technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. Flex partners with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, industrial and power. As of March 31, 2025, Flex reports its financial performance based on two operating and reportable segments as follows:

[0000866374-25-000027:notes:17]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-25-000027:notes:18]
◦Communications, Enterprise and Cloud, including data center, edge, and communications infrastructure

[0000866374-25-000027:notes:19]
◦Lifestyle, including appliances, floorcare, smart living, HVAC, and power tools

[0000866374-25-000027:notes:20]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-25-000027:notes:21]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-25-000027:notes:22]
◦Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power.

[0000866374-25-000027:notes:23]
◦Automotive, including compute platforms, power electronics, motion, and interface

[0000866374-25-000027:notes:24]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-25-000027:notes:25]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

[0000866374-25-000027:notes:26]
Nextracker Follow-on Offering and Spin-off

[0000866374-25-000027:notes:27]
On February 13, 2023, Nextracker Inc. ("Nextracker") completed an initial public offering (the "IPO") of its Class A common stock. Prior to the IPO, the Company maintained an 82.6% indirect ownership in Nextracker and consolidated Nextracker. On July 3, 2023, Nextracker completed a follow-on offering to its IPO and issued 15,631,562 shares of Class A common stock and received net proceeds of $552 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., the Company’s indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. The Company received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses. After the follow-on transaction, Flex held approximately 51.5% of Nextracker's common stock.

[0000866374-25-000027:notes:28]
In connection with the IPO, Nextracker entered into a Tax Receivable Agreement ("TRA") with Flex and TPG wherein 85% of the tax benefits realized in relation to the IPO would be paid to those parties. Flex has not recorded an asset in relation to amounts potentially due to Flex under the TRA as the amounts are contingent upon Nextracker realizing the IPO related tax benefits. As such, amounts will be recognized in income, if and when they are received. Amounts that could be received by Flex, over a 20 year period, range from zero to approximately $300 million. During fiscal year 2025, $13 million was received under the Nextracker TRA.

[0000866374-25-000027:notes:29]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interest in Nextracker to Flex shareholders on a pro-rata basis based on the number of ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of

[0000866374-25-000027:notes:30]
Merger, dated as of February 7, 2023. Under the terms of the Nextracker spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for each Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares. Nextracker spin-off is intended to qualify as a tax-free transaction for U.S. federal income tax purposes.

[0000866374-25-000027:notes:31]
As a result of the completion of this spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and Flex no longer consolidates Nextracker into its financial results. All noncontrolling interest related to Nextracker have been eliminated through additional paid-in capital. Prior to or in connection with this spin-off, Flex entered into various agreements to effect Nextracker spin-off and provide a framework for the relationship between Flex and Nextracker following the spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.

[0000866374-25-000027:notes:32]
Subsequent to this spin-off, Flex presents Nextracker’s historical operations as discontinued operations and, as such, Nextracker’s historical results have been excluded from continuing operations and unless otherwise indicated Flex’s disclosures are presented on a continuing operations basis.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000866374-25-000027:notes:33]
SUMMARY OF ACCOUNTING POLICIES
Basis of Presentation and Principles of Consolidation

[0000866374-25-000027:notes:34]
The accompanying consolidated financial statements include the accounts of Flex and its majority-owned subsidiaries, after elimination of intercompany accounts and transactions. Amounts included in these consolidated financial statements are expressed in U.S. dollars unless otherwise designated. The Company consolidates its majority-owned subsidiaries and investments in entities in which the Company has a controlling interest. For the consolidated majority-owned subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners.

[0000866374-25-000027:notes:35]
The historical statements of comprehensive income and cash flows and the balances related to stockholders’ equity have not been revised to reflect the effect of the Nextracker spin-off. See note 7 "Discontinued Operations" for additional information.

[0000866374-25-000027:notes:36]
Use of Estimates

[0000866374-25-000027:notes:37]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of  restricted share unit awards granted under the Company's stock-based compensation plans. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts) there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000027:notes:38]
Translation of Foreign Currencies

[0000866374-25-000027:notes:39]
The financial position and results of operations for certain of the Company's subsidiaries are measured using a currency other than the U.S. dollar as their functional currency. Accordingly, all assets and liabilities for these subsidiaries are translated into U.S. dollars at the current exchange rates as of the respective balance sheet dates. Revenue and expense items are translated at the average exchange rates prevailing during the period. Cumulative gains and losses from the translation of these subsidiaries' financial statements are reported as other comprehensive income (loss), a component of shareholders' equity.

[0000866374-25-000027:notes:40]
Foreign exchange gains and losses arising from transactions denominated in a currency other than the functional currency of the entity involved, and re-measurement adjustments for foreign operations where the U.S. dollar is the functional currency, are included in the Company's consolidated results of operations. Non-functional currency transaction gains and losses, and re-measurement adjustments were not material to the Company's consolidated results of operations for all periods presented, and have been classified as a component of other charges (income), net in the consolidated statements of operations.

[0000866374-25-000027:notes:41]
Revenue Recognition

[0000866374-25-000027:notes:42]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts, the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method. Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Certain of the Company's customer contracts involve purchasing raw materials from customers or acting as an agent for the sale of certain customer products. Finished goods billings related to these products are reported net of the associated material cost in net sales in the consolidated statements of operations. Refer to note 4 "Revenue" for further details.

[0000866374-25-000027:notes:43]
Government Incentives and Grants

[0000866374-25-000027:notes:44]
The Company receives incentives from federal, state and local governments in different regions of the world that primarily encourage the Company to establish, maintain, or increase investment, employment, or production in the regions. The Company accounts for government incentives as a reduction in the cost of the capital investment or a reduction of expense, based on the substance of the incentives received. Benefits are generally recorded when all conditions attached to the incentive have been met and there is reasonable assurance of receipt. The Company records capital-related incentives as a reduction to Property and equipment, net on the consolidated balance sheets and recognizes a reduction to depreciation and amortization expense over the useful life of the corresponding acquired asset. The Company records operating grants as a reduction to expense in the same line item on the consolidated statements of operations as the expenditure for which the grant is intended to compensate. Government incentives and grant transactions are not material to the Company's financial position, results of operations or cash flows.

[0000866374-25-000027:notes:45]
Concentration of Credit Risk

[0000866374-25-000027:notes:46]
Financial instruments which potentially subject the Company to concentrations of credit risk are primarily accounts receivable, derivative instruments, and cash and cash equivalents.

[0000866374-25-000027:notes:47]
Customer Credit Risk

[0000866374-25-000027:notes:48]
The Company has an established customer credit policy, through which it manages customer credit exposures through credit evaluations, credit limit setting, monitoring, and enforcement of credit limits for new and existing customers. The Company performs ongoing credit evaluations of its customers' financial condition and makes provisions for doubtful accounts based on the outcome of those credit evaluations. The Company evaluates the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections and the age of past due

[0000866374-25-000027:notes:49]
receivables. To the extent the Company identifies exposures as a result of credit or customer evaluations, the Company also reviews other customer related exposures, including but not limited to inventory and related contractual obligations.

[0000866374-25-000027:notes:50]
The following table summarizes the activity in the Company's allowance for doubtful accounts during fiscal years 2025, 2024 and 2023:

[0000866374-25-000027:notes:51]
|  | Balance atBeginningof Year |  | Charges (Recoveries) to Costs and Expenses(1) |  | Deductions/Write-Offs (2) |  | Balance atEnd ofYear |
|  | (In millions) |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended March 31, 2023 | $ | 52 |  |  | $ | 4 |  |  | $ | (50) |  |  | $ | 6 |  |
| Year ended March 31, 2024 | 6 |  |  | 9 |  |  | (3) |  |  | 12 |  |
| Year ended March 31, 2025 | 12 |  |  | (1) |  |  | (4) |  |  | 7 |  |

[0000866374-25-000027:notes:52]
(1)Charges and recoveries incurred during fiscal years 2025, 2024 and 2023 are primarily for costs and expenses or bad debt recoveries related to various distressed customers.

[0000866374-25-000027:notes:53]
(2)Deductions and write-offs during fiscal year 2023 is primarily as a result of a settlement reached with a certain former customer.

[0000866374-25-000027:notes:54]
No customer accounted for greater than 10% of the Company's net sales in fiscal years 2025, 2024 or 2023. No customer accounted for greater than 10% of the Company's total balance of accounts receivable, net as of the fiscal year ended March 31, 2025, March 31, 2024 or March 31, 2023.

[0000866374-25-000027:notes:55]
The Company's ten largest customers accounted for approximately 44%, 37% and 37%, of its net sales in fiscal years 2025, 2024 and 2023, respectively.

[0000866374-25-000027:notes:56]
Derivative Instruments

[0000866374-25-000027:notes:57]
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions. See additional discussion of derivatives in note 10.

[0000866374-25-000027:notes:58]
Cash and Cash Equivalents

[0000866374-25-000027:notes:59]
The Company maintains cash and cash equivalents with various financial institutions that management believes to be of high credit quality. These financial institutions are located in many different locations throughout the world. The Company's investment portfolio, which consists of short-term bank deposits and money market accounts, is classified as cash equivalents on the consolidated balance sheets.

[0000866374-25-000027:notes:60]
All highly liquid investments with maturities of three months or less from original dates of purchase are carried at cost, which approximates fair market value, and are considered to be cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, money market funds and time deposits.

[0000866374-25-000027:notes:61]
Cash and cash equivalents consisted of the following:

[0000866374-25-000027:notes:62]
|  | As of March 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Cash and bank balances | $ | 754 |  |  | $ | 1,715 |  |
| Money market funds and time deposits | 1,535 |  |  | 759 |  |
|  | $ | 2,289 |  |  | $ | 2,474 |  |

[0000866374-25-000027:notes:63]
Inventories

[0000866374-25-000027:notes:64]
Inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. The stated cost is comprised of direct materials, labor and overhead. The components of inventories, net of applicable lower of cost or net realizable value write-downs, were as follows:

[0000866374-25-000027:notes:65]
|  | As of March 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Raw materials | $ | 4,092 |  |  | $ | 5,045 |  |
| Work-in-progress | 485 |  |  | 623 |  |
| Finished goods | 494 |  |  | 537 |  |
|  | $ | 5,071 |  |  | $ | 6,205 |  |

[0000866374-25-000027:notes:66]
Property and Equipment, Net

[0000866374-25-000027:notes:67]
Property and equipment are stated at cost, less accumulated depreciation and amortization. Depreciation and amortization are recognized on a straight-line basis over the estimated useful lives of the related assets, with the exception of building leasehold improvements, which are depreciated over the term of the lease, if shorter. Repairs and maintenance costs are expensed as incurred. Property and equipment is comprised of the following:

[0000866374-25-000027:notes:68]
|  | DepreciableLife(In Years) |  | As of March 31, |
|  |  | 2025 |  | 2024 |
|  |  |  | (In millions) |
| Machinery and equipment | 2 - 10 |  | $ | 3,978 |  |  | $ | 3,960 |  |
| Buildings | 30 |  | 1,342 |  |  | 1,212 |  |
| Leasehold improvements | Shorter of lease term or useful life of the improvement |  | 669 |  |  | 651 |  |
| Furniture, fixtures, computer equipment and software, and other | 3 - 7 |  | 564 |  |  | 549 |  |
| Land | — |  | 126 |  |  | 123 |  |
| Construction-in-progress | — |  | 271 |  |  | 214 |  |
|  |  |  | 6,950 |  |  | 6,709 |  |
| Accumulated depreciation and amortization |  |  | (4,620) |  |  | (4,440) |  |
| Property and equipment, net |  |  | $ | 2,330 |  |  | $ | 2,269 |  |

[0000866374-25-000027:notes:69]
Total depreciation expense associated with property and equipment was approximately $439 million, $428 million and $411 million in fiscal years 2025, 2024 and 2023, respectively.

[0000866374-25-000027:notes:70]
The Company reviews property and equipment for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of property and equipment is determined by comparing its carrying amount to the lowest level of identifiable projected undiscounted cash flows the property and equipment are expected to generate. An impairment loss is recognized when the carrying amount of property and equipment exceeds its fair value.

[0000866374-25-000027:notes:71]
Deferred Income Taxes

[0000866374-25-000027:notes:72]
The Company provides for income taxes in accordance with the asset and liability method of accounting for income taxes. Under this method, deferred income taxes are recognized for the tax consequences of temporary differences between the carrying amount and the tax basis of existing assets and liabilities by applying the applicable statutory tax rate to such differences. Additionally, the Company assesses whether each income tax position is "more likely than not" of being sustained on audit, including resolution of related appeals or litigation, if any. For each income tax position that meets the "more likely than not" recognition threshold, the Company would then assess the largest amount of tax benefit that is greater than 50% likely of being realized upon effective settlement with the tax authority.

[0000866374-25-000027:notes:73]
Accounting for Business and Asset Acquisitions

[0000866374-25-000027:notes:74]
The Company has strategically pursued business and asset acquisitions. For business combinations, the fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax liabilities, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill and if the fair value of assets acquired and liabilities assumed exceeds the purchase consideration a gain on bargain purchase is recognized.

[0000866374-25-000027:notes:75]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. Changes to valuation allowances on acquired deferred tax assets are recognized in the provision for, or benefit from, income taxes. The valuation of these tangible and identifiable intangible assets and liabilities is subject to further management review and may change materially between the preliminary allocation and end of the purchase price allocation period. Any changes in these estimates may have a material effect on the Company's consolidated operating results or financial position.

[0000866374-25-000027:notes:76]
Goodwill

[0000866374-25-000027:notes:77]
The Company evaluates goodwill for impairment at the reporting unit level annually, and in certain circumstances such as a change in reporting units or whenever there are indications that goodwill might be impaired. The Company performed its annual goodwill impairment assessment on January 1, 2025 and as a result of the quantitative assessment of its goodwill, the Company determined that no impairment existed as of the date of the impairment test because the fair value of each one of its six reporting units exceeded its respective carrying value.

[0000866374-25-000027:notes:78]
Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which typically is measured based upon, among other factors, market valuations, market multiples for comparable companies as well as a discounted cash flow analysis. Certain of these approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require management to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider the Company's budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest rates, cost of capital, tax rates, market EBITDA comparable and credit ratings. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of the Company's goodwill.

[0000866374-25-000027:notes:79]
If the recorded value of the assets, including goodwill, and liabilities ("net book value") of any reporting unit exceeds its fair value, an impairment loss may be required to be recognized.

[0000866374-25-000027:notes:80]
The following table summarizes the activity in the Company's goodwill during fiscal years 2025 and 2024:

[0000866374-25-000027:notes:81]
|  |  | FAS |  | FRS |  |  |  | Total |
|  |  | (In millions) |
| Balance at March 31, 2023 |  | $ | 371 |  |  | $ | 768 |  |  |  |  | $ | 1,139 |  |
| Divestitures (1) |  | — |  |  | (1) |  |  |  |  | (1) |  |
| Foreign currency translation adjustments |  | — |  |  | (3) |  |  |  |  | (3) |  |
| Balance at March 31, 2024 |  | 371 |  |  | 764 |  |  |  |  | 1,135 |  |
| Acquisitions (2) |  | 39 |  |  | 170 |  |  |  |  | 209 |  |
| Foreign currency translation adjustments |  | — |  |  | (3) |  |  |  |  | (3) |  |
| Balance at March 31, 2025 |  | $ | 410 |  |  | $ | 931 |  |  |  |  | $ | 1,341 |  |

[0000866374-25-000027:notes:82]
(1)A reduction of approximately $1 million as a result of the divestiture of a non-strategic immaterial business within the FRS segment in fiscal year 2024.

[0000866374-25-000027:notes:83]
(2)Represents goodwill of $170 million from the Crown acquisition, $31 million from the JetCool acquisition and $8 million from an acquisition completed in the first quarter of fiscal year 2025. Refer to Note 19 for further details.

[0000866374-25-000027:notes:84]
Other Intangible Assets

[0000866374-25-000027:notes:85]
The Company's acquired intangible assets are subject to amortization over their estimated useful lives and are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an intangible asset may not be recoverable. An impairment loss is recognized when the carrying amount of an intangible asset exceeds its fair value. The Company reviewed the carrying value of its intangible assets as of March 31, 2025 and concluded that such amounts continued to be recoverable.

[0000866374-25-000027:notes:86]
Intangible assets are comprised of customer-related intangible assets that include contractual agreements and customer relationships, and licenses and other intangible assets that are primarily comprised of licenses, patents and trademarks, and developed technologies. Generally, both customer-related intangible assets and licenses and other intangible assets are amortized on a straight-line basis, over a period of up to ten years. No residual value is estimated for any intangible assets. The fair value of the Company's intangible assets purchased through business combinations is determined based on management's estimates of cash flow and recoverability. During fiscal year 2025, the total value of intangible assets increased by $165 million as a result of the Company's acquisitions during the period. These acquisitions contributed an additional $100 million in customer-related intangible assets and $65 million in licenses and other intangibles assets, such as trade names and technology. Refer to note 19 for additional information.

[0000866374-25-000027:notes:87]
The components of acquired intangible assets are as follows:

[0000866374-25-000027:notes:88]
|  | As of March 31, 2025 |  | As of March 31, 2024 |
|  | Weighted-Average Remaining Useful life (in Years) |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | NetCarryingAmount |
|  |  |  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | 8.3 |  | $ | 383 |  |  | $ | (186) |  |  | $ | 197 |  |  | $ | 316 |  |  | $ | (186) |  |  | $ | 130 |  |
| Licenses and other intangibles | 6.7 |  | 365 |  |  | (219) |  |  | 146 |  |  | 298 |  |  | (183) |  |  | 115 |  |
| Total |  |  | $ | 748 |  |  | $ | (405) |  |  | $ | 343 |  |  | $ | 614 |  |  | $ | (369) |  |  | $ | 245 |  |

[0000866374-25-000027:notes:89]
Total intangible asset amortization expense recognized in operations during fiscal years 2025, 2024 and 2023 was $70 million, $70 million and $81 million, respectively. The gross carrying amounts of intangible assets are removed when fully amortized. During fiscal year 2025, the gross carrying amounts of fully amortized intangible assets totaled $31 million. The estimated future annual amortization expense for acquired intangible assets is as follows:

[0000866374-25-000027:notes:90]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2026 | $ | 67 |  |
| 2027 | 57 |  |
| 2028 | 43 |  |
| 2029 | 40 |  |
| 2030 | 35 |  |
| Thereafter | 101 |  |
| Total amortization expense | $ | 343 |  |

[0000866374-25-000027:notes:91]
The Company owns or licenses various United States and foreign patents relating to a variety of technologies. For certain of the Company's proprietary processes, inventions, and works of authorship, the Company relies on trade secret or copyright protection. The Company also maintains trademark rights (including registrations) for the Company's corporate name and several other trademarks and service marks that the Company uses in the Company's business in the United States and other countries throughout the world. The Company has policies and procedures (including both technological means and training programs for the Company's employees) to identify and protect the Company's intellectual property, as well as that of the Company's customers and suppliers.

[0000866374-25-000027:notes:92]
Derivative Instruments and Hedging Activities

[0000866374-25-000027:notes:93]
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows. Additional information is included in note 10.

[0000866374-25-000027:notes:94]
Investments

[0000866374-25-000027:notes:95]
The Company has an investment portfolio that consists of strategic investments in privately held companies, and certain venture capital funds which are included within other non-current assets. These privately held companies range from startups to more mature companies with established revenue streams and business models. As of March 31, 2025, and 2024, the Company's investments in non-consolidated companies totaled $119 million and $123 million, respectively.

[0000866374-25-000027:notes:96]
The Company recognized $3 million of equity in losses and $8 million of equity in earnings, associated with its equity method investments, in Equity in earnings (losses) of unconsolidated affiliates on the consolidated statements of operations during fiscal years 2025 and 2024, respectively.

[0000866374-25-000027:notes:97]
Non-consolidated investments in entities are accounted for using the equity method when the Company has an investment in common stock or in-substance common stock, and either (a) has the ability to significantly influence the operating decisions of the issuer, or (b) if the Company has a voting percentage generally equal to or greater than 20% but less than 50%, and for non-majority-owned investments in partnerships when generally greater than 5%. Cost method is used for investments where the Company does not have the ability to significantly influence the operating decisions of the investee, or if the Company’s investment is in securities other than common stock or in-substance common stock.

[0000866374-25-000027:notes:98]
The Company monitors these investments for impairment indicators and makes appropriate reductions in carrying values as required whenever events or changes in circumstances indicate that the assets may be impaired. The factors the Company

[0000866374-25-000027:notes:99]
considers in its evaluation of potential impairment of its investments include, but are not limited to, a significant deterioration in the earnings performance or business prospects of the investee, or factors that raise significant concerns about the investee’s ability to continue as a going concern, such as negative cash flows from operation or working capital deficiencies. Fair values of these investments, when required, are estimated using unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy, and require management to make various judgmental assumptions primarily about comparable company multiples and discounted cash flow projections. Some of the inherent estimates and assumptions used in determining the fair value of the investments are outside the control of management. While the Company believes it has made reasonable estimates and assumptions to calculate the fair value of the investments, it is possible a material change could occur. If the actual results are not consistent with management's estimates and assumptions used to calculate fair value, it could result in material impairments of investments.

[0000866374-25-000027:notes:100]
For investments accounted for under the cost method that do not have readily determinable fair values, the Company measures them at cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar investment of the same issuer.

[0000866374-25-000027:notes:101]
Customer Working Capital Advances

[0000866374-25-000027:notes:102]
Customer working capital advances were $1.6 billion and $2.2 billion, as of March 31, 2025 and 2024, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-25-000027:notes:103]
Other non-current assets

[0000866374-25-000027:notes:104]
Other non-current assets include deferred tax assets of $577 million and $644 million as of March 31, 2025 and 2024, respectively.

[0000866374-25-000027:notes:105]
Other Current Liabilities

[0000866374-25-000027:notes:106]
Other current liabilities include customer-related accruals of $246 million and $277 million as of March 31, 2025 and 2024, respectively.

[0000866374-25-000027:notes:107]
Supplier Finance Programs

[0000866374-25-000027:notes:108]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

[0000866374-25-000027:notes:109]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statements of cash flows. The roll-forward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the

[0000866374-25-000027:notes:110]
fiscal years ended March 31, 2025 and March 31, 2024 are as follows:

[0000866374-25-000027:notes:111]
|  |  | Fiscal Year Ended |
|  |  | March 31, 2025 |  | March 31, 2024 |
|  |  | (In millions) |
| Confirmed obligations outstanding at the beginning of the year |  | $ | 123 |  |  | $ | 157 |  |
| Invoices confirmed during the year |  | 574 |  |  | 604 |  |
| Confirmed invoices paid during the year |  | (569) |  |  | (643) |  |
| Foreign currency exchange impact |  | (9) |  |  | 5 |  |
| Confirmed obligations outstanding at the end of the year |  | $ | 119 |  |  | $ | 123 |  |

[0000866374-25-000027:notes:112]
Leases

[0000866374-25-000027:notes:113]
The Company is a lessee with several non-cancellable operating leases, primarily for warehouses, buildings, and other assets such as vehicles and equipment. The Company determines if an arrangement is a lease at contract inception. A contract is a lease or contains a lease when (1) there is an identified asset, and (2) the Company has the right to control the use of the identified asset. The Company recognizes a right-of-use ("ROU") asset and a lease liability at the lease commencement date for the Company's operating leases. For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at the lease commencement date. The Company has elected the short-term lease recognition and measurement exemption for all classes of assets, which allows the Company to not recognize ROU assets and lease liabilities for leases with a lease term of 12 months or less and with no purchase option the Company is reasonably certain of exercising. The Company has also elected the practical expedient to account for the lease and non-lease components as a single lease component, for all classes of underlying assets. Therefore, the lease payments used to measure the lease liability include all of the fixed considerations in the contract. Lease payments included in the measurement of the lease liability comprise the following: fixed payments (including in-substance fixed payments), and variable payments that depend on an index or rate (initially measured using the index or rate at the lease commencement date). As the Company cannot determine the interest rate implicit in the lease for the Company's leases, the Company uses the Company's estimate of the incremental borrowing rate as of the commencement date in determining the present value of lease payments. The Company's estimated incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. The lease term for all of the Company's leases includes the non-cancellable period of the lease plus any additional periods covered by either an option to extend (or not to terminate) the lease that the Company is reasonably certain to exercise, or an option to extend (or not to terminate) the lease controlled by the lessor.

[0000866374-25-000027:notes:114]
As of March 31, 2025 and 2024, current operating lease liabilities were $135 million and $136 million, respectively, which are included in other current liabilities on the consolidated balance sheets.

[0000866374-25-000027:notes:115]
Restructuring Charges

[0000866374-25-000027:notes:116]
The Company recognizes restructuring charges related to its plans to close or consolidate excess manufacturing facilities and reduce excess workforce capacity. In connection with these activities, the Company records restructuring charges for employee termination costs, long-lived asset impairment and other exit-related costs.

[0000866374-25-000027:notes:117]
The recognition of restructuring charges requires the Company to make certain judgments and estimates regarding the nature, timing and amount of costs associated with the planned exit activity. To the extent the Company's actual results differ from its estimates and assumptions, the Company may be required to revise the estimates of future liabilities, requiring the recognition of additional restructuring charges or the reduction of liabilities already recognized. Such changes to previously estimated amounts may be material to the consolidated financial statements. At the end of each reporting period, the Company evaluates the remaining accrued balances to ensure that no excess accruals are retained, and the utilization of the provisions are for their intended purpose in accordance with developed restructuring plans. See note 16 for additional information regarding restructuring charges.

[0000866374-25-000027:notes:118]
Recently Issued Accounting Pronouncements

[0000866374-25-000027:notes:119]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. We are currently evaluating the guidance to determine the impact on the Company's disclosures. In January 2025,

[0000866374-25-000027:notes:120]
the FASB issued ASU 2025-01 on the same topic to clarify the amendments for ASU 2024-03 are effective for the Company in the fourth quarter of fiscal year 2028.

[0000866374-25-000027:notes:121]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-25-000027:notes:122]
Recently Adopted Accounting Pronouncements

[0000866374-25-000027:notes:123]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025. The Company adopted the guidance retrospectively during the fourth quarter of fiscal year 2025. See note 21 for additional reportable segment disclosures.


## us-gaap:DerivativesPolicyTextBlock

[0000866374-25-000027:notes:124]
Derivative Instruments
The amount subject to credit risk related to derivative instruments is generally limited to the amount, if any, by which a counterparty's obligations exceed the obligations of the Company with that counterparty. To manage counterparty risk, the Company limits its derivative transactions to those with recognized financial institutions.
Derivative Instruments and Hedging Activities
All derivative instruments are recognized on the consolidated balance sheets at fair value. If the derivative instrument is designated as a cash flow hedge, effectiveness is tested monthly using a regression analysis of the change in spot currency rates and the change in present value of the spot currency rates. The spot currency rates are discounted to present value using functional currency Inter-bank Offering Rates over the maximum length of the hedge period. The effective portion of changes in the fair value of the derivative instrument (excluding time value) is recognized in shareholders' equity as a separate component of accumulated other comprehensive income (loss), and recognized in the consolidated statements of operations when the hedged item affects earnings. Ineffective and excluded portions of changes in the fair value of cash flow hedges are recognized in earnings immediately. If the derivative instrument is designated as a fair value hedge, the changes in the fair value of the derivative instrument and of the hedged item attributable to the hedged risk are recognized in earnings in the current period. Cash receipts and cash payments related to derivative instruments are recorded in the same category as the cash flows from the items being hedged on the consolidated statements of cash flows.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000866374-25-000027:notes:125]
LEASES
The Company has several commitments under operating leases for warehouses, buildings, and equipment. The Company also has a number of finance leases with an immaterial impact on its consolidated financial statements. Leases have remaining lease terms ranging from approximately 1 year to 19 years.

[0000866374-25-000027:notes:126]
The components of lease cost recognized were as follow (in millions):

[0000866374-25-000027:notes:127]
| Lease cost | Fiscal Year Ended |
|  | March 31, 2025 |  | March 31, 2024 |
| Operating lease cost | $ | 173 |  |  | $ | 167 |  |

[0000866374-25-000027:notes:128]
Amounts reported in the consolidated balance sheet as of the fiscal years ended March 31, 2025 and 2024 were (in millions, except weighted average lease term and discount rate):

[0000866374-25-000027:notes:129]
|  | As of March 31, 2025 |  | As of March 31, 2024 |
| Operating Leases: |  |  |  |
| Operating lease right of use assets | $ | 562 |  | $ | 601 |
| Operating lease liabilities * | 591 |  | 626 |
| Weighted-average remaining lease term (In years) |  |  |  |
| Operating leases | 6.0 |  | 6.3 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 4.4 | % |  | 4.4 | % |

[0000866374-25-000027:notes:130]
* Operating lease liabilities includes $135 million current lease liabilities and $456 million non-current lease liabilities.

[0000866374-25-000027:notes:131]
Other information related to leases was as follow (in millions):

[0000866374-25-000027:notes:132]
|  | Fiscal Year Ended |
|  | March 31, 2025 |  | March 31, 2024 |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 168 |  |  | $ | 160 |  |
| Right‑of‑use assets obtained in exchange for lease liabilities |  |  |  |
| Operating Lease | $ | 106 |  |  | $ | 134 |  |

[0000866374-25-000027:notes:133]
Future lease payments under non-cancellable leases as of March 31, 2025 were as follows (in millions):

[0000866374-25-000027:notes:134]
| Fiscal Year Ended March 31, | Operating Leases |
| 2026 | $ | 158 |  |
| 2027 | 126 |  |
| 2028 | 106 |  |
| 2029 | 84 |  |
| 2030 | 62 |  |
| Thereafter | 134 |  |
| Total undiscounted lease payments | 670 |  |
| Less: imputed interest | 79 |  |
| Total lease liabilities | $ | 591 |  |

[0000866374-25-000027:notes:135]
Total rent expense amounted to $194 million, $188 million and $182 million in fiscal years 2025, 2024 and 2023, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-25-000027:notes:136]
REVENUE
Revenue Recognition

[0000866374-25-000027:notes:137]
The Company provides a comprehensive suite of services for its customers that range from advanced product design to manufacturing and logistics to after-sales services. The first step in its process for revenue recognition is to identify a contract with a customer. A contract is defined as an agreement between two parties that creates enforceable rights and obligations and can be written, verbal, or implied. The Company generally enters into master supply agreements ("MSAs") with its customers that provide the framework under which business will be conducted. This includes matters such as warranty, indemnification, transfer of title and risk of loss, liability for excess and obsolete inventory, pricing formulas, payment terms, etc., and the level of business under those agreements may not be guaranteed. In those instances, the Company bids on a program-by-program basis and typically receives customer purchase orders for specific quantities and timing of products. As a result, the Company considers its contract with a customer to be the combination of the MSA and the purchase order, or any other similar documents such as a statement of work, product addendum, forecast commitments, emails or other communications that embody the commitment by the customer.

[0000866374-25-000027:notes:138]
In determining the appropriate amount of revenue to recognize, the Company applies the following steps: (i) identifies the contracts with the customers; (ii) identifies performance obligations in the contracts; (iii) determines the transaction price; (iv) allocates the transaction price to the performance obligations per the contracts; and (v) recognizes revenue when (or as) the Company satisfies a performance obligation. Further, the Company assesses whether control of the products or services promised under the contract are transferred to the customer at a point in time (PIT) or over time (OT). The Company is first required to evaluate whether its contracts meet the criteria for OT recognition. The Company has determined that for a portion of its contracts the Company is manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and the Company has an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer measured based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, the Company recognizes revenue when it has transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method.

[0000866374-25-000027:notes:139]
Customer Contracts and Related Obligations

[0000866374-25-000027:notes:140]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. The Company estimates the variable consideration related to these price adjustments as part of the total transaction price and recognizes revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. The Company constrains the amount of revenues recognized for these contractual provisions based on its best estimate of the

[0000866374-25-000027:notes:141]
amount which will not result in a significant reversal of revenue in a future period. The Company determines the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Often these obligations are settled with the customer in a period after shipment through various methods which include reduction of prices for future purchases, issuance of a payment to the customer, or issuance of a credit note applied against the customer’s accounts receivable balance. In many instances, the agreement is silent on the settlement mechanism. Any difference between the amount accrued for potential refunds and the actual amount agreed to with the customer is recorded as an increase or decrease in revenue. These potential price adjustments are included as part of other current liabilities on the consolidated balance sheet and disclosed as part of customer-related accruals in note 2.

[0000866374-25-000027:notes:142]
Performance Obligations

[0000866374-25-000027:notes:143]
The Company derives its revenues primarily from manufacturing services, and to a lesser extent, from innovative design, engineering, and supply chain services and solutions.

[0000866374-25-000027:notes:144]
A performance obligation is an implicitly or explicitly promised good or service that is material in the context of the contract and is both capable of being distinct (customer can benefit from the good or service on its own or together with other readily available resources) and distinct within the context of the contract (separately identifiable from other promises). The Company considers all activities typically included in its contracts, and identifies those activities representing a promise to transfer goods or services to a customer. These include, but are not limited to, design and engineering services, prototype products, tooling, etc. Each promised good or service with regards to these identified activities is accounted for as a separate performance obligation only if it is distinct - i.e., the customer can benefit from it on its own or together with other resources that are readily available to the customer. Certain activities on the other hand are determined not to constitute a promise to transfer goods or service, and therefore do not represent separate performance obligations for revenue recognition (e.g., procurement of materials and standard workmanship warranty).

[0000866374-25-000027:notes:145]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. Promised goods or services that are immaterial in the context of the contract are not separately assessed as performance obligations. In the event that more than one performance obligation is identified in a contract, the Company is required to allocate the transaction price between the performance obligations. The allocation would generally be performed on the basis of a relative standalone price for each distinct good or service. This standalone price most often represents the price that the Company would sell similar goods or services separately.

[0000866374-25-000027:notes:146]
Contract Balances

[0000866374-25-000027:notes:147]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to receivables when rights to payment become unconditional and invoiced.

[0000866374-25-000027:notes:148]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $377 million and $490 million as of March 31, 2025 and 2024, respectively, of which $347 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-25-000027:notes:149]
Disaggregation of Revenue

[0000866374-25-000027:notes:150]
The following table presents the Company’s revenue disaggregated based on timing of transfer - PIT and OT for the fiscal years ended March 31, 2025, 2024 and 2023:

[0000866374-25-000027:notes:151]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |
| Point in time | $ | 11,303 |  |  | $ | 12,811 |  |  | $ | 14,942 |  |
| Over time | 2,771 |  |  | 1,112 |  |  | 827 |  |
| Total | 14,074 |  |  | 13,923 |  |  | 15,769 |  |
| FRS |  |  |  |  |  |
| Point in time | 8,778 |  |  | 11,706 |  |  | 12,004 |  |
| Over time | 2,961 |  |  | 786 |  |  | 729 |  |
| Total | 11,739 |  |  | 12,492 |  |  | 12,733 |  |
| Flex |  |  |  |  |  |
| Point in time | 20,081 |  |  | 24,517 |  |  | 26,946 |  |
| Over time | 5,732 |  |  | 1,898 |  |  | 1,556 |  |
| Total | $ | 25,813 |  |  | $ | 26,415 |  |  | $ | 28,502 |  |

[0000866374-25-000027:notes:152]
During the year ended March 31, 2025, certain existing customer contractual relationships were changed to provide an enforceable right to payment for work completed to date that had the effect of transitioning revenue with those customers from being recognized on a point in time to an over time basis, with prospective effect. This change had the effect of increasing contract assets by $232 million as of March 31, 2025. Contract assets are generally transferred to receivables in the succeeding quarter due to the short-term nature of the Company’s manufacturing cycle.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-25-000027:notes:153]
SHARE-BASED COMPENSATION
Equity Compensation Plan

[0000866374-25-000027:notes:154]
Flex historically maintains stock-based compensation plans at the corporate level. The Company grants equity compensation awards under its 2017 Equity Incentive Plan (as amended, the "2017 Plan").

[0000866374-25-000027:notes:155]
Stock-Based Compensation Expense

[0000866374-25-000027:notes:156]
The following table summarizes the Company's stock-based compensation expense for the 2017 Plan:

[0000866374-25-000027:notes:157]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Cost of sales | $ | 32 |  |  | $ | 28 |  |  | $ | 24 |  |
| Selling, general and administrative expenses | 93 |  |  | 85 |  |  | 77 |  |
| Total share-based compensation expense | $ | 125 |  |  | $ | 113 |  |  | $ | 101 |  |

[0000866374-25-000027:notes:158]
Cash flows related to tax benefits from stock-based compensation are classified as operating cash flows. During fiscal year 2025, the Company recognized $14 million of tax benefit associated with stock-based compensation expense as an operating cash inflow. No such tax benefits were recognized in fiscal years 2024 and 2023.

[0000866374-25-000027:notes:159]
The 2017 Plan

[0000866374-25-000027:notes:160]
As of March 31, 2025, the Company had approximately 18.4 million shares available for grant under the 2017 Plan. The Company grants restricted share unit ("RSU") awards under its 2017 Plan. RSU awards are rights to acquire a specified number of ordinary shares for no cash consideration in exchange for continued service with the Company. RSU awards generally vest in installments over three years, and unvested RSU awards are generally forfeited upon termination of employment.

[0000866374-25-000027:notes:161]
Vesting for certain RSU awards is contingent upon both service and market conditions or both service and performance conditions.

[0000866374-25-000027:notes:162]
As of March 31, 2025, the total unrecognized compensation cost related to unvested RSU awards under the 2017 Plan was approximately $196 million. These costs will be amortized generally on a straight-line basis over a weighted-average period of approximately two years. Approximately $14 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain market conditions. Approximately $16 million of the total unrecognized compensation cost is related to RSU awards granted to certain key employees whereby vesting is contingent on meeting certain performance conditions.

[0000866374-25-000027:notes:163]
Determining Fair Value - RSU awards

[0000866374-25-000027:notes:164]
Valuation and Amortization Method—The fair market value of RSU awards granted, other than those awards with a market condition, is the closing price of the Company's ordinary shares on the date of grant and is generally recognized as compensation expense on a straight-line basis over the respective vesting period.

[0000866374-25-000027:notes:165]
Determining Fair Value - RSU awards with service and market conditions

[0000866374-25-000027:notes:166]
Valuation and Amortization Method—The Company estimates the fair value of RSU awards granted under the 2017 Plan whereby vesting is contingent on meeting certain market conditions using Monte Carlo simulation. This fair value is then amortized on a straight-line basis over the vesting period, which is the service period.

[0000866374-25-000027:notes:167]
Expected Volatility of Flex—Volatility used in a Monte Carlo simulation is derived from the historical volatility of Flex's stock price over a period equal to the service period of the RSU awards granted. The service period is three years for those RSU awards granted in fiscal years 2025, 2024, and 2023.

[0000866374-25-000027:notes:168]
Average Peer Volatility—Volatility used in a Monte Carlo simulation is derived from the historical volatilities of Flex's peer companies for the RSU awards granted in fiscal years 2025, 2024, and 2023.

[0000866374-25-000027:notes:169]
Average Peer Correlation—Correlation coefficients were used to model the movement of Flex's stock price relative to Flex's peer companies for the RSU awards granted in fiscal years 2025, 2024, and 2023.

[0000866374-25-000027:notes:170]
Expected Dividend —The Company has never paid dividends on its ordinary shares and accordingly the dividend yield percentage is zero for all periods.

[0000866374-25-000027:notes:171]
Risk-Free Interest Rate assumptions—The Company bases the risk-free interest rate used in the Monte Carlo simulation on the implied yield currently available on U.S. Treasury constant maturities issued with a term equivalent to the expected term of the RSU awards.

[0000866374-25-000027:notes:172]
The fair value of the Company's RSU awards under the 2017 Plan, whereby vesting is contingent on meeting certain market conditions, for fiscal years 2025, 2024, and 2023 was estimated using the following weighted-average assumptions:

[0000866374-25-000027:notes:173]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Expected volatility | 34.6 | % |  | 36.9 | % |  | 49.0 | % |
| Average peer volatility | 34.0 | % |  | 35.2 | % |  | 41.4 | % |
| Average peer correlation | 0.3 |  | 0.4 |  | 0.4 |
| Risk-free interest rate | 4.4 | % |  | 4.3 | % |  | 3.0 | % |

[0000866374-25-000027:notes:174]
Share-Based Awards Activity

[0000866374-25-000027:notes:175]
The following table summarizes the Company's RSU award activity under the 2017 Plan ("Price" reflects the weighted-average grant-date fair value):

[0000866374-25-000027:notes:176]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | Shares |  | Price |  | Shares |  | Price |  | Shares |  | Price |
| Unvested RSU awards outstanding, beginning of fiscal year | 15,367,056 |  |  | $ | 17.73 |  |  | 15,348,615 |  |  | $ | 16.79 |  |  | 17,019,559 |  |  | $ | 14.13 |  |
| Granted (1) | 5,747,499 |  |  | 33.38 |  |  | 6,162,067 |  |  | 27.86 |  |  | 8,416,650 |  |  | 18.22 |  |
| Vested (1) | (8,213,127) |  |  | 16.46 |  |  | (8,529,857) |  |  | 14.34 |  |  | (9,229,198) |  |  | 12.51 |  |
| Forfeited (2) | (1,170,193) |  |  | 20.88 |  |  | (994,150) |  |  | 19.76 |  |  | (858,396) |  |  | 15.31 |  |
| Adjustment due to the Nextracker spin-off (3) | — |  |  |  |  | 3,380,381 |  |  |  |  | — |  |  |  |
| Unvested RSU awards outstanding, end of fiscal year (4) | 11,731,235 |  |  | $ | 24.96 |  |  | 15,367,056 |  |  | $ | 17.73 |  |  | 15,348,615 |  |  | $ | 16.79 |  |

[0000866374-25-000027:notes:177]
(1)Included in fiscal years 2025, 2024 and 2023, amounts are 0.7 million, 1.2 million and 1.2 million of share bonus awards representing the number of awards achieved above target levels based on the achievement of certain market and performance conditions for awards granted in fiscal years 2022, 2021 and 2020, respectively. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-25-000027:notes:178]
(2)Includes immaterial RSU awards previously granted to Nextracker employees under the 2017 Plan canceled due to the Nextracker spin-off.

[0000866374-25-000027:notes:179]
(3)Represents an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Nextracker spin-off.

[0000866374-25-000027:notes:180]
(4)The weighted-average grant date fair value of the RSUs included in the line item "Adjustment due to the Nextracker spin-off" is equal to the weighted-average grant date fair value of the awards at their respective grant date divided by a factor of approximately 1.29. The weighted-average grant date fair value of the unvested RSUs as of March 31, 2024 reflects the adjustment.

[0000866374-25-000027:notes:181]
Of the 5.7 million unvested RSU awards granted in fiscal year 2025, approximately 4.0 million are plain-vanilla unvested RSU awards with no performance or market conditions with an average grant date price of $33.08 per share. Further, approximately 0.3 million of these unvested RSU awards granted in fiscal year 2025 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions, with an average grant date fair value estimated to be $42.36 per award calculated using a Monte Carlo simulation. Vesting information for these shares is further detailed in the table below.

[0000866374-25-000027:notes:182]
Of the 11.7 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2025, approximately 1.2 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain market conditions summarized as follows:

[0000866374-25-000027:notes:183]
|  |  | Targetnumber ofawards as ofMarch 31, 2025(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment dates |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2025 |  | 283,002 |  |  | $ | 42.36 |  |  |  |  | — |  |  | 566,004 |  |  | June 2027 |
| Fiscal 2024 |  | 386,668 |  |  | $ | 35.55 |  |  |  |  | — |  |  | 773,336 |  |  | June 2026 |
| Fiscal 2023 |  | 539,204 |  |  | $ | 23.45 |  |  |  |  | — |  |  | 1,078,408 |  |  | June 2025 |
| Totals |  | 1,208,874 |  |  |  |  |  |  |  |  | 2,417,748 |  |  |  |

[0000866374-25-000027:notes:184]
(1)    Includes an adjustment to the outstanding RSU awards under the terms of the 2017 Plan using a conversion ratio of approximately 1.29 as a result of the Nextracker spin-off.

[0000866374-25-000027:notes:185]
(2)    Vesting ranges from zero to 200% based on measurement of Flex's total shareholder return against Flex's peer companies for RSU awards granted in fiscal years 2025, 2024 and 2023.

[0000866374-25-000027:notes:186]
The Company will continue to recognize share-based compensation expense for awards with market conditions regardless of whether such awards will ultimately vest. During fiscal year 2025, 1.6 million shares vested in connection with the awards with market and performance conditions granted in fiscal year 2022.

[0000866374-25-000027:notes:187]
Approximately 0.7 million of these unvested RSU awards granted in fiscal year 2025 represents the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, with an average grant date price of $31.14 per share. Vesting information for these shares is further detailed in the table below.

[0000866374-25-000027:notes:188]
Of the 11.7 million unvested RSU awards outstanding under the 2017 Plan as of the fiscal year ended March 31, 2025, approximately 1.6 million unvested RSU awards represents the target amount of grants made to certain key employees whereby vesting is contingent on meeting certain performance conditions summarized as follows:

[0000866374-25-000027:notes:189]
|  |  | Targetnumber ofawards as ofMarch 31, 2025(in shares) (1) |  |  |  |  |  | Range of sharesthat may be issued (2) |  |  |
|  |  | Averagegrant datefair value(per share) |  |  |  |  |
|  |  |  |  | Assessment date |
| Year of grant |  |  |  | Minimum |  | Maximum |  |
| Fiscal 2025 |  | 683,786 |  |  | $ | 31.14 |  |  |  |  | — |  |  | 1,119,404 |  |  | Mar 2028 |
| Fiscal 2024 |  | 386,965 |  |  | $ | 26.67 |  |  |  |  | — |  |  | 773,930 |  |  | Mar 2027 |
| Fiscal 2023 |  | 539,606 |  |  | $ | 16.52 |  |  |  |  | — |  |  | 1,079,212 |  |  | Mar 2026 |
| Totals |  | 1,610,357 |  |  |  |  |  |  |  |  | 2,972,546 |  |  |  |

[0000866374-25-000027:notes:190]
(2)    Vesting ranges from zero to 200% based on performance of Company's average adjusted earnings per share growth and for certain awards vesting ranges from zero to 100% based on Company's adjusted operating profit goals.

[0000866374-25-000027:notes:191]
The total intrinsic value of RSU awards vested under the Company's 2017 Plan was $260 million, $227 million and $148 million during fiscal years 2025, 2024 and 2023, respectively, based on the closing price of the Company's ordinary shares on the date vested.


## us-gaap:EarningsPerShareTextBlock

[0000866374-25-000027:notes:192]
EARNINGS PER SHARE
Basic earnings per share excludes dilution and is computed by dividing net income by the weighted-average number of ordinary shares outstanding during the applicable periods.

[0000866374-25-000027:notes:193]
Diluted earnings per share reflects the potential dilution from share-based compensation awards. The potential dilution from restricted share unit awards was computed using the treasury stock method based on the average fair market value of the Company's ordinary shares for the period.

[0000866374-25-000027:notes:194]
The computation of earnings per share and weighted average shares outstanding of the Company’s ordinary shares for the following periods is presented below:

[0000866374-25-000027:notes:195]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions, except per share amounts) |
| Numerator: |  |  |  |  |  |
| Net income from continuing operations | $ | 838 |  |  | $ | 872 |  |  | $ | 683 |  |
| Net income from discontinued operations, net of tax (Note 7) | — |  |  | 373 |  |  | 350 |  |
| Less: Net income attributable to noncontrolling interest and redeemable noncontrolling interest (Note 7) | — |  |  | 239 |  |  | 240 |  |
| Net income from discontinued operations attributable to Flex Ltd. (Note 7) | — |  |  | 134 |  |  | 110 |  |
| Total net income attributable to Flex Ltd. | $ | 838 |  |  | $ | 1,006 |  |  | $ | 793 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average ordinary shares outstanding - basic | 391 |  |  | 435 |  |  | 454 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 7 |  |  | 6 |  |  | 8 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding - diluted | 398 |  |  | 441 |  |  | 462 |  |
| Earnings per share - basic |  |  |  |  |  |
| Continuing operations | $ | 2.14 |  |  | $ | 2.00 |  |  | $ | 1.50 |  |
| Discontinued operations, net of tax (Note 7) | — |  |  | 0.31 |  |  | 0.25 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.14 |  |  | $ | 2.31 |  |  | $ | 1.75 |  |
| Earnings per share - diluted |  |  |  |  |  |
| Continuing operations | $ | 2.11 |  |  | $ | 1.98 |  |  | $ | 1.48 |  |
| Discontinued operations, net of tax (Note 7) | — |  |  | 0.30 |  |  | 0.24 |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 2.11 |  |  | $ | 2.28 |  |  | $ | 1.72 |  |

[0000866374-25-000027:notes:196]
(1)An immaterial amount of RSU awards during fiscal years 2025, 2024, and 2023, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted average ordinary shares equivalents.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000866374-25-000027:notes:197]
DISCONTINUED OPERATIONS
On January 2, 2024, Flex completed the spin-off of our remaining interests in Nextracker to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution.

[0000866374-25-000027:notes:198]
Nextracker's financial results for periods prior to the spin-off have been reflected in our consolidated statement of operations, retrospectively, as discontinued operations. Details of net income from discontinued operations included in our consolidated statements of operations are as follows:

[0000866374-25-000027:notes:199]
|  |  |  | Fiscal Year Ended March 31, |
|  |  |  | 2024 (1) |  | 2023 |
|  |  |  | (In millions) |
| Net sales (2) |  |  | $ | 1,664 |  |  | $ | 1,844 |  |
| Cost of sales (2) |  |  | 1,198 |  |  | 1,555 |  |
| Gross profit |  |  | 466 |  |  | 289 |  |
| Selling, general and administrative expenses |  |  | 145 |  |  | 121 |  |
| Intangible amortization |  |  | — |  |  | 1 |  |
| Operating income |  |  | 321 |  |  | 167 |  |
| Interest, net |  |  | 1 |  |  | 1 |  |
| Other charges (income), net |  |  | (2) |  |  | (1) |  |
| Income before income taxes |  |  | 322 |  |  | 167 |  |
| (Benefit from) provision for income taxes |  |  | (51) |  |  | (183) |  |
| Net income from discontinued operations |  |  | 373 |  |  | 350 |  |
| Net income from discontinued operations attributable to noncontrolling interest and redeemable noncontrolling interest (3) |  |  | 239 |  |  | 240 |  |
| Net income from discontinued operations attributable to Flex Ltd. |  |  | $ | 134 |  |  | $ | 110 |  |

[0000866374-25-000027:notes:200]
(1)Represents the financial results for the nine-month period prior to the Nextracker spin-off. The financial results for the period from January 1, 2024 to the spin-off date were immaterial.

[0000866374-25-000027:notes:201]
(2)Both net sales and cost of sales from discontinued operations includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of approximately $99 million and $59 million for fiscal years ended March 31, 2024 and 2023, respectively.

[0000866374-25-000027:notes:202]
(3)Net income from discontinued operations attributable to noncontrolling interest represented a share of pre-tax income of $145 million and zero and of income tax benefits of $94 million and $197 million and distributions to redeemable noncontrolling interest of zero and $43 million for the fiscal years ended March 31, 2024 and 2023, respectively. As such, pre-tax income attributable to Flex Ltd. from discontinued operations was $177 million and $167 million for the same periods.

[0000866374-25-000027:notes:203]
Details of cash flows from discontinued operations are as follows:

[0000866374-25-000027:notes:204]
|  |  |  | Fiscal Year Ended March 31, |
|  |  |  | 2024 (1) |  | 2023 |
|  |  |  | (In millions) |
| Net cash provided by (used in) discontinued operations operating activities (2) |  |  | $ | 317 |  |  | $ | 108 |  |
| Net cash used in discontinued operations investing activities |  |  | (4) |  |  | (3) |  |

[0000866374-25-000027:notes:205]
(1)Represents the financial results for the nine-month period prior to the Nextracker spin-off.

[0000866374-25-000027:notes:206]
(2)Cash flows from discontinued operations operating activities includes the effect of intercompany transactions that were eliminated from Flex's consolidated operations of $54 million and ($23) million for the fiscal years ended March 31, 2024 and 2023, respectively.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000866374-25-000027:notes:207]
SUPPLEMENTAL CASH FLOW DISCLOSURES
The following table represents supplemental cash flow disclosures and non-cash investing and financing activities:

[0000866374-25-000027:notes:208]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Net cash paid for: |  |  |  |  |  |
| Interest | $ | 214 |  |  | $ | 226 |  |  | $ | 227 |  |
| Income taxes | 184 |  |  | 243 |  |  | 124 |  |
| Non-cash investing and financing activity: |  |  |  |  |  |
| Unpaid purchases of property and equipment | $ | 136 |  |  | $ | 97 |  |  | $ | 184 |  |
| Pre-IPO paid-in-kind dividend to redeemable noncontrolling interest | — |  |  | — |  |  | 21 |  |


## us-gaap:DebtDisclosureTextBlock

[0000866374-25-000027:notes:209]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt are as follows:

[0000866374-25-000027:notes:210]
|  | Maturity Date |  | As of March 31, |
|  |  |  | 2025 |  | 2024 |
|  |  |  | (In millions) |
| 4.750% Notes ("2025 Notes") (1) | June 2025 |  | 531 |  |  | 584 |  |
| 3.750% Notes ("2026 Notes") (1) | February 2026 |  | 678 |  |  | 682 |  |
| 6.000% Notes ("2028 Notes") (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes ("2029 Notes") (1) | June 2029 |  | 655 |  |  | 657 |  |
| 4.875% Notes ("2030 Notes") (1) | May 2030 |  | 676 |  |  | 681 |  |
| 5.250% Notes ("2032 Notes") (1)(2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 269 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (14) |  |  | (15) |  |
|  |  |  | 3,692 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (1,209) |  |  | — |  |
| Non-current portion |  |  | $ | 2,483 |  |  | $ | 3,261 |  |

[0000866374-25-000027:notes:211]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.

[0000866374-25-000027:notes:212]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.

[0000866374-25-000027:notes:213]
(3)In December 2021, the Company issued HUF 100 billion (approximately $269 million as of March 31, 2025) in aggregate principal amount of bonds under the National Bank of Hungary’s Bond Funding for Growth Scheme. The bonds are unsecured and unsubordinated obligations of the Company and rank equally with all of the Company’s other existing and future unsecured and unsubordinated obligations. The outstanding principal amount of the bonds bear interest at 3.60% per annum. The proceeds of the bonds were used for general corporate purposes. The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

[0000866374-25-000027:notes:214]
Revolving Credit Facilities:

[0000866374-25-000027:notes:215]
In July 2022, the Company entered into a $2.5 billion credit agreement which matures in July 2027 (the "2027 Credit Facility") and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. The 2027 Credit Facility replaced the previous $2.0 billion revolving credit facility, which was due to mature in January 2026. As of March 31, 2025 and 2024, no borrowings were outstanding.

[0000866374-25-000027:notes:216]
Borrowings under the 2027 Credit Facility bear interest, at the Company’s option, either at (i) the Base Rate (as defined in the 2027 Credit Facility), plus 1.0% and an applicable margin ranging from 0.125% to 0.750% per annum based on credit ratings or (ii) Term SOFR (or an Alternative Currency Term Rate based on the applicable currency at issue or Alternative Currency Daily Rate based on Sterling Overnight Index Average) plus the applicable margin ranging between 1.125% and 1.750% per annum based on credit ratings, plus an adjustment for Term SOFR loans of 0.10% per annum and an adjustment for Sterling Overnight Index Average loans of 0.0326% per annum. Interest on the outstanding borrowings is payable, (i) in the case of borrowings at the Base Rate, on the last business day of March, June, September and December of each calendar year and the maturity date, (ii) in the case of borrowings at the Term SOFR rate (or Alternative Currency Term Rate), on the last day of the applicable interest period selected by the Company, which date shall be no later than the last day of every third month and the maturity date and (iii) in the case of borrowings at the Alternative Currency Daily Rate, on the last day of each calendar month and the maturity date. The Company is required to pay a quarterly commitment fee on the unutilized portion of the revolving credit commitments under the 2027 Credit Facility ranging from 0.125% to 0.275% per annum, based on credit ratings. The Company is also required to pay letter of credit usage fees ranging from 1.125% to 1.750% per annum (based on the credit ratings) on the amount of the daily average outstanding letters of credit and a fronting fee of 0.125% per annum on the undrawn and unexpired amount of each letter of credit.

[0000866374-25-000027:notes:217]
Under the 2027 Credit Facility, the interest rate margins, commitment fee and letter of credit usage fee are subject to upward or downward adjustments if the Company achieves, or fails to achieve, certain specified sustainability targets with respect to workplace safety and greenhouse gas emissions. Such upward or downward sustainability adjustments may be up to 0.05% per annum in the case of the interest rate margins and letter of credit usage fee and up to 0.01% per annum in the case of the commitment fee.

[0000866374-25-000027:notes:218]
As of March 31, 2025 and 2024, the Company and certain of its subsidiaries had various uncommitted revolving credit facilities, lines of credit and other credit facilities of $584 million and $318 million in the aggregate, respectively. There were no borrowings outstanding under these facilities as of March 31, 2025 and 2024. These unsecured credit facilities, and lines of credit and other credit facilities bear annual interest at the respective country's inter-bank offering rate, plus an applicable margin.

[0000866374-25-000027:notes:219]
Delayed Draw Term Loan:

[0000866374-25-000027:notes:220]
In March 2025, the Company entered into a $500 million delayed draw term loan credit agreement. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt and other general corporate purposes. The delayed draw term loan is available to be drawn through June 30, 2025. All borrowings under the delayed draw term loan will become due on December 31, 2027. Interest is based on either (a) a Term SOFR-based formula plus a margin of 87.5 basis points to 150 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 50.0 basis points, depending on the Company's credit ratings. As of March 31, 2025, the Company had no borrowings outstanding.

[0000866374-25-000027:notes:221]
Debt Covenants:

[0000866374-25-000027:notes:222]
Borrowings under the Company’s debt agreements are subject to various covenants that limit the Company’s ability to incur additional indebtedness, sell assets, effect mergers and certain transactions, and effect certain transactions with subsidiaries and affiliates. In addition, the 2027 Credit Facility and delayed draw term loan also require that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio. The Company is also subject to certain covenants requiring the Company to offer to repurchase the 2025 Notes, 2026 Notes, 2028 Notes, 2029 Notes, 2030 Notes and 2032 Notes upon a change of control. As of March 31, 2025 and 2024, the Company was in compliance with its debt covenants.

[0000866374-25-000027:notes:223]
The weighted-average interest rates for the Company's long-term debt were 4.6% and 4.5% as of March 31, 2025 and 2024, respectively.

[0000866374-25-000027:notes:224]
Scheduled repayments of the Company's bank borrowings and long-term debt are as follows:

[0000866374-25-000027:notes:225]
| Fiscal Year Ending March 31, | Amount |
|  | (In millions) |
| 2026 | $ | 1,209 |  |
| 2027 | — |  |
| 2028 | 398 |  |
| 2029 | 27 |  |
| 2030 | 682 |  |
| Thereafter | 1,390 |  |
| Total | $ | 3,706 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-25-000027:notes:226]
FINANCIAL INSTRUMENTS
Foreign Currency Contracts

[0000866374-25-000027:notes:227]
The Company transacts business in various foreign countries and is therefore exposed to foreign currency exchange rate risk inherent in forecasted sales, cost of sales, and monetary assets and liabilities denominated in non-functional currencies. The Company has established risk management programs to protect against volatility in the value of non-functional currency denominated monetary assets and liabilities, and of future cash flows caused by changes in foreign currency exchange rates. The Company tries to maintain a partial or fully hedged position for certain transaction exposures, which are primarily, but not limited to, forecasted sales and cost of sales, and monetary assets and liabilities in currencies other than the functional currency of the operating entity. The Company enters into short-term and long-term foreign currency derivative contracts, including forward, swap, and option contracts, to hedge only those currency exposures associated with certain assets and liabilities, primarily accounts receivable, accounts payable, debt, and cash flows denominated in non-functional currencies. Gains and losses on the Company's derivative contracts are designed to offset losses and gains on the assets, liabilities and transactions hedged, and accordingly, generally do not subject the Company to risk of significant accounting losses. The Company hedges committed exposures and does not engage in speculative transactions. The credit risk of these derivative contracts is minimized since the contracts are with large financial institutions and, accordingly, fair value adjustments related to the credit risk of the counterparty financial institution were not material.

[0000866374-25-000027:notes:228]
As of March 31, 2025, the aggregate notional amount of the Company's outstanding foreign currency derivative contracts was $7.9 billion as summarized below:

[0000866374-25-000027:notes:229]
|  |  |  | Notional ContractValue in USD |
| Currency |  |  |  |  | Buy |  | Sell |
|  |  |  |  |  | (In millions) |
| Cash Flow Hedges |  |  |  |  |  |  |  |
| HUF |  |  |  |  | $ | 400 |  |  | $ | — |  |
| MXN |  |  |  |  | 391 |  |  | — |  |
| Other |  |  |  |  | 577 |  |  | 7 |  |
|  |  |  |  |  | 1,368 |  |  | 7 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |
| CNY |  |  |  |  | 881 |  |  | 513 |  |
| EUR |  |  |  |  | 783 |  |  | 787 |  |
| HKD |  |  |  |  | — |  |  | 441 |  |
| MXN |  |  |  |  | 452 |  |  | 325 |  |
| MYR |  |  |  |  | 379 |  |  | 238 |  |
| Other |  |  |  |  | 807 |  |  | 921 |  |
|  |  |  |  |  | 3,302 |  |  | 3,225 |  |
| Total Notional Contract Value in USD |  |  |  |  | $ | 4,670 |  |  | $ | 3,232 |  |

[0000866374-25-000027:notes:230]
As of March 31, 2025 and 2024, the fair value of the Company's short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company's exposure to monetary assets and liabilities denominated in a non-functional

[0000866374-25-000027:notes:231]
currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the consolidated statements of operations. The Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders' equity in the consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred losses were $8 million as of March 31, 2025, and are expected to be recognized primarily as a component of cost of sales in the consolidated statement of operations primarily over the next twelve-month period, except for gains attributable to changes in fair value of  the USD HUF cross currency swaps, which are discussed below.

[0000866374-25-000027:notes:232]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in other current assets and other non-current liabilities as of March 31, 2025 and March 31, 2024, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-25-000027:notes:233]
The following table presents the fair value of the Company's derivative instruments utilized for foreign currency risk management purposes at March 31, 2025 and 2024:

[0000866374-25-000027:notes:234]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | March 31,2025 |  | March 31,2024 |  | Balance SheetLocation |  | March 31,2025 |  | March 31,2024 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 13 |  |  | $ | 45 |  |  | Other current liabilities |  | $ | (18) |  |  | $ | (9) |  |
| Foreign currency contracts | Other non-current assets |  | — |  |  | — |  |  | Other non-current liabilities |  | (46) |  |  | (33) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 21 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | (15) |  |  | $ | (10) |  |

[0000866374-25-000027:notes:235]
The Company has financial instruments subject to master netting arrangements, which provide for the net settlement of all contracts with certain counterparties. The Company does not offset fair value amounts for assets and liabilities recognized for derivative instruments under these arrangements, as such, the asset and liability balances presented in the table above reflect the gross amounts of derivatives in the consolidated balance sheets. The impact of netting derivative assets and liabilities is not material to the Company's financial position for any of the periods presented.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-25-000027:notes:236]
ACCUMULATED OTHER COMPREHENSIVE LOSS
The changes in accumulated other comprehensive loss by component, net of tax, during fiscal years ended March 31, 2025, 2024 and 2023 are as follows:

[0000866374-25-000027:notes:237]
|  | Unrealized gain (loss) onderivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Ending balance on March 31, 2022 | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive loss before reclassifications | (25) |  |  | (67) |  |  | (92) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 77 |  |  | 3 |  |  | 80 |  |
| Net current-period other comprehensive gain (loss) | 52 |  |  | (64) |  |  | (12) |  |
| Ending balance on March 31, 2023 | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |
| Other comprehensive gain (loss) before reclassifications | 95 |  |  | (19) |  |  | 76 |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | (77) |  |  | — |  |  | (77) |  |
| Net current-period other comprehensive gain (loss) | 18 |  |  | (19) |  |  | (1) |  |
| Ending balance on March 31, 2024 | $ | 4 |  |  | $ | (199) |  |  | $ | (195) |  |
| Other comprehensive gain (loss) before reclassifications | (77) |  |  | (6) |  |  | (83) |  |
| Net (gain) loss reclassified from accumulated other comprehensive loss | 54 |  |  | — |  |  | 54 |  |
| Net current-period other comprehensive gain (loss) | (23) |  |  | (6) |  |  | (29) |  |
| Ending balance on March 31, 2025 | $ | (19) |  |  | $ | (205) |  |  | $ | (224) |  |

[0000866374-25-000027:notes:238]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the fiscal year 2025 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the consolidated statement of operations, which primarily relate to the Company's foreign currency contracts accounted for as cash flow hedges.
The tax impact to other comprehensive loss was immaterial for all periods presented.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-25-000027:notes:239]
TRADE RECEIVABLES SALES PROGRAMS
The Company sells accounts receivables to certain third-party banking institutions under factoring programs. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.7 billion and $0.8 billion as of March 31, 2025 and 2024, respectively. For the fiscal years ended March 31, 2025, 2024 and 2023, total accounts receivable sold to certain third party banking institutions was approximately $4.0 billion, $3.6 billion and $3.5 billion, respectively. The receivables that were sold were removed from the consolidated balance sheets and the cash received was included as cash provided by operating activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-25-000027:notes:240]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-25-000027:notes:241]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of March 31, 2025.

[0000866374-25-000027:notes:242]
Level 2 - Applies to assets or liabilities for which there are inputs other than quoted prices included within level 1 that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets) such as cash and cash equivalents and money market funds; or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000866374-25-000027:notes:243]
The Company values foreign exchange forward contracts using level 2 observable inputs which primarily consist of an income approach based on the present value of the forward rate less the contract rate multiplied by the notional amount.

[0000866374-25-000027:notes:244]
The Company's cash equivalents include bank time deposits and money market funds, which are valued using level 2 inputs, such as interest rates and maturity periods. Due to their short-term nature, their carrying amount approximates fair value.

[0000866374-25-000027:notes:245]
The Company has deferred compensation plans for its officers and certain other employees. Amounts deferred under the plans are invested in hypothetical investments selected by the participant or the participant's investment manager. The Company's deferred compensation plan assets are included in other non-current assets on the consolidated balance sheets and include money market funds, mutual funds, corporate and government bonds and certain convertible securities that are valued using prices obtained from various pricing sources. These sources price these investments using certain market indices and the performance of these investments in relation to these indices. As a result, the Company has classified these investments as level 2 in the fair value hierarchy.

[0000866374-25-000027:notes:246]
Level 3 - Applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000866374-25-000027:notes:247]
The Company has accrued for contingent consideration related to its acquisition of JetCool, classified as a level 3 measurement in the fair value hierarchy due to significant unobservable inputs. Fair value is determined using internal cash flow models that incorporate unobservable inputs, including the probability of achieving performance milestones. As of March 31, 2025 and March 31, 2024, the balances of contingent consideration were $5 million and zero, respectively.

[0000866374-25-000027:notes:248]
The significant inputs include the Company's probability assessments of expected future revenue during the earn-out periods, associated volatility, and a discount rate reflecting uncertainties in the obligation consistent with the terms of the purchase agreement. Significant decreases in expected revenue, or increases in the discount rate or volatility, would reduce fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-25-000027:notes:249]
There were no transfers between levels in the fair value hierarchy during fiscal years 2025 and 2024.

[0000866374-25-000027:notes:250]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0000866374-25-000027:notes:251]
The following table presents the Company's assets and liabilities measured at fair value on a recurring basis as of March 31, 2025 and 2024:

[0000866374-25-000027:notes:252]
|  | Fair Value Measurements as of March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 1,535 |  |  | $ | — |  |  | $ | 1,535 |  |
| Foreign currency contracts (Note 10) | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (79) |  |  | $ | — |  |  | $ | (79) |  |
| Contingent consideration in connection with acquisitions | — |  |  | — |  |  | (5) |  |  | (5) |  |

[0000866374-25-000027:notes:253]
|  | Fair Value Measurements as of March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (Note 2) | $ | — |  |  | $ | 759 |  |  | $ | — |  |  | $ | 759 |  |
| Foreign currency contracts (Note 10) | — |  |  | 59 |  |  | — |  |  | 59 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |
| Mutual funds, money market accounts and equity securities | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 10) | $ | — |  |  | $ | (52) |  |  | $ | — |  |  | $ | (52) |  |

[0000866374-25-000027:notes:254]
Other financial instruments

[0000866374-25-000027:notes:255]
The following table presents the Company's major debts not carried at fair value as of March 31, 2025 and 2024:

[0000866374-25-000027:notes:256]
|  | As of March 31, 2025 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair ValueHierarchy |
|  | (In millions) |  | (In millions) |  |  |
| 4.750% Notes due June 2025 | 531 |  |  | 531 |  |  | 584 |  |  | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 678 |  |  | 672 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 409 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 655 |  |  | 651 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 676 |  |  | 669 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 497 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 269 |  |  | 215 |  |  | 274 |  |  | 219 |  |  | Level 2 |

[0000866374-25-000027:notes:257]
The Notes due June 2025, February 2026, January 2028, June 2029, May 2030 and January 2032 are valued based on broker trading prices in active markets. HUF Bonds are valued based on the broker trading prices in an inactive market.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-25-000027:notes:258]
COMMITMENTS AND CONTINGENCIES
Commitments

[0000866374-25-000027:notes:259]
As of March 31, 2025 and 2024, the gross carrying amount and associated accumulated depreciation of the Company's property and equipment financed under finance leases, and the related obligations was not material. The Company also leases certain of its facilities and equipment under non-cancelable operating leases. These operating leases expire in various years through 2044. Refer to note 3 for additional details on the minimum lease payments.

[0000866374-25-000027:notes:260]
Litigation and other legal matters

[0000866374-25-000027:notes:261]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-25-000027:notes:262]
As previously disclosed, the Company was involved in a commercial dispute related to a construction matter with related production objectives. Management had assessed the potential outcomes of this dispute, considered available information, and consulted with legal counsel and as a result of this assessment recognized $50 million in the fourth quarter of the fiscal year ended March 31, 2024 as an accrual. The parties reached a settlement in line with the accrued amount after the end of the fourth quarter of the fiscal year ended March 31, 2025.

[0000866374-25-000027:notes:263]
One of the Company's Brazilian subsidiaries received six assessments for certain sales and import taxes. Four of the assessments have been successfully definitively defeated. The Company was unsuccessful at the administrative level in two of the remaining assessments and filed annulment actions in federal court in Brasilia, Brazil. The first annulment action was filed on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 37 million Brazilian reals (approximately USD $6 million). The Brazilian court ruled in favor of the Company on the first annulment action on March 7, 2025 and the assessment obligation has been canceled, although it remains subject to appeal. The second annulment action was filed on September 19, 2023; the updated value of that assessment inclusive of interest and penalties is 60 million Brazilian reals (approximately USD $10 million). The Company is still awaiting a resolution of the second annulment action. The Company believes that it has meritorious defenses to these assessments and will continue to vigorously oppose them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-25-000027:notes:264]
A foreign Tax Authority ("Tax Authority") had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. In the quarter ended March 31, 2025, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-25-000027:notes:265]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material effect on the Company’s financial position, results of operations or cash flows.

[0000866374-25-000027:notes:266]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000866374-25-000027:notes:267]
INCOME TAXES
The domestic (Singapore) and foreign components of income from continuing operations before income taxes were comprised of the following:

[0000866374-25-000027:notes:268]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Domestic | $ | 94 |  |  | $ | (165) |  |  | $ | 99 |  |
| Foreign | 929 |  |  | 831 |  |  | 708 |  |
| Total | $ | 1,023 |  |  | $ | 666 |  |  | $ | 807 |  |

[0000866374-25-000027:notes:269]
The (benefit from) provision for income taxes from continuing operations consisted of the following:

[0000866374-25-000027:notes:270]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Current: |  |  |  |  |  |
| Domestic | $ | 2 |  |  | $ | 3 |  |  | $ | 6 |  |
| Foreign | 128 |  |  | 161 |  |  | 117 |  |
|  | 130 |  |  | 164 |  |  | 123 |  |
| Deferred: |  |  |  |  |  |
| Domestic | 3 |  |  | (1) |  |  | 1 |  |
| Foreign | 52 |  |  | (369) |  |  | — |  |
|  | 55 |  |  | (370) |  |  | 1 |  |
| (Benefit from) provision for income taxes | $ | 185 |  |  | $ | (206) |  |  | $ | 124 |  |

[0000866374-25-000027:notes:271]
The domestic statutory income tax rate was approximately 17.0% in fiscal years 2025, 2024 and 2023. The reconciliation of the income tax expense (benefit) from continuing operations expected based on domestic statutory income tax rates to the expense (benefit) for income taxes included in the consolidated statements of operations is as follows:

[0000866374-25-000027:notes:272]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Income taxes based on domestic statutory rates | $ | 174 |  |  | $ | 113 |  |  | $ | 137 |  |
| Effect of jurisdictional tax rate differential | 13 |  |  | 68 |  |  | 52 |  |
| Change in unrecognized tax benefit | (19) |  |  | (10) |  |  | (7) |  |
| Change in valuation allowance | (37) |  |  | (685) |  |  | (290) |  |
| Foreign exchange movement on prior year taxes recoverable | 4 |  |  | (1) |  |  | 4 |  |
| Liability for undistributed earnings | 6 |  |  | 135 |  |  | — |  |
| Global intangible low-taxed income (GILTI) / Subpart F income | 9 |  |  | 13 |  |  | 18 |  |
| Nextracker related transactions gains | — |  |  | 115 |  |  | 158 |  |
| Earnings from partnership | — |  |  | 47 |  |  | 39 |  |
| U.S. state taxes | 10 |  |  | 10 |  |  | 2 |  |
| Excess compensation (Section 162(m)) | 16 |  |  | 15 |  |  | 9 |  |
| Other | 9 |  |  | (26) |  |  | 2 |  |
| (Benefit from) provision for income taxes | $ | 185 |  |  | $ | (206) |  |  | $ | 124 |  |

[0000866374-25-000027:notes:273]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The aggregate dollar effect on the Company’s income resulting from tax holidays and tax incentives to attract and retain business for the fiscal years ended March 31, 2025, 2024 and 2023 were $17 million, $20 million and $14 million, respectively. For the fiscal year ended March 31, 2025, the effect on basic and diluted earnings per share was $0.04, and the effects on basic and diluted earnings per share during fiscal years 2024 and 2023 were $0.05, and $0.03, respectively. Unless extended or otherwise renegotiated, the Company's existing holidays will expire in various years through the end of fiscal year 2032.

[0000866374-25-000027:notes:274]
The Company provides a valuation allowance against deferred tax assets that in the Company's estimation are not more likely than not to be realized. During fiscal years 2025, 2024 and 2023, the Company released net valuation allowances totaling $4 million, $447 million and $6 million, respectively. For fiscal year 2025, included in the $4 million net release was a $5 million valuation allowance release related to the Company’s Canadian operations as these amounts were deemed to be more likely than not to be realized.

[0000866374-25-000027:notes:275]
In addition, various other valuation allowance positions in other jurisdictions were increased or decreased to offset movement in deferred tax positions due to varying factors such as one-time income recognition in loss entities with existing valuation allowances, liquidation of entities with existing valuation allowances, recognition of uncertain tax positions impacting deferred tax assets with existing valuation allowances, foreign exchange impacts on deferred tax balances with existing valuation allowances, and current period losses in legal entities with existing valuation allowance positions. These offsetting changes in the valuation allowance included a decrease of $53 million in the fiscal year ended March 31, 2025, an increase of $43 million and a decrease of $254 million in the fiscal years ended March 31 2024 and, 2023, respectively.

[0000866374-25-000027:notes:276]
Under its territorial tax system, Singapore generally does not tax foreign sourced income until repatriated to Singapore.  The Company has included the effects of Singapore's territorial tax system in the rate differential line above. The tax effects of foreign income not repatriated to Singapore for the fiscal years ended March 31, 2025, 2024 and 2023 were $96 million, zero and $31 million, respectively.

[0000866374-25-000027:notes:277]
The components of deferred income taxes are as follows:

[0000866374-25-000027:notes:278]
|  | As of March 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Deferred tax liabilities: |  |  |  |
| Fixed assets | $ | (44) |  |  | $ | (59) |  |
| Intangible assets | (52) |  |  | (56) |  |
| Others | (128) |  |  | (149) |  |
| Total deferred tax liabilities | (224) |  |  | (264) |  |
| Deferred tax assets: |  |  |  |
| Fixed assets | 76 |  |  | 82 |  |
| Intangible assets | 3 |  |  | 4 |  |
| Deferred compensation | 37 |  |  | 25 |  |
| Inventory valuation | 32 |  |  | 26 |  |
| Provision for doubtful accounts | 3 |  |  | 2 |  |
| Net operating loss and other carryforwards | 1,022 |  |  | 1,168 |  |
| Tax receivable agreement | 74 |  |  | 77 |  |
| Others | 186 |  |  | 184 |  |
| Total deferred tax assets | 1,433 |  |  | 1,568 |  |
| Valuation allowances | (781) |  |  | (838) |  |
| Total deferred tax assets, net of valuation allowances | 652 |  |  | 730 |  |
| Net deferred tax asset | $ | 428 |  |  | $ | 466 |  |
| The net deferred tax asset is classified as follows: |  |  |  |
| Long-term asset | $ | 577 |  |  | $ | 644 |  |
| Long-term liability | (149) |  |  | (178) |  |
| Total | $ | 428 |  |  | $ | 466 |  |

[0000866374-25-000027:notes:279]
Utilization of the Company's deferred tax assets is limited by the future earnings of the Company in the tax jurisdictions in which such deferred assets arose. As a result, management is uncertain as to when or whether these operations will generate sufficient profit to realize any benefit from the deferred tax assets. The valuation allowance provides a reserve against deferred tax assets that are not more likely than not to be realized by the Company. However, management has determined that it is more likely than not that the Company will realize certain of these benefits and, accordingly, has recognized a deferred tax asset from these benefits. The change in valuation allowance is net of certain increases and decreases to prior year losses and other carryforwards that have no current impact on the tax provision.

[0000866374-25-000027:notes:280]
The Company has recorded deferred tax assets of approximately $1.1 billion related to tax losses and other carryforwards against which the Company has recorded a valuation allowance for all but $286 million of the deferred tax assets. These tax losses and other carryforwards will expire at various dates as follows:

[0000866374-25-000027:notes:281]
| Expiration dates of deferred tax assets related to operating losses and other carryforwards |  |
| Fiscal year | (In millions) |
| 2026 - 2031 | $ | 134 |  |
| 2032 - 2037 | 204 |  |
| 2038 and thereafter | 17 |  |
| Indefinite | 696 |  |
|  | $ | 1,051 |  |

[0000866374-25-000027:notes:282]
The amount of deferred tax assets considered realizable, however, could be reduced or increased in the near-term if facts, including the amount of taxable income or the mix of taxable income between subsidiaries, differ from management’s estimates.

[0000866374-25-000027:notes:283]
The Company does not provide for income taxes on approximately $767 million of undistributed earnings of its subsidiaries which are considered to be indefinitely reinvested outside of Singapore as management has plans for the use of such earnings to fund certain activities outside of Singapore. The estimated amount of the unrecognized deferred tax liability on these undistributed earnings is approximately $80 million. In the current year, the Company, as part of its regular process, assessed its cash position in overseas territories relative to the levels needed to manage operations and fund future investment in those territories. Following a sustained improvement in the working capital position in China and a trend of customers nearshoring their manufacturing operations, management noted that the current and forecasted cash position in China was in excess of levels required to fund the Company’s business in the country. As a result, a deferred tax liability of $117 million was recorded on the remaining distributable earnings from China of approximately $1.17 billion.

[0000866374-25-000027:notes:284]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows:

[0000866374-25-000027:notes:285]
|  | Fiscal Year EndedMarch 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Balance, beginning of fiscal year | $ | 197 |  |  | $ | 268 |  |
| Additions based on tax position related to the current year | 10 |  |  | 10 |  |
| Additions for tax positions of prior years | 1 |  |  | 22 |  |
| Reductions for tax positions of prior years | (5) |  |  | (82) |  |
| Reductions related to lapse of applicable statute of limitations | (23) |  |  | (17) |  |
| Impact from foreign exchange rates fluctuation | — |  |  | (4) |  |
| Balance, end of fiscal year | $ | 180 |  |  | $ | 197 |  |

[0000866374-25-000027:notes:286]
The Company’s unrecognized tax benefits are subject to change over the next twelve months primarily as a result of the expiration of certain statutes of limitations and as audits are settled. The Company believes it is reasonably possible that the total amount of unrecognized tax benefits could decrease by an additional approximate $15 million within the next twelve months primarily due to potential settlements of various audits and the expiration of certain statutes of limitations.

[0000866374-25-000027:notes:287]
The Company and its subsidiaries file federal, state, and local income tax returns in multiple jurisdictions around the world. With few exceptions, the Company is no longer subject to income tax examinations by tax authorities for years before 2006.

[0000866374-25-000027:notes:288]
Of the $180 million of unrecognized tax benefits at March 31, 2025, $153 million will affect the annual effective tax rate ("ETR") if the benefits are eventually recognized. The amount that does not impact the ETR relates to positions that would be settled with a tax loss carryforward previously subject to a valuation allowance.

[0000866374-25-000027:notes:289]
The Company recognizes interest and penalties accrued related to unrecognized tax benefits within the Company’s tax expense. During the fiscal years ended March 31, 2025, 2024 and 2023, the Company recognized interest and penalties of approximately ($3) million, ($2) million and ($1) million, respectively. The Company had approximately $10 million, $13 million and $15 million accrued for the payment of interest and penalties as of the fiscal years ended March 31, 2025, 2024, and 2023, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-25-000027:notes:290]
RESTRUCTURING CHARGES
Fiscal Year 2025

[0000866374-25-000027:notes:291]
During fiscal year 2025, the Company committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, the Company recognized approximately $86 million of restructuring charges, most of which related to employee severance. Certain restructuring charges of $84 million are not included in segment income, as disclosed further in note 21.

[0000866374-25-000027:notes:292]
Fiscal Year 2024

[0000866374-25-000027:notes:293]
The Company identified certain structural changes to restructure its business throughout fiscal year 2024. During fiscal year 2024, the Company recognized approximately $175 million of restructuring charges, most of which related to employee severance and are not included in segment income.

[0000866374-25-000027:notes:294]
Fiscal Year 2023

[0000866374-25-000027:notes:295]
The Company identified certain structural changes to restructure its business throughout fiscal year 2023. During fiscal year 2023, the Company recognized approximately $27 million of restructuring charges, most of which related to employee severance. Restructuring charges are not included in segment income.

[0000866374-25-000027:notes:296]
The following table summarizes the provisions for charges incurred, respective payments for the fiscal years ended March 31, 2025, 2024, and 2023, respectively, and remaining accrued balances as of the same periods:

[0000866374-25-000027:notes:297]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2022 | $ | 35 |  |  | $ | — |  |  | $ | 8 |  |  | $ | 43 |  |
| Provision for charges incurred in fiscal year 2023 | 27 |  |  | — |  |  | — |  |  | 27 |  |
| Cash payments for charges incurred in fiscal year 2022 and prior | (7) |  |  | — |  |  | — |  |  | (7) |  |
| Cash payments for charges incurred in fiscal year 2023 | (11) |  |  | — |  |  | — |  |  | (11) |  |
| Non-cash reductions incurred in fiscal year 2023 | — |  |  | — |  |  | (2) |  |  | (2) |  |
| Balance as of March 31, 2023 | 44 |  |  | — |  |  | 6 |  |  | 50 |  |
| Provision for charges incurred in fiscal year 2024 | 161 |  |  | 14 |  |  | — |  |  | 175 |  |
| Cash payments for charges incurred in fiscal year 2023 and prior | (13) |  |  | — |  |  | — |  |  | (13) |  |
| Cash payments for charges incurred in fiscal year 2024 | (115) |  |  | — |  |  | — |  |  | (115) |  |
| Non-cash reductions incurred in fiscal year 2024 | — |  |  | (14) |  |  | (3) |  |  | (17) |  |
| Balance as of March 31, 2024 | 77 |  |  | — |  |  | 3 |  |  | 80 |  |
| Provision for charges incurred in fiscal year 2025 | 76 |  |  | 10 |  |  | — |  |  | 86 |  |
| Cash payments for charges incurred in fiscal year 2024 and prior | (20) |  |  | — |  |  | — |  |  | (20) |  |
| Cash payments for charges incurred in fiscal year 2025 | (54) |  |  | — |  |  | — |  |  | (54) |  |
| Non-cash reductions incurred in fiscal year 2025 (1) | (28) |  |  | (10) |  |  | (3) |  |  | (41) |  |
| Balance as of March 31, 2025 | 51 |  |  | — |  |  | — |  |  | 51 |  |
| Less: Current portion (classified as other current liabilities) | 51 |  |  | — |  |  | — |  |  | 51 |  |
| Accrued restructuring costs, net of current portion (classified as other non-current liabilities) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000866374-25-000027:notes:298]
(1) The non-cash adjustments predominantly relate to the liabilities derecognized as part of a business disposition. Refer to Note 19 for further details.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-25-000027:notes:299]
OTHER CHARGES (INCOME), NET
Other charges (income), net for the fiscal years ended March 31, 2025, 2024 and 2023 are comprised of the following:

[0000866374-25-000027:notes:300]
|  | Fiscal Year Ended March 31 |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| (Gain)/Loss on foreign exchange transactions | $ | 10 |  |  | $ | 24 |  |  | $ | (7) |  |
| (Gain) on bargain purchase (1) | (19) |  |  | — |  |  | — |  |
| Other | (5) |  |  | 20 |  |  | 13 |  |

[0000866374-25-000027:notes:301]
(1)Represents the gain on bargain purchase as a result of an acquisition occurring during the fourth quarter of fiscal year 2025. See note 19 "Business and Asset Acquisitions & Divestitures" for additional information.


## flex:InterestAndOtherNetTextBlock

[0000866374-25-000027:notes:302]
INTEREST EXPENSE AND INTEREST INCOME
Interest expense and interest income for the fiscal years ended March 31, 2025, 2024 and 2023 are primarily comprised of the following:

[0000866374-25-000027:notes:303]
|  | Fiscal Year Ended March 31 |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 185 |  |  | $ | 161 |  |  | $ | 191 |  |
| AR sales programs related expenses | 33 |  |  | 46 |  |  | 39 |  |
| Interest income | (61) |  |  | (56) |  |  | (30) |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000866374-25-000027:notes:304]
BUSINESS ACQUISITIONS & DIVESTITURES
Fiscal 2025 Acquisitions and divestitures

[0000866374-25-000027:notes:305]
The Company completed four acquisitions during fiscal year 2025, accounted for as business combinations. The results of the acquired businesses are included in the Company’s condensed consolidated financial statements from their respective acquisition dates. The allocation of the purchase price to the tangible and identifiable intangible assets acquired and liabilities assumed was based on their estimated fair values as of the date of acquisition. The excess of the purchase price over the tangible and identifiable intangible assets acquired and liabilities assumed has been allocated to goodwill and if the fair value of assets acquired and liabilities assumed exceeds the purchase consideration a gain on bargain purchase was recognized. Pro-forma results of operations have not been presented because the effects were not material to the Company’s condensed consolidated financial results for all periods presented. Additional information, which existed as of the acquisition date, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the date of acquisition. Changes to amounts recorded as assets and liabilities may result in a corresponding adjustment to goodwill or gain on bargain purchase during the respective measurement periods.

[0000866374-25-000027:notes:306]
Acquisition of Crown Technical Systems ("Crown")

[0000866374-25-000027:notes:307]
On November 19, 2024, the Company completed the business acquisition of 100% ownership of Crown, a U.S. leader in critical power solutions for a total estimated purchase consideration of $319 million, including cash of $313 million and a $6 million estimate of customary closing adjustments. The acquisition adds complementary capabilities to our existing portfolio in the United States, primarily strengthening our industrial power solutions. Crown is included in the Industrial reporting unit within the FRS segment. The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of Crown (in millions):

[0000866374-25-000027:notes:308]
| Current Assets: |  |
| Cash | $ | 5 |  |
| Accounts receivable | 23 |  |
| Inventory | 10 |  |
| Other current assets | 2 |  |
| Total current assets | 40 |  |
| Property and equipment | 1 |  |
| Operating lease right-of-use assets | 7 |  |
| Intangible assets | 128 |  |
| Goodwill | 170 |  |
| Total assets | $ | 346 |  |
| Current liabilities: |  |
| Accounts payable | $ | 4 |  |
| Accrued liabilities & other current liabilities | 17 |  |
| Total current liabilities | 21 |  |
| Operating lease liabilities, non-current | 6 |  |
| Total aggregate purchase price | $ | 319 |  |

[0000866374-25-000027:notes:309]
The intangible assets of $128 million are comprised of customer related intangible assets of $83 million and licenses and other intangible assets such as trade names and patented technology of $45 million. Customer related assets will be amortized

[0000866374-25-000027:notes:310]
over a weighted-average estimated useful life of 12.6 years while licenses and other intangibles will be amortized over a weighted-average estimated useful life of 10.0 years.

[0000866374-25-000027:notes:311]
Acquisition of JetCool Technologies Inc. ("JetCool")

[0000866374-25-000027:notes:312]
On November 14, 2024, the Company acquired 100% ownership of JetCool, a provider of liquid cooling solutions tailored for the data center market, for approximately $43 million in cash, a deemed settled pre-existing loan from Flex of approximately $5 million, and $5 million of contingent consideration for a total estimated purchase price of $53 million. JetCool is included in the Communications, Enterprise and Cloud reporting unit within the FAS segment. The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of JetCool (in millions):

[0000866374-25-000027:notes:313]
| Current Assets: |  |
| Cash | $ | 4 |  |
| Inventory | 1 |  |
| Total current assets | 5 |  |
| Property and equipment | 1 |  |
| Operating lease right-of-use assets | 2 |  |
| Intangible assets | 21 |  |
| Goodwill | 31 |  |
| Total assets | $ | 60 |  |
| Operating lease liabilities | $ | 2 |  |
| Deferred tax liability | 5 |  |
| Total aggregate purchase price | $ | 53 |  |

[0000866374-25-000027:notes:314]
Intangible assets of $21 million relate to developed technology and will be amortized over a weighted-average estimated useful life of 6.5 years.

[0000866374-25-000027:notes:315]
Acquisition of Orangeburg Manufacturing Facility ("Orangeburg")

[0000866374-25-000027:notes:316]
On February 4, 2025, the Company acquired the U.S. manufacturing operations of the Forest & Garden division of Husqvarna, a leading global producer of outdoor power products. Under the agreement, the Company assumed operation of Husqvarna’s Orangeburg, South Carolina, facility to support Husqvarna’s U.S. manufacturing requirements. The total estimated purchase consideration was $78 million, including $57 million in cash and $21 million in deferred consideration, to be paid $8 million in fiscal year 2026, $5 million in fiscal year 2027, $4 million in fiscal year 2028 and $4 million in fiscal year 2029. Additionally, the Company recognized a gain on bargain purchase of $19 million in other charges (income) on the consolidated statements of operations during fiscal year 2025. The gain on bargain purchase reflects the seller’s strategic decision to prioritize its partnership with Flex as a manufacturing partner. The acquired business is included in the Lifestyle reporting unit within the FAS segment. The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of the business (in millions):

[0000866374-25-000027:notes:317]
| Current Assets: |  |
| Inventory | $ | 32 |  |
| Total current assets | 32 |  |
| Property and equipment | 57 |  |
| Intangible assets | 15 |  |
| Total assets | $ | 104 |  |
| Deferred tax liability | $ | 7 |  |
| Net assets acquired | $ | 97 |  |
| Gain on Bargain Purchase | $ | (19) |  |
| Total aggregate purchase price | $ | 78 |  |

[0000866374-25-000027:notes:318]
Intangible assets of $15 million relate to customer relationships and will be amortized over a weighted-average estimated useful life of 5 years.

[0000866374-25-000027:notes:319]
Other Acquisition

[0000866374-25-000027:notes:320]
In May 2024, the Company completed the acquisition of a business that was not material to the Company's consolidated financial position, results of operations, or cash flows. The acquisition expands the Company’s service offerings across multiple markets and supports sustainability initiatives through second-life products. $8 million of goodwill was recognized in connection with this transaction, as of March 31, 2025.

[0000866374-25-000027:notes:321]
Divestiture

[0000866374-25-000027:notes:322]
During the fiscal year ended March 31, 2025, the Company disposed of one of its European sites. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net loss on disposition of $6 million was recorded in other charges (income), net in the consolidated statements of operations for fiscal year 2025.

[0000866374-25-000027:notes:323]
Fiscal 2024 Divestitures

[0000866374-25-000027:notes:324]
During the fiscal year ended March 31, 2024, the Company completed the spin-off of Nextracker. See note 7 - "Discontinued Operations" for additional information.

[0000866374-25-000027:notes:325]
In addition, the Company disposed of a non-strategic business within the FRS segment and received proceeds of approximately $14 million. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net loss on dispositions was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for fiscal year 2024.

[0000866374-25-000027:notes:326]
Fiscal 2023 Divestitures

[0000866374-25-000027:notes:327]
During the fiscal year ended March 31, 2023, the Company disposed of a non-strategic business within the FRS segment and received approximately $4 million of proceeds. The property and equipment and various other assets sold and liabilities transferred were not material to the Company's consolidated financial results. The net gain on dispositions was not material to the Company’s consolidated financial results, and was included in other charges (income), net in the consolidated statements of operations for the fiscal year 2023.


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000866374-25-000027:notes:328]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of Crown (in millions):

[0000866374-25-000027:notes:329]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of JetCool (in millions):

[0000866374-25-000027:notes:330]
The following represents the Company's preliminary allocation of the total purchase price to the acquired assets and liabilities of the business (in millions):


## us-gaap:TreasuryStockTextBlock

[0000866374-25-000027:notes:331]
SHARE REPURCHASE PLAN
During fiscal year 2025, the Company repurchased approximately 38.5 million shares for an aggregate purchase price of approximately $1.3 billion and retired 32.9 million of these shares.

[0000866374-25-000027:notes:332]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $1.7 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 8, 2024. As of March 31, 2025, shares in the aggregate amount of $1.0 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-25-000027:notes:333]
SEGMENT REPORTING
The Company's Chief Executive Officer is our Chief Operating Decision Maker ("CODM") who evaluates how we allocate resources, assess performance and make strategic and operational decisions. Based on such evaluation, the Company determined as of and for the period ended March 31, 2025, that Flex has two operating and reportable segments. During the fourth quarter of fiscal year 2024, following the Nextracker spin-off, the Company classified the pre spin-off results of Nextracker, formerly our Nextracker segment, as discontinued operations in our consolidated statements of operations. See note 7 "Discontinued Operations" for additional information.

[0000866374-25-000027:notes:334]
The FAS segment is optimized for speed to market based on a highly flexible supply and manufacturing system. FAS is comprised of the following end markets that represent reporting units:

[0000866374-25-000027:notes:335]
•Communications, Enterprise and Cloud, including data center, edge, and communications infrastructure

[0000866374-25-000027:notes:336]
•Lifestyle, including appliances, floorcare, smart living, HVAC, and power tools

[0000866374-25-000027:notes:337]
•Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-25-000027:notes:338]
The FRS segment is optimized for longer product lifecycles requiring complex ramps with specialized production models and critical environments. FRS is comprised of the following end markets that represent reporting units:

[0000866374-25-000027:notes:339]
•Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power.

[0000866374-25-000027:notes:340]
•Automotive, including compute platforms, power electronics, motion, and interface

[0000866374-25-000027:notes:341]
•Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-25-000027:notes:342]
The determination of the separate operating and reporting segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-25-000027:notes:343]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales (disaggregated below into cost of inventory and manufacturing expenses), and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000027:notes:344]
Selected financial information by segment is in the tables below.

[0000866374-25-000027:notes:345]
| Fiscal Year Ended March 31, 2025 | FAS |  | FRS |  | Corporate & Other |  | Total |
| Net Sales | $ | 14,074 |  |  | $ | 11,739 |  |  | $ | — |  |  | $ | 25,813 |  |
| Cost of inventory | (10,378) |  |  | (7,866) |  |  | — |  |  | (18,244) |  |
| Manufacturing expenses | (2,508) |  |  | (2,774) |  |  | (26) |  |  | (5,308) |  |
| Segment selling, general and administrative expenses | (334) |  |  | (415) |  |  | (53) |  |  | (802) |  |
| Segment income | $ | 854 |  |  | $ | 684 |  |  | $ | (79) |  |  | $ | 1,459 |  |
| Intangible amortization |  |  |  |  |  |  | $ | 70 |  |
| Stock-based compensation |  |  |  |  |  |  | 125 |  |
| Restructuring charges |  |  |  |  |  |  | 84 |  |
| Customer related asset impairment (1) |  |  |  |  |  |  | 2 |  |
| Legal and other (2) |  |  |  |  |  |  | 9 |  |
| Interest expenses |  |  |  |  |  |  | 218 |  |
| Interest income |  |  |  |  |  |  | 61 |  |
| Other charges (income), net |  |  |  |  |  |  | (14) |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (3) |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 1,023 |  |

[0000866374-25-000027:notes:346]
(1)Customer related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During fiscal year 2025, the Company recognized approximately $2 million of customer related asset impairments.

[0000866374-25-000027:notes:347]
(2)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and asset impairment. During fiscal year 2025, the Company accrued for $5 million related to asset impairments and $4 million is related to acquisition costs.

[0000866374-25-000027:notes:348]
| Fiscal Year Ended March 31, 2024 | FAS |  | FRS |  | Corporate & Other |  | Total |
| Net Sales | $ | 13,923 |  |  | $ | 12,492 |  |  | $ | — |  |  | $ | 26,415 |  |
| Cost of inventory | (10,549) |  |  | (8,610) |  |  | 10 |  |  | (19,149) |  |
| Manufacturing expenses | (2,382) |  |  | (2,796) |  |  | (28) |  |  | (5,206) |  |
| Segment selling, general and administrative expenses | (323) |  |  | (420) |  |  | (50) |  |  | (793) |  |
| Segment income | $ | 669 |  |  | $ | 666 |  |  | $ | (68) |  |  | $ | 1,267 |  |
| Intangible amortization |  |  |  |  |  |  | $ | 70 |  |
| Stock-based compensation |  |  |  |  |  |  | 113 |  |
| Restructuring charges |  |  |  |  |  |  | 172 |  |
| Customer related asset impairment (1) |  |  |  |  |  |  | 14 |  |
| Legal and other (2) |  |  |  |  |  |  | 45 |  |
| Interest expenses |  |  |  |  |  |  | 207 |  |
| Interest income |  |  |  |  |  |  | 56 |  |
| Other charges (income), net |  |  |  |  |  |  | 44 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | 8 |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 666 |  |

[0000866374-25-000027:notes:349]
(1)Customer related asset impairments may consist of non-cash impairments of property and equipment to estimated fair value for customers from whom we have disengaged or are in the process of disengaging as well as additional provisions for doubtful accounts receivable for customers that are experiencing financial difficulties and inventory that is considered non-recoverable that is written down to net realizable value. In subsequent periods, the Company may recover a portion of the costs previously incurred related to assets impaired or reduced to net realizable value. During fiscal year 2024, the Company recognized approximately $14 million of customer related asset impairments.

[0000866374-25-000027:notes:350]
(2)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During fiscal year 2024, the Company recognized a $50 million loss contingency for a commercial dispute related to a construction matter with related production objectives.

[0000866374-25-000027:notes:351]
| Fiscal Year Ended March 31, 2023 | FAS |  | FRS |  | Corporate & Other |  | Total |
| Net Sales | $ | 15,769 |  |  | $ | 12,733 |  |  | $ | — |  |  | $ | 28,502 |  |
| Cost of inventory | (12,256) |  |  | (9,067) |  |  | 19 |  |  | (21,304) |  |
| Manufacturing expenses | (2,485) |  |  | (2,655) |  |  | (30) |  |  | (5,170) |  |
| Segment selling, general and administrative expenses | (334) |  |  | (404) |  |  | (58) |  |  | (796) |  |
| Segment income | $ | 694 |  |  | $ | 607 |  |  | $ | (69) |  |  | $ | 1,232 |  |
| Intangible amortization |  |  |  |  |  |  | $ | 81 |  |
| Stock-based compensation |  |  |  |  |  |  | 101 |  |
| Restructuring charges |  |  |  |  |  |  | 27 |  |
| Customer related asset impairment |  |  |  |  |  |  | — |  |
| Legal and other (1) |  |  |  |  |  |  | 6 |  |
| Interest expenses |  |  |  |  |  |  | 230 |  |
| Interest income |  |  |  |  |  |  | 30 |  |
| Other charges (income), net |  |  |  |  |  |  | 6 |  |
| Equity in earnings (losses) of unconsolidated affiliates |  |  |  |  |  |  | (4) |  |
| Income from continuing operations before income taxes |  |  |  |  |  |  | $ | 807 |  |

[0000866374-25-000027:notes:352]
(1)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims.

[0000866374-25-000027:notes:353]
Corporate and Other primarily includes corporate service costs that are not included in the CODM's assessment of the performance of each of the identified reporting segments.

[0000866374-25-000027:notes:354]
The Company provides an overall platform of assets and services, which the segments utilize for the benefit of their various customers. The shared assets and services are contained within the Company's global manufacturing and design operations and include manufacturing and design facilities. Most of the underlying manufacturing and design assets are co-mingled in the operating campuses and are compatible to operate across segments and highly interchangeable throughout the platform. Given the highly interchangeable nature of the assets, they are not separately identified by segment nor reported by segment to the Company's CODM.

[0000866374-25-000027:notes:355]
Property and equipment on a segment basis is not separately identified and is not internally reported by segment to the Company's CODM as described above. During fiscal years 2025, 2024 and 2023, total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other, is as follows:

[0000866374-25-000027:notes:356]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Depreciation expense: |  |  |  |  |  |
| Flex Agility Solutions | $ | 179 |  |  | $ | 171 |  |  | $ | 177 |  |
| Flex Reliability Solutions | 249 |  |  | 241 |  |  | 217 |  |
| Corporate and Other | 11 |  |  | 16 |  |  | 17 |  |
| Total depreciation expense | $ | 439 |  |  | $ | 428 |  |  | $ | 411 |  |

[0000866374-25-000027:notes:357]
Geographic information of net sales is as follows:

[0000866374-25-000027:notes:358]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 12,656 |  |  | 49 | % |  | $ | 12,232 |  |  | 46 | % |  | $ | 11,906 |  |  | 42 | % |
| Asia | 7,701 |  |  | 30 | % |  | 8,540 |  |  | 32 | % |  | 10,384 |  |  | 36 | % |
| Europe | 5,456 |  |  | 21 | % |  | 5,643 |  |  | 22 | % |  | 6,212 |  |  | 22 | % |
|  | $ | 25,813 |  |  |  |  | $ | 26,415 |  |  |  |  | $ | 28,502 |  |  |  |

[0000866374-25-000027:notes:359]
Revenues are attributable to the country in which the product is manufactured or service is provided.

[0000866374-25-000027:notes:360]
During fiscal years 2025, 2024 and 2023, net sales generated from Singapore, the country of domicile, were approximately $266 million, $660 million and $552 million, respectively.

[0000866374-25-000027:notes:361]
The following table summarizes the countries that accounted for more than 10% of net sales in fiscal years 2025, 2024, and 2023:

[0000866374-25-000027:notes:362]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In millions) |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,854 |  |  | 27 | % |  | $ | 6,935 |  |  | 26 | % |  | $ | 6,626 |  |  | 23 | % |
| China | 4,319 |  |  | 17 | % |  | 5,117 |  |  | 19 | % |  | 6,562 |  |  | 23 | % |
| U.S. | 4,162 |  |  | 16 | % |  | 3,598 |  |  | 14 | % |  | 3,394 |  |  | 12 | % |

[0000866374-25-000027:notes:363]
No other country accounted for more than 10% of net sales for the fiscal periods presented in the table above.

[0000866374-25-000027:notes:364]
Geographic information of property and equipment, net is as follows:

[0000866374-25-000027:notes:365]
|  | As of March 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Americas | $ | 1,292 |  |  | 55 | % |  | $ | 1,220 |  |  | 54 | % |
| Asia | 555 |  |  | 24 | % |  | 565 |  |  | 25 | % |
| Europe | 483 |  |  | 21 | % |  | 484 |  |  | 21 | % |
|  | $ | 2,330 |  |  |  |  | $ | 2,269 |  |  |  |

[0000866374-25-000027:notes:366]
As of March 31, 2025 and 2024, property and equipment, net held in Singapore was approximately $4 million and $5 million, respectively.

[0000866374-25-000027:notes:367]
The following table summarizes the countries that accounted for more than 10% of property and equipment, net in fiscal years 2025 and 2024:

[0000866374-25-000027:notes:368]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |  |  |  |
| Mexico | $ | 815 |  |  | 35 | % |  | $ | 793 |  |  | 35 | % |
| U.S. | 376 |  |  | 16 | % |  | 334 |  |  | 15 | % |
| China | 293 |  |  | 13 | % |  | 307 |  |  | 14 | % |

[0000866374-25-000027:notes:369]
No other country accounted for more than 10% of property and equipment, net for the fiscal periods presented in the table above.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-25-000027:notes:370]
(1)Legal and other consists of costs not directly related to core business results including matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable offset by a gain upon successful settlement of certain supplier claims. 
During fiscal years 2025, 2024 and 2023, total depreciation expense, including amounts allocated to the reportable segments and Corporate and Other, is as follows:


## us-gaap:MinorityInterestDisclosureTextBlock

[0000866374-25-000027:notes:371]
NONCONTROLLING INTEREST
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interests in Nextracker to Flex shareholders on a pro-rata basis based on the number of ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023.

[0000866374-25-000027:notes:372]
Flex's noncontrolling and redeemable noncontrolling interest related solely to Nextracker. As of March 31, 2025 and 2024, noncontrolling interest was zero. Net income attributable to noncontrolling interest was zero, $239 million and $197 million in fiscal years 2025, 2024, and 2023, respectively. Net income attributable to redeemable noncontrolling interest was zero in fiscal years 2025 and 2024, and $43 million in fiscal year 2023.


## us-gaap:SubsequentEventsTextBlock

[0000866374-25-000027:notes:373]
SUBSEQUENT EVENTS
On April 30, 2025, Flex completed the acquisition of a manufacturing business in Bielsko Biała, Poland for estimated consideration of $35 million. The acquisition, which will be accounted for as a business combination, is not significant to the consolidated financial position, result of operations and cash flows of the Company. The acquired business will support the growth of Flex's power business in Europe.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000866374-25-000027:notes:374]
QUARTERLY FINANCIAL DATA (UNAUDITED)
The Company's third fiscal quarter ends on December 31, and the fourth fiscal quarter and fiscal year ends on March 31 of each year. The first fiscal quarters of 2025 and 2024 ended on June 28, 2024 and June 30, 2023 respectively, and the second fiscal quarters of 2025 and 2024, ended on September 27, 2024, and September 29, 2023, respectively.

[0000866374-25-000027:notes:375]
The Company completed the Nextracker spin-off in the fourth quarter of fiscal year 2024, which resulted in material retrospective changes to our consolidated statements of operations. See note 7 "Discontinued Operations" for further information. The following tables contain unaudited quarterly financial data for fiscal year 2025 and 2024:

[0000866374-25-000027:notes:376]
|  | Fiscal Year 2025 |
|  | Three Months Ended |
|  | June 28, 2024 |  | September 27, 2024 |  | December 31, 2024 |  | March 31, 2025 |
|  | (In millions, except per share amounts) |
| Net sales | $ | 6,314 |  |  | $ | 6,545 |  |  | $ | 6,556 |  |  | $ | 6,398 |  |
| Gross profit | 471 |  |  | 531 |  |  | 594 |  |  | 563 |  |
| Operating income | 233 |  |  | 297 |  |  | 334 |  |  | 305 |  |
| Net income attributable to Flex Ltd. | 139 |  |  | 214 |  |  | 263 |  |  | 222 |  |
| Weighted-average ordinary shares outstanding - basic | 402 |  | 394 |  | 387 |  | 381 |
| Weighted-average ordinary shares outstanding - diluted | 411 |  | 400 |  | 394 |  | 389 |
| Earnings per share - basic (1) |  |  |  |  |  |  |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.35 |  |  | $ | 0.54 |  |  | $ | 0.68 |  |  | $ | 0.58 |  |
| Earnings per share - diluted (1) |  |  |  |  |  |  |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.34 |  |  | $ | 0.54 |  |  | $ | 0.67 |  |  | $ | 0.57 |  |

[0000866374-25-000027:notes:377]
(1)    Earnings per share are computed independently for each quarter presented; therefore, the sum of the quarterly earnings per share may not equal the total earnings per share amounts for the fiscal year.

[0000866374-25-000027:notes:378]
|  | Fiscal Year 2024 |
|  | Three Months Ended |
|  | June 30, 2023 |  | September 29, 2023 |  | December 31, 2023 |  | March 31, 2024 |
|  | (In millions, except per share amounts) |
| Net sales | $ | 6,892 |  |  | $ | 6,933 |  |  | $ | 6,421 |  |  | $ | 6,169 |  |
| Gross profit | 476 |  |  | 519 |  |  | 433 |  |  | 437 |  |
| Operating income | 215 |  |  | 281 |  |  | 198 |  |  | 159 |  |
| Net income from continuing operations | 147 |  |  | 201 |  |  | 129 |  |  | 395 |  |
| Net income from discontinued operations, net of tax | 64 |  |  | 205 |  |  | 104 |  |  | — |  |
| Net income | 211 |  |  | 406 |  |  | 233 |  |  | 395 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 25 |  |  | 178 |  |  | 36 |  |  | — |  |
| Net income attributable to Flex Ltd. | $ | 186 |  |  | $ | 228 |  |  | $ | 197 |  |  | $ | 395 |  |
| Weighted-average ordinary shares outstanding - basic | 447 |  | 443 |  | 431 |  | 417 |
| Weighted-average ordinary shares outstanding - diluted | 455 |  | 448 |  | 436 |  | 425 |
| Earnings per share - basic (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.33 |  |  | $ | 0.45 |  |  | $ | 0.30 |  |  | $ | 0.95 |  |
| Discontinued operations, net of tax | 0.09 |  |  | 0.06 |  |  | 0.16 |  |  | — |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.42 |  |  | $ | 0.51 |  |  | $ | 0.46 |  |  | $ | 0.95 |  |
| Earnings per share - diluted (1) |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.32 |  |  | $ | 0.45 |  |  | $ | 0.30 |  |  | $ | 0.93 |  |
| Discontinued operations, net of tax | 0.09 |  |  | 0.06 |  |  | 0.15 |  |  | — |  |
| Total attributable to the shareholders of Flex Ltd. | $ | 0.41 |  |  | $ | 0.51 |  |  | $ | 0.45 |  |  | $ | 0.93 |  |
