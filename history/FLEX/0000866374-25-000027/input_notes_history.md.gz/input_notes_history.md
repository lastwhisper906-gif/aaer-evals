# FLEX note change history — 0000866374-24-000053 → 0000866374-25-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a
  (was, 2024-10-31, similarity 0.828):
[0000866374-24-000053:note_history:1]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated,

- added (2025-01-31):
[0000866374-25-000008:note_history:2]
material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

- changed (2025-01-31):
[0000866374-25-000008:note_history:3]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. In the quarter ended December 31, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.
  (was, 2024-10-31, similarity 0.9621):
[0000866374-24-000053:note_history:3]
A foreign Tax Authority (“Tax Authority”) had assessed a cumulative total of approximately $285 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. Subsequent to the quarter ended September 27, 2024, approximately $118 million of the approximate $285 million assessment was abated by the Tax Authority, leaving approximately $167 million remaining. The Company disagrees with the Tax Authority’s remaining assessments and is actively contesting the assessments through the administrative and judicial processes.

- removed (2025-01-31):
[0000866374-24-000053:note_history:4]
(iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:5]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle and healthcare. As of December 31, 2024, Flex's two operating and reportable segments were as follows:
  (was, 2024-10-31, similarity 0.9733):
[0000866374-24-000053:note_history:5]
Flex Ltd. ("Flex" or the "Company") is the advanced, end-to-end manufacturing partner of choice that helps market-leading brands design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports our customers' entire product lifecycle with a broad array of services in every major region. The Company's full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services. Flex partners with customers across a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of September 27, 2024, Flex's two operating and reportable segments were as follows:

- changed (2025-01-31):
[0000866374-25-000008:note_history:6]
◦Communications, Enterprise and Cloud ("CEC"), including data infrastructure, edge infrastructure and communications infrastructure
  (was, 2024-10-31, similarity 0.9685):
[0000866374-24-000053:note_history:6]
◦Communications, Enterprise and Cloud, including data infrastructure, edge infrastructure and communications infrastructure

- changed (2025-01-31):
[0000866374-25-000008:note_history:7]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards, power adapters and chargers).
  (was, 2024-10-31, similarity 0.9964):
[0000866374-24-000053:note_history:7]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance), supply chain management software solutions and component product offerings (including flexible printed circuit boards and power adapters and chargers).

- changed (2025-01-31):
[0000866374-25-000008:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.
  (was, 2024-10-31, similarity 0.9928):
[0000866374-24-000053:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2024 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and six-month periods ended September 27, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025.

- added (2025-01-31):
[0000866374-25-000008:note_history:9]
The third quarters for fiscal years 2025 and 2024 ended on December 31 of each year and are comprised of 95 and 93 days, respectively. The Company's first three quarters for fiscal years 2025 and 2024 are both comprised of 275 days.

- changed (2025-01-31):
[0000866374-25-000008:note_history:10]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows
  (was, 2024-10-31, similarity 0.7551):
[0000866374-24-000053:note_history:10]
On January 2, 2024, Flex completed its spin-off (the "Spin-off") of its remaining interest in Nextracker Inc. ("Nextracker"). After the Spin-off, Flex no longer consolidates the financial results of Nextracker within its financial results of continuing operations. For all the periods prior to the Spin-off, the financial results of Nextracker are presented as net earnings from

- added (2025-01-31):
[0000866374-25-000008:note_history:11]
and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

- added (2025-01-31):
[0000866374-25-000008:note_history:12]
In November 2024, the FASB issued ASU 2024-03 "Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses", which requires public entities to disclose specified information about certain costs and expenses. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2028 and will be applied retrospectively to all prior periods presented on its consolidated financial statements. We are currently evaluating the guidance to determine the impact on the Company's disclosures.

- changed (2025-01-31):
[0000866374-25-000008:note_history:13]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company has assessed the impact of ASU 2023-07 on its consolidated financial statements and intends to adopt the guidance retrospectively with the updated segment disclosures in the fourth quarter of fiscal year 2025.
  (was, 2024-10-31, similarity 0.925):
[0000866374-24-000053:note_history:13]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company is currently assessing the impact of ASU 2023-07 on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.

- removed (2025-01-31):
[0000866374-24-000053:note_history:14]
The first quarters for fiscal years 2025 and 2024 ended on June 28, 2024, which is comprised of 89 days in the period, and June 30, 2023, which is comprised of 91 days, respectively. The second quarters for fiscal years 2025 and 2024 ended on September 27, 2024 and September 29, 2023, respectively, which are comprised of 91 days in both periods.

- removed (2025-01-31):
[0000866374-24-000053:note_history:15]
discontinued operations in the condensed consolidated statements of operations and unless otherwise indicated Flex's disclosures are presented on a continuing operations basis. The historical statements of comprehensive income and cash flows and the balances related to shareholders' equity have not been revised to reflect the Spin-off. See note 6 "Discontinued Operations" for additional information.

- removed (2025-01-31):
[0000866374-24-000053:note_history:16]
Supplier Finance Programs

- removed (2025-01-31):
[0000866374-24-000053:note_history:17]
The Company has four supplier finance programs, all of which have substantially similar characteristics, with various financial institutions that act as the paying agent for certain payables of the Company. The Company established these programs through agreements with the financial institutions to enable more efficient payment processing to our suppliers while also providing our suppliers a potential source of liquidity to the extent they choose to sell their receivables to the financial institutions in advance of the due dates. Our suppliers’ participation in the programs is voluntary, the Company is not involved in negotiations of the suppliers’ arrangements with the financial institutions to sell their receivables, and our rights and obligations to our suppliers are not impacted by our suppliers’ decisions to sell amounts under these programs. Under these supplier finance programs, the Company pays the financial institutions the stated amount of confirmed invoices from its participating suppliers on the original maturity dates of the invoices. All payment terms are short-term in nature and are not dependent on whether the suppliers participate in the supplier finance programs or if the suppliers elect to receive early payment from the financial institutions. No guarantees are provided by the Company under the supplier finance programs and the Company incurs no costs related to the programs. We have no economic interest in a supplier’s decision to participate in the supplier finance programs.

- removed (2025-01-31):
[0000866374-24-000053:note_history:18]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The Company's outstanding obligations confirmed as valid under its supplier finance programs as of September 27, 2024 and March 31, 2024 were $133 million and $123 million, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:19]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2024 and March 31, 2024 are as follows:
  (was, 2024-10-31, similarity 0.9789):
[0000866374-24-000053:note_history:19]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of September 27, 2024 and March 31, 2024 are as follows:

- changed (2025-01-31):
[0000866374-25-000008:note_history:20]
|  | Maturity Date |  | As of December 31, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 679 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 677 |  |  | 681 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 254 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (16) |  |  | (15) |  |
|  |  |  | 3,679 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (532) |  |  | — |  |
| Non-current portion |  |  | $ | 3,147 |  |  | $ | 3,261 |  |
  (was, 2024-10-31, similarity 0.753):
[0000866374-24-000053:note_history:20]
|  | Maturity Date |  | As of September 27, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 680 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 678 |  |  | 681 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (2) | December 2031 |  | 283 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (17) |  |  | (15) |  |
|  |  |  | 3,709 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (531) |  |  | — |  |
| Non-current portion |  |  | $ | 3,178 |  |  | $ | 3,261 |  |

- added (2025-01-31):
[0000866374-25-000008:note_history:21]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.

- changed (2025-01-31):
[0000866374-25-000008:note_history:22]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of December 31, 2024 and March 31, 2024, respectively.
  (was, 2024-10-31, similarity 0.9805):
[0000866374-24-000053:note_history:22]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.5% as of September 27, 2024 and March 31, 2024, respectively.

- changed (2025-01-31):
[0000866374-25-000008:note_history:23]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2024 are as follows:
  (was, 2024-10-31, similarity 0.9767):
[0000866374-24-000053:note_history:23]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 27, 2024 are as follows:

- changed (2025-01-31):
[0000866374-25-000008:note_history:24]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2025.
  (was, 2024-10-31, similarity 0.9574):
[0000866374-24-000053:note_history:24]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2025.

- removed (2025-01-31):
[0000866374-24-000053:note_history:25]
Notes due January 2032

- removed (2025-01-31):
[0000866374-24-000053:note_history:26]
In August 2024, the Company issued $500 million of 5.250% Notes due 2032 (the “Notes”). The Company received proceeds of approximately $496 million, net of discount and certain issuance costs. The Company incurred and capitalized as a direct reduction to the carrying amount of the Notes presented on the balance sheet of approximately $5 million of costs incurred in conjunction with the Notes issuance. Interest on the Notes is payable on January 15 and July 15 of each year, beginning on January 15, 2025.

- removed (2025-01-31):
[0000866374-24-000053:note_history:27]
The indenture governing the Notes contains covenants that, among other things, restrict the ability of the Company and certain of the Company's subsidiaries to create liens; enter into sale-leaseback transactions; and consolidate or merge with, or convey, transfer or lease all or substantially all of the Company's assets to, another person, or permit any other person to consolidate, merge, combine or amalgamate with or into the Company. These covenants are subject to a number of significant limitations and exceptions set forth in the indenture. The indenture also provides for customary events of default, including, but not limited to, cross defaults to certain specified other debt of the Company and its subsidiaries.

- removed (2025-01-31):
[0000866374-24-000053:note_history:28]
In the case of an event of default arising from specified events of bankruptcy or insolvency, all outstanding Notes will become due and payable immediately without further action or notice. If any other event of default under the indenture occurs or is continuing, the trustee or holders of at least 25% in aggregate principal amount of the then outstanding Notes may declare the entire principal of Notes, together with all accrued and unpaid interest, if any, to be due and payable immediately, but upon certain conditions such declaration and its consequences may be rescinded and annulled by the holders of a majority in principal amount of the Notes. As of September 27, 2024, the Company was in compliance with the covenants in the indenture governing the Notes.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:29]
|  | As of December 31, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 532 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 679 |  |  | 670 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 398 |  |  | 406 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 644 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 677 |  |  | 662 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 494 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 254 |  |  | 203 |  |  | 274 |  |  | 219 |  |  | Level 2 |
  (was, 2024-10-31, similarity 0.9947):
[0000866374-24-000053:note_history:29]
|  | As of September 27, 2024 |  | As of March 31, 2024 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| 4.750% Notes due June 2025 | $ | 532 |  |  | $ | 531 |  |  | $ | 584 |  |  | $ | 578 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 680 |  |  | 673 |  |  | 682 |  |  | 662 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 397 |  |  | 404 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 656 |  |  | 658 |  |  | 657 |  |  | 643 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 678 |  |  | 679 |  |  | 681 |  |  | 662 |  |  | Level 1 |
| 5.250% Notes due January 2032 | 499 |  |  | 503 |  |  | — |  |  | — |  |  | Level 1 |
| 3.600% HUF Bonds due December 2031 | 283 |  |  | 226 |  |  | 274 |  |  | 219 |  |  | Level 2 |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:30]
Bank borrowings and long-term debt as of December 31, 2024 and March 31, 2024 are as follows:
  (was, 2024-10-31, similarity 0.9701):
[0000866374-24-000053:note_history:30]
Bank borrowings and long-term debt as of September 27, 2024 and March 31, 2024 are as follows:

- changed (2025-01-31):
[0000866374-25-000008:note_history:31]
|  | Maturity Date |  | As of December 31, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 679 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 398 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 677 |  |  | 681 |  |
| 5.250% Notes (1) (2) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (3) | December 2031 |  | 254 |  |  | 274 |  |
| Other |  |  | — |  |  | 1 |  |
| Debt issuance costs |  |  | (16) |  |  | (15) |  |
|  |  |  | 3,679 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (532) |  |  | — |  |
| Non-current portion |  |  | $ | 3,147 |  |  | $ | 3,261 |  |
  (was, 2024-10-31, similarity 0.753):
[0000866374-24-000053:note_history:31]
|  | Maturity Date |  | As of September 27, 2024 |  | As of March 31, 2024 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 532 |  |  | $ | 584 |  |
| 3.750% Notes (1) | February 2026 |  | 680 |  |  | 682 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 397 |  |
| 4.875% Notes (1) | June 2029 |  | 656 |  |  | 657 |  |
| 4.875% Notes (1) | May 2030 |  | 678 |  |  | 681 |  |
| 5.250% Notes (1) | January 2032 |  | 499 |  |  | — |  |
| 3.600% HUF Bonds (2) | December 2031 |  | 283 |  |  | 274 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (17) |  |  | (15) |  |
|  |  |  | 3,709 |  |  | 3,261 |  |
| Current portion, net of debt issuance costs |  |  | (531) |  |  | — |  |
| Non-current portion |  |  | $ | 3,178 |  |  | $ | 3,261 |  |

- changed (2025-01-31):
[0000866374-25-000008:note_history:32]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
  (was, 2024-10-31, similarity 0.7217):
[0000866374-24-000053:note_history:32]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. The notes are the Company’s senior unsecured obligations and rank equally with all other existing and future senior unsecured debt obligations.
(2)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.

- added (2025-01-31):
[0000866374-25-000008:note_history:33]
(2)In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs.
(3)The bonds mature in December 2031 with annual payments equal to 10% of the original principal amount thereof on each of the seventh, eighth, and ninth anniversaries of the bonds, with the remaining 70% due upon maturity.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2024 are as follows:
  (was, 2024-10-31, similarity 0.9767):
[0000866374-24-000053:note_history:34]
Scheduled repayments of the Company's bank borrowings and long-term debt as of September 27, 2024 are as follows:

- changed (2025-01-31):
[0000866374-25-000008:note_history:35]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2025.
  (was, 2024-10-31, similarity 0.9574):
[0000866374-24-000053:note_history:35]
(1)Represents estimated repayments for the remaining fiscal six-month period ending March 31, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:36]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-10-31, similarity 0.8825):
[0000866374-24-000053:note_history:36]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 27, 2024 and September 29, 2023, respectively.

- changed (2025-01-31):
[0000866374-25-000008:note_history:37]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,849 |  |  | $ | 3,151 |  |  | $ | 8,646 |  |  | $ | 9,867 |  |
| Over time | 750 |  |  | 314 |  |  | 1,924 |  |  | 817 |  |
| Total | 3,599 |  |  | 3,465 |  |  | 10,570 |  |  | 10,684 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,960 |  |  | 2,793 |  |  | 6,830 |  |  | 9,070 |  |
| Over time | 997 |  |  | 163 |  |  | 2,015 |  |  | 492 |  |
| Total | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,809 |  |  | 5,944 |  |  | 15,476 |  |  | 18,937 |  |
| Over time | 1,747 |  |  | 477 |  |  | 3,939 |  |  | 1,309 |  |
| Total | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |
  (was, 2024-10-31, similarity 0.9737):
[0000866374-24-000053:note_history:37]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,924 |  |  | $ | 3,280 |  |  | $ | 5,797 |  |  | $ | 6,716 |  |
| Over time | 682 |  |  | 338 |  |  | 1,174 |  |  | 503 |  |
| Total | 3,606 |  |  | 3,618 |  |  | 6,971 |  |  | 7,219 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,237 |  |  | 3,145 |  |  | 4,870 |  |  | 6,277 |  |
| Over time | 702 |  |  | 170 |  |  | 1,018 |  |  | 329 |  |
| Total | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,161 |  |  | 6,425 |  |  | 10,667 |  |  | 12,993 |  |
| Over time | 1,384 |  |  | 508 |  |  | 2,192 |  |  | 832 |  |
| Total | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000866374-25-000008:note_history:38]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $355 million and $490 million as of December 31, 2024 and March 31, 2024, respectively, of which $314 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.
  (was, 2024-10-31, similarity 0.9912):
[0000866374-24-000053:note_history:38]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $372 million and $490 million as of September 27, 2024 and March 31, 2024, respectively, of which $334 million and $449 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

- changed (2025-01-31):
[0000866374-25-000008:note_history:39]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2024 and December 31, 2023, respectively.
  (was, 2024-10-31, similarity 0.8825):
[0000866374-24-000053:note_history:39]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and six-month periods ended September 27, 2024 and September 29, 2023, respectively.

- changed (2025-01-31):
[0000866374-25-000008:note_history:40]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,849 |  |  | $ | 3,151 |  |  | $ | 8,646 |  |  | $ | 9,867 |  |
| Over time | 750 |  |  | 314 |  |  | 1,924 |  |  | 817 |  |
| Total | 3,599 |  |  | 3,465 |  |  | 10,570 |  |  | 10,684 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 1,960 |  |  | 2,793 |  |  | 6,830 |  |  | 9,070 |  |
| Over time | 997 |  |  | 163 |  |  | 2,015 |  |  | 492 |  |
| Total | 2,957 |  |  | 2,956 |  |  | 8,845 |  |  | 9,562 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 4,809 |  |  | 5,944 |  |  | 15,476 |  |  | 18,937 |  |
| Over time | 1,747 |  |  | 477 |  |  | 3,939 |  |  | 1,309 |  |
| Total | $ | 6,556 |  |  | $ | 6,421 |  |  | $ | 19,415 |  |  | $ | 20,246 |  |
  (was, 2024-10-31, similarity 0.9737):
[0000866374-24-000053:note_history:40]
|  | Three-Month Periods Ended |  | Six-Month Periods Ended |
|  | September 27, 2024 |  | September 29, 2023 |  | September 27, 2024 |  | September 29, 2023 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 2,924 |  |  | $ | 3,280 |  |  | $ | 5,797 |  |  | $ | 6,716 |  |
| Over time | 682 |  |  | 338 |  |  | 1,174 |  |  | 503 |  |
| Total | 3,606 |  |  | 3,618 |  |  | 6,971 |  |  | 7,219 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,237 |  |  | 3,145 |  |  | 4,870 |  |  | 6,277 |  |
| Over time | 702 |  |  | 170 |  |  | 1,018 |  |  | 329 |  |
| Total | 2,939 |  |  | 3,315 |  |  | 5,888 |  |  | 6,606 |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,161 |  |  | 6,425 |  |  | 10,667 |  |  | 12,993 |  |
| Over time | 1,384 |  |  | 508 |  |  | 2,192 |  |  | 832 |  |
| Total | $ | 6,545 |  |  | $ | 6,933 |  |  | $ | 12,859 |  |  | $ | 13,825 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-01-31):
[0000866374-24-000053:note_history:41]
SUBSEQUENT EVENTS
On October 16, 2024, the Company entered into a definitive agreement to acquire 100% ownership of Crown Technical Systems (“Crown”), a U.S. leader in critical power solutions for $325 million in an all-cash transaction. The acquisition will add to the Company' portfolio of power products and expand its offering in the utility and data center markets and is expected to close in the third quarter of fiscal year 2025, subject to customary closing conditions, including regulatory approval. For reporting purposes, Crown will be included in the Industrial reporting unit within the FRS segment.
