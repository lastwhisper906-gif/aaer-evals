# FLEX MD&A — 0000866374-25-000027


## mdna

[0000866374-25-000027:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000866374-25-000027:mdna:2]
OVERVIEW

[0000866374-25-000027:mdna:3]
We are the advanced, end-to-end manufacturing partner of choice that helps a diverse customer base design, build, deliver and manage innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we deliver technology innovation, supply chain, and manufacturing solutions to diverse industries and end markets. Our full suite of specialized capabilities includes design and engineering, supply chain, manufacturing, post-production and post-sale services, and proprietary products. We partner with customers across a diverse set of industries including data center, communications, enterprise, consumer, automotive, industrial, healthcare, industrial and power. As of March 31, 2025, we report our financial performance based on two operating and reportable segments as follows:

[0000866374-25-000027:mdna:4]
•Flex Agility Solutions ("FAS"), which is comprised of the following end markets:

[0000866374-25-000027:mdna:5]
◦Communications, Enterprise and Cloud ("CEC"), including data center, edge, and communications infrastructure

[0000866374-25-000027:mdna:6]
◦Lifestyle, including appliances, floorcare, smart living, HVAC, and power tools

[0000866374-25-000027:mdna:7]
◦Consumer Devices, including mobile and high velocity consumer devices.

[0000866374-25-000027:mdna:8]
•Flex Reliability Solutions ("FRS"), which is comprised of the following end markets:

[0000866374-25-000027:mdna:9]
◦Industrial, including industrial devices, capital equipment, renewables, critical power, and embedded power.

[0000866374-25-000027:mdna:10]
◦Automotive, including compute platforms, power electronics, motion, and interface

[0000866374-25-000027:mdna:11]
◦Health Solutions, including medical devices, medical equipment, and drug delivery

[0000866374-25-000027:mdna:12]
In fiscal year 2025, we formally introduced the next phase in our strategic evolution, its EMS + Products + Services approach. This hybrid model is focused on strengthening our core manufacturing and supply chain capabilities while expanding our portfolio of proprietary products and value-added services to maximize value creation for customers. To advance this approach, we completed several strategic acquisitions in fiscal year 2025 that enhance our differentiated portfolio to address critical data center customer challenges around power, heat and scale. These included the acquisitions of JetCool to expand direct-to-chip liquid cooling capabilities and Crown to increase critical power capabilities while adding opportunities in grid modernization.

[0000866374-25-000027:mdna:13]
Our strategy is to provide customers with a full range of cost competitive, vertically-integrated global supply chain solutions through which we can design, build, ship and service a complete packaged product for our customers. This enables our customers to leverage our supply chain solutions to meet their product requirements throughout the entire product lifecycle.

[0000866374-25-000027:mdna:14]
In today’s business landscape, we are witnessing greater product diversification by many companies, primarily in the technology sector, along with increased product complexity. These companies now require unique and customized manufacturing and supply chain solutions that meet their evolving requirements.

[0000866374-25-000027:mdna:15]
We use a portfolio approach to manage our extensive service offerings. As our customers change the way they go to market, we have the capability to reorganize and rebalance our business portfolio in order to align with our customers' needs and requirements in an effort to optimize operating results. The objective of our business model is to allow us to be flexible and redeploy and reposition our assets and resources as necessary to meet specific customers' supply chain solution needs across all the markets we serve and earn a return on our invested capital above the weighted average cost of that capital.

[0000866374-25-000027:mdna:16]
We believe that our strategy is positioning us to take advantage of the long-term, future growth prospects for outsourcing of advanced manufacturing capabilities, design and engineering services and after-market services.

[0000866374-25-000027:mdna:17]
We are continuously evaluating our capital structure in response to the current environment and expect that our current financial condition, including our liquidity sources are adequate to fund future commitments. See additional discussion in the Liquidity and Capital Resources section below.

[0000866374-25-000027:mdna:18]
Nextracker Spin-off

[0000866374-25-000027:mdna:19]
On February 13, 2023, our former subsidiary, Nextracker completed an initial public offering (the "IPO") of its Class A common stock and on July 3, 2023 completed a follow-on offering to the IPO. Prior to the IPO, we maintained an 82.6% indirect ownership in Nextracker and consolidated Nextracker. Subsequent to the IPO and follow-on offering, we retained a 51.5% indirect ownership in Nextracker and continued to consolidate Nextracker and report Nextracker as an operating segment.

[0000866374-25-000027:mdna:20]
On January 2, 2024, we completed the previously announced Nextracker spin-off to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the "Distribution") as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023. Under the terms of the spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for each Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

[0000866374-25-000027:mdna:21]
As a result of the completion of the spin-off, Nextracker became a fully independent public company, we no longer directly or indirectly hold any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and subsequent to the third quarter ended December 31, 2023 we no longer consolidate Nextracker into our financial results. Flex ordinary shares continue to trade on Nasdaq under the ticker symbol "FLEX" and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol "NXT".

[0000866374-25-000027:mdna:22]
The historical financial results and financial position of Nextracker are presented as discontinued operations in the consolidated statements of operations for all periods (through the date of the Nextracker spin-off) presented. The historical statements of comprehensive income and cash flows and the balances related to stockholders’ equity have not been revised to reflect the effect of the spin-off. See note 7 "Discontinued Operations" to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further information. Unless otherwise indicated, any reference to income statement items in this "Management’s Discussion and Analysis of Financial Condition and Results of Operations" refers to results from continuing operations.

[0000866374-25-000027:mdna:23]
Update on Component Shortages and Logistical Constraints on our Business

[0000866374-25-000027:mdna:24]
Component shortages experienced in the recent past have largely subsided, however logistical constraints persist which have increased freight costs. We continue to monitor potential supply chain disruptions, as a result of emerging and evolving geopolitical tensions and tariff implementations. Refer to "Risk Factors - Supply chain disruptions, logistical constraints, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future affect, our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory" and "- Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets."

[0000866374-25-000027:mdna:25]
Russian Invasion of Ukraine and Israel-Hamas War

[0000866374-25-000027:mdna:26]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-25-000027:mdna:27]
Tariffs

[0000866374-25-000027:mdna:28]
The U.S. tariffs initially announced in April 2025, which continue to evolve, and other countries' potential retaliatory tariffs and import/export restrictions may materially increase our product input costs and negatively affect global economic conditions contracting customer demand. As a contract manufacturer, we expect to recover the cost of tariffs by passing tariff

[0000866374-25-000027:mdna:29]
costs to our customers which would increase net sales, decrease operating income margins, and negatively affect operating cash flow timing as we recover paid tariffs from our customers. To the extent we are unsuccessful in passing tariff costs to our customers, our results of operations and cash flows would be negatively impacted.  We will continue to monitor changes in global trade policy and employ measures to mitigate the impact of tariffs and leverage competitive opportunities. However, despite these efforts, the Company may not be able to fully mitigate the impact of changes in trade policies or an economic downturn.  See Risk Factors - "Global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets have in the past adversely affected, and may in the future adversely affect, our business, results of operations, financial condition, and access to capital markets."

[0000866374-25-000027:mdna:30]
Business Overview

[0000866374-25-000027:mdna:31]
We are one of the world's largest providers of global supply chain solutions, with revenues from continuing operations of $25.8 billion in the fiscal year ended March 31, 2025. We have established an extensive network of manufacturing facilities in the world's major markets (Asia, the Americas, and Europe) to serve the outsourcing needs of both multinational and regional customers. We design, build, ship, and service products for our customers through a network of approximately 100 facilities in approximately 30 countries across four continents. As of March 31, 2025, our total manufacturing capacity was approximately 27 million square feet. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment, by country, based on the location of our manufacturing sites (amounts may not sum due to rounding):

[0000866374-25-000027:mdna:32]
|  | Fiscal Year Ended March 31, |
|  | 2025 | 2024 |  |  |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |
| Americas | $ | 12,656 |  | 49 | % | $ | 12,232 |  | 46 | % |  |  |  |  |
| Asia | 7,701 |  | 30 | % | 8,540 |  | 32 | % |  |  |  |  |
| Europe | 5,456 |  | 21 | % | 5,643 |  | 22 | % |  |  |  |  |
|  | $ | 25,813 |  |  | $ | 26,415 |  |  |  |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |
| Mexico | $ | 6,854 |  | 27 | % | $ | 6,935 |  | 26 | % |  |  |  |  |
| China | 4,319 |  | 17 | % | 5,117 |  | 19 | % |  |  |  |  |
| U.S. | 4,162 |  | 16 | % | 3,598 |  | 14 | % |  |  |  |  |
| Malaysia | 2,379 |  | 9 | % | 2,122 |  | 8 | % |  |  |  |  |
| Brazil | 1,552 |  | 6 | % | 1,529 |  | 6 | % |  |  |  |  |
| Hungary | 1,316 |  | 5 | % | 1,368 |  | 5 | % |  |  |  |  |
| Other | 5,231 |  | 20 | % | 5,746 |  | 22 | % |  |  |  |  |
|  | $ | 25,813 |  |  | $ | 26,415 |  |  |  |  |  |  |

[0000866374-25-000027:mdna:33]
|  | Fiscal Year Ended March 31, |
|  | 2025 | 2024 |
|  | (In millions) |
| Property and equipment, net: |  |  |  |  |
| Mexico | $ | 815 |  | 35 | % | $ | 793 |  | 35 | % |
| U.S. | 376 |  | 16 | % | 334 |  | 15 | % |
| China | 293 |  | 13 | % | 307 |  | 14 | % |
| Malaysia | 163 |  | 7 | % | 142 |  | 6 | % |
| Hungary | 140 |  | 6 | % | 124 |  | 5 | % |
| Brazil | 83 |  | 4 | % | 88 |  | 4 | % |
| Other | 460 |  | 19 | % | 481 |  | 21 | % |
|  | $ | 2,330 |  |  | $ | 2,269 |  |  |

[0000866374-25-000027:mdna:34]
38

[0000866374-25-000027:mdna:35]
We believe that the combination of our extensive open innovation platform solutions, design and engineering services, advanced supply chain management solutions and services, significant scale and global presence, and manufacturing campuses, including many in low-cost geographic areas provide us with a competitive advantage and strong differentiation in the market for designing, manufacturing and servicing products for leading multinational and regional customers. Specifically, we offer our customers the ability to simplify their global product development, manufacturing process, and after-sales services, and enable them to meaningfully accelerate their time to market and cost savings.

[0000866374-25-000027:mdna:36]
Our operating results are affected by a number of factors, including the following:

[0000866374-25-000027:mdna:37]
•global economic conditions, including inflationary pressures, currency volatility, stagflation, slower economic growth or recession, high or rising interest rates, trade conflicts, tariffs, geopolitical uncertainty and instability in financial markets;

[0000866374-25-000027:mdna:38]
•the mix of the manufacturing services we are providing, the number, size, and complexity of new manufacturing programs, the degree to which we utilize our manufacturing capacity, seasonal demand, and other factors;

[0000866374-25-000027:mdna:39]
•the effects on our business when our customers are not successful in marketing their products, or when their products do not gain widespread commercial acceptance;

[0000866374-25-000027:mdna:40]
•our ability to achieve commercially viable production yields and to manufacture components in commercial quantities to the performance specifications demanded by our customers;

[0000866374-25-000027:mdna:41]
•the effects on our business due to certain customers' products having short product lifecycles, our customers' ability to cancel or delay orders or change production quantities or locations, the short-term nature of our customers' commitments and rapid changes in demand;

[0000866374-25-000027:mdna:42]
•the effects that current credit and market conditions could have on the liquidity and financial condition of our customers and suppliers, including any impact on their ability to meet their contractual obligations;

[0000866374-25-000027:mdna:43]
•the impacts on our business due to supply chain issues, including component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea;

[0000866374-25-000027:mdna:44]
•integration of acquired businesses and facilities;

[0000866374-25-000027:mdna:45]
•increased labor costs due to adverse labor conditions in the markets we operate;

[0000866374-25-000027:mdna:46]
•changes in tax legislation;

[0000866374-25-000027:mdna:47]
•changes in trade regulations and treaties; and

[0000866374-25-000027:mdna:48]
•exposure to infectious disease, epidemics and pandemics on our business operations in geographic locations impacted by an outbreak and on the business operations of our customers and suppliers.

[0000866374-25-000027:mdna:49]
We also are subject to other risks as outlined in Item 1A, "Risk Factors".

[0000866374-25-000027:mdna:50]
Net sales for fiscal year 2025 decreased approximately 2%, or $0.6 billion, to $25.8 billion from the prior year. Net sales for our FAS segment increased $0.2 billion, or 1%, from the prior year, primarily driven by a 1% increase in our CEC business, as strength in cloud outweighed softer demand in non-cloud. In addition, our CEC business benefited from an approximate $1 billion increase in customer buy-sell activity, which increases gross profit, but is accounted for as a reduction of the transaction price, and therefore, excluded from net sales. In customer buy-sell activities, the Company procures components from a customer to use in manufacturing and/or to provide services such as assembly, transformation, and integration. Later, it sells the finished product back to that customer or its end customers. The results of the FAS segment also reflected a 15% increase in our Consumer Devices business from stronger demand, offset by a 4% decrease in our Lifestyle business due to softer demand. Net sales for our FRS segment decreased $0.8 billion, or 6%, from the prior year, primarily driven by a decrease in net sales of 10% in our Industrial business which was driven by weaker demand in renewables, clean energy and industrial devices partially offset by strong growth and the Crown acquisition in critical power offerings, a 3% decrease in our Automotive business and a 3% decrease in our Health Solutions business, both due to lower customer demand. Our fiscal year

[0000866374-25-000027:mdna:51]
2025 gross profit totaled $2.2 billion, representing an increase of $0.3 billion, or 16%, from the prior year. The increase was primarily driven by an increase in gross profit margin due to improved product mix, operational efficiencies and lower restructuring charges. Our net income from continuing operations totaled $0.8 billion, representing a decrease of $34 million, or 4%, compared to fiscal year 2024, due to the factors explained above net of a $0.2 billion provision for income taxes in fiscal 2025 versus a $0.2 billion income tax benefit in fiscal 2024 primarily attributed to the release of a U.S. deferred tax asset valuation allowance occurring during fiscal year 2024, and not reoccurring in fiscal year 2025.

[0000866374-25-000027:mdna:52]
Cash provided by operating activities increased by approximately $0.2 billion in fiscal 2025 as compared with fiscal 2024, as a result of higher profitability (after consideration of non-cash deferred income taxes) and favorable working capital movements. Refer to "Liquidity and Capital Resources" section for further details of changes in net working capital.

[0000866374-25-000027:mdna:53]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted cash flows on a consistent basis for investor transparency. Our adjusted free cash flow was $1.1 billion and $0.8 billion for fiscal years 2025 and 2024, respectively. Refer to the Liquidity and Capital Resources section for the adjusted free cash flows reconciliation to the most directly comparable GAAP financial measure of cash flows from operations. Cash used in investing activities increased by approximately $0.3 billion to a cash outflow of $0.8 billion for fiscal year 2025, compared with a cash outflow of $0.5 billion for fiscal year 2024, primarily due to an increase of approximately $0.4 billion in cash paid for acquisitions of businesses, net of cash acquired in fiscal year 2025. Cash used in financing activities decreased by approximately $0.8 billion to a cash outflow of $0.8 billion for fiscal year 2025, primarily driven by an approximately $0.5 billion increase in cash received from bank borrowings and long-term debt, along with a $0.4 billion decrease in repayments of bank borrowings and long-term debt in fiscal year 2025 compared to fiscal year 2024.

[0000866374-25-000027:mdna:54]
CRITICAL ACCOUNTING ESTIMATES

[0000866374-25-000027:mdna:55]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to global economic conditions, including the impact of ongoing trade conflicts and tariffs, and geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the foregoing factors. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-25-000027:mdna:56]
We believe the following critical accounting estimates affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. For further discussion of our significant accounting policies, refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data."

[0000866374-25-000027:mdna:57]
Revenue Recognition

[0000866374-25-000027:mdna:58]
In determining the appropriate amount of revenue to recognize, we apply the following steps: (i) identify the contracts with the customers; (ii) identify performance obligations in the contracts; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations per the contracts; and (v) recognize revenue when (or as) we satisfy a performance obligation. Further, we assess whether control of the product or services promised under the contract is transferred to the customer at a point in time (PIT) or over time (OT). We are first required to evaluate whether our contracts meet the criteria for OT recognition. We have determined that for a portion of our contracts, we are manufacturing products for which there is no alternative use (due to the unique nature of the customer-specific product and intellectual property restrictions) and we have an enforceable right to payment including a reasonable profit for work-in-progress inventory with respect to these contracts. For certain other contracts, the Company’s performance creates and enhances an asset that the customer controls as the Company performs under the contract. As a result, revenue is recognized under these contracts OT based on the cost-to-cost method as it best depicts the transfer of control to the customer based on the ratio of costs incurred to date as compared to the total estimated costs at completion of the performance obligation. For all other contracts that do not meet these criteria, we recognize revenue when we have transferred control of the related manufactured products which generally occurs upon delivery and passage of title to the customer. Service contract revenue is recognized on an overtime basis using the output method. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-25-000027:mdna:59]
Customer Contracts and Related Obligations

[0000866374-25-000027:mdna:60]
Certain of our customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include, but are not limited to, sharing of cost savings, committed price reductions, material margins earned

[0000866374-25-000027:mdna:61]
over the period that are contractually required to be paid to the customers, rebates, refunds tied to performance metrics such as on-time delivery, and other periodic pricing resets that may be refundable to customers. We estimate the variable consideration related to these price adjustments as part of the total transaction price and recognize revenue in accordance with the pattern applicable to the performance obligation, subject to a constraint. We constrain the amount of revenues recognized for these contractual provisions based on our best estimate of the amount which will not result in a significant reversal of revenue in a future period. We determine the amounts to be recognized based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances. Refer to note 4 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further details.

[0000866374-25-000027:mdna:62]
Inventory Valuation

[0000866374-25-000027:mdna:63]
Our inventories are stated at the lower of cost (on a first-in, first-out basis) or net realizable value. Our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand. We purchase our inventory based on forecasted demand and anticipated component shortages, and we estimate write downs for excess and obsolete inventory based on our regular reviews of inventory quantities on hand, and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers' product demands are less favorable than those projected, additional write downs may be required. In addition, unanticipated changes in the liquidity or financial position of our customers and/or changes in economic conditions may require additional write downs for inventories due to our customers' inability to fulfill their contractual obligations with regards to inventory procured to fulfill customer demand.

[0000866374-25-000027:mdna:64]
Carrying Value of Long-Lived Assets

[0000866374-25-000027:mdna:65]
We review property and equipment and acquired amortizable intangible assets for impairment at least annually and whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. An impairment loss is recognized when the carrying amount of the asset group exceeds its fair value. Recoverability of property and equipment and acquired amortizable intangible assets are measured by comparing their carrying amount to the projected cash flows the assets are expected to generate. If such asset groups are determined to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment and acquired amortizable intangible assets exceeds fair value. Our judgments regarding projected cash flows for an extended period of time and the fair value of assets may be impacted by changes in market conditions, the general business environment and other factors including geopolitical conflicts (including the Russian invasion of Ukraine and the Israel-Hamas war), which remain highly uncertain and unpredictable. To the extent our estimates relating to cash flows and fair value of assets change adversely we may have to recognize material impairment charges in the future.

[0000866374-25-000027:mdna:66]
Business Combinations

[0000866374-25-000027:mdna:67]
In business combinations, the fair value of the net assets acquired and the results of the acquired businesses are included in the Company's consolidated financial statements from the acquisition dates forward. The Company is required to make estimates and assumptions that affect the reported amounts of assets and liabilities and results of operations during the reporting period. Estimates are used in accounting for, among other things, the fair value of acquired net operating assets, property and equipment, intangible assets and related deferred tax balances, useful lives of plant and equipment and amortizable lives for acquired intangible assets. Any excess of the purchase consideration over the fair value of the identified assets and liabilities acquired is recognized as goodwill and if the fair value of assets acquired and liabilities assumed exceeds the purchase consideration a gain on bargain purchase is recognized.

[0000866374-25-000027:mdna:68]
The Company estimates the preliminary fair value of acquired assets and liabilities as of the date of acquisition based on information available at that time. Contingent consideration is recorded at fair value as of the date of the acquisition with subsequent adjustments recorded in earnings. The valuation of acquired assets and liabilities is subject to further management review and may change between the preliminary allocation and end of the one-year purchase price allocation period. Refer to note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our acquisitions.

[0000866374-25-000027:mdna:69]
Goodwill

[0000866374-25-000027:mdna:70]
Goodwill is tested for impairment on an annual basis and whenever events or changes in circumstances indicate that the carrying amount of goodwill may not be recoverable. Recoverability of goodwill is measured at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit, which is measured based upon, among other factors, market multiples for comparable companies as well as a discounted cash flow analysis. These approaches use significant unobservable inputs, or Level 3 inputs, as defined by the fair value hierarchy and require us to make various judgmental assumptions about sales, operating margins, growth rates and discount rates which consider our budgets, business plans and economic projections, and are believed to reflect market participant views. Some of the inherent estimates and assumptions used in determining fair value of the reporting units are outside the control of management, including interest

[0000866374-25-000027:mdna:71]
rates, cost of capital, tax rates, market EBITDA comparables and credit ratings. While we believe we have made reasonable estimates and assumptions to calculate the fair value of the reporting units, it is possible a material change could occur. If our actual results are not consistent with our estimates and assumptions used to calculate fair value, it could result in material impairments of our goodwill. Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further detail on our goodwill.

[0000866374-25-000027:mdna:72]
Income Taxes

[0000866374-25-000027:mdna:73]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities, which will result in deductible amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change due to future market conditions, changes in U.S. or international tax laws and other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against deferred tax assets previously recognized, resulting in additional or lesser income tax expense.

[0000866374-25-000027:mdna:74]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our tax position, operating results, financial position and cash flows. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our tax position.

[0000866374-25-000027:mdna:75]
RESULTS OF OPERATIONS

[0000866374-25-000027:mdna:76]
The following table sets forth, for the periods indicated, certain statements of operations data expressed as a percentage of net sales (amounts may not sum due to rounding). The financial information and the discussion below should be read in conjunction with the consolidated financial statements and notes thereto included in Item 8, "Financial Statements and Supplementary Data".

[0000866374-25-000027:mdna:77]
The data below, and discussion that follows, represents our results from operations, and relative percentages.

[0000866374-25-000027:mdna:78]
|  | Fiscal Year EndedMarch 31, |
|  | 2025 |  | 2024 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 91.4 |  |  | 92.4 |  |  |  |  |  |
| Restructuring charges | 0.2 |  |  | 0.5 |  |  |  |  |  |
| Gross profit | 8.4 |  |  | 7.1 |  |  |  |  |  |
| Selling, general and administrative expenses | 3.5 |  |  | 3.5 |  |  |  |  |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Operating income | 4.5 |  |  | 3.2 |  |  |  |  |  |
| Interest expense | 0.8 |  |  | 0.8 |  |  |  |  |  |
| Interest income | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Other charges (income), net | (0.1) |  |  | 0.2 |  |  |  |  |  |
| Equity in earnings (losses) of unconsolidated affiliates | — |  |  | 0.1 |  |  |  |  |  |
| Income from continuing operations before income taxes | 4.0 |  |  | 2.5 |  |  |  |  |  |
| Provision for (benefit from) income taxes | 0.8 |  |  | (0.8) |  |  |  |  |  |
| Net income from continuing operations | 3.2 |  |  | 3.3 |  |  |  |  |  |
| Net income from discontinued operations, net of tax | — |  |  | 1.4 |  |  |  |  |  |
| Net income | 3.2 |  |  | 4.7 |  |  |  |  |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | — |  |  | 0.9 |  |  |  |  |  |
| Net income attributable to Flex Ltd. | 3.2 | % |  | 3.8 | % |  |  |  |  |

[0000866374-25-000027:mdna:79]
Net sales

[0000866374-25-000027:mdna:80]
The following table sets forth our net sales by segment, and their relative percentages:

[0000866374-25-000027:mdna:81]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  |  |  |  |
| Net sales: | (In millions) |
| Flex Agility Solutions | $ | 14,074 |  |  | 55 | % |  | $ | 13,923 |  |  | 53 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 11,739 |  |  | 45 | % |  | 12,492 |  |  | 47 | % |  |  |  |  |  |  |  |  |
|  | $ | 25,813 |  |  |  |  | $ | 26,415 |  |  |  |  |  |  |  |  |  |  |  |

[0000866374-25-000027:mdna:82]
Net sales for the fiscal year ended March 31, 2025 totaled $25.8 billion, representing a decrease of approximately $0.6 billion, or 2%, from $26.4 billion for the fiscal year ended March 31, 2024. Net sales for our FAS segment increased $0.2 billion, or 1%, from fiscal year 2024, mainly due to a 1% increase in our CEC business as strength in cloud outweighed softer demand in non-cloud. In addition, the CEC business benefited from an approximate $1 billion increase in customer buy-sell activity, which increases gross profit, but is accounted for as a reduction of the transaction price, and therefore, excluded from net sales. The results of the FAS segment also reflected a 15% increase in our Consumer Devices business from stronger demand, offset by a 4% decrease in our Lifestyle business due to softer demand. Net sales in our FRS segment decreased $0.8 billion, or 6%, from fiscal year 2024, driven primarily by a decrease in net sales of 10% in our Industrial business which was driven by weaker demand in renewables, clean energy and industrial devices partially offset by strong growth and the Crown acquisition in critical power offerings, a 3% decrease in our Automotive business, and a 3% decrease in our Health Solution business, primarily driven by softening demand in medical equipment, partially offset by increased demand for medical devices.  The factors described above include the impact of certain customers transitioning from point in time to over time revenue recognition which increased net sales by approximately 1% for the year ended March 31, 2025.  This transition also contributed to an increase in contract assets as of March 31, 2025.

[0000866374-25-000027:mdna:83]
Net sales for the fiscal year ended March 31, 2025 increased $0.4 billion to $12.7 billion in the Americas, decreased $0.8 billion to $7.7 billion in Asia, and decreased $0.2 billion to $5.5 billion in Europe.

[0000866374-25-000027:mdna:84]
Our ten largest customers during fiscal years 2025 and 2024 accounted for approximately 44% and 37% of net sales, respectively. We have made substantial efforts to maintain a diverse portfolio which allows us to operate at scale in many different industries, and, as a result, no customer accounted for greater than 10% of net sales in fiscal year 2025 or 2024.

[0000866374-25-000027:mdna:85]
Cost of sales

[0000866374-25-000027:mdna:86]
Cost of sales is affected by a number of factors, including the number and size of new manufacturing programs, product mix, labor cost fluctuations by region, component costs and availability and capacity utilization.

[0000866374-25-000027:mdna:87]
Cost of sales during fiscal year 2025 totaled $23.6 billion, representing a decrease of approximately $0.8 billion, or 3% from $24.4 billion during fiscal year 2024. The decrease in cost of sales is more than the decreased consolidated sales of $0.6 billion, or 2%, as a result of favorable mix with increases in revenue in higher margin cloud and power products as well as cost actions taken during the period. Cost of sales in FAS decreased $45 million, less than 1%, from fiscal year 2024 and cost of sales in FRS for fiscal year 2025 decreased $0.8 billion, or approximately 7%, from fiscal year 2024, as a result of decreased sales and product mix.

[0000866374-25-000027:mdna:88]
Gross profit

[0000866374-25-000027:mdna:89]
Gross profit is affected by a fluctuation in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all markets. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-25-000027:mdna:90]
Gross profit during fiscal year 2025 increased $0.3 billion to $2.2 billion, or 8.4% of net sales, from $1.9 billion, or 7.1% of net sales, during fiscal year 2024. The increase in gross profit during fiscal year 2025 in spite of lower sales was due to the factors discussed above as well as lower restructuring costs in fiscal year 2025.

[0000866374-25-000027:mdna:91]
Segment income

[0000866374-25-000027:mdna:92]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include amortization of intangibles, stock-based compensation, certain restructuring charges, customer related asset impairment, legal and other, interest expense, interest income, other charges (income), net, and equity in earnings of unconsolidated affiliates. A portion of depreciation is allocated to the respective segments, together with other general corporate, research and development and administrative expenses.

[0000866374-25-000027:mdna:93]
The following table sets forth segment income and margins. Segment margins in the table below may not recalculate exactly due to rounding.

[0000866374-25-000027:mdna:94]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  |  |  |  |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 854 |  |  | 6.1 | % |  | $ | 669 |  |  | 4.8 | % |  |  |  |  |  |  |  |  |
| Flex Reliability Solutions | 684 |  |  | 5.8 | % |  | 666 |  |  | 5.3 | % |  |  |  |  |  |  |  |  |

[0000866374-25-000027:mdna:95]
FAS segment margin increased 130 basis points, to 6.1% for fiscal year 2025, from 4.8% for fiscal year 2024. The margin increase during the period was driven by strong execution, product mix and cost actions taken.

[0000866374-25-000027:mdna:96]
FRS segment margin increased 50 basis points, to 5.8% for fiscal year 2025, from 5.3% for fiscal year 2024. The margin increase in the FRS segment was primarily driven by increased productivity, favorable mix and cost actions taken.

[0000866374-25-000027:mdna:97]
Restructuring charges

[0000866374-25-000027:mdna:98]
During fiscal year 2025, we committed to targeted restructuring activities to improve operational efficiency by reducing excess workforce capacity. As a result, we recognized approximately $86 million of restructuring charges, primarily related to employee severance. During fiscal year 2024, we recognized approximately $175 million of restructuring charges, also primarily related to employee severance.

[0000866374-25-000027:mdna:99]
Refer to note 16 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our restructuring activities.

[0000866374-25-000027:mdna:100]
Selling, general and administrative expenses

[0000866374-25-000027:mdna:101]
Selling, general and administrative expenses ("SG&A") totaled $904 million, during fiscal year 2025, compared to $922 million during fiscal year 2024, decreasing by $18 million and representing no significant change as SG&A remained consistent at 3.5% of net sales.

[0000866374-25-000027:mdna:102]
Intangible amortization

[0000866374-25-000027:mdna:103]
Amortization of intangible assets were $70 million in each of fiscal years 2025 and 2024, representing no significant change from fiscal year 2024, due to amortization related to existing intangibles decreasing year over year being offset by amortization related to intangibles acquired from various business acquisitions occurring in the second half of fiscal year 2025.

[0000866374-25-000027:mdna:104]
Interest expense

[0000866374-25-000027:mdna:105]
Interest expense was $218 million during fiscal year 2025, compared to $207 million during fiscal year 2024, increasing $11 million primarily due to the issuance of $0.5 billion in senior notes during fiscal year 2025.

[0000866374-25-000027:mdna:106]
Interest income

[0000866374-25-000027:mdna:107]
Interest income was $61 million during fiscal year 2025, compared to $56 million during fiscal year 2024, increasing $5 million primarily due to increased cash deposits.

[0000866374-25-000027:mdna:108]
Other charges (income), net

[0000866374-25-000027:mdna:109]
During fiscal year 2025, we recorded $14 million of other income, net, compared to $44 million of other charges, net, in fiscal year 2024. The increase in other income, net was primarily driven by a gain on bargain purchase of $19 million as a result of an acquisition occurring during the fourth quarter of fiscal year 2025. Additionally, losses on foreign exchange items in fiscal year 2025 decreased from $24 million to $10 million compared to fiscal year 2024.

[0000866374-25-000027:mdna:110]
Refer to notes 17 and 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our other charges (income), net and business acquisitions & divestitures.

[0000866374-25-000027:mdna:111]
Equity in earnings (losses) of unconsolidated affiliates

[0000866374-25-000027:mdna:112]
During fiscal year 2025, we recorded $3 million of equity in losses of unconsolidated affiliates, compared to $8 million of equity in earnings of unconsolidated affiliates during fiscal year 2024. The decrease during fiscal year 2025 was primarily due to lower investment fund gains versus fiscal year 2024, resulting from overarching market conditions that impacted investment fund values during the fiscal year.

[0000866374-25-000027:mdna:113]
Income taxes

[0000866374-25-000027:mdna:114]
We work to ensure that we accrue and pay the appropriate amount of income taxes according to the laws and regulations of each jurisdiction in which we operate. Certain of our subsidiaries have, at various times, been granted tax relief in their respective countries, resulting in lower income taxes than would otherwise be the case under ordinary tax rates. The consolidated effective tax rates were 18.1% and (30.9)% for the fiscal years 2025 and 2024, respectively. The effective rate varies from the Singapore statutory rate of 17.0% in each year as a result of the following items:

[0000866374-25-000027:mdna:115]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  |  |  |  |
| Income taxes based on domestic statutory rates | 17.0 | % |  | 17.0 | % |  |  |  |  |
| Effect of jurisdictional tax rate differential | 1.3 | % |  | 10.3 | % |  |  |  |  |
| Change in unrecognized tax benefit | (1.9) | % |  | (1.4) | % |  |  |  |  |
| Change in valuation allowance | (3.6) | % |  | (102.9) | % |  |  |  |  |
| Foreign exchange movement on prior year taxes recoverable | 0.4 | % |  | (0.2) | % |  |  |  |  |
| Liability for undistributed earnings | 0.6 | % |  | 20.3 | % |  |  |  |  |
| Global intangible low-taxes income (GILTI) / Subpart F income | 0.9 | % |  | 1.9 | % |  |  |  |  |
| Nextracker related transactions gains | — | % |  | 17.2 | % |  |  |  |  |
| Earnings from partnership | — | % |  | 7.0 | % |  |  |  |  |
| U.S. state taxes | 1.0 | % |  | 1.5 | % |  |  |  |  |
| Excess compensation (Section 162(m)) | 1.6 | % |  | 2.3 | % |  |  |  |  |
| Other | 0.8 | % |  | (3.9) | % |  |  |  |  |
| (Benefit from) provision for income taxes | 18.1 | % |  | (30.9) | % |  |  |  |  |

[0000866374-25-000027:mdna:116]
A number of countries in which the Company is located allow for tax holidays or provide other tax incentives to attract and retain business. In general, these holidays were secured based on the nature, size and location of the Company’s operations. The effect of tax holidays and tax incentives we received primarily for our subsidiaries in China, Malaysia, Netherlands, Costa Rica, and Israel was $17 million and $20 million in fiscal years 2025 and 2024, respectively. Refer to note 15 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion. We generate most of our revenues and profits from operations outside of Singapore.

[0000866374-25-000027:mdna:117]
We are regularly subject to tax return audits and examinations by various taxing jurisdictions around the world, and there can be no assurance that the final determination of any tax examinations will not be materially different than that which is reflected in our income tax provisions and accruals. Should additional taxes be assessed as a result of a current or future examination, there could be a material adverse effect on our effective tax rate, tax position, operating results, financial position and cash flows.

[0000866374-25-000027:mdna:118]
The OECD Pillar Two Global Anti-Base Erosion ("GloBE") model rules, issued under the OECD Inclusive Framework on Base Erosion and Profit Shifting, introduce a global minimum tax of 15% applicable to multinational enterprise groups with consolidated financial statement revenue in excess of €750 million. Numerous foreign jurisdictions have already enacted tax legislation based on the GloBE rules, with some effective as early as January 1, 2024. As of March 31, 2025, we recognized a nominal income tax expense for Pillar Two GloBE minimum tax. However, Singapore (our parent company jurisdiction) has enacted OECD Pillar 2 legislation which will be applicable to our fiscal year 2026, which we believe will adversely impact our effective tax rate.  The amount of the future impact will be dependent upon a number of factors, including the changing jurisdictional mix of earnings, future legislative enactments in other jurisdictions, and new OECD guidance.  The Company will continue to monitor the evolving tax legislation and OECD guidance, along with its impact to the effective tax rate and cash flows.

[0000866374-25-000027:mdna:119]
45

[0000866374-25-000027:mdna:120]
On August 16, 2022, the Inflation Reduction Act of 2022 ("IRA") was enacted into law, which includes a new corporate minimum tax, a stock repurchase excise tax, numerous green energy credits, other tax provisions, and significantly increased enforcement resources. While detailed regulations on some aspects of the act are still outstanding, we do not anticipate a material impact to our consolidated financial statements from these provisions.

[0000866374-25-000027:mdna:121]
Net income from continuing operations

[0000866374-25-000027:mdna:122]
Net income from continuing operations was $838 million during fiscal year 2025, compared to $872 million during fiscal year 2024, primarily driven by the same factors attributable to income from continuing operations before income taxes and the release of U.S. deferred tax asset valuation allowances in fiscal year 2024 as outlined above.

[0000866374-25-000027:mdna:123]
Net income from discontinued operations

[0000866374-25-000027:mdna:124]
Net income from discontinued operations was zero in fiscal year 2025, compared to $373 million in fiscal year 2024. Net income from discontinued operations was solely related to our Nextracker business that was spun off during fiscal year 2024.

[0000866374-25-000027:mdna:125]
Net income attributable to noncontrolling interest

[0000866374-25-000027:mdna:126]
Net income attributable to noncontrolling interest was zero in fiscal year 2025, compared to $239 million during fiscal year 2024, primarily driven by the same factors noted in the discussion above for net income from discontinued operations.

[0000866374-25-000027:mdna:127]
LIQUIDITY AND CAPITAL RESOURCES

[0000866374-25-000027:mdna:128]
We continuously evaluate our ability to meet our obligations over the next 12 months and have proactively adjusted our capital structure to improve maturities and liquidity. We expect that our current financial condition, including our liquidity sources, are adequate to fund current and future commitments. As of March 31, 2025, we had cash and cash equivalents of approximately $2.3 billion and bank and other borrowings of approximately $3.7 billion. We have a $2.5 billion revolving credit facility that is due to mature in July 2027 (the "2027 Credit Facility"), under which we had no borrowings outstanding as of March 31, 2025. In March 2025 we entered into a $500 million delayed draw term loan credit agreement, under which we had no borrowings outstanding as of March 31, 2025. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. Refer to note 9 to the condensed consolidated financial statement for details on the 2027 Credit Facility and the delayed draw term loan. As of March 31, 2025, we were in compliance with the covenants under all of our credit facilities and indentures and expect to remain in compliance with the covenants in the upcoming 12 months.

[0000866374-25-000027:mdna:129]
In fiscal year 2024, we implemented a 10b5-1 bond buyback program, aiming to repurchase certain outstanding bonds issued by us. During the twelve-month period ended March 31, 2025, we repurchased approximately $53 million of our 4.750% Notes due June 2025, resulting in an immaterial gain in our consolidated statement of operations.

[0000866374-25-000027:mdna:130]
Our cash balances are held in numerous locations throughout the world. As of March 31, 2025, approximately 81% of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated, under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $0.8 billion as of March 31, 2025). Repatriation could result in an additional income tax payment; however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-25-000027:mdna:131]
Fiscal Year 2025

[0000866374-25-000027:mdna:132]
Cash provided by operating activities was $1.5 billion during fiscal year 2025. The total cash provided by operating activities resulted primarily from $0.8 billion of net income for the period plus $0.8 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, deferred income taxes and stock-based compensation. Non-cash charges were in line with the prior year with the exception of deferred income taxes that were significantly impacted in fiscal year 2024 by factors outlined in the income tax section above. These cash inflows of $1.6 billion were partially offset by a net change in our operating assets and liabilities of $0.1 billion as the reduction in inventory and increase in payables compared to fiscal year 2024 were offset by increases in accounts receivable, contract assets and a decrease in working capital advances.

[0000866374-25-000027:mdna:133]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased by $1.5 billion to $3.0 billion as of March 31, 2025 from $4.5

[0000866374-25-000027:mdna:134]
46

[0000866374-25-000027:mdna:135]
billion as of March 31, 2024. This decrease was primarily driven by a $1.2 billion increase in the current portion of long-term debt as two notes will mature within twelve months of March 31, 2025. Additional factors include a $1.1 billion decrease in inventory and a $0.7 billion increase in accounts payable being partially offset by a $0.6 billion increase in accounts receivable, net, a $0.4 billion increase in contract assets and working capital advances decreasing by $0.6 billion as inventory levels reduced.

[0000866374-25-000027:mdna:136]
Cash used in investing activities totaled $0.8 billion during fiscal year 2025. This was primarily driven by $0.4 billion of cash paid for the acquisitions of the Orangeburg manufacturing facility, Crown and JetCool, net of cash acquired, and $0.4 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our businesses. Refer to Note 19 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for further discussion of our business acquisitions & divestitures.

[0000866374-25-000027:mdna:137]
Cash used in financing activities was $0.8 billion during fiscal year 2025. This was primarily driven by $1.3 billion of cash paid for the repurchase of our ordinary shares, partially offset by $0.5 billion of proceeds from borrowings. Refer to note 9 and note 20 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-25-000027:mdna:138]
Fiscal Year 2024

[0000866374-25-000027:mdna:139]
Cash provided by operating activities was $1.3 billion during fiscal year 2024. The total cash provided by operating activities resulted primarily from $1.2 billion of net income for the period plus $0.3 billion of non-cash charges such as depreciation, amortization, non-cash lease expense, restructuring and impairment charges, deferred income taxes and stock-based compensation. Depreciation expense was $0.4 billion and relatively consistent with prior years. These additions were offset by a net change in our operating assets and liabilities of $0.3 billion.

[0000866374-25-000027:mdna:140]
We believe net working capital is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital decreased by $0.7 billion to $4.5 billion as of March 31, 2024 from $5.2 billion as of March 31, 2023. This decrease was primarily driven by a $1.2 billion decrease in inventories, a $0.5 billion decrease in accounts receivable, net and derecognition of $0.4 billion of Nextracker's working capital following the spin-off, partially offset by a $1.3 billion decrease in accounts payables.

[0000866374-25-000027:mdna:141]
Cash used in investing activities totaled $0.5 billion during fiscal year 2024. This was primarily driven by $0.5 billion of capital expenditures for property and equipment to continue expanding capabilities and capacity in support of our CEC, Automotive, and Industrial businesses.

[0000866374-25-000027:mdna:142]
Cash used in financing activities was $1.7 billion during fiscal year 2024. This was primarily driven by $1.3 billion of cash paid for the repurchase of our ordinary shares and $0.4 billion net cash for repayments of bank borrowings and long-term debt, as cash received from the sale of Nextracker shares was offset by the capital reduction from the Nextracker spin-off and other financing items. Refer to note 9 and note 20 to the consolidated financial statement in Item 8, "Financial Statements and Supplementary Data" for additional details.

[0000866374-25-000027:mdna:143]
Adjusted Free Cash Flow

[0000866374-25-000027:mdna:144]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment to present adjusted free cash flows on a consistent basis for investors. Our adjusted free cash flow was $1.1 billion and $0.8 billion for fiscal years 2025 and 2024, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-25-000027:mdna:145]
|  | Fiscal Year Ended March 31, |
|  | 2025 |  | 2024 |  |  |  |  |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,505 |  |  | $ | 1,326 |  |  |  |  |  |
| Purchases of property and equipment | (438) |  |  | (530) |  |  |  |  |  |
| Proceeds from the disposition of property and equipment | 15 |  |  | 25 |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,082 |  |  | $ | 821 |  |  |  |  |  |

[0000866374-25-000027:mdna:146]
47

[0000866374-25-000027:mdna:147]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months and beyond.

[0000866374-25-000027:mdna:148]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, and the levels of shipments and changes in the volume of customer orders.

[0000866374-25-000027:mdna:149]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of March 31, 2025.

[0000866374-25-000027:mdna:150]
Historically, we have funded operations from cash and cash equivalents generated from operations, proceeds from public offerings of debt securities, bank debt and lease financings. We may enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and anticipated growth as needed. During fiscal year 2025 and 2024, we received approximately $4.0 billion and $3.6 billion, respectively, from other sales of receivables under our factoring programs. As of March 31, 2025 and 2024, the outstanding balance on receivables sold for cash was $0.7 billion and $0.8 billion, respectively, under our accounts receivable factoring programs, which were removed from accounts receivable balances in our consolidated balance sheets.

[0000866374-25-000027:mdna:151]
Historically we have been successful in refinancing and extending the maturity dates on our term loans and credit facilities. In July 2022, the Company entered into a new $2.5 billion credit agreement which matures in July 2027 and consists of a $2.5 billion revolving credit facility with a sub-limit of $360 million available for swing line loans, and a sub-limit of $175 million available for the issuance of letters of credit. In August 2024, the Company issued $500 million of 5.250% Notes due 2032. The Company received proceeds of approximately $496 million, net of discount and certain issuance costs. Refer to note 9 to the condensed consolidated financial statement for details.

[0000866374-25-000027:mdna:152]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-25-000027:mdna:153]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $1.7 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 8, 2024. During fiscal year 2025, we paid $1.3 billion to repurchase shares under the current and prior repurchase plans at an average price of $32.66 per share. As of March 31, 2025, shares in the aggregate amount of $1.0 billion were available to be repurchased under the current plan.

[0000866374-25-000027:mdna:154]
CONTRACTUAL OBLIGATIONS AND COMMITMENTS

[0000866374-25-000027:mdna:155]
In March 2025, we entered into a $500 million delayed draw term loan credit agreement, under which we had no borrowings outstanding as of March 31, 2025. Borrowings under the delayed draw term loan may be used for working capital, capital expenditures, refinancing of current debt, and other general corporate purposes. All borrowings under the delayed draw term loan will become due on December 31, 2027. Interest is based on either (a) a Term SOFR-based formula plus a margin of 87.5 basis points to 150 basis points, depending on the Company’s credit ratings, or (b) a Base Rate formula plus a margin of 0.0 basis point to 50.0 basis points, depending on the Company's credit ratings. Refer to note 9 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for details of our debt obligations.

[0000866374-25-000027:mdna:156]
In addition. we have leased certain of our property and equipment under finance lease commitments, and certain of our facilities and equipment under operating lease commitments. The following table summarizes current and non-current material cash requirements as of March 31, 2025 including future payments due under our debt including finance leases and related interest obligations and operating leases (amounts may not sum due to rounding):

[0000866374-25-000027:mdna:157]
|  | Total |  | 1 Year or Less |  | 2 - 3 Years |  | 4 - 5 Years |  | Greater Than5 Years |
|  | (In millions) |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings, long-term debt and finance lease obligations: |  |  |  |  |  |  |  |  |  |
| Bank borrowings and long-term debt | $ | 3,706 |  |  | $ | 1,209 |  |  | $ | 398 |  |  | $ | 709 |  |  | $ | 1,390 |  |
| Interest on long-term debt obligations | 642 |  |  | 146 |  |  | 242 |  |  | 174 |  |  | 80 |  |
| Operating leases, net of subleases | 670 |  |  | 158 |  |  | 232 |  |  | 146 |  |  | 134 |  |
| Restructuring costs | 51 |  |  | 51 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 5,069 |  |  | $ | 1,564 |  |  | $ | 872 |  |  | $ | 1,029 |  |  | $ | 1,604 |  |

[0000866374-25-000027:mdna:158]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory, which are not included in the table above. The majority of the purchase obligations are generally short-term in nature. We generally do not enter into non-cancelable purchase orders for materials until we receive a corresponding production forecast from our customers. Our purchase obligations can fluctuate significantly from period to period and can materially impact our future operating asset and liability balances, and our future working capital requirements. We intend to use our existing cash balances, together with anticipated cash flows from operations to fund our existing and future contractual obligations.

[0000866374-25-000027:mdna:159]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000866374-25-000027:mdna:160]
Refer to note 2 to the consolidated financial statements in Item 8, "Financial Statements and Supplementary Data" for recent accounting pronouncements.

[0000866374-25-000027:mdna:161]
49
