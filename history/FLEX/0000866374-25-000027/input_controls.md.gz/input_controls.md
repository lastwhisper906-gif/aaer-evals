# FLEX 10-K controls and the auditor's report


## auditors_report

[0000866374-25-000027:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-25-000027:auditors_report:2]
To the shareholders and the Board of Directors of Flex Ltd., Singapore

[0000866374-25-000027:auditors_report:3]
Opinion on the Financial Statements

[0000866374-25-000027:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2025 and 2024, the related consolidated statements of operations, comprehensive income, redeemable noncontrolling interest and shareholders' equity, and cash flows for each of the three years in the period ended March 31, 2025, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of March 31, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended March 31, 2025, in conformity with accounting principles generally accepted in the United States of America.

[0000866374-25-000027:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated May 21, 2025 expressed an unqualified opinion on the Company's internal control over financial reporting.

[0000866374-25-000027:auditors_report:6]
Basis for Opinion

[0000866374-25-000027:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-25-000027:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000866374-25-000027:auditors_report:9]
Critical Audit Matter

[0000866374-25-000027:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000866374-25-000027:auditors_report:11]
Revenue - Variable Consideration and Associated Customer-Related Accruals for Pricing Adjustments - Refer to Notes 2 and 4 to the Financial Statements

[0000866374-25-000027:auditors_report:12]
Critical Audit Matter Description

[0000866374-25-000027:auditors_report:13]
Certain of the Company’s customer agreements include potential price adjustments which may result in variable consideration. These price adjustments include committed price reductions, material margins earned over the period that are contractually required to be paid to the customers, and other periodic pricing resets that may be refundable to customers. The Company recognizes estimates of this variable consideration that are not expected to result in a significant revenue reversal in the future, primarily based on the amount of potential refunds required by the contract, historical experience and other surrounding facts and circumstances.

[0000866374-25-000027:auditors_report:14]
We identified the recognition of variable consideration and the associated customer-related accruals for pricing adjustments as a critical audit matter due to the judgments necessary to determine when estimates of this variable consideration are no longer expected to result in a significant revenue reversal in the future. This required extensive audit effort and a higher degree of auditor judgment when performing audit procedures to evaluate the reasonableness of the variable consideration and associated customer-related accruals for pricing adjustments.

[0000866374-25-000027:auditors_report:15]
51

[0000866374-25-000027:auditors_report:16]
How the Critical Audit Matter Was Addressed in the Audit

[0000866374-25-000027:auditors_report:17]
Our audit procedures related to variable consideration and associated customer related accruals for pricing adjustments included the following, among others:

[0000866374-25-000027:auditors_report:18]
•We tested the effectiveness of controls the Company has in place relating to reviewing customer contracts to identify price adjustment clauses, estimating variable consideration and assessing the reasonableness of customer related accrual balances.

[0000866374-25-000027:auditors_report:19]
•We evaluated the Company’s accounting policy with respect to variable consideration, as well as its process for identifying contracts that include potential price adjustment clauses.

[0000866374-25-000027:auditors_report:20]
•We selected a sample of contracts with customers that included potential price adjustment clauses and performed the following:

[0000866374-25-000027:auditors_report:21]
–We read the customer contracts to develop an understanding of clauses that could give rise to variable consideration and evaluated whether the Company’s accounting conclusions with respect to those clauses were reasonable.

[0000866374-25-000027:auditors_report:22]
–We obtained and tested the mathematical accuracy of the Company’s calculations of customer related accruals and evaluated the Company’s judgments regarding the amount of variable consideration that should be deferred. In making this evaluation we considered both the terms included in the customer contract and the Company’s historical experience in settling amounts with the customer.

[0000866374-25-000027:auditors_report:23]
/s/ DELOITTE & TOUCHE LLP

[0000866374-25-000027:auditors_report:24]
San Jose, California

[0000866374-25-000027:auditors_report:25]
May 21, 2025

[0000866374-25-000027:auditors_report:26]
We have served as the Company’s auditor since 2002.

[0000866374-25-000027:auditors_report:27]
52

[0000866374-25-000027:auditors_report:28]
FLEX LTD.


## item_9a

[0000866374-25-000027:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000866374-25-000027:item_9a:2]
(a)Evaluation of Disclosure Controls and Procedures

[0000866374-25-000027:item_9a:3]
The Company's management, with the participation of the Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company's disclosure controls and procedures (as defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of March 31, 2025. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer concluded that, as of March 31, 2025, the Company's disclosure controls and procedures were effective in ensuring that information required to be disclosed by the Company in reports that it files or submits under the Exchange Act, is (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms and (ii) accumulated and communicated to our management, including our Chief  Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000866374-25-000027:item_9a:4]
(b)Management's Annual Report on Internal Control over Financial Reporting

[0000866374-25-000027:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Rule 13a-15(f) under the Exchange Act. Internal control over financial reporting consists of policies and procedures that: (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (2) are designed and operated to provide reasonable assurance regarding the reliability of the Company's financial reporting and the Company's process for the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the Company’s assets that could have a material effect on the financial statements. Because of its inherent limitations, a system of internal control over financial reporting can provide only reasonable assurance and may not prevent or detect misstatements or prevent or detect instances of fraud. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls may be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-25-000027:item_9a:6]
Management excluded Crown Technical Systems, JetCool Technologies Inc., and the U.S. manufacturing operations of the Forest & Garden division of Husqvarna, which were acquired during fiscal year 2025, from its annual assessment of the effectiveness of internal control over financial reporting as of March 31, 2025.  These fiscal year 2025 acquisitions constitute, in aggregate, less than 2% of total assets and less than 1% of net sales of the related consolidated financial statement amounts as of, and for the fiscal year ended March 31, 2025.

[0000866374-25-000027:item_9a:7]
As of March 31, 2025, under the supervision and with the participation of management, including the Company's Chief Executive Officer and Chief Financial Officer, an evaluation was conducted of the effectiveness of the Company's internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on that evaluation, management concluded that the Company's internal control over financial reporting was effective as of March 31, 2025.

[0000866374-25-000027:item_9a:8]
(c)Attestation Report of the Registered Public Accounting Firm

[0000866374-25-000027:item_9a:9]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2025 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report which appears in this Item under the heading "Report of Independent Registered Public Accounting Firm."

[0000866374-25-000027:item_9a:10]
(d)Changes in Internal Control Over Financial Reporting

[0000866374-25-000027:item_9a:11]
There were no changes in our internal control over financial reporting that occurred during the fourth quarter ended March 31, 2025 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000866374-25-000027:item_9a:12]
100

[0000866374-25-000027:item_9a:13]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000866374-25-000027:item_9a:14]
To the shareholders and the Board of Directors of Flex Ltd., Singapore

[0000866374-25-000027:item_9a:15]
Opinion on Internal Control over Financial Reporting

[0000866374-25-000027:item_9a:16]
We have audited the internal control over financial reporting of Flex Ltd. and subsidiaries (the "Company") as of March 31, 2025, based on criteria established in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control—Integrated Framework (2013) issued by COSO.

[0000866374-25-000027:item_9a:17]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended March 31, 2025, of the Company, and our report dated May 21, 2025 expressed an unqualified opinion on those financial statements.

[0000866374-25-000027:item_9a:18]
As described in Management’s Annual Report on Internal Control over Financial Reporting, management excluded from its assessment the internal control over financial reporting of Crown Technical Systems, JetCool Technologies Inc., and the U.S. manufacturing operations of the Forest & Garden division of Husqvarna, which were acquired during fiscal year 2025, and whose financial statements, in the aggregate, constitute less than 2% of total assets and less than 1% of net sales of the related consolidated financial statement amounts as of and for the year ended March 31, 2025. Accordingly, our audit did not include the internal control over financial reporting at Crown Technical Systems, JetCool Technologies Inc., nor the U.S. manufacturing operations of the Forest & Garden division of Husqvarna.

[0000866374-25-000027:item_9a:19]
Basis for Opinion

[0000866374-25-000027:item_9a:20]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000866374-25-000027:item_9a:21]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000866374-25-000027:item_9a:22]
Definition and Limitations of Internal Control over Financial Reporting

[0000866374-25-000027:item_9a:23]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000866374-25-000027:item_9a:24]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000866374-25-000027:item_9a:25]
/s/ DELOITTE & TOUCHE LLP

[0000866374-25-000027:item_9a:26]
San Jose, California

[0000866374-25-000027:item_9a:27]
May 21, 2025

[0000866374-25-000027:item_9a:28]
101
