# FLEX MD&A — 0000866374-24-000012


## mdna

[0000866374-24-000012:mdna:1]
[same as prior period, unchanged from 0000866374-23-000066:mdna:1]

[0000866374-24-000012:mdna:2]
[same as prior period, unchanged from 0000866374-23-000066:mdna:2]

[0000866374-24-000012:mdna:3]
[same as prior period, unchanged from 0000866374-23-000066:mdna:3]

[0000866374-24-000012:mdna:4]
We are the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, we support the entire product lifecycle with advanced manufacturing solutions and operate one of the most trusted global supply chains. We also provide additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. We support a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of December 31, 2023, our three operating and reportable segments were as follows:

[0000866374-24-000012:mdna:5]
[same as prior period, unchanged from 0000866374-23-000066:mdna:5]

[0000866374-24-000012:mdna:6]
[same as prior period, unchanged from 0000866374-23-000066:mdna:6]

[0000866374-24-000012:mdna:7]
[same as prior period, unchanged from 0000866374-23-000066:mdna:7]

[0000866374-24-000012:mdna:8]
[same as prior period, unchanged from 0000866374-23-000066:mdna:8]

[0000866374-24-000012:mdna:9]
[same as prior period, unchanged from 0000866374-23-000066:mdna:9]

[0000866374-24-000012:mdna:10]
[same as prior period, unchanged from 0000866374-23-000066:mdna:10]

[0000866374-24-000012:mdna:11]
[same as prior period, unchanged from 0000866374-23-000066:mdna:11]

[0000866374-24-000012:mdna:12]
[same as prior period, unchanged from 0000866374-23-000066:mdna:12]

[0000866374-24-000012:mdna:13]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-24-000012:mdna:14]
[same as prior period, unchanged from 0000866374-23-000066:mdna:14]

[0000866374-24-000012:mdna:15]
[same as prior period, unchanged from 0000866374-23-000066:mdna:15]

[0000866374-24-000012:mdna:16]
[same as prior period, unchanged from 0000866374-23-000066:mdna:16]

[0000866374-24-000012:mdna:17]
[same as prior period, unchanged from 0000866374-23-000066:mdna:17]

[0000866374-24-000012:mdna:18]
[same as prior period, unchanged from 0000866374-23-000066:mdna:20]

[0000866374-24-000012:mdna:19]
[same as prior period, unchanged from 0000866374-23-000066:mdna:18]

[0000866374-24-000012:mdna:20]
Component shortages and logistical constraints improved as the year progressed. We continue to monitor potential supply chain disruptions, including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea. Refer to “Risk Factors - “Supply chain disruptions, manufacturing interruptions or delays, or the failure to accurately forecast customer demand, have in the past affected, and may in the future, affect our ability to meet customer demand, lead to higher costs, or result in excess or obsolete inventory. We have been and continue to be adversely affected by supply chain issues, including shortages of required electronic components.” as disclosed in Part I, “Item 1A. Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0000866374-24-000012:mdna:21]
[same as prior period, unchanged from 0000866374-23-000066:mdna:21]

[0000866374-24-000012:mdna:22]
We continue to monitor and respond to the conflict in Ukraine and the associated sanctions and other restrictions. We also are monitoring and responding to the Israel-Hamas war. As of the date of this report, there is no material impact to our business operations and financial performance in Ukraine and Israel. The full impact of the conflicts on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflicts and their impact on regional and global economic conditions. We will continue to monitor the conflicts and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0000866374-24-000012:mdna:23]
[same as prior period, unchanged from 0000866374-23-000066:mdna:23]

[0000866374-24-000012:mdna:24]
On July 3, 2023, our subsidiary Nextracker Inc. ("Nextracker") completed a follow-on offering to its initial public offering, which was completed on February 13, 2023, and issued 15,631,562 shares of Class A common stock and received net proceeds of $551 million. The entire net proceeds were used by Nextracker to acquire 14,025,000 Nextracker LLC common units from Yuma, Inc., our indirect wholly-owned subsidiary, and 1,606,562 Nextracker LLC common units from TPG Rise Flash, L.P., an affiliate of the global alternative asset management firm TPG. As a result of the repurchase of Nextracker LLC common units by Nextracker, 15,631,562 shares of Nextracker Class B common stock were cancelled. Subsequent to the follow-on offering, we owned 74,432,619 shares of Class B common stock, representing 51.5% of the total outstanding shares of Nextracker common stock and, accordingly, continued to control Nextracker. We received approximately $495 million from the follow-on offering, after distribution of net proceeds to TPG and expenses.

[0000866374-24-000012:mdna:25]
On October 25, 2023, we announced our plan to effect a Spin-off of all of our remaining interests in Nextracker to our shareholders on a pro rata basis pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023 (the “Merger Agreement”).

[0000866374-24-000012:mdna:26]
On January 2, 2024, we completed the Spin-off of our remaining interests in Nextracker to Flex shareholders on a pro rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution. Under the previously disclosed terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for every Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

[0000866374-24-000012:mdna:27]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, we no longer directly or indirectly hold any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and we will no longer consolidate Nextracker into our future financial results. Flex ordinary shares continue to trade on Nasdaq under the ticker symbol “FLEX” and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol “NXT”.

[0000866374-24-000012:mdna:28]
The historical results of Nextracker will be reported in our consolidated financial statements as discontinued operations beginning in our fourth quarter ending March 31, 2024.

[0000866374-24-000012:mdna:29]
28

[0000866374-24-000012:mdna:30]
Also, prior to or in connection with the Spin-off, we entered into various agreements to effect the Spin-off and provide a framework for the relationship between us and Nextracker following the Spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.

[0000866374-24-000012:mdna:31]
[same as prior period, unchanged from 0000866374-23-000066:mdna:26]

[0000866374-24-000012:mdna:32]
We are one of the world's largest providers of global supply chain solutions, with revenues of $21.9 billion for the nine-month period ended December 31, 2023 and $30.3 billion in the fiscal year ended March 31, 2023. We have established an extensive network of manufacturing facilities in the world's major consumer and enterprise markets (Asia, the Americas, and Europe) to serve the growing outsourcing needs of both multinational and regional customers. We design, build, ship, and service consumer and enterprise products for our customers through a network of over 100 facilities in approximately 30 countries across four continents. Prior to the Spin-off, we also provided intelligent, integrated solar tracker and software solutions used in utility-scale and ground-mounted distributed generation solar projects around the world. The following tables set forth the relative percentages and dollar amounts of net sales by region and by country, and net property and equipment by country, based on the location of our manufacturing sites:

[0000866374-24-000012:mdna:33]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 3,771 |  |  | 53 | % |  | $ | 3,455 |  |  | 45 | % |  | $ | 10,937 |  |  | 50 | % |  | $ | 10,182 |  |  | 45 | % |
| Asia | 1,997 |  |  | 28 | % |  | 2,748 |  |  | 35 | % |  | 6,686 |  |  | 31 | % |  | 8,016 |  |  | 35 | % |
| Europe | 1,335 |  |  | 19 | % |  | 1,553 |  |  | 20 | % |  | 4,287 |  |  | 19 | % |  | 4,671 |  |  | 20 | % |
|  | $ | 7,103 |  |  |  |  | $ | 7,756 |  |  |  |  | $ | 21,910 |  |  |  |  | $ | 22,869 |  |  |  |
| Net sales by country: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mexico | $ | 1,711 |  |  | 24 | % |  | $ | 1,703 |  |  | 22 | % |  | $ | 5,241 |  |  | 24 | % |  | $ | 4,859 |  |  | 21 | % |
| U.S. | 1,632 |  |  | 23 | % |  | 1,188 |  |  | 15 | % |  | 4,416 |  |  | 20 | % |  | 3,651 |  |  | 16 | % |
| China | 1,172 |  |  | 17 | % |  | 1,759 |  |  | 23 | % |  | 3,956 |  |  | 18 | % |  | 5,113 |  |  | 22 | % |
| Malaysia | 500 |  |  | 7 | % |  | 650 |  |  | 8 | % |  | 1,601 |  |  | 7 | % |  | 1,853 |  |  | 8 | % |
| Brazil | 405 |  |  | 6 | % |  | 548 |  |  | 7 | % |  | 1,223 |  |  | 6 | % |  | 1,622 |  |  | 7 | % |
| Hungary | 317 |  |  | 4 | % |  | 327 |  |  | 4 | % |  | 1,031 |  |  | 5 | % |  | 944 |  |  | 4 | % |
| Other | 1,366 |  |  | 19 | % |  | 1,581 |  |  | 21 | % |  | 4,442 |  |  | 20 | % |  | 4,827 |  |  | 22 | % |
|  | $ | 7,103 |  |  |  |  | $ | 7,756 |  |  |  |  | $ | 21,910 |  |  |  |  | $ | 22,869 |  |  |  |

[0000866374-24-000012:mdna:34]
|  | As of |  | As of |
| Property and equipment, net: | December 31, 2023 |  | March 31, 2023 |
|  | (In millions) |
| Mexico | $ | 799 |  |  | 34 | % |  | $ | 763 |  |  | 32 | % |
| U.S. | 349 |  |  | 15 | % |  | 365 |  |  | 16 | % |
| China | 321 |  |  | 14 | % |  | 338 |  |  | 14 | % |
| Malaysia | 146 |  |  | 6 | % |  | 152 |  |  | 6 | % |
| Hungary | 131 |  |  | 6 | % |  | 140 |  |  | 6 | % |
| Brazil | 89 |  |  | 4 | % |  | 89 |  |  | 4 | % |
| Other | 493 |  |  | 21 | % |  | 502 |  |  | 22 | % |
|  | $ | 2,328 |  |  |  |  | $ | 2,349 |  |  |  |

[0000866374-24-000012:mdna:35]
[same as prior period, unchanged from 0000866374-23-000066:mdna:30]

[0000866374-24-000012:mdna:36]
[same as prior period, unchanged from 0000866374-23-000066:mdna:31]

[0000866374-24-000012:mdna:37]
[same as prior period, unchanged from 0000866374-23-000066:mdna:33]

[0000866374-24-000012:mdna:38]
[same as prior period, unchanged from 0000866374-23-000066:mdna:32]

[0000866374-24-000012:mdna:39]
[same as prior period, unchanged from 0000866374-23-000066:mdna:34]

[0000866374-24-000012:mdna:40]
[same as prior period, unchanged from 0000866374-23-000066:mdna:35]

[0000866374-24-000012:mdna:41]
[same as prior period, unchanged from 0000866374-23-000066:mdna:36]

[0000866374-24-000012:mdna:42]
[same as prior period, unchanged from 0000866374-23-000066:mdna:37]

[0000866374-24-000012:mdna:43]
•the impacts on our business due to component shortages, disruptions in transportation or other supply chain related constraints including disruptions in international commerce as a result of attacks on shipping vessels in the Red Sea;

[0000866374-24-000012:mdna:44]
[same as prior period, unchanged from 0000866374-23-000066:mdna:39]

[0000866374-24-000012:mdna:45]
[same as prior period, unchanged from 0000866374-23-000066:mdna:40]

[0000866374-24-000012:mdna:46]
[same as prior period, unchanged from 0000866374-23-000066:mdna:41]

[0000866374-24-000012:mdna:47]
[same as prior period, unchanged from 0000866374-23-000066:mdna:42]

[0000866374-24-000012:mdna:48]
[same as prior period, unchanged from 0000866374-23-000066:mdna:43]

[0000866374-24-000012:mdna:49]
[same as prior period, unchanged from 0000866374-23-000066:mdna:44]

[0000866374-24-000012:mdna:50]
[same as prior period, unchanged from 0000866374-23-000066:mdna:45]

[0000866374-24-000012:mdna:51]
[same as prior period, unchanged from 0000866374-23-000066:mdna:46]

[0000866374-24-000012:mdna:52]
We are also subject to other risks as outlined in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended March 31, 2023 and in Part II, Item 1A of this report on Form 10-Q.

[0000866374-24-000012:mdna:53]
[same as prior period, unchanged from 0000866374-23-000066:mdna:48]

[0000866374-24-000012:mdna:54]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Due to geopolitical conflicts (including the Russian invasion of  Ukraine and the Israel-Hamas war), there has been and we expect there will continue to be uncertainty and disruption in the global economy and financial markets. We have made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000012:mdna:55]
[same as prior period, unchanged from 0000866374-23-000066:mdna:50]

[0000866374-24-000012:mdna:56]
[same as prior period, unchanged from 0000866374-23-000066:mdna:51]

[0000866374-24-000012:mdna:57]
[same as prior period, unchanged from 0000866374-23-000066:mdna:52]

[0000866374-24-000012:mdna:58]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 90.1 |  |  | 92.4 |  |  | 91.0 |  |  | 92.5 |  |
| Restructuring charges | 0.9 |  |  | 0.1 |  |  | 0.4 |  |  | — |  |
| Gross profit | 9.0 |  |  | 7.5 |  |  | 8.6 |  |  | 7.5 |  |
| Selling, general and administrative expenses | 3.7 |  |  | 3.1 |  |  | 3.7 |  |  | 3.2 |  |
| Restructuring charges | 0.2 |  |  | — |  |  | 0.1 |  |  | — |  |
| Intangible amortization | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Operating income | 4.9 |  |  | 4.1 |  |  | 4.6 |  |  | 4.0 |  |
| Interest, net | 0.5 |  |  | 0.7 |  |  | 0.5 |  |  | 0.7 |  |
| Other charges, net | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Income before income taxes | 4.3 |  |  | 3.4 |  |  | 4.0 |  |  | 3.3 |  |
| Provision for income taxes | 1.0 |  |  | 0.3 |  |  | 0.1 |  |  | 0.4 |  |
| Net income | 3.3 |  |  | 3.1 |  |  | 3.9 |  |  | 2.9 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 0.5 |  |  | 0.1 |  |  | 1.1 |  |  | 0.1 |  |
| Net income attributable to Flex Ltd. | 2.8 | % |  | 3.0 | % |  | 2.8 | % |  | 2.8 | % |

[0000866374-24-000012:mdna:59]
[same as prior period, unchanged from 0000866374-23-000066:mdna:54]

[0000866374-24-000012:mdna:60]
[same as prior period, unchanged from 0000866374-23-000066:mdna:55]

[0000866374-24-000012:mdna:61]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,466 |  |  | 49 | % |  | $ | 4,029 |  |  | 52 | % |  | $ | 10,685 |  |  | 49 | % |  | $ | 12,024 |  |  | 53 | % |
| Flex Reliability Solutions | 2,956 |  |  | 42 | % |  | 3,225 |  |  | 42 | % |  | 9,561 |  |  | 44 | % |  | 9,493 |  |  | 42 | % |
| Nextracker | 710 |  |  | 10 | % |  | 516 |  |  | 7 | % |  | 1,763 |  |  | 8 | % |  | 1,384 |  |  | 6 | % |
| Intersegment eliminations | (29) |  |  | — | % |  | (14) |  |  | — | % |  | (99) |  |  | — | % |  | (32) |  |  | — | % |
|  | $ | 7,103 |  |  |  |  | $ | 7,756 |  |  |  |  | $ | 21,910 |  |  |  |  | $ | 22,869 |  |  |  |

[0000866374-24-000012:mdna:62]
Net sales during the three-month period ended December 31, 2023 totaled $7.1 billion, representing a decrease of approximately $0.7 billion, or 8% from $7.8 billion during the three-month period ended December 31, 2022. Net sales for our FAS segment decreased approximately $0.6 billion, or 14% from the three-month period ended December 31, 2022, primarily driven by significant decreases in our Lifestyle and Consumer Devices businesses, and a mid single-digit percentage decrease in our Communications, Enterprise and Cloud ("CEC") business due to softer demand in consumer end markets and difficult year-over-year comparisons in CEC. Net sales for our FRS segment decreased approximately 0.3 billion, or 8% from the three-month period ended December 31, 2022, primarily driven by a high-teen percentage decrease in our Industrial business due to difficult year-over year comparisons and lower customer demand, partially offset by a low single-digit increase in our Automotive business due to higher customer demand. Net sales for our Health Solutions business remained relatively flat. Net sales for our Nextracker segment increased approximately $0.2 billion, or 38% from the three-month period ended December 31, 2022, primarily driven by an increase in gigawatts delivered. Net sales decreased $0.8 billion to $2.0 billion in Asia, decreased $0.2 billion to $1.3 billion in Europe, and increased $0.3 billion to $3.8 billion in the Americas.

[0000866374-24-000012:mdna:63]
[same as prior period, unchanged from 0000866374-23-000066:mdna:58]

[0000866374-24-000012:mdna:64]
Net sales during the nine-month period ended December 31, 2023 totaled $21.9 billion, representing a decrease of approximately $1.0 billion, or 4% from $22.9 billion during the nine-month period ended December 31, 2022. Net sales for our FAS segment decreased approximately $1.3 billion, or 11% from the nine-month period ended December 31, 2022, primarily driven by a significant decrease in our Consumer Devices business, a high-teen percentage decrease in our Lifestyle business and a low single-digit percentage decrease in our CEC business due to the same factors as noted in the three-month period discussion above. Net sales for our FRS segment increased approximately $0.1 billion, or 1% from the nine-month period ended December 31, 2022, primarily driven by a high single-digit percentage increase in our Automotive business and a mid single-digit percentage increase in our Health Solutions business which benefited from ramps across various end markets, offset by a mid single-digit percentage decrease in our Industrial business due to lower customer demand. Net sales for our Nextracker segment increased approximately $0.4 billion, or 27% from the nine-month period ended December 31, 2022, primarily driven by the same factors as noted in the three-month period discussion above. Net sales decreased $1.3 billion to $6.7 billion in Asia, decreased $0.4 billion to $4.3 billion in Europe, and increased $0.8 billion to $10.9 billion in the Americas.

[0000866374-24-000012:mdna:65]
Our ten largest customers during the three and nine-month periods ended December 31, 2023 accounted for approximately 35% and 33% of net sales, respectively. Our ten largest customers during the three and nine-month periods ended December 31, 2022 accounted for approximately 35% of net sales. No customer accounted for more than 10% of net sales during the three or nine-month periods ended December 31, 2023 or December 31, 2022.

[0000866374-24-000012:mdna:66]
[same as prior period, unchanged from 0000866374-23-000066:mdna:62]

[0000866374-24-000012:mdna:67]
[same as prior period, unchanged from 0000866374-23-000066:mdna:63]

[0000866374-24-000012:mdna:68]
Cost of sales during the three-month period ended December 31, 2023 totaled $6.4 billion, representing a decrease of approximately $0.8 billion, or 11% from $7.2 billion during the three-month period ended December 31, 2022. The lower cost of sales for the three-month period ended December 31, 2023 was primarily driven by decreased consolidated sales of $0.7 billion or 8%. Cost of sales in FAS for the three-month period ended December 31, 2023 decreased approximately $0.5 billion, or 15% from the three-month period ended December 31, 2022, which is relatively in line with the overall 14% decrease in FAS revenue during the same period primarily as a result of lower revenue in our Lifestyle, Consumer Devices, and CEC businesses. Cost of sales in FRS for the three-month period ended December 31, 2023 decreased approximately $0.3 billion, or 10% from the three-month period ended December 31, 2022, which is in line with the overall decrease in FRS revenue during the same period, primarily as a result of lower revenue in our Industrial business. Cost of sales in our Nextracker segment for the three-month period ended December 31, 2023 increased approximately $66 million, or 15% from the three-month period ended December 31, 2022, primarily due to the 38% increase in Nextracker revenue during the same period, offset by improved profitability resulting from a decline in freight and logistics costs and improved operational execution.

[0000866374-24-000012:mdna:69]
Cost of sales during the nine-month period ended December 31, 2023 totaled $19.9 billion, representing a decrease of approximately $1.2 billion, or 6% from $21.2 billion during the nine-month period ended December 31, 2022. The lower cost of sales for the nine-month period ended December 31, 2023 was primarily driven by decreased consolidated sales of $1.0 billion or 4%. Cost of sales in FAS for the nine-month period ended December 31, 2023 decreased approximately $1.3 billion, or 11% from the nine-month period ended December 31, 2022, which is aligned with the overall 11% decrease in FAS revenue during the same period primarily due to the drivers noted in the discussion above for the three-month period. Cost of sales in FRS for the nine-month period ended December 31, 2023 increased approximately $22 million, or 0.3% from the nine-month period ended December 31, 2022, which is in line with the overall 1% increase in FRS revenue during the same period, primarily due to the drivers noted in the discussion above for net sales for the nine-month period. Cost of sales in our Nextracker segment for the nine-month period ended December 31, 2023 increased approximately $97 million, or 8% from the nine-month period ended December 31, 2022, primarily driven by the same factors noted above in the three-month period discussion.

[0000866374-24-000012:mdna:70]
[same as prior period, unchanged from 0000866374-23-000066:mdna:66]

[0000866374-24-000012:mdna:71]
Gross profit is affected by fluctuations in cost of sales elements as outlined above and further by a number of factors, including product lifecycles, unit volumes, product mix, pricing, competition, new product introductions, and the expansion or consolidation of manufacturing facilities, as well as specific restructuring activities initiated from time to time. The flexible design of our manufacturing processes allows us to manufacture a broad range of products in our facilities and better utilize our manufacturing capacity across our diverse geographic footprint and service customers from all segments. In the case of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-24-000012:mdna:72]
[same as prior period, unchanged from 0000866374-23-000066:mdna:68]

[0000866374-24-000012:mdna:73]
Gross profit during the three-month period ended December 31, 2023 increased $59 million to $0.6 billion, or 9.0% of net sales, from $0.6 billion, or 7.5% of net sales, during the three-month period ended December 31, 2022. Gross margin improved 150 basis points during the three-month period ended December 31, 2023 primarily due to favorable mix with growth in our higher-margin Nextracker segment, partially offset by an increase in restructuring costs.

[0000866374-24-000012:mdna:74]
Gross profit during the nine-month period ended December 31, 2023 increased $0.2 billion to $1.9 billion, or 8.6% of net sales, from $1.7 billion, or 7.5% of net sales, during the nine-month period ended December 31, 2022. Gross margin improved 110 basis points during the same period due to the same factors noted above in the three-month period discussion.

[0000866374-24-000012:mdna:75]
[same as prior period, unchanged from 0000866374-23-000066:mdna:72]

[0000866374-24-000012:mdna:76]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest, net and other charges, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-24-000012:mdna:77]
[same as prior period, unchanged from 0000866374-23-000066:mdna:74]

[0000866374-24-000012:mdna:78]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 174 |  |  | 5.0 | % |  | $ | 181 |  |  | 4.5 | % |  | $ | 488 |  |  | 4.6 | % |  | $ | 523 |  |  | 4.4 | % |
| Flex Reliability Solutions | 159 |  |  | 5.4 | % |  | 143 |  |  | 4.4 | % |  | 495 |  |  | 5.2 | % |  | 465 |  |  | 4.9 | % |
| Nextracker | 162 |  |  | 22.8 | % |  | 60 |  |  | 11.7 | % |  | 356 |  |  | 20.2 | % |  | 133 |  |  | 9.6 | % |

[0000866374-24-000012:mdna:79]
FAS segment margin increased approximately 50 basis points, to 5.0%, for the three-month period ended December 31, 2023, from 4.5% for the three-month period ended December 31, 2022. The margin increase was primarily due to strong execution against new project ramps and product mix. The FAS segment margin increased approximately 20 basis points, to  4.6% for the nine-month period ended December 31, 2023, from 4.4% for the nine-month period ended December 31, 2022. This was primarily due to strong execution and product mix.

[0000866374-24-000012:mdna:80]
FRS segment margin increased approximately 100 basis points, to 5.4% for the three-month period ended December 31, 2023, from 4.4% for the three-month period ended December 31, 2022. The margin increase was primarily driven by improving margins in our Automotive and Health Solutions businesses due to increased productivity partially offset by lower sales in our Industrial business. FRS segment margin increased approximately 30 basis points, to 5.2% for the nine-month period ended December 31, 2023 from 4.9% for the nine-month period ended December 31, 2022. This was driven by improving margins in our Health Solutions business due to increased productivity and the effect of reduction in inflation recoveries, partially offset by lower sales in our Industrial business.

[0000866374-24-000012:mdna:81]
Nextracker segment margin increased approximately 1,110 basis points, to 22.8% for the three-month period ended December 31, 2023, from 11.7% for the three-month period ended December 31, 2022. The margin increase was driven by disciplined pricing, freight savings, and favorable cost absorption with increased revenue. Nextracker segment margin increased approximately 1,060 basis points, to 20.2% for the nine-month period ended December 31, 2023, from 9.6% for the nine-month period ended December 31, 2022. The increase in Nextracker segment margin during the nine-month period is due to the same factors noted in the discussion above for the three-month period.

[0000866374-24-000012:mdna:82]
[same as prior period, unchanged from 0000866374-23-000066:mdna:79]

[0000866374-24-000012:mdna:83]
In October, 2023, we committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and nine-month periods ended December 31, 2023, we recognized approximately $74 million and $100 million of restructuring charges, respectively, primarily related to employee severance.

[0000866374-24-000012:mdna:84]
[same as prior period, unchanged from 0000866374-23-000066:mdna:81]

[0000866374-24-000012:mdna:85]
Selling, general and administrative expenses (“SG&A”) was approximately $0.3 billion, or 3.7% of net sales, during the three-month period ended December 31, 2023, increasing $21 million from approximately $0.2 billion or 3.1% of net sales, during the three-month period ended December 31, 2022. SG&A was $0.8 billion, or 3.7% of net sales, during the nine-month period ended December 31, 2023, increasing $77 million from $0.7 billion or 3.2% of net sales, during the nine-month period

[0000866374-24-000012:mdna:86]
ended December 31, 2022. The increase was primarily due to elevated SG&A costs to support higher revenue growth in our Nextracker business and higher labor costs.

[0000866374-24-000012:mdna:87]
[same as prior period, unchanged from 0000866374-23-000066:mdna:84]

[0000866374-24-000012:mdna:88]
Amortization of intangible assets decreased to $17 million during the three-month period ended December 31, 2023, from $19 million for the three-month period ended December 31, 2022, and decreased to $54 million during the nine-month period ended December 31, 2023, from $62 million for the nine-month period ended December 31, 2022, primarily due to certain intangibles now being fully amortized.

[0000866374-24-000012:mdna:89]
[same as prior period, unchanged from 0000866374-23-000066:mdna:86]

[0000866374-24-000012:mdna:90]
Interest, net was an expense of $36 million during the three-month period ended December 31, 2023 compared to an expense of $54 million during the three-month period ended December 31, 2022, primarily due to higher interest income, and lower bank borrowings compared to the prior year period.

[0000866374-24-000012:mdna:91]
Interest, net was an expense of $112 million during the nine-month period ended December 31, 2023 compared to an expense of $150 million during the nine-month period ended December 31, 2022, primarily due to the same drivers noted in the discussion above for the three-month period.

[0000866374-24-000012:mdna:92]
Other charges, net

[0000866374-24-000012:mdna:93]
Other charges, net remained flat at an expense of $5 million during both the three-month periods ended December 31, 2023 and December 31, 2022, primarily due to foreign exchange transaction loss.

[0000866374-24-000012:mdna:94]
Other charges, net was an expense of $32 million during the nine-month period ended December 31, 2023 compared to an expense of $2 million during the nine-month period ended December 31, 2022, primarily due to higher foreign exchange transaction losses compared to the prior year period.

[0000866374-24-000012:mdna:95]
[same as prior period, unchanged from 0000866374-23-000066:mdna:92]

[0000866374-24-000012:mdna:96]
[same as prior period, unchanged from 0000866374-23-000066:mdna:93]

[0000866374-24-000012:mdna:97]
The consolidated effective tax rate was 24% and 2% for the three and nine-month periods ended December 31, 2023, and 10% and 13% for the three and nine-month periods ended December 31, 2022, respectively. The effective rate varies from the Singapore statutory rate of 17% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia, the Netherlands and Israel. The effective tax rate for the three-month period ended December 31, 2023 was significantly higher than the effective tax rate for the three-month period ended December 31, 2022 primarily due to a $21 million reduction of previously recorded deferred tax assets of Nextracker with the charge being fully attributable to noncontrolling interests. The effective tax rate for the nine-month period ended December 31, 2023 was significantly lower than the effective tax rate for the nine-month period ended December 31, 2022 primarily due to the recording of a $140 million deferred tax asset, with an offsetting entry to income tax benefit fully attributable to noncontrolling interest in connection with Nextracker's follow-on public offering whereby Nextracker purchased additional Nextracker LLC units from a related Flex U.S. subsidiary.

[0000866374-24-000012:mdna:98]
[same as prior period, unchanged from 0000866374-23-000066:mdna:95]

[0000866374-24-000012:mdna:99]
[same as prior period, unchanged from 0000866374-23-000066:mdna:96]

[0000866374-24-000012:mdna:100]
In response to the challenging economic environment following the COVID-19 pandemic, we continuously evaluate our ability to meet our obligations over the next 12 months and have proactively reset our capital structure during these times to improve maturities and liquidity. As a result, we expect that our current financial condition, including our liquidity sources are adequate to fund current and future commitments. As of December 31, 2023, we had cash and cash equivalents of approximately $2.8 billion and bank and other borrowings of approximately $3.4 billion. As of December 31, 2023, we had a $2.5 billion revolving credit facility that is due to mature in July 2027, and a $0.5 billion Nextracker revolving credit facility

[0000866374-24-000012:mdna:101]
[same as prior period, unchanged from 0000866374-23-000066:mdna:98]

[0000866374-24-000012:mdna:102]
that is due to mature in February 2028, under which we had no borrowings outstanding. As of December 31, 2023, we were in compliance with the covenants under all of our credit facilities and indentures; we also expect to remain in compliance with the covenants in the upcoming 12 months for our credit facilities and indentures.

[0000866374-24-000012:mdna:103]
In fiscal year 2024, we implemented a 10b5-1 bond buyback program, aiming to repurchase certain outstanding bonds issued by us. During the nine-month period ended December 31, 2023, we repurchased approximately $8 million of the 4.750% Notes due 2025, resulting in an immaterial gain on our condensed consolidated statement of operations.

[0000866374-24-000012:mdna:104]
Cash provided by operating activities was $0.6 billion during the nine-month period ended December 31, 2023, primarily driven by $0.9 billion of net income for the period plus $0.5 billion of non-cash charges such as depreciation, amortization, and stock-based compensation offset by certain changes in net working capital as discussed below.

[0000866374-24-000012:mdna:105]
We believe net working capital ("NWC") is a key metric that measures our liquidity. Net working capital is calculated as current assets less current liabilities. Net working capital increased approximately $0.3 billion to $5.5 billion as of December 31, 2023, from $5.2 billion as of March 31, 2023. The increase was primarily the result of the effect of a decrease in accounts payable of $0.6 billion and working capital advances of $0.4 billion partially offset by a reduction in inventory of $0.7 billion.

[0000866374-24-000012:mdna:106]
Cash used in investing activities was $0.4 billion during the nine-month period ended December 31, 2023. This was primarily driven by $0.4 billion of net capital expenditures for property and equipment to continue expanding capabilities and capacity in support of primarily our expanding CEC, Automotive, and Industrial businesses.

[0000866374-24-000012:mdna:107]
We believe adjusted free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our adjusted free cash flow is defined as cash from operations, less net purchases of property and equipment allowing us to present adjusted cash flows on a consistent basis for investors. Our adjusted free cash flow for the nine-month periods ended December 31, 2023 and December 31, 2022 was an inflow of $0.2 billion and an inflow of $0.1 billion, respectively. Adjusted free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Adjusted free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Adjusted free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-24-000012:mdna:108]
|  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 647 |  |  | $ | 500 |  |
| Purchases of property and equipment | (449) |  |  | (455) |  |
| Proceeds from the disposition of property and equipment | 21 |  |  | 20 |  |
| Adjusted free cash flow | $ | 219 |  |  | $ | 65 |  |

[0000866374-24-000012:mdna:109]
Cash used by financing activities was $0.8 billion during the nine-month period ended December 31, 2023, which was primarily driven by $0.8 billion of cash paid for the repurchase of our ordinary shares and $0.4 billion in repayments of bank borrowings and long-term debt, offset by $0.5 billion of net proceeds from the issuance of Nextracker shares, after the distribution to TPG and expenses.

[0000866374-24-000012:mdna:110]
Our cash balances are generated and held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2023 and March 31, 2023, approximately 49% and 27%, respectively, of our cash and cash equivalents were held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $1.9 billion as of March 31, 2023). Repatriation could result in an additional income tax payment; however, for the majority of our foreign entities, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held.

[0000866374-24-000012:mdna:111]
[same as prior period, unchanged from 0000866374-23-000066:mdna:108]

[0000866374-24-000012:mdna:112]
Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-24-000012:mdna:113]
[same as prior period, unchanged from 0000866374-23-000066:mdna:109]

[0000866374-24-000012:mdna:114]
We maintain a commercial paper program which provides short-term financing under which there were no borrowings outstanding as of December 31, 2023.

[0000866374-24-000012:mdna:115]
[same as prior period, unchanged from 0000866374-23-000066:mdna:111]

[0000866374-24-000012:mdna:116]
The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-24-000012:mdna:117]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $2.0 billion in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Annual General Meeting which was held on August 2, 2023. During the nine-month period ended December 31, 2023, we paid $781 million to repurchase shares under the current and prior repurchase plans at an average price of $25.32 per share. As of December 31, 2023, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.

[0000866374-24-000012:mdna:118]
[same as prior period, unchanged from 0000866374-23-000066:mdna:114]

[0000866374-24-000012:mdna:119]
[same as prior period, unchanged from 0000866374-23-000066:mdna:115]

[0000866374-24-000012:mdna:120]
There were no material changes in our contractual obligations and commitments as of December 31, 2023.
