# FLEX notes — 0000866374-24-000012


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-24-000012:notes:1]
[same as prior period, unchanged from 0000866374-23-000066:notes:1]

[0000866374-24-000012:notes:2]
Flex Ltd. ("Flex" or the "Company") is the diversified manufacturing partner of choice that helps market-leading brands design, build and deliver innovative products that improve the world. Through the collective strength of a global workforce across approximately 30 countries with responsible, sustainable operations, Flex supports the entire product lifecycle with advanced manufacturing solutions and operates one of the most trusted global supply chains. The Company also provides additional value to customers through a broad array of services, including design and engineering, component services, rapid prototyping, fulfillment, and circular economy solutions. Flex supports a diverse set of industries including cloud, communications, enterprise, automotive, industrial, consumer devices, lifestyle, healthcare, and energy. As of December 31, 2023, Flex's three operating and reportable segments were as follows:

[0000866374-24-000012:notes:3]
[same as prior period, unchanged from 0000866374-23-000066:notes:3]

[0000866374-24-000012:notes:4]
[same as prior period, unchanged from 0000866374-23-000066:notes:4]

[0000866374-24-000012:notes:5]
[same as prior period, unchanged from 0000866374-23-000066:notes:5]

[0000866374-24-000012:notes:6]
[same as prior period, unchanged from 0000866374-23-000066:notes:6]

[0000866374-24-000012:notes:7]
[same as prior period, unchanged from 0000866374-23-000066:notes:7]

[0000866374-24-000012:notes:8]
[same as prior period, unchanged from 0000866374-23-000066:notes:8]

[0000866374-24-000012:notes:9]
[same as prior period, unchanged from 0000866374-23-000066:notes:9]

[0000866374-24-000012:notes:10]
[same as prior period, unchanged from 0000866374-23-000066:notes:10]

[0000866374-24-000012:notes:11]
•Nextracker, the leading provider of intelligent, integrated solar tracker and software solutions that are used in utility-scale and ground-mounted distributed generation solar projects around the world. Nextracker's products enable solar panels to follow the sun’s movement across the sky and optimize plant performance.

[0000866374-24-000012:notes:12]
[same as prior period, unchanged from 0000866374-23-000066:notes:12]

[0000866374-24-000012:notes:13]
Nextracker Spin-off

[0000866374-24-000012:notes:14]
On January 2, 2024, the Company completed its previously announced spin-off of its remaining interests in Nextracker (the "Spin-off") to Flex shareholders on a pro-rata basis based on the number ordinary shares of Flex held by each shareholder of Flex (the “Distribution”) as of December 29, 2023, which was the record date of the Distribution, pursuant to the Agreement and Plan of Merger, dated as of February 7, 2023. Refer to note 17, “Subsequent Events” to the condensed consolidated financial statement for further details.

[0000866374-24-000012:notes:15]
[same as prior period, unchanged from 0000866374-23-000066:notes:13]

[0000866374-24-000012:notes:16]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2023 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair statement have been included. Operating results for the three and nine-month periods ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024. Certain prior period amounts in the condensed consolidated financial statements, as well as in the Notes thereto, have been reclassified to conform to the current presentation.

[0000866374-24-000012:notes:17]
The third quarters for fiscal years 2024 and 2023 ended on December 31 of each year and are comprised of 93 and 92 days, respectively. The Company's first three quarters for fiscal years 2024 and 2023 both are comprised of 275 days.

[0000866374-24-000012:notes:18]
The accompanying unaudited condensed consolidated financial statements include the accounts of Flex and its subsidiaries, after elimination of intercompany accounts and transactions. The Company consolidates subsidiaries and investments in entities in which the Company has a controlling interest. A controlling financial interest may exist in variable interest entities (“VIEs”), through governance provisions and arrangements to provide services to VIEs. The Company is required to consolidate a VIE of which it is the primary beneficiary. To determine if the Company is the primary beneficiary, the Company evaluates whether it has the power to direct the activities of a VIE that most significantly impact the VIE’s economic performance and the obligation to absorb the losses of the VIE or the right to receive benefits from the VIE that could potentially be significant to the VIE. The Company evaluates its relationships with its VIEs on an ongoing basis to determine whether it continues to be the primary beneficiary. The condensed consolidated financial statements reflect the assets and liabilities of VIEs that are consolidated. For the consolidated subsidiaries in which the Company owns less than 100%, the Company recognizes a noncontrolling interest for the ownership of the noncontrolling owners. As of December 31, 2023, we presented noncontrolling interest as permanent equity in the condensed balance sheets, reflecting the equity held by other parties. The amount of consolidated net income attributable to Flex Ltd. and the noncontrolling interest and redeemable noncontrolling interest are presented in the condensed consolidated statements of operations.

[0000866374-24-000012:notes:19]
[same as prior period, unchanged from 0000866374-23-000066:notes:18]

[0000866374-24-000012:notes:20]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for, among other things: allowances for doubtful accounts; inventory write-downs; valuation allowances for deferred tax assets; uncertain tax positions; valuation and useful lives of long-lived assets including property, equipment, and intangible assets; valuation of goodwill; valuation of investments in privately-held companies; asset impairments; fair values of financial instruments, notes receivable and derivative instruments; restructuring charges; contingencies; warranty provisions; incremental borrowing rates in determining the present value of lease payments; accruals for potential price adjustments arising from customer contracts; fair values of assets obtained and liabilities assumed in business combinations; and the fair values of stock options and restricted share unit awards granted under the Company's stock-based compensation plans. Due to geopolitical conflicts (including the Russian invasion of Ukraine, the Israel-Hamas war, and other geopolitical conflicts), there has been and will continue to be uncertainty and disruption in the global economy and financial markets. The Company has made estimates and assumptions taking into consideration certain possible impacts due to the Russian invasion of Ukraine and the Israel-Hamas war. These estimates may change, as new events occur, and additional information is obtained. Actual results may differ from previously estimated amounts, and such differences may be material to the condensed consolidated financial statements. Estimates and assumptions are reviewed periodically, and the effects of revisions are reflected in the period they occur.

[0000866374-24-000012:notes:21]
Recently Issued Accounting Pronouncements

[0000866374-24-000012:notes:22]
In October 2023, the FASB issued ASU 2023-06 "Disclosure Improvements - Codification Amendments in Response to the SEC's Disclosure Update and Simplification Initiative", which amends the disclosure or presentation requirements related to various subtopics in the FASB Accounting Standard Codification (the "Codification"). This ASU will become effective on the date the SEC removes the applicable disclosure from Regulation S-X or Regulation S-K, with early adoption prohibited. If by June 30, 2027, the SEC has not removed the applicable requirement from Regulation S-X or Regulation S-K, the pending content of the related amendment will be removed from the Codification and will not be become effective for any entity. The Company expects the new guidance will have an immaterial impact on its condensed consolidated financial statements, and intends to adopt the guidance when it becomes effective.

[0000866374-24-000012:notes:23]
In November 2023, the FASB issued ASU 2023-07 "Segment Reporting - Improvements to Reportable Segment Disclosures", which updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2025, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance retrospectively when it becomes effective in the fourth quarter of fiscal year 2025.

[0000866374-24-000012:notes:24]
In December 2023, the FASB issued ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which expands disclosures in an entity’s income tax rate reconciliation table and regarding cash taxes paid both in the U.S. and foreign jurisdictions. The guidance is effective for the Company beginning in the fourth quarter of fiscal year 2026. The

[0000866374-24-000012:notes:25]
Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and intends to adopt the guidance prospectively when it becomes effective in the fourth quarter of fiscal year 2026.

[0000866374-24-000012:notes:26]
Recently Adopted Accounting Pronouncement

[0000866374-24-000012:notes:27]
In September 2022, the FASB issued ASU 2022-04 "Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations", which requires a buyer in a supplier finance program to disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. To achieve that objective, the buyer should disclose qualitative and quantitative information about its supplier finance programs. The amendments in this update do not affect the recognition, measurement, or financial statement presentation of obligations covered by supplier finance program. The guidance is effective for the Company beginning in the first quarter of fiscal year 2024, except for the amendment on rollforward information which is effective in fiscal year 2025, with early adoption permitted. The Company adopted the guidance retrospectively during the first quarter of fiscal year 2024, including a rollforward of changes in those obligations, with immaterial impacts on its condensed consolidated financial statements.

[0000866374-24-000012:notes:28]
[same as prior period, unchanged from 0000866374-23-000066:notes:22]

[0000866374-24-000012:notes:29]
Obligations under these programs are classified within accounts payable on the condensed consolidated balance sheets, with the associated payments reflected in the operating activities section of the condensed consolidated statement of cash flows. The rollforward of the Company's outstanding obligations confirmed as valid under its supplier finance programs for the nine-month period ended December 31, 2023 is as follows.

[0000866374-24-000012:notes:30]
|  | Nine-Month Period Ended |
|  | December 31, 2023 |
|  | (In millions) |
| Confirmed obligations outstanding at the beginning of the period | $ | 275 |  |
| Invoices confirmed during the period | 812 |  |
| Confirmed invoices paid during the period | (897) |  |
| Foreign currency exchange impact | 4 |  |
| Confirmed obligations outstanding at the end of the period | $ | 194 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-24-000012:notes:31]
[same as prior period, unchanged from 0000866374-23-000066:notes:26]

[0000866374-24-000012:notes:32]
[same as prior period, unchanged from 0000866374-23-000066:notes:27]

[0000866374-24-000012:notes:33]
|  | As of December 31, 2023 |  | As of March 31, 2023 |
|  | (In millions) |
| Raw materials | $ | 5,303 |  |  | $ | 6,140 |  |
| Work-in-progress | 697 |  |  | 709 |  |
| Finished goods | 815 |  |  | 681 |  |
|  | $ | 6,815 |  |  | $ | 7,530 |  |

[0000866374-24-000012:notes:34]
[same as prior period, unchanged from 0000866374-23-000066:notes:29]

[0000866374-24-000012:notes:35]
During the nine-month period ended December 31, 2023, there was no material activity in the Company's goodwill account for each of its reportable segments, other than foreign currency translation adjustments of approximately $6 million, which primarily impacted the FRS segment, and a write-off of approximately $1 million as a result of the divestiture of a non-strategic immaterial business within the FRS segment during the third quarter of fiscal year 2024.

[0000866374-24-000012:notes:36]
[same as prior period, unchanged from 0000866374-23-000066:notes:31]

[0000866374-24-000012:notes:37]
|  | As of December 31, 2023 |  | As of March 31, 2023 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 334 |  |  | $ | (194) |  |  | $ | 140 |  |  | $ | 373 |  |  | $ | (204) |  |  | $ | 169 |  |
| Licenses and other intangibles | 306 |  |  | (180) |  |  | 126 |  |  | 299 |  |  | (152) |  |  | 147 |  |
| Total | $ | 640 |  |  | $ | (374) |  |  | $ | 266 |  |  | $ | 672 |  |  | $ | (356) |  |  | $ | 316 |  |

[0000866374-24-000012:notes:38]
[same as prior period, unchanged from 0000866374-23-000066:notes:33]

[0000866374-24-000012:notes:39]
[same as prior period, unchanged from 0000866374-23-000066:notes:34]

[0000866374-24-000012:notes:40]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | 17 |  |
| 2025 |  | 64 |  |
| 2026 |  | 43 |  |
| 2027 |  | 36 |  |
| 2028 |  | 28 |  |
| Thereafter |  | 78 |  |
| Total amortization expense |  | $ | 266 |  |

[0000866374-24-000012:notes:41]
[same as prior period, unchanged from 0000866374-23-000066:notes:36]

[0000866374-24-000012:notes:42]
(1)Represents estimated amortization for the remaining fiscal three-month period ending March 31, 2024.

[0000866374-24-000012:notes:43]
[same as prior period, unchanged from 0000866374-23-000066:notes:38]

[0000866374-24-000012:notes:44]
Customer working capital advances were $1.9 billion and $2.3 billion, as of December 31, 2023 and March 31, 2023, respectively. The customer working capital advances are not interest-bearing, do not generally have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production or the customer working capital advance agreement is terminated.

[0000866374-24-000012:notes:45]
[same as prior period, unchanged from 0000866374-23-000066:notes:40]

[0000866374-24-000012:notes:46]
Other current liabilities include customer-related accruals of $248 million and $313 million as of December 31, 2023 and March 31, 2023, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000866374-24-000012:notes:47]
[same as prior period, unchanged from 0000866374-23-000066:notes:42]

[0000866374-24-000012:notes:48]
[same as prior period, unchanged from 0000866374-23-000066:notes:43]

[0000866374-24-000012:notes:49]
A contract liability is recognized when the Company receives payments in advance of the satisfaction of performance. Contract liabilities, identified as deferred revenue, were $755 million and $885 million as of December 31, 2023 and March 31, 2023, respectively, of which $626 million and $795 million, respectively, is included in deferred revenue and customer working capital advances under current liabilities.

[0000866374-24-000012:notes:50]
[same as prior period, unchanged from 0000866374-23-000066:notes:45]

[0000866374-24-000012:notes:51]
The following table presents the Company’s revenue disaggregated based on timing of transfer, point in time or over time, for the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively.

[0000866374-24-000012:notes:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Timing of Transfer | (In millions) |
| FAS |  |  |  |  |  |  |  |
| Point in time | $ | 3,152 |  |  | $ | 3,812 |  |  | $ | 9,868 |  |  | $ | 11,378 |  |
| Over time | 314 |  |  | 217 |  |  | 817 |  |  | 646 |  |
| Total | 3,466 |  |  | 4,029 |  |  | 10,685 |  |  | 12,024 |  |
| FRS |  |  |  |  |  |  |  |
| Point in time | 2,793 |  |  | 3,038 |  |  | 9,069 |  |  | 8,938 |  |
| Over time | 163 |  |  | 187 |  |  | 492 |  |  | 555 |  |
| Total | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker |  |  |  |  |  |  |  |
| Point in time | 6 |  |  | 8 |  |  | 33 |  |  | 41 |  |
| Over time | 704 |  |  | 508 |  |  | 1,730 |  |  | 1,343 |  |
| Total | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations |  |  |  |  |  |  |  |
| Point in time | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Over time | — |  |  | — |  |  | — |  |  | — |  |
| Total | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
| Flex |  |  |  |  |  |  |  |
| Point in time | 5,922 |  |  | 6,844 |  |  | 18,871 |  |  | 20,325 |  |
| Over time | 1,181 |  |  | 912 |  |  | 3,039 |  |  | 2,544 |  |
| Total | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-24-000012:notes:53]
[same as prior period, unchanged from 0000866374-23-000066:notes:48]

[0000866374-24-000012:notes:54]
Flex historically maintains stock-based compensation plans at a corporate level. The Company's primary plan used for granting equity compensation awards is the Company's 2017 Equity Incentive Plan (the "2017 Plan"). During the fiscal year 2023, Nextracker granted equity compensation awards to Nextracker employees under the 2022 Nextracker Inc. Equity Incentive Plan (the "2022 Nextracker Plan"), which is administered by Nextracker, a majority-owned subsidiary of the Company prior to the Spin-off.

[0000866374-24-000012:notes:55]
[same as prior period, unchanged from 0000866374-23-000066:notes:50]

[0000866374-24-000012:notes:56]
[same as prior period, unchanged from 0000866374-23-000066:notes:51]

[0000866374-24-000012:notes:57]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Cost of sales | $ | 10 |  |  | $ | 7 |  |  | $ | 29 |  |  | $ | 21 |  |
| Selling, general and administrative expenses | 29 |  |  | 20 |  |  | 96 |  |  | 59 |  |
| Total share-based compensation expense | $ | 39 |  |  | $ | 27 |  |  | $ | 125 |  |  | $ | 80 |  |

[0000866374-24-000012:notes:58]
Total number of options outstanding and exercisable were immaterial as of December 31, 2023. All options have been fully expensed as of December 31, 2023.

[0000866374-24-000012:notes:59]
[same as prior period, unchanged from 0000866374-23-000066:notes:54]

[0000866374-24-000012:notes:60]
During the nine-month period ended December 31, 2023, the Company granted approximately 4.9 million restricted share unit ("RSU") awards. Of this amount, approximately 3.0 million are plain-vanilla unvested RSU awards that vest over a period of three years, with no performance or market conditions, and with an average grant date price of $26.82 per award. In addition, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain performance conditions, and with an average grant date price of $26.72 per award. The number of shares contingent on performance conditions that ultimately will vest will range from zero up to a maximum of approximately 0.8 million based on a measurement of the Company's adjusted earnings per share growth over certain specified periods, and will cliff vest after a period of three years, to the extent such performance conditions have been met. Further, approximately 0.4 million unvested shares represent the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $35.64 per award and was calculated using a Monte Carlo simulation. The number of shares contingent on market conditions that ultimately will vest will range from zero up to a maximum of approximately 0.8 million based on a measurement of the percentile rank of the Company’s total shareholder return over certain specified periods against the Company's peer companies, and will cliff vest after a period of three years, to the extent such market conditions have been met. Finally, the remaining balance of approximately 1.2 million represents the number of shares issued upon vesting of RSU awards above target levels based on the achievement of certain market conditions for awards granted in the fiscal year 2021. These awards were issued and immediately vested in accordance with the terms and conditions of the underlying awards.

[0000866374-24-000012:notes:61]
As of December 31, 2023, approximately 12 million unvested RSU awards under the 2017 Plan were outstanding, of which vesting for a targeted amount of approximately 1.2 million shares is contingent on meeting certain market conditions, and vesting for a targeted amount of approximately 1.2 million shares is contingent on meeting certain performance conditions. The number of shares tied to market conditions that will ultimately be issued can range from zero to approximately 2.4 million based on the achievement levels. The number of shares tied to performance conditions that will ultimately be issued can range from zero to approximately 2.4 million based on the achievement levels. During the nine-month period ended December 31, 2023, approximately 2.3 million shares vested in connection with the awards with market conditions granted in fiscal year 2021.

[0000866374-24-000012:notes:62]
As of December 31, 2023, total unrecognized compensation expense related to unvested RSU awards under the 2017 Plan, was approximately $170 million, and will be recognized over a weighted-average remaining vesting period of 2.0 years.

[0000866374-24-000012:notes:63]
[same as prior period, unchanged from 0000866374-23-000066:notes:59]

[0000866374-24-000012:notes:64]
During the nine-month period ended December 31, 2023, Nextracker awarded approximately 2.1 million equity-based compensation awards to its employees under the 2022 Nextracker Plan, which included approximately 0.5 million option awards, approximately 1.2 million RSU ("NRSU") awards and approximately 0.4 million performance-based restricted share unit ("NPSU") awards. Vesting for the awards granted under the 2022 Nextracker Plan is contingent upon continued employee service and also may be subject to certain performance conditions.

[0000866374-24-000012:notes:65]
As of December 31, 2023, approximately 6.6 million unvested options awards, NRSU awards, and NPSU awards under the 2022 Nextracker Plan were outstanding, of which vesting for a targeted amount of approximately 3.6 million shares is contingent on meeting certain performance conditions.

[0000866374-24-000012:notes:66]
Total unrecognized compensation expense related to unvested awards under the 2022 Nextracker Plan was approximately $93 million, which is expected to be recognized over a weighted-average period of approximately 2.3 years. After the Spin-off, the Company will not include stock-based compensation expense for the awards granted under the 2022 Nextracker Plan in its consolidated financial statements. Approximately $38 million of expense was recognized for equity-based compensation awards granted under the 2022 Nextracker Plan for the nine-month period ended December 31, 2023.

[0000866374-24-000012:notes:67]
Modifications of Share-Based Awards

[0000866374-24-000012:notes:68]
In January 2024, in connection with the Nextracker Spin-off, the Company was required to make certain adjustments to the number of share-based compensation awards under the 2017 Plan using a conversion ratio designed to preserve the intrinsic value of the awards to the holders immediately prior to the Spin-off. Adjustments to the outstanding share-based compensation awards are not expected to result in additional material compensation expense. All outstanding restricted share unit awards for employees transferred to Nextracker were canceled in connection with the Spin-off.


## us-gaap:EarningsPerShareTextBlock

[0000866374-24-000012:notes:69]
[same as prior period, unchanged from 0000866374-23-000066:notes:63]

[0000866374-24-000012:notes:70]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions, except per share amounts) |
| Basic earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 233 |  |  | $ | 237 |  |  | $ | 850 |  |  | $ | 670 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 36 |  |  | 7 |  |  | 239 |  |  | 19 |  |
| Net income attributable to Flex Ltd. | $ | 197 |  |  | $ | 230 |  |  | $ | 611 |  |  | $ | 651 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 431 |  |  | 452 |  |  | 440 |  |  | 455 |  |
| Basic earnings per share | $ | 0.46 |  |  | $ | 0.51 |  |  | $ | 1.39 |  |  | $ | 1.43 |  |
| Diluted earnings per share attributable to the shareholders of Flex Ltd. |  |  |  |  |  |  |  |
| Net income | $ | 233 |  |  | $ | 237 |  |  | $ | 850 |  |  | $ | 670 |  |
| Net income attributable to noncontrolling interest and redeemable noncontrolling interest | 36 |  |  | 7 |  |  | 239 |  |  | 19 |  |
| Net income attributable to Flex Ltd. | $ | 197 |  |  | $ | 230 |  |  | $ | 611 |  |  | $ | 651 |  |
| Shares used in computation: |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 431 |  |  | 452 |  |  | 440 |  |  | 455 |  |
| Weighted-average ordinary share equivalents from RSU awards (1) | 5 |  |  | 7 |  |  | 6 |  |  | 7 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 436 |  |  | 459 |  |  | 446 |  |  | 462 |  |
| Diluted earnings per share | $ | 0.45 |  |  | $ | 0.50 |  |  | $ | 1.37 |  |  | $ | 1.41 |  |

[0000866374-24-000012:notes:71]
(1)An immaterial amount of RSU awards for both the three and nine-month periods ended December 31, 2023 and December 31, 2022, respectively, were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents.


## us-gaap:DebtDisclosureTextBlock

[0000866374-24-000012:notes:72]
BANK BORROWINGS AND LONG-TERM DEBT
Bank borrowings and long-term debt as of December 31, 2023 and March 31, 2023 are as follows:

[0000866374-24-000012:notes:73]
|  | Maturity Date |  | As of December 31, 2023 |  | As of March 31, 2023 |
|  |  |  | (In millions) |
| 4.750% Notes (1) | June 2025 |  | $ | 592 |  |  | $ | 599 |  |
| 3.750% Notes (1) | February 2026 |  | 683 |  |  | 686 |  |
| 6.000% Notes (1) | January 2028 |  | 397 |  |  | 396 |  |
| 4.875% Notes (1) | June 2029 |  | 657 |  |  | 658 |  |
| 4.875% Notes (1) | May 2030 |  | 682 |  |  | 685 |  |
| JPY Term Loan (2) | April 2024 |  | — |  |  | 253 |  |
| Delayed Draw Term Loan (3) | November 2023 |  | — |  |  | 150 |  |
| Nextracker Term Loan | February 2028 |  | 150 |  |  | 150 |  |
| 3.600% HUF Bonds | December 2031 |  | 290 |  |  | 284 |  |
| Other |  |  | 1 |  |  | 1 |  |
| Debt issuance costs |  |  | (18) |  |  | (21) |  |
|  |  |  | 3,434 |  |  | 3,841 |  |
| Current portion, net of debt issuance costs |  |  | (3) |  |  | (150) |  |
| Non-current portion |  |  | $ | 3,431 |  |  | $ | 3,691 |  |

[0000866374-24-000012:notes:74]
(1)The notes are carried at the principal amount of each note, less any unamortized discount or premium and unamortized debt issuance costs. These notes represent the Company’s senior unsecured obligations and hold equal ranking with all other existing and future senior unsecured debt obligations.

[0000866374-24-000012:notes:75]
(2)During the first quarter of fiscal year 2024, the Company repaid the JPY Term Loan for approximately $241 million. In addition, the Company also settled the associated USD JPY cross currency swap for approximately $60 million.

[0000866374-24-000012:notes:76]
(3)During the second quarter of fiscal year 2024, the Company repaid the Delayed Draw Term Loan for approximately $150 million.

[0000866374-24-000012:notes:77]
The weighted-average interest rate for the Company's long-term debt was 4.6% and 4.7% as of December 31, 2023 and March 31, 2023, respectively.

[0000866374-24-000012:notes:78]
Scheduled repayments of the Company's bank borrowings and long-term debt as of December 31, 2023 are as follows:

[0000866374-24-000012:notes:79]
| Fiscal Year Ending March 31, |  | Amount |
|  |  | (In millions) |
| 2024 (1) |  | $ | — |  |
| 2025 |  | 3 |  |
| 2026 |  | 1,275 |  |
| 2027 |  | — |  |
| 2028 |  | 544 |  |
| Thereafter |  | 1,630 |  |
| Total |  | $ | 3,452 |  |

[0000866374-24-000012:notes:80]
(1)Represents estimated repayments for the remaining fiscal three-month period ending March 31, 2024.


## flex:InterestAndOtherNetTextBlock

[0000866374-24-000012:notes:81]
INTEREST, NET 
Interest, net for the three and nine-month periods ended December 31, 2023 and December 31, 2022 are primarily composed of the following:

[0000866374-24-000012:notes:82]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Interest expenses on debt obligations | $ | 42 |  |  | $ | 49 |  |  | $ | 131 |  |  | $ | 136 |  |
| Interest income | (17) |  |  | (8) |  |  | (53) |  |  | (17) |  |
| AR sale program related expenses | 11 |  |  | 13 |  |  | 34 |  |  | 26 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-24-000012:notes:83]
[same as prior period, unchanged from 0000866374-23-000066:notes:77]

[0000866374-24-000012:notes:84]
[same as prior period, unchanged from 0000866374-23-000066:notes:78]

[0000866374-24-000012:notes:85]
As of December 31, 2023, the aggregate notional amount of the Company’s outstanding foreign currency derivative contracts was $9.8 billion as summarized below:

[0000866374-24-000012:notes:86]
|  |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |
| Cash Flow Hedges |  |  |  |  |
| HUF |  | $ | 452 |  |  | $ | — |  |
| MXN |  | 555 |  |  | — |  |
| Other |  | 544 |  |  | 9 |  |
|  |  | 1,551 |  |  | 9 |  |
| Other Foreign Currency Contracts |  |  |  |  |
| BRL |  | — |  |  | 401 |  |
| CNY |  | 311 |  |  | 25 |  |
| EUR |  | 2,321 |  |  | 2,365 |  |
| MXN |  | 574 |  |  | 469 |  |
| MYR |  | 288 |  |  | 148 |  |
| Other |  | 778 |  |  | 544 |  |
|  |  | 4,272 |  |  | 3,952 |  |
| Total Notional Contract Value in USD |  | $ | 5,823 |  |  | $ | 3,961 |  |

[0000866374-24-000012:notes:87]
As of December 31, 2023, the fair value of the Company’s short-term foreign currency contracts was included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of other charges (income), net in the condensed consolidated statements of operations. As of December 31, 2023 and March 31, 2023, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. Deferred gain was $32 million as of December 31, 2023, and is expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations over the next twelve-month period, except

[0000866374-24-000012:notes:88]
[same as prior period, unchanged from 0000866374-23-000066:notes:82]

[0000866374-24-000012:notes:89]
The Company entered into USD HUF cross currency swaps in December 2021 to hedge the foreign currency risk on the HUF bonds due December 2031, and the fair value of the cross currency swaps was included in current other assets and long-term other liabilities as of December 31, 2023 and March 31, 2023, respectively. The changes in fair value of the USD HUF cross currency swaps are reported in accumulated other comprehensive loss. In addition, corresponding amounts are reclassified out of accumulated other comprehensive loss to other charges (income), net to offset the remeasurement of the underlying HUF bond principal, which also impacts the same line.

[0000866374-24-000012:notes:90]
[same as prior period, unchanged from 0000866374-23-000066:notes:84]

[0000866374-24-000012:notes:91]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31,2023 |  | March 31,2023 |  | Balance SheetLocation |  | December 31,2023 |  | March 31,2023 |
|  | (In millions) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 49 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | 7 |  |  | $ | 22 |  |
| Foreign currency contracts | Other assets |  | $ | — |  |  | $ | — |  |  | Other liabilities |  | $ | 11 |  |  | $ | 88 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 22 |  |  | $ | 26 |  |  | Other current liabilities |  | $ | 19 |  |  | $ | 19 |  |

[0000866374-24-000012:notes:92]
[same as prior period, unchanged from 0000866374-23-000066:notes:86]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-24-000012:notes:93]
[same as prior period, unchanged from 0000866374-23-000066:notes:87]

[0000866374-24-000012:notes:94]
|  | Three-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (13) |  |  | $ | (227) |  |  | $ | (240) |  |  | $ | (73) |  |  | $ | (279) |  |  | $ | (352) |  |
| Other comprehensive loss before reclassifications | 63 |  |  | 58 |  |  | 121 |  |  | 77 |  |  | 80 |  |  | 157 |  |
| Net loss reclassified from accumulated other comprehensive loss | (24) |  |  | 1 |  |  | (23) |  |  | (49) |  |  | — |  |  | (49) |  |
| Net current-period other comprehensive loss | 39 |  |  | 59 |  |  | 98 |  |  | 28 |  |  | 80 |  |  | 108 |  |
| Ending balance | $ | 26 |  |  | $ | (168) |  |  | $ | (142) |  |  | $ | (45) |  |  | $ | (199) |  |  | $ | (244) |  |

[0000866374-24-000012:notes:95]
|  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |
|  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In millions) |
| Beginning balance | $ | (14) |  |  | $ | (180) |  |  | $ | (194) |  |  | $ | (66) |  |  | $ | (116) |  |  | $ | (182) |  |
| Other comprehensive gain (loss) before reclassifications | 126 |  |  | 11 |  |  | 137 |  |  | (72) |  |  | (83) |  |  | (155) |  |
| Net (gains) loss reclassified from accumulated other comprehensive loss | (86) |  |  | 1 |  |  | (85) |  |  | 93 |  |  | — |  |  | 93 |  |
| Net current-period other comprehensive gains (loss) | 40 |  |  | 12 |  |  | 52 |  |  | 21 |  |  | (83) |  |  | (62) |  |
| Ending balance | $ | 26 |  |  | $ | (168) |  |  | $ | (142) |  |  | $ | (45) |  |  | $ | (199) |  |  | $ | (244) |  |

[0000866374-24-000012:notes:96]
Substantially all unrealized gains and losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three and nine-month periods ended December 31, 2023 were reclassified out of accumulated other comprehensive loss to other charges (income), net and cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges. The tax impacts on the changes in accumulated other comprehensive loss for the three-month periods ended December 31, 2023 and December 31, 2022 were $7 million and $9 million, respectively. The tax impacts on the changes in accumulated other comprehensive loss for the nine-month periods ended December 31, 2023 and December 31, 2022 were $2 million and immaterial, respectively.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-24-000012:notes:97]
[same as prior period, unchanged from 0000866374-23-000066:notes:91]

[0000866374-24-000012:notes:98]
[same as prior period, unchanged from 0000866374-23-000066:notes:92]

[0000866374-24-000012:notes:99]
The Company historically has engaged in asset-backed securitization programs (the “ABS Programs”), selling trade receivables to affiliated special purpose entities and then to unaffiliated financial institutions. Upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, the receivables are derecognized from our consolidated balance sheet as effective control of the transferred receivables is passed to the unaffiliated financial institutions, which have the right to pledge or sell the receivables. Accounts receivable sold under the ABS Programs are included as cash provided by operating activities in the consolidated statement of cash flow. During the nine-month periods ended December 31, 2023 and December 31, 2022, no accounts receivable were sold under the ABS Programs.

[0000866374-24-000012:notes:100]
Trade Accounts Receivable Sale Programs
The Company also sells accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected on accounts where the Company has continuing involvement was approximately $0.9 billion and $0.8 billion as of December 31, 2023 and March 31, 2023, respectively. For the nine-month periods ended December 31, 2023 and December 31, 2022, total accounts receivable sold to certain third-party banking institutions was approximately $2.6 billion and $2.6 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received was included as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-24-000012:notes:101]
FAIR VALUE MEASUREMENT OF ASSETS AND LIABILITIES 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability. The accounting guidance for fair value establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000866374-24-000012:notes:102]
Level 1 - Applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities. There were no balances classified as level 1 in the fair value hierarchy as of December 31, 2023 and March 31, 2023.

[0000866374-24-000012:notes:103]
[same as prior period, unchanged from 0000866374-23-000066:notes:96]

[0000866374-24-000012:notes:104]
[same as prior period, unchanged from 0000866374-23-000066:notes:97]

[0000866374-24-000012:notes:105]
[same as prior period, unchanged from 0000866374-23-000066:notes:98]

[0000866374-24-000012:notes:106]
[same as prior period, unchanged from 0000866374-23-000066:notes:99]

[0000866374-24-000012:notes:107]
[same as prior period, unchanged from 0000866374-23-000066:notes:100]

[0000866374-24-000012:notes:108]
There were no transfers between levels in the fair value hierarchy during the nine-month periods ended December 31, 2023 and December 31, 2022.

[0000866374-24-000012:notes:109]
[same as prior period, unchanged from 0000866374-23-000066:notes:102]

[0000866374-24-000012:notes:110]
The following table presents the Company’s assets and liabilities measured at fair value on a recurring basis as of December 31, 2023 and March 31, 2023:

[0000866374-24-000012:notes:111]
|  | Fair Value Measurements as of December 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,102 |  |  | $ | — |  |  | $ | 1,102 |  |
| Foreign currency contracts (Note 8) | — |  |  | 71 |  |  | — |  |  | 71 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (37) |  |  | $ | — |  |  | $ | (37) |  |
|  | Fair Value Measurements as of March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In millions) |
| Assets: |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 2,324 |  |  | $ | — |  |  | $ | 2,324 |  |
| Foreign currency contracts (Note 8) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  | 0 |
| Mutual funds, money market accounts and equity securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Liabilities: |  |  |  |  |  |  | 0 |
| Foreign currency contracts (Note 8) | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |

[0000866374-24-000012:notes:112]
[same as prior period, unchanged from 0000866374-23-000066:notes:105]

[0000866374-24-000012:notes:113]
[same as prior period, unchanged from 0000866374-23-000066:notes:106]

[0000866374-24-000012:notes:114]
|  | As of December 31, 2023 |  | As of March 31, 2023 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In millions) |  |  |
| JPY Term Loan due April 2024 | $ | — |  |  | $ | — |  |  | $ | 253 |  |  | $ | 253 |  |  | Level 2 |
| 4.750% Notes due June 2025 | 592 |  |  | 585 |  |  | 599 |  |  | 590 |  |  | Level 1 |
| 3.750% Notes due February 2026 | 683 |  |  | 662 |  |  | 686 |  |  | 657 |  |  | Level 1 |
| 6.000% Notes due January 2028 | 397 |  |  | 411 |  |  | 396 |  |  | 399 |  |  | Level 1 |
| 4.875% Notes due June 2029 | 657 |  |  | 646 |  |  | 658 |  |  | 631 |  |  | Level 1 |
| 4.875% Notes due May 2030 | 682 |  |  | 671 |  |  | 685 |  |  | 661 |  |  | Level 1 |
| Delayed Draw Term Loan due November 2023 | — |  |  | — |  |  | 150 |  |  | 150 |  |  | Level 2 |
| Nextracker Term Loan due February 2028 | 150 |  |  | 148 |  |  | 150 |  |  | 150 |  |  | Level 2 |
| 3.600% HUF Bonds due December 2031 | 290 |  |  | 212 |  |  | 284 |  |  | 196 |  |  | Level 2 |

[0000866374-24-000012:notes:115]
[same as prior period, unchanged from 0000866374-23-000066:notes:108]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-24-000012:notes:116]
COMMITMENTS AND CONTINGENCIES 
Litigation and other legal matters

[0000866374-24-000012:notes:117]
In connection with the matters described below, the Company has accrued for loss contingencies where it believes that losses are probable and estimable. Although it is reasonably possible that actual losses could be in excess of the Company’s accrual, the Company is unable to estimate a reasonably possible loss or range of loss in excess of its accrual, due to various reasons, including, among others, that: (i) the proceedings are in early stages or no claims have been asserted, (ii) specific damages have not been sought in all of these matters, (iii) damages, if asserted, are considered unsupported and/or exaggerated, (iv) there is uncertainty as to the outcome of pending appeals, motions, or settlements, (v) there are significant factual issues to be resolved, and/or (vi) there are novel legal issues or unsettled legal theories presented. Any such excess loss could have a material effect on the Company’s results of operations or cash flows for a particular period or on the Company’s financial condition.

[0000866374-24-000012:notes:118]
One of the Company's Brazilian subsidiaries has received assessments for certain sales and import taxes. There were originally six tax assessments totaling the updated amount inclusive of interest and penalties of 419 million Brazilian reals (approximately USD $87 million based on the exchange rate as of December 31, 2023). The Company successfully defeated one of the six assessments in September 2019 (totaling approximately 61 million Brazilian reals or USD $13 million). The Company successfully defeated another three of the assessments in September 2022 (totaling the updated amount inclusive of interest and penalties of approximately 261 million Brazilian reals or USD $54 million), each of which remains subject to appeal. The Company was unsuccessful at the administrative level for one of the assessments and filed an annulment action in federal court in Brasilia, Brazil on March 23, 2020; the updated value of that assessment inclusive of interest and penalties is 41 million Brazilian reals (approximately USD $8 million). One of the assessments remains in the review process at the administrative level. The Company believes that it has meritorious defenses to each of these assessments and will continue to vigorously oppose all of them, as well as any future assessments. The Company does not expect final judicial determination on any of these claims in the near future.

[0000866374-24-000012:notes:119]
On February 14, 2019, the Company submitted an initial notification of voluntary disclosure to the U.S. Department of the Treasury, Office of Foreign Assets Control ("OFAC") regarding possible noncompliance with U.S. economic sanctions requirements among certain non-U.S. Flex-affiliated operations. On September 28, 2020, the Company made a submission to OFAC that completed the Company’s voluntary disclosure based on the results of an internal investigation regarding the matter. On June 11, 2021, the Company notified OFAC that it had identified possible additional relevant transactions at one non-U.S. Flex-affiliated operation. The Company submitted an update to OFAC on November 16, 2021 reporting on the results of its review of those transactions. The Company intends to continue to cooperate fully with OFAC in this matter going forward. Nonetheless, it is reasonably possible that the Company could be subject to penalties that could have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-24-000012:notes:120]
A foreign Tax Authority (“Tax Authority”) has assessed a cumulative total of approximately $221 million in taxes owed for multiple Flex legal entities within its jurisdiction for various fiscal years ranging from fiscal year 2010 through fiscal year 2020. The assessed amounts related to the denial of certain deductible intercompany payments and taxability of income earned outside such jurisdiction. The Company disagrees with the Tax Authority’s assessments and is actively contesting the assessments through the administrative and judicial processes.

[0000866374-24-000012:notes:121]
As the final resolution of the above outstanding tax item remains uncertain, the Company continues to provide for the uncertain tax positions based on the more likely than not standard. While the resolution of the issues may result in tax liabilities, interest and penalties, which may be significantly higher than the amounts accrued for these matters, management currently believes that the resolution will not have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000866374-24-000012:notes:122]
In addition to the matters discussed above, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:TreasuryStockTextBlock

[0000866374-24-000012:notes:123]
SHARE REPURCHASES 
During the three and nine-month periods ended December 31, 2023, the Company repurchased 10.7 million and 30.8 million shares at an aggregate purchase price of $275 million and $781 million, respectively, and retired all of these shares. During the second quarter of fiscal year 2024, the Company also retired an additional 50.2 million shares of treasury stock which were repurchased in the prior periods, at an aggregate purchase price of $388 million.

[0000866374-24-000012:notes:124]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $2.0 billion in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 2, 2023. As of December 31, 2023, shares in the aggregate amount of $1.5 billion were available to be repurchased under the current plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-24-000012:notes:125]
SEGMENT REPORTING
The Company reports its financial performance based on three operating and reportable segments, Flex Agility Solutions, Flex Reliability Solutions and Nextracker, and analyzes operating income as the measure of segment profitability. Following the Spin-off, the Company's operating and reportable segments are Flex Agility Solutions and Flex Reliability Solutions. The determination of these segments is based on several factors, including the nature of products and services, the nature of production processes, customer base, delivery channels and similar economic characteristics.

[0000866374-24-000012:notes:126]
An operating segment's performance is evaluated based on its pre-tax operating contribution, or segment income. Segment income is defined as net sales less cost of sales, and segment selling, general and administrative expenses, and does not include intangible amortization, stock-based compensation, restructuring charges, legal and other, and interest, net and other charges, net. A portion of depreciation is allocated to the respective segments, together with other general corporate research and development and administrative expenses.

[0000866374-24-000012:notes:127]
[same as prior period, unchanged from 0000866374-23-000066:notes:120]

[0000866374-24-000012:notes:128]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
|  | (In millions) |
| Net sales: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 3,466 |  |  | $ | 4,029 |  |  | $ | 10,685 |  |  | $ | 12,024 |  |
| Flex Reliability Solutions | 2,956 |  |  | 3,225 |  |  | 9,561 |  |  | 9,493 |  |
| Nextracker | 710 |  |  | 516 |  |  | 1,763 |  |  | 1,384 |  |
| Intersegment eliminations | (29) |  |  | (14) |  |  | (99) |  |  | (32) |  |
|  | $ | 7,103 |  |  | $ | 7,756 |  |  | $ | 21,910 |  |  | $ | 22,869 |  |
| Segment income and reconciliation of income before income taxes: |  |  |  |  |  |  |  |
| Flex Agility Solutions | $ | 174 |  |  | $ | 181 |  |  | $ | 488 |  |  | $ | 523 |  |
| Flex Reliability Solutions | 159 |  |  | 143 |  |  | 495 |  |  | 465 |  |
| Nextracker | 162 |  |  | 60 |  |  | 356 |  |  | 133 |  |
| Corporate and Other | (18) |  |  | (12) |  |  | (46) |  |  | (43) |  |
| Total segment income | 477 |  |  | 372 |  |  | 1,293 |  |  | 1,078 |  |
| Reconciling items: |  |  |  |  |  |  |  |
| Intangible amortization | 17 |  |  | 19 |  |  | 54 |  |  | 62 |  |
| Stock-based compensation | 39 |  |  | 27 |  |  | 125 |  |  | 80 |  |
| Restructuring charges | 73 |  |  | 5 |  |  | 97 |  |  | 5 |  |
| Legal and other (1) | — |  |  | — |  |  | 2 |  |  | 13 |  |
| Interest, net | 36 |  |  | 54 |  |  | 112 |  |  | 150 |  |
| Other charges (income), net | 5 |  |  | 5 |  |  | 32 |  |  | 2 |  |
| Income before income taxes | $ | 307 |  |  | $ | 262 |  |  | $ | 871 |  |  | $ | 766 |  |

[0000866374-24-000012:notes:129]
(1)Legal and other consists of costs not directly related to core business results and may include matters relating to commercial disputes, government regulatory and compliance, intellectual property, antitrust, tax, employment or shareholder issues, product liability claims and other issues on a global basis as well as acquisition related costs and customer related asset recoveries. During the first half of fiscal year 2023, the Company accrued for certain loss contingencies where losses are considered probable and estimable.

[0000866374-24-000012:notes:130]
[same as prior period, unchanged from 0000866374-23-000066:notes:123]

[0000866374-24-000012:notes:131]
[same as prior period, unchanged from 0000866374-23-000066:notes:124]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000866374-24-000012:notes:132]
RESTRUCTURING CHARGES
In October 2023, the Company’s management committed to targeted restructuring activities to improve operational efficiencies by reducing excess workforce capacity. During the three and nine-month periods ended December 31, 2023, the Company recognized approximately $74 million and $100 million of restructuring charges, respectively, most of which related to employee severance.

[0000866374-24-000012:notes:133]
The following table summarizes the provisions, respective payments, and remaining accrued balance as of December 31, 2023 for charges incurred during the nine-month period ended December 31, 2023:

[0000866374-24-000012:notes:134]
|  | Severance |  | Long-LivedAssetImpairment |  | OtherExit Costs |  | Total |
|  | (In millions) |
| Balance as of March 31, 2023 | $ | 44 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 50 |  |
| Provision for charges incurred during the nine-month period ended December 31, 2023 | 93 |  |  | 5 |  |  | 2 |  |  | 100 |  |
| Cash payments during the nine-month period ended December 31, 2023 | (84) |  |  | — |  |  | — |  |  | (84) |  |
| Non-cash reductions during the nine-month period ended December 31, 2023 | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Other adjustments | (1) |  |  | — |  |  | (1) |  |  | (2) |  |
| Balance as of December 31, 2023 | 52 |  |  | — |  |  | 7 |  |  | 59 |  |
| Less: Current portion (classified as other current liabilities) | 51 |  |  | — |  |  | 7 |  |  | 58 |  |
| Accrued restructuring costs, net of current portion (classified as other liabilities) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |


## us-gaap:VariableInterestEntityDisclosureTextBlock

[0000866374-24-000012:notes:135]
VARIABLE INTEREST ENTITIES
Prior to the Spin-off, the Company controlled Nextracker Inc. ("Nextracker") through its holding of Class B common stock that did not participate in the earnings of Nextracker. As such, the shareholders of the equity at risk in Nextracker (the Class A common stock shareholders) did not have the power to direct the key activities of Nextracker and consequently Nextracker was a variable interest entity ("VIE"). The Company had the ability to control Nextracker's activities through its control of 51.4% and 61.4% of the voting rights of Nextracker as of December 31, 2023 and March 31, 2023, respectively. The Company also had the ability to receive significant benefits from the VIE (through its ability to convert its investments in Nextracker and Nextracker LLC into Class A common stock of Nextracker or cash) and as such the Company had been determined to be the primary beneficiary of the VIE. As such, the Company continued to consolidate Nextracker and the interests in Nextracker held by third parties are presented as a noncontrolling interest prior to the Spin-off. Evaluation of the VIE model and identification of the primary beneficiary requires significant judgements to be made regarding which entities can control the activities of a VIE, who can receive benefits or absorb losses from the VIE and the significance of those benefits and losses to the VIE.

[0000866374-24-000012:notes:136]
[same as prior period, unchanged from 0000866374-23-000066:notes:128]

[0000866374-24-000012:notes:137]
As of December 31, 2023 and March 31, 2023, noncontrolling interest was $480 million and $355 million, respectively. Net income attributable to noncontrolling interest was $36 million and $239 million for the three and nine-month periods ended December 31, 2023, respectively. Net income attributable to noncontrolling interest was zero for both the three and nine-month periods ended December 31, 2022. As a result of Nextracker's February 13, 2023 IPO, the noncontrolling interest previously determined to be redeemable prior to the IPO did not exist as of December 31, 2023. Net income attributable to redeemable noncontrolling interest was zero for both the three and nine-month periods ended December 31, 2023. Net income attributable to redeemable noncontrolling interest was $7 million and $19 million for the three and nine-month periods ended December 31, 2022, respectively.

[0000866374-24-000012:notes:138]
The carrying amounts and classification of the VIE's external assets and liabilities as of December 31, 2023 and March 31, 2023 are included in the condensed consolidated balance sheets as follows:

[0000866374-24-000012:notes:139]
|  | December 31, 2023 |  | March 31, 2023 |
|  | (In millions) (Unaudited) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash | $ | 368 |  |  | $ | 130 |  |
| Accounts receivable, net | 365 |  |  | 271 |
| Contract assets | 352 |  |  | 298 |
| Inventories | 203 |  |  | 138 |
| Other current assets | 131 |  |  | 35 |
| Total current assets | 1,419 |  |  | 872 |
| Property and equipment, net | 8 |  |  | 7 |
| Goodwill | 265 |  |  | 265 |
| Other intangible assets, net | 2 |  |  | 1 |
| Other assets | 401 |  |  | 275 |
| Total assets | $ | 2,095 |  |  | $ | 1,420 |  |
| Liabilities |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 375 |  |  | $ | 211 |  |
| Accrued expenses | 70 |  |  | 60 |  |
| Deferred revenue | 180 |  |  | 176 |  |
| Other current liabilities | 76 |  |  | 49 |  |
| Total current liabilities | 701 |  |  | 496 |  |
| Long-term debt | 145 |  |  | 147 |  |
| Other liabilities | 439 |  |  | 280 |  |
| Total liabilities | $ | 1,285 |  |  | $ | 923 |  |


## us-gaap:SubsequentEventsTextBlock

[0000866374-24-000012:notes:140]
SUBSEQUENT EVENTS
On January 2, 2024, Flex completed the Spin-off of our remaining interests in Nextracker to Flex shareholders on a pro rata basis based on the number ordinary shares of Flex held by each shareholder of Flex as of December 29, 2023, which was the record date of the Distribution. Under the previously disclosed terms of the Spin-off, Flex shareholders received approximately 0.17 shares of Nextracker Class A common stock for every Flex ordinary share held as of the record date of the Distribution. Flex shareholders received cash in lieu of any fractional shares.

[0000866374-24-000012:notes:141]
As a result of the completion of the Spin-off, Nextracker became a fully independent public company, Flex no longer directly or indirectly holds any shares of Nextracker common stock or any securities convertible into or exchangeable for shares of Nextracker common stock and Flex will no longer consolidate Nextracker into its future financial results. Following the Spin-off, Flex ordinary shares continue to trade on Nasdaq under the ticker symbol “FLEX” and shares of Nextracker Class A common stock continue to trade on Nasdaq under the ticker symbol “NXT”.

[0000866374-24-000012:notes:142]
The historical results of Nextracker will be reported in Flex's consolidated financial statements as discontinued operations beginning in Flex's fourth quarter ending March 31, 2024.

[0000866374-24-000012:notes:143]
Prior to or in connection with the Spin-off, Flex entered into various agreements to effect the Spin-off and provide a framework for the relationship between Flex and Nextracker following the Spin-off, including a Separation Agreement, a Tax Matters Agreement, a Transition Services Agreement, as well as agreements governing future trading relationships.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000866374-24-000012:notes:144]
On November 22, 2023, Scott Offer, Executive Vice President and General Counsel, adopted a trading plan that provides for the sale of up to 150,000 ordinary shares of the Company. The plan will terminate on March 14, 2024, subject to early termination for certain specified events set forth in the plan.

[0000866374-24-000012:notes:145]
On December 5, 2023, Michael P. Hartung, President, Agility Solutions, adopted a trading plan that provides for the sale of up to 43,381 ordinary shares of the Company. The plan will terminate on December 5, 2024, subject to early termination for certain specified events set forth in the plan.

[0000866374-24-000012:notes:146]
On December 14, 2023, Hooi Tan, President, Global Operations and Components, adopted a trading plan that provides for the sale of up to 32,110 ordinary shares of the Company. The plan will terminate on December 12, 2024, subject to early termination for certain specified events set forth in the plan.
