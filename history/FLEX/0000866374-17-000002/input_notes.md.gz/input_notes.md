# FLEX notes — 0000866374-17-000002


## flex:InterestAndOtherNetTextBlock

[0000866374-17-000002:notes:1]
[same as prior period, unchanged from 0000866374-16-000007:notes:1]

[0000866374-17-000002:notes:2]
During the three-month and nine-month periods ended December 31, 2016, the Company recognized interest expense of $26.6 million and $79.9 million, respectively, on its debt obligations outstanding during the periods. During the three-month and nine-month periods ended December 31, 2015, the Company recognized interest expense of $26.2 million and $71.4 million, respectively.


## flex:SummaryOfDeferredPurchasePriceReceivablesTableTextBlock

[0000866374-17-000002:notes:3]
[same as prior period, unchanged from 0000866374-16-000007:notes:3]

[0000866374-17-000002:notes:4]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 461,544 |  |  | $ | 537,619 |  |  | $ | 501,097 |  |  | $ | 600,672 |  |
| Transfers of receivables | 919,766 |  |  | 920,370 |  |  | 2,442,490 |  |  | 2,671,095 |  |
| Collections | (712,392 | ) |  | (923,294 | ) |  | (2,274,669 | ) |  | (2,737,072 | ) |
| Ending balance | $ | 668,918 |  |  | $ | 534,695 |  |  | $ | 668,918 |  |  | $ | 534,695 |  |


## flex:SupplementalGuarantorAndNonGuarantorCondensedConsolidatingFinancialStatementsTextBlock

[0000866374-17-000002:notes:5]
[same as prior period, unchanged from 0000866374-16-000007:notes:5]

[0000866374-17-000002:notes:6]
Flex Ltd. (“Parent”) has three tranches of Notes of $500 million, $500 million, and $600 million, respectively, each outstanding, which mature on February 15, 2020, February 15, 2023 and June 15, 2025, respectively. These Notes are senior unsecured obligations, and are guaranteed, fully and unconditionally, jointly and severally, on an unsecured basis, by certain of the Company’s 100% owned subsidiaries (the “guarantor subsidiaries”). These subsidiary guarantees will terminate upon 1) a sale or other disposition of the guarantor or the sale or disposition of all or substantially all the assets of the guarantor (other than to the Parent or a subsidiary); 2) such guarantor ceasing to be a guarantor or a borrower under the Company’s Term Loan Agreement and the Revolving Line of Credit; 3) defeasance or discharge of the Notes, as provided in the Notes indenture; or 4) if at any time the Notes are rated investment grade, provided that each rating agency confirms that the Notes will continue to be rated investment grade after the Note Guaranties are terminated.

[0000866374-17-000002:notes:7]
[same as prior period, unchanged from 0000866374-16-000007:notes:7]

[0000866374-17-000002:notes:8]
Condensed Consolidating Balance Sheets as of December 31, 2016

[0000866374-17-000002:notes:9]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 943,807 |  |  | $ | 63,698 |  |  | $ | 849,591 |  |  | $ | — |  |  | $ | 1,857,096 |  |
| Accounts receivable | — |  |  | 815,141 |  |  | 1,347,609 |  |  | — |  |  | 2,162,750 |  |
| Inventories | — |  |  | 1,521,272 |  |  | 1,972,345 |  |  | — |  |  | 3,493,617 |  |
| Inter company receivable | 10,504,971 |  |  | 7,802,175 |  |  | 14,601,712 |  |  | (32,908,858 | ) |  | — |  |
| Other current assets | 5,796 |  |  | 187,215 |  |  | 907,148 |  |  | — |  |  | 1,100,159 |  |
| Total current assets | 11,454,574 |  |  | 10,389,501 |  |  | 19,678,405 |  |  | (32,908,858 | ) |  | 8,613,622 |  |
| Property and equipment, net | — |  |  | 584,382 |  |  | 1,737,154 |  |  | — |  |  | 2,321,536 |  |
| Goodwill and other intangible assets, net | 1,214 |  |  | 85,894 |  |  | 1,250,213 |  |  | — |  |  | 1,337,321 |  |
| Other assets | 2,211,872 |  |  | 276,492 |  |  | 2,000,849 |  |  | (3,958,643 | ) |  | 530,570 |  |
| Investment in subsidiaries | 2,562,818 |  |  | 3,456,295 |  |  | 17,947,038 |  |  | (23,966,151 | ) |  | — |  |
| Total assets | $ | 16,230,478 |  |  | $ | 14,792,564 |  |  | $ | 42,613,659 |  |  | $ | (60,833,652 | ) |  | $ | 12,803,049 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 63,365 |  |  | $ | — |  |  | $ | 5,491 |  |  | $ | — |  |  | $ | 68,856 |  |
| Accounts payable | — |  |  | 1,734,186 |  |  | 2,965,548 |  |  | — |  |  | 4,699,734 |  |
| Accrued payroll | — |  |  | 99,464 |  |  | 258,458 |  |  | — |  |  | 357,922 |  |
| Inter company payable | 10,728,155 |  |  | 10,528,081 |  |  | 11,652,622 |  |  | (32,908,858 | ) |  | — |  |
| Other current liabilities | 28,349 |  |  | 785,866 |  |  | 937,030 |  |  | — |  |  | 1,751,245 |  |
| Total current liabilities | 10,819,869 |  |  | 13,147,597 |  |  | 15,819,149 |  |  | (32,908,858 | ) |  | 6,877,757 |  |
| Long term liabilities | 2,810,714 |  |  | 2,042,092 |  |  | 2,389,632 |  |  | (3,958,643 | ) |  | 3,283,795 |  |
| Flex Ltd. shareholders’ equity (deficit) | 2,599,895 |  |  | (397,125 | ) |  | 24,363,276 |  |  | (23,966,151 | ) |  | 2,599,895 |  |
| Noncontrolling interests | — |  |  | — |  |  | 41,602 |  |  | — |  |  | 41,602 |  |
| Total shareholders’ equity (deficit) | 2,599,895 |  |  | (397,125 | ) |  | 24,404,878 |  |  | (23,966,151 | ) |  | 2,641,497 |  |
| Total liabilities and shareholders’ equity | $ | 16,230,478 |  |  | $ | 14,792,564 |  |  | $ | 42,613,659 |  |  | $ | (60,833,652 | ) |  | $ | 12,803,049 |  |

[0000866374-17-000002:notes:10]
[same as prior period, unchanged from 0000866374-16-000007:notes:10]

[0000866374-17-000002:notes:11]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 734,869 |  |  | $ | 148,201 |  |  | $ | 724,500 |  |  | $ | — |  |  | $ | 1,607,570 |  |
| Accounts receivable | — |  |  | 729,331 |  |  | 1,315,426 |  |  | — |  |  | 2,044,757 |  |
| Inventories | — |  |  | 1,482,410 |  |  | 2,009,246 |  |  | — |  |  | 3,491,656 |  |
| Inter company receivable | 9,105,728 |  |  | 5,568,392 |  |  | 12,404,722 |  |  | (27,078,842 | ) |  | — |  |
| Other current assets | 2,951 |  |  | 180,842 |  |  | 987,350 |  |  | — |  |  | 1,171,143 |  |
| Total current assets | 9,843,548 |  |  | 8,109,176 |  |  | 17,441,244 |  |  | (27,078,842 | ) |  | 8,315,126 |  |
| Property and equipment, net | — |  |  | 553,072 |  |  | 1,704,561 |  |  | — |  |  | 2,257,633 |  |
| Goodwill and other intangible assets, net | 175 |  |  | 60,895 |  |  | 1,284,750 |  |  | — |  |  | 1,345,820 |  |
| Other assets | 2,249,145 |  |  | 267,034 |  |  | 2,004,437 |  |  | (4,054,214 | ) |  | 466,402 |  |
| Investment in subsidiaries | 2,815,426 |  |  | 3,038,002 |  |  | 18,175,348 |  |  | (24,028,776 | ) |  | — |  |
| Total assets | $ | 14,908,294 |  |  | $ | 12,028,179 |  |  | $ | 40,610,340 |  |  | $ | (55,161,832 | ) |  | $ | 12,384,981 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowings and current portion of long-term debt | $ | 58,836 |  |  | $ | 946 |  |  | $ | 5,384 |  |  | $ | — |  |  | $ | 65,166 |  |
| Accounts payable | — |  |  | 1,401,835 |  |  | 2,846,457 |  |  | — |  |  | 4,248,292 |  |
| Accrued payroll | — |  |  | 114,509 |  |  | 239,038 |  |  | — |  |  | 353,547 |  |
| Inter company payable | 9,562,405 |  |  | 7,999,335 |  |  | 9,517,102 |  |  | (27,078,842 | ) |  | — |  |
| Other current liabilities | 33,008 |  |  | 869,470 |  |  | 1,002,722 |  |  | — |  |  | 1,905,200 |  |
| Total current liabilities | 9,654,249 |  |  | 10,386,095 |  |  | 13,610,703 |  |  | (27,078,842 | ) |  | 6,572,205 |  |
| Long term liabilities | 2,683,173 |  |  | 2,063,988 |  |  | 2,514,299 |  |  | (4,054,214 | ) |  | 3,207,246 |  |
| Flex Ltd. shareholders’ equity (deficit) | 2,570,872 |  |  | (421,904 | ) |  | 24,450,680 |  |  | (24,028,776 | ) |  | 2,570,872 |  |
| Noncontrolling interests | — |  |  | — |  |  | 34,658 |  |  | — |  |  | 34,658 |  |
| Total shareholders’ equity (deficit) | 2,570,872 |  |  | (421,904 | ) |  | 24,485,338 |  |  | (24,028,776 | ) |  | 2,605,530 |  |
| Total liabilities and shareholders’ equity | $ | 14,908,294 |  |  | $ | 12,028,179 |  |  | $ | 40,610,340 |  |  | $ | (55,161,832 | ) |  | $ | 12,384,981 |  |

[0000866374-17-000002:notes:12]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2016

[0000866374-17-000002:notes:13]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,186,855 |  |  | $ | 4,453,753 |  |  | $ | (2,525,609 | ) |  | $ | 6,114,999 |  |
| Cost of sales | — |  |  | 3,722,516 |  |  | 4,501,637 |  |  | (2,525,609 | ) |  | 5,698,544 |  |
| Gross profit (loss) | — |  |  | 464,339 |  |  | (47,884 | ) |  | — |  |  | 416,455 |  |
| Selling, general and administrative expenses | — |  |  | 66,738 |  |  | 164,813 |  |  | — |  |  | 231,551 |  |
| Intangible amortization | 25 |  |  | 864 |  |  | 17,845 |  |  | — |  |  | 18,734 |  |
| Interest and other, net | (370,703 | ) |  | 662,422 |  |  | (265,791 | ) |  | — |  |  | 25,928 |  |
| Income (loss) from continuing operations before income taxes | 370,678 |  |  | (265,685 | ) |  | 35,249 |  |  | — |  |  | 140,242 |  |
| Provision for (benefit from) income taxes | — |  |  | (4,018 | ) |  | 14,791 |  |  | — |  |  | 10,773 |  |
| Equity in earnings in subsidiaries | (241,209 | ) |  | (71,920 | ) |  | 4,401 |  |  | 308,728 |  |  | — |  |
| Net income (loss) | $ | 129,469 |  |  | $ | (333,587 | ) |  | $ | 24,859 |  |  | $ | 308,728 |  |  | $ | 129,469 |  |

[0000866374-17-000002:notes:14]
Condensed Consolidating Statements of Operations for the Three-Month Period Ended December 31, 2015

[0000866374-17-000002:notes:15]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 4,597,684 |  |  | $ | 5,718,182 |  |  | $ | (3,552,689 | ) |  | $ | 6,763,177 |  |
| Cost of sales | — |  |  | 4,187,076 |  |  | 5,676,323 |  |  | (3,552,689 | ) |  | 6,310,710 |  |
| Gross profit | — |  |  | 410,608 |  |  | 41,859 |  |  | — |  |  | 452,467 |  |
| Selling, general and administrative expenses | — |  |  | 83,346 |  |  | 157,271 |  |  | — |  |  | 240,617 |  |
| Intangible amortization | 75 |  |  | 960 |  |  | 18,284 |  |  | — |  |  | 19,319 |  |
| Interest and other, net | 49,358 |  |  | 316,345 |  |  | (299,722 | ) |  | — |  |  | 65,981 |  |
| Income (loss) from continuing operations before income taxes | (49,433 | ) |  | 9,957 |  |  | 166,026 |  |  | — |  |  | 126,550 |  |
| Benefit from income taxes | — |  |  | (8,071 | ) |  | (14,289 | ) |  | — |  |  | (22,360 | ) |
| Equity in earnings in subsidiaries | 198,343 |  |  | (88,988 | ) |  | (10,534 | ) |  | (98,821 | ) |  | — |  |
| Net income (loss) | $ | 148,910 |  |  | $ | (70,960 | ) |  | $ | 169,781 |  |  | $ | (98,821 | ) |  | $ | 148,910 |  |

[0000866374-17-000002:notes:16]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2016

[0000866374-17-000002:notes:17]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 12,008,455 |  |  | $ | 13,981,899 |  |  | $ | (7,990,017 | ) |  | $ | 18,000,337 |  |
| Cost of sales | — |  |  | 10,822,629 |  |  | 14,031,584 |  |  | (7,990,017 | ) |  | 16,864,196 |  |
| Gross profit (loss) | — |  |  | 1,185,826 |  |  | (49,685 | ) |  | — |  |  | 1,136,141 |  |
| Selling, general and administrative expenses | — |  |  | 212,059 |  |  | 502,981 |  |  | — |  |  | 715,040 |  |
| Intangible amortization | 175 |  |  | 2,298 |  |  | 59,845 |  |  | — |  |  | 62,318 |  |
| Interest and other, net | (561,290 | ) |  | 1,322,198 |  |  | (674,032 | ) |  | — |  |  | 86,876 |  |
| Income (loss) from continuing operations before income taxes | 561,115 |  |  | (350,729 | ) |  | 61,521 |  |  | — |  |  | 271,907 |  |
| Provision for (benefit from) income taxes | 11 |  |  | (947 | ) |  | 40,153 |  |  | — |  |  | 39,217 |  |
| Equity in earnings in subsidiaries | (328,414 | ) |  | (136,175 | ) |  | (69,935 | ) |  | 534,524 |  |  | — |  |
| Net income (loss) | $ | 232,690 |  |  | $ | (485,957 | ) |  | $ | (48,567 | ) |  | $ | 534,524 |  |  | $ | 232,690 |  |

[0000866374-17-000002:notes:18]
Condensed Consolidating Statements of Operations for the Nine-Month Period Ended December 31, 2015

[0000866374-17-000002:notes:19]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net sales | $ | — |  |  | $ | 13,126,281 |  |  | $ | 15,168,232 |  |  | $ | (9,648,326 | ) |  | $ | 18,646,187 |  |
| Cost of sales | — |  |  | 11,972,388 |  |  | 15,120,401 |  |  | (9,648,326 | ) |  | 17,444,463 |  |
| Gross profit | — |  |  | 1,153,893 |  |  | 47,831 |  |  | — |  |  | 1,201,724 |  |
| Selling, general and administrative expenses | — |  |  | 213,614 |  |  | 453,184 |  |  | — |  |  | 666,798 |  |
| Intangible amortization | 225 |  |  | 2,881 |  |  | 40,011 |  |  | — |  |  | 43,117 |  |
| Interest and other, net | (347,663 | ) |  | 929,730 |  |  | (475,704 | ) |  | — |  |  | 106,363 |  |
| Income from continuing operations before income taxes | 347,438 |  |  | 7,668 |  |  | 30,340 |  |  | — |  |  | 385,446 |  |
| Provision for (benefit from) income taxes | — |  |  | (4,630 | ) |  | 7,339 |  |  | — |  |  | 2,709 |  |
| Equity in earnings in subsidiaries | 35,299 |  |  | (140,241 | ) |  | 42,225 |  |  | 62,717 |  |  | — |  |
| Net income (loss) | $ | 382,737 |  |  | $ | (127,943 | ) |  | $ | 65,226 |  |  | $ | 62,717 |  |  | $ | 382,737 |  |

[0000866374-17-000002:notes:20]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2016

[0000866374-17-000002:notes:21]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 129,469 |  |  | $ | (333,587 | ) |  | $ | 24,859 |  |  | $ | 308,728 |  |  | $ | 129,469 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (36,412 | ) |  | 58,791 |  |  | 35,660 |  |  | (94,451 | ) |  | (36,412 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (201 | ) |  | 3,443 |  |  | (201 | ) |  | (3,242 | ) |  | (201 | ) |
| Comprehensive income (loss) | $ | 92,856 |  |  | $ | (271,353 | ) |  | $ | 60,318 |  |  | $ | 211,035 |  |  | $ | 92,856 |  |

[0000866374-17-000002:notes:22]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Three-Month Period Ended December 31, 2015

[0000866374-17-000002:notes:23]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 148,910 |  |  | $ | (70,960 | ) |  | $ | 169,781 |  |  | $ | (98,821 | ) |  | $ | 148,910 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 30,063 |  |  | 62,209 |  |  | 50,828 |  |  | (113,037 | ) |  | 30,063 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 10,497 |  |  | 4,099 |  |  | 10,497 |  |  | (14,596 | ) |  | 10,497 |  |
| Comprehensive income (loss) | $ | 189,470 |  |  | $ | (4,652 | ) |  | $ | 231,106 |  |  | $ | (226,454 | ) |  | $ | 189,470 |  |

[0000866374-17-000002:notes:24]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2016

[0000866374-17-000002:notes:25]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 232,690 |  |  | $ | (485,957 | ) |  | $ | (48,567 | ) |  | $ | 534,524 |  |  | $ | 232,690 |  |
| Other comprehensive income (loss): | 0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | (22,338 | ) |  | 68,972 |  |  | 57,055 |  |  | (126,027 | ) |  | (22,338 | ) |
| Unrealized gain (loss) on derivative instruments and other, net of zero tax | (912 | ) |  | 6,942 |  |  | (912 | ) |  | (6,030 | ) |  | (912 | ) |
| Comprehensive income (loss) | $ | 209,440 |  |  | $ | (410,043 | ) |  | $ | 7,576 |  |  | $ | 402,467 |  |  | $ | 209,440 |  |

[0000866374-17-000002:notes:26]
Condensed Consolidating Statements of Comprehensive Income (Loss) for the Nine-Month Period Ended December 31, 2015

[0000866374-17-000002:notes:27]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (in thousands) |
| Net income (loss) | $ | 382,737 |  |  | $ | (127,943 | ) |  | $ | 65,226 |  |  | $ | 62,717 |  |  | $ | 382,737 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments, net of zero tax | 2,579 |  |  | 5,025 |  |  | (703 | ) |  | (4,322 | ) |  | 2,579 |  |
| Unrealized gain on derivative instruments and other, net of zero tax | 17,782 |  |  | 9,884 |  |  | 17,782 |  |  | (27,666 | ) |  | 17,782 |  |
| Comprehensive income (loss) | $ | 403,098 |  |  | $ | (113,034 | ) |  | $ | 82,305 |  |  | $ | 30,729 |  |  | $ | 403,098 |  |

[0000866374-17-000002:notes:28]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2016

[0000866374-17-000002:notes:29]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 520,709 |  |  | $ | (354,918 | ) |  | $ | 847,430 |  |  | $ | (33 | ) |  | $ | 1,013,188 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (134,755 | ) |  | (250,812 | ) |  | 27 |  |  | (385,540 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (73,469 | ) |  | (106,790 | ) |  | — |  |  | (180,259 | ) |
| Proceeds from divestiture of businesses, net of cash held in divested businesses | — |  |  | 20,500 |  |  | 15,573 |  |  | — |  |  | 36,073 |  |
| Investing cash flows to affiliates | (840,082 | ) |  | (3,334,220 | ) |  | (532,400 | ) |  | 4,706,702 |  |  | — |  |
| Other investing activities, net | (61,213 | ) |  | (7,823 | ) |  | 19,332 |  |  | — |  |  | (49,704 | ) |
| Net cash used in investing activities | (901,295 | ) |  | (3,529,767 | ) |  | (855,097 | ) |  | 4,706,729 |  |  | (579,430 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 204,916 |  |  | — |  |  | 602 |  |  | — |  |  | 205,518 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (106,547 | ) |  | (4,460 | ) |  | (4,082 | ) |  | — |  |  | (115,089 | ) |
| Payments for repurchases of ordinary shares | (259,658 | ) |  | — |  |  | — |  |  | — |  |  | (259,658 | ) |
| Net proceeds from issuance of ordinary shares | 11,978 |  |  | — |  |  | — |  |  | — |  |  | 11,978 |  |
| Financing cash flows from affiliates | 790,398 |  |  | 3,813,276 |  |  | 103,022 |  |  | (4,706,696 | ) |  | — |  |
| Other financing activities, net | 30,000 |  |  | (11,347 | ) |  | (65,955 | ) |  | — |  |  | (47,302 | ) |
| Net cash provided by financing activities | 671,087 |  |  | 3,797,469 |  |  | 33,587 |  |  | (4,706,696 | ) |  | (204,553 | ) |
| Effect of exchange rates on cash and cash equivalents | (81,563 | ) |  | 2,713 |  |  | 99,171 |  |  | — |  |  | 20,321 |  |
| Net increase (decrease) in cash and cash equivalents | 208,938 |  |  | (84,503 | ) |  | 125,091 |  |  | — |  |  | 249,526 |  |
| Cash and cash equivalents, beginning of period | 734,869 |  |  | 148,201 |  |  | 724,500 |  |  | — |  |  | 1,607,570 |  |
| Cash and cash equivalents, end of period | $ | 943,807 |  |  | $ | 63,698 |  |  | $ | 849,591 |  |  | $ | — |  |  | $ | 1,857,096 |  |

[0000866374-17-000002:notes:30]
Condensed Consolidating Statements of Cash Flows for the Nine-Month Period Ended December 31, 2015

[0000866374-17-000002:notes:31]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
|  | (In thousands) |
| Net cash provided by (used in) operating activities | $ | 343,182 |  |  | $ | (93,746 | ) |  | $ | 690,336 |  |  | $ | — |  |  | $ | 939,772 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property and equipment, net of proceeds from disposal | — |  |  | (128,011 | ) |  | (285,928 | ) |  | 5 |  |  | (413,934 | ) |
| Acquisition and divestiture of businesses, net of cash acquired and cash held in divested business | — |  |  | (809,233 | ) |  | (94,612 | ) |  | — |  |  | (903,845 | ) |
| Proceeds from divestiture of business, net of cash held in divested business | — |  |  | — |  |  | 3,603 |  |  | — |  |  | 3,603 |  |
| Investing cash flows to affiliates | (1,099,775 | ) |  | (923,812 | ) |  | (1,087,520 | ) |  | 3,111,107 |  |  | — |  |
| Other investing activities, net | (2,046 | ) |  | (23,270 | ) |  | 26,713 |  |  | — |  |  | 1,397 |  |
| Net cash used in investing activities | (1,101,821 | ) |  | (1,884,326 | ) |  | (1,437,744 | ) |  | 3,111,112 |  |  | (1,312,779 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from bank borrowings and long-term debt | 695,309 |  |  | — |  |  | 60,375 |  |  | — |  |  | 755,684 |  |
| Repayments of bank borrowings, long-term debt and capital lease obligations | (35,638 | ) |  | (1,333 | ) |  | (3,735 | ) |  | — |  |  | (40,706 | ) |
| Payments for repurchases of ordinary shares | (331,690 | ) |  | — |  |  | — |  |  | — |  |  | (331,690 | ) |
| Net proceeds from issuance of ordinary shares | 52,950 |  |  | — |  |  | — |  |  | — |  |  | 52,950 |  |
| Financing cash flows from affiliates | 632,750 |  |  | 1,996,352 |  |  | 482,010 |  |  | (3,111,112 | ) |  | — |  |
| Other financing activities, net | — |  |  | — |  |  | (49,742 | ) |  | — |  |  | (49,742 | ) |
| Net cash provided by financing activities | 1,013,681 |  |  | 1,995,019 |  |  | 488,908 |  |  | (3,111,112 | ) |  | 386,496 |  |
| Effect of exchange rates on cash and cash equivalents | 4,101 |  |  | 2,143 |  |  | (13,947 | ) |  | — |  |  | (7,703 | ) |
| Net decrease (increase) in cash and cash equivalents | 259,143 |  |  | 19,090 |  |  | (272,447 | ) |  | — |  |  | 5,786 |  |
| Cash and cash equivalents, beginning of period | 608,971 |  |  | 168,272 |  |  | 851,165 |  |  | — |  |  | 1,628,408 |  |
| Cash and cash equivalents, end of period | $ | 868,114 |  |  | $ | 187,362 |  |  | $ | 578,718 |  |  | $ | — |  |  | $ | 1,634,194 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000866374-17-000002:notes:32]
[same as prior period, unchanged from 0000866374-16-000007:notes:32]

[0000866374-17-000002:notes:33]
[same as prior period, unchanged from 0000866374-16-000007:notes:33]

[0000866374-17-000002:notes:34]
During the nine-month period ended December 31, 2016, the Company completed three acquisitions that were not individually, nor in the aggregate, significant to the consolidated financial position, results of operations and cash flows of the Company. Most notably is the Company’s acquisition of two manufacturing and development facilities from Bose Corporation (“Bose”), a global leader in audio systems. The acquisition expanded the Company’s capabilities in the audio market and is included in the CTG segment. The other acquired businesses strengthen the Company's capabilities in the energy market within the IEI segment. The Company paid a total of $179.7 million, net of cash acquired, of which $161.9 million, net of $17.8 million of cash acquired is related to the Bose acquisition. The Company acquired primarily $69.8 million of inventory, $66.0 million of property and equipment, recorded goodwill of $57.5 million and intangible assets of $44.9 million substantially related to Bose. The intangibles will amortize over a weighted-average estimated useful life of 7.4 years. In connection with these acquisitions, the Company assumed $60.8 million in other liabilities including additional consideration of $28.0 million payable to Bose by the end of fiscal year 2017. Further, the equity incentive plan of one of the acquirees was assumed as part of the acquisition.

[0000866374-17-000002:notes:35]
The results of operations for each of the acquisitions completed in fiscal year 2017, including the Bose acquisition, were included in the Company’s consolidated financial results beginning on the date of each acquisition, and the total amount of net income and revenue of the acquisitions, collectively, were immaterial to the Company's consolidated financial results for the three-month and nine-month periods ended December 31, 2016. Pro-forma results of operations for the acquisitions completed in fiscal year 2017 have not been presented because the effects, individually and in the aggregate, were not material to the Company’s consolidated financial results for all periods presented.

[0000866374-17-000002:notes:36]
The total amount of net income for the acquisitions completed in fiscal year 2016, collectively, were $29.5 million and $34.4 million, for the three-month and nine-month periods ended December 31, 2015, respectively. The total amount of revenue of these acquisitions, collectively, was not material to the Company’s consolidated financial results for the three-month and nine-month periods ended December 31, 2015. On a pro-forma basis, and assuming the fiscal year 2016 acquisitions occurred on the first day of that fiscal year, or April 1, 2015, the Company's net income would have been estimated to be $111.4 million and $322.0 million for the three-month and nine-month periods ended December 31, 2015, respectively. Pro-forma revenue for the acquisitions in fiscal year 2016 has not been presented because the effect, collectively, was not material to the Company’s consolidated revenues for all periods presented.

[0000866374-17-000002:notes:37]
[same as prior period, unchanged from 0000866374-16-000007:notes:37]

[0000866374-17-000002:notes:38]
[same as prior period, unchanged from 0000866374-16-000007:notes:38]

[0000866374-17-000002:notes:39]
During the nine-month period ended December 31, 2016, the Company disposed of two non-strategic businesses within the HRS and IEI segments. The Company received $33.0 million of proceeds, net of an immaterial amount of cash held in one of the divested businesses. The property and equipment and various other assets sold, and liabilities transferred were not material to the Company's consolidated financial results. The loss on disposition was not material to the Company’s consolidated financial results, and is included in other charges, net in the condensed consolidated statements of operations for the nine-month period ended December 31, 2016.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000866374-17-000002:notes:40]
COMMITMENTS AND CONTINGENCIES

[0000866374-17-000002:notes:41]
Litigation and other legal matters

[0000866374-17-000002:notes:42]
One of the Company's Brazilian subsidiaries has received several related assessments for certain sales and import taxes. The first two tax assessments were received in fiscal year 2014 and fiscal year 2016 relating to calendar year 2010 for an alleged total amount of 109 million Brazilian reals (approximately USD $34 million based on the exchange rate as of December 31, 2016). These two assessments are in various stages of the review process at the administrative level. During the third quarter of fiscal year 2017, the same Brazilian subsidiary received a third assessment related to calendar year 2011 taxes of an additional 181 million Brazilian reals (approximately USD $56 million based on the exchange rate as of December 31, 2016). The Company plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company is unable to determine the likelihood of an unfavorable outcome of these assessments against its Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for these assessments or any future assessments that are reasonably possible. The Company does not expect final judicial determination on any of these claims for several years.

[0000866374-17-000002:notes:43]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during fiscal year 2017.

[0000866374-17-000002:notes:44]
In addition, from time to time, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business. The Company defends itself vigorously against any such claims. Although the outcome of these matters is currently not determinable, management expects that any losses that are probable or reasonably possible of being incurred as a result of these matters, which are in excess of amounts already accrued in the Company’s condensed consolidated balance sheets, would not be material to the financial statements as a whole.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000866374-17-000002:notes:45]
[same as prior period, unchanged from 0000866374-16-000007:notes:45]

[0000866374-17-000002:notes:46]
[same as prior period, unchanged from 0000866374-16-000007:notes:46]

[0000866374-17-000002:notes:47]
|  | Three-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (42,233 | ) |  | $ | (80,319 | ) |  | $ | (122,552 | ) |  | $ | (60,981 | ) |  | $ | (139,723 | ) |  | $ | (200,704 | ) |
| Other comprehensive gain (loss) before reclassifications | (1,354 | ) |  | (33,770 | ) |  | (35,124 | ) |  | 5,941 |  |  | 9,224 |  |  | 15,165 |  |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 1,153 |  |  | (2,642 | ) |  | (1,489 | ) |  | 4,556 |  |  | 20,839 |  |  | 25,395 |  |
| Net current-period other comprehensive gain (loss) | (201 | ) |  | (36,412 | ) |  | (36,613 | ) |  | 10,497 |  |  | 30,063 |  |  | 40,560 |  |
| Ending balance | $ | (42,434 | ) |  | $ | (116,731 | ) |  | $ | (159,165 | ) |  | $ | (50,484 | ) |  | $ | (109,660 | ) |  | $ | (160,144 | ) |

[0000866374-17-000002:notes:48]
|  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |
|  | Unrealized loss on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |  | Unrealized gain(loss) on derivativeinstruments andother |  | Foreign currencytranslationadjustments |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (41,522 | ) |  | $ | (94,393 | ) |  | $ | (135,915 | ) |  | $ | (68,266 | ) |  | $ | (112,239 | ) |  | $ | (180,505 | ) |
| Other comprehensive loss before reclassifications | (1,031 | ) |  | (19,471 | ) |  | (20,502 | ) |  | (8,478 | ) |  | (18,412 | ) |  | (26,890 | ) |
| Net (gains) losses reclassified from accumulated other comprehensive loss | 119 |  |  | (2,867 | ) |  | (2,748 | ) |  | 26,260 |  |  | 20,991 |  |  | 47,251 |  |
| Net current-period other comprehensive gain (loss) | (912 | ) |  | (22,338 | ) |  | (23,250 | ) |  | 17,782 |  |  | 2,579 |  |  | 20,361 |  |
| Ending balance | $ | (42,434 | ) |  | $ | (116,731 | ) |  | $ | (159,165 | ) |  | $ | (50,484 | ) |  | $ | (109,660 | ) |  | $ | (160,144 | ) |

[0000866374-17-000002:notes:49]
Net losses reclassified from accumulated other comprehensive loss during the nine-month period ended December 31, 2015 relating to derivative instruments and other includes $24.7 million attributable to the Company’s cash flow hedge instruments which were recognized as a component of cost of sales in the condensed consolidated statement of operations. During the three-month ended December 31, 2015, the Company recognized a loss of $26.8 million in connection with the disposition of a non-strategic Western European manufacturing facility, which included a $25.3 million cumulative foreign currency translation loss. This loss was offset by the release of certain cumulative foreign currency translation gains of $4.2 million, which has been reclassified from accumulated other comprehensive loss during the period and is included in other charges, net in the condensed consolidated statement of operations.

[0000866374-17-000002:notes:50]
Substantially all unrealized losses relating to derivative instruments and other, reclassified from accumulated other comprehensive loss for the three-month and nine-month periods ended December 31, 2015, was recognized as a component of cost of sales in the condensed consolidated statement of operations, which primarily relate to the Company’s foreign currency contracts accounted for as cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0000866374-17-000002:notes:51]
Organization of the Company

[0000866374-17-000002:notes:52]
Flex Ltd., formerly Flextronics International Ltd., ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from Sketch-to-Scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of its medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes its mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

[0000866374-17-000002:notes:53]
The Company's service offerings include a comprehensive range of value-added design and engineering services that are tailored to the various markets and needs of its customers. Other focused service offerings relate to manufacturing (including enclosures, metals, plastic injection molding, precision plastics, machining, and mechanicals), system integration and assembly and test services, materials procurement, inventory management, logistics and after-sales services (including product repair, warranty services, re-manufacturing and maintenance) and supply chain management software solutions and component product offerings (including rigid and flexible printed circuit boards and power adapters and chargers).


## us-gaap:DebtDisclosureTextBlock

[0000866374-17-000002:notes:54]
BANK BORROWINGS AND LONG TERM DEBT

[0000866374-17-000002:notes:55]
Bank borrowings and long-term debt are as follows:

[0000866374-17-000002:notes:56]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 525,000 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 595,879 |  |  | 595,589 |  |
| Other | 62,448 |  |  | 71,317 |  |
| Debt issuance costs | (16,487 | ) |  | (17,351 | ) |
| Total | $ | 2,866,840 |  |  | $ | 2,774,555 |  |

[0000866374-17-000002:notes:57]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of December 31, 2016 and March 31, 2016.

[0000866374-17-000002:notes:58]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018. On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which will commence October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

[0000866374-17-000002:notes:59]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

[0000866374-17-000002:notes:60]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of December 31, 2016, the Company was in compliance with the covenants under this term loan agreement.

[0000866374-17-000002:notes:61]
Repayment of the Company’s long term debt outstanding as of December 31, 2016 is as follows:

[0000866374-17-000002:notes:62]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 11,579 |  |
| 2018 | 58,504 |  |
| 2019 | 486,317 |  |
| 2020 | 517,567 |  |
| 2021 | 64,648 |  |
| Thereafter | 1,744,712 |  |
| Total | $ | 2,883,327 |  |

[0000866374-17-000002:notes:63]
_________________________________________________________

[0000866374-17-000002:notes:64]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2017. |

[0000866374-17-000002:notes:65]
On January 23, 2017, the Company entered into a €100 million (approximately $105.4 million as of December 31, 2016), 5-year, unsecured, term-loan agreement due January 2, 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000866374-17-000002:notes:66]
[same as prior period, unchanged from 0000866374-16-000007:notes:52]

[0000866374-17-000002:notes:67]
[same as prior period, unchanged from 0000866374-16-000007:notes:53]

[0000866374-17-000002:notes:68]
The Company enters into forward contracts and foreign currency swap contracts primarily to manage the foreign currency risk associated with monetary accounts and anticipated foreign currency denominated transactions. The Company hedges committed exposures and does not engage in speculative transactions. As of December 31, 2016, the aggregate notional amount of the Company’s outstanding foreign currency contracts was $4.8 billion as summarized below:

[0000866374-17-000002:notes:69]
|  |  | Foreign Currency Amount |  | Notional Contract Value in USD |
| Currency |  | Buy |  | Sell |  | Buy |  | Sell |
|  |  | (In thousands) |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |  |  |  |
| CNY |  | 1,037,000 |  |  | — |  |  | $ | 148,969 |  |  | $ | — |  |
| EUR |  | 36,268 |  |  | 56,358 |  |  | 37,693 |  |  | 64,046 |  |
| HUF |  | 16,053,300 |  |  | — |  |  | 54,006 |  |  | — |  |
| ILS |  | 86,441 |  |  | — |  |  | 22,413 |  |  | — |  |
| INR |  | 1,314,549 |  |  | — |  |  | 19,100 |  |  | — |  |
| MXN |  | 1,775,000 |  |  | — |  |  | 85,636 |  |  | — |  |
| MYR |  | 139,000 |  |  | 9,000 |  |  | 31,013 |  |  | 2,008 |  |
| RON |  | 95,661 |  |  | — |  |  | 21,901 |  |  | — |  |
| Other |  | N/A |  |  | N/A |  |  | 34,172 |  |  | 12,223 |  |
|  |  |  |  |  |  |  |  | 454,903 |  |  | 78,277 |  |
| Other Foreign Currency Contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| BRL |  | — |  |  | 443,000 |  |  | — |  |  | 134,946 |  |
| CNY |  | 4,319,620 |  |  | 2,035,392 |  |  | 620,177 |  |  | 292,391 |  |
| DKK |  | 187,400 |  |  | 157,200 |  |  | 26,201 |  |  | 21,979 |  |
| EUR |  | 874,957 |  |  | 1,385,620 |  |  | 913,218 |  |  | 1,444,927 |  |
| GBP |  | 35,110 |  |  | 65,145 |  |  | 42,969 |  |  | 79,940 |  |
| HUF |  | 29,285,732 |  |  | 24,552,611 |  |  | 98,522 |  |  | 82,599 |  |
| ILS |  | 62,640 |  |  | 59,420 |  |  | 16,241 |  |  | 15,407 |  |
| INR |  | 4,040,788 |  |  | 677,800 |  |  | 59,242 |  |  | 10,000 |  |
| MXN |  | 1,718,039 |  |  | 1,155,529 |  |  | 82,888 |  |  | 55,749 |  |
| MYR |  | 383,028 |  |  | 89,800 |  |  | 85,459 |  |  | 20,036 |  |
| PLN |  | 122,243 |  |  | 70,681 |  |  | 28,864 |  |  | 16,689 |  |
| SGD |  | 44,800 |  |  | 11,150 |  |  | 30,846 |  |  | 7,677 |  |
| Other |  | N/A |  |  | N/A |  |  | 54,729 |  |  | 67,304 |  |
|  |  |  |  |  |  |  |  | 2,059,356 |  |  | 2,249,644 |  |
| Total Notional Contract Value in USD |  |  |  |  |  |  |  | $ | 2,514,259 |  |  | $ | 2,327,921 |  |

[0000866374-17-000002:notes:70]
As of December 31, 2016, the fair value of the Company’s short-term foreign currency contracts was not material and is included in other current assets or other current liabilities, as applicable, in the condensed consolidated balance sheets. Certain of these contracts are designed to economically hedge the Company’s exposure to monetary assets and liabilities denominated in a non-functional currency and are not accounted for as hedges under the accounting standards. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change as a component of interest and other, net in the condensed consolidated statements of operations. As of December 31, 2016 and March 31, 2016, the Company also has included net deferred gains and losses in accumulated other comprehensive loss, a component of shareholders’ equity in the condensed consolidated balance sheets, relating to changes in fair value of its foreign currency contracts that are accounted for as cash flow hedges. These deferred losses were $3.6 million as of December 31, 2016, and are expected to be recognized primarily as a component of cost of sales in the condensed consolidated statements of operations primarily over the next twelve-month period. The gains and losses recognized in earnings due to hedge ineffectiveness were not material for all fiscal periods presented and are included as a component of interest and other, net in the condensed consolidated statements of operations.

[0000866374-17-000002:notes:71]
[same as prior period, unchanged from 0000866374-16-000007:notes:57]

[0000866374-17-000002:notes:72]
|  | Fair Values of Derivative Instruments |
|  | Asset Derivatives |  | Liability Derivatives |
|  |  |  | Fair Value |  |  |  | Fair Value |
|  | Balance SheetLocation |  | December 31, 2016 |  | March 31, 2016 |  | Balance SheetLocation |  | December 31, 2016 |  | March 31, 2016 |
|  | (In thousands) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 7,681 |  |  | $ | 5,510 |  |  | Other current liabilities |  | $ | 9,933 |  |  | $ | 2,446 |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts | Other current assets |  | $ | 20,254 |  |  | $ | 17,138 |  |  | Other current liabilities |  | $ | 12,995 |  |  | $ | 18,645 |  |

[0000866374-17-000002:notes:73]
[same as prior period, unchanged from 0000866374-16-000007:notes:59]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000866374-17-000002:notes:74]
[same as prior period, unchanged from 0000866374-16-000007:notes:60]

[0000866374-17-000002:notes:75]
[same as prior period, unchanged from 0000866374-16-000007:notes:61]

[0000866374-17-000002:notes:76]
[same as prior period, unchanged from 0000866374-16-000007:notes:62]

[0000866374-17-000002:notes:77]
[same as prior period, unchanged from 0000866374-16-000007:notes:63]

[0000866374-17-000002:notes:78]
[same as prior period, unchanged from 0000866374-16-000007:notes:64]

[0000866374-17-000002:notes:79]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cost of sales | $ | 2,437 |  |  | $ | 2,407 |  |  | $ | 7,506 |  |  | $ | 6,440 |  |
| Selling, general and administrative expenses | 18,344 |  |  | 21,826 |  |  | 59,805 |  |  | 50,119 |  |
| Total share-based compensation expense | $ | 20,781 |  |  | $ | 24,233 |  |  | $ | 67,311 |  |  | $ | 56,559 |  |

[0000866374-17-000002:notes:80]
[same as prior period, unchanged from 0000866374-16-000007:notes:66]

[0000866374-17-000002:notes:81]
Total unrecognized compensation expense related to share options under the 2010 Plan is not significant. As of December 31, 2016, the number of options outstanding and exercisable under the 2010 Plan was 0.2 million each, and at a weighted-average exercise price of $8.97 per share and $8.93 per share, respectively.

[0000866374-17-000002:notes:82]
During the nine-month period ended December 31, 2016, the Company granted 6.3 million unvested share bonus awards under the 2010 Plan. Of this amount, approximately 5.4 million unvested share bonus awards have an average grant date price of $12.93 per share. Further, approximately 0.7 million of these unvested shares represents the target amount of grants made to certain key employees whereby vesting is contingent on certain market conditions. The average grant date fair value of these awards contingent on certain market conditions was estimated to be $17.57 per award and was calculated using a Monte Carlo simulation. The remaining 0.2 million of unvested share bonus awards under the 2010 Plan have an average grant date price of $12.82 per share and represents the target amount of grants made to certain executive officers whereby vesting is contingent on meeting certain free cash flow targets. The number of shares under the 2010 Plan, contingent on market conditions that ultimately will vest range from zero up to a maximum of 1.4 million based on a measurement of the percentile rank of the Company’s total shareholder return over a certain specified period against the Standard and Poor’s (“S&P”) 500 Composite Index and will cliff vest after a period of three years, if such market conditions have been met. The number of shares under the 2010 Plan, contingent on free cash flow targets that ultimately will vest range from zero up to a maximum of 0.4 million of the target payment based on a measurement of cumulative three-year increase of free cash flow from operations of the Company, and will cliff vest after a period of three years.

[0000866374-17-000002:notes:83]
As of December 31, 2016, approximately 15.8 million unvested share bonus awards under the 2010 Plan were outstanding, of which vesting for a targeted amount of 2.3 million is contingent primarily on meeting certain market conditions. The number of shares that will ultimately be issued can range from zero to 4.6 million based on the achievement levels of the respective conditions. During the nine-month period ended December 31, 2016, 3.5 million shares under the 2010 Plan vested in connection with the share bonus awards with market conditions granted in fiscal year 2014.

[0000866374-17-000002:notes:84]
As of December 31, 2016, total unrecognized compensation expense related to unvested share bonus awards under the 2010 Plan is $139.2 million, and will be recognized over a weighted-average remaining vesting period of 2.6 years. Approximately $22.6 million of the total unrecognized compensation cost, is related to awards under the 2010 Plan whereby vesting is contingent on meeting certain market conditions.

[0000866374-17-000002:notes:85]
[same as prior period, unchanged from 0000866374-16-000007:notes:71]

[0000866374-17-000002:notes:86]
All shares previously granted under the NEXTracker plan are the result of the Company's conversion of all outstanding, unvested shares of NEXTracker into unvested shares of the Company, as part of the acquisition. Therefore, no additional share options or share bonus awards were granted by the Company during the nine-month period ended December 31, 2016.

[0000866374-17-000002:notes:87]
As of December 31, 2016, total unrecognized compensation expense related to share options under the NEXTracker Plan is $9.2 million, and will be recognized over a weighted-average remaining vesting period of 2.1 years. As of December 31, 2016, the number of options outstanding and exercisable was 1.8 million and 0.4 million, respectively, at a weighted-average exercise price of $3.54 per share and $4.48 per share, respectively.

[0000866374-17-000002:notes:88]
As of December 31, 2016, approximately 1.6 million unvested share bonus awards were outstanding. The total unrecognized compensation expense related to unvested share bonus awards under the NEXTracker Plan is $10.7 million, and will be recognized over a weighted-average remaining vesting period of 1.8 years.

[0000866374-17-000002:notes:89]
[same as prior period, unchanged from 0000866374-16-000007:notes:75]

[0000866374-17-000002:notes:90]
[same as prior period, unchanged from 0000866374-16-000007:notes:76]

[0000866374-17-000002:notes:91]
As of December 31, 2016, total unrecognized compensation expense related to share options under the BrightBox Plan is $1.5 million, and will be recognized over a weighted-average remaining vesting period of 2.4 years. As of December 31, 2016, the number of options outstanding was 0.2 million, at a weighted-average exercise price of $0.51 per share. No options under this plan were exercisable as of December 31, 2016.


## us-gaap:EarningsPerShareTextBlock

[0000866374-17-000002:notes:92]
[same as prior period, unchanged from 0000866374-16-000007:notes:78]

[0000866374-17-000002:notes:93]
[same as prior period, unchanged from 0000866374-16-000007:notes:79]

[0000866374-17-000002:notes:94]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands, except per share amounts) |
| Net income | $ | 129,469 |  |  | $ | 148,910 |  |  | $ | 232,690 |  |  | $ | 382,737 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 539,638 |  |  | 554,919 |  |  | 542,780 |  |  | 561,070 |  |
| Basic earnings per share | $ | 0.24 |  |  | $ | 0.27 |  |  | $ | 0.43 |  |  | $ | 0.68 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 129,469 |  |  | $ | 148,910 |  |  | $ | 232,690 |  |  | $ | 382,737 |  |
| Shares used in computation: |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average ordinary shares outstanding | 539,638 |  |  | 554,919 |  |  | 542,780 |  |  | 561,070 |  |
| Weighted-average ordinary share equivalents from stock options and awards (1) (2) | 5,384 |  |  | 6,077 |  |  | 5,592 |  |  | 7,856 |  |
| Weighted-average ordinary shares and ordinary share equivalents outstanding | 545,022 |  |  | 560,996 |  |  | 548,372 |  |  | 568,926 |  |
| Diluted earnings per share | $ | 0.24 |  |  | $ | 0.27 |  |  | $ | 0.42 |  |  | $ | 0.67 |  |

[0000866374-17-000002:notes:95]
[same as prior period, unchanged from 0000866374-16-000007:notes:81]

[0000866374-17-000002:notes:96]
(1)         Options to purchase ordinary shares of 0.5 million and 2.1 million during the three-month periods ended December 31, 2016 and December 31, 2015, respectively, and share bonus awards of 0.1 million for the three-month period ended December 31, 2015 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive share bonus awards was excluded for the three-month period ended December 31, 2016.

[0000866374-17-000002:notes:97]
(2)         Options to purchase ordinary shares of 0.7 million and 1.2 million during the nine-month periods ended December 31, 2016 and December 31, 2015, respectively, and share bonus awards of 3.5 million for the nine-month period ended December 31, 2015 were excluded from the computation of diluted earnings per share due to their anti-dilutive impact on the weighted-average ordinary share equivalents. An immaterial amount of anti-dilutive share bonus awards was excluded for the nine-month period ended December 31, 2016.


## us-gaap:FairValueDisclosuresTextBlock

[0000866374-17-000002:notes:98]
[same as prior period, unchanged from 0000866374-16-000007:notes:84]

[0000866374-17-000002:notes:99]
[same as prior period, unchanged from 0000866374-16-000007:notes:85]

[0000866374-17-000002:notes:100]
[same as prior period, unchanged from 0000866374-16-000007:notes:86]

[0000866374-17-000002:notes:101]
[same as prior period, unchanged from 0000866374-16-000007:notes:87]

[0000866374-17-000002:notes:102]
[same as prior period, unchanged from 0000866374-16-000007:notes:88]

[0000866374-17-000002:notes:103]
[same as prior period, unchanged from 0000866374-16-000007:notes:89]

[0000866374-17-000002:notes:104]
[same as prior period, unchanged from 0000866374-16-000007:notes:90]

[0000866374-17-000002:notes:105]
[same as prior period, unchanged from 0000866374-16-000007:notes:91]

[0000866374-17-000002:notes:106]
[same as prior period, unchanged from 0000866374-16-000007:notes:92]

[0000866374-17-000002:notes:107]
[same as prior period, unchanged from 0000866374-16-000007:notes:93]

[0000866374-17-000002:notes:108]
During the three-month period ended December 31, 2015, the Company accrued $81.0 million of contingent consideration related to the acquisition of NEXTracker on the date of acquisition. The fair value of the liability was estimated using a simulation-based measurement technique with significant inputs that are not observable in the market and thus represents a level 3 fair value measurement. The significant inputs in the fair value measurement not supported by market activity included the Company's probability assessments of expected future revenue during the earn-out period and associated volatility, appropriately discounted considering the uncertainties associated with the obligation, and calculated in accordance with the terms of the merger agreement. Significant decreases in expected revenue during the earn-out period, or significant increases in the discount rate or volatility in isolation would result in lower fair value estimates. The interrelationship between these inputs is not considered significant.

[0000866374-17-000002:notes:109]
During the three-month period ended December 31, 2016, the Company paid $40.6 million of the total contingent consideration following the first year's targets achievement in accordance with the terms of the merger agreement, which is included in other financing activities, net, in the condensed consolidated statements of cash flows.

[0000866374-17-000002:notes:110]
[same as prior period, unchanged from 0000866374-16-000007:notes:95]

[0000866374-17-000002:notes:111]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Beginning balance | $ | 75,614 |  |  | $ | 4,500 |  |  | $ | 73,423 |  |  | $ | 4,500 |  |
| Additions to accrual | — |  |  | 81,000 |  |  | — |  |  | 81,000 |  |
| Payments | (40,555 | ) |  | — |  |  | (42,776 | ) |  | — |  |
| Fair value adjustments | (6,997 | ) |  | 4,000 |  |  | (2,585 | ) |  | 4,000 |  |
| Ending balance | $ | 28,062 |  |  | $ | 89,500 |  |  | $ | 28,062 |  |  | $ | 89,500 |  |

[0000866374-17-000002:notes:112]
The Company values deferred purchase price receivables relating to its asset-backed securitization program based on a discounted cash flow analysis using unobservable inputs (i.e., level 3 inputs), which are primarily risk free interest rates adjusted for the credit quality of the underlying creditor. Due to its high credit quality and short term maturity, the fair value approximates carrying value. Significant increases in either of the major unobservable inputs (credit spread, risk free interest rate) in isolation would result in lower fair value estimates, however the impact is not meaningful. The interrelationship between these inputs is also insignificant. Refer to note 10 for a reconciliation of the change in the deferred purchase price receivable during the three-month and nine-month periods ended December 31, 2016 and December 31, 2015.

[0000866374-17-000002:notes:113]
There were no transfers between levels in the fair value hierarchy during the three-month and nine-month periods ended December 31, 2016 and December 31, 2015.

[0000866374-17-000002:notes:114]
[same as prior period, unchanged from 0000866374-16-000007:notes:99]

[0000866374-17-000002:notes:115]
[same as prior period, unchanged from 0000866374-16-000007:notes:100]

[0000866374-17-000002:notes:116]
|  | Fair Value Measurements as of December 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 751,027 |  |  | $ | — |  |  | $ | 751,027 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 668,918 |  |  | 668,918 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 27,935 |  |  | — |  |  | 27,935 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 6,686 |  |  | 50,522 |  |  | — |  |  | 57,208 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (22,928 | ) |  | $ | — |  |  | $ | (22,928 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (28,062 | ) |  | (28,062 | ) |
|  | Fair Value Measurements as of March 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds and time deposits (included in cash and cash equivalents of the condensed consolidated balance sheet) | $ | — |  |  | $ | 1,074,132 |  |  | $ | — |  |  | $ | 1,074,132 |  |
| Deferred purchase price receivable (Note 10) | — |  |  | — |  |  | 501,097 |  |  | 501,097 |  |
| Foreign exchange contracts (Note 8) | — |  |  | 22,648 |  |  | — |  |  | 22,648 |  |
| Deferred compensation plan assets: |  |  |  |  |  |  |  |  |  | 0 |  |
| Mutual funds, money market accounts and equity securities | 9,228 |  |  | 40,556 |  |  | — |  |  | 49,784 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  | 0 |  |
| Foreign exchange contracts (Note 8) | $ | — |  |  | $ | (21,091 | ) |  | $ | — |  |  | $ | (21,091 | ) |
| Contingent consideration in connection with business acquisitions | — |  |  | — |  |  | (73,423 | ) |  | (73,423 | ) |

[0000866374-17-000002:notes:117]
[same as prior period, unchanged from 0000866374-16-000007:notes:102]

[0000866374-17-000002:notes:118]
[same as prior period, unchanged from 0000866374-16-000007:notes:103]

[0000866374-17-000002:notes:119]
|  | As of December 31, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | 525,000 |  |  | 524,675 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 525,740 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 (1) | 700,000 |  |  | 696,941 |  |  | 577,500 |  |  | 573,533 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 532,810 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,879 |  |  | 639,288 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,820,879 |  |  | $ | 2,919,454 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

[0000866374-17-000002:notes:120]
(1)    On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021. Refer to note 5 for further details of the arrangement.

[0000866374-17-000002:notes:121]
The Term Loans and Notes due February 2020, February 2023 and June 2025 are valued based on broker trading prices in active markets.

[0000866374-17-000002:notes:122]
The Company values its outstanding €49.7 million (approximately $52.3 million as of December 31, 2016), 5-year, unsecured, term-loan due September 30, 2020 based on the current market rate, and as of December 31, 2016, the carrying amount approximates fair value.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000866374-17-000002:notes:123]
Recently Adopted Accounting Pronouncement

[0000866374-17-000002:notes:124]
In March 2016, the Financial Accounting Standards Board ("FASB") issued new guidance intended to reduce the cost and complexity of the accounting for share-based payments. The new guidance simplifies various aspects of the accounting for share-based payments including income tax effects, withholding requirements and forfeitures. The Company elected to early adopt this new guidance beginning in the first quarter of fiscal year 2017. The guidance eliminates additional paid in capital ("APIC") pools and requires companies to recognize all excess tax benefits and tax deficiencies in the income statement when the awards vest or are settled. It also addresses the presentation of excess tax benefits and employee taxes paid on the statement of cash flows. Prior to adoption, the Company elected to not deduct tax benefits for stock-based compensation awards on its tax returns, and accordingly, did not have any excess tax benefits or tax deficiencies upon adoption. The Company therefore determined that adoption of the new guidance had no impact on the condensed consolidated statement of operations and the condensed consolidated statement of cash flows. Further, the new guidance eliminates the requirement to estimate forfeitures and reduce stock compensation expense during the vesting period. Instead, companies can elect to account for actual forfeitures as they occur and record any previously unrecognized compensation expense for estimated forfeitures up to the period of adoption as a retrospective adjustment to beginning retained earnings. The Company has made the election to account for actual forfeitures as they occur starting in fiscal year 2017. After assessment, it was determined that the cumulative effect adjustment required under the new guidance was immaterial and therefore the Company did not record a retrospective adjustment. The Company finally determined that the adoption of this guidance did not have a significant impact on the consolidated financial position, results of operations and cash flows of the Company.

[0000866374-17-000002:notes:125]
Recently Issued Accounting Pronouncements

[0000866374-17-000002:notes:126]
In January 2017, the FASB issued new guidance that changes the definition of a business to assist entities with evaluating when a set of transferred assets and activities is a business. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The guidance may result in more asset acquisitions being accounted for as purchases of assets in lieu of business combinations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019.

[0000866374-17-000002:notes:127]
In October 2016, the FASB issued new guidance to amend the consolidation guidance on how a reporting entity that is the single decision maker of a variable interest entity ("VIE") should treat indirect interests in the entity held through related parties that are under common control with the reporting entity when determining whether it is the primary beneficiary of that VIE. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2018.

[0000866374-17-000002:notes:128]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company intends to early adopt the new guidance starting in the first quarter of fiscal year 2018, with an expected immaterial impact on its consolidated financial statements.

[0000866374-17-000002:notes:129]
In August 2016, the FASB issued new guidance intended to address specific cash flow issues with the objective of reducing the existing diversity in practice. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The Company is currently assessing the impact of this update and the timing of adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000866374-17-000002:notes:130]
[same as prior period, unchanged from 0000866374-16-000007:notes:111]

[0000866374-17-000002:notes:131]
[same as prior period, unchanged from 0000866374-16-000007:notes:115]

[0000866374-17-000002:notes:132]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.

[0000866374-17-000002:notes:133]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second quarters for fiscal year 2017 and fiscal year 2016 ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively. The Company's third quarters end on December 31 of each year, which are comprised of 92 days and 97 days for fiscal years 2017 and 2016, respectively.

[0000866374-17-000002:notes:134]
[same as prior period, unchanged from 0000866374-16-000007:notes:118]

[0000866374-17-000002:notes:135]
[same as prior period, unchanged from 0000866374-16-000007:notes:119]


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0000866374-17-000002:notes:136]
OTHER CHARGES, NET

[0000866374-17-000002:notes:137]
The Company incurred expenses of $44.4 million and $46.3 million during the three-month and nine-month periods ended December 31, 2015, respectively, primarily due to $26.8 million loss on disposition of a non-strategic Western European manufacturing facility, which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by currency translation gains of $4.2 million during the three-month and nine-month periods ended December 31, 2015.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000866374-17-000002:notes:138]
[same as prior period, unchanged from 0000866374-16-000007:notes:120]

[0000866374-17-000002:notes:139]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In thousands) |
| Intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer-related intangibles | $ | 254,991 |  |  | $ | (96,655 | ) |  | $ | 158,336 |  |  | $ | 223,046 |  |  | $ | (66,473 | ) |  | $ | 156,573 |  |
| Licenses and other intangibles | 279,740 |  |  | (66,473 | ) |  | 213,267 |  |  | 285,053 |  |  | (37,872 | ) |  | 247,181 |  |
| Total | $ | 534,731 |  |  | $ | (163,128 | ) |  | $ | 371,603 |  |  | $ | 508,099 |  |  | $ | (104,345 | ) |  | $ | 403,754 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000866374-17-000002:notes:140]
The following table summarizes the activity in the Company’s goodwill account for each of its four segments during the nine-month period ended December 31, 2016:

[0000866374-17-000002:notes:141]
|  |  | HRS |  | CTG |  | IEI |  | CEC |  | Amount |
|  | (In thousands) |
| Balance, beginning of the year |  | $ | 439,336 |  |  | $ | 68,234 |  |  | $ | 322,803 |  |  | $ | 111,693 |  |  | $ | 942,066 |  |
| Additions (1) |  | — |  |  | 39,791 |  |  | 17,727 |  |  | — |  |  | 57,518 |  |
| Divestitures (2) |  | (1,787 | ) |  | — |  |  | (2,640 | ) |  | — |  |  | (4,427 | ) |
| Purchase accounting adjustments (3) |  | 794 |  |  | — |  |  | — |  |  | — |  |  | 794 |  |
| Foreign currency translation adjustments (4) |  | (30,233 | ) |  | — |  |  | — |  |  | — |  |  | (30,233 | ) |
| Balance, end of the period |  | $ | 408,110 |  |  | $ | 108,025 |  |  | $ | 337,890 |  |  | $ | 111,693 |  |  | $ | 965,718 |  |

[0000866374-17-000002:notes:142]
| (1) | The goodwill generated from the Company’s business combinations completed during the nine-month period ended December 31, 2016 is primarily related to value placed on the acquired employee workforces, service offerings and capabilities of the acquired businesses. The goodwill is not deductible for income tax purposes. See note 12 for additional information. |

[0000866374-17-000002:notes:143]
| (2) | During the nine-month period ended December 31, 2016, the Company disposed of two non-strategic businesses within the IEI and HRS segments, and recorded an aggregate reduction of goodwill of $4.4 million accordingly, which is included in the loss on sale recorded in other charges, net on the condensed consolidated statement of operations. |

[0000866374-17-000002:notes:144]
[same as prior period, unchanged from 0000866374-16-000007:notes:126]

[0000866374-17-000002:notes:145]
| (4) | During the nine-month period ended December 31, 2016, the Company recorded $30.2 million of foreign currency translation adjustments primarily related to the goodwill associated with the acquisition of Mirror Controls International ("MCi"), as the U.S. Dollar strengthened against the Euro. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000866374-17-000002:notes:146]
[same as prior period, unchanged from 0000866374-16-000007:notes:127]

[0000866374-17-000002:notes:147]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Raw materials | $ | 2,399,270 |  |  | $ | 2,234,512 |  |
| Work-in-progress | 436,289 |  |  | 561,282 |  |
| Finished goods | 658,058 |  |  | 695,862 |  |
|  | $ | 3,493,617 |  |  | $ | 3,491,656 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000866374-17-000002:notes:148]
[same as prior period, unchanged from 0000866374-16-000007:notes:129]

[0000866374-17-000002:notes:149]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Net sales: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 2,102,321 |  |  | $ | 2,469,099 |  |  | $ | 6,400,233 |  |  | $ | 6,640,626 |  |
| Consumer Technologies Group | 1,848,970 |  |  | 2,057,850 |  |  | 4,827,488 |  |  | 5,633,903 |  |
| Industrial & Emerging Industries | 1,140,366 |  |  | 1,214,225 |  |  | 3,672,103 |  |  | 3,490,205 |  |
| High Reliability Solutions | 1,023,342 |  |  | 1,022,003 |  |  | 3,100,513 |  |  | 2,881,453 |  |
|  | $ | 6,114,999 |  |  | $ | 6,763,177 |  |  | $ | 18,000,337 |  |  | $ | 18,646,187 |  |
| Segment income and reconciliation of income before tax: |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 62,109 |  |  | $ | 75,578 |  |  | $ | 176,460 |  |  | $ | 198,400 |  |
| Consumer Technologies Group | 59,282 |  |  | 49,032 |  |  | 139,230 |  |  | 129,045 |  |
| Industrial & Emerging Industries | 39,681 |  |  | 49,230 |  |  | 127,020 |  |  | 110,498 |  |
| High Reliability Solutions | 82,729 |  |  | 82,806 |  |  | 249,972 |  |  | 213,890 |  |
| Corporate and Other | (20,695 | ) |  | (20,563 | ) |  | (82,395 | ) |  | (60,348 | ) |
| Total segment income | 223,106 |  |  | 236,083 |  |  | 610,287 |  |  | 591,485 |  |
| Reconciling items: |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 18,734 |  |  | 19,319 |  |  | 62,318 |  |  | 43,117 |  |
| Stock-based compensation | 20,781 |  |  | 24,233 |  |  | 67,311 |  |  | 56,559 |  |
| Inventory impairment and other (1) | — |  |  | — |  |  | 92,915 |  |  | — |  |
| Restructuring (2) | 17,421 |  |  | — |  |  | 28,960 |  |  | — |  |
| Other charges, net | 3,090 |  |  | 44,415 |  |  | 15,007 |  |  | 46,257 |  |
| Interest and other, net | 22,838 |  |  | 21,566 |  |  | 71,869 |  |  | 60,106 |  |
| Income before income taxes | $ | 140,242 |  |  | $ | 126,550 |  |  | $ | 271,907 |  |  | $ | 385,446 |  |

[0000866374-17-000002:notes:150]
| (1) | During the fourth quarter of fiscal year 2016, the Company accepted the return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61.0 million as of March 31, 2016, associated with its outstanding SunEdison receivables. |

[0000866374-17-000002:notes:151]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the nine-month period ended December 31, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same period. The total charge of $92.9 million is included in cost of sales for the nine-month period ended December 31, 2016 but is excluded from segment results above.

[0000866374-17-000002:notes:152]
| (2) | During the second quarter of fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $29.0 million was recognized during the nine-month period ended December 31, 2016. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000866374-17-000002:notes:153]
[same as prior period, unchanged from 0000866374-16-000007:notes:134]

[0000866374-17-000002:notes:154]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 17,977 |  |
| 2018 | 66,810 |  |
| 2019 | 60,038 |  |
| 2020 | 51,054 |  |
| 2021 | 46,953 |  |
| Thereafter | 128,771 |  |
| Total amortization expense | $ | 371,603 |  |

[0000866374-17-000002:notes:155]
| (1) | Represents estimated amortization for the remaining three-month period ending March 31, 2017. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000866374-17-000002:notes:156]
[same as prior period, unchanged from 0000866374-16-000007:notes:137]

[0000866374-17-000002:notes:157]
[same as prior period, unchanged from 0000866374-16-000007:notes:138]

[0000866374-17-000002:notes:158]
[same as prior period, unchanged from 0000866374-16-000007:notes:139]

[0000866374-17-000002:notes:159]
| (2) | During the second quarter of fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $29.0 million was recognized during the nine-month period ended December 31, 2016. The Company expects to finalize the plan by the end of fiscal year 2017. |

[0000866374-17-000002:notes:160]
[same as prior period, unchanged from 0000866374-16-000007:notes:141]

[0000866374-17-000002:notes:161]
[same as prior period, unchanged from 0000866374-16-000007:notes:142]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000866374-17-000002:notes:162]
[same as prior period, unchanged from 0000866374-16-000007:notes:143]

[0000866374-17-000002:notes:163]
[same as prior period, unchanged from 0000866374-16-000007:notes:144]

[0000866374-17-000002:notes:164]
[same as prior period, unchanged from 0000866374-16-000007:notes:145]

[0000866374-17-000002:notes:165]
The gross carrying amounts of intangible assets are removed when fully amortized. During the nine-month period ended December 31, 2016, the total value of intangible assets increased primarily as a result of three acquisitions. The estimated future annual amortization expense for intangible assets is as follows:

[0000866374-17-000002:notes:166]
[same as prior period, unchanged from 0000866374-16-000007:notes:147]

[0000866374-17-000002:notes:167]
Other current assets include approximately $668.9 million and $501.1 million as of December 31, 2016 and March 31, 2016, respectively, for the deferred purchase price receivable from the Company's Global and North American Asset-Backed Securitization programs. See note 10 for additional information.

[0000866374-17-000002:notes:168]
Included in other current assets, as of March 31, 2016, was the remaining value of certain assets purchased on behalf of a customer and financed by a third party banking institution in the amount of $83.6 million, the nature of which is more fully discussed in Note 17, "Business and Asset Acquisitions" to the Company's Form 10-K for the year ended March 31, 2016. During the three-month period ended December 31, 2016, the Company entered into an agreement with the third party banking institution and the customer granted a waiver of any amounts owed under the financing arrangement which allowed for a net settlement of the related asset and liability.

[0000866374-17-000002:notes:169]
Other Assets

[0000866374-17-000002:notes:170]
During the third quarter of fiscal year 2017, the Company formed a joint venture with RIB Software AG, a provider of technology for the construction industry. This joint venture will offer a fully integrated enterprise software platform for building and housing projects. The Company contributed $60.0 million for a non-controlling interest in this joint venture, and the amount is included in other assets on the condensed consolidated balance sheet using the equity method of accounting. The equity in earnings related to this investment is immaterial to the Company's condensed consolidated statement of operations for the three-month and nine-month periods ended December 31, 2016, and is included in interest and other, net.

[0000866374-17-000002:notes:171]
[same as prior period, unchanged from 0000866374-16-000007:notes:150]

[0000866374-17-000002:notes:172]
Other current liabilities include customer working capital advances of $228.0 million and $253.7 million, customer-related accruals of $494.5 million and $479.5 million, and deferred revenue of $311.3 million and $332.3 million as of December 31, 2016 and March 31, 2016, respectively. The customer working capital advances are not interest-bearing, do not have fixed repayment dates and are generally reduced as the underlying working capital is consumed in production. As of March 31, 2016, other current liabilities also include the outstanding balance due to the third party banking institution related to the financed equipment discussed above of $122.0 million. As discussed above, during the three-month period ended December 31, 2016, the Company entered into an agreement with the third party banking institution and the customer granted a waiver of any amounts owed under the financing arrangement which provided for a net settlement of the outstanding balance of approximately $90.6 million with the related asset.


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000866374-17-000002:notes:173]
[same as prior period, unchanged from 0000866374-16-000007:notes:152]

[0000866374-17-000002:notes:174]
[same as prior period, unchanged from 0000866374-16-000007:notes:153]

[0000866374-17-000002:notes:175]
[same as prior period, unchanged from 0000866374-16-000007:notes:154]

[0000866374-17-000002:notes:176]
The Company continuously sells designated pools of trade receivables under its Global Asset-Backed Securitization Agreement (the “Global Program”) and its North American Asset-Backed Securitization Agreement (the “North American Program,” collectively, the “ABS Programs”) to affiliated special purpose entities, each of which in turn sells 100% of the receivables to unaffiliated financial institutions. These programs allow the operating subsidiaries to receive a cash payment and a deferred purchase price receivable for sold receivables. Following the transfer of the receivables to the special purpose entities, the transferred receivables are isolated from the Company and its affiliates, and upon the sale of the receivables from the special purpose entities to the unaffiliated financial institutions, effective control of the transferred receivables is passed to the unaffiliated financial institutions, which has the right to pledge or sell the receivables. Although the special purpose entities are consolidated by the Company, they are separate corporate entities and their assets are available first to satisfy the claims of their creditors. The investment limits set by the financial institutions are $850.0 million for the Global Program, of which $750.0 million is committed and $100.0 million is uncommitted, and $250.0 million for the North American Program, of which $210.0 million is committed and $40.0 million is uncommitted. Both programs require a minimum level of deferred purchase price receivable to be retained by the Company in connection with the sales.

[0000866374-17-000002:notes:177]
The Company services, administers and collects the receivables on behalf of the special purpose entities and receives a servicing fee of 0.1% to 0.5% of serviced receivables per annum. Servicing fees recognized during the three-month and nine-month periods ended December 31, 2016 and December 31, 2015 were not material and are included in interest and other, net within the condensed consolidated statements of operations. As the Company estimates the fee it receives in return for its obligation to service these receivables is at fair value, no servicing assets and liabilities are recognized.

[0000866374-17-000002:notes:178]
As of December 31, 2016, approximately $1.7 billion of accounts receivable had been sold to the special purpose entities under the ABS Programs for which the Company had received net cash proceeds of approximately $1.0 billion and deferred purchase price receivables of approximately $668.9 million. As of March 31, 2016, approximately $1.4 billion of accounts receivable had been sold to the special purpose entities for which the Company had received net cash proceeds of $880.8 million and deferred purchase price receivables of approximately $501.1 million. The portion of the purchase price for the receivables which is not paid by the unaffiliated financial institutions in cash is a deferred purchase price receivable, which is paid to the special purpose entity as payments on the receivables are collected from account debtors. The deferred purchase price receivable represents a beneficial interest in the transferred financial assets and is recognized at fair value as part of the sale transaction. The deferred purchase price receivables are included in other current assets as of December 31, 2016 and March 31, 2016, and were carried at the expected recovery amount of the related receivables. The difference between the carrying amount of the receivables sold under these programs and the sum of the cash and fair value of the deferred purchase price receivables received at time of transfer is recognized as a loss on sale of the related receivables and recorded in interest and other, net in the condensed consolidated statements of operations and were immaterial for all periods presented.

[0000866374-17-000002:notes:179]
As of December 31, 2016 and March 31, 2016, the accounts receivable balances that were sold under the ABS Programs were removed from the condensed consolidated balance sheets and the net cash proceeds received by the Company were included as cash provided by operating activities in the condensed consolidated statements of cash flows.

[0000866374-17-000002:notes:180]
For the nine-month periods ended December 31, 2016 and December 31, 2015, cash flows from sales of receivables under the ABS Programs consisted of approximately $4.2 billion and $3.9 billion, for transfers of receivables, respectively (of which approximately $315.1 million and $355.1 million, respectively, represented new transfers and the remainder proceeds from collections reinvested in revolving-period transfers).

[0000866374-17-000002:notes:181]
[same as prior period, unchanged from 0000866374-16-000007:notes:160]

[0000866374-17-000002:notes:182]
The Company also sold accounts receivables to certain third-party banking institutions. The outstanding balance of receivables sold and not yet collected was approximately $209.5 million and $339.1 million as of December 31, 2016 and March 31, 2016, respectively. For the nine-month periods ended December 31, 2016 and December 31, 2015, total accounts receivable sold to certain third party banking institutions was approximately $1.0 billion and $1.8 billion, respectively. The receivables that were sold were removed from the condensed consolidated balance sheets and the cash received is reflected as cash provided by operating activities in the condensed consolidated statements of cash flows.


## us-gaap:TreasuryStockTextBlock

[0000866374-17-000002:notes:183]
[same as prior period, unchanged from 0000866374-16-000007:notes:162]

[0000866374-17-000002:notes:184]
During the three-month and nine-month periods ended December 31, 2016, the Company repurchased 5.2 million shares at an aggregate purchase price of $75.0 million, and 19.5 million shares at an aggregate purchase price of $255.9 million, respectively, and retired all of these shares.

[0000866374-17-000002:notes:185]
Under the Company’s current share repurchase program, the Board of Directors authorized repurchases of its outstanding ordinary shares for up to $500 million in accordance with the share repurchase mandate approved by the Company’s shareholders at the date of the most recent Annual General Meeting held on August 24, 2016. As of December 31, 2016, shares in the aggregate amount of $375.2 million were available to be repurchased under the current plan.
