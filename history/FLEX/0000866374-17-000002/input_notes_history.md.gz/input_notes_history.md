# FLEX note change history — 0000866374-16-000007 → 0000866374-17-000002


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-01-27):
[0000866374-17-000002:note_history:1]
One of the Company's Brazilian subsidiaries has received several related assessments for certain sales and import taxes. The first two tax assessments were received in fiscal year 2014 and fiscal year 2016 relating to calendar year 2010 for an alleged total amount of 109 million Brazilian reals (approximately USD $34 million based on the exchange rate as of December 31, 2016). These two assessments are in various stages of the review process at the administrative level. During the third quarter of fiscal year 2017, the same Brazilian subsidiary received a third assessment related to calendar year 2011 taxes of an additional 181 million Brazilian reals (approximately USD $56 million based on the exchange rate as of December 31, 2016). The Company plans to continue to vigorously oppose all of these assessments, as well as any future assessments. The Company is unable to determine the likelihood of an unfavorable outcome of these assessments against its Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for these assessments or any future assessments that are reasonably possible. The Company does not expect final judicial determination on any of these claims for several years.
  (was, 2016-10-31, similarity 0.6779):
[0000866374-16-000007:note_history:1]
During the third quarter of fiscal year 2014, one of the Company's Brazilian subsidiaries received an assessment for certain sales and import taxes. The tax assessment notice was for nine months of calendar year 2010 for an alleged amount of 52 million Brazilian reals (approximately USD $16 million based on the exchange rate as of September 30, 2016) plus interest. This assessment is in the second stage of the review process at the administrative level. During the fourth quarter of fiscal year 2016, the same Brazilian subsidiary received a further assessment related to the same import taxes of an additional 57 million Brazilian reals (approximately USD $18 million based on the exchange rate as of September 30, 2016) plus interest. This assessment is in the first stage of the review process at the administrative level. The Company plans to continue to vigorously oppose both of these assessments, as well as any future assessments. The Company is unable to determine the likelihood of an unfavorable outcome of these assessments against our Brazilian subsidiary. While the Company believes there is no legal basis for the alleged liabilities, due to the complexities and uncertainty surrounding the administrative-review and judicial processes in Brazil and the nature of the claims, it is unable to reasonably estimate a range of loss for this assessment or any future assessments that are reasonably possible. The Company does not expect final judicial determination on either of these claims for several years.

- changed (2017-01-27):
[0000866374-17-000002:note_history:2]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during fiscal year 2017.
  (was, 2016-10-31, similarity 0.9803):
[0000866374-16-000007:note_history:2]
During fiscal year 2015, one of the Company's non-operating Brazilian subsidiaries received an assessment of approximately USD $100 million related to income and social contribution taxes, interest and penalties. During the first quarter of fiscal year 2017, the Company received a final favorable judgment in the judicial process reversing the assessment and the case is now closed. As the Company had previously determined there was no legal basis for the assessment, no adjustment was required to be recorded during the first quarter of fiscal year 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-01-27):
[0000866374-17-000002:note_history:3]
Flex Ltd., formerly Flextronics International Ltd., ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from Sketch-to-Scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of its medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes its mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.
  (was, 2016-10-31, similarity 0.9985):
[0000866374-16-000007:note_history:3]
Flex Ltd., formerly Flextronics International Ltd., ("Flex", or the "Company") was incorporated in the Republic of Singapore in May 1990. The Company's operations have expanded over the years through a combination of organic growth and acquisitions. The Company is a globally-recognized leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from sketch to scaletm; from conceptual sketch to full-scale production. The Company designs, builds, ships and services complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through its activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of its medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; automotive business, including vehicle electronics, connectivity, and clean technologies; and defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes its mobile devices business, including smart phones; consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions. The Company's strategy is to provide customers with a full range of cost competitive, vertically integrated global supply chain solutions through which the Company can design, build, ship and service a complete packaged product for its OEM customers. This enables the Company's OEM customers to leverage the Company's supply chain solutions to meet their product requirements throughout the entire product life cycle.

- changed (2017-01-27):
[0000866374-17-000002:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and nine-month periods ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.
  (was, 2016-10-31, similarity 0.9928):
[0000866374-16-000007:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or “GAAP”) for interim financial information and in accordance with the requirements of Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and footnotes required by U.S. GAAP for complete financial statements, and should be read in conjunction with the Company’s audited consolidated financial statements as of and for the fiscal year ended March 31, 2016 contained in the Company’s Annual Report on Form 10-K. In the opinion of management, all adjustments (consisting only of normal recurring adjustments) considered necessary for a fair presentation have been included. Operating results for the three-month and six-month periods ended September 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017.

- changed (2017-01-27):
[0000866374-17-000002:note_history:5]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second quarters for fiscal year 2017 and fiscal year 2016 ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively. The Company's third quarters end on December 31 of each year, which are comprised of 92 days and 97 days for fiscal years 2017 and 2016, respectively.
  (was, 2016-10-31, similarity 0.8303):
[0000866374-16-000007:note_history:5]
The first quarters for fiscal year 2017 and fiscal year 2016 ended on July 1, 2016, which is comprised of 92 days in the period, and June 26, 2015, which is comprised of 87 days in the period, respectively. The second quarters for fiscal year 2017 and fiscal year 2016 ended on September 30, 2016 and September 25, 2015, which are comprised of 91 days in both periods, respectively.

- changed (2017-01-27):
[0000866374-17-000002:note_history:6]
Recently Issued Accounting Pronouncements
  (was, 2016-10-31, similarity 0.9877):
[0000866374-16-000007:note_history:6]
Recently Issued Accounting Pronouncement

- added (2017-01-27):
[0000866374-17-000002:note_history:7]
In January 2017, the FASB issued new guidance that changes the definition of a business to assist entities with evaluating when a set of transferred assets and activities is a business. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early application permitted. The guidance may result in more asset acquisitions being accounted for as purchases of assets in lieu of business combinations. The Company intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2019.

- added (2017-01-27):
[0000866374-17-000002:note_history:8]
In October 2016, the FASB issued new guidance to amend the consolidation guidance on how a reporting entity that is the single decision maker of a variable interest entity ("VIE") should treat indirect interests in the entity held through related parties that are under common control with the reporting entity when determining whether it is the primary beneficiary of that VIE. This guidance is effective for the Company beginning in the first quarter of fiscal year 2018, with early adoption permitted. The Company expects the new guidance will have an immaterial impact on its consolidated financial statements, and it intends to adopt the guidance when it becomes effective in the first quarter of fiscal year 2018.

- added (2017-01-27):
[0000866374-17-000002:note_history:9]
In October 2016, the FASB issued new guidance intended to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory. This guidance is effective for the Company beginning in the first quarter of fiscal year 2019, with early adoption permitted in the first interim period of fiscal year 2018. The Company intends to early adopt the new guidance starting in the first quarter of fiscal year 2018, with an expected immaterial impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-01-27):
[0000866374-17-000002:note_history:10]
BANK BORROWINGS AND LONG TERM DEBT

- added (2017-01-27):
[0000866374-17-000002:note_history:11]
Bank borrowings and long-term debt are as follows:

- added (2017-01-27):
[0000866374-17-000002:note_history:12]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 525,000 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 595,879 |  |  | 595,589 |  |
| Other | 62,448 |  |  | 71,317 |  |
| Debt issuance costs | (16,487 | ) |  | (17,351 | ) |
| Total | $ | 2,866,840 |  |  | $ | 2,774,555 |  |

- added (2017-01-27):
[0000866374-17-000002:note_history:13]
The weighted-average interest rates for the Company’s long-term debt were 3.5% as of December 31, 2016 and March 31, 2016.

- added (2017-01-27):
[0000866374-17-000002:note_history:14]
On August 30, 2013, the Company entered into a $600 million term loan agreement due August 30, 2018. On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan, thereby increasing the total amount under the term loan to $700 million. This loan is repayable in quarterly installments of $4.1 million, which will commence October 31, 2017 and continue through September 30, 2021, with the remaining amount due at maturity.

- added (2017-01-27):
[0000866374-17-000002:note_history:15]
Borrowings under this term loan bear interest, at the Company's option, either at (i) LIBOR plus the applicable margin for LIBOR loans ranging between 1.125% and 2.125%, based on the Company's credit ratings or (ii) the base rate (the greatest of the prime rate in effect on each day as published in The Wall Street Journal, the federal funds rate plus 0.5% and LIBOR for a one-month interest period plus 1.00%) plus an applicable margin ranging between 0.125% and 1.125%, based on the Company's credit rating.

- added (2017-01-27):
[0000866374-17-000002:note_history:16]
This term loan is unsecured, and contains customary restrictions on the Company's and its subsidiaries' ability to (i) incur certain debt, (ii) make certain investments, (iii) make certain acquisitions of other entities, (iv) incur liens, (v) dispose of assets, (vi) make non-cash distributions to shareholders, and (vii) engage in transactions with affiliates. These covenants are subject to a number of exceptions and limitations. This term loan agreement also requires that the Company maintain a maximum ratio of total indebtedness to EBITDA (earnings before interest expense, taxes, depreciation and amortization), and a minimum interest coverage ratio, as defined therein, during its term; provided that the requirement to maintain the minimum interest coverage ratio may be suspended in certain circumstances. As of December 31, 2016, the Company was in compliance with the covenants under this term loan agreement.

- added (2017-01-27):
[0000866374-17-000002:note_history:17]
Repayment of the Company’s long term debt outstanding as of December 31, 2016 is as follows:

- added (2017-01-27):
[0000866374-17-000002:note_history:18]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 11,579 |  |
| 2018 | 58,504 |  |
| 2019 | 486,317 |  |
| 2020 | 517,567 |  |
| 2021 | 64,648 |  |
| Thereafter | 1,744,712 |  |
| Total | $ | 2,883,327 |  |

- added (2017-01-27):
[0000866374-17-000002:note_history:19]
_________________________________________________________

- added (2017-01-27):
[0000866374-17-000002:note_history:20]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2017. |

- added (2017-01-27):
[0000866374-17-000002:note_history:21]
On January 23, 2017, the Company entered into a €100 million (approximately $105.4 million as of December 31, 2016), 5-year, unsecured, term-loan agreement due January 2, 2022.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-01-27):
[0000866374-17-000002:note_history:22]
|  | As of December 31, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | 525,000 |  |  | 524,675 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 525,740 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through November 2021 (1) | 700,000 |  |  | 696,941 |  |  | 577,500 |  |  | 573,533 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 532,810 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,879 |  |  | 639,288 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,820,879 |  |  | $ | 2,919,454 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |
  (was, 2016-10-31, similarity 0.7686):
[0000866374-16-000007:note_history:22]
|  | As of September 30, 2016 |  | As of March 31, 2016 |  |  |
|  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  | Fair Value Hierarchy |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through August 2018 | $ | 570,000 |  |  | $ | 568,222 |  |  | $ | 577,500 |  |  | $ | 573,533 |  |  | Level 1 |
| Term Loan, including current portion, due in installments through March 2019 | 525,000 |  |  | 520,406 |  |  | 547,500 |  |  | 542,709 |  |  | Level 1 |
| 4.625% Notes due February 2020 | 500,000 |  |  | 536,250 |  |  | 500,000 |  |  | 524,735 |  |  | Level 1 |
| 5.000% Notes due February 2023 | 500,000 |  |  | 550,000 |  |  | 500,000 |  |  | 507,500 |  |  | Level 1 |
| 4.750% Notes due June 2025 | 595,782 |  |  | 639,000 |  |  | 595,589 |  |  | 604,926 |  |  | Level 1 |
| Total | $ | 2,690,782 |  |  | $ | 2,813,878 |  |  | $ | 2,720,589 |  |  | $ | 2,753,403 |  |  |  |

- added (2017-01-27):
[0000866374-17-000002:note_history:23]
(1)    On November 30, 2016, the Company entered into a new arrangement to extend the maturity date of the agreement from August 30, 2018 to November 30, 2021. Refer to note 5 for further details of the arrangement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-01-27):
[0000866374-17-000002:note_history:24]
Bank borrowings and long-term debt are as follows:

- added (2017-01-27):
[0000866374-17-000002:note_history:25]
|  | As of December 31, 2016 |  | As of March 31, 2016 |
|  | (In thousands) |
| Term Loan, including current portion, due in installments through March 2019 | $ | 525,000 |  |  | $ | 547,500 |  |
| 4.625% Notes due February 2020 | 500,000 |  |  | 500,000 |  |
| Term Loan, including current portion, due in installments through November 2021 | 700,000 |  |  | 577,500 |  |
| 5.000% Notes due February 2023 | 500,000 |  |  | 500,000 |  |
| 4.75% Notes due June 2025 | 595,879 |  |  | 595,589 |  |
| Other | 62,448 |  |  | 71,317 |  |
| Debt issuance costs | (16,487 | ) |  | (17,351 | ) |
| Total | $ | 2,866,840 |  |  | $ | 2,774,555 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-01-27):
[0000866374-17-000002:note_history:26]
Repayment of the Company’s long term debt outstanding as of December 31, 2016 is as follows:

- added (2017-01-27):
[0000866374-17-000002:note_history:27]
| Fiscal Year Ending March 31, | Amount |
|  | (In thousands) |
| 2017 (1) | $ | 11,579 |  |
| 2018 | 58,504 |  |
| 2019 | 486,317 |  |
| 2020 | 517,567 |  |
| 2021 | 64,648 |  |
| Thereafter | 1,744,712 |  |
| Total | $ | 2,883,327 |  |

- added (2017-01-27):
[0000866374-17-000002:note_history:28]
_________________________________________________________

- added (2017-01-27):
[0000866374-17-000002:note_history:29]
| (1) | Represents scheduled repayment for the remaining three-month period ending March 31, 2017. |
