# FLEX MD&A — 0000866374-17-000002


## mdna

[0000866374-17-000002:mdna:1]
[same as prior period, unchanged from 0000866374-16-000007:mdna:1]

[0000866374-17-000002:mdna:2]
[same as prior period, unchanged from 0000866374-16-000007:mdna:2]

[0000866374-17-000002:mdna:3]
[same as prior period, unchanged from 0000866374-16-000007:mdna:3]

[0000866374-17-000002:mdna:4]
We are a globally-recognized, leading provider of innovative design, engineering, manufacturing, and supply chain services and solutions that span from Sketch-to-Scaletm; from conceptual sketch to full-scale production. We design, build, ship and service complete packaged consumer electronics and industrial products for original equipment manufacturers ("OEMs"), through our activities in the following segments: High Reliability Solutions ("HRS"), which is comprised of our medical business including consumer health, digital health, disposables, drug delivery, diagnostics, life sciences and imaging equipment; our automotive business, including vehicle electronics, connectivity, and clean technologies; and our defense and aerospace businesses, focused on commercial aviation, defense and military; Consumer Technologies Group ("CTG"), which includes our mobile devices business, including smart phones; our consumer electronics business, including connected living, wearable electronics including digital sport, game consoles, and connectivity devices; and our high-volume computing business, including various supply chain solutions for notebook personal computers ("PC"), tablets, and printers; in addition, our CTG group is expanding its business relationships to include supply chain optimization for non-electronics products such as shoes and clothing; Industrial and Emerging Industries ("IEI"), which is comprised of semiconductor and capital equipment, office solutions, household industrial and lifestyle, industrial automation and kiosks, energy and metering, and lighting; and Communications & Enterprise Compute ("CEC"), which includes radio access base stations, remote radio heads, and small cells for wireless infrastructure; optical, routing, broadcasting, and switching products for the data and video networks; server and storage platforms for both enterprise and cloud-based deployments; next generation storage and security appliance products; and rack level solutions, converged infrastructure and software-defined product solutions.

[0000866374-17-000002:mdna:5]
[same as prior period, unchanged from 0000866374-16-000007:mdna:5]

[0000866374-17-000002:mdna:6]
[same as prior period, unchanged from 0000866374-16-000007:mdna:6]

[0000866374-17-000002:mdna:7]
[same as prior period, unchanged from 0000866374-16-000007:mdna:7]

[0000866374-17-000002:mdna:8]
[same as prior period, unchanged from 0000866374-16-000007:mdna:16]

[0000866374-17-000002:mdna:9]
[same as prior period, unchanged from 0000866374-16-000007:mdna:8]

[0000866374-17-000002:mdna:10]
[same as prior period, unchanged from 0000866374-16-000007:mdna:9]

[0000866374-17-000002:mdna:11]
We are one of the world's largest providers of global supply chain solutions, with revenues of $18.0 billion for the nine-month period ended December 31, 2016 and $24.4 billion in fiscal year 2016. The following tables set forth the relative percentages and dollar amounts of net sales and net property and equipment, by country, based on the location of our manufacturing sites:

[0000866374-17-000002:mdna:12]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Net sales: |  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  |  | (In thousands) |
| China |  | $ | 1,822,644 |  |  | 30 | % |  | $ | 2,466,098 |  |  | 37 | % |  | $ | 5,622,560 |  |  | 31 | % |  | $ | 6,642,761 |  |  | 35 | % |
| Mexico |  | 1,129,320 |  |  | 17 | % |  | 945,360 |  |  | 14 | % |  | 2,997,522 |  |  | 17 | % |  | 2,795,863 |  |  | 15 | % |
| U.S. |  | 589,031 |  |  | 10 | % |  | 874,197 |  |  | 13 | % |  | 2,006,299 |  |  | 11 | % |  | 2,144,543 |  |  | 12 | % |
| Malaysia |  | 585,356 |  |  | 10 | % |  | 492,723 |  |  | 7 | % |  | 1,698,105 |  |  | 10 | % |  | 1,605,012 |  |  | 9 | % |
| Brazil |  | 536,333 |  |  | 9 | % |  | 477,577 |  |  | 7 | % |  | 1,325,964 |  |  | 7 | % |  | 1,460,404 |  |  | 8 | % |
| Other |  | 1,452,315 |  |  | 24 | % |  | 1,507,222 |  |  | 22 | % |  | 4,349,887 |  |  | 24 | % |  | 3,997,604 |  |  | 21 | % |
|  |  | $ | 6,114,999 |  |  |  |  |  | $ | 6,763,177 |  |  |  |  |  | $ | 18,000,337 |  |  |  |  |  | $ | 18,646,187 |  |  |  |  |

[0000866374-17-000002:mdna:13]
|  |  | As of |  | As of |
| Property and equipment, net: |  | December 31, 2016 |  | March 31, 2016 |
|  |  | (In thousands) |
| China |  | $ | 763,950 |  |  | 33 | % |  | $ | 789,571 |  |  | 35 | % |
| Mexico |  | 485,744 |  |  | 21 | % |  | 429,989 |  |  | 19 | % |
| U.S. |  | 301,597 |  |  | 13 | % |  | 330,778 |  |  | 15 | % |
| Malaysia |  | 182,150 |  |  | 8 | % |  | 159,787 |  |  | 7 | % |
| Hungary |  | 125,281 |  |  | 5 | % |  | 107,492 |  |  | 5 | % |
| Other |  | 462,814 |  |  | 20 | % |  | 425,559 |  |  | 19 | % |
|  |  | $ | 2,321,536 |  |  |  |  |  | $ | 2,257,633 |  |  |  |  |

[0000866374-17-000002:mdna:14]
[same as prior period, unchanged from 0000866374-16-000007:mdna:13]

[0000866374-17-000002:mdna:15]
[same as prior period, unchanged from 0000866374-16-000007:mdna:14]

[0000866374-17-000002:mdna:16]
[same as prior period, unchanged from 0000866374-16-000007:mdna:15]

[0000866374-17-000002:mdna:17]
[same as prior period, unchanged from 0000866374-16-000007:mdna:33]

[0000866374-17-000002:mdna:18]
[same as prior period, unchanged from 0000866374-16-000007:mdna:17]

[0000866374-17-000002:mdna:19]
[same as prior period, unchanged from 0000866374-16-000007:mdna:18]

[0000866374-17-000002:mdna:20]
[same as prior period, unchanged from 0000866374-16-000007:mdna:19]

[0000866374-17-000002:mdna:21]
[same as prior period, unchanged from 0000866374-16-000007:mdna:20]

[0000866374-17-000002:mdna:22]
[same as prior period, unchanged from 0000866374-16-000007:mdna:21]

[0000866374-17-000002:mdna:23]
[same as prior period, unchanged from 0000866374-16-000007:mdna:22]

[0000866374-17-000002:mdna:24]
[same as prior period, unchanged from 0000866374-16-000007:mdna:23]

[0000866374-17-000002:mdna:25]
[same as prior period, unchanged from 0000866374-16-000007:mdna:24]

[0000866374-17-000002:mdna:26]
| • | increased labor costs due to adverse labor conditions in the markets we operate; |

[0000866374-17-000002:mdna:27]
| • | changes in tax legislation; and |

[0000866374-17-000002:mdna:28]
| • | changes in trade regulations and treaties. |

[0000866374-17-000002:mdna:29]
[same as prior period, unchanged from 0000866374-16-000007:mdna:27]

[0000866374-17-000002:mdna:30]
[same as prior period, unchanged from 0000866374-16-000007:mdna:28]

[0000866374-17-000002:mdna:31]
[same as prior period, unchanged from 0000866374-16-000007:mdna:29]

[0000866374-17-000002:mdna:32]
[same as prior period, unchanged from 0000866374-16-000007:mdna:30]

[0000866374-17-000002:mdna:33]
[same as prior period, unchanged from 0000866374-16-000007:mdna:31]

[0000866374-17-000002:mdna:34]
[same as prior period, unchanged from 0000866374-16-000007:mdna:43]

[0000866374-17-000002:mdna:35]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 93.2 |  |  | 93.3 |  |  | 93.7 |  |  | 93.6 |  |
| Gross profit | 6.8 |  |  | 6.7 |  |  | 6.3 |  |  | 6.4 |  |
| Selling, general and administrative expenses | 3.8 |  |  | 3.6 |  |  | 4.0 |  |  | 3.6 |  |
| Intangible amortization | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.2 |  |
| Interest and other, net | 0.4 |  |  | 0.3 |  |  | 0.4 |  |  | 0.3 |  |
| Other charges, net | 0.1 |  |  | 0.7 |  |  | 0.1 |  |  | 0.2 |  |
| Income before income taxes | 2.2 |  |  | 1.8 |  |  | 1.5 |  |  | 2.1 |  |
| Provision for (benefit from) income taxes | 0.2 |  |  | (0.3 | ) |  | 0.2 |  |  | 0.0 |  |
| Net income | 2.0 | % |  | 2.1 | % |  | 1.3 | % |  | 2.1 | % |

[0000866374-17-000002:mdna:36]
[same as prior period, unchanged from 0000866374-16-000007:mdna:34]

[0000866374-17-000002:mdna:37]
[same as prior period, unchanged from 0000866374-16-000007:mdna:35]

[0000866374-17-000002:mdna:38]
|  |  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
| Segments: |  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  |  | (In thousands) |
| Communications & Enterprise Compute |  | $ | 2,102,321 |  |  | 34 | % |  | $ | 2,469,099 |  |  | 37 | % |  | $ | 6,400,233 |  |  | 36 | % |  | $ | 6,640,626 |  |  | 36 | % |
| Consumer Technologies Group |  | 1,848,970 |  |  | 30 | % |  | 2,057,850 |  |  | 30 | % |  | 4,827,488 |  |  | 27 | % |  | 5,633,903 |  |  | 30 | % |
| Industrial & Emerging Industries |  | 1,140,366 |  |  | 19 | % |  | 1,214,225 |  |  | 18 | % |  | 3,672,103 |  |  | 20 | % |  | 3,490,205 |  |  | 19 | % |
| High Reliability Solutions |  | 1,023,342 |  |  | 17 | % |  | 1,022,003 |  |  | 15 | % |  | 3,100,513 |  |  | 17 | % |  | 2,881,453 |  |  | 15 | % |
|  |  | $ | 6,114,999 |  |  |  |  |  | $ | 6,763,177 |  |  |  |  |  | $ | 18,000,337 |  |  |  |  |  | $ | 18,646,187 |  |  |  |  |

[0000866374-17-000002:mdna:39]
Net sales during the three-month period ended December 31, 2016 totaled $6.1 billion, representing a decrease of approximately $0.6 billion, or 9.6% from $6.8 billion during the three-month period ended December 31, 2015. The overall decline in sales was driven by decreases in three of our segments while our HRS segment remained constant. The decline in our CEC segment of $366.8 million, is largely attributable to lower sales within our networking business as well as within our legacy server and storage business. Our CTG segment declined $208.9 million, primarily because of a decline in demand from our largest smartphone customer Lenovo/Motorola in connection with our exit of a China operation dedicated to them, partially offset by revenues from our Bose acquisition. Lastly, our IEI segment declined $73.9 million, primarily driven by push-outs and delays on multiple large scale energy projects within our solar tracking business. Net sales decreased $484.9 million to $2.8 billion in Asia, and $122.0 million to $1.1 billion in Europe, while remaining relatively consistent in the Americas at $2.3 billion.

[0000866374-17-000002:mdna:40]
Net sales during the nine-month period ended December 31, 2016 totaled $18.0 billion, representing a decrease of approximately $0.6 billion, or 3.5% from $18.6 billion during the nine-month period ended December 31, 2015. The decline in sales was driven by an $806.4 million decrease in our CTG segment and a $240.4 million decrease in our CEC segment, attributable to the same factors described above. These were offset by slight increases within our HRS segment, driven by our auto and medical businesses, and within our IEI segment driven by contribution from our NEXTracker Inc. ("NEXTracker") acquisition and expansion within our capital equipment business. Net sales decreased $675.0 million to $8.4 billion in Asia, and $62.8 million to $6.3 billion in Americas, while increasing $92.0 million to $3.2 billion in Europe.

[0000866374-17-000002:mdna:41]
Our ten largest customers, during the three and nine-month periods ended December 31, 2016, accounted for approximately 46% and 43% of net sales, respectively. No customer accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2016.

[0000866374-17-000002:mdna:42]
[same as prior period, unchanged from 0000866374-16-000007:mdna:51]

[0000866374-17-000002:mdna:43]
Our ten largest customers, during the three and nine-month periods ended December 31, 2015, accounted for approximately 46% of net sales, respectively. Lenovo/Motorola accounted for more than 10% of net sales during the three and nine-month periods ended December 31, 2015.

[0000866374-17-000002:mdna:44]
[same as prior period, unchanged from 0000866374-16-000007:mdna:41]

[0000866374-17-000002:mdna:45]
Gross profit is affected by a number of factors, including the number and size of new manufacturing programs, product mix, component costs and availability, product life cycles, unit volumes, pricing, competition, new product introductions, capacity utilization and the expansion or consolidation of manufacturing facilities. The flexible design of our manufacturing processes allows us to build a broad range of products in our facilities and better utilize our manufacturing capacity. In the cases of new programs, profitability normally lags revenue growth due to product start-up costs, lower manufacturing program volumes in the start-up phase, operational inefficiencies, and under-absorbed overhead. Gross margin for these programs often improves over time as manufacturing volumes increase, as our utilization rates and overhead absorption improve, and as we increase the level of manufacturing services content. As a result of these various factors, our gross margin varies from period to period.

[0000866374-17-000002:mdna:46]
Gross profit during the three-month period ended December 31, 2016 decreased $36.0 million to $416.5 million, or 6.8% of net sales, from $452.5 million, or 6.7% of net sales, during the three-month period ended December 31, 2015. Gross profit declined primarily because of the drop in revenue coupled with higher severance costs as we rationalize the current footprint at existing sites, and continue to shift the talent base in support of our Sketch-to-Scaletm initiatives in fiscal year 2017. During the nine-month period ended December 31, 2016 we recognized $29.0 million of severance costs of which $21.8 million is included in cost of sales and $7.2 million is included in SG&A. These were partially offset by a greater concentration of higher-margin business and greater levels of innovation and engineering led engagements, as part our Sketch-to-Scaletm strategy.

[0000866374-17-000002:mdna:47]
Gross profit during the nine-month period ended December 31, 2016 decreased $65.6 million to $1.1 billion, or 6.3% of net sales from $1.2 billion, or 6.4% of net sales, during the nine-month period ended December 31, 2015. The decline is largely attributable to the $92.9 million, or 50 basis points of charges recognized related to the significant decline in prices for solar modules and the slowdown in demand. This negative impact was partially offset by a favorable business mix due to a greater concentration of our higher margin HRS business coupled with improved operational efficiencies and improved customer mix in our CTG segment.

[0000866374-17-000002:mdna:48]
Gross margins improved 10 basis points and deteriorated 10 basis points in the three-month and nine-month periods ended December 31, 2016, respectively, compared to that of the three-month and nine-month periods ended December 31, 2015, as a result of the various factors described above.

[0000866374-17-000002:mdna:49]
[same as prior period, unchanged from 0000866374-16-000007:mdna:46]

[0000866374-17-000002:mdna:50]
[same as prior period, unchanged from 0000866374-16-000007:mdna:47]

[0000866374-17-000002:mdna:51]
[same as prior period, unchanged from 0000866374-16-000007:mdna:48]

[0000866374-17-000002:mdna:52]
|  | Three-Month Periods Ended |  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Segment income & margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Communications & Enterprise Compute | $ | 62,109 |  |  | 3.0 | % |  | $ | 75,578 |  |  | 3.1 | % |  | $ | 176,460 |  |  | 2.8 | % |  | $ | 198,400 |  |  | 3.0 | % |
| Consumer Technologies Group | 59,282 |  |  | 3.2 | % |  | 49,032 |  |  | 2.4 | % |  | 139,230 |  |  | 2.9 | % |  | 129,045 |  |  | 2.3 | % |
| Industrial & Emerging Industries | 39,681 |  |  | 3.5 | % |  | 49,230 |  |  | 4.1 | % |  | 127,020 |  |  | 3.5 | % |  | 110,498 |  |  | 3.2 | % |
| High Reliability Solutions | 82,729 |  |  | 8.1 | % |  | 82,806 |  |  | 8.1 | % |  | 249,972 |  |  | 8.1 | % |  | 213,890 |  |  | 7.4 | % |
| Corporate and Other | (20,695 | ) |  |  |  | (20,563 | ) |  |  |  | (82,395 | ) |  |  |  | (60,348 | ) |  |  |
| Total segment income | 223,106 |  |  | 3.6 | % |  | 236,083 |  |  | 3.5 | % |  | 610,287 |  |  | 3.4 | % |  | 591,485 |  |  | 3.2 | % |
| Reconciling items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible amortization | 18,734 |  |  |  |  | 19,319 |  |  |  |  | 62,318 |  |  |  |  | 43,117 |  |  |  |
| Stock-based compensation | 20,781 |  |  |  |  | 24,233 |  |  |  |  | 67,311 |  |  |  |  | 56,559 |  |  |  |
| Inventory impairment and other (1) | — |  |  |  |  | — |  |  |  |  | 92,915 |  |  |  |  | — |  |  |  |
| Restructuring (2) | 17,421 |  |  |  |  | — |  |  |  |  | 28,960 |  |  |  |  | — |  |  |  |
| Other charges, net | 3,090 |  |  |  |  | 44,415 |  |  |  |  | 15,007 |  |  |  |  | 46,257 |  |  |  |
| Interest and other, net | 22,838 |  |  |  |  | 21,566 |  |  |  |  | 71,869 |  |  |  |  | 60,106 |  |  |  |
| Income before income taxes | $ | 140,242 |  |  |  |  | $ | 126,550 |  |  |  |  | $ | 271,907 |  |  |  |  | $ | 385,446 |  |  |  |

[0000866374-17-000002:mdna:53]
| (1) | During the fourth quarter of fiscal year 2016, the Company accepted the return of previously shipped inventory from a former customer, SunEdison, Inc. ("SunEdison"), of approximately $90 million. On April 21, 2016, SunEdison filed a petition for reorganization under bankruptcy law, and as a result, the Company recognized a bad debt reserve of $61.0 million as of March 31, 2016, associated with its outstanding SunEdison receivables. |

[0000866374-17-000002:mdna:54]
During the second quarter of fiscal year 2017, prices for solar panel modules declined significantly. The Company determined that certain solar panel inventory on hand at the end of the second quarter of fiscal year 2017 was not fully recoverable and recorded a charge of $60.0 million to reduce the carrying costs to market in the nine-month period ended December 31, 2016. The Company also recognized a $16.0 million impairment charge for solar module equipment and $16.9 million primarily related to negative margin sales and other associated solar panel direct costs incurred during the same period. The total charge of $92.9 million is included in cost of sales for the nine-month period ended December 31, 2016 but is excluded from segment results above.

[0000866374-17-000002:mdna:55]
| (2) | During the second quarter of fiscal year 2017, the Company initiated a plan to rationalize the current footprint at existing sites including corporate SG&A functions and to continue to shift the talent base in support of its Sketch-to-Scaletm initiatives. As part of this plan, approximately $29.0 million was recognized during the nine-month period ended December 31, 2016. The Company expects to finalize the plan by the end of fiscal year 2017. |

[0000866374-17-000002:mdna:56]
CEC segment margin decreased 10 basis points, to 3.0% for the three-month period ended December 31, 2016, from 3.1% during the three-month period ended December 31, 2015 due to lower capacity utilization causing reduced overhead absorption. CEC segment margin decreased 20 basis points, to 2.8% for the nine-month period ended December 31, 2016, from 3.0% during the nine-month period ended December 31, 2015 as a result of lower capacity utilization causing reduced overhead absorption, coupled with incremental costs for proactive repositioning certain programs and actions to better align CEC's operating structure.

[0000866374-17-000002:mdna:57]
CTG segment margin increased 80 and 60 basis points, to 3.2% and 2.9%, respectively, for the three-month and nine-month periods ended December 31, 2016, from 2.4% and 2.3%, during the three-month and nine-month periods ended December 31, 2015, respectively. The increase is primarily driven by portfolio shift within the CTG product mix with a greater concentration of higher margin consumer products where we provide greater levels of design and engineering value-added content, as well as exiting of lower margin businesses.

[0000866374-17-000002:mdna:58]
IEI segment margin decreased 60 basis points, to 3.5% for the three-month period ended December 31, 2016, from 4.1% during the three-month period ended December 31, 2015 primarily as a result of a decline in revenue due to push-outs and delays on multiple large scale energy projects within our solar tracking business. IEI segment margin increased 30 basis points,

[0000866374-17-000002:mdna:59]
40

[0000866374-17-000002:mdna:60]
to 3.5% for the nine-month period ended December 31, 2016, from 3.2% during the nine-month period ended December 31, 2015 due to contribution from our NEXTracker acquisition, partially offset by underperformance primarily driven by our formerly largest IEI customer, SunEdison, declaring bankruptcy in April 2016.

[0000866374-17-000002:mdna:61]
HRS segment margin increased 70 basis points, to 8.1% for the nine-month period ended December 31, 2016, from 7.4% during the nine-month period ended December 31, 2015. These improvements are primarily the result of new program launches and richer mix with greater value-added business engagements as a result of greater design and engineering solutions as part of our Sketch-to-Scaletm offering in our core HRS business, and contribution from our MCi acquisition since the second quarter of fiscal year 2016. HRS segment margin remained constant at 8.1% for the three-month periods ended December 31, 2016 and December 31, 2015, respectively.

[0000866374-17-000002:mdna:62]
[same as prior period, unchanged from 0000866374-16-000007:mdna:58]

[0000866374-17-000002:mdna:63]
Selling, general and administrative expenses (“SG&A”) was $231.6 million, or 3.8% of net sales, during the three-month period ended December 31, 2016, decreasing $9.1 million from $240.6 million, or 3.6% of net sales, during the three-month period ended December 31, 2015, primarily due to decreases in stock-based compensation expense.

[0000866374-17-000002:mdna:64]
SG&A was $715.0 million, or 4.0% of net sales, during the nine-month period ended December 31, 2016, increasing $48.2 million from $666.8 million, or 3.6% of net sales, during the nine-month period ended December 31, 2015. The increase in SG&A in dollars and as a percentage of net sales was primarily due to increases in stock-based compensation expense, incremental costs associated with our acquisition of NEXTracker which drives a higher proportional SG&A level and further investments in design and engineering resources by the Company, to support our increased Sketch-to-Scaletm initiatives, and to a lesser extent the charges described below.

[0000866374-17-000002:mdna:65]
During the second quarter of fiscal year 2017, the Company initiated a plan to accelerate its ability to support more Sketch-to-Scaletm efforts across the Company and reposition away from historical legacy programs and structures through rationalizing its current footprint at existing sites and at corporate SG&A functions. The Company estimates that costs associated with its plan will range from $40 million to $50 million in fiscal year 2017, including approximately $29.0 million recognized in the nine-month period ended December 31, 2016. The Company expects to finalize the plan by the end of fiscal year 2017.

[0000866374-17-000002:mdna:66]
[same as prior period, unchanged from 0000866374-16-000007:mdna:61]

[0000866374-17-000002:mdna:67]
Amortization of intangible assets decreased by $0.6 million during the three-month period ended December 31, 2016 to $18.7 million from $19.3 million for the three-month period ended December 31, 2015.

[0000866374-17-000002:mdna:68]
Amortization of intangible assets increased by $19.2 million during the nine-month period ended December 31, 2016 to $62.3 million from $43.1 million during the nine-month period ended December 31, 2015. The increase is primarily due to incremental amortization expense on intangible assets relating to our acquisitions completed in the second half of fiscal year 2016.

[0000866374-17-000002:mdna:69]
[same as prior period, unchanged from 0000866374-16-000007:mdna:63]

[0000866374-17-000002:mdna:70]
Interest and other, net was $22.8 million during the three-month period ended December 31, 2016 compared to $21.6 million during the three-month period ended December 31, 2015. The increase in interest and other, net of $1.3 million primarily reflects a modest impact from increased interest rates.

[0000866374-17-000002:mdna:71]
Interest and other, net was $71.9 million during the nine-month period ended December 31, 2016 compared to $60.1 million during the nine-month period ended December 31, 2015. The increase in interest and other, net of $11.8 million was primarily as a result of $8.5 million of incremental interest expense mainly from the 4.750% Notes due June 15, 2025 issued during the first quarter of fiscal year 2016, as well as the decline in foreign currency gains recognized, offset by $8.0 million of non-recurring acquisition-related costs incurred during the nine-month period ended December 31, 2015.

[0000866374-17-000002:mdna:72]
Other Charges, net

[0000866374-17-000002:mdna:73]
Other Charges, net was $44.4 million and $46.3 million during the three-month and nine-month periods ended December 31, 2015, respectively, primarily due to a $26.8 million loss on disposition of a non-strategic Western European manufacturing facility which included a non-cash foreign currency translation loss of $25.3 million, and $21.8 million from the impairment of a non-core investment. These were offset by foreign currency translation gains of $4.2 million during the three-month and nine-month periods ended December 31, 2015.

[0000866374-17-000002:mdna:74]
[same as prior period, unchanged from 0000866374-16-000007:mdna:66]

[0000866374-17-000002:mdna:75]
[same as prior period, unchanged from 0000866374-16-000007:mdna:67]

[0000866374-17-000002:mdna:76]
[same as prior period, unchanged from 0000866374-16-000007:mdna:68]

[0000866374-17-000002:mdna:77]
The consolidated effective tax rate was 7.7% and 14.4% for the three-month and nine-month periods ended December 31, 2016, respectively, and (17.7)% and 0.7% for the three-month and nine-month periods ended December 31, 2015, respectively. The effective rate varies from the Singapore statutory rate of 17.0% as a result of recognition of earnings in different jurisdictions (we generate most of our revenues and profits from operations outside of Singapore), operating loss carryforwards, income tax credits, release of previously established valuation allowances for deferred tax assets, liabilities for uncertain tax positions, as well as the effect of certain tax holidays and incentives granted to our subsidiaries primarily in China, Malaysia and Israel. Notably, during the three-month period ended December 31, 2016, the Company had a net reduction in liabilities for uncertain tax positions of $12.2 million which was primarily driven by lapse of statutes of limitations. The effective tax rates for the three and nine-month periods ended December 31, 2015 are significantly lower than the effective tax rates for the three and nine-month periods ended December 31, 2016 primarily due to a $39.3 million release of a previous established valuation allowance position as a result of recording deferred tax liabilities in purchase accounting for the NEXTracker acquisition, which occurred during the three-month period ended December 31, 2015.

[0000866374-17-000002:mdna:78]
[same as prior period, unchanged from 0000866374-16-000007:mdna:70]

[0000866374-17-000002:mdna:79]
As of December 31, 2016, we had cash and cash equivalents of approximately $1.9 billion and bank and other borrowings of approximately $2.9 billion. We have a $1.5 billion revolving credit facility that expires in March 2019, under which there were no borrowings outstanding as of the end of the quarter. As of December 31, 2016, we were in compliance with the covenants under each of our existing credit facilities and indentures.

[0000866374-17-000002:mdna:80]
Cash provided by operating activities was $1.0 billion during the nine-month period ended December 31, 2016. This resulted from $232.7 million of net income for the period plus adjustments for $466.8 million of non-cash charges such as depreciation, amortization, and other impairment charges (which includes the $60.0 million inventory write-down recorded during the nine-month period ended December 31, 2016), and $313.7 million from changes in our operating assets and liabilities. These changes were mainly related to an increase in accounts payable due to timing of payments to suppliers, offset by an increase in accounts receivable driven by the increase in sales activity.

[0000866374-17-000002:mdna:81]
[same as prior period, unchanged from 0000866374-16-000007:mdna:73]

[0000866374-17-000002:mdna:82]
|  | Three-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |
| Days in trade accounts receivable | 42 days |  | 42 days |
| Days in inventory | 57 days |  | 51 days |
| Days in accounts payable | 74 days |  | 69 days |
| Cash conversion cycle | 25 days |  | 24 days |

[0000866374-17-000002:mdna:83]
Days in trade accounts receivable was calculated as average accounts receivable, net of allowance for doubtful accounts, for the current and prior quarters, adding back the reduction in accounts receivable resulting from non-cash accounts receivable sales, divided by annualized sales for the current quarter by day. During the three-month period ended December 31, 2016, days in trade accounts receivable remained consistent compared to the three-month period ended December 31, 2015. Non-cash accounts receivable sales or deferred purchase price receivables included for the purposes of the calculation were $668.9 million and $534.7 million for the quarters ended December 31, 2016 and December 31, 2015, respectively. Deferred purchase price receivables are recorded in other current assets in the condensed consolidated balance sheets. For further information regarding deferred purchase price receivables see note 10 to the condensed consolidated financial statements.

[0000866374-17-000002:mdna:84]
Days in inventory was calculated as the average inventory for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in inventory increased by 6 days during the three-month period ended December 31, 2016, compared to the three-month period ended December 31, 2015, primarily due to lower sales attributable to higher turn customers in the current quarter.

[0000866374-17-000002:mdna:85]
Days in accounts payable was calculated as the average accounts payable for the current and prior quarters divided by annualized cost of sales for the respective quarter by day. Days in accounts payable increased by 5 days during the three-month period ended December 31, 2016, compared to the three-month period ended December 31, 2015, primarily due to timing of payments, combined with a lower cost of sales attributable to lower sales in the current period compared to the prior year.

[0000866374-17-000002:mdna:86]
Our cash conversion cycle was calculated as the sum of days of inventory and days of account receivables outstanding less days payable outstanding. Our cash conversion cycle increased by 1 day during the three-month period ended December 31, 2016, compared to the three-month period ended December 31, 2015, due to the factors for each of the components in the calculation discussed above.

[0000866374-17-000002:mdna:87]
Cash used in investing activities amounted to $579.4 million during the nine-month period ended December 31, 2016. This resulted primarily from $385.5 million of net capital expenditures for property and equipment to expand capability and capacity in support of our automotive and medical businesses and further investments in both automation and expanding technologies to support our innovation services. In addition, $180.3 million was paid primarily for the acquisition of three businesses, net of cash acquired, including $161.9 million, net of $17.8 million of cash acquired related to the acquisition of the manufacturing facilities from Bose. Further, $60.0 million was paid for a non-controlling interest in a joint venture with RIB Software AG as our partner. Offsets in other investing activities include $33.0 million received for the sale of two non-strategic businesses, and $26.8 million of proceeds from the sale of certain assets that were purchased on behalf of a customer and financed by a third party banking institution.

[0000866374-17-000002:mdna:88]
We believe free cash flow is an important liquidity metric because it measures, during a given period, the amount of cash generated that is available to repay debt obligations, make investments, fund acquisitions, repurchase company shares and for certain other activities. Our free cash flow is calculated as cash from operations less net purchases of property and equipment. Our free cash flows for the nine-month period ended December 31, 2016 was $627.6 million compared to $525.8 million for the nine-month period ended December 31, 2015. Free cash flow is not a measure of liquidity under U.S. GAAP, and may not be defined and calculated by other companies in the same manner. Free cash flow should not be considered in isolation or as an alternative to net cash provided by operating activities. Free cash flows reconcile to the most directly comparable GAAP financial measure of cash flows from operations as follows:

[0000866374-17-000002:mdna:89]
|  | Nine-Month Periods Ended |
|  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 1,013,188 |  |  | $ | 939,772 |  |
| Purchases of property and equipment | (413,596 | ) |  | (418,561 | ) |
| Proceeds from the disposition of property and equipment | 28,056 |  |  | 4,627 |  |
| Free cash flow | $ | 627,648 |  |  | $ | 525,838 |  |

[0000866374-17-000002:mdna:90]
Cash used in financing activities was $204.6 million during the nine-month period ended December 31, 2016, which was primarily for the repurchase of our ordinary shares in the amount of $259.7 million, and $115.1 million for repayment of bank borrowings and long-term debt. These cash outflows were partially offset by $205.5 million of net proceeds from bank borrowings and long-term debt, of which $130 million is the incremental amount borrowed extending the maturity date of one of our term loan agreements from August 30, 2018 to November 30, 2021. Refer to note 5 to the condensed consolidated financial statements for further details.

[0000866374-17-000002:mdna:91]
Our cash balances are held in numerous locations throughout the world. Liquidity is affected by many factors, some of which are based on normal ongoing operations of the business and some of which arise from fluctuations related to global economics and markets. Local government regulations may restrict our ability to move cash balances to meet cash needs under certain circumstances; however, any current restrictions are not material. We do not currently expect such regulations and restrictions to impact our ability to pay vendors and conduct operations throughout the global organization. We believe that our existing cash balances, together with anticipated cash flows from operations and borrowings available under our credit facilities, will be sufficient to fund our operations through at least the next twelve months. As of December 31, 2016

[0000866374-17-000002:mdna:92]
approximately half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. As of March 31, 2016, over half of our cash and cash equivalents was held by foreign subsidiaries outside of Singapore. Although substantially all of the amounts held outside of Singapore could be repatriated under current laws, a significant amount could be subject to income tax withholdings. We provide for tax liabilities on these amounts for financial statement purposes, except for certain of our foreign earnings that are considered indefinitely reinvested outside of Singapore (approximately $916.0 million as of March 31, 2016). Repatriation could result in an additional income tax payment, however, our intent is to permanently reinvest these funds outside of Singapore and our current plans do not demonstrate a need to repatriate them to fund our operations in jurisdictions outside of where they are held. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is that cash balances would remain outside of Singapore and we would meet our liquidity needs through ongoing cash flows, external borrowings, or both.

[0000866374-17-000002:mdna:93]
Future liquidity needs will depend on fluctuations in levels of inventory, accounts receivable and accounts payable, the timing of capital expenditures for new equipment, the extent to which we utilize operating leases for new facilities and equipment, the levels of shipments and changes in the volumes of customer orders, our targeted investments, and our targeted business and asset acquisitions.

[0000866374-17-000002:mdna:94]
[same as prior period, unchanged from 0000866374-16-000007:mdna:85]

[0000866374-17-000002:mdna:95]
We anticipate that we will enter into debt and equity financings, sales of accounts receivable and lease transactions to fund acquisitions and growth. The sale or issuance of equity or convertible debt securities could result in dilution to current shareholders. Further, we may issue debt securities that have rights and privileges senior to those of holders of ordinary shares, and the terms of this debt could impose restrictions on operations and could increase debt service obligations. This increased indebtedness could limit our flexibility as a result of debt service requirements and restrictive covenants, potentially affect our credit ratings, and may limit our ability to access additional capital or execute our business strategy. Any downgrades in credit ratings could adversely affect our ability to borrow as a result of more restrictive borrowing terms. We continue to assess our capital structure and evaluate the merits of redeploying available cash to reduce existing debt or repurchase ordinary shares.

[0000866374-17-000002:mdna:96]
Under our current share repurchase program, our Board of Directors authorized repurchases of our outstanding ordinary shares for up to $500 million in accordance with the share purchase mandate approved by our shareholders at the date of the most recent Extraordinary General Meeting which was held on August 24, 2016. During the nine-month period ended December 31, 2016, we paid $259.7 million to repurchase shares (under the current and prior repurchase plans) at an average price of $13.14 per share. As of December 31, 2016, shares in the aggregate amount of $375.2 million were available to be repurchased under the current plan.

[0000866374-17-000002:mdna:97]
[same as prior period, unchanged from 0000866374-16-000007:mdna:88]

[0000866374-17-000002:mdna:98]
Information regarding our long-term debt payments, operating lease payments, capital lease payments and other commitments is provided in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on our Form 10-K for the fiscal year ended March 31, 2016. There have been no material changes in our contractual obligations and commitments since March 31, 2016 except for the following changes to our debt obligations.

[0000866374-17-000002:mdna:99]
On November 30, 2016 we extended the maturity date of one of our term loan agreements from August 30, 2018 to November 30, 2021, and borrowed an incremental amount of $130 million under this term loan. Refer to note 5 to the condensed consolidated financial statements for additional details on this term loan.

[0000866374-17-000002:mdna:100]
Future payments due under our long-term debt and interest on long-term debt obligations changed from those described in the Contractual Obligations and Commitments table contained within our Annual Report on our Form 10-K for the fiscal year ended March 31, 2016 and accordingly these two items have been updated as follows:

[0000866374-17-000002:mdna:101]
|  |  | Total |  | Less Than1 Year |  | 1-3 Years |  | 4-5 Years |  | Great Than5 Years |
|  |  | (In thousands) |
| Long-term Debt Obligations: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 2,929,152 |  |  | $ | 57,405 |  |  | $ | 544,821 |  |  | $ | 517,567 |  |  | $ | 1,809,359 |  |
| Interest on long-term debt obligations |  | 756,482 |  |  | 99,888 |  |  | 218,606 |  |  | 109,422 |  |  | 328,566 |  |
| Total long-term debt obligations |  | $ | 3,685,634 |  |  | $ | 157,293 |  |  | $ | 763,427 |  |  | $ | 626,989 |  |  | $ | 2,137,925 |  |

[0000866374-17-000002:mdna:102]
[same as prior period, unchanged from 0000866374-16-000007:mdna:90]

[0000866374-17-000002:mdna:103]
We sell designated pools of trade receivables to unaffiliated financial institutions under our ABS programs, and in addition to cash, we receive a deferred purchase price receivable for each pool of the receivables sold. Each of these deferred purchase price receivables serves as additional credit support to the financial institutions and is recorded at its estimated fair value. As of December 31, 2016 and March 31, 2016, the fair values of our deferred purchase price receivable were approximately $668.9 million and $501.1 million, respectively. As of December 31, 2016 and March 31, 2016, the outstanding balance on receivables sold for cash was $1.2 billion under all our accounts receivable sales programs, which are not included in our condensed consolidated balance sheets. For further information, see note 10 to the condensed consolidated financial statements.
