# SMCI 10-K controls and the auditor's report


## auditors_report

[0001375365-19-000079:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-19-000079:auditors_report:2]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-19-000079:auditors_report:3]
Opinion on the Financial Statements

[0001375365-19-000079:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Super Micro Computer, Inc. and subsidiaries (the "Company") as of June 30, 2019 and 2018, the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended June 30, 2019, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2019 and 2018, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2019, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-19-000079:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) and our report dated December 19, 2019, expressed an adverse opinion on the Company’s internal control over financial reporting because of material weaknesses.

[0001375365-19-000079:auditors_report:6]
Change in Accounting Principle

[0001375365-19-000079:auditors_report:7]
As discussed in Note 1 to the financial statements, effective July 1, 2018, the Company has changed its method of accounting for revenue due to adoption of Accounting Standards Codification Topic 606 (ASU No. 2014-09), Revenue from Contracts with Customers, and all subsequent amendments (collectively, “ASC 606”). The Company adopted ASC 606 using the modified retrospective approach.

[0001375365-19-000079:auditors_report:8]
Basis for Opinion

[0001375365-19-000079:auditors_report:9]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-19-000079:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001375365-19-000079:auditors_report:11]
Critical Audit Matters

[0001375365-19-000079:auditors_report:12]
The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that were communicated or required to be communicated to the audit committee and that (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001375365-19-000079:auditors_report:13]
Related Party Transactions - Variable Interest Entity Primary Beneficiary Determination - Refer to Note 1 to the financial statements

[0001375365-19-000079:auditors_report:14]
Critical Audit Matter Description

[0001375365-19-000079:auditors_report:15]
The Company has a variety of business relationships defined by various agreements with Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"). Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company.

[0001375365-19-000079:auditors_report:16]
Purchases from Ablecom and Compuware were $144.5 million and $139.6 million, respectively, for the fiscal year ended June 30, 2019. Net sales to Compuware as a distributor were $17.7 million for the fiscal year ended June 30, 2019.

[0001375365-19-000079:auditors_report:17]
The Company concluded that Ablecom and Compuware are variable interest entities (VIEs) and that it is not the primary beneficiary as it does not have the power to direct the activities that are most significant to Ablecom and Compuware. Therefore, the Company does not consolidate Ablecom and Compuware. The Company considered its explicit arrangements with Ablecom and Compuware, including its supplier arrangements, and as a result of the substantial related party relationships between the Company, Ablecom and Compuware, the Company also considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-19-000079:auditors_report:18]
We identified management’s conclusion that it is not the primary beneficiary as a critical audit matter because of the judgments necessary for management to determine whether any explicit and implicit arrangements exist that would cause the Company to protect those related parties’ interest from absorbing losses, as well as the material weaknesses identified by the Company in all five components of Internal Control - Integrated Framework (2013) issued by COSO. This required extensive audit effort due to the complexity and variety of related party relationships with Ablecom and Compuware and required a high degree of auditor judgment when performing audit procedures to audit the Company’s conclusion that it is not the primary beneficiary.

[0001375365-19-000079:auditors_report:19]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-19-000079:auditors_report:20]
Our audit procedures related to management’s conclusion that it is not the primary beneficiary included the following, among others:

[0001375365-19-000079:auditors_report:21]
| • | We evaluated and tested whether the arrangements are accurately considered and that arrangements have been included in the consideration by comparing those related parties we had identified during our audit procedures for proper inclusion in the Company’s evaluation and performed inspection of source documents on a sample basis. |

[0001375365-19-000079:auditors_report:22]
| • | We tested management’s assertion that it does not have the power to direct the activities that are most significant to, or obligation to absorb the losses of, Ablecom and Compuware by reviewing all agreements and transactions between the parties. |

[0001375365-19-000079:auditors_report:23]
| • | We obtained confirmations directly from Ablecom and Compuware regarding the nature of their business relationships with the Company, the extent of power, if any, held by the Company over the most significant activities of Ablecom and Compuware’s businesses, and the existence of any implicit arrangements that may have a bearing on the Company’s ability to have power over Ablecom and Compuware. |

[0001375365-19-000079:auditors_report:24]
As a result of the material weaknesses identified by the Company in all five components of Internal Control - Integrated Framework (2013) issued by COSO, we increased the extent of testing around the Company’s procedures for assessing whether the arrangements with Ablecom and Compuware are off market or whether they force Ablecom and Compuware to absorb losses.  We also increased the extent of testing to determine if there are any agreements that provide the Company with power to direct the activities that are most significant to Ablecom and Compuware.

[0001375365-19-000079:auditors_report:25]
Inventories - Excess and Obsolescence Reserve - Refer to Notes 1 and 5 to the financial statements

[0001375365-19-000079:auditors_report:26]
Critical Audit Matter Description

[0001375365-19-000079:auditors_report:27]
The Company’s inventories are stated at weighted average cost, subject to lower of cost or net realizable value, and as necessary, the Company writes down the valuation of inventories for excess and obsolescence.  The provision for excess and obsolete inventory for the fiscal year ended June 30, 2019, was $28.5 million.

[0001375365-19-000079:auditors_report:28]
We identified the excess and obsolescence reserve as a critical audit matter because of the judgments management makes to estimate the excess and obsolescence reserve, as well as the material weaknesses identified by the Company in all five components of Internal Control - Integrated Framework (2013) issued by COSO.  This required a high degree of auditor judgment and an increased extent of effort when performing audit procedures to evaluate the methodology and the reasonableness of the excess and obsolescence reserve.

[0001375365-19-000079:auditors_report:29]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-19-000079:auditors_report:30]
Our audit procedures related to the Company’s excess and obsolescence reserve included the following procedures, among others:

[0001375365-19-000079:auditors_report:31]
| • | We gained an understanding and evaluated the Company’s methodology for determining inventory that is excess or obsolete and the key assumptions and judgments made as part of the process. |

[0001375365-19-000079:auditors_report:32]
| • | We evaluated the assumptions used by the Company to define what is considered aged inventory by assessing historical trends in the Company’s product life cycle as well as evaluating the underlying calculations applied to the aged inventory. |

[0001375365-19-000079:auditors_report:33]
| • | We evaluated the inventory valuation utilizing the methodology above to assess the inventory reserve rate applied to different aging buckets. |

[0001375365-19-000079:auditors_report:34]
As a result of the Company’s material weaknesses identified by the Company in all five components of Internal Control - Integrated Framework (2013) issued by COSO, we increased the extent of testing on reports derived from the Company’s systems and applications.

[0001375365-19-000079:auditors_report:35]
Revenue - Refer to Note 3 to the financial statements

[0001375365-19-000079:auditors_report:36]
Critical Audit Matter Description

[0001375365-19-000079:auditors_report:37]
The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Net sales for the fiscal year ended June 30, 2019 was $3.5 billion, which principally consist of product sales.

[0001375365-19-000079:auditors_report:38]
We identified the timing of revenue recognition for product sales (i.e., whether the Company recorded product sales in the appropriate fiscal year) as a critical audit matter because of the material weaknesses identified by the Company associated with revenue recognition accounting controls and the material weaknesses in all five components of Internal Control - Integrated Framework (2013) issued by COSO. This made auditing the timing of revenue recognition for product sales more challenging and required an increased extent of audit effort, including the need for us to involve specialists and modify the nature and extent of our audit procedures and the evidence obtained.

[0001375365-19-000079:auditors_report:39]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-19-000079:auditors_report:40]
Our audit procedures related to the timing of revenue recognition for product sales included the following, among others:

[0001375365-19-000079:auditors_report:41]
| • | We selected a sample of product sales from the period immediately preceding the Company’s fiscal year end and obtained the invoice, purchase order, customer contract or agreement, packing list, bill of lading, proof of delivery, and evidence of cash collection, in order to evaluate whether revenue was recognized in the appropriate fiscal year. |

[0001375365-19-000079:auditors_report:42]
| • | We selected a sample of product sales for the year and obtained the related contract to identify whether customer acceptance clauses existed that delayed the timing of revenue recognition. |

[0001375365-19-000079:auditors_report:43]
| • | We selected a sample of credit memos from the period immediately subsequent to the Company’s fiscal year end and obtained the credit memo and the related invoice, return merchandise authorization form, and shipping documents, as applicable and among others, to evaluate whether revenue was recognized in the fiscal year ended June 30, 2019 before control was transferred to the customer or customer acceptance was certain. |

[0001375365-19-000079:auditors_report:44]
| • | We obtained and evaluated internal certifications provided by the Company’s employees related to sales transactions in order to identify the existence of side agreements that could impact the timing of revenue recognition. We also selected a sample of employees and conducted interviews to corroborate the accuracy and completeness of the information provided in the certifications. |

[0001375365-19-000079:auditors_report:45]
| • | We selected a sample of the Company’s top customers and confirmed the terms and conditions of the master sales |

[0001375365-19-000079:auditors_report:46]
agreement or purchase orders directly with the customer.

[0001375365-19-000079:auditors_report:47]
As a result of the material weaknesses, among other modifications to the nature and extent of our audit procedures and the evidence obtained, we involved forensic specialists, increased the number of selections we would have otherwise made if the Company’s controls were designed and operating effectively. With the assistance of information technology and data analytics specialists, we also performed data extraction procedures to test the accuracy and completeness of the revenue information generated from the Company’s systems and applications.

[0001375365-19-000079:auditors_report:48]
/s/ Deloitte & Touche LLP

[0001375365-19-000079:auditors_report:49]
San Jose, California

[0001375365-19-000079:auditors_report:50]
December 19, 2019

[0001375365-19-000079:auditors_report:51]
We have served as the Company's auditor since fiscal 2003.

[0001375365-19-000079:auditors_report:52]
70

[0001375365-19-000079:auditors_report:53]
SUPER MICRO COMPUTER, INC.


## item_9a

[0001375365-19-000079:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-19-000079:item_9a:2]
Background

[0001375365-19-000079:item_9a:3]
Prior to the issuance of the Company’s consolidated financial statements for the fiscal year ended June 30, 2017, the audit committee (the “Audit Committee”) of the Company’s Board of Directors (the “Board”) investigated and assessed certain accounting and internal control matters at the Company, principally focused on certain revenue recognition matters. Concurrently, new members of the Company’s management, under the direction of the Audit Committee, performed a thorough analysis of the Company’s historical financial statements, accounting policies and financial reporting, as well as the Company’s disclosure controls and procedures and its internal control over financial reporting. Management concluded that our disclosure controls and procedures were not effective as of June 30, 2017 because of certain material weaknesses in our internal control over financial reporting, as described in our 2017 10-K.

[0001375365-19-000079:item_9a:4]
The Company is committed to remediating these material weaknesses and strengthening its internal control over financial reporting, and our management has developed a comprehensive plan for this remediation and strengthening. In consultation with the Audit Committee, our management began developing this plan during the comprehensive analysis described above and continued developing it after we filed the 2017 10-K. We began to implement certain elements of the plan during fiscal years 2018 and 2019, and have continued to implement the plan during the current fiscal year. Among other actions, our actions to date have included both strengthening existing individual controls and designing and implementing new individual controls. However, before our management can conclude that these new and strengthened controls are sufficient to remediate the material weaknesses, the controls must operate effectively for a sufficient period of time. As of June 30, 2019,

[0001375365-19-000079:item_9a:5]
sufficient time had not elapsed since we implemented the new and strengthened controls for our management to determine that they operated effectively as of that date. For this reason, although we have taken many actions to strengthen our internal control over financial reporting and the Company’s disclosure controls and procedures, our management did not conclude that any of the material weaknesses identified in the 2017 10-K had been remediated as of June 30, 2019. The actions we have taken to address these material weaknesses are described below under “Remediation Plan and Status.”

[0001375365-19-000079:item_9a:6]
In connection with the preparation and filing of this Annual Report on Form 10-K, we have conducted the requisite evaluations of the effectiveness of our disclosure controls and procedures and of our internal control over financial reporting, both as of June 30, 2019.

[0001375365-19-000079:item_9a:7]
Evaluation of Disclosure Controls and Procedures

[0001375365-19-000079:item_9a:8]
Under the supervision, and with the participation, of our management, including our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of June 30, 2019. Based on this evaluation of our disclosure controls and procedures, our CEO and CFO have concluded that our disclosure controls and procedures were not effective as of June 30, 2019 because of certain material weaknesses in our internal control over financial reporting, as further described below.

[0001375365-19-000079:item_9a:9]
Notwithstanding the conclusion by our CEO and CFO that our disclosure controls and procedures as of June 30, 2019 were not effective, and notwithstanding the material weaknesses in our internal control over financial reporting described below, management believes that the consolidated financial statements and related financial information included in this Annual Report fairly present in all material respects our financial condition, results of operations and cash flows as of the dates presented, and for the periods ended on such dates, in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”).

[0001375365-19-000079:item_9a:10]
Management’s Report on Internal Control Over Financial Reporting

[0001375365-19-000079:item_9a:11]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f).

[0001375365-19-000079:item_9a:12]
Internal control over financial reporting is a process designed by, or under the supervision of, our CEO and CFO to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our consolidated financial statements for external purposes in accordance with U.S. GAAP. Management’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets, (ii) provide reasonable assurance that transactions are appropriately recorded to permit preparation of financial statements in accordance with U.S. GAAP and that our receipts and expenditures are made only in accordance with authorizations of management, acting under authority delegated to them by the Board, and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on our financial statements.

[0001375365-19-000079:item_9a:13]
Management, including our CEO and CFO, assessed our internal control over financial reporting as of June 30, 2019. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in its Internal Control - Integrated Framework (2013) (the “COSO Framework”). Based on this assessment, management has determined that we did not maintain effective internal control over financial reporting as of June 30, 2019 because of the material weaknesses described below.

[0001375365-19-000079:item_9a:14]
A material weakness in internal controls is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. Because of its inherent limitations, even appropriate internal control over financial reporting may not prevent or detect misstatements.

[0001375365-19-000079:item_9a:15]
In connection with management’s assessment of the Company’s internal control over financial reporting described above, management has identified the deficiencies described below that constitute material weaknesses in our internal control over financial reporting as of June 30, 2019.

[0001375365-19-000079:item_9a:16]
Control Environment

[0001375365-19-000079:item_9a:17]
In our Annual Report on Form 10-K for the year ended June 30, 2017 we disclosed the identification of deficiencies in the control environment component of the COSO Framework that constituted material weaknesses, either individually or in the aggregate. These deficiencies related to all the principles associated with the control environment component of the COSO Framework.

[0001375365-19-000079:item_9a:18]
We are committed to remediating the underlying cause of these material weaknesses and are taking actions to enhance our internal control over financial reporting relating to the material weaknesses. However, we are still in the process of implementing our comprehensive remediation plan and we have not had sufficient time to test the effectiveness of the new and strengthened controls as of June 30, 2019. Consequently, deficiencies that constitute material weaknesses, either individually or in the aggregate, in the control environment and other components remain.

[0001375365-19-000079:item_9a:19]
The material weaknesses noted above cannot be considered remediated until each control has been appropriately designed, has operated for a sufficient period of time, and management has concluded, through testing, that the control is operating effectively. Due to the interdependencies between the COSO Framework components, the material weakness in our control environment contributed to other material weaknesses within our system of internal control over financial reporting.

[0001375365-19-000079:item_9a:20]
Risk Assessment

[0001375365-19-000079:item_9a:21]
We identified deficiencies in the risk assessment component of the COSO Framework that aggregated to a material weakness. These deficiencies related to the principles associated with the risk assessment component of the COSO Framework, specifically principles within the component related to: (i) identifying, assessing, and communicating appropriate control objectives, (ii) identifying and analyzing risks to achieve these objectives, (iii) contemplating fraud risks, and (iv) identifying and assessing changes in the business that could impact the system of internal controls. As of June 30, 2019, our risk assessment component framework had not yet operated for a sufficient period of time for us to determine its effectiveness.

[0001375365-19-000079:item_9a:22]
Control Activities

[0001375365-19-000079:item_9a:23]
We identified deficiencies in the control activities component of the COSO Framework that aggregated to a material weakness. These deficiencies related to principles associated with the control activities component of the COSO Framework, specifically principles within the component related to (i) selecting and developing control activities that mitigate risks, (ii) selecting and developing general controls over technology and (iii) deploying control activities through policies that establish what is expected and procedures that put policies into action. We did not design or operate certain control activities to sufficiently respond to potential risks of material misstatement in the area of revenue recognition. We did not effectively select and develop certain information technology (“IT”) general controls and we also had control deficiencies at both the IT administrator and end-user levels across multiple applications relevant to financial reporting. We also had deficiencies related to segregation of duties. Deficiencies in control activities contributed to the potential for there to have been material accounting errors in substantially all financial statements account balances and disclosures.

[0001375365-19-000079:item_9a:24]
Information and Communication

[0001375365-19-000079:item_9a:25]
We identified deficiencies in the information and communication component of the COSO Framework that aggregated to a material weakness. These deficiencies related to principles associated with the information and communications component of the COSO Framework, specifically principles within the component related to (i) generating and using relevant quality information and (ii) internally communicating information, including objectives and responsibilities for internal control, necessary to support the functioning of internal control. We rely on manual business processes to compensate for a lack of extensive integration in our information systems. We also rely heavily on each of our various functions, such as sales, operations, accounting, legal and management, to communicate to the other functions information that the entire organization needs to operate an effective internal control environment. In certain areas, our control activity deficiencies resulted from insufficient communication of information among our internal functions.

[0001375365-19-000079:item_9a:26]
Monitoring of Controls

[0001375365-19-000079:item_9a:27]
We identified deficiencies in the monitoring of controls component of the COSO Framework that aggregated to a material weakness. There were deficiencies related to a principle associated with the monitoring of controls component of the COSO Framework, specifically selecting, developing and performing ongoing and/or separate evaluations. We lacked controls (i) to determine whether components of internal control were present and functioning and (ii) to detect incorrect accounting practices.

[0001375365-19-000079:item_9a:28]
The material weaknesses noted above contributed to the following additional material weaknesses:

[0001375365-19-000079:item_9a:29]
Revenue Recognition Accounting

[0001375365-19-000079:item_9a:30]
We identified deficiencies in revenue recognition accounting controls that resulted in material weaknesses, either individually or in the aggregate, as we did not appropriately design, or effectively operate, internal controls over certain aspects of accurate recording, presentation, and disclosure of revenue and related costs. The following were contributing factors to the material weaknesses in revenue recognition accounting:

[0001375365-19-000079:item_9a:31]
| • | Our internal controls did not consistently identify and properly account for certain key non-standard contract or arrangement terms for sales transactions. |

[0001375365-19-000079:item_9a:32]
| • | Our internal controls failed to consistently identify transactions where the terms of the sales arrangements with our customers were not properly documented in a form that fully reflected the final understanding between the parties as to the specific nature and terms of the agreed-upon transaction. |

[0001375365-19-000079:item_9a:33]
| • | Our internal controls failed to consistently identify, resolve, document, and allow for proper accounting where there were inconsistencies among the various documents underlying our sales transactions, and we did not always communicate the existence or resolution of those inconsistencies to our accounting organization to enable the proper recognition of revenue. |

[0001375365-19-000079:item_9a:34]
| • | Internal controls intended to establish a consistent approach for reviewing pricing and establishing supportable estimates of standalone selling price in allocating revenue between multiple performance obligations have not been implemented for a sufficient period of time to demonstrate the controls were operating effectively. |

[0001375365-19-000079:item_9a:35]
Information Technology General Controls

[0001375365-19-000079:item_9a:36]
We identified deficiencies related to IT general controls that represented a material weakness, either individually or in the aggregate. The following were contributing factors to the material weakness in information technology and general controls:

[0001375365-19-000079:item_9a:37]
| • | We have a decentralized approach to developing IT policies and practices and to monitoring our IT controls. As a result, our internal procedures for granting and monitoring employee access, and managing changes to various applications and infrastructure layers relevant to our financial reporting are not consistent across those applications and infrastructure layers. In addition, some of our internally-developed applications relevant to financial reporting lack system tracking capabilities to monitor access changes or application changes. We have also authorized certain users with broad access, both as a user and as an administrator, to all parts of our primary accounting system without adequate monitoring or recording of how they used that access. As a result of these factors, we have material weaknesses related to access controls and change management. The fact that we have material weaknesses related to access controls and change management means that it is possible that our business process controls that depend on the affected information systems, or that depend on data or financial reports generated from the affected information systems, could be adversely affected due to the access control and change management issues, although we have identified no instances of any adverse effect due to these deficiencies. |

[0001375365-19-000079:item_9a:38]
The effectiveness of our internal control over financial reporting as of June 30, 2019 has been audited by Deloitte & Touche LLP, our independent registered public accounting firm, as stated in its report that is included herein.

[0001375365-19-000079:item_9a:39]
Remediation Plan and Status

[0001375365-19-000079:item_9a:40]
As previously disclosed, starting in the second half of fiscal year 2018 and throughout fiscal year 2019, we began to design and implement processes and procedures to remediate material weaknesses identified as of June 30, 2017.

[0001375365-19-000079:item_9a:41]
Our management is committed to remediating identified control deficiencies (including both those that rise to the level of a material weakness and those that do not), fostering continuous improvement in our internal controls and enhancing our overall internal controls environment. Our management believes that these remediation actions, along with additional actions, when fully implemented, will remediate the material weaknesses we have identified and strengthen our internal control over financial reporting. We are committed to improving our internal control processes and intend to continue to review and improve our financial reporting controls and procedures. As we continue to evaluate and work to improve our internal control over financial reporting, we may take additional or different measures to address control deficiencies with the overall objective to

[0001375365-19-000079:item_9a:42]
design and operate internal controls that mitigate identified risks and enable an effective system of internal control over external financial reporting.

[0001375365-19-000079:item_9a:43]
We have taken the following actions, among others, to address previously disclosed material weaknesses:

[0001375365-19-000079:item_9a:44]
| • | Restructured our sales organization, which resulted in the resignations of the Senior Vice President of International Sales, the Senior Vice President of Worldwide Sales, the Vice President, Strategic Accounts, the Vice President, Strategic Sales, the Vice President, Business Development and certain other sales personnel. |

[0001375365-19-000079:item_9a:45]
| • | Appointed experienced professionals to key accounting and finance and compliance leadership positions, including the appointments of a new Chief Financial Officer and a new Corporate Controller in January 2018, and the creation of, and appointments to, two newly established roles of Chief Compliance Officer and Vice President of Internal Audit in May 2018 and August 2018, respectively. |

[0001375365-19-000079:item_9a:46]
| • | Reviewed and amended our Code of Conduct to align with the organizational changes described above and to strengthen certain provisions regarding compliance and reporting violations of the Code of Conduct. |

[0001375365-19-000079:item_9a:47]
| • | Adopted an Internal Audit Charter setting forth the responsibilities of the internal audit function and establishing that the Vice President of Internal Audit reports directly to the Audit Committee and that the Audit Committee has authority to provide adequate funding for this function. |

[0001375365-19-000079:item_9a:48]
| • | Changed our organizational structure to narrow the scope of responsibilities of certain of our senior executives and to revise various reporting relationships, which included the appointment of a new Senior Vice President of Worldwide Sales, and a new Senior Vice President of Operations. |

[0001375365-19-000079:item_9a:49]
| • | Conducted training in the following areas: |

[0001375365-19-000079:item_9a:50]
| – | Revenue recognition training for our global sales force, various operations personnel, and certain senior executives, including our CEO, which included detailed examples of acceptable and unacceptable sales practices, |

[0001375365-19-000079:item_9a:51]
| – | Reviewed with our senior management team our amended Code of Conduct, |

[0001375365-19-000079:item_9a:52]
| – | Reviewed with our CEO enhanced processes for periodic evaluations by the CEO and the CFO of the effectiveness of our disclosure controls and procedures, and the periodic assessments by the CEO and the CFO of the effectiveness of our internal control over financial reporting, and other compliance matters, and |

[0001375365-19-000079:item_9a:53]
| – | Shipping and cut-off training for accounting and operations personnel that included new requirements for quarter-end procedures. |

[0001375365-19-000079:item_9a:54]
| • | Enhanced the sales sub-certification document that supports our CEO’s and CFO’s financial statement certifications and expanded the sub-certification participation population to the global sales force. |

[0001375365-19-000079:item_9a:55]
To date, we have taken the following actions related to material weaknesses that, as of June 30, 2019, had not yet been fully implemented or had not been in place for a sufficient period of time to demonstrate that they were having their desired effect:

[0001375365-19-000079:item_9a:56]
| • | Upgraded our accounting department to include the new roles of Senior Director of Tax, Financial Audit Director and Information Technology Audit Director, as well as replaced certain of our accounting personnel with more experienced individuals, including rebuilding and expanding our revenue recognition team. |

[0001375365-19-000079:item_9a:57]
| • | Enhanced the financial statement risk assessment and fraud risk assessment which are a foundational element of our Sarbanes-Oxley compliance program. |

[0001375365-19-000079:item_9a:58]
| • | Implemented a sequence of meetings around our processes to prepare and report on the consolidated financial statements that promotes cross-functional communication and broadens the accountability for internal controls. |

[0001375365-19-000079:item_9a:59]
| • | Implemented new revenue recognition processes and controls to: |

[0001375365-19-000079:item_9a:60]
| – | Effect an appropriate cutoff of shipping activity |

[0001375365-19-000079:item_9a:61]
| – | Increase the alignment of invoicing with physical shipment |

[0001375365-19-000079:item_9a:62]
| – | Identify and account for transactions that may not have met revenue recognition criteria |

[0001375365-19-000079:item_9a:63]
| – | Appropriately account for the allocation of revenue among performance obligations |

[0001375365-19-000079:item_9a:64]
115

[0001375365-19-000079:item_9a:65]
| • | Assigned accountability for certain internal controls to our Compliance Department, such as our organizational-wide quarterly sales certification process. |

[0001375365-19-000079:item_9a:66]
| • | Conducted a process by which employees re-certified their understanding of, and compliance with, the Company’s Code of Conduct. |

[0001375365-19-000079:item_9a:67]
| • | Adopted a charter for our compliance program to promote an organizational culture that encourages the highest standards of ethical business conduct and compliance with the law, exercises appropriate due diligence to prevent and detect unlawful conduct, and protects the Company’s reputation. |

[0001375365-19-000079:item_9a:68]
Our management believes that meaningful progress has been made on the remaining remediation efforts. Management regards successful completion of our remaining remediation actions as an important priority. Some of the more significant remaining remediation activities include:

[0001375365-19-000079:item_9a:69]
| • | Developing and implementing an ongoing compliance training program regarding significant accounting and financial reporting matters, as well as broad compliance matters, for accounting, financial reporting, sales and operations personnel, as well as for our CEO, our other corporate executives and the Board. |

[0001375365-19-000079:item_9a:70]
| • | Integrating the responsibility for internal controls across business functions to assign accountability for internal controls beyond the accounting and finance team. |

[0001375365-19-000079:item_9a:71]
| • | Increasing standardization and automation within accounting processes to improve the reliability of information used by existing accounting personnel. |

[0001375365-19-000079:item_9a:72]
| • | Implementing a governance committee for our Sarbanes-Oxley compliance program and assigning individual accountability for internal controls. |

[0001375365-19-000079:item_9a:73]
| • | Redesigning and implementing necessary changes to the existing system of internal controls in the context of the revised and more comprehensive risk assessment. |

[0001375365-19-000079:item_9a:74]
| • | Updating selected policies and assigning accountable policy owners related to revenue recognition. |

[0001375365-19-000079:item_9a:75]
| • | Reevaluating the boundary applications that interface with our primary accounting and reporting application and redesigning logical access and program change controls to enhance the reliability of information used to conduct other internal controls. |

[0001375365-19-000079:item_9a:76]
| • | Implementing and/or enhancing IT general controls and segregation of duties controls: |

[0001375365-19-000079:item_9a:77]
| – | Monitoring instances in which individuals are granted broad access |

[0001375365-19-000079:item_9a:78]
| – | Strengthening provisioning of privileged access roles |

[0001375365-19-000079:item_9a:79]
| – | Developing change management capabilities in certain boundary applications and implementing new change management controls |

[0001375365-19-000079:item_9a:80]
| • | Identifying and properly accounting for non-standard terms, including increased information sharing between Sales and other departments on sales transactions |

[0001375365-19-000079:item_9a:81]
| • | Identifying and resolving instances in which customer contracts and purchase orders have conflicting terms, including the new processes to ensure customer master data is complete, accurate and updated as needed on a timely basis |

[0001375365-19-000079:item_9a:82]
| • | Enhancing procedures to ensure contracts create enforceable rights and obligations, including standardizing the method by which we accept customer purchase orders. |

[0001375365-19-000079:item_9a:83]
| • | Developing a system of daily reports related to revenue recognition that enable ongoing monitoring for non-standard transactions and the appropriate allocation of revenue among performance obligations. |

[0001375365-19-000079:item_9a:84]
| • | Testing of sufficient instances of the performance of controls to determine operational effectiveness. |

[0001375365-19-000079:item_9a:85]
Changes in Internal Control Over Financial Reporting

[0001375365-19-000079:item_9a:86]
116

[0001375365-19-000079:item_9a:87]
Other than the ongoing remediation efforts described above, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the three months ended June 30, 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-19-000079:item_9a:88]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-19-000079:item_9a:89]
To the shareholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-19-000079:item_9a:90]
Opinion on Internal Control over Financial Reporting

[0001375365-19-000079:item_9a:91]
We have audited the internal control over financial reporting of Super Micro Computer, Inc. and subsidiaries (the “Company”) as of June 30, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, because of the effect of the material weaknesses identified below on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of June 30, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0001375365-19-000079:item_9a:92]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year June 30, 2019, of the Company and our report dated December 19, 2019, expressed an unqualified opinion on those financial statements and included an explanatory paragraph regarding the Company’s change in method of accounting for revenue in fiscal year 2019 due to the adoption of Accounting Standards Codification 606, Revenue from Contracts with Customers.

[0001375365-19-000079:item_9a:93]
Basis for Opinion

[0001375365-19-000079:item_9a:94]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-19-000079:item_9a:95]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-19-000079:item_9a:96]
Definition and Limitations of Internal Control over Financial Reporting

[0001375365-19-000079:item_9a:97]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-19-000079:item_9a:98]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-19-000079:item_9a:99]
Material Weaknesses

[0001375365-19-000079:item_9a:100]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company’s annual or interim financial statements will not be prevented or detected on a timely basis. The following material weaknesses have been identified and included in management's assessment:

[0001375365-19-000079:item_9a:101]
Control Environment

[0001375365-19-000079:item_9a:102]
The Company has identified deficiencies in the control environment component of the COSO Framework that constituted material weaknesses, either individually or in the aggregate. These deficiencies related to all the principles associated with the control environment component of the COSO Framework.  The Company is still in the process of implementing its comprehensive remediation plan and has not had sufficient time to test the effectiveness of certain remediation actions as of June 30, 2019. Consequently, deficiencies that constitute material weaknesses, either individually or in the aggregate, in the control environment and other components remain.

[0001375365-19-000079:item_9a:103]
Due to the interdependencies between the COSO Framework components, the material weakness in the control environment contributed to other material weaknesses within the Company’s system of internal control over financial reporting.

[0001375365-19-000079:item_9a:104]
Risk Assessment

[0001375365-19-000079:item_9a:105]
The Company identified deficiencies in the risk assessment component of the COSO Framework that aggregated to a material weakness. These deficiencies related to the principles associated with the risk assessment component of the COSO Framework, specifically principles within the component related to: (i) identifying, assessing, and communicating appropriate control objectives, (ii) identifying and analyzing risks to achieve these objectives, (iii) contemplating fraud risks, and (iv) identifying and assessing changes in the business that could impact the system of internal controls. As of June 30, 2019, the Company’s risk assessment component framework had not yet operated for a sufficient period of time to determine its effectiveness.

[0001375365-19-000079:item_9a:106]
Control Activities

[0001375365-19-000079:item_9a:107]
The Company identified deficiencies in the control activities component of the COSO Framework that aggregated to a material weakness. These deficiencies related to principles associated with the control activities component of the COSO Framework, specifically principles within the component related to (i) selecting and developing control activities that mitigate risks, (ii) selecting and developing general controls over technology and (iii) deploying control activities through policies that establish what is expected and procedures that put policies into action. The Company did not design or operate certain control activities to sufficiently respond to potential risks of material misstatement in the area of revenue recognition. The Company did not effectively select and develop certain information technology (“IT”) general controls and also had control deficiencies at both the IT administrator and end-user levels across multiple applications relevant to financial reporting. The Company also had deficiencies related to segregation of duties. Deficiencies in control activities contributed to the potential for there to have been material accounting errors in substantially all financial statements account balances and disclosures.

[0001375365-19-000079:item_9a:108]
Information and Communication

[0001375365-19-000079:item_9a:109]
The Company identified deficiencies in the information and communication component of the COSO Framework that aggregated to a material weakness. These deficiencies related to principles associated with the information and communications component of the COSO Framework, specifically principles within the component related to (i) generating and using relevant quality information and (ii) internally communicating information, including objectives and responsibilities for internal control, necessary to support the functioning of internal control. The Company relies on manual business processes to compensate for a lack of extensive integration in their information systems. The Company also relies heavily on each of the various functions, such as sales, operations, accounting, legal and management, to communicate to the other functions information that the entire organization needs to operate an effective internal control environment. In certain areas, control activity deficiencies resulted from insufficient communication of information among internal functions.

[0001375365-19-000079:item_9a:110]
Monitoring of Controls

[0001375365-19-000079:item_9a:111]
The Company identified deficiencies in the monitoring of controls component of the COSO Framework that aggregated to a material weakness. There were deficiencies related to a principle associated with the monitoring of controls component of the COSO Framework, specifically selecting, developing and performing ongoing and/or separate evaluations. The Company lacked controls (i) to determine whether components of internal control were present and functioning and (ii) to detect incorrect accounting practices.

[0001375365-19-000079:item_9a:112]
The material weaknesses noted above contributed to the following additional material weaknesses:

[0001375365-19-000079:item_9a:113]
Revenue Recognition Accounting

[0001375365-19-000079:item_9a:114]
The Company identified deficiencies in revenue recognition accounting controls that resulted in material weaknesses, either individually or in the aggregate, as the Company did not appropriately design, or effectively operate, internal controls

[0001375365-19-000079:item_9a:115]
over certain aspects of accurate recording, presentation, and disclosure of revenue and related costs. The following were contributing factors to the material weaknesses in revenue recognition accounting:

[0001375365-19-000079:item_9a:116]
| • | Internal controls did not consistently identify and properly account for certain key non-standard contract or arrangement terms for sales transactions. |

[0001375365-19-000079:item_9a:117]
| • | Internal controls failed to consistently identify transactions where the terms of the sales arrangements with customers were not properly documented in a form that fully reflected the final understanding between the parties as to the specific nature and terms of the agreed-upon transaction. |

[0001375365-19-000079:item_9a:118]
| • | Internal controls failed to consistently identify, resolve, document, and allow for proper accounting where there were inconsistencies among the various documents underlying sales transactions, and the Company did not always communicate the existence or resolution of those inconsistencies to the accounting organization to enable the proper recognition of revenue. |

[0001375365-19-000079:item_9a:119]
| • | Internal controls intended to establish a consistent approach for reviewing pricing and establishing supportable estimates of standalone selling price in allocating revenue between multiple performance obligations have not been implemented for a sufficient period of time to demonstrate the controls were operating effectively. |

[0001375365-19-000079:item_9a:120]
Information Technology General Controls

[0001375365-19-000079:item_9a:121]
The Company identified deficiencies related to IT general controls that represented a material weakness, either individually or in the aggregate. The following were contributing factors to the material weakness in information technology and general controls:

[0001375365-19-000079:item_9a:122]
| • | The Company has a decentralized approach to developing IT policies and practices and to monitoring our IT controls. As a result, the Company’s internal procedures for granting and monitoring employee access and managing changes to various applications and infrastructure layers relevant to financial reporting are not consistent across those applications and infrastructure layers. In addition, some of the Company’s internally-developed applications relevant to financial reporting lack system tracking capabilities to monitor access changes or application changes. The Company has also authorized certain users with broad access, both as a user and as an administrator, to all parts of the primary accounting system without adequate monitoring or recording of how they used that access. As a result of these factors, the Company has material weaknesses related to access controls and monitoring for changes to applications. The fact that the Company had material weaknesses related to access controls and change management means that it is possible that business process controls that depend on the affected information systems, or that depend on data or financial reports generated from affected information systems, could be adversely affected due to the access control and change management issues, although the Company has identified no instances of any adverse effect due to these deficiencies. |

[0001375365-19-000079:item_9a:123]
These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements as of and for the year ended June 30, 2019, of the Company, and this report does not affect our report on such financial statements.

[0001375365-19-000079:item_9a:124]
/s/ Deloitte & Touche LLP

[0001375365-19-000079:item_9a:125]
San Jose, California

[0001375365-19-000079:item_9a:126]
December 19, 2019
