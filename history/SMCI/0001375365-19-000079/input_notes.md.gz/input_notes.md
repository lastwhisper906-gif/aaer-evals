# SMCI notes — 0001375365-19-000079


## smci:PropertyPlantAndEquipmentUsefulLifeTableTextBlock

[0001375365-19-000079:notes:1]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-19-000079:notes:2]
| Software | 3 to 5 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |


## smci:SummaryOfAllowanceForDoubtfulAccountsAndSalesReturnsTableTextBlock

[0001375365-19-000079:notes:3]
Accounts receivable allowances as of June 30, 2019, 2018 and 2017 consisted of the following (in thousands):

[0001375365-19-000079:notes:4]
|  | BeginningBalance |  | Charged toCost andExpenses |  | Additions/(Deductions) |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2019 | $ | 1,945 |  |  | $ | 7,058 |  |  | $ | (97 | ) |  | $ | 8,906 |  |
| Year ended June 30, 2018 | 2,370 |  |  | (96 | ) |  | (329 | ) |  | 1,945 |  |
| Year ended June 30, 2017 | 2,033 |  |  | 334 |  |  | 3 |  |  | 2,370 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001375365-19-000079:notes:5]
Accrued Liabilities

[0001375365-19-000079:notes:6]
Accrued liabilities as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:7]
|  | June 30, |
|  | 2019 |  | 2018 |
| Accrued payroll and related expenses | $ | 25,552 |  |  | $ | 25,532 |  |
| Contract manufacturers liability | 25,308 |  |  | 28,754 |  |
| Accrued professional fees | 11,756 |  |  | 6,626 |  |
| Customer deposits | 11,133 |  |  | 14,938 |  |
| Accrued warranty costs | 8,661 |  |  | 7,589 |  |
| Accrued cooperative marketing expenses | 5,830 |  |  | 6,413 |  |
| Others | 26,438 |  |  | 12,626 |  |
| Total accrued liabilities | $ | 114,678 |  |  | $ | 102,478 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001375365-19-000079:notes:8]
Advertising Costs

[0001375365-19-000079:notes:9]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-19-000079:notes:10]
Commitments and Contingencies

[0001375365-19-000079:notes:11]
Litigation and Claims— In February 2018, the Company became a party to legal proceedings whereby complainants have alleged that it has violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions. In July 2019, the Company filed a motion to dismiss which remains pending. See Note 19, "Subsequent Events" for further details. From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001375365-19-000079:notes:12]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-19-000079:notes:13]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2019, these remaining noncancelable commitments were $299.8 million, including $101.6 million for related parties.

[0001375365-19-000079:notes:14]
Lease Commitments—The Company leases offices and equipment under noncancelable operating leases which expire at various dates through 2026. In addition, the Company leases certain of its equipment under capital leases. The future minimum lease commitments under all leases are as follows (in thousands):

[0001375365-19-000079:notes:15]
| Year ending: | CapitalLeases |  | OperatingLeases |
| June 30, 2020 | $ | 164 |  |  | $ | 6,582 |  |
| June 30, 2021 | 103 |  |  | 3,831 |  |
| June 30, 2022 | 40 |  |  | 2,439 |  |
| June 30, 2023 | 1 |  |  | 1,175 |  |
| June 30, 2024 | — |  |  | 1,166 |  |
| Thereafter | — |  |  | 2,279 |  |
| Total minimum lease payments | 308 |  |  | $ | 17,472 |  |
| Less: Amounts representing interest | 14 |  |  |  |
| Present value of minimum lease payments | 294 |  |  |  |
| Less: Long-term portion | 140 |  |  |  |
| Current portion | $ | 154 |  |  |  |

[0001375365-19-000079:notes:16]
Rent expense for the fiscal years ended June 30, 2019, 2018 and 2017, was $6.7 million, $5.9 million and $5.0 million, respectively.

[0001375365-19-000079:notes:17]
Standby Letter of Credit - In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:ConsolidationPolicyTextBlock

[0001375365-19-000079:notes:18]
Basis of Presentation

[0001375365-19-000079:notes:19]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations, and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee. Prior to July 1, 2018, investments for which the Company was not able to exercise significant influence over the investee were accounted for under the cost method.

[0001375365-19-000079:notes:20]
Certain reclassifications have been made to the amounts for the fiscal year 2017 consolidated statement of operations and consolidated statement of cash flows in order to conform to the current year’s presentation.


## us-gaap:CostOfSalesPolicyTextBlock

[0001375365-19-000079:notes:21]
Cost of Sales

[0001375365-19-000079:notes:22]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or net realizable value and excess and obsolete inventory.


## us-gaap:DebtDisclosureTextBlock

[0001375365-19-000079:notes:23]
Short-term Debt

[0001375365-19-000079:notes:24]
Short-term debt obligations as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:25]
|  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | 1,116 |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | 1,116 |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,531 |  |  | 22,935 |  |
| Total short-term debt | $ | 23,647 |  |  | $ | 116,181 |  |

[0001375365-19-000079:notes:26]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000079:notes:27]
Bank of America

[0001375365-19-000079:notes:28]
2016 Bank of America Credit Facility

[0001375365-19-000079:notes:29]
In June 2016, the Company entered into a credit agreement with Bank of America (the “2016 Bank of America Credit Facility”). Prior to its maturity in April 2018, the Company repaid and terminated the 2016 Bank of America Credit Facility using the proceeds from its 2018 Bank of America Credit Facility (defined below). Immediately prior to its termination, the 2016 Bank of America Credit Facility (giving effect to all amendments since the inception of the 2016 Bank of America Credit Facility), provided for (i) a $85.0 million revolving line of credit including a $5.0 million letter of credit sublimit (ii) a $20.0 million revolving line of credit for the Company's Taiwan and the Netherlands entities, and (iii) a five-year $50.0 million term loan. The 2016 Bank of America Credit Facility term loan was secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan were payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the $85.0 million revolving line of credit was at the LIBOR rate plus 1.25% per annum. The interest rate of the $20.0 million revolving line of credit was equal to a minimum of 0.9% per annum plus the lender's cost of funds, as defined in the agreements.

[0001375365-19-000079:notes:30]
2018 Bank of America Credit Facility

[0001375365-19-000079:notes:31]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

[0001375365-19-000079:notes:32]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

[0001375365-19-000079:notes:33]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000079:notes:34]
As of June 30, 2019 and 2018 the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million and $67.3 million, respectively.  The interest rates under the 2018 Bank of America Credit Facility as of June 30, 2019 and 2018 were 4.5% per annum and 4.75% per annum, respectively.  As of June 30, 2019, a $3.2 million letter of credit was outstanding under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.3 million and $2.8 million as of June 30, 2019 and 2018, respectively.  As of June 30, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $245.7 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000079:notes:35]
CTBC Bank

[0001375365-19-000079:notes:36]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD $700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. The Company extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000079:notes:37]
In May 2017, the Company renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, the Company entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

[0001375365-19-000079:notes:38]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000079:notes:39]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000079:notes:40]
The total outstanding borrowings under the 2019 and 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.5 million and $22.9 million at June 30, 2019 and 2018, respectively. At June 30, 2019 , the Company did not have any outstanding balance under the 2019 CTBC Credit Facility revolving line of credit.  As of June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $25.9 million in U.S. dollars. The interest rate for these loans were 0.93% per annum as of June 30, 2019 and 0.95% per annum as of June 30, 2018. At June 30, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $27.5 million. As of June 30, 2019, the net book value of land and building located in Bade, Taiwan collateralizing the 2019 CTBC Credit Facility term loan was $25.8 million.

[0001375365-19-000079:notes:41]
Covenant Compliance

[0001375365-19-000079:notes:42]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000079:notes:43]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company is required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

[0001375365-19-000079:notes:44]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001375365-19-000079:notes:45]
Prepaid expenses and other current assets as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:46]
|  | June 30, |
|  | 2019 |  | 2018 |
| Receivables from vendors (1) | $ | 83,050 |  |  | $ | 93,003 |  |
| Restricted cash | 11,673 |  |  | 2,803 |  |
| Prepaid expenses | 7,269 |  |  | 6,321 |  |
| Deferred service costs | 3,374 |  |  | 2,920 |  |
| Others | 4,429 |  |  | 5,809 |  |
| Total prepaid expenses and other current assets | $ | 109,795 |  |  | $ | 110,856 |  |

[0001375365-19-000079:notes:47]
__________________________

[0001375365-19-000079:notes:48]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $82.0 million and $87.4 million as of June 30, 2019 and 2018, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-19-000079:notes:49]
The following is a summary of net sales by product type (in thousands):

[0001375365-19-000079:notes:50]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 2,858,644 |  |  | 81.7 | % |  | $ | 2,663,580 |  |  | 79.3 | % |  | $ | 1,740,633 |  |  | 70.0 | % |
| Subsystems and accessories | 641,716 |  |  | 18.3 | % |  | 696,912 |  |  | 20.7 | % |  | 744,296 |  |  | 30.0 | % |
| Total | $ | 3,500,360 |  |  | 100.0 | % |  | $ | 3,360,492 |  |  | 100.0 | % |  | $ | 2,484,929 |  |  | 100.0 | % |

[0001375365-19-000079:notes:51]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

[0001375365-19-000079:notes:52]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-19-000079:notes:53]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the fiscal years ended June 30, 2019, 2018 and 2017, of net sales by geographic region (in thousands):

[0001375365-19-000079:notes:54]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 2,032,948 |  |  | $ | 1,902,106 |  |  | $ | 1,422,667 |  |
| Asia | 712,211 |  |  | 762,701 |  |  | 500,956 |  |
| Europe | 611,014 |  |  | 547,507 |  |  | 453,798 |  |
| Other | 144,187 |  |  | 148,178 |  |  | 107,508 |  |
|  | $ | 3,500,360 |  |  | $ | 3,360,492 |  |  | $ | 2,484,929 |  |

[0001375365-19-000079:notes:55]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for fiscal years 2019, 2018 and 2017:

[0001375365-19-000079:notes:56]
|  | Years Ended June 30, |  | 2019 over 2018 |  | 2018 over 2017 |
|  | 2019 |  | 2018 |  | 2017 |  | % |  | % |
| Indirect sales channel | 39.3 | % |  | 41.5 | % |  | 47.8 | % |  | (2.2 | )% |  | (6.3 | )% |
| Direct customers and OEMs | 60.7 | % |  | 58.5 | % |  | 52.2 | % |  | 2.2 | % |  | 6.3 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-19-000079:notes:57]
Stock-based Compensation and Stockholders’ Equity

[0001375365-19-000079:notes:58]
Share Repurchase Program

[0001375365-19-000079:notes:59]
In July 2016, the Company’s Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100.0 million of the Company’s common stock in the open market or in private transactions during the following twelve months at prevailing market prices. In fiscal year 2017, the Company purchased 888,097 shares of the Company's common stock in the open market at a weighted average price of $20.79 for $18.5 million. Repurchases were made under the program using the Company’s cash resources. The repurchase program ended in July 2017.

[0001375365-19-000079:notes:60]
Equity Incentive Plan

[0001375365-19-000079:notes:61]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of the date the 2016 Plan became effective, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006 Plan"). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards have been or will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan at the time the 2016 Plan became effective, if those awards were or are forfeited at any time after the 2016 Plan became effective, will become available for use under the 2016 Plan. At the time the 2016 Plan became effective, all remaining ungranted shares under the 2006 Plan were canceled. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. Under the 2016 Plan, the Company granted PRSUs to its Chief Executive Officer, 50% of which vest based on the achievement of certain performance metrics at the end of the performance period while the remainder vest in equal amounts over the following ten quarters provided he continues to be employed by the Company. As of June 30, 2019, the Company had 843,917 authorized shares available for future issuance under the 2016 Plan.

[0001375365-19-000079:notes:62]
Determining Fair Value

[0001375365-19-000079:notes:63]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-19-000079:notes:64]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience.

[0001375365-19-000079:notes:65]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-19-000079:notes:66]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-19-000079:notes:67]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-19-000079:notes:68]
The fair value of stock option grants for the fiscal years ended June 30, 2019, 2018 and 2017 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-19-000079:notes:69]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Risk-free interest rate | 2.32% - 2.97% |  |  | 1.92% - 2.86% |  |  | 1.12% - 2.03% |  |
| Expected term | 6.05 years |  |  | 5.82 years |  |  | 5.31 - 5.38 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 47.34% - 50.28% |  |  | 45.32% - 48.07% |  |  | 43.36% - 49.64% |  |
| Weighted-average fair value | $ | 9.25 |  |  | $ | 10.98 |  |  | $ | 10.71 |  |

[0001375365-19-000079:notes:70]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2019, 2018 and 2017 (in thousands):

[0001375365-19-000079:notes:71]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Cost of sales | $ | 1,663 |  |  | $ | 1,812 |  |  | $ | 1,382 |  |
| Research and development | 12,981 |  |  | 13,893 |  |  | 12,559 |  |
| Sales and marketing | 1,805 |  |  | 1,980 |  |  | 2,144 |  |
| General and administrative | 4,735 |  |  | 6,971 |  |  | 3,580 |  |
| Stock-based compensation expense before taxes | 21,184 |  |  | 24,656 |  |  | 19,665 |  |
| Income tax impact | (4,349 | ) |  | (6,902 | ) |  | (5,946 | ) |
| Stock-based compensation expense, net | $ | 16,835 |  |  | $ | 17,754 |  |  | $ | 13,719 |  |

[0001375365-19-000079:notes:72]
Prior to adoption of ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options and vesting of RSUs and PRSUs in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Upon adoption of the new guidance on July 1, 2017, the cash flows from excess tax benefits related to such awards are classified as cash from operating activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. Prior to adoption of ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, the Company had $1.8 million of excess tax benefits recorded in additional paid-in capital in the fiscal year ended June 30, 2017 and had excess tax benefits classified as cash from financing activities of $2.3 million in the fiscal year ended June 30, 2017 for options issued since July 1, 2006. The Company adopted the accounting guidance on July 1, 2017 and as a result of the adoption, the Company recorded $0.5 million of excess tax benefit in income tax expense in the fiscal year ended June 30, 2018.

[0001375365-19-000079:notes:73]
As of June 30, 2019, $6.9 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.58 years, $31.5 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.77 years and $0.3 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 1.5 years.

[0001375365-19-000079:notes:74]
Stock Option Activity

[0001375365-19-000079:notes:75]
The following table summarizes stock option activity during the fiscal years ended June 30, 2019, 2018 and 2017 under all plans:

[0001375365-19-000079:notes:76]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2016 (7,495,131 shares exercisable at weighted average exercise price of $13.35 per share) |  | 8,960,867 |  |  | 14.88 |  |  |  |  |  |
| Granted |  | 473,000 |  |  | 24.27 |  |  |  |  |  |
| Exercised |  | (1,007,065 | ) |  | 10.80 |  |  |  |  |  |
| Forfeited/Cancelled |  | (51,143 | ) |  | 17.96 |  |  |  |  |  |
| Balance as of June 30, 2017 (7,348,320 shares exercisable at weighted average exercise price of $14.58 per share) |  | 8,375,659 |  |  | 15.88 |  |  |  |  |  |
| Granted |  | 489,705 |  |  | 23.58 |  |  |  |  |  |
| Exercised |  | (267,970 | ) |  | 11.36 |  |  |  |  |  |
| Forfeited/Cancelled |  | (296,256 | ) |  | 15.36 |  |  |  |  |  |
| Balance as of June 30, 2018 (7,563,189 shares exercisable at weighted average exercise price of $15.71 per share) |  | 8,301,138 |  |  | 16.50 |  |  |  |  |  |
| Granted |  | 434,320 |  |  | 18.58 |  |  |  |  |  |
| Forfeited/Cancelled |  | (1,360,823 | ) |  | 8.94 |  |  |  |  |  |
| Balance as of June 30, 2019 (6,624,009 shares exercisable at weighted average exercise price of $17.65 per share) |  | 7,374,635 |  |  | 18.02 |  |  | 3.82 |  | $ | 25,798 |  |
| Options vested and exercisable at June 30, 2019 |  | 6,624,009 |  |  | 17.65 |  |  | 3.27 |  | $ | 24,811 |  |

[0001375365-19-000079:notes:77]
No options were exercised in the fiscal year ended June 30, 2019. The total pretax intrinsic value of options exercised during the fiscal years ended June 30, 2018 and 2017 was $4.0 million and $14.0 million, respectively. Additional information regarding options outstanding as of June 30, 2019, is as follows:

[0001375365-19-000079:notes:78]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $7.94 - $10.35 |  | 897,340 |  |  | 2.15 |  | $ | 9.20 |  |  | 897,340 |  |  | $ | 9.20 |  |
| 10.68 - 12.50 |  | 805,871 |  |  | 2.04 |  | 11.79 |  |  | 805,871 |  |  | 11.79 |  |
| 12.68 - 13.67 |  | 752,762 |  |  | 2.60 |  | 13.34 |  |  | 639,772 |  |  | 13.39 |  |
| 14.23 - 15.22 |  | 869,966 |  |  | 3.26 |  | 14.69 |  |  | 827,076 |  |  | 14.68 |  |
| 15.54 - 17.96 |  | 857,451 |  |  | 3.50 |  | 17.47 |  |  | 812,830 |  |  | 17.47 |  |
| 18.59 - 20.54 |  | 804,519 |  |  | 3.10 |  | 18.95 |  |  | 789,758 |  |  | 18.92 |  |
| 20.70 - 24.70 |  | 844,988 |  |  | 7.06 |  | 22.12 |  |  | 455,083 |  |  | 21.72 |  |
| 25.40 - 26.75 |  | 842,984 |  |  | 4.60 |  | 26.00 |  |  | 836,830 |  |  | 26.00 |  |
| 26.95 - 37.06 |  | 663,254 |  |  | 6.51 |  | 30.29 |  |  | 523,949 |  |  | 31.00 |  |
| 39.19 |  | 35,500 |  |  | 4.50 |  | 39.19 |  |  | 35,500 |  |  | 39.19 |  |
| $7.94 - $39.19 |  | 7,374,635 |  |  | 3.82 |  | $ | 18.02 |  |  | 6,624,009 |  |  | $ | 17.65 |  |

[0001375365-19-000079:notes:79]
RSU and PRSU Activity

[0001375365-19-000079:notes:80]
In January 2015, the Company began to grant RSUs to employees. The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting.

[0001375365-19-000079:notes:81]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. The first award was a one-year PRSU and the second award was a two-year PRSU. The one-year PRSUs would be earned based on the Company’s performance as it relates to a revenue growth metric and a minimum non-GAAP operating margin metric during the fiscal year ended June 30, 2018 with eligibility up to 200% of the targeted number of units based on revenue growth if the minimum non-GAAP operating margin is achieved. If the performance metrics were met, 50% of the PRSUs would vest at June 30, 2018 while the remainder would vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors determined that the Company achieved the revenue and non-GAAP operating margin metrics for the fiscal year ended June 30, 2018 at a level that entitled the Chief Executive Officer to 200% of the originally targeted number of shares subject to the one-year PRSU. 50% of the PRSUs so earned were vested as of June 30, 2018, and an additional 20% of the PRSUs vested during the four quarters ended June 30, 2019, in accordance with the terms of the grant.

[0001375365-19-000079:notes:82]
The two-year PRSUs would be earned based on the Company’s performance for the average non-GAAP operating margin metric for the two fiscal years ended June 30, 2019 with eligibility up to 100% of the targeted number of units. If the performance metrics would have been met, 50% of the PRSUs would have vested at June 30, 2019 while the remainder would have been vested in equal amounts over the following ten quarters if the Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors has determined that the Company did not achieve the required performance metrics for these two-year PRSUs to be earned and, consequently, this PRSU terminated in December 2019.

[0001375365-19-000079:notes:83]
The following table summarizes RSUs and PRSUs activity during the fiscal years ended June 30, 2019 and 2018 under all plans:

[0001375365-19-000079:notes:84]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUs Outstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2016 |  | 926,983 |  |  | $ | 30.23 |  |  | — |  |  |  |  |
| Granted |  | 808,020 |  |  | 23.73 |  |  | — |  |  |  |  |
| Released |  | (411,739 | ) |  | 27.41 |  |  | — |  |  |  |  |
| Forfeited |  | (96,907 | ) |  | 26.40 |  |  | — |  |  |  |  |
| Balance as of June 30, 2017 |  | 1,226,357 |  |  | 26.11 |  |  | — |  |  |  |  |
| Granted |  | 986,680 |  |  | 21.90 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Released (2) |  | (572,789 | ) |  | 26.34 |  |  | — |  |  |  |  |
| Forfeited |  | (159,643 | ) |  | 24.90 |  |  | — |  |  |  |  |
| Balance as of June 30, 2018 |  | 1,480,605 |  |  | 23.34 |  |  | 120,000 |  |  |  | 27.10 |  |
| Granted |  | 1,086,911 |  |  | 18.37 |  |  | — |  |  |  |  |
| Released (2) |  | (549,886 | ) |  | 24.87 |  |  | — |  |  |  |  |
| Forfeited |  | (144,528 | ) |  | 20.25 |  |  | — |  |  |  |  |
| Balance as of June 30, 2019 |  | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  |  |  | $ | 27.10 |  |

[0001375365-19-000079:notes:85]
| (1) | Reflects the number of PRSUs that have been earned based on the achievement of performance metrics. |

[0001375365-19-000079:notes:86]
| (2) | The number of shares released excludes 172,857 RSUs that were vested but not released in fiscal year 2019. The number of shares released also excludes 24,000 and 60,000 PRSUs that were vested but not released in fiscal years 2019 and 2018, respectively. These vested RSUs and PRSUs will be released upon the effectiveness of the Company's registration statement on Form S-8. |

[0001375365-19-000079:notes:87]
The total pretax intrinsic value of RSUs and PRSUs vested was $14.3 million, $16.8 million and $11.3 million for the fiscal years ended June 30, 2019, 2018 and 2017, respectively. In fiscal years 2019, 2018 and 2017, upon vesting and release, 549,886, 572,789 and 411,739 shares of RSUs were partially net share-settled such that the Company withheld 175,044, 199,715 and 144,994 shares, respectively, with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to tax authorities were$3.1 million, $4.5 million and $3.6 million for the fiscal years ended June 30, 2019, 2018 and 2017, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001375365-19-000079:notes:88]
Net Income Per Common Share

[0001375365-19-000079:notes:89]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested RSUs. Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-19-000079:notes:90]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001375365-19-000079:notes:91]
Investment in a Corporate Venture

[0001375365-19-000079:notes:92]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of June 30, 2019 and June 30, 2018, the Company's equity investment in the Corporate Venture was $1.7 million and $2.4 million, respectively, and was recorded under investment in equity investee on the Company's consolidated balance sheet. The Company's share of losses of the Corporate Venture were $2.7 million, $3.6 million, and $0.3 million for the fiscal years ended June 30, 2019, June 30, 2018, and June 30, 2017, respectively.

[0001375365-19-000079:notes:93]
The Company recorded a deferred gain related to the contribution of certain technology rights of $7.0 million in the third fiscal quarter of 2017. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled.

[0001375365-19-000079:notes:94]
As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of June 30, 2019 and 2018, the Company had unamortized deferred gain balance of $2.0 million and $1.4 million, respectively, in accrued liabilities and $3.0 million and $3.5 million, respectively, in other long-term liabilities in the Company’s consolidated balance sheets.

[0001375365-19-000079:notes:95]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the fiscal years being presented.

[0001375365-19-000079:notes:96]
Additionally, the Company sold products worth $52.2 million, $21.7 million, $10.9 million to the Corporate Venture in the fiscal years 2019, 2018, 2017, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of June 30, 2019 and June 30, 2018 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $13.1 million and $2.9 million due from the Corporate Venture in accounts receivable, net as of June 30, 2019 and 2018, respectively, in its consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001375365-19-000079:notes:97]
The following table sets forth the Company’s cash equivalents, certificates of deposit and investment in auction rate security as of June 30, 2019 and 2018 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-19-000079:notes:98]
| June 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,162 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,162 |  |
| Certificates of deposit (2) | — |  |  | 1,285 |  |  | — |  |  | 1,285 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,162 |  |  | $ | 1,285 |  |  | $ | 1,571 |  |  | $ | 4,018 |  |
| June 30, 2018 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,136 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,136 |  |
| Certificates of deposit (2) | — |  |  | 30,219 |  |  | — |  |  | 30,219 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,136 |  |  | $ | 30,219 |  |  | $ | 1,571 |  |  | $ | 32,926 |  |

[0001375365-19-000079:notes:99]
(1) $0.4 million and $0.3 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2019 and 2018, respectively.

[0001375365-19-000079:notes:100]
(2) $0.2 million and $29.2 million in certificates of deposit are included in cash and cash equivalents and $1.1 million and $1.0 million in certificates of deposit are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2019 and 2018, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001375365-19-000079:notes:101]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of auction rate securities, using significant unobservable inputs (Level 3) for fiscal years 2019 and 2018 (in thousands):

[0001375365-19-000079:notes:102]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |
| Balance as of the beginning of the fiscal year | $ | 1,571 |  |  | $ | 2,625 |  |
| Sales and settlements at par | — |  |  | (1,000 | ) |
| Total unrealized loss included in other comprehensive income | — |  |  | (54 | ) |
| Balance as of the end of the fiscal year | $ | 1,571 |  |  | $ | 1,571 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-19-000079:notes:103]
Fair Value Disclosure

[0001375365-19-000079:notes:104]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and other assets. The Company classifies its cash equivalents and other assets, except for its investment in an auction rate security, within Level 1 or Level 2  in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of June 30, 2019 and 2018. See Note 1, "Organization and Summary of Significant Accounting Policies", for a discussion of the Company’s policies regarding the fair value hierarchy. The Company used discounted cash flows to estimate the fair value of the auction rate security as of June 30, 2019 and 2018. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-19-000079:notes:105]
Financial Assets and Liabilities Measured on a Recurring Basis

[0001375365-19-000079:notes:106]
The above table excludes $247.6 million and $85.9 million of cash included in cash and cash equivalents, $11.7 million and $2.8 million of restricted cash included in prepaid expenses and other current assets, and $0.4 million and $0.4 million of restricted cash, non-current included in other assets in the consolidated balance sheets as of June 30, 2019 and 2018, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in fiscal years 2019 and 2018.

[0001375365-19-000079:notes:107]
The following is a summary of the Company’s investment in an auction rate security as of June 30, 2019 and 2018 (in thousands):

[0001375365-19-000079:notes:108]
|  | June 30, 2019 and 2018 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-19-000079:notes:109]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2019 and 2018, total debt of $23.6 million and $116.2 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-19-000079:notes:110]
Financial Assets Measured on a Non-recurring Basis

[0001375365-19-000079:notes:111]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values. Prior to July 1, 2018, the Company accounted for its investment in non-marketable equity securities at cost less impairment. Realized gains and losses on non-marketable equity securities sold or impaired were recognized in other income (expense), net. Upon adoption of the new guidance, Financial Instruments - Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, on July 1, 2018, the Company classifies its investment in non-marketable equity instruments as Level 3 as the fair value is determined using significant unobservable inputs. During the fiscal year ended June 30, 2019 the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities. During fiscal year 2019, the Company recorded impairment charges of $2.7 million for its non-marketable equity securities which had an initial cost basis of $2.7 million as it was determined the carrying value of the investments were not recoverable. During fiscal years 2018 and 2017, the Company did not record any other-than-temporary impairments on financial assets required to be measured at fair value on a non-recurring basis.

[0001375365-19-000079:notes:112]
There were no transfers of financial assets measured on a non-recurring basis between Level 1, Level 2 or Level 3 securities in fiscal years 2019, 2018 and 2017.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001375365-19-000079:notes:113]
Foreign Currency Transactions

[0001375365-19-000079:notes:114]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, with the exception of Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in foreign currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the foreign currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the foreign currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations in other expense, net.

[0001375365-19-000079:notes:115]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD$”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-19-000079:notes:116]
The functional currency of the Company's equity method investee is the local currency. Adjustments for the Company's share of the effects of foreign currency translation from local currency to U.S. dollars are recorded as increases or decreases to the carrying value of the investment and included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001375365-19-000079:notes:117]
Long-Lived Assets

[0001375365-19-000079:notes:118]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-19-000079:notes:119]
Income Taxes

[0001375365-19-000079:notes:120]
The components of income before income tax provision for the fiscal years ended June 30, 2019, 2018 and 2017 are as follows (in thousands):

[0001375365-19-000079:notes:121]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 45,126 |  |  | $ | 39,394 |  |  | $ | 82,078 |  |
| Foreign | 44,397 |  |  | 48,821 |  |  | 9,513 |  |
| Income before income tax provision | $ | 89,523 |  |  | $ | 88,215 |  |  | $ | 91,591 |  |

[0001375365-19-000079:notes:122]
The income tax provision for the fiscal years ended June 30, 2019, 2018 and 2017, consists of the following (in thousands):

[0001375365-19-000079:notes:123]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |
| Federal | $ | 12,308 |  |  | $ | 11,090 |  |  | $ | 26,033 |  |
| State | 2,917 |  |  | 815 |  |  | 695 |  |
| Foreign | 16,531 |  |  | 12,984 |  |  | 4,001 |  |
|  | 31,756 |  |  | 24,889 |  |  | 30,729 |  |
| Deferred: |  |  |  |  |  |
| Federal | (13,078 | ) |  | 14,304 |  |  | (6,782 | ) |
| State | (2,888 | ) |  | 265 |  |  | 353 |  |
| Foreign | (906 | ) |  | (1,015 | ) |  | 134 |  |
|  | (16,872 | ) |  | 13,554 |  |  | (6,295 | ) |
| Income tax provision | $ | 14,884 |  |  | $ | 38,443 |  |  | $ | 24,434 |  |

[0001375365-19-000079:notes:124]
The Company’s net deferred tax assets as of June 30, 2019 and 2018 consist of the following (in thousands):

[0001375365-19-000079:notes:125]
|  | June 30, |
|  | 2019 |  | 2018 |
| R&D credit | $ | 20,858 |  |  | $ | 16,281 |  |
| Deferred revenue | 18,963 |  |  | 10,347 |  |
| Inventory valuation | 11,856 |  |  | 7,354 |  |
| Stock-based compensation | 6,080 |  |  | 5,119 |  |
| Accrued vacation and bonus | 2,681 |  |  | 2,276 |  |
| Warranty accrual | 1,948 |  |  | 1,669 |  |
| Marketing fund accrual | 554 |  |  | 678 |  |
| Other | 4,559 |  |  | 3,644 |  |
| Total deferred income tax assets | 67,499 |  |  | 47,368 |  |
| Deferred tax liabilities-depreciation and other | (5,406 | ) |  | (5,504 | ) |
| Valuation allowance | (20,967 | ) |  | (16,281 | ) |
| Deferred income tax assets, net | 41,126 |  |  | 25,583 |  |

[0001375365-19-000079:notes:126]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2019, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of California R&D tax credits that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2019, the gross excess credits of $26.4 million, or net of federal tax benefit of $20.9 million, are subject to a full valuation allowance. At June 30, 2018, the gross excess credits of $20.5 million, or net of federal tax benefit of $16.2 million, are subject to a full valuation allowance. The change in valuation allowance from 2018 to 2019 is $4.7 million. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2019 and 2018 was $41.1 million and $25.6 million, respectively.

[0001375365-19-000079:notes:127]
In December 2017, the U.S. federal government enacted the 2017 Tax Reform Act. The 2017 Tax Reform Act reduced the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a one-time transition tax on foreign earnings of U.S. subsidiaries that were not previously subject to U.S. income tax. Under U.S. GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. As a result, the Company has completed its analysis and has recorded a one-time $12.9 million, net write down of its U.S. deferred tax assets and liabilities resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and a one-time transition tax of $2.8 million, in its income tax provision for the fiscal year ended June 30, 2018. The Company expects further guidance may be forthcoming from the federal and state tax agencies, which could result in additional impacts.

[0001375365-19-000079:notes:128]
The 2017 Tax Reform Act also creates a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) that must be included currently in the gross income of a CFC’s U.S. stockholder starting in the tax year that begins after 2017. The tax impact from GILTI has been recorded in the Company's income tax provision for the fiscal year ended June 30, 2019, net of foreign tax credit, and is not material to the Company's income tax provision for the fiscal year ended June 30, 2019.

[0001375365-19-000079:notes:129]
Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into a company’s measurement of its deferred taxes. The Company's selection of an accounting policy for the fiscal year ended June 30, 2018 with respect to the GILTI tax rules is to treat GILTI tax as a current period expense under the period cost method.

[0001375365-19-000079:notes:130]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. The Company previously asserted that all of its foreign undistributed earnings were indefinitely reinvested. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for Netherlands. The Company may repatriate foreign earnings from Netherlands which are previously taxed income as a result of the 2017 Tax Reform Act. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-19-000079:notes:131]
The following is a reconciliation for the fiscal years ended June 30, 2019, 2018 and 2017, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-19-000079:notes:132]
|  |  | Years Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Tax at statutory rate |  | 21.0 | % |  | 28.1 | % |  | 35.0 | % |
| Uncertain tax positions |  | 2.5 |  |  | 6.3 |  |  | (7.6 | ) |
| Stock-based compensation |  | 2.1 |  |  | 1.8 |  |  | 2.5 |  |
| Settlement with tax authority |  | 1.6 |  |  | — |  |  | 2.0 |  |
| Foreign tax rate differences |  | 1.1 |  |  | (6.0 | ) |  | 0.8 |  |
| State income tax, net of federal tax benefit |  | 0.5 |  |  | (0.1 | ) |  | 4.6 |  |
| Tax reform related |  | — |  |  | 17.9 |  |  | — |  |
| Qualified production activity deduction |  | — |  |  | (1.3 | ) |  | (3.0 | ) |
| Foreign withholding tax |  | — |  |  | — |  |  | 1.1 |  |
| Federal provision true-up |  | (1.6 | ) |  | 1.5 |  |  | 0.1 |  |
| Subpart F income inclusion |  | (2.1 | ) |  | 0.7 |  |  | — |  |
| Research and development tax credit |  | (9.5 | ) |  | (8.7 | ) |  | (9.4 | ) |
| Other |  | 1.0 |  |  | 3.4 |  |  | 0.6 |  |
| Effective tax rate |  | 16.6 | % |  | 43.6 | % |  | 26.7 | % |

[0001375365-19-000079:notes:133]
As of June 30, 2019, the Company had state research and development tax credit carryforwards of $34.3 million. The state research and development tax credits will carryforward indefinitely to offset future state income taxes.

[0001375365-19-000079:notes:134]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-19-000079:notes:135]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2016 | $ | 19,395 |  |
| Gross increases: |  |
| For current year’s tax positions | 5,732 |  |
| For prior years’ tax positions | 1,119 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (7,029 | ) |
| Balance at June 30, 2017 | 19,217 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,864 |  |
| For prior years’ tax positions | — |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (964 | ) |
| Balance at June 30, 2018 | 25,117 |  |
| Gross increases: |  |
| For current year’s tax positions | 7,789 |  |
| For prior years’ tax positions | — |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (4,858 | ) |
| Balance at June 30, 2019 | $ | 28,048 |  |

[0001375365-19-000079:notes:136]
________________________

[0001375365-19-000079:notes:137]
*excludes interest, penalties, federal benefit of state reserves

[0001375365-19-000079:notes:138]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $18.6 million and $16.6 million as of June 30, 2019 and 2018, respectively.

[0001375365-19-000079:notes:139]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes in the consolidated statements of operations. As of June 30, 2019 and 2018, the Company had accrued $1.5 million and $1.3 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively.

[0001375365-19-000079:notes:140]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and intends to pay the $1.6 million tax liability in January 2020. The impact of this adjustment on the income statement will be offset by the release of previously unrecognized tax benefits related to the fiscal year audited in the period in which the proposed adjustment was accepted.

[0001375365-19-000079:notes:141]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made as or the underlying matters are settled or otherwise resolved.

[0001375365-19-000079:notes:142]
The federal statute of limitations remains open in general for tax years ended June 30, 2016 through 2019. Various states statute of limitations remain open in general for tax years ended June 30, 2015 through 2019. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2013 through 2019. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.8 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0001375365-19-000079:notes:143]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-19-000079:notes:144]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.


## us-gaap:InventoryDisclosureTextBlock

[0001375365-19-000079:notes:145]
Inventories

[0001375365-19-000079:notes:146]
Inventories as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:147]
|  | June 30, |
|  | 2019 |  | 2018 |
| Finished goods | $ | 492,387 |  |  | $ | 633,348 |  |
| Work in process | 43,598 |  |  | 61,162 |  |
| Purchased parts and raw materials | 134,203 |  |  | 158,742 |  |
| Total inventories | $ | 670,188 |  |  | $ | 853,252 |  |

[0001375365-19-000079:notes:148]
During fiscal years 2019, 2018 and 2017, the Company recorded a provision for excess and obsolete inventory to cost of sales totaling $28.5 million, $9.4 million and $15.7 million, respectively, excluding a provision for adjusting the cost of certain inventories to net realizable value of $4.4 million in fiscal year 2019. The adjustment for lower of cost or net realizable value and lower of cost or market was not material in fiscal years 2018 and 2017.


## us-gaap:InventoryPolicyTextBlock

[0001375365-19-000079:notes:149]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped. Prior to July 1, 2017, inventories were stated at weighted-average cost, subject to lower of cost or market.

[0001375365-19-000079:notes:150]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001375365-19-000079:notes:151]
Leases

[0001375365-19-000079:notes:152]
Leases are evaluated and recorded as capital leases if one of the following is true at inception: (a) the present value of minimum lease payments meets or exceeds 90% of the fair value of the asset, (b) the lease term is greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contains a bargain purchase option, or (d) title to the property transfers to the Company at the end of the lease. The Company records an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets are depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability are accounted for using the effective interest method.

[0001375365-19-000079:notes:153]
Leases that are not classified as capital leases are accounted for as operating leases. Operating lease agreements that have tenant improvement allowances are evaluated for lease incentives. For leases that contain escalating rent payments, the Company recognizes rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-19-000079:notes:154]
Accounts Receivable Allowances

[0001375365-19-000079:notes:155]
The Company has established an allowance for doubtful accounts. The allowance for doubtful accounts is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2019, 2018 and 2017 consisted of the following (in thousands):


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001375365-19-000079:notes:156]
Accounting Pronouncements Recently Adopted

[0001375365-19-000079:notes:157]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, ASC 606, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to ASC 606. The Company adopted ASC 606 on July 1, 2018 using the modified retrospective method. In connection with the adoption of ASC 606, the Company recorded a transition adjustment to increase retained earnings by $6.8 million as of July 1, 2018. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

[0001375365-19-000079:notes:158]
The primary impact of the adoption of ASC 606 was the acceleration of revenue recognition for (i) sales to distributors where the Company previously accounted for such sales on a sell-through basis and (ii) software arrangements. The following tables summarize the impacts of the adoption of ASC 606 on the Company’s consolidated financial statements. The adoption of ASC 606 did not have any impact on the net cash provided by operating activities.

[0001375365-19-000079:notes:159]
Selected Captions from the Consolidated Balance Sheet as of June 30, 2019 (in thousands)

[0001375365-19-000079:notes:160]
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| ASSETS |  |  |  |  |  |
| Accounts receivable, net of allowances | $ | 393,624 |  |  | $ | (21,404 | ) |  | $ | 372,220 |  |
| Inventories | 670,188 |  |  | 14,823 |  |  | 685,011 |  |
| Prepaid expenses and other current assets | 109,795 |  |  | (2,478 | ) |  | 107,317 |  |
| Deferred income taxes, net | 41,126 |  |  | 1,131 |  |  | 42,257 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Accrued liabilities | $ | 114,678 |  |  | $ | (6,392 | ) |  | $ | 108,286 |  |
| Deferred revenue | 94,153 |  |  | 2,611 |  |  | 96,764 |  |
| Income taxes payable | 13,021 |  |  | (831 | ) |  | 12,190 |  |
| Deferred revenue, non-current | 109,266 |  |  | 3,992 |  |  | 113,258 |  |
| Retained earnings | 611,903 |  |  | (7,308 | ) |  | 604,595 |  |

[0001375365-19-000079:notes:161]
Selected Captions from the Consolidated Statement of Operations for the year ended June 30, 2019 (in thousands)

[0001375365-19-000079:notes:162]
|  | As reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Net sales | $ | 3,500,360 |  |  | $ | 12,591 |  |  | $ | 3,512,951 |  |
| Cost of sales | 3,004,838 |  |  | 15,981 |  |  | 3,020,819 |  |
| Gross profit | 495,522 |  |  | (3,390 | ) |  | 492,132 |  |
| General and administrative | 141,228 |  |  | (2,491 | ) |  | 138,737 |  |
| Income before income tax provision | 89,523 |  |  | (899 | ) |  | 88,624 |  |
| Income tax provision | 14,884 |  |  | (404 | ) |  | 14,480 |  |
| Net income | 71,918 |  |  | (495 | ) |  | 71,423 |  |

[0001375365-19-000079:notes:163]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the existing guidance under which an entity must measure inventory at the lower of cost or market. The Company adopted the accounting guidance on July 1, 2017. The effect of the adoption had no impact on the consolidated financial statements and related disclosures.

[0001375365-19-000079:notes:164]
In January 2016, the FASB issued new guidance, Financial Instruments - Overall: Recognition and Measurement of Financial Assets and Financial Liabilities. This guidance changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of equity investments not accounted for under the equity method to be recorded at fair value through the consolidated statement of operations at the end of each reporting period.  The Company adopted this accounting standard update as of July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements. As a result of the adoption of the new standard, the Company’s equity investments are accounted for as follows:

[0001375365-19-000079:notes:165]
| • | Marketable equity securities that have a readily determinable fair value are measured and recorded at fair value. |

[0001375365-19-000079:notes:166]
| • | Non-marketable equity securities that do not have a readily determinable fair value and for which the Company does not control the investee nor is it able to exert significant influence over the investee are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. |

[0001375365-19-000079:notes:167]
| • | Equity method investments are equity securities for which the Company does not control the investee but is able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus the Company's share of equity method investee income or loss. |

[0001375365-19-000079:notes:168]
In March 2016, the FASB issued new accounting guidance, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. Early adoption is permitted for any interim or annual periods. The Company adopted the accounting guidance on July 1, 2017 that resulted in the recognition of excess tax benefits in the Company's provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of its change in forfeiture policy. The new guidance eliminated the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. The new guidance also requires the Company to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise.  As a result of the adoption, the Company recorded a reduction in income tax payable of $0.2 million, an increase in common stock and additional paid-in capital of $0.1 million and an increase in retained earnings of $0.1 million.

[0001375365-19-000079:notes:169]
In March 2016, the FASB issued new accounting guidance Investments - Equity Method and Joint Ventures: Simplifying the Transition to Equity Method of Accounting. The amendments in this update eliminate the requirement that an entity retroactively adopt the equity method of accounting if an investment qualifies for use of the equity method as a result of increase in ownership interest or degree of influence. In accordance with the amendments, an equity method investor will begin to apply the equity method when the investor obtains significant influence without having to retroactively adjust the investment and record a cumulative catch up for the years when the investment did not qualify for the equity method of accounting. The Company adopted the accounting guidance on July 1, 2017. The result of the adoption had no impact on the consolidated financial statements and related disclosures.

[0001375365-19-000079:notes:170]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated statements of cash flows.

[0001375365-19-000079:notes:171]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements and related disclosures.

[0001375365-19-000079:notes:172]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The Company adopted the accounting guidance on July 1, 2018 using a retrospective transition method to each period presented. The adoption did not have a material impact on the consolidated statements of cash flows. Presentation of prior period information has been retrospectively adjusted.

[0001375365-19-000079:notes:173]
In February 2017, the FASB issued new accounting guidance, Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets: Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets. This guidance clarifies the scope and application on the sale or transfer of nonfinancial assets and in substance nonfinancial assets to noncustomers, including partial sales. The Company adopted this guidance on July 1, 2018. Prior to adoption, the Company had previously contributed certain technology rights in exchange for 30% ownership in a privately-held company (the “Corporate Venture”) and accounted for the transaction in accordance with the guidance related to exchanges of a nonfinancial asset for a noncontrolling ownership interest in ASC 845 - Nonmonetary Transactions, which has been eliminated by the new guidance. As a result of the adoption of the new guidance, the Company recognized $3.0 million increase in the carrying value of the equity-method investment, a $2.1 million increase in deferred gain, and a $0.9 million increase in retained earnings.

[0001375365-19-000079:notes:174]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018. The SEC staff subsequently indicated that it would not object if a filer’s first presentation of changes in stockholders’ equity is included in its Form 10-Q for the quarter that begins after the final rule’s effective date. Among the amendments is the requirement to present the changes in stockholders’ equity in the interim financial statements (either in a separate statement or footnote) in Quarterly Reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The Company adopted this guidance in the first quarter of fiscal year 2019, and presented the changes in stockholders’ equity in the Company’s Quarterly Reports on Form 10-Q for the first, second, and third quarters of fiscal year 2019.

[0001375365-19-000079:notes:175]
Accounting Pronouncements Not Yet Adopted

[0001375365-19-000079:notes:176]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. Since its issuance, the FASB has issued several amendments to the new lease standard. The standard is effective for the Company from July 1, 2019 and the Company will apply this standard using the modified retrospective approach and will not restate prior comparative periods.  The Company will elect the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new standard its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease guidance. While the Company is currently finalizing its implementation of new policies, processes and internal controls to comply with the new rules, it is anticipated that the adoption of the new standard will result in the recognition of right-of-use assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, as of July 1, 2019, primarily related to real estate leases. The adoption of the new standard will not have a material impact on the Company’s consolidated statement of operations or consolidated statement of cash flows.

[0001375365-19-000079:notes:177]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000079:notes:178]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election and is effective for the Company from July 1, 2019. The adoption of the guidance will not have a material impact on its consolidated financial statements.

[0001375365-19-000079:notes:179]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The new amendment is effective for the Company from July 1, 2019. The adoption of the new standard will not have a material impact on its consolidated financial statements and related disclosures.

[0001375365-19-000079:notes:180]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the Concepts Statement, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

[0001375365-19-000079:notes:181]
In August 2018, the FASB issued amended guidance to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-19-000079:notes:182]
Organization and Summary of Significant Accounting Policies

[0001375365-19-000079:notes:183]
Organization

[0001375365-19-000079:notes:184]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

[0001375365-19-000079:notes:185]
Use of Estimates

[0001375365-19-000079:notes:186]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates.

[0001375365-19-000079:notes:187]
Fair Value of Financial Instruments

[0001375365-19-000079:notes:188]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-19-000079:notes:189]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001375365-19-000079:notes:190]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001375365-19-000079:notes:191]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001375365-19-000079:notes:192]
Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposit and investments in auction rate securities are carried at fair value. Short-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms.

[0001375365-19-000079:notes:193]
Cash and Cash Equivalents

[0001375365-19-000079:notes:194]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months.

[0001375365-19-000079:notes:195]
Restricted Cash and Cash Equivalents

[0001375365-19-000079:notes:196]
Restricted cash is comprised of amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to the Company’s workers’ compensation program. These restricted cash balances have been excluded from the Company's cash and cash equivalents balance.

[0001375365-19-000079:notes:197]
Investments in Auction Rate Securities

[0001375365-19-000079:notes:198]
The Company classifies its investments in auction rate securities ("auction rate securities") as non-current available-for-sale investments. The auction rate securities consist of municipal securities, which are debt securities. The Company uses discounted cash flow to estimate the fair value of any auction rate securities. These auction rate securities are recorded within other assets in the consolidated balance sheets at fair value. Unrealized gains and losses on auction rate securities are included as a component of accumulated other comprehensive (loss) income, net of tax.

[0001375365-19-000079:notes:199]
Property, Plant and Equipment

[0001375365-19-000079:notes:200]
For assets acquired and financed under capital leases, the present value of the future minimum lease payments is recorded at the date of acquisition as property, plant and equipment with the corresponding amount recorded as a capital lease obligation, and the amortization is computed on a straight-line basis over the shorter of the lease term or estimated useful life.

[0001375365-19-000079:notes:201]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge for long-lived assets has been recorded in any of the periods presented.

[0001375365-19-000079:notes:202]
Revenue Recognition

[0001375365-19-000079:notes:203]
The Company’s revenue recognition policy and related disclosures are discussed in Note 3, “Revenue.”

[0001375365-19-000079:notes:204]
Allowances for Doubtful Accounts

[0001375365-19-000079:notes:205]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer concentrations, customer-credit-worthiness, and current economic trends to evaluate the adequacy of the allowance for doubtful accounts. The Company's provision for (recovery of) bad debt was $7.1 million, $(0.1) million, and $0.3 million in fiscal years 2019, 2018 and 2017, respectively.

[0001375365-19-000079:notes:206]
Product Warranties

[0001375365-19-000079:notes:207]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, under recently adopted guidance, Revenue from Contracts with Customers, (“ASC 606”), these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2019, 2018 and 2017, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-19-000079:notes:208]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Balance, beginning of the year | $ | 9,884 |  |  | $ | 7,721 |  |  | $ | 7,129 |  |
| Provision for warranty | 22,991 |  |  | 20,868 |  |  | 21,642 |  |
| Costs utilized | (26,281 | ) |  | (19,904 | ) |  | (21,256 | ) |
| Change in estimated liability for pre-existing warranties | 4,440 |  |  | 1,199 |  |  | 206 |  |
| Balance, end of the year | $ | 11,034 |  |  | $ | 9,884 |  |  | $ | 7,721 |  |
| Current portion | 8,661 |  |  | 7,589 |  |  | 5,976 |  |
| Non-current portion | $ | 2,373 |  |  | $ | 2,295 |  |  | $ | 1,745 |  |

[0001375365-19-000079:notes:209]
Research and Development

[0001375365-19-000079:notes:210]
Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $2.8 million, $6.1 million, and $10.3 million for the fiscal years ended June 30, 2019, 2018 and 2017, respectively.

[0001375365-19-000079:notes:211]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-19-000079:notes:212]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred. Total advertising and promotional expenses were $2.4 million, $3.5 million, and $5.4 million for the fiscal years ended June 30, 2019, 2018 and 2017, respectively.

[0001375365-19-000079:notes:213]
Stock-Based Compensation

[0001375365-19-000079:notes:214]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options and restricted stock units ("RSUs"). The share-based awards granted to non-employees have not been material to date. The Company is required to estimate the fair value of share-based awards on the date of grant. The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Prior to July 1, 2017, the Company estimated forfeitures and expensed the value of awards that were ultimately expected to vest over the requisite service periods. The fair value of RSUs with service conditions or performance conditions is based on the closing market price of the Company's common stock on the date of grant. The fair value for RSUs with service conditions, or time-based RSUs, is amortized on a straight-line basis over the requisite service period. The fair value for RSUs with performance conditions ("PRSUs") is recognized on a ratable basis over the requisite service period when it is probable the performance conditions of the awards will be met. The Company reassesses the probability of vesting at each reporting period and adjusts the total compensation expense of the award based on this probability assessment.

[0001375365-19-000079:notes:215]
The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the implied and historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000079:notes:216]
Variable Interest Entities

[0001375365-19-000079:notes:217]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-19-000079:notes:218]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-19-000079:notes:219]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2019, 2018 and 2017, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's consolidated statements of operations.

[0001375365-19-000079:notes:220]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-19-000079:notes:221]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 71,918 |  |  | $ | 46,165 |  |  | $ | 66,854 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 49,917 |  |  | 49,345 |  |  | 48,383 |  |
| Effect of dilutive securities | 1,799 |  |  | 2,806 |  |  | 3,296 |  |
| Weighted-average diluted shares | 51,716 |  |  | 52,151 |  |  | 51,679 |  |
| Basic net income per common share | $ | 1.44 |  |  | $ | 0.94 |  |  | $ | 1.38 |  |
| Diluted net income per common share | $ | 1.39 |  |  | $ | 0.89 |  |  | $ | 1.29 |  |

[0001375365-19-000079:notes:222]
For the fiscal years ended June 30, 2019, 2018 and 2017, the Company had stock options, RSUs and PRSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 3,758,000, 2,221,000, and 1,620,000 for the fiscal years ended June 30, 2019, 2018 and 2017, respectively.

[0001375365-19-000079:notes:223]
Concentration of Supplier Risk

[0001375365-19-000079:notes:224]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 21.8%, 26.0%, and 31.0% of total purchases for the fiscal years ended June 30, 2019, 2018 and 2017, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 12, "Related Party Transactions", accounted for 9.2%, 9.0%, and 11.1% of total cost of sales for the fiscal years ended June 30, 2019, 2018 and 2017, respectively.

[0001375365-19-000079:notes:225]
Concentration of Credit Risk

[0001375365-19-000079:notes:226]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales in fiscal years 2019, 2018 and 2017. One customer accounted for 17.0% and 11.6% of accounts receivable, net as of June 30, 2019 and 2018, respectively.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001375365-19-000079:notes:227]
Prepaid Expenses and Other Assets

[0001375365-19-000079:notes:228]
Other assets as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:229]
|  | June 30, |
|  | 2019 |  | 2018 |
| Deferred service costs, non-current | $ | 3,572 |  |  | $ | 3,583 |  |
| Restricted cash, non-current | 2,303 |  |  | 2,202 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Non-marketable equity securities (1) | 878 |  |  | 3,539 |  |
| Deposits | 686 |  |  | 671 |  |
| Prepaid expense, non-current | 1,649 |  |  | 2,471 |  |
| Total other assets | $ | 10,659 |  |  | $ | 14,037 |  |

[0001375365-19-000079:notes:230]
(1) For the fiscal year ended June 30, 2019, the balance represents investment in non-marketable equity securities without readily determinable fair values. For the fiscal year ended June 30, 2018, the balance represents investments in equity securities accounted for under the cost method.

[0001375365-19-000079:notes:231]
Cash, cash equivalents and restricted cash as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:232]
|  | June 30, |
|  | 2019 |  | 2018 |
| Cash and cash equivalents | $ | 248,164 |  |  | $ | 115,377 |  |
| Restricted cash included in prepaid expenses and other current assets | 11,673 |  |  | 2,803 |  |
| Restricted cash included in other assets | 2,303 |  |  | 2,202 |  |
| Total cash, cash equivalents and restricted cash | $ | 262,140 |  |  | $ | 120,382 |  |


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001375365-19-000079:notes:233]
Other Long-term Liabilities

[0001375365-19-000079:notes:234]
Other long-term liabilities as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:235]
|  | June 30, |
|  | 2019 |  | 2018 |
| Accrued unrecognized tax benefits including related interest and penalties | $ | 20,102 |  |  | $ | 17,872 |  |
| Accrued warranty costs, non-current | 2,373 |  |  | 2,295 |  |
| Others | 3,708 |  |  | 4,398 |  |
| Total other long-term liabilities | $ | 26,183 |  |  | $ | 24,565 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-19-000079:notes:236]
Retirement Plans

[0001375365-19-000079:notes:237]
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2019, 2018 and 2017.

[0001375365-19-000079:notes:238]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. The Company is required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the fiscal years ended June 30, 2019, 2018 and 2017, the Company’s matching contribution was $0.5 million, $0.5 million, and $0.4 million, respectively.

[0001375365-19-000079:notes:239]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2019, 2018 and 2017, the Company’s contribution was $1.6 million, $1.5 million and $1.9 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-19-000079:notes:240]
Property, Plant, and Equipment

[0001375365-19-000079:notes:241]
Property, plant and equipment as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-19-000079:notes:242]
|  | June 30, |
|  | 2019 |  | 2018 |
| Buildings | $ | 86,136 |  |  | $ | 88,689 |  |
| Land | 74,926 |  |  | 74,919 |  |
| Machinery and equipment | 79,946 |  |  | 71,081 |  |
| Buildings construction in progress (1) | 14,189 |  |  | 1,779 |  |
| Building and leasehold improvements | 22,307 |  |  | 18,760 |  |
| Software | 18,415 |  |  | 15,522 |  |
| Furniture and fixtures | 20,193 |  |  | 18,475 |  |
|  | 316,112 |  |  | 289,225 |  |
| Accumulated depreciation and amortization | (108,775 | ) |  | (92,594 | ) |
| Property, plant and equipment, net | $ | 207,337 |  |  | $ | 196,631 |  |

[0001375365-19-000079:notes:243]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001375365-19-000079:notes:244]
Quarterly Financial Information (Unaudited)

[0001375365-19-000079:notes:245]
The following table presents the Company’s unaudited consolidated quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company's quarterly results of operations for these periods are not necessary indicative of future results of operations.

[0001375365-19-000079:notes:246]
|  | Three Months Ended |
|  | Jun. 30 |  | Mar. 31 |  | Dec. 31 |  | Sep. 30, |  | Jun. 30 |  | Mar. 31 |  | Dec. 31 |  | Sep. 30, |
|  | 2019 |  | 2019 |  | 2018 |  | 2018 |  | 2018 |  | 2018 |  | 2017 |  | 2017 |
|  | (In thousands, except per share data) |
| Net sales | $ | 854,234 |  |  | $ | 743,499 |  |  | $ | 931,509 |  |  | $ | 971,118 |  |  | $ | 981,662 |  |  | $ | 835,110 |  |  | $ | 826,983 |  |  | $ | 716,737 |  |
| Gross Profit | $ | 132,034 |  |  | $ | 112,327 |  |  | $ | 127,922 |  |  | $ | 123,239 |  |  | $ | 132,329 |  |  | $ | 105,917 |  |  | $ | 105,694 |  |  | $ | 86,054 |  |
| Net income (loss) | $ | 23,710 |  |  | $ | 10,646 |  |  | $ | 18,220 |  |  | $ | 19,342 |  |  | $ | 26,274 |  |  | $ | 14,595 |  |  | $ | (783 | ) |  | $ | 6,079 |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.21 |  |  | $ | 0.37 |  |  | $ | 0.39 |  |  | $ | 0.53 |  |  | $ | 0.30 |  |  | $ | (0.02 | ) |  | $ | 0.12 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.21 |  |  | $ | 0.36 |  |  | $ | 0.37 |  |  | $ | 0.50 |  |  | $ | 0.28 |  |  | $ | (0.02 | ) |  | $ | 0.12 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-19-000079:notes:247]
Related Party Transactions

[0001375365-19-000079:notes:248]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang owned approximately 0.4% of the Company's common stock as of June 30, 2017, but owned no shares as of June 30, 2018 and thereafter. As of June 30, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of June 30, 2019. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of June 30, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-19-000079:notes:249]
Dealings with Ablecom

[0001375365-19-000079:notes:250]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-19-000079:notes:251]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.3% and 97.0% of the chassis included in the products sold by the Company during fiscal years 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-19-000079:notes:252]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-19-000079:notes:253]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $31.0 million and $39.3 million at June 30, 2019 and 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-19-000079:notes:254]
Dealings with Compuware

[0001375365-19-000079:notes:255]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-19-000079:notes:256]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-19-000079:notes:257]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-19-000079:notes:258]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-19-000079:notes:259]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $70.6 million and $111.7 million at June 30, 2019 and 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-19-000079:notes:260]
The Company’s results from transactions with Ablecom and Compuware for each of the fiscal years ended June 30, 2019, 2018, and 2017 are as follows (in thousands):

[0001375365-19-000079:notes:261]
|  | Years Ended June 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Ablecom |  |  |  |  |  |
| Purchases (1) | $ | 145,273 |  |  | $ | 152,332 |  |  | $ | 123,734 |  |
| Compuware |  |  |  |  |  |
| Net sales | $ | 17,651 |  |  | $ | 46,921 |  |  | $ | 22,959 |  |
| Purchases (1) | 139,579 |  |  | 119,548 |  |  | 118,912 |  |

[0001375365-19-000079:notes:262]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-19-000079:notes:263]
The Company's net sales to Ablecom were not material for the fiscal years ended June 30, 2019, 2018, and 2017.

[0001375365-19-000079:notes:264]
The Company had the following balances related to transactions with Ablecom and Compuware as of June 30, 2019 and 2018 (in thousands):

[0001375365-19-000079:notes:265]
|  | June 30, |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 7,236 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 33,928 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 14,396 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 34,417 |  |  | 45,617 |  |

[0001375365-19-000079:notes:266]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 8, "Investment in a Corporate Venture" for a discussion of the investment and the transactions that took place during the fiscal years 2019, 2018, and 2017.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-19-000079:notes:267]
Revenue

[0001375365-19-000079:notes:268]
Revenue recognition for periods after the Company’s adoption of ASC 606 as of July 1, 2018

[0001375365-19-000079:notes:269]
The Company adopted ASC 606 as of July 1, 2018 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, the Company considered the effect of all modifications when identifying performance obligations and allocating transaction price, which did not have a material effect on the adjustment to retained earnings. The Company recognized the cumulative effect of initially applying ASC 606 as an adjustment to the opening balance of retained earnings. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

[0001375365-19-000079:notes:270]
ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of the promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.

[0001375365-19-000079:notes:271]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-19-000079:notes:272]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customers from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

[0001375365-19-000079:notes:273]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-19-000079:notes:274]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000079:notes:275]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services.  Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-19-000079:notes:276]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-19-000079:notes:277]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-19-000079:notes:278]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-19-000079:notes:279]
Revenue recognition for periods prior to the Company’s adoption of ASC 606 as of July 1, 2018

[0001375365-19-000079:notes:280]
Product sales. The Company recognizes revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of its  products to customers, unless customer acceptance  is uncertain or significant obligations to the  customer remain: (i) persuasive evidence of an arrangement exists through   customer contracts and  orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

[0001375365-19-000079:notes:281]
The Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. The Company also reduces revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

[0001375365-19-000079:notes:282]
The Company may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement between the Company and the distributor.

[0001375365-19-000079:notes:283]
The Company records costs related to shipping and handling in sales and marketing expenses. Shipping and handling fees billed to customers are included in net sales.

[0001375365-19-000079:notes:284]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000079:notes:285]
Multiple-element arrangements. Certain of the Company’s arrangements contain multiple elements, consisting of   both the Company’s products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

[0001375365-19-000079:notes:286]
The Company allocates arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of     selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available.

[0001375365-19-000079:notes:287]
The Company does not have VSOE for deliverables in its arrangements, and TPE is generally not available because its products are highly differentiated, and the Company is unable to obtain reliable information on the products and pricing practices of the Company’s competitors. BESP reflects the Company’s estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

[0001375365-19-000079:notes:288]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. The Company determines BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-19-000079:notes:289]
Disaggregation of Revenue

[0001375365-19-000079:notes:290]
The Company disaggregates revenue by type of product, by geographical market, and by products sold to indirect sales channel partners or direct customers and OEMs that depict the nature, amount, and timing of revenue and cash flows. Service revenues are not a significant component of total revenue and are aggregated within the respective categories.

[0001375365-19-000079:notes:291]
Contract Balances

[0001375365-19-000079:notes:292]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

[0001375365-19-000079:notes:293]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s consolidated financial statements.

[0001375365-19-000079:notes:294]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On July 1, 2018, deferred revenue totaled $143.5 million after recognizing the cumulative effect of initially applying ASC 606. Of that amount, $53.9 million was recognized as revenue during the fiscal year ended June 30, 2019.

[0001375365-19-000079:notes:295]
Deferred revenue increased during the fiscal year ended June 30, 2019 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

[0001375365-19-000079:notes:296]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-19-000079:notes:297]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of June 30, 2019 was approximately $203.4 million. The Company expects to recognize approximately 46% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-19-000079:notes:298]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-19-000079:notes:299]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company allocates the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Such contract acquisition costs that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

[0001375365-19-000079:notes:300]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001375365-19-000079:notes:301]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-19-000079:notes:302]
|  | June 30, |
|  | 2019 |  | 2018 |
| Long-lived assets: |  |  |  |
| United States | $ | 162,835 |  |  | $ | 151,567 |  |
| Asia | 41,915 |  |  | 42,533 |  |
| Europe | 2,587 |  |  | 2,531 |  |
|  | $ | 207,337 |  |  | $ | 196,631 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-19-000079:notes:303]
Segment Reporting

[0001375365-19-000079:notes:304]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-19-000079:notes:305]
The Company’s revenue is presented on a disaggregated basis in Note 3, “Revenue” by type of product, by geographical market, and by products sold through its indirect sales channel or to its direct customers and OEMs.


## us-gaap:SubsequentEventsTextBlock

[0001375365-19-000079:notes:306]
Subsequent Events

[0001375365-19-000079:notes:307]
On February 8, 2018, two putative class action complaints were filed against us, our CEO, and our former CFO in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff and it filed an amended complaint naming our Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, plaintiff filed a further amended complaint naming our former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, we filed a motion to dismiss which remains pending. We believe the allegations filed are without merit and intend to vigorously defend against the lawsuit.

[0001375365-19-000079:notes:308]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring is not expected to have a material impact on the estimated annual effective tax rate.
