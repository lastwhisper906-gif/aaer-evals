# SMCI MD&A — 0001375365-19-000079


## mdna

[0001375365-19-000079:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-19-000079:mdna:2]
Nasdaq Delisting of our Common Stock

[0001375365-19-000079:mdna:3]
As a result of the delay in filing our periodic reports with the SEC and failure to hold an annual meeting, we were unable to comply with the Nasdaq listing standards and our common stock was suspended from trading on the Nasdaq Global Select Market effective August 23, 2018 and formally delisted effective March 22, 2019. Following the suspension of trading, our common stock has been quoted on the OTC Market and is currently traded under the symbol “SMCI.” For further information regarding trading in our common stock, refer to Part II, Item 5, “Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities” in this Annual Report.

[0001375365-19-000079:mdna:4]
Overview

[0001375365-19-000079:mdna:5]
We are a global leader and innovator of high-performance, high-efficiency server and storage technology. We develop and provide end-to-end green computing solutions to the cloud computing, data centers, enterprise, big data, AI, HPC, edge computing and IoT markets. Our solutions range from complete server, storage, modular blade servers, blades and workstations to full racks, networking devices, server management software, server sub-systems and global support and services.

[0001375365-19-000079:mdna:6]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2019, 2018 and 2017, our net income was $71.9 million, $46.2 million and $66.9 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-19-000079:mdna:7]
During fiscal years 2018 and 2019, we continued to concentrate our efforts on selling server and storage systems to larger customers such as enterprise and data center customers. As a result of these efforts, sales of server and storage systems represented sequentially greater percentages of our net sales over the course of the two fiscal years, rising from 70.0% of net sales in fiscal year 2017 to 79.3% in fiscal year 2018 and 81.7% in fiscal year 2019. Server and storage systems generally have higher average selling prices and provide an opportunity to sell services. The substantial increase in our net sales from fiscal year 2017 to fiscal year 2018 reflected both this concentration on selling server and storage systems and an increased demand for our products. The further increase in our net sales from fiscal year 2018 to fiscal year 2019, which was less substantial than the prior year’s increase in net sales, reflected our continued concentration on selling server and storage systems, but also reflected a softening demand for our products due to an overall market slowdown in the second half of fiscal year 2019. In addition, adverse publicity associated with false assertions made against our company in a news article published in October 2018 and the unrelated suspension of trading in our common stock on NASDAQ in August 2018 may have been factors contributing to the slower growth in our net sales for fiscal year 2019.

[0001375365-19-000079:mdna:8]
Financial Highlights

[0001375365-19-000079:mdna:9]
The following is a summary of financial highlights of fiscal years 2019 and 2018:

[0001375365-19-000079:mdna:10]
| • | Net sales increased by 4.2% and 35.2% in fiscal years 2019 and 2018, respectively, as compared to fiscal years 2018 and 2017, respectively. |

[0001375365-19-000079:mdna:11]
| • | Gross margin increased to 14.2% in fiscal year 2019 from 12.8% in fiscal year 2018, primarily due to lower prices for key components, a favorable geographic mix with less competitive pricing, and increased service revenues that have higher margins. Gross margin in fiscal year 2018 decreased by 130 basis points from 14.1% in fiscal year 2017 primarily due to higher costs of key components resulting from shortages of memory and SSDs, higher volume of server and storage systems sales configured with these key components and a less favorable geographical mix of sales resulting in a higher cost of sales. |

[0001375365-19-000079:mdna:12]
| • | Operating expenses increased by 18.8% and 31.4% in fiscal years 2019 and 2018, respectively, as compared to fiscal years 2018 and 2017, respectively. The increase in both fiscal years was primarily due to an increase in professional fees incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, as well as an increase in the number of employees to support our growth. |

[0001375365-19-000079:mdna:13]
| • | Net income increased to $71.9 million as compared to $46.2 million in fiscal year 2018, which was primarily due to a reduction in our effective tax rate to 16.6% as compared to 43.6% in fiscal year 2018 and a $1.3 million increase in income before taxes. Net income in fiscal year 2018 decreased by $20.7 million from $66.9 million in fiscal year 2017 primarily due to an increase in our effective tax rate to 43.6% in fiscal year 2018, in part due to the remeasurement of our deferred tax assets under the 2017 Tax Reform Act, as compared to 26.7% in fiscal year 2017. |

[0001375365-19-000079:mdna:14]
| • | Our cash and cash equivalents were $248.2 million, $115.4 million and $110.6 million at the end of fiscal years 2019, 2018, and 2017, respectively. In fiscal year 2019, we generated net cash of $141.8 million, of which $262.6 million was generated from operating activities related to increased net income and improved working capital management while we invested $24.8 million primarily in new manufacturing capacity and used $95.8 million in financing activities primarily to repay outstanding loans. In fiscal year 2018, we generated net cash of $7.6 million, of which $84.3 million was generated from operating activities related to improved working capital management while we invested $25.9 million primarily in new manufacturing capacity and used $50.8 million in financing activities to primarily repay outstanding loans. |

[0001375365-19-000079:mdna:15]
Subsequent Events

[0001375365-19-000079:mdna:16]
For details, see Part II, Item 8, Note 19, “Subsequent Events” in our notes to the consolidated financial statements in this Annual Report.

[0001375365-19-000079:mdna:17]
Critical Accounting Policies

[0001375365-19-000079:mdna:18]
General

[0001375365-19-000079:mdna:19]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-19-000079:mdna:20]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-19-000079:mdna:21]
Revenue recognition for periods after adoption of ASC 606 as of July 1, 2018

[0001375365-19-000079:mdna:22]
We adopted the new accounting guidance issued by the Financial Accounting Standards Board (“FASB”), Revenue from Contracts with Customers, (“ASC 606”) as of July 1, 2018 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, we considered the effect of all

[0001375365-19-000079:mdna:23]
modifications when identifying performance obligations and allocating transaction price, which did not have a material effect on the adjustment to retained earnings. We recognized the cumulative effect of initially applying ASC 606 as an adjustment to the opening balance of retained earnings. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

[0001375365-19-000079:mdna:24]
ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of the promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.

[0001375365-19-000079:mdna:25]
We generate revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-19-000079:mdna:26]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold are delivered via shipment from our facilities or drop shipment directly to our customer from our vendor. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which we expect to be entitled.

[0001375365-19-000079:mdna:27]
As part of determining the transaction price in contracts with customers, we estimate reserves for future sales returns based on a review of our history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. We also reduce revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-19-000079:mdna:28]
Services sales. Our sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000079:mdna:29]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-19-000079:mdna:30]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-19-000079:mdna:31]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-19-000079:mdna:32]
We consider shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost

[0001375365-19-000079:mdna:33]
of products sold. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-19-000079:mdna:34]
Revenue recognition for periods prior to adoption of ASC 606 as of July 1, 2018

[0001375365-19-000079:mdna:35]
Product sales. We recognize revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of our  products to customers, unless customer acceptance  is uncertain or significant obligations to the  customer remain: (i) persuasive evidence of an arrangement exists through   customer contracts and  orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

[0001375365-19-000079:mdna:36]
We estimate reserves for future sales returns based on a review of our history of actual returns for each major product line. We also reduce revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

[0001375365-19-000079:mdna:37]
We may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement with the distributor.

[0001375365-19-000079:mdna:38]
We record costs related to shipping and handling in sales and marketing expenses. Shipping and handling fees billed to customers are included in net sales.

[0001375365-19-000079:mdna:39]
Services sales. Our sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000079:mdna:40]
Multiple-element arrangements. Certain of our arrangements contain multiple elements, consisting of both our products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

[0001375365-19-000079:mdna:41]
We allocate arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available.

[0001375365-19-000079:mdna:42]
We do not have VSOE for deliverables in our arrangements, and TPE is generally not available because our products are highly differentiated, and we are unable to obtain reliable information on the products and pricing practices of our competitors. BESP reflects our estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

[0001375365-19-000079:mdna:43]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. We determine BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.

[0001375365-19-000079:mdna:44]
Product Warranties

[0001375365-19-000079:mdna:45]
We offer product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and we do not offer any services beyond the assurance that the product will continue working as specified. Therefore, under recently adopted guidance, ASC 606, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, we accrue for estimated returns of defective products at the time revenue is recognized. We monitor warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on

[0001375365-19-000079:mdna:46]
estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with our historical experience, and the changes in the cost of servicing warranty claims. We account for the effect of such changes in estimates prospectively.

[0001375365-19-000079:mdna:47]
Inventories

[0001375365-19-000079:mdna:48]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of units based upon our forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped. Prior to July 1, 2017, inventories were stated at weighted-average cost, subject to lower of cost or market.

[0001375365-19-000079:mdna:49]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-19-000079:mdna:50]
Income Taxes

[0001375365-19-000079:mdna:51]
We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-19-000079:mdna:52]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-19-000079:mdna:53]
Stock-Based Compensation

[0001375365-19-000079:mdna:54]
We measure and recognize compensation expense for all share-based awards made to employees and non-employees, including stock options and restricted stock units ("RSUs"). The share-based awards granted to non-employees have not been material to date. We are required to estimate the fair value of share-based awards on the date of grant. We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Prior to July 1, 2017, we estimated forfeitures and expensed the value of awards that were ultimately expected to vest over the requisite service periods. The fair value of RSUs with service conditions or performance conditions is based on the closing market price of our common stock on the date of grant. The fair value for RSUs with service conditions, or time-based RSUs, is amortized on a straight-line basis over the requisite service period. The fair value for RSUs with performance conditions ("PRSUs") is recognized on a ratable basis over the requisite service period when it is probable the performance conditions of the awards will be met. We reassess the probability of vesting at each reporting period and adjust our total compensation cost of the awards based on this probability assessment.

[0001375365-19-000079:mdna:55]
We estimate the fair value of stock options granted using a Black-Scholes option pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the implied and historical volatility of our common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000079:mdna:56]
Variable Interest Entities

[0001375365-19-000079:mdna:57]
We determine at the inception of each arrangement whether an entity in which we hold an investment or in which we have other variable interests is considered a variable interest entity ("VIE"). We consolidate VIEs when we are the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, we assess whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether we are the primary beneficiary. If we are not the primary beneficiary in a VIE, we account for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-19-000079:mdna:58]
We have concluded that Ablecom Technology, Inc. ("Ablecom") and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary as we do not have the power to direct the activities that are most significant to the entities and therefore, we do not consolidate these entities. In performing this analysis, we considered our explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between us and these two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests from suffering losses. We determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-19-000079:mdna:59]
We and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the “Management Company”) in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. We have concluded that the Management Company is a VIE and we are the primary beneficiary as we have the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2019, 2018 and 2017, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom’s interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom’s interest was not material for the periods presented and was included in general and administrative expenses in our consolidated statements of operations.

[0001375365-19-000079:mdna:60]
Results of Operations

[0001375365-19-000079:mdna:61]
Net Sales

[0001375365-19-000079:mdna:62]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact our net sales are the number of compute nodes sold, the average selling prices per node for our server and storage system sales and units shipped and the average selling price per unit for our subsystem and accessories. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs, and memory, and the prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories. A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs.

[0001375365-19-000079:mdna:63]
The following table presents net sales by product type for fiscal years 2019, 2018 and 2017 (dollars in millions):

[0001375365-19-000079:mdna:64]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 2,858.6 |  |  | $ | 2,663.6 |  |  | $ | 1,740.6 |  |  | $ | 195.0 |  |  | 7.3 | % |  | $ | 923.0 |  |  | 53.0 | % |
| Percentage of total net sales | 81.7 | % |  | 79.3 | % |  | 70.0 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 641.7 |  |  | 696.9 |  |  | 744.3 |  |  | (55.2 | ) |  | (7.9 | )% |  | (47.4 | ) |  | (6.4 | )% |
| Percentage of total net sales | 18.3 | % |  | 20.7 | % |  | 30.0 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,500.3 |  |  | $ | 3,360.5 |  |  | $ | 2,484.9 |  |  | $ | 139.8 |  |  | 4.2 | % |  | $ | 875.6 |  |  | 35.2 | % |

[0001375365-19-000079:mdna:65]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:66]
In fiscal year 2019, we continued our strategy of focusing on selling server and storage systems to larger customers such as enterprise and internet data center and cloud customers. The year-over-year increase in server and storage systems sales was primarily due to an increase of average selling price per compute node by approximately 15%, offset by a decrease of approximately 6.5% in the number of units of compute nodes shipped, which is attributable to an overall market slowdown in the second half of fiscal year 2019. The increase in the average selling prices of our server and storage systems was primarily due to higher sales of our complete systems configured with higher density computing and more memory and storage capacity. During the first half of fiscal year 2019, we increased our average selling prices primarily to remain consistent with the increases in the cost of memory and SSDs on a year-over year basis. During October 2018, a 10% tariff was applied to certain key components made in China and was partially incorporated into our average selling prices to the extent that component sourcing alternatives were not available. As costs for memory and SSDs began to decline in the second half of fiscal year 2019, our average selling prices to customers declined accordingly. The year-over-year decrease in net sales of our subsystems and accessories in fiscal year 2019 was primarily due to lower sales of subsystems and accessories through our indirect sales channel.

[0001375365-19-000079:mdna:67]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:68]
In fiscal year 2018, we continued our strategy of focusing on selling server and storage systems to larger customers such as enterprise and internet data center and cloud customers. The substantial increase year-over-year in server and storage systems sales was primarily due to an increase of average selling price per compute node by approximately 32% and an increase of approximately 14% in the number of units of compute nodes shipped due to an increased demand for our products. The increase in the average selling prices of our server and storage systems was primarily due to higher sales of our complete systems configured with higher density computing and more memory and storage capacity. During fiscal year 2018, our average selling prices to customers increased as a result of the increases in the cost of memory and SSDs. The year-over-year decrease in net sales of our subsystems and accessories in fiscal year 2018 was primarily due to lower sales of subsystem and accessories through our indirect sales channel as we continued to promote our sales of server and storage systems to our direct customers and OEMs.

[0001375365-19-000079:mdna:69]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs for fiscal years 2019, 2018 and 2017:

[0001375365-19-000079:mdna:70]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | % |  | % |
| Indirect sales channel | 39.3 | % |  | 41.5 | % |  | 47.8 | % |  | (2.2 | )% |  | (6.3 | )% |
| Direct customers and OEMs | 60.7 | % |  | 58.5 | % |  | 52.2 | % |  | 2.2 | % |  | 6.3 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001375365-19-000079:mdna:71]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:72]
The year-over-year decrease in net sales through our indirect sales channel as a percentage of total net sales was primarily due to the higher sales to our direct customers and OEMs. The year-over-year increase in net sales to direct customers and OEMs as a percentage of total net sales was primarily due to higher sales of our server and storage systems to internet data center and cloud, enterprise and OEM customers.

[0001375365-19-000079:mdna:73]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:74]
The year-over-year decrease in net sales through our indirect sales channel as a percentage of total net sales was primarily due to the lower sales of our subsystems and accessories, which are typically sold through our indirect sales channel. The year-over-year increase in net sales to direct customers and OEMs as a percentage of total net sales was primarily due to the higher volume of sales of our server and storage systems to our internet data center and cloud, enterprise and OEM customers.

[0001375365-19-000079:mdna:75]
The following table presents percentages of net sales by geographic region for fiscal years 2019, 2018 and 2017:

[0001375365-19-000079:mdna:76]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | % |  | % |
| United States | 58.1 | % |  | 56.6 | % |  | 57.2 | % |  | 1.5 | % |  | (0.6 | )% |
| Europe | 17.5 | % |  | 16.3 | % |  | 18.3 | % |  | 1.2 | % |  | (2.0 | )% |
| Asia | 20.3 | % |  | 22.7 | % |  | 20.2 | % |  | (2.4 | )% |  | 2.5 | % |
| Others | 4.1 | % |  | 4.4 | % |  | 4.3 | % |  | (0.3 | )% |  | 0.1 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001375365-19-000079:mdna:77]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:78]
The year-over-year increase in net sales in the United States as a percentage of total net sales was primarily due to the higher sales of our server and storage systems to our direct customers and OEMs. The year-over-year decrease in net sales in Asia as a percentage of total net sales was due primarily to decreased sales through our indirect sales channel in China, partially offset by increased sales in Taiwan to enterprise datacenter customers. The increased percentage of net sales in Europe was primarily due to higher sales in the Netherlands to enterprise and cloud computing customers.

[0001375365-19-000079:mdna:79]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:80]
The year-over-year decline in net sales in the United States and Europe as a percentage of total net sales was primarily due to higher sales growth in Asia, particularly China and Taiwan, as compared to other regions.

[0001375365-19-000079:mdna:81]
Cost of Sales and Gross Margin

[0001375365-19-000079:mdna:82]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-19-000079:mdna:83]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the fiscal years 2019 and 2018, we continued to expand manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 9.2%, 9.0% and 11.1% of our cost of sales for fiscal years 2019, 2018 and 2017, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 12, “Related Party Transactions.”

[0001375365-19-000079:mdna:84]
Cost of sales and gross margin for fiscal years 2019, 2018 and 2017, are as follows (dollars in millions):

[0001375365-19-000079:mdna:85]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 3,004.8 |  |  | $ | 2,930.5 |  |  | $ | 2,135.0 |  |  | $ | 74.3 |  |  | 2.5 | % |  | $ | 795.5 |  |  | 37.3 | % |
| Gross profit | 495.5 |  |  | 430.0 |  |  | 350.0 |  |  | 65.5 |  |  | 15.2 | % |  | 80.0 |  |  | 22.9 | % |
| Gross margin | 14.2 | % |  | 12.8 | % |  | 14.1 | % |  |  |  | 1.4 | % |  |  |  |  | (1.3 | )% |

[0001375365-19-000079:mdna:86]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:87]
The year-over-year increase in cost of sales was primarily attributable to an increase of $25.8 million in product cost related to the increase in net sales volume, increased expense of $23.3 million in the provision for excess inventory and obsolescence, an increase in overhead costs of $10.7 million attributable to increased tariffs for import of components from China, an increase of $8.6 million in compensation and benefits including stock-based compensation as a result of an increase in annual salaries and benefits and an increase in the number of operations personnel we employ to support the growth of our business, and an increase of warranty provision of $5.4 million related to the increase in net sales.

[0001375365-19-000079:mdna:88]
The year-over-year increase in the gross margin percentage was primarily due to lower costs of memory and SSDs components in the second half of fiscal year 2019 and the timing of adjusting our average selling prices. In addition, in fiscal year 2019 as compared with fiscal year 2018, we had lower net sales in Asia where pricing is typically lower and the market there is more competitive which resulted in a shift in geographic mix that had a positive impact on our gross margin percentage.

[0001375365-19-000079:mdna:89]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:90]
The year-over-year increase in cost of sales was primarily attributable to an increase of $772.6 million in product costs due to an increase in key component prices in combination with an increase in net sales volume, an increase of $7.8 million in compensation and benefits including stock-based compensation as a result of an increase in annual salaries and benefits and an increase in the number of operations personnel to support the growth of our business, an increase of $6.9 million in facility expense as a result of the expansion of our Green Computing Park in San Jose, California and an increase of $11.6 million in overhead costs due to an increase in freight charges and other manufacturing costs driven by the increase in net sales, offset by a decrease of $6.1 million in the provision for excess inventory and obsolescence.

[0001375365-19-000079:mdna:91]
The year-over-year decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component sourcing due to component shortages, partially offset by higher average selling prices per compute node. In fiscal year 2018, the growth in net sales in Asia was higher than in fiscal year 2017, which negatively impacted our gross margin due to more competitive pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:92]
Operating Expenses

[0001375365-19-000079:mdna:93]
Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-19-000079:mdna:94]
Sales and marketing expenses consist primarily of personnel expenses, including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-19-000079:mdna:95]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance and outside legal, audit, tax fees, insurance and bad debt.

[0001375365-19-000079:mdna:96]
Operating expenses for fiscal years 2019, 2018 and 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:97]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 179.9 |  |  | $ | 165.1 |  |  | $ | 144.0 |  |  | $ | 14.8 |  |  | 9.0 | % |  | $ | 21.1 |  |  | 14.7 | % |
| Percentage of total net sales | 5.1 | % |  | 4.9 | % |  | 5.8 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 77.2 |  |  | 71.6 |  |  | 66.4 |  |  | 5.6 |  |  | 7.8 | % |  | 5.2 |  |  | 7.8 | % |
| Percentage of total net sales | 2.2 | % |  | 2.1 | % |  | 2.7 | % |  |  |  |  |  |  |  |  |
| General and administrative | 141.2 |  |  | 98.6 |  |  | 44.7 |  |  | 42.6 |  |  | 43.2 | % |  | 53.9 |  |  | 120.6 | % |
| Percentage of total net sales | 4.0 | % |  | 2.9 | % |  | 1.8 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 398.3 |  |  | $ | 335.3 |  |  | $ | 255.1 |  |  | 63.0 |  |  | 18.8 | % |  | 80.2 |  |  | 31.4 | % |
| Percentage of total net sales | 11.4 | % |  | 10.0 | % |  | 10.3 | % |  |  |  |  |  |  |  |  |

[0001375365-19-000079:mdna:98]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:99]
The year-over-year increase in research and development expenses was due to an increase of $16.0 million in personnel expenses, an decrease of $3.3 million in reimbursements received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products, offset by a decrease of $6.1 million in product development costs. Our personnel expenses increased primarily as a result of an increase in annual salaries and benefits, and an increase in the number of research and development personnel to support our expanded product development initiatives and to support the growth of our business in many market verticals.

[0001375365-19-000079:mdna:100]
The year-over-year increase in sales and marketing expenses was due to an increase of $6.1 million in personnel expenses, as a result of an increase in annual salaries and benefits and an increase in the number of sales and marketing personnel, offset by a $1.5 million decrease in expenses related to advertising and promotion activities.

[0001375365-19-000079:mdna:101]
The year-over-year increase in general and administrative expenses was attributable to an increase of $31.7 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, an increase of $7.2 million in bad debt provision expenses primarily as a result of our inability to collect receivables from certain international customers and an increase of $2.7 million primarily attributable to increase in sales tax accrual and insurance costs.

[0001375365-19-000079:mdna:102]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:103]
The year-over-year increase in research and development expenses was due to an increase of $21.1 million in personnel expenses, an decrease of $4.2 million in reimbursements received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products, offset by a decrease of $3.9 million in product development costs and $1.1 million increase of deferred gain related to our remaining performance obligations in association with the contribution of certain technology rights to the equity investee in China. Our personnel expenses increased primarily as a result of an increase in annual salaries and benefits and an increase in the number of research and development personnel to support our product development and growth of business.

[0001375365-19-000079:mdna:104]
The year-over-year increase in sales and marketing expenses was due to an increase of $7.0 million in personnel expenses, as a result of an increase in annual salaries and benefits and an increase in the number of sales and marketing personnel, offset by a decrease of $1.8 million in advertising and promotion expenses driven by higher reimbursements received under our cooperative marketing arrangements with certain vendors.

[0001375365-19-000079:mdna:105]
The year-over-year increase in general and administrative expenses was due to an increase of $45.8 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements

[0001375365-19-000079:mdna:106]
and an increase of $8.1 million in personnel expenses. Our personnel expenses in general and administrative expenses increased primarily as a result of an increase in annual salaries and benefits and an increase in the number of personnel to support our expanded business.

[0001375365-19-000079:mdna:107]
Interest and Other Expense, Net

[0001375365-19-000079:mdna:108]
Other expense, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-19-000079:mdna:109]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-19-000079:mdna:110]
Interest and other expense, net for fiscal years 2019, 2018 and 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:111]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | $ |  | % |  | $ |  | % |
| Other expense, net | $ | (1.0 | ) |  | $ | (0.8 | ) |  | $ | (1.0 | ) |  | $ | (0.2 | ) |  | 25.0 | % |  | $ | 0.2 |  |  | (20.0 | )% |
| Interest expense | (6.7 | ) |  | (5.7 | ) |  | (2.3 | ) |  | (1.0 | ) |  | 17.5 | % |  | (3.4 | ) |  | 147.8 | % |
| Interest and other expense, net | $ | (7.7 | ) |  | $ | (6.5 | ) |  | $ | (3.3 | ) |  | $ | (1.2 | ) |  | 18.5 | % |  | $ | (3.2 | ) |  | 97.0 | % |

[0001375365-19-000079:mdna:112]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:113]
The year-over-year increase in interest and other expense, net was primarily due to an increase of $1.0 million in interest expense related to amortization of loan origination fees in connection with refinancing of our debt in the last quarter of fiscal year 2018, an increase in other expense of $2.1 million primarily as a result of an impairment recorded for certain investments, offset by an increase of $1.9 million attributable to increase in interest income on our interest bearing deposits and foreign exchange gain due to favorable foreign currency fluctuations.

[0001375365-19-000079:mdna:114]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:115]
The year-over-year increase in interest and other expense, net was primarily due to an increase of $3.4 million in interest expense attributable to increased borrowings under our credit facilities to support our growth.

[0001375365-19-000079:mdna:116]
Provision for Income Taxes

[0001375365-19-000079:mdna:117]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, foreign derived intangible income deduction, and foreign tax credits, which were partially offset by state taxes, stock based compensation, taxes on foreign earnings, and unrecognized tax benefits. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 14, “Income Taxes” to the consolidated financial statements in this Annual Report.

[0001375365-19-000079:mdna:118]
Provision for income taxes and effective tax rates for fiscal years 2019, 2018 and 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:119]
|  | Years Ended June 30, |  | 2019 over 2018 Change |  | 2018 over 2017 Change |
|  | 2019 |  | 2018 |  | 2017 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 14.9 |  |  | $ | 38.4 |  |  | $ | 24.4 |  |  | $ | (23.5 | ) |  | (61.2 | )% |  | $ | 14.0 |  |  | 57.4 | % |
| Percentage of total net sales | 0.4 | % |  | 1.1 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 16.6 | % |  | 43.6 | % |  | 26.7 | % |  |  |  |  |  |  |  |  |

[0001375365-19-000079:mdna:120]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-19-000079:mdna:121]
The year-over-year decrease in the effective tax rate was primarily due to a reduction of the statutory tax rate from 28.1% to 21% as a result of the tax reform, and a prior year recording of a one-time $12.9 million write down of U.S. deferred tax assets and liabilities, and a one-time transition tax of $2.8 million, all as a result of the 2017 Tax Reform Act.

[0001375365-19-000079:mdna:122]
Fiscal Year 2018 Compared with Fiscal Year 2017

[0001375365-19-000079:mdna:123]
The year-over-year increase in the effective tax rate was primarily due to a $12.9 million one-time write down of U.S. deferred tax assets and liabilities, resulting from the U.S. federal corporate income tax rate decrease from 35% to 21% effective January 1, 2018, and the U.S. federal one-time transition tax of $2.8 million, each as a result of the 2017 Tax Reform Act. The Company’s statutory tax rate was reduced from 35% in 2017 to 28.1% in 2018 which includes a blended rate for the current year related to tax reform. The blended rate was a result of rate change from 35% to 21%, effective as of January 1, 2018, for all taxpayers, including fiscal year tax payers.

[0001375365-19-000079:mdna:124]
Liquidity and Capital Resources

[0001375365-19-000079:mdna:125]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $248.2 million and $115.4 million as of June 30, 2019 and 2018, respectively. Our cash in foreign locations was $124.6 million and $114.0 million as of June 30, 2019 and 2018, respectively.

[0001375365-19-000079:mdna:126]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Due to the enactment of the 2017 Tax Reform Act, all of our cash, cash equivalents and investments held by foreign subsidiaries were subject to U.S. taxation under the one-time transition tax as further discussed in Part II, Item 8, Note 14, "Income Taxes". Subsequent repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through ongoing cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-19-000079:mdna:127]
We believe that our current cash, cash equivalents, credit lines and internally generated cash flows will be generally sufficient to support our operating businesses, remediation efforts, maturing debt and interest payments for the twelve months following the issuance of these consolidated financial statements.

[0001375365-19-000079:mdna:128]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-19-000079:mdna:129]
|  | Years Ended June 30, |  | 2019 over 2018 |  | 2018 over 2017 |
|  | 2019 |  | 2018 |  | 2017 |  |  |
| Net cash provided by (used in) operating activities | $ | 262.6 |  |  | $ | 84.3 |  |  | $ | (96.2 | ) |  | $ | 178.3 |  |  | $ | 180.5 |  |
| Net cash used in investing activities | $ | (24.8 | ) |  | $ | (25.9 | ) |  | $ | (29.4 | ) |  | $ | 1.1 |  |  | $ | 3.5 |  |
| Net cash (used in) provided by financing activities | $ | (95.8 | ) |  | $ | (50.8 | ) |  | $ | 57.7 |  |  | $ | (45.0 | ) |  | $ | (108.5 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 141.8 |  |  | $ | 7.6 |  |  | $ | (67.9 | ) |  | $ | 134.2 |  |  | $ | 75.5 |  |

[0001375365-19-000079:mdna:130]
Operating Activities

[0001375365-19-000079:mdna:131]
Net cash provided by operating activities increased by $178.3 million for fiscal year 2019 as compared to fiscal year 2018.  The increase was due primarily to a reduction of net working capital of $160.6 million due to improved working capital management and reduced costs for key components in the second half of fiscal year 2019, higher net income in fiscal year 2019 of $25.8 million, the change in the non-cash charges related to an increase in excess and obsolete inventory of $23.3 million for aged inventory and $7.2 million for bad debt, partially offset by a reduction of $30.7 million in the non-cash charges related to the change in our deferred income tax assets, primarily as a result of the 2017 Tax Reform Act and a decrease of $8.0 million from the change in deferred revenue compared to prior year, related to the lower growth in services business year-over-year.

[0001375365-19-000079:mdna:132]
Net cash provided by operating activities increased by $180.5 million for fiscal year 2018 as compared to fiscal year 2017. The increase was due primarily to a reduction of net working capital of $136.1 million due to improved working capital management in the second half of fiscal year 2018, an increase of $36.5 million from the change in deferred revenue related to the growth in our services business year-over-year, an increase in the non-cash charges related to the change in our deferred income tax assets of $19.0 million, primarily as a result of the 2017 Tax Reform Act, partially offset by lower net income of $20.7 million for the period.

[0001375365-19-000079:mdna:133]
Investing Activities

[0001375365-19-000079:mdna:134]
Net cash used in investing activities was $24.8 million, $25.9 million and $29.4 million for the fiscal years 2019, 2018 and 2017, respectively, as we continued to invest in our Green Computing Park in San Jose to expand our capacity and office space.

[0001375365-19-000079:mdna:135]
Financing Activities

[0001375365-19-000079:mdna:136]
Net cash used in financing activities increased by $45.0 million for fiscal year 2019 as compared to fiscal year 2018 primarily due to increased debt repayments of $43.1 million. Net cash used in financing activities was $50.8 million in fiscal year 2018 primarily due to net debt repayments of $48.7 million as compared to net cash provided by financing activities in fiscal year 2017 of $57.7 million related to net debt borrowings of $66.6 million and $10.9 million raised from the proceeds from the exercise of stock options, partially offset by stock repurchases of $18.5 million.

[0001375365-19-000079:mdna:137]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-19-000079:mdna:138]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000079:mdna:139]
Bank of America

[0001375365-19-000079:mdna:140]
2016 Bank of America Credit Facility

[0001375365-19-000079:mdna:141]
In June 2016, we entered into a credit agreement with Bank of America (the “2016 Bank of America Credit Facility”). Prior to its maturity in April 2018, we repaid and terminated the 2016 Bank of America Credit Facility using the proceeds from our 2018 Bank of America Credit Facility (defined below). Immediately prior to its termination, the 2016 Bank of America Credit Facility (giving effect to all amendments since the inception of the 2016 Bank of America Credit Facility), provided for (i) a $85.0 million revolving line of credit including a $5.0 million letter of credit sublimit, (ii) a $20.0 million revolving line of credit for our Taiwan and the Netherlands entities, and (iii) a five-year $50.0 million term loan. The 2016 Bank of America Credit Facility term loan was secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan were payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the $85.0 million revolving line of credit was at the LIBOR rate plus 1.25% per annum. The interest rate of the $20.0 million revolving line of credit was equal to a minimum of 0.9% per annum plus the lender's cost of funds, as defined in the agreements.

[0001375365-19-000079:mdna:142]
2018 Bank of America Credit Facility

[0001375365-19-000079:mdna:143]
In April 2018, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at our option and if certain conditions are satisfied, including being current on all of our delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against our line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to a five-year revolving credit facility, Super Micro Computer’s assets, and at our option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to either repurchase our shares or pay any dividends.

[0001375365-19-000079:mdna:144]
In the fourth fiscal quarter of 2018, we paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in our consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in our consolidated balance sheets.

[0001375365-19-000079:mdna:145]
On January 31, 2019, we paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, we entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000079:mdna:146]
As of June 30, 2019 and 2018, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of June 30, 2019 and 2018 were 4.5% per annum and 4.75% per annum, respectively. As of June 30, 2019, a $3.2 million letter of credit was outstanding under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.3 million and $2.8 million as of June 30, 2019 and 2018, respectively.  As of June 30, 2019, our available borrowing capacity under the 2018 Bank of America Credit Facility was $245.7 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000079:mdna:147]
CTBC Bank

[0001375365-19-000079:mdna:148]
In April 2016, we entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD $700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum, which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. We extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000079:mdna:149]
In May 2017, we renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum, which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, we entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

[0001375365-19-000079:mdna:150]
In January 2018, we entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000079:mdna:151]
In June 2019, we entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established

[0001375365-19-000079:mdna:152]
NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000079:mdna:153]
The total outstanding borrowings under the 2019 and 2018 CTBC Credit Facility term loans were denominated in NTD and remeasured into U.S. dollars of $22.5 million and $22.9 million at June 30, 2019 and 2018, respectively. At June 30, 2019, we did not have any outstanding balance under the 2019 CTBC Credit Facility revolving line of credit. As of June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit was $25.9 million in U.S. dollars. The interest rate for these loans were 0.93% per annum as of June 30, 2019 and 0.95% per annum as of June 30, 2018. At June 30, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $27.5 million. As of June 30, 2019, the net book value of land and building located in Bade, Taiwan collateralizing the 2019 CTBC Credit Facility term loan was $25.8 million.

[0001375365-19-000079:mdna:154]
Covenant Compliance

[0001375365-19-000079:mdna:155]
2018 Bank of America Credit Facility

[0001375365-19-000079:mdna:156]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains a financial covenant, which requires that we maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect.  We have been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000079:mdna:157]
On September 7, 2018, Bank of America issued an extension letter to us in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, we entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, we paid a fee to extend the delivery to June 30, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, we are required to deliver our audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver our audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If we elect to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, we are required to deliver our audited financial statements by March 31, 2020.

[0001375365-19-000079:mdna:158]
CTBC Bank

[0001375365-19-000079:mdna:159]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.

[0001375365-19-000079:mdna:160]
Share Repurchase Program

[0001375365-19-000079:mdna:161]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100.0 million of our common stock in the open market or in private transactions during the next twelve months at prevailing market prices. In fiscal year 2017, we purchased 888,097 shares of our common stock in the open market at a weighted average price of $20.79 per share for approximately $18.5 million. Repurchases were made under the program using our cash on hand. The repurchase program ended in July 2017. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to repurchase our common stock.

[0001375365-19-000079:mdna:162]
Contractual Obligations

[0001375365-19-000079:mdna:163]
The following table describes our contractual obligations as of June 30, 2019:

[0001375365-19-000079:mdna:164]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 6,582 |  |  | $ | 6,270 |  |  | $ | 2,341 |  |  | $ | 2,279 |  |  | $ | 17,472 |  |
| Capital leases, including interest | 164 |  |  | 143 |  |  | 1 |  |  | — |  |  | 308 |  |
| Debt, including interest (1) | 23,906 |  |  | — |  |  | — |  |  | — |  |  | 23,906 |  |
| Purchase commitments (2) | 299,542 |  |  | 246 |  |  | — |  |  | — |  |  | 299,788 |  |
| Total (3) | $ | 330,194 |  |  | $ | 6,659 |  |  | $ | 2,342 |  |  | $ | 2,279 |  |  | $ | 341,474 |  |

[0001375365-19-000079:mdna:165]
__________________________

[0001375365-19-000079:mdna:166]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rates under our 2018 Bank of America Credit Facility and 2019 CTBC Credit Facility at June 30, 2019. |

[0001375365-19-000079:mdna:167]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. See Part II, Item 8, Note 15, “Commitments and Contingencies” to the consolidated financial statements in this Annual Report for a discussion of purchase commitments. |

[0001375365-19-000079:mdna:168]
| (3) | The table above excludes liabilities for deferred revenue of $203.4 million, $5.0 million of deferred gain related to our remaining performance obligations in association with the contribution of certain technology rights to a privately-held company located in China, and unrecognized tax benefits and related interest and penalties accrual of $20.1 million. Deferred revenue represents billed services in advance which include extended warranty, on-site technical support, and software maintenance. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Part II, Item 8, Note 14, “Income Taxes” to the consolidated financial statements in this Annual Report for a discussion of income taxes. |

[0001375365-19-000079:mdna:169]
We expect to fund our remaining contractual obligations from our ongoing operations and existing cash and cash equivalents on hand.

[0001375365-19-000079:mdna:170]
Recent Accounting Pronouncements

[0001375365-19-000079:mdna:171]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report.

[0001375365-19-000079:mdna:172]
Off-Balance Sheet Arrangements

[0001375365-19-000079:mdna:173]
We do not have any off-balance sheet arrangements.

[0001375365-19-000079:mdna:174]
Quarterly Results of Operations

[0001375365-19-000079:mdna:175]
As described in the Explanatory Note, we are presenting our quarterly results of operations for the periods ended March 31, 2018, December 31, 2017 and September 30, 2017 herein, in lieu of filing separate Quarterly Reports on Form 10-Q for such periods.

[0001375365-19-000079:mdna:176]
Net Sales

[0001375365-19-000079:mdna:177]
The following table presents net sales by product type for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016 (dollars in millions):

[0001375365-19-000079:mdna:178]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Server and storage systems | $ | 669.1 |  |  | $ | 427.6 |  |  | $ | 241.5 |  |  | 56.5 | % |  | $ | 629.7 |  |  | $ | 456.1 |  |  | $ | 173.6 |  |  | 38.1 | % |  | $ | 542.4 |  |  | $ | 358.9 |  |  | $ | 183.5 |  |  | 51.1 | % |
| % of total net sales | 80.1 | % |  | 69.6 | % |  |  |  |  |  | 76.1 | % |  | 68.8 | % |  |  |  |  |  | 75.7 | % |  | 67.9 | % |  |  |  |  |
| Subsystems and accessories | 166.0 |  |  | 187.2 |  |  | (21.2 | ) |  | (11.3 | )% |  | $ | 197.3 |  |  | $ | 207.1 |  |  | $ | (9.8 | ) |  | (4.7 | )% |  | $ | 174.3 |  |  | $ | 169.9 |  |  | $ | 4.4 |  |  | 2.6 | % |
| % of total net sales | 19.9 | % |  | 30.4 | % |  |  |  |  |  | 23.9 | % |  | 31.2 | % |  |  |  |  |  | 24.3 | % |  | 32.1 | % |  |  |  |  |
| Total net sales | $ | 835.1 |  |  | $ | 614.8 |  |  | $ | 220.3 |  |  | 35.8 | % |  | $ | 827.0 |  |  | $ | 663.2 |  |  | $ | 163.8 |  |  | 24.7 | % |  | $ | 716.7 |  |  | $ | 528.8 |  |  | $ | 187.9 |  |  | 35.5 | % |

[0001375365-19-000079:mdna:179]
The period-over-period substantial increase in our net sales in fiscal year 2018, as compared to fiscal year 2017, reflects our continued trend of concentrating our efforts on selling server and storage systems to larger customers such as internet data center and cloud computing and enterprise customers and a stronger industry-wide market for server and storage solutions.

[0001375365-19-000079:mdna:180]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:181]
The period-over-period increase in server and storage systems sales was primarily due to an increase in the average selling price per compute node by approximately by 25% and an increase in the number of units of compute nodes shipped of approximately 22%. The period-over-period decrease in sales of subsystems and accessories was primarily due to a decrease in the volume of subsystems and accessories shipped of approximately 26%, offset by an increase in the average selling price per unit by approximately 11%.

[0001375365-19-000079:mdna:182]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:183]
The period-over-period increase in server and storage systems sales was primarily due to an increase of average selling price per compute node by approximately 23% and an increase in the number of units of compute nodes shipped, of approximately 16%. The period-over-period decrease in sales of subsystems and accessories is primarily due to a decrease in the volume of subsystems and accessories shipped of approximately 18%, offset by an increase in the average selling price per unit by approximately 14%.

[0001375365-19-000079:mdna:184]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:185]
The period-over-period increase in server and storage systems sales was primarily due to an increase of average selling price per compute node by approximately 43%. The increase in the average selling prices of our server and storage systems was primarily due to higher sales of our complete systems configured with higher density computing and more memory and storage capacity and as a result of the increases in the cost of memory and SSDs. The period-over-period increase in sales of subsystems and accessories is primarily due to an increase in the average selling price per unit by approximately 8%, offset by a decrease in the number of units shipped by approximately 8%.

[0001375365-19-000079:mdna:186]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016:

[0001375365-19-000079:mdna:187]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | % |  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| Indirect sales channel | 42.8 | % |  | 46.6 | % |  | (3.8 | )% |  | 41.5 | % |  | 46.5 | % |  | (5.0 | )% |  | 47.3 | % |  | 50.7 | % |  | (3.4 | )% |
| Direct customers and OEMs | 57.2 | % |  | 53.4 | % |  | 3.8 | % |  | 58.5 | % |  | 53.5 | % |  | 5.0 | % |  | 52.7 | % |  | 49.3 | % |  | 3.4 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000079:mdna:188]
The period-over-period decrease in net sales through our indirect sales channel as a percentage of total net sales in each of the three month periods presented in fiscal year 2018, as compared with the corresponding three month periods in fiscal year 2017 were primarily due to the lower sales of our subsystems and accessories. The period-over-period increase in net sales

[0001375365-19-000079:mdna:189]
to direct customers and OEMs as a percentage of total net sales in each of the three month periods presented in fiscal year 2018, as compared with the corresponding three month periods in fiscal year 2017 were primarily due to the increased volume of our server and storage systems to our internet data center and cloud, enterprise and OEM customers, in addition to higher average selling prices.

[0001375365-19-000079:mdna:190]
The following table presents percentages of net sales by geographic region for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016:

[0001375365-19-000079:mdna:191]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | % |  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| United States | 54.5 | % |  | 56.4 | % |  | (1.9 | )% |  | 54.3 | % |  | 58.5 | % |  | (4.2 | )% |  | 57.6 | % |  | 58.9 | % |  | (1.3 | )% |
| Europe | 18.0 | % |  | 17.1 | % |  | 0.9 | % |  | 16.5 | % |  | 18.8 | % |  | (2.3 | )% |  | 14.8 | % |  | 20.3 | % |  | (5.5 | )% |
| Asia | 22.5 | % |  | 21.5 | % |  | 1.0 | % |  | 24.8 | % |  | 18.7 | % |  | 6.1 | % |  | 23.6 | % |  | 16.5 | % |  | 7.1 | % |
| Other | 5.0 | % |  | 5.0 | % |  | — | % |  | 4.4 | % |  | 4.0 | % |  | 0.4 | % |  | 4.0 | % |  | 4.3 | % |  | (0.3 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000079:mdna:192]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:193]
The period-over-period decline in net sales in the United States as a percentage of total net sales was primarily due to higher sales growth of our server and storage systems in China, Taiwan, the Netherlands, United Kingdom and Germany as compared to the United States. The higher sales in Asia and Europe were due to the higher sales of our server and storage systems to our internet data center and cloud, enterprise and OEM customers.

[0001375365-19-000079:mdna:194]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:195]
The period-over-period decline in net sales in the United States and Europe as a percentage of total net sales was primarily due to higher sales growth of our server and storage systems in Asia, particularly China and Taiwan as compared to the United States and Europe. The higher sales in Asia were due to the higher sales of our server and storage systems to our internet data center and cloud, enterprise and OEM customers.

[0001375365-19-000079:mdna:196]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:197]
The period-over-period net sales in the United States, Europe and other countries declined as a percentage of total net sales primarily due to higher sales growth of our server and storage systems in Asia, particularly China and Taiwan as compared to the United States, Europe and other countries. The higher sales in Asia were due to the higher sales of our server and storage systems to our internet data center and cloud, enterprise and OEM customers.

[0001375365-19-000079:mdna:198]
The following table presents net sales by product type for the nine months ended March 31, 2018 and six months ended December 31, 2017 (dollars in millions):

[0001375365-19-000079:mdna:199]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Server and storage systems | $ | 1,841.2 |  |  | $ | 1,242.6 |  |  | $ | 598.6 |  |  | 48.2 | % |  | $ | 1,172.1 |  |  | $ | 815.0 |  |  | $ | 357.1 |  |  | 43.8 | % |
| % of total net sales | 77.4 | % |  | 68.8 | % |  |  |  |  |  | 75.9 | % |  | 68.4 | % |  |  |  |  |
| Subsystems and accessories | $ | 537.6 |  |  | $ | 564.2 |  |  | $ | (26.6 | ) |  | (4.7 | )% |  | $ | 371.6 |  |  | $ | 376.9 |  |  | $ | (5.3 | ) |  | (1.4 | )% |
| % of total net sales | 22.6 | % |  | 31.2 | % |  |  |  |  |  | 24.1 | % |  | 31.6 | % |  |  |  |  |
| Total net sales | $ | 2,378.8 |  |  | $ | 1,806.8 |  |  | $ | 572.0 |  |  | 31.7 | % |  | $ | 1,543.7 |  |  | $ | 1,191.9 |  |  | $ | 351.8 |  |  | 29.5 | % |

[0001375365-19-000079:mdna:200]
The period-over-period substantial increase in our net sales in fiscal year 2018, as compared to fiscal year 2017 for both the nine months ended March 31, 2019 and the six months ended December 31, 2018 reflects our continued focus on selling server and storage systems to larger customers such as internet data center and cloud computing and enterprise

[0001375365-19-000079:mdna:201]
customers, as well as higher average selling prices during a stronger industry-wide expanded market for server and storage solutions.

[0001375365-19-000079:mdna:202]
Comparison of Nine Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:203]
The period-over-period increase in server and storage systems sales was primarily due to an increase in the average selling price per compute node  by approximately 30% and an increase in the number of units of compute nodes shipped by approximately 14%. The period-over-period decrease in sales of subsystems and accessories was primarily due to a decrease in the volume of subsystems and accessories shipped of approximately 17%, offset by an increase in the average selling price per unit by approximately 11%.

[0001375365-19-000079:mdna:204]
Comparison of Six Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:205]
The period-over-period increase in server and storage systems sales was primarily due to an increase in the average selling price per compute node by approximately 32% and an increase in the number of units of compute nodes shipped by approximately 10%. The period-over-period decrease in sales of subsystems and accessories was primarily due to a decrease in the volume of subsystems and accessories shipped by approximately 13%, offset by an increase in the average selling price per unit by approximately 11%.

[0001375365-19-000079:mdna:206]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs for the nine months ended March 31, 2018 and six months ended December 31, 2017:

[0001375365-19-000079:mdna:207]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | % |  | 2017 |  | 2016 |  | % |
| Indirect sales channel | 43.7 | % |  | 47.8 | % |  | (4.1 | )% |  | 44.2 | % |  | 48.4 | % |  | (4.2 | )% |
| Direct customers and OEMs | 56.3 | % |  | 52.2 | % |  | 4.1 | % |  | 55.8 | % |  | 51.6 | % |  | 4.2 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000079:mdna:208]
The period-over-period decrease in net sales through our indirect sales channel as a percentage of total net sales in each of the nine and six month periods presented in fiscal year 2018, as compared with the corresponding nine and six month periods in fiscal year 2017 were primarily due to the lower sales of our subsystems and accessories. The period-over-period increase in net sales to direct customers and OEMs as a percentage of total net sales in each of the nine and six month periods presented in fiscal year 2018, as compared with the corresponding nine and six month periods in fiscal year 2017 were primarily due to the higher sales of server and storage systems to our internet data center, cloud computing, enterprise and OEM customers.

[0001375365-19-000079:mdna:209]
The following table presents percentages of net sales by geographic region for the nine months ended March 31, 2018 and six months ended December 31, 2017 :

[0001375365-19-000079:mdna:210]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | % |  | 2017 |  | 2016 |  | % |
| United States | 55.4 | % |  | 57.9 | % |  | (2.5 | )% |  | 55.8 | % |  | 58.7 | % |  | (2.9 | )% |
| Europe | 16.5 | % |  | 18.6 | % |  | (2.1 | )% |  | 15.8 | % |  | 19.4 | % |  | (3.6 | )% |
| Asia | 23.6 | % |  | 19.0 | % |  | 4.6 | % |  | 24.2 | % |  | 17.7 | % |  | 6.5 | % |
| Other | 4.5 | % |  | 4.5 | % |  | — | % |  | 4.2 | % |  | 4.2 | % |  | — | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000079:mdna:211]
The period-over-period decline in net sales as a percentage of total net sales in the United States and Europe in each of the nine and six month periods presented in fiscal year 2018, as compared with the corresponding nine and six month periods in fiscal year 2017 were primarily due to higher sales growth of our server and storage systems in Asia, particularly China and Taiwan as compared to both the United States and Europe. The higher sales in Asia were attributable to the higher sales of our server and storage systems to our internet data center, cloud computing, enterprise and OEM customers.

[0001375365-19-000079:mdna:212]
Cost of Sales and Gross Margin

[0001375365-19-000079:mdna:213]
Cost of sales and gross margin for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016 are as follows (dollars in millions):

[0001375365-19-000079:mdna:214]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Cost of Sales | $ | 729.2 |  |  | $ | 529.5 |  |  | $ | 199.7 |  |  | 37.7 | % |  | $ | 721.3 |  |  | $ | 567.1 |  |  | $ | 154.2 |  |  | 27.2 | % |  | $ | 630.7 |  |  | $ | 446.2 |  |  | $ | 184.5 |  |  | 41.3 | % |
| Gross Profit | $ | 105.9 |  |  | $ | 85.3 |  |  | $ | 20.6 |  |  | 24.2 | % |  | $ | 105.7 |  |  | $ | 96.1 |  |  | $ | 9.6 |  |  | 10.0 | % |  | $ | 86.1 |  |  | $ | 82.6 |  |  | $ | 3.5 |  |  | 4.2 | % |
| Gross Margin | 12.7 | % |  | 13.9 | % |  |  |  | (1.2 | )% |  | 12.8 | % |  | 14.5 | % |  |  |  | (1.7 | )% |  | 12.0 | % |  | 15.6 | % |  |  |  | (3.6 | )% |

[0001375365-19-000079:mdna:215]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:216]
The period-over-period increase in cost of sales was primarily attributable to an increase of $189.9 million in product cost reflecting higher key component prices and the increase in net sales volume, an increase of $2.0 million in personnel expenses, an increase of $2.5 million in other manufacturing related costs, an increase of $1.3 million of depreciation expense and an increase in other cost of sales of $4.0 million.

[0001375365-19-000079:mdna:217]
The period-over-period decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component sourcing due to component shortages partially offset by higher average selling prices per compute node. The period-over-period growth in net sales in Asia was higher in the three months ended March 31, 2018 which negatively impacted our gross margin due to more competitive pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:218]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:219]
The period-over-period increase in cost of sales was primarily attributable to an increase of $149.3 million in product cost reflecting higher key component prices and the increase in net sales volume, an increase of $1.1 million in personnel expenses, an increase of $1.3 million in depreciation and an increase in other cost of sales of $2.5 million.

[0001375365-19-000079:mdna:220]
The period-over-period decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component sourcing due to component shortages, partially offset by higher average selling prices per compute node. The period-over-period growth in net sales in Asia was higher in the three months ended December 31, 2017 compared to the other major sales regions, this shift in sales mix negatively impacted our gross margin due to lower pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:221]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:222]
The period-over-period increase in cost of sales was primarily attributable to an increase of $176.0 million in product cost reflecting higher key component prices and the increase in net sales volume, an increase of $3.5 million in overhead-related costs related to meeting increased demand, an increase of $1.1 million in personnel expenses, and an increase in other cost of sales of $3.9 million.

[0001375365-19-000079:mdna:223]
The period-over-period decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component sourcing due to component shortages, partially offset by higher average selling prices per compute node. The period-over-period growth in net sales in Asia was higher in the three months ended September 30, 2017, which negatively impacted our gross margin due to more competitive pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:224]
Cost of sales and gross margin for the nine months ended March 31, 2018 and six months ended December 31, 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:225]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Cost of Sales | $ | 2,081.2 |  |  | $ | 1,542.7 |  |  | $ | 538.5 |  |  | 34.9 | % |  | $ | 1,352.0 |  |  | $ | 1,013.3 |  |  | $ | 338.7 |  |  | 33.4 | % |
| Gross Profit | $ | 297.7 |  |  | $ | 264.0 |  |  | $ | 33.7 |  |  | 12.8 | % |  | $ | 191.8 |  |  | $ | 178.7 |  |  | $ | 13.1 |  |  | 7.3 | % |
| Gross Margin | 12.5 | % |  | 14.6 | % |  |  |  | (2.1 | )% |  | 12.4 | % |  | 15.0 | % |  |  |  | (2.6 | )% |

[0001375365-19-000079:mdna:226]
Comparison of Nine Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:227]
The period-over-period increase in cost of sales was primarily attributable to an increase of $515.2 million in product costs reflecting higher key component prices and the increase in net sales volume, an increase of $4.9 million in other manufacturing-related costs, an increase of $4.2 million in compensation and benefits, an increase of $3.2 million in depreciation, an increase of $6.0 million in overhead-related expenses to meet increased demand and an increase in other cost of sales of $5.0 million.

[0001375365-19-000079:mdna:228]
The period-over-period decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component  sourcing due to component shortages partially offset by higher average selling prices per compute node. The period-over-period growth in net sales in Asia was higher in the nine months ended March 31, 2018 which negatively impacted our gross margin due to more competitive pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:229]
Comparison of Six Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:230]
The period-over-period increase in cost of sales was primarily attributable to an increase of $325.3 million in product costs reflecting higher key component prices and the increase in net sales volume, an increase of $2.2 million in compensation and benefits, an increase of $3.5 million in overhead-related expenses to meet increased demand, an increase of $1.9 million in depreciation and an increase in other cost of sales of $5.8 million.

[0001375365-19-000079:mdna:231]
The period-over-period decrease in the gross margin percentage was primarily due to lower sales of our subsystems and accessories and higher sales of our server and storage systems, which reflected higher costs in key component sourcing due to component shortages, partially offset by higher average selling prices per compute node. The period-over-period growth in net sales in Asia was higher in the six months ended December 31, 2017, which negatively impacted our gross margin due to more competitive pricing in Asia as compared to other regions.

[0001375365-19-000079:mdna:232]
Operating Expenses

[0001375365-19-000079:mdna:233]
Operating expenses for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016, are as follows (dollars in millions):

[0001375365-19-000079:mdna:234]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Research and development | $ | 42.3 |  |  | $ | 36.0 |  |  | $ | 6.3 |  |  | 17.5 | % |  | $ | 39.5 |  |  | $ | 35.4 |  |  | $ | 4.1 |  |  | 11.6 | % |  | $ | 40.7 |  |  | $ | 34.1 |  |  | $ | 6.6 |  |  | 19.4 | % |
| Percentage of total net sales | 5.1 | % |  | 5.9 | % |  |  |  |  |  | 4.8 | % |  | 5.3 | % |  |  |  |  |  | 5.7 | % |  | 6.4 | % |  |  |  |  |
| Sales and marketing | $ | 18.9 |  |  | $ | 16.2 |  |  | $ | 2.7 |  |  | 16.7 | % |  | $ | 18.0 |  |  | $ | 16.8 |  |  | $ | 1.2 |  |  | 7.1 | % |  | $ | 16.8 |  |  | $ | 15.2 |  |  | $ | 1.6 |  |  | 10.5 | % |
| Percentage of total net sales | 2.3 | % |  | 2.6 | % |  |  |  |  |  | 2.2 | % |  | 2.5 | % |  |  |  |  |  | 2.3 | % |  | 2.9 | % |  |  |  |  |
| General and administrative | $ | 23.6 |  |  | $ | 11.6 |  |  | $ | 12.0 |  |  | 103.4 | % |  | $ | 25.5 |  |  | $ | 10.4 |  |  | $ | 15.1 |  |  | 145.2 | % |  | $ | 19.3 |  |  | $ | 10.8 |  |  | $ | 8.5 |  |  | 78.7 | % |
| Percentage of total net sales | 2.7 | % |  | 1.9 | % |  |  |  |  |  | 3.1 | % |  | 1.6 | % |  |  |  |  |  | 2.7 | % |  | 2.0 | % |  |  |  |  |
| Total operating expenses | $ | 84.8 |  |  | $ | 63.8 |  |  | $ | 21.0 |  |  | 32.9 | % |  | $ | 83.0 |  |  | $ | 62.6 |  |  | $ | 20.4 |  |  | 32.6 | % |  | $ | 76.7 |  |  | $ | 60.1 |  |  | $ | 16.6 |  |  | 27.6 | % |
| Percentage of total net sales | 10.1 | % |  | 10.4 | % |  |  |  |  |  | 10.0 | % |  | 9.4 | % |  |  |  |  |  | 10.7 | % |  | 11.4 | % |  |  |  |  |

[0001375365-19-000079:mdna:235]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:236]
The period-over-period increase in research and development expenses was primarily due to an increase of $4.8 million in personnel expenses, and a decrease of $1.3 million in reimbursements received for certain research and development costs that we incur pursuant to joint development arrangements with certain of our suppliers and customers.

[0001375365-19-000079:mdna:237]
The period-over-period increase in sales and marketing expenses was primarily due to an increase of $1.9 million in personnel expenses and an increase of $0.8 million in advertising and promotion expenses driven by higher promotional expense associated with our net sales.

[0001375365-19-000079:mdna:238]
The period-over-period increase in general and administrative expenses was primarily due to an increase of $2.9 million in personnel expenses and an increase of $10.1 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, offset by a decrease of $1.0 million in other individually insignificant general and administrative expenses.

[0001375365-19-000079:mdna:239]
Our personnel expenses increased in each of research and development, sales and marketing, and general and administrative expenses, primarily as a result of our annual compensation review and an increase in the number of personnel.

[0001375365-19-000079:mdna:240]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:241]
The period-over-period increase in research and development expenses was primarily due to an increase of $6.3 million in personnel expenses, offset by a decrease of $2.2 million in product development costs.

[0001375365-19-000079:mdna:242]
The period-over-period increase in sales and marketing expenses was primarily due to an increase of $2.0 million in personnel expenses, offset by a decrease in advertising and promotion expenses driven by increased marketing rebates earned under market development arrangements with certain vendors.

[0001375365-19-000079:mdna:243]
The period-over-period increase in general and administrative expenses was primarily due to an increase of $2.8 million in personnel expenses and an increase of $12.3 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements.

[0001375365-19-000079:mdna:244]
Our personnel expenses increased in each of research and development, sales and marketing, and general and administrative expenses, primarily as a result of our annual compensation review as well as an increase in the number of personnel.

[0001375365-19-000079:mdna:245]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:246]
The period-over-period increase in research and development expenses was primarily due to an increase of $5.1 million in personnel expenses, and an increase of $1.2 million in product development costs.

[0001375365-19-000079:mdna:247]
The period-over-period increase in sales and marketing expenses was primarily due to an increase of $1.8 million in personnel expenses.

[0001375365-19-000079:mdna:248]
The period-over-period increase in general and administrative expenses was primarily due to an increase of $3.2 million in personnel expenses and an increase of $6.7 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements. These increases were offset by a decrease of $0.8 million in other individually insignificant general and administrative expenses and a decrease of $0.7 million in the allowance for doubtful accounts.

[0001375365-19-000079:mdna:249]
Our personnel expenses increased in each of research and development, sales and marketing, and general and administrative expenses, primarily as a result of our annual compensation review as well as an increase in the number of personnel.

[0001375365-19-000079:mdna:250]
Operating expenses for the nine months ended March 31, 2018 and six months ended December 31, 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:251]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Research and development | $ | 122.5 |  |  | $ | 105.6 |  |  | $ | 16.9 |  |  | 16.0 | % |  | $ | 80.2 |  |  | $ | 69.6 |  |  | $ | 10.6 |  |  | 15.2 | % |
| Percentage of total net sales | 5.1 | % |  | 5.8 | % |  |  |  |  |  | 5.2 | % |  | 5.8 | % |  |  |  |  |
| Sales and marketing | $ | 53.7 |  |  | $ | 48.2 |  |  | $ | 5.5 |  |  | 11.4 | % |  | $ | 34.8 |  |  | $ | 31.9 |  |  | $ | 2.9 |  |  | 9.1 | % |
| Percentage of total net sales | 2.3 | % |  | 2.7 | % |  |  |  |  |  | 2.3 | % |  | 2.7 | % |  |  |  |  |
| General and administrative | $ | 68.2 |  |  | $ | 32.8 |  |  | $ | 35.4 |  |  | 107.9 | % |  | $ | 44.7 |  |  | $ | 21.2 |  |  | $ | 23.5 |  |  | 110.8 | % |
| Percentage of total net sales | 2.9 | % |  | 1.8 | % |  |  |  |  |  | 2.9 | % |  | 1.8 | % |  |  |  |  |
| Total operating expenses | $ | 244.5 |  |  | $ | 186.6 |  |  | $ | 57.8 |  |  | 31.0 | % |  | $ | 159.7 |  |  | $ | 122.7 |  |  | $ | 37.0 |  |  | 30.2 | % |
| Percentage of total net sales | 10.3 | % |  | 10.3 | % |  |  |  |  |  | 10.3 | % |  | 10.3 | % |  |  |  |  |

[0001375365-19-000079:mdna:252]
Comparison of Nine Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:253]
The period-over-period increase in research and development expenses was primarily due to an increase of $16.2 million in personnel expenses, a decrease of $1.3 million in reimbursements received for certain research and development costs that we incur pursuant to joint development arrangements with certain of our suppliers and customers, offset by a decrease of $1.0 million in product development costs.

[0001375365-19-000079:mdna:254]
The period-over-period increase in sales and marketing expenses was primarily due to an increase of $5.7 million in personnel expenses, offset by a decrease in other individually insignificant sales and marketing expenses.

[0001375365-19-000079:mdna:255]
The period-over-period increase in general and administrative expenses was primarily due to an increase of $8.9 million in personnel expenses, and an increase of $29.1 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements. These increases were offset by a decrease of $1.5 million in other individually insignificant general and administrative expenses, and a decrease of $1.0 million in allowance for doubtful accounts.

[0001375365-19-000079:mdna:256]
Our personnel expenses increased in each of research and development, sales and marketing, and general and administrative expenses, primarily as a result of our annual compensation review as well as an increase in the number of personnel.

[0001375365-19-000079:mdna:257]
Comparison of Six Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:258]
The period-over-period increase in research and development expenses was primarily due to an increase of $11.4 million in personnel expenses, offset by a decrease of $1.0 million in product development costs.

[0001375365-19-000079:mdna:259]
The period-over-period increase in sales and marketing expenses was primarily due to an increase of $3.8 million in personnel expenses, offset by a decrease in advertising and promotion expenses driven by increased marketing rebates earned under market development arrangements with certain vendors and a decrease in other individually insignificant sales and marketing expense.

[0001375365-19-000079:mdna:260]
The period-over-period increase in general and administrative expenses was primarily due to an increase of $6.0 million in personnel expenses, and an increase of $19.0 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements. These increases were offset by a decrease of $0.7 million in other individually insignificant general and administrative expenses, including a decrease of $0.8 million in the allowance for doubtful accounts.

[0001375365-19-000079:mdna:261]
Our personnel expenses increased in each of research and development, sales and marketing, and general and administrative expenses, primarily as a result of our annual compensation review as well as an increase in the number of personnel.

[0001375365-19-000079:mdna:262]
Interest and Other Income (Expense), Net

[0001375365-19-000079:mdna:263]
Interest and other income (expense), net for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016, are as follows (dollars in millions):

[0001375365-19-000079:mdna:264]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Other income (expense), net | $ | (0.4 | ) |  | $ | (1.5 | ) |  | $ | 1.1 |  |  | (73.3 | )% |  | $ | (0.4 | ) |  | $ | 0.7 |  |  | $ | (1.1 | ) |  | (157.1 | )% |  | $ | (0.8 | ) |  | $ | (0.4 | ) |  | $ | (0.4 | ) |  | 100.0 | % |
| Interest expense | (1.3 | ) |  | (0.6 | ) |  | (0.7 | ) |  | 116.7 | % |  | (1.1 | ) |  | (0.5 | ) |  | (0.6 | ) |  | 120.0 | % |  | (1.1 | ) |  | (0.3 | ) |  | (0.8 | ) |  | 266.7 | % |
| Interest and other income (expense), net | $ | (1.7 | ) |  | $ | (2.1 | ) |  | $ | 0.4 |  |  |  |  | $ | (1.5 | ) |  | $ | 0.2 |  |  | $ | (1.7 | ) |  |  |  | $ | (1.9 | ) |  | $ | (0.7 | ) |  | $ | (1.2 | ) |  |  |

[0001375365-19-000079:mdna:265]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:266]
Interest and other expense, net remained largely consistent period-over-period.

[0001375365-19-000079:mdna:267]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:268]
The period-over-period increase in interest and other income (expense), net was primarily due to an increase of $0.6 million in interest expense attributable to increased borrowings under our credit facilities to support our growth and an increase in foreign exchange losses of $1.1 million attributable to unfavorable foreign currency fluctuations.

[0001375365-19-000079:mdna:269]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:270]
The period-over-period increase in interest and other expense, net was primarily due to an increase of $0.8 million in interest expense attributable to increased borrowings under our credit facilities to support our growth and an impairment recorded for an investment, offset by favorable foreign currency fluctuations.

[0001375365-19-000079:mdna:271]
Interest and other income (expense), net for the nine months ended March 31, 2018 and six months ended December 31, 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:272]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Other income (expense), net | $ | (1.6 | ) |  | $ | (1.3 | ) |  | $ | (0.3 | ) |  | 23.1 | % |  | $ | (1.2 | ) |  | $ | 0.2 |  |  | $ | (1.4 | ) |  | (700.0 | )% |
| Interest expense | (3.5 | ) |  | (1.4 | ) |  | (2.1 | ) |  | 150.0 | % |  | (2.2 | ) |  | (0.8 | ) |  | (1.4 | ) |  | 175.0 | % |
| Interest and other income (expense), net | $ | (5.1 | ) |  | $ | (2.7 | ) |  | $ | (2.4 | ) |  |  |  | $ | (3.4 | ) |  | $ | (0.6 | ) |  | $ | (2.8 | ) |  |  |

[0001375365-19-000079:mdna:273]
Comparison of Nine Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:274]
The period-over-period increase in interest and other expense, net was primarily due to an increase of $2.1 million in interest expense attributable to increased borrowings under our credit facilities to support our growth.

[0001375365-19-000079:mdna:275]
Comparison of Six Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:276]
The period-over-period increase in interest and other income (expense), net was primarily due to an increase of $1.4 million in interest expense attributable to increased borrowings under our credit facilities to support our growth and an increase of $1.4 million primarily attributable to an impairment recorded for an investment and an increase in foreign exchange losses due to unfavorable foreign currency fluctuations.

[0001375365-19-000079:mdna:277]
Provision for Income Taxes

[0001375365-19-000079:mdna:278]
Provision for income taxes and effective tax rates for the three months ended March 31, 2018 and 2017, December 31, 2017 and 2016, and September 30, 2017 and 2016, are as follows (dollars in millions):

[0001375365-19-000079:mdna:279]
|  | Three months endedMarch 31, |  | Change |  | Three months endedDecember 31, |  | Change |  | Three months endedSeptember 30, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Income tax provision | $ | 4.2 |  |  | $ | 4.0 |  |  | $ | 0.2 |  |  | 5.0 | % |  | $ | 20.8 |  |  | $ | 10.8 |  |  | $ | 10.0 |  |  | 92.6 | % |  | $ | 0.7 |  |  | $ | 6.3 |  |  | $ | (5.6 | ) |  | (88.9 | )% |
| Percentage of total net sales | 0.5 | % |  | 0.7 | % |  |  |  |  |  | 2.5 | % |  | 1.6 | % |  |  |  |  |  | 0.1 | % |  | 1.2 | % |  |  |  |  |
| Effective tax rate | 21.4 | % |  | 20.8 | % |  |  |  |  |  | 98.2 | % |  | 32.1 | % |  |  |  |  |  | 9.8 | % |  | 29.0 | % |  |  |  |  |

[0001375365-19-000079:mdna:280]
Comparison of Three Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:281]
The period-over-period increase in the effective tax rate was primarily attributable to the benefit related to the release of certain tax reserves following the completion of an income tax audit in a foreign jurisdiction in the prior period.

[0001375365-19-000079:mdna:282]
Comparison of Three Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:283]
The period-over-period increase in the effective tax rate was primarily attributable to a $12.9 million one-time write down of U.S. deferred tax assets and liabilities, resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and a U.S. federal one-time transition tax of $2.8 million, each in connection with the 2017 Tax Reform Act.

[0001375365-19-000079:mdna:284]
Comparison of Three Months Ended September 30, 2017 and 2016

[0001375365-19-000079:mdna:285]
The year-over-year decrease in the effective tax rate was primarily due to a reduction of the statutory tax rate from 28.1% to 21%, as a result of tax reform, and a prior year recording of a one-time $12.9 million write down of U.S. deferred tax assets and liabilities, and a one-time transition tax of $2.8 million, all as a result of the 2017 Tax Reform Act.

[0001375365-19-000079:mdna:286]
Provision for income taxes and effective tax rates for the nine months ended March 31, 2018 and six months ended December 31, 2017 are as follows (dollars in millions):

[0001375365-19-000079:mdna:287]
|  | Nine months endedMarch 31, |  | Change |  | Six months endedDecember 31, |  | Change |
|  | 2018 |  | 2017 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Income tax provision | $ | 25.7 |  |  | $ | 21.1 |  |  | $ | 4.6 |  |  | 21.8 | % |  | $ | 21.6 |  |  | $ | 17.1 |  |  | $ | 4.5 |  |  | 26.3 | % |
| Percentage of total net sales | 1.1 | % |  | 1.2 | % |  |  |  |  |  | 1.4 | % |  | 1.4 | % |  |  |  |  |
| Effective tax rate | 53.5 | % |  | 28.3 | % |  |  |  |  |  | 75.3 | % |  | 30.9 | % |  |  |  |  |

[0001375365-19-000079:mdna:288]
Comparison of Nine Months Ended March 31, 2018 and 2017

[0001375365-19-000079:mdna:289]
The period-over-period increase in the effective tax rate was primarily attributable to a $12.9 million one-time write down of U.S. deferred tax assets and liabilities, resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and a U.S. federal one-time transition tax of $2.8 million, each in connection with the 2017 Tax Reform Act.

[0001375365-19-000079:mdna:290]
Comparison of Six Months Ended December 31, 2017 and 2016

[0001375365-19-000079:mdna:291]
The period-over-period increase in the effective tax rate was primarily attributable to a $12.9 million one-time write down of U.S. deferred tax assets and liabilities, resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and a U.S. federal one-time transition tax of $2.8 million, each in connection with the 2017 Tax Reform Act.

[0001375365-19-000079:mdna:292]
Quarterly Financial Information (Unaudited)

[0001375365-19-000079:mdna:293]
As described in the Explanatory Note, we are presenting our quarterly financial information for the periods ended March 31, 2018, December 31, 2017 and September 30, 2017 herein in lieu of filing separate Quarterly Reports on Form 10-Q for such periods.

[0001375365-19-000079:mdna:294]
SUPER MICRO COMPUTER, INC.

[0001375365-19-000079:mdna:295]
CONSOLIDATED BALANCE SHEETS (unaudited)

[0001375365-19-000079:mdna:296]
(in thousands, except share and per share amounts)

[0001375365-19-000079:mdna:297]
|  | March 31, |  | December 31, |  | September 30 |  | June 30, |
|  | 2018 |  | 2017 |  | 2017 |  | 2017 |
| ASSETS |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 135,897 |  |  | $ | 129,214 |  |  | $ | 137,456 |  |  | $ | 110,606 |  |
| Accounts receivable, net | 347,807 |  |  | 354,981 |  |  | 329,825 |  |  | 324,004 |  |
| Inventories | 822,069 |  |  | 844,847 |  |  | 778,214 |  |  | 736,668 |  |
| Prepaid expenses and other current assets | 115,012 |  |  | 112,581 |  |  | 98,584 |  |  | 89,888 |  |
| Total current assets | 1,420,785 |  |  | 1,441,623 |  |  | 1,344,079 |  |  | 1,261,166 |  |
| Investment in equity investee | 4,027 |  |  | 4,426 |  |  | 5,393 |  |  | 6,067 |  |
| Property, plant and equipment, net | 197,561 |  |  | 199,002 |  |  | 197,760 |  |  | 195,576 |  |
| Deferred income taxes, net | 28,461 |  |  | 27,136 |  |  | 39,191 |  |  | 39,119 |  |
| Other assets | 13,907 |  |  | 15,036 |  |  | 13,202 |  |  | 13,202 |  |
| Total assets | $ | 1,664,741 |  |  | $ | 1,687,223 |  |  | $ | 1,599,625 |  |  | $ | 1,515,130 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable | $ | 411,116 |  |  | $ | 489,959 |  |  | $ | 414,458 |  |  | $ | 396,895 |  |
| Accrued liabilities | 104,105 |  |  | 93,152 |  |  | 87,426 |  |  | 79,867 |  |
| Income taxes payable | 4,742 |  |  | 7,736 |  |  | 4,312 |  |  | 1,364 |  |
| Short-term debt, net of debt issuance costs | 186,284 |  |  | 177,650 |  |  | 179,857 |  |  | 161,447 |  |
| Deferred revenue | 50,738 |  |  | 43,414 |  |  | 50,911 |  |  | 32,957 |  |
| Total current liabilities | 756,985 |  |  | 811,911 |  |  | 736,964 |  |  | 672,530 |  |
| Deferred revenue, non-current | 72,894 |  |  | 61,399 |  |  | 53,776 |  |  | 47,548 |  |
| Other long-term liabilities | 21,810 |  |  | 20,899 |  |  | 20,750 |  |  | 21,206 |  |
| Total liabilities | 851,689 |  |  | 894,209 |  |  | 811,490 |  |  | 741,284 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.001 par value |  |  |  |  |  |  |  |
| Authorized shares: 100,000,000 |  |  |  |  |  |  |  |
| Issued shares: 50,808,161, 50,712,177, 50,623,630 and 50,273,527 at March 31, 2018, December 31, 2017, September 30, 2017 and June 30, 2017, respectively | 326,863 |  |  | 321,738 |  |  | 316,203 |  |  | 308,271 |  |
| Treasury stock (at cost), 1,333,125 shares | (20,491 | ) |  | (20,491 | ) |  | (20,491 | ) |  | (20,491 | ) |
| Accumulated other comprehensive income (loss) | 522 |  |  | 204 |  |  | 72 |  |  | (77 | ) |
| Retained earnings | 505,997 |  |  | 491,402 |  |  | 492,185 |  |  | 485,973 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 812,891 |  |  | 792,853 |  |  | 787,969 |  |  | 773,676 |  |
| Noncontrolling interest | 161 |  |  | 161 |  |  | 166 |  |  | 170 |  |
| Total stockholders’ equity | 813,052 |  |  | 793,014 |  |  | 788,135 |  |  | 773,846 |  |
| Total liabilities and stockholders’ equity | $ | 1,664,741 |  |  | $ | 1,687,223 |  |  | $ | 1,599,625 |  |  | $ | 1,515,130 |  |

[0001375365-19-000079:mdna:298]
60

[0001375365-19-000079:mdna:299]
SUPER MICRO COMPUTER, INC.

[0001375365-19-000079:mdna:300]
CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited)

[0001375365-19-000079:mdna:301]
(in thousands, except per share amounts)

[0001375365-19-000079:mdna:302]
|  | Three Months Ended |
|  | September 30, |
|  | 2017 |  | 2016 |
| Net sales | $ | 716,737 |  |  | $ | 528,763 |  |
| Cost of sales | 630,683 |  |  | 446,211 |  |
| Gross profit | 86,054 |  |  | 82,552 |  |
| Operating expenses: |  |  |  |
| Research and development | 40,668 |  |  | 34,150 |  |
| Sales and marketing | 16,796 |  |  | 15,163 |  |
| General and administrative | 19,271 |  |  | 10,816 |  |
| Total operating expenses | 76,735 |  |  | 60,129 |  |
| Income from operations | 9,319 |  |  | 22,423 |  |
| Other expense, net | (796 | ) |  | (449 | ) |
| Interest expense | (1,083 | ) |  | (330 | ) |
| Income before income tax provision | 7,440 |  |  | 21,644 |  |
| Income tax provision | (726 | ) |  | (6,271 | ) |
| Share of loss from equity investee, net of taxes | (635 | ) |  | — |  |
| Net income | $ | 6,079 |  |  | $ | 15,373 |  |
| Net income per common share: |  |  |  |
| Basic | $ | 0.12 |  |  | $ | 0.32 |  |
| Diluted | $ | 0.12 |  |  | $ | 0.30 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |
| Basic | 49,097 |  |  | 48,165 |  |
| Diluted | 52,449 |  |  | 51,120 |  |

[0001375365-19-000079:mdna:303]
SUPER MICRO COMPUTER, INC.

[0001375365-19-000079:mdna:304]
CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited)

[0001375365-19-000079:mdna:305]
(in thousands, except per share amounts)

[0001375365-19-000079:mdna:306]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, |  | December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 826,983 |  |  | $ | 663,200 |  |  | $ | 1,543,720 |  |  | $ | 1,191,963 |  |
| Cost of sales | 721,289 |  |  | 567,064 |  |  | 1,351,972 |  |  | 1,013,275 |  |
| Gross profit | 105,694 |  |  | 96,136 |  |  | 191,748 |  |  | 178,688 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 39,544 |  |  | 35,458 |  |  | 80,212 |  |  | 69,608 |  |
| Sales and marketing | 17,995 |  |  | 16,776 |  |  | 34,791 |  |  | 31,939 |  |
| General and administrative | 25,460 |  |  | 10,381 |  |  | 44,731 |  |  | 21,197 |  |
| Total operating expenses | 82,999 |  |  | 62,615 |  |  | 159,734 |  |  | 122,744 |  |
| Income from operations | 22,695 |  |  | 33,521 |  |  | 32,014 |  |  | 55,944 |  |
| Other (expense) income, net | (394 | ) |  | 690 |  |  | (1,190 | ) |  | 241 |  |
| Interest expense | (1,088 | ) |  | (497 | ) |  | (2,171 | ) |  | (827 | ) |
| Income before income tax provision | 21,213 |  |  | 33,714 |  |  | 28,653 |  |  | 55,358 |  |
| Income tax provision | (20,840 | ) |  | (10,838 | ) |  | (21,566 | ) |  | (17,109 | ) |
| Share of loss from equity investee, net of taxes | (1,156 | ) |  | — |  |  | (1,791 | ) |  | — |  |
| Net (loss) income | $ | (783 | ) |  | $ | 22,876 |  |  | $ | 5,296 |  |  | $ | 38,249 |  |
| Net (loss) income per common share: |  |  |  |  |  |  |  |
| Basic | $ | (0.02 | ) |  | $ | 0.48 |  |  | $ | 0.11 |  |  | $ | 0.79 |  |
| Diluted | $ | (0.02 | ) |  | $ | 0.44 |  |  | $ | 0.10 |  |  | $ | 0.74 |  |
| Weighted-average shares used in calculation of net (loss) income per common share: |  |  |  |  |  |  |  |
| Basic | 49,335 |  |  | 48,124 |  |  | 49,216 |  |  | 48,144 |  |
| Diluted | 49,335 |  |  | 51,521 |  |  | 52,220 |  |  | 51,352 |  |

[0001375365-19-000079:mdna:307]
62

[0001375365-19-000079:mdna:308]
SUPER MICRO COMPUTER, INC.

[0001375365-19-000079:mdna:309]
CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited)

[0001375365-19-000079:mdna:310]
(in thousands, except per share amounts)

[0001375365-19-000079:mdna:311]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 835,110 |  |  | $ | 614,798 |  |  | $ | 2,378,830 |  |  | $ | 1,806,761 |  |
| Cost of sales | 729,193 |  |  | 529,461 |  |  | 2,081,165 |  |  | 1,542,736 |  |
| Gross profit | 105,917 |  |  | 85,337 |  |  | 297,665 |  |  | 264,025 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 42,284 |  |  | 36,017 |  |  | 122,496 |  |  | 105,625 |  |
| Sales and marketing | 18,893 |  |  | 16,249 |  |  | 53,684 |  |  | 48,188 |  |
| General and administrative | 23,555 |  |  | 11,546 |  |  | 68,286 |  |  | 32,743 |  |
| Total operating expenses | 84,732 |  |  | 63,812 |  |  | 244,466 |  |  | 186,556 |  |
| Income from operations | 21,185 |  |  | 21,525 |  |  | 53,199 |  |  | 77,469 |  |
| Other expense, net | (388 | ) |  | (1,517 | ) |  | (1,578 | ) |  | (1,276 | ) |
| Interest expense | (1,326 | ) |  | (558 | ) |  | (3,497 | ) |  | (1,385 | ) |
| Income before income tax provision | 19,471 |  |  | 19,450 |  |  | 48,124 |  |  | 74,808 |  |
| Income tax provision | (4,159 | ) |  | (4,023 | ) |  | (25,725 | ) |  | (21,132 | ) |
| Share of loss from equity investee, net of taxes | (717 | ) |  | (77 | ) |  | (2,508 | ) |  | (77 | ) |
| Net income | $ | 14,595 |  |  | $ | 15,350 |  |  | $ | 19,891 |  |  | $ | 53,599 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.30 |  |  | $ | 0.32 |  |  | $ | 0.40 |  |  | $ | 1.11 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.30 |  |  | $ | 0.38 |  |  | $ | 1.04 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 49,425 |  |  | 48,445 |  |  | 49,285 |  |  | 48,243 |  |
| Diluted | 51,679 |  |  | 51,918 |  |  | 52,090 |  |  | 51,579 |  |

[0001375365-19-000079:mdna:312]
Related Party Transactions

[0001375365-19-000079:mdna:313]
Consolidated Balance Sheets (unaudited)

[0001375365-19-000079:mdna:314]
|  | March 31, |  | December 31, |  | September 30, |  | June 30, |
|  | 2018 |  | 2017 |  | 2017 |  | 2017 |
| ASSETS |  |  |  |  |  |  |  |
| Accounts receivable, net | $ | 1,723 |  |  | $ | 4,834 |  |  | $ | 4,008 |  |  | $ | 6,877 |  |
| Prepaid expenses and other current assets | 20,291 |  |  | 20,315 |  |  | 11,777 |  |  | 13,327 |  |
| Total assets | $ | 22,014 |  |  | $ | 25,149 |  |  | $ | 15,785 |  |  | $ | 20,204 |  |
| LIABILITIES |  |  |  |  |  |  |  |
| Accounts payable | $ | 80,760 |  |  | $ | 74,257 |  |  | $ | 56,630 |  |  | $ | 55,928 |  |
| Accrued liabilities | 17,066 |  |  | 15,060 |  |  | 11,316 |  |  | 8,450 |  |
| Other long-term liabilities | 3,850 |  |  | 4,200 |  |  | 4,550 |  |  | 4,900 |  |
| Total liabilities | $ | 101,676 |  |  | $ | 93,517 |  |  | $ | 72,496 |  |  | $ | 69,278 |  |

[0001375365-19-000079:mdna:315]
Consolidated Statements of Operations (unaudited)

[0001375365-19-000079:mdna:316]
|  | Three Months Ended |
|  | September 30, |
|  | 2017 |  | 2016 |
| Net sales | $ | 11,929 |  |  | $ | 3,567 |  |
| Cost of sales | 60,516 |  |  | 50,220 |  |

[0001375365-19-000079:mdna:317]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, |  | December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 16,656 |  |  | $ | 6,410 |  |  | $ | 28,585 |  |  | $ | 9,974 |  |
| Cost of sales | 68,428 |  |  | 64,999 |  |  | 128,944 |  |  | 115,220 |  |

[0001375365-19-000079:mdna:318]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 17,614 |  |  | $ | 10,217 |  |  | $ | 46,199 |  |  | $ | 20,191 |  |
| Cost of sales | 62,861 |  |  | 62,523 |  |  | 191,805 |  |  | 177,742 |  |
