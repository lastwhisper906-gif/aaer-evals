# SMCI notes — 0001628280-15-007025


## smci:CertainSignificantRisksandUncertaintiesPolicyPolicyTextBlock

[0001628280-15-007025:notes:1]
Certain Significant Risks and Uncertainties

[0001628280-15-007025:notes:2]
The Company operates in the high technology industry and is subject to a number of risks, some of which are beyond the Company’s control, that could have a material adverse effect on the Company’s business, operating results, and financial condition. These risks include variability and uncertainty of revenues and operating results; product obsolescence; geographic concentration; international operations; dependence on key personnel; competition; intellectual property claims and litigation; management of growth; and limited sources of supply.


## smci:ConcentrationofCreditRiskPolicyPolicyTextBlock

[0001628280-15-007025:notes:3]
Concentration of Credit Risk

[0001628280-15-007025:notes:4]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents and long-term investments and accounts receivable.


## smci:ConcentrationofSupplierRiskPolicyPolicyTextBlock

[0001628280-15-007025:notes:5]
Concentration of Supplier Risk

[0001628280-15-007025:notes:6]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry.


## smci:InvestmentsandOtherAssetsPolicyPolicyTextBlock

[0001628280-15-007025:notes:7]
Other Assets

[0001628280-15-007025:notes:8]
As of June 30, 2015, other assets consist primarily of a long-term deferred service costs of $1,490,000, investments in privately held companies of $1,411,000, a long-term prepaid royalty license of $997,000 and restricted cash of $840,000. As of June 30, 2014, other assets consist primarily of a long-term prepaid royalty license of $1,246,000, an investment in a privately held company of $750,000 and restricted cash of $450,000. Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California, one deposit to an escrow account required by the Company's worker's compensation program and bank guarantees in connection with office leases in the Netherlands.


## smci:PropertyPlantAndEquipmentUsefulLifeTableTextBlock

[0001628280-15-007025:notes:9]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001628280-15-007025:notes:10]
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Software | 3 to 5 years |
| Buildings | 39 years |
| Building improvements | 20 years |
| Land improvements | 15 years |
| Leasehold improvements | shorter of lease term or estimated useful life |


## smci:SummaryOfAllowanceForDoubtfulAccountsAndSalesReturnsTableTextBlock

[0001628280-15-007025:notes:11]
Accounts receivable allowances as of June 30, 2015, 2014 and 2013, consisted of the following (in thousands):

[0001628280-15-007025:notes:12]
|  | BeginningBalance |  | Charged toCost andExpenses |  | Deductions |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2015 | $ | 1,474 |  |  | $ | 326 |  |  | $ | (602 | ) |  | $ | 1,198 |  |
| Year ended June 30, 2014 | 1,562 |  |  | 1,476 |  |  | (1,564 | ) |  | 1,474 |  |
| Year ended June 30, 2013 | 777 |  |  | 929 |  |  | (144 | ) |  | 1,562 |  |
| Allowance for sales returns |  |  |  |  |  |  |  |
| Year ended June 30, 2015 | $ | 448 |  |  | $ | 9,383 |  |  | $ | (9,401 | ) |  | $ | 430 |  |
| Year ended June 30, 2014 | 404 |  |  | 8,985 |  |  | (8,941 | ) |  | 448 |  |
| Year ended June 30, 2013 | 329 |  |  | 7,463 |  |  | (7,388 | ) |  | 404 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-15-007025:notes:13]
Accrued Liabilities

[0001628280-15-007025:notes:14]
Accrued liabilities as of June 30, 2015 and 2014 consisted of the following (in thousands):

[0001628280-15-007025:notes:15]
|  | June 30, |
|  | 2015 |  | 2014 |
| Accrued payroll and related expenses | $ | 15,141 |  |  | $ | 11,624 |  |
| Customer deposits | 6,314 |  |  | 4,185 |  |
| Accrued warranty costs | 7,700 |  |  | 7,083 |  |
| Accrued cooperative marketing expenses | 5,690 |  |  | 4,387 |  |
| Deferred service revenue | 4,085 |  |  | 2,463 |  |
| Others | 7,813 |  |  | 7,822 |  |
| Total accrued liabilities | $ | 46,743 |  |  | $ | 37,564 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001628280-15-007025:notes:16]
Advertising Costs

[0001628280-15-007025:notes:17]
Advertising costs are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001628280-15-007025:notes:18]
Cash and Cash Equivalents

[0001628280-15-007025:notes:19]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposits with maturities of less than three months.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-007025:notes:20]
Commitments and Contingencies

[0001628280-15-007025:notes:21]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-15-007025:notes:22]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of June 30, 2015, these remaining non-cancellable commitments were $378,341,000 compared to $211,090,000 as of June 30, 2014.

[0001628280-15-007025:notes:23]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $185,680,000, which will be paid through December 2016. The Company entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.

[0001628280-15-007025:notes:24]
Lease Commitments—The Company leases offices and equipment under noncancelable operating leases which expire at various dates through 2025. In addition, the Company leases certain of its equipment under capital leases. The future minimum lease commitments under all leases are as follows (in thousands):

[0001628280-15-007025:notes:25]
|  | Balance as of |
| Year ending: | CapitalLeases |  | OperatingLeases |
| June 30, 2016 | $ | 200 |  |  | $ | 4,344 |  |
| June 30, 2017 | 194 |  |  | 3,347 |  |
| June 30, 2018 | 167 |  |  | 2,840 |  |
| June 30, 2019 | 128 |  |  | 2,862 |  |
| June 30, 2020 | 27 |  |  | 2,913 |  |
| Thereafter | — |  |  | 3,545 |  |
| Total minimum lease payments | 716 |  |  | $ | 19,851 |  |
| Less: Amounts representing interest | 76 |  |  |  |
| Present value of minimum lease payments | 640 |  |  |  |
| Less: Long-term portion | 475 |  |  |  |
| Current portion | $ | 165 |  |  |  |

[0001628280-15-007025:notes:26]
Rent expense for the years ended June 30, 2015, 2014 and 2013, was $3,729,000, $3,477,000 and $3,345,000, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-15-007025:notes:27]
Basis of Presentation

[0001628280-15-007025:notes:28]
The consolidated financial statements reflect the consolidated balance sheets, results of operations and cash flows of Super Micro Computer, Inc. and its wholly-owned subsidiaries (collectively, the “Company”). All intercompany accounts and transactions have been eliminated in consolidation.

[0001628280-15-007025:notes:29]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the Consolidated Balance Sheets. Net income attributable to the noncontrolling interest is not presented separately in the Consolidated Statements of Operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:CostOfSalesPolicyTextBlock

[0001628280-15-007025:notes:30]
Cost of Sales

[0001628280-15-007025:notes:31]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses, equipment and facility expenses, warranty costs and provision for lower of cost or market and excess and obsolete inventory.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-007025:notes:32]
Short-term and Long-term Obligations

[0001628280-15-007025:notes:33]
Short-term and long-term obligations as of June 30, 2015 and 2014 consisted of the following (in thousands):

[0001628280-15-007025:notes:34]
|  | June 30, |
|  | 2015 |  | 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 59,699 |  |  | $ | 17,699 |  |
| CTBC Bank | 9,700 |  |  | — |  |
| Total line of credit | 69,399 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 3,733 |  |  | 6,533 |  |
| CTBC Bank | 21,280 |  |  | 22,055 |  |
| Total building term loans | 25,013 |  |  | 28,588 |  |
| Total debt | 94,412 |  |  | 46,287 |  |
| Current portion | (93,479 | ) |  | (42,554 | ) |
| Long-term portion | $ | 933 |  |  | $ | 3,733 |  |

[0001628280-15-007025:notes:35]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-15-007025:notes:36]
Bank of America

[0001628280-15-007025:notes:37]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that matures on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum.

[0001628280-15-007025:notes:38]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.18% at June 30, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-007025:notes:39]
As of June 30, 2015 and 2014, the total outstanding borrowings under the Bank of America term loan was $3,733,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $59,699,000 and $17,699,000 as of June 30, 2015 and 2014, respectively. The interest rates for these loans ranged from 0.79% to 1.68% per annum at June 30, 2015 and from 1.19%  to 1.65% per annum at June 30, 2014, respectively. As of June 30, 2015, the unused revolving line of credit with Bank of America was $5,301,000.

[0001628280-15-007025:notes:40]
CTBC Bank

[0001628280-15-007025:notes:41]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollars or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollars or $14,912,000 U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

[0001628280-15-007025:notes:42]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

[0001628280-15-007025:notes:43]
In December 2014, the Company entered into a second amendment to the existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $31,453,000 U.S. dollar equivalents.

[0001628280-15-007025:notes:44]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,280,000 and $22,055,000 at June 30, 2015 and 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9,700,000 in U.S. dollars at June 30, 2015. There were no outstanding borrowings under the CTBC Bank revolving line of credit at June 30, 2014. The interest rate for this loan ranged from 0.82% and 1.16% at June 30, 2015 and 1.15% per annum at June 30, 2014. At June 30, 2015, NT$39,145,000 or $1,286,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-007025:notes:45]
Covenant Compliance

[0001628280-15-007025:notes:46]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-007025:notes:47]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001628280-15-007025:notes:48]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001628280-15-007025:notes:49]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001628280-15-007025:notes:50]
As of June 30, 2015 and 2014, total assets of $1,045,408,000 and $751,396,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of June 30, 2015 and 2014, total assets collateralizing the term loan with Bank of America were $17,354,000 and $17,584,000. As of June 30, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001628280-15-007025:notes:51]
As of June 30, 2015 and 2014, the land and building located in Bade, Taiwan with a value of  $27,047,000 and $27,345,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with China Trust Bank at June 30, 2015.

[0001628280-15-007025:notes:52]
Debt Maturities

[0001628280-15-007025:notes:53]
The following table as of June 30, 2015, summarizes future minimum principal payments on the Company’s debts excluding capital leases (in thousands):

[0001628280-15-007025:notes:54]
| Fiscal Years Ending June 30, |  |
| 2016 | $ | 93,479 |  |
| 2017 | 933 |  |
| 2018 | — |  |
| 2019 | — |  |
| 2020 | — |  |
| Thereafter | — |  |
| Total | $ | 94,412 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-007025:notes:55]
Stock-based Compensation and Stockholders’ Equity

[0001628280-15-007025:notes:56]
Equity Incentive Plan

[0001628280-15-007025:notes:57]
The authorized number of shares that may be issued under the Company's 2006 Equity Incentive Plan (the "2006 Plan") automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and restricted stock units vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. The 2006 Plan is the successor equity incentive plan to the Company's 1998 Stock Option Plan. As of June 30, 2015, the Company had 482,258 authorized shares available for future issuance under the 2006 plan.

[0001628280-15-007025:notes:58]
Determining Fair Value

[0001628280-15-007025:notes:59]
Valuation and amortization method—The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. The fair value of restricted stock units is based on the closing market price of the Company's common stock on the date of grant. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-15-007025:notes:60]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and the Company's historical experience.

[0001628280-15-007025:notes:61]
Expected Volatility—Expected volatility is based on a combination of the Company's implied and historical volatility.

[0001628280-15-007025:notes:62]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001628280-15-007025:notes:63]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the U.S. Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001628280-15-007025:notes:64]
Estimated Forfeitures—The estimated forfeiture rate is based on the Company’s historical forfeiture rates and the estimate is revised in subsequent periods if actual forfeitures differ from the estimate.

[0001628280-15-007025:notes:65]
The fair value of stock option grants for the years ended June 30, 2015, 2014 and 2013 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-15-007025:notes:66]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Risk-free interest rate | 1.35% - 1.76% |  |  | 1.53% - 1.90% |  |  | 0.65% - 0.90% |  |
| Expected life | 5.40 - 5.44 years |  |  | 5.49 - 5.58 years |  |  | 5.03 - 5.15 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 46.93% - 49.31% |  |  | 43.48% - 50.07% |  |  | 51.27% - 51.76% |  |
| Weighted-average fair value | $ | 12.72 |  |  | $ | 7.23 |  |  | $ | 4.53 |  |

[0001628280-15-007025:notes:67]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the years ended June 30, 2015, 2014 and 2013 (in thousands):

[0001628280-15-007025:notes:68]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Cost of sales | $ | 901 |  |  | $ | 941 |  |  | $ | 953 |  |
| Research and development | 8,643 |  |  | 6,783 |  |  | 6,527 |  |
| Sales and marketing | 1,553 |  |  | 1,260 |  |  | 1,541 |  |
| General and administrative | 2,602 |  |  | 2,078 |  |  | 2,340 |  |
| Stock-based compensation expense before taxes | 13,699 |  |  | 11,062 |  |  | 11,361 |  |
| Income tax impact | (3,791 | ) |  | (2,426 | ) |  | (548 | ) |
| Stock-based compensation expense, net | $ | 9,908 |  |  | $ | 8,636 |  |  | $ | 10,813 |  |

[0001628280-15-007025:notes:69]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $11,157,000, $7,041,000 and $1,734,000 of excess tax benefits recorded in additional paid-in capital in the years ended June 30, 2015, 2014 and 2013, respectively. The Company had excess tax benefits classified as cash from financing activities of $8,089,000, $2,992,000 and $865,000 in the year ended June 30, 2015, 2014 and 2013, respectively, for options issued since July 1, 2006.

[0001628280-15-007025:notes:70]
As of June 30, 2015, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted to employees and non-employee directors was $30,203,000, which will be recognized over a weighted-average vesting period of approximately 2.32 years.

[0001628280-15-007025:notes:71]
Stock Option Activity

[0001628280-15-007025:notes:72]
The following table summarizes stock option activity during the years ended June 30, 2015, 2014 and 2013 under all stock option plans:

[0001628280-15-007025:notes:73]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2012 (7,410,152 shares exercisable at weighted average exercise price of $8.25 per share) |  | 11,302,228 |  |  | $ | 10.36 |  |  |  |  |  |
| Granted (weighted average fair value of $4.53) |  | 1,952,270 |  |  | 11.83 |  |  |  |  |  |
| Exercised |  | (612,034 | ) |  | 3.01 |  |  |  |  |  |
| Forfeited |  | (436,286 | ) |  | 14.01 |  |  |  |  |  |
| Balance as of June 30, 2013 (8,731,818 shares exercisable at weighted average exercise price of $9.66 per share) |  | 12,206,178 |  |  | 10.83 |  |  |  |  |  |
| Granted (weighted average fair value of $7.23) |  | 1,808,006 |  |  | 15.87 |  |  |  |  |  |
| Exercised |  | (2,863,878 | ) |  | 8.36 |  |  |  |  |  |
| Forfeited |  | (244,704 | ) |  | 14.25 |  |  |  |  |  |
| Balance as of June 30, 2014 (7,558,631 shares exercisable at weighted average exercise price of $11.05 per share) |  | 10,905,602 |  |  | 12.24 |  |  |  |  |  |
| Granted (weighted average fair value of $12.72) |  | 1,093,920 |  |  | 28.28 |  |  |  |  |  |
| Exercised |  | (2,124,401 | ) |  | 10.99 |  |  |  |  |  |
| Forfeited |  | (172,278 | ) |  | 18.68 |  |  |  |  |  |
| Balance as of June 30, 2015 |  | 9,702,843 |  |  | $ | 14.21 |  |  | 5.93 |  | $ | 150,746 |  |
| Options vested and expected to vest at June 30, 2015 |  | 9,531,602 |  |  | $ | 14.04 |  |  | 5.87 |  | $ | 149,539 |  |
| Options vested and exercisable at June 30, 2015 |  | 7,208,475 |  |  | $ | 12.24 |  |  | 5.04 |  | $ | 124,991 |  |

[0001628280-15-007025:notes:74]
The total pretax intrinsic value of options exercised during the years ended June 30, 2015, 2014 and 2013 was $48,077,000, $30,165,000 and $4,614,000, respectively.

[0001628280-15-007025:notes:75]
Additional information regarding options outstanding as of June 30, 2015, is as follows:

[0001628280-15-007025:notes:76]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $3.25 - 7.46 |  | 1,014,562 |  |  | 3.14 |  | $ | 5.79 |  |  | 1,014,562 |  |  | $ | 5.79 |  |
| 7.91 - 9.24 |  | 1,193,314 |  |  | 4.10 |  | 8.51 |  |  | 1,083,090 |  |  | 8.44 |  |
| 9.72 - 10.66 |  | 1,363,849 |  |  | 4.81 |  | 10.38 |  |  | 1,157,004 |  |  | 10.44 |  |
| 10.68 - 12.50 |  | 1,027,794 |  |  | 6.35 |  | 11.79 |  |  | 802,857 |  |  | 11.72 |  |
| 12.68 - 13.89 |  | 1,006,396 |  |  | 4.39 |  | 13.51 |  |  | 1,003,144 |  |  | 13.51 |  |
| 14.23 - 15.22 |  | 975,057 |  |  | 7.40 |  | 14.68 |  |  | 628,936 |  |  | 14.89 |  |
| 15.54 - 17.96 |  | 986,861 |  |  | 7.34 |  | 17.46 |  |  | 643,547 |  |  | 17.32 |  |
| 18.59 - 20.70 |  | 1,113,157 |  |  | 7.14 |  | 19.19 |  |  | 737,161 |  |  | 19.12 |  |
| 21.86 - 37.06 |  | 986,353 |  |  | 9.30 |  | 28.10 |  |  | 138,174 |  |  | 25.88 |  |
| 39.19 |  | 35,500 |  |  | 9.62 |  | 39.19 |  |  | — |  |  | — |  |
| $3.25 - $39.19 |  | 9,702,843 |  |  | 5.93 |  | $ | 14.21 |  |  | 7,208,475 |  |  | $ | 12.24 |  |

[0001628280-15-007025:notes:77]
Restricted Stock Unit Activity

[0001628280-15-007025:notes:78]
In January 2015, the Company began to grant restricted stock units to employees. The Company grants restricted stock units to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. Restricted stock units are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting and settlement.

[0001628280-15-007025:notes:79]
The following table summarizes restricted stock unit activity during the year ended June 30, 2015 under the 2006 Plan:

[0001628280-15-007025:notes:80]
|  |  | Restricted Stock UnitsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 |  | — |  |  | $ | — |  |  |  |
| Granted |  | 374,720 |  |  | $ | 35.82 |  |  |  |
| Vested |  | (14,685 | ) |  | $ | 35.23 |  |  |  |
| Forfeited |  | (56,711 | ) |  | $ | 34.90 |  |  |  |
| Balance as of June 30, 2015 |  | 303,324 |  |  | $ | 36.02 |  |  | $ | 8,972 |  |

[0001628280-15-007025:notes:81]
The total pretax intrinsic value of restricted stock units vested was $486,000 for the year ended June 30, 2015. In fiscal year 2015, upon vesting, 14,685 shares of restricted stock units were partially net share-settled such that the Company withheld 5,278 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock units on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $175,000 during the year ended June 30, 2015 and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2006 Plan, shares withheld in connection with net-share settlements are returned to the 2006 Plan and are available for future grants under the 2006 Plan.

[0001628280-15-007025:notes:82]
Restricted Stock Awards

[0001628280-15-007025:notes:83]
Restricted stock awards are share awards that provide the rights to a set number of shares of the Company’s stock on the grant date. In August 2008, the Compensation Committee of the Board of Directors of the Company (the “Committee”) approved the terms of an agreement (the “Option Exercise Agreement”) with Charles Liang, a director and President and Chief Executive Officer of the Company, pursuant to which Mr. Liang exercised a fully vested option previously granted to him for the purchase of 925,000 shares. The option was exercised using a “net-exercise” procedure in which he was issued a number of shares representing the spread between the option exercise price and the then current market value of the shares subject to the option (898,205 shares based upon the market value as of the date of exercise). The shares issued upon exercise of the option are subject to vesting over five years. Vesting of the shares subject to the award may accelerate in certain circumstances pursuant to the terms of the Option Exercise Agreement. The Company determined that there is no incremental fair value of the option exchanged for the award. 898,205 shares were vested as of June 30, 2015 and 2014.

[0001628280-15-007025:notes:84]
Restricted Stock Award Activity

[0001628280-15-007025:notes:85]
The following table summarizes the Company’s restricted stock award activity for the years ended June 30, 2015, 2014 and 2013:

[0001628280-15-007025:notes:86]
|  | Restricted Stock Awards |
|  | Numberof Shares |  | WeightedAverageGrant DateFair ValuePer Share |
| Nonvested stock at June 30, 2012 | 362,782 |  |  | $ | 10.72 |  |
| Granted | — |  |  | — |  |
| Vested | (183,141 | ) |  | 10.79 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2013 | 179,641 |  |  | 10.66 |  |
| Granted | 3,500 |  |  | 14.23 |  |
| Vested | (183,141 | ) |  | 10.73 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2014 | — |  |  | — |  |
| Granted | — |  |  | — |  |
| Vested | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2015 | — |  |  | $ | — |  |

[0001628280-15-007025:notes:87]
The Company had no restricted stock award activity for the year ended June 30, 2015. The total pretax intrinsic value of restricted stock awards vested was $1,965,000 and $2,225,000 for the years ended June 30, 2014 and 2013, respectively. In fiscal years 2014 and 2013, upon vesting, 183,141 and 183,141 shares of restricted stock awards were partially net share-settled such that the Company withheld 51,583 and 85,091 shares, respectively, with value equivalent to an officer's minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock awards on their vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities were $681,000 and $1,034,000 in fiscal years 2014 and 2013, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. There are no unvested restricted stock awards at June 30, 2015 and 2014.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-15-007025:notes:88]
Net Income Per Common Share

[0001628280-15-007025:notes:89]
The Company’s restricted share awards are subject to repurchase and settled in shares of common stock upon vesting. Such awards have the nonforfeitable right to receive dividends on an equal basis with common stock and therefore are considered participating securities that must be included in the calculation of net income per share using the two-class method. Under the two-class method, basic and diluted net income per common share is determined by calculating net income per share for common stock and participating securities based on participation rights in undistributed earnings. Diluted net income per common share is calculated by adjusting outstanding shares, assuming any dilutive effects of stock incentive awards calculated using the treasury stock method. Under the treasury stock method, an increase in the fair market value of our common stock results in a greater dilutive effect from outstanding stock options and restricted stock units. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-15-007025:notes:90]
These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-15-007025:notes:91]
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,943 |  |
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-15-007025:notes:92]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for fiscal years 2015 and 2014 (in thousands):

[0001628280-15-007025:notes:93]
|  | June 30, |
|  | 2015 |  | 2014 |
| Balance as of beginning of year | $ | 2,647 |  |  | $ | 2,637 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | (14 | ) |  | 10 |  |
| Sales and settlements at par | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |
| Balance as of end of year | $ | 2,633 |  |  | $ | 2,647 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-007025:notes:94]
Fair Value Disclosure

[0001628280-15-007025:notes:95]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of June 30, 2015 and 2014. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001628280-15-007025:notes:96]
The following table sets forth the Company’s cash equivalents and long-term investments as of June 30, 2015 and 2014 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-15-007025:notes:97]
The above table excludes $94,901,000 and $96,324,000 of cash and $1,130,000 and $746,000 of certificates of deposit held by the Company as of June 30, 2015 and 2014, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in fiscal year 2015 and 2014.

[0001628280-15-007025:notes:98]
The following is a summary of the Company’s long-term investments as of June 30, 2015 and 2014 (in thousands):

[0001628280-15-007025:notes:99]
|  | June 30, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |
|  | June 30, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |

[0001628280-15-007025:notes:100]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2015 and 2014, short-term and long-term debt of $94,412,000 and $46,287,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001628280-15-007025:notes:101]
Foreign Currency Translation

[0001628280-15-007025:notes:102]
The functional currency of the Company’s international subsidiaries is the U.S. dollar. Assets and liabilities of the Company's international subsidiaries that are denominated in the local currency are remeasured into U.S. dollars at period-end exchange rates and revenue and expenses that are denominated in the local currency are remeasured into U.S. dollars at the average exchange rates during the period. Accordingly, remeasurement of foreign currency accounts and foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001628280-15-007025:notes:103]
Long-Lived Assets

[0001628280-15-007025:notes:104]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-007025:notes:105]
Income Taxes

[0001628280-15-007025:notes:106]
The components of income before income tax provision for the years ended June 30, 2015, 2014 and 2013 are as follows (in thousands):

[0001628280-15-007025:notes:107]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| United States | $ | 118,083 |  |  | $ | 66,152 |  |  | $ | 14,102 |  |
| Foreign | 27,813 |  |  | 13,442 |  |  | 12,494 |  |
| Income before income tax provision | $ | 145,896 |  |  | $ | 79,594 |  |  | $ | 26,596 |  |

[0001628280-15-007025:notes:108]
The income tax provision for the years ended June 30, 2015, 2014 and 2013, consists of the following (in thousands):

[0001628280-15-007025:notes:109]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |
| Federal | $ | 33,496 |  |  | $ | 20,102 |  |  | $ | 7,904 |  |
| State | 1,980 |  |  | 624 |  |  | 684 |  |
| Foreign | 10,960 |  |  | 5,252 |  |  | 3,806 |  |
|  | 46,436 |  |  | 25,978 |  |  | 12,394 |  |
| Deferred: |  |  |  |  |  |
| Federal | (1,989 | ) |  | 122 |  |  | (5,984 | ) |
| State | 70 |  |  | (472 | ) |  | (1,093 | ) |
| Foreign | (484 | ) |  | (191 | ) |  | — |  |
|  | (2,403 | ) |  | (541 | ) |  | (7,077 | ) |
| Income tax provision | $ | 44,033 |  |  | $ | 25,437 |  |  | $ | 5,317 |  |

[0001628280-15-007025:notes:110]
The Company’s net deferred tax assets as of June 30, 2015 and 2014, consist of the following (in thousands):

[0001628280-15-007025:notes:111]
|  | June 30, |
|  | 2015 |  | 2014 |
| Warranty accrual | $ | 2,493 |  |  | $ | 2,459 |  |
| Marketing fund accrual | 1,163 |  |  | 938 |  |
| Inventory valuation | 10,158 |  |  | 9,472 |  |
| Stock-based compensation | 4,800 |  |  | 4,114 |  |
| Research and development credit | — |  |  | 1,938 |  |
| Accrued vacation and bonus | 1,230 |  |  | 1,296 |  |
| Payable to foreign subsidiaries | 1,716 |  |  | 1,922 |  |
| Other | 1,428 |  |  | 1,501 |  |
| Total deferred income tax assets | 22,988 |  |  | 23,640 |  |
| Deferred tax liabilities-depreciation and other | (628 | ) |  | (644 | ) |
| Deferred income tax assets-net | $ | 22,360 |  |  | $ | 22,996 |  |

[0001628280-15-007025:notes:112]
The cumulative undistributed earnings of our foreign subsidiaries of $40,886,000 at June 30, 2015 are considered to be indefinitely reinvested and accordingly, no provisions for federal and state income taxes have been provided thereon. The Company determined that the calculation of the amount of unrecognized deferred tax liability related to these cumulative unremitted earnings was not practicable. Upon distribution of those earnings in the form of dividends or otherwise, the Company would be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes payable to various foreign countries.

[0001628280-15-007025:notes:113]
Income tax benefits resulting from stock option transactions of $11,157,000, $7,041,000 and $1,734,000 were credited to stockholders’ equity in the years ended June 30, 2015, 2014 and 2013, respectively.

[0001628280-15-007025:notes:114]
The following is a reconciliation for the years ended June 30, 2015, 2014 and 2013, of the statutory rate to the Company’s effective federal tax rate:

[0001628280-15-007025:notes:115]
|  |  | Years Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Tax at statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income tax, net of federal tax benefit |  | 3.0 |  |  | 3.3 |  |  | 3.8 |  |
| Foreign tax rate differences |  | (3.0 | ) |  | (2.5 | ) |  | (6.7 | ) |
| Research and development tax credit |  | (3.4 | ) |  | (4.0 | ) |  | (14.4 | ) |
| Qualified production activity deduction |  | (1.3 | ) |  | (1.8 | ) |  | (2.9 | ) |
| Stock based compensation |  | 2.2 |  |  | 4.5 |  |  | 13.5 |  |
| Uncertain tax positions |  | (0.7 | ) |  | (2.1 | ) |  | (11.0 | ) |
| Subpart F income inclusion |  | (2.9 | ) |  | (3.9 | ) |  | (3.8 | ) |
| Foreign withholding tax |  | 3.0 |  |  | 4.1 |  |  | 5.5 |  |
| Federal tax return to provision adjustment |  | 0.2 |  |  | (0.7 | ) |  | (3.9 | ) |
| Other |  | (1.9 | ) |  | 0.1 |  |  | 4.9 |  |
| Effective tax rate |  | 30.2 | % |  | 32.0 | % |  | 20.0 | % |

[0001628280-15-007025:notes:116]
As of June 30, 2015, the Company had state research and development tax credit carryforwards of $10,199,000. The state research and development tax credits will carryforward indefinitely to offset future state income taxes. $6,197,000 of the state research and development tax credit carryforwards were attributable to excess tax deductions from stock option exercises, and were not included in the deferred tax assets shown above. The benefit of these carryforwards will be credited to equity when realized.

[0001628280-15-007025:notes:117]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001628280-15-007025:notes:118]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2012 | $ | 8,025 |  |
| Gross increases: |  |
| For current year’s tax positions | 2,044 |  |
| For prior years’ tax positions | 490 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (2,470 | ) |
| For prior year' tax positions | — |  |
| Balance at June 30, 2013 | 8,089 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,120 |  |
| For prior years’ tax positions | 132 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (1,726 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2014 | 9,615 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,855 |  |
| For prior years’ tax positions | 793 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (971 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2015 | $ | 13,292 |  |

[0001628280-15-007025:notes:119]
__________________________

[0001628280-15-007025:notes:120]
| * | excludes interest, penalties, federal benefit of state reserves |

[0001628280-15-007025:notes:121]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, is $10,971,000 and $8,168,000 as of June 30, 2015 and 2014, respectively.

[0001628280-15-007025:notes:122]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes in the consolidated statements of operations. As of June 30, 2015 and 2014, the Company had accrued $898,000 and $818,000 for the payment of interest and penalties relating to unrecognized tax benefits, respectively. During fiscal year 2015, 2014 and 2013, there was no material change in the total amount of the liability for accrued interest and penalties related to the unrecognized tax benefits.

[0001628280-15-007025:notes:123]
The Company is subject to U.S. federal income tax as well as income taxes in many state and foreign jurisdictions.  In August 2015, the Company scheduled a meeting with the Internal Revenue Service to commence a pre-examination of the federal income tax returns for tax years 2013 and 2014. The Company does not expect a resolution to be reached during the next twelve months. While management believes that the Company has adequately provided reserves for all uncertain tax positions, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. The federal statute of limitations remain open in general for tax years 2012 through 2015. The state statute of limitations remain open in general for tax years 2010 through 2015. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2008 through 2015. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:IncomeTaxPolicyTextBlock

[0001628280-15-007025:notes:124]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying currently enacted tax laws. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001628280-15-007025:notes:125]
The Company recognizes the tax liability for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related change in its tax provision during the period in which the Company makes such determination.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-15-007025:notes:126]
Inventory

[0001628280-15-007025:notes:127]
Inventory as of June 30, 2015 and 2014 consisted of the following (in thousands):

[0001628280-15-007025:notes:128]
|  | June 30, |
|  | 2015 |  | 2014 |
| Finished goods | $ | 384,647 |  |  | $ | 246,803 |  |
| Work in process | 23,214 |  |  | 18,794 |  |
| Purchased parts and raw materials | 55,632 |  |  | 50,240 |  |
| Total inventory | $ | 463,493 |  |  | $ | 315,837 |  |


## us-gaap:InventoryPolicyTextBlock

[0001628280-15-007025:notes:129]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units to lower of cost or market or for excess and obsolescence based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-15-007025:notes:130]
Long-term Investments

[0001628280-15-007025:notes:131]
As of June 30, 2015 and 2014, the Company held $2,633,000 and $2,647,000, respectively, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at June 30, 2015 and AAA or AA2 at June 30, 2014. These auction rate preferred shares have no stated maturity date.

[0001628280-15-007025:notes:132]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of June 30, 2015 and 2014, $2,633,000 and $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments, respectively.

[0001628280-15-007025:notes:133]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of June 30, 2015 and 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of June 30, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.93%, 3 years and 0.47%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001628280-15-007025:notes:134]
Based on this assessment of fair value, the Company determined a recovery (loss) in fair value of its auction rate securities of $(14,000) and $10,000 during the year ended June 30, 2015 and 2014, respectively. There was a cumulative total decline of $117,000 and $103,000 as of June 30, 2015 and 2014, respectively. That amount has been recorded as a component of other comprehensive income. As of June 30, 2015 and 2014, the Company has recorded an accumulated unrealized loss of $70,000 and $62,000, respectively, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001628280-15-007025:notes:135]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In fiscal year 2015 and 2014, there was no auction rate securities redeemed or sold. In fiscal year 2013, $300,000 of auction rate securities were redeemed at par.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-15-007025:notes:136]
Accounts Receivable Allowances

[0001628280-15-007025:notes:137]
The Company has established an allowance for doubtful accounts and an allowance for sales returns. The allowance for doubtful accounts is based upon the credit risk of specific customers, historical trends related to past losses and other relevant factors. The Company also provides its customers with product return rights. A provision for such returns is provided for in the same period that the related sales are recorded based upon contractual return rights and historical trends. Accounts receivable allowances as of June 30, 2015, 2014 and 2013, consisted of the following (in thousands):


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-15-007025:notes:138]
Adoption of New Accounting Pronouncements

[0001628280-15-007025:notes:139]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company adopted the new disclosure on July 1, 2014. The adoption of this guidance did not have a material impact on our results of operations or financial position.

[0001628280-15-007025:notes:140]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations or financial position.

[0001628280-15-007025:notes:141]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The new standard is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-15-007025:notes:142]
In July 2015, the FASB issued authoritative guidance related to inventory measurement. The new standard requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The new standard is effective for the Company on July 1, 2017 . The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-15-007025:notes:143]
Summary of Significant Accounting Policies

[0001628280-15-007025:notes:144]
Organization

[0001628280-15-007025:notes:145]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in San Jose, California, the Netherlands, Taiwan, China and Japan.

[0001628280-15-007025:notes:146]
Use of Estimates

[0001628280-15-007025:notes:147]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, product warranty accruals, stock-based compensation, impairment of short-term and long-term investments and income taxes. Actual results could differ from those estimates.

[0001628280-15-007025:notes:148]
Fair Value of Financial Instruments

[0001628280-15-007025:notes:149]
The Company accounts for certain assets and liabilities at fair value. Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents and long-term investments are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms. The hierarchy below lists three levels of fair value based on the extent to which inputs used in measuring fair value are observable in the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001628280-15-007025:notes:150]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001628280-15-007025:notes:151]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001628280-15-007025:notes:152]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001628280-15-007025:notes:153]
The Company classifies its long-term investments in auction-rate securities ("auction rate securities") as long-term available-for-sale investments. Auction rate securities consist of municipal securities. The discounted cash flow model is used to estimate the fair value of the auction rate securities. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a component of accumulated other comprehensive income, net of tax.

[0001628280-15-007025:notes:154]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units to lower of cost or market or for excess and obsolescence based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected. During fiscal years 2015, 2014 and 2013, the Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $5,928,000, $2,254,000 and $9,725,000, respectively.

[0001628280-15-007025:notes:155]
Property, Plant and Equipment

[0001628280-15-007025:notes:156]
For assets acquired and financed under capital leases, the present value of the future minimum lease payments is recorded at the date of acquisition as property and equipment with the corresponding amount recorded as a capital lease obligation, and the amortization is computed on a straight-line basis over the shorter of lease term or estimated useful life.

[0001628280-15-007025:notes:157]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge has been recorded in any of the periods presented.

[0001628280-15-007025:notes:158]
Revenue Recognition

[0001628280-15-007025:notes:159]
The Company recognizes revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. The Company’s standard arrangement with its customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination. The Company generally does not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, the Company regularly reviews its history of actual returns for each major product line. The Company also communicates regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with distributors

[0001628280-15-007025:notes:160]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At June 30, 2015 and 2014, the Company had deferred revenue of $459,000 and $7,665,000 and related deferred product costs of $219,000 and $6,674,000, respectively, related to shipments to customers pending acceptance.

[0001628280-15-007025:notes:161]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. The Company also makes estimates of the uncollectibility of accounts receivable, analyzing accounts receivable and historical bad debts, customer concentrations, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, the Company evaluates aged items in the accounts receivable aging report and provides an allowance in an amount the Company deems adequate for doubtful accounts. Our provision for bad debt was $326,000, $1,476,000 and $929,000 in fiscal years 2015, 2014 and 2013, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than the Company's historical experience, or if other circumstances arise, the Company's estimates of the recoverability of amounts due to the Company could be overstated, and additional allowances could be required, which could have an adverse impact on its reported operating expenses. The Company provides for price protection to certain distributors. The Company assesses the market competition and product technology obsolescence, and makes price adjustments based on its judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on the distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time the Company reduces the product prices.

[0001628280-15-007025:notes:162]
The Company has an immaterial amount of service revenue relating to on-site service and non-warranty repairs. Revenue for on-site service is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001628280-15-007025:notes:163]
Product Warranties

[0001628280-15-007025:notes:164]
The Company offers product warranties ranging from 15 to 39 months against any defective products. The Company accrues for estimated returns of defective products at the time revenue is recognized based on historical warranty experience and recent trends. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The Company’s estimates and assumptions used have been historically close to actual. If in future periods the Company experiences or anticipates an increase or decrease in warranty claims as a result of new product introductions or changes in unit volumes compared with its historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, the Company intends to adjust its estimates appropriately. The following table presents for the years ended June 30, 2015, 2014 and 2013, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities (in thousands):

[0001628280-15-007025:notes:165]
|  | June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Balance, beginning of year | $ | 7,083 |  |  | $ | 6,472 |  |  | $ | 5,522 |  |
| Provision for warranty | 15,771 |  |  | 14,175 |  |  | 13,438 |  |
| Costs charged to accrual | (14,950 | ) |  | (13,950 | ) |  | (12,487 | ) |
| Change in estimated liability for pre-existing warranties | (204 | ) |  | 386 |  |  | (1 | ) |
| Balance, end of year | $ | 7,700 |  |  | $ | 7,083 |  |  | $ | 6,472 |  |

[0001628280-15-007025:notes:166]
Software Development Costs

[0001628280-15-007025:notes:167]
Software development costs are included in research and development and are expensed as incurred. Software development costs are capitalized beginning when technological feasibility has been established and ending when a product is available for general release to customers. To date, the period between achieving technological feasibility and the issuance of such software has been short and software development costs qualifying for capitalization have been insignificant.

[0001628280-15-007025:notes:168]
Research and Development

[0001628280-15-007025:notes:169]
Research and development costs are expensed as incurred and consist primarily of salaries, consulting services, other direct expenses and other engineering expenses. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $6,318,000, $3,132,000 and $2,112,000 for the years ended June 30, 2015, 2014 and 2013, respectively.

[0001628280-15-007025:notes:170]
Cooperative Marketing Arrangements

[0001628280-15-007025:notes:171]
The Company has arrangements with resellers of its products to reimburse the resellers for cooperative marketing costs meeting specified criteria. The Company accrues the cooperative marketing costs based on these arrangements and its estimate for resellers’ claims for marketing activities. The Company records marketing costs meeting such specified criteria within sales and marketing expenses in the consolidated statements of operations. For those marketing costs that do not meet the specified criteria, the amounts are recorded as a reduction to sales in the consolidated statements of operations.

[0001628280-15-007025:notes:172]
Total cooperative marketing costs charged to sales and marketing expenses for the years ended June 30, 2015, 2014 and 2013, were $1,995,000, $2,058,000 and $1,550,000, respectively. Total amounts recorded as reductions to sales for the years ended June 30, 2015, 2014 and 2013, were $4,200,000, $2,829,000 and $2,610,000, respectively.

[0001628280-15-007025:notes:173]
Advertising costs are expensed as incurred. Total advertising and promotional expenses, including cooperative marketing payments, were $7,263,000, $5,183,000 and $4,085,000 for the years ended June 30, 2015, 2014 and 2013, respectively.

[0001628280-15-007025:notes:174]
Stock-Based Compensation

[0001628280-15-007025:notes:175]
The Company measures and recognizes the compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors, including employee stock options and restricted stock units. The Company is required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of our restricted stock units is based on the closing market price of the Company's common stock on the date of grant. The Company estimated the fair value of stock options granted using a Black-Scholes option pricing model and a single option award approach. This model requires the Company to make estimates and assumptions with respect to the expected term of the option, the expected volatility of the price of the Company's common stock and the expected forfeiture rate. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-15-007025:notes:176]
The expected term represents the period that the Company's stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and historical experience. The expected volatility is based on a combination of the Company's implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-15-007025:notes:177]
Shipping and Handling Fees

[0001628280-15-007025:notes:178]
The Company incurred shipping costs of $2,090,000, $1,605,000 and $1,475,000 for the years ended June 30, 2015, 2014 and 2013, respectively, which were included in sales and marketing expenses.

[0001628280-15-007025:notes:179]
The computation of basic and diluted net income per common share using the two-class method is as follows (in thousands, except per share amounts):

[0001628280-15-007025:notes:180]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Basic net income per common share calculation |  |  |  |  |  |
| Net income | $ | 101,863 |  |  | $ | 54,157 |  |  | $ | 21,279 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (36 | ) |  | (106 | ) |
| Net income attributable to common shares—basic | $ | 101,863 |  |  | $ | 54,121 |  |  | $ | 21,173 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,434 |  |  | 43,599 |  |  | 41,992 |  |
| Basic net income per common share | $ | 2.19 |  |  | $ | 1.24 |  |  | $ | 0.50 |  |
| Diluted net income per common share calculation |  |  |  |  |  |
| Net income | $ | 101,863 |  |  | $ | 54,157 |  |  | $ | 21,279 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (34 | ) |  | (101 | ) |
| Net income attributable to common shares—diluted | $ | 101,863 |  |  | $ | 54,123 |  |  | $ | 21,178 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,434 |  |  | 43,599 |  |  | 41,992 |  |
| Dilutive effect of options and restricted stock units to purchase common stock | 3,660 |  |  | 2,913 |  |  | 1,915 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 50,094 |  |  | 46,512 |  |  | 43,907 |  |
| Diluted net income per common share | $ | 2.03 |  |  | $ | 1.16 |  |  | $ | 0.48 |  |

[0001628280-15-007025:notes:181]
For the years ended June 30, 2015, 2014 and 2013, the Company had stock options and restricted stock units outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 3,805,000, 3,465,000 and 6,241,000 for the years ended June 30, 2015, 2014 and 2013, respectively.

[0001628280-15-007025:notes:182]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.7%, 23.4%, and 21.9% of total purchases for the years ended June 30, 2015, 2014 and 2013, respectively. Ablecom Technology, Inc., a related party of the Company as noted in Note 9, accounted for 12.6%, 16.1% and 18.9% of total purchases for the years ended June 30, 2015, 2014 and 2013, respectively.

[0001628280-15-007025:notes:183]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents and long-term investments and accounts receivable. One customer accounted for 10.1% of net sales in fiscal year 2015. No single customer accounted for 10% or more of net sales in fiscal years 2014 and 2013.  No customer accounted for 10% or more of accounts receivable as of June 30, 2015 and 2014.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-15-007025:notes:184]
Retirement Plan

[0001628280-15-007025:notes:185]
The Company sponsors a 401(k) savings plan for eligible U.S. employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the years ended June 30, 2015, 2014 and 2013.

[0001628280-15-007025:notes:186]
Beginning in March 2003, employees of Super Micro Computer, B.V. have the option to deduct a portion of their gross wages and invest the amount in a defined contribution plan. The Company has agreed to match 10% of the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the years ended June 30, 2015, 2014 and 2013, the Company’s matching contribution was $200,000, $198,000 and $133,000, respectively.

[0001628280-15-007025:notes:187]
The Company maintains a defined benefit pension plan of Super Micro Computer, Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. Plan assets of the funded defined benefit pension plan are deposited into a government-managed account in which the Company has no control over investment strategy. For the years ended June 30, 2015, 2014 and 2013, the Company’s contribution was $862,000, $740,000 and $660,000, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-15-007025:notes:188]
Property, Plant, and Equipment

[0001628280-15-007025:notes:189]
Property, plant and equipment as of June 30, 2015 and 2014 consisted of the following (in thousands):

[0001628280-15-007025:notes:190]
|  | June 30, |
|  | 2015 |  | 2014 |
| Land | $ | 63,962 |  |  | $ | 63,962 |  |
| Buildings | 51,959 |  |  | 51,959 |  |
| Building and leasehold improvements | 8,323 |  |  | 7,683 |  |
| Buildings construction in progress (1) | 25,572 |  |  | 587 |  |
| Machinery and equipment | 40,689 |  |  | 34,342 |  |
| Furniture and fixtures | 7,421 |  |  | 5,892 |  |
| Purchased software | 3,343 |  |  | 3,606 |  |
| Purchased software construction in progress (2) | 8,567 |  |  | 2,548 |  |
|  | 209,836 |  |  | 170,579 |  |
| Accumulated depreciation and amortization | (46,798 | ) |  | (39,990 | ) |
| Property, plant and equipment, net | $ | 163,038 |  |  | $ | 130,589 |  |

[0001628280-15-007025:notes:191]
(1) In connection with the purchase of the property located in San Jose, California, the Company engaged several contractors for the development and construction of improvements on the property, which was completed in August 2015.

[0001628280-15-007025:notes:192]
(2) The Company completed its implementation of a new enterprise resource planning, or ERP, system for its U.S. headquarters on July 5, 2015 and has capitalized the costs of the new ERP software and certain expenses associated directly with the development of the ERP system as of June 30, 2015.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-15-007025:notes:193]
Quarterly Financial Data (Unaudited)

[0001628280-15-007025:notes:194]
The following table presents the Company’s unaudited consolidated quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company’s quarterly results of operations for these periods are not necessarily indicative of future results of operations.

[0001628280-15-007025:notes:195]
|  | Three Months Ended |
|  | Sep. 30, 2014 |  | Dec. 31, 2014 |  | Mar. 31, 2015 |  | Jun. 30, 2015 |
|  | (In thousands, except per share data) |
| Net sales | $ | 443,322 |  |  | $ | 503,014 |  |  | $ | 471,225 |  |  | $ | 573,594 |  |
| Gross profit | $ | 69,193 |  |  | $ | 84,452 |  |  | $ | 76,820 |  |  | $ | 89,766 |  |
| Net income | $ | 20,863 |  |  | $ | 31,242 |  |  | $ | 23,056 |  |  | $ | 26,702 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.46 |  |  | $ | 0.68 |  |  | $ | 0.49 |  |  | $ | 0.56 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.61 |  |  | $ | 0.44 |  |  | $ | 0.51 |  |

[0001628280-15-007025:notes:196]
|  | Three Months Ended |
|  | Sep. 30, 2013 |  | Dec. 31, 2013 |  | Mar. 31, 2014 |  | Jun. 30, 2014 |
|  | (In thousands, except per share data) |
| Net sales | $ | 309,016 |  |  | $ | 356,362 |  |  | $ | 373,755 |  |  | $ | 428,069 |  |
| Gross profit | $ | 46,792 |  |  | $ | 55,092 |  |  | $ | 57,264 |  |  | $ | 66,397 |  |
| Net income | $ | 7,699 |  |  | $ | 13,335 |  |  | $ | 16,574 |  |  | $ | 16,549 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.18 |  |  | $ | 0.31 |  |  | $ | 0.38 |  |  | $ | 0.37 |  |
| Diluted | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.35 |  |  | $ | 0.34 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-15-007025:notes:197]
Related-party and Other Transactions

[0001628280-15-007025:notes:198]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at June 30, 2015.

[0001628280-15-007025:notes:199]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-15-007025:notes:200]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-15-007025:notes:201]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-15-007025:notes:202]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. For fiscal year 2015, 2014 and 2013, the Company purchased products from Ablecom totaling $227,562,000, $201,848,000 and $179,735,000, respectively. For fiscal year 2015, 2014 and 2013, the Company sold products to Ablecom totaling $58,013,000, $14,576,000 and $13,805,000, respectively.

[0001628280-15-007025:notes:203]
Amounts owed to the Company by Ablecom as of June 30, 2015 and 2014, were $13,186,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of June 30, 2015 and 2014, were $59,015,000 and $48,969,000, respectively. In fiscal year 2015, the Company paid Ablecom the majority of invoiced dollars between 46 and 74 days of invoice date. For the years ended June 30, 2015, 2014 and 2013, the Company paid $5,851,000, $6,906,000 and $5,076,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-15-007025:notes:204]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $67,261,000 and $64,464,000 at June 30, 2015 and 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-15-007025:notes:205]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. The Management Company had no business operations as of June 30, 2012. In fiscal year 2015, 2014 and 2013, $(11,000), $(6,000) and $13,000 of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the consolidated statements of operations.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-15-007025:notes:206]
The following is a summary of net sales by product type (in thousands):

[0001628280-15-007025:notes:207]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 1,213,608 |  |  | 60.9 | % |  | $ | 740,789 |  |  | 50.5 | % |  | $ | 501,868 |  |  | 43.2 | % |
| Subsystems and accessories | 777,547 |  |  | 39.1 | % |  | 726,413 |  |  | 49.5 | % |  | 660,693 |  |  | 56.8 | % |
| Total | $ | 1,991,155 |  |  | 100.0 | % |  | $ | 1,467,202 |  |  | 100.0 | % |  | $ | 1,162,561 |  |  | 100.0 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-15-007025:notes:208]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the years ended June 30, 2015, 2014 and 2013, of net sales by geographic region (in thousands):

[0001628280-15-007025:notes:209]
|  | Years Ended June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Net sales: |  |  |  |  |  |
| United States | $ | 1,160,651 |  |  | $ | 809,250 |  |  | $ | 629,869 |  |
| Europe | 378,323 |  |  | 316,760 |  |  | 265,635 |  |
| Asia | 326,912 |  |  | 299,403 |  |  | 237,798 |  |
| Other | 125,269 |  |  | 41,789 |  |  | 29,259 |  |
|  | $ | 1,991,155 |  |  | $ | 1,467,202 |  |  | $ | 1,162,561 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-15-007025:notes:210]
The following is a summary of long-lived assets, excluding financial instruments, deferred tax assets, other assets, goodwill and intangible assets (in thousands):

[0001628280-15-007025:notes:211]
|  | June 30, |
|  | 2015 |  | 2014 |  | 2013 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 124,292 |  |  | $ | 94,119 |  |  | $ | 61,976 |  |
| Asia | 37,695 |  |  | 36,123 |  |  | 33,500 |  |
| Europe | 1,051 |  |  | 347 |  |  | 436 |  |
|  | $ | 163,038 |  |  | $ | 130,589 |  |  | $ | 95,912 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-007025:notes:212]
Segment Reporting

[0001628280-15-007025:notes:213]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001628280-15-007025:notes:214]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories done by the Company. One customer represented 10.1% of the Company's total net sales in fiscal year 2015 and no customer represented greater than 10% of the Company’s total net sales for the years ended June 30, 2014 and 2013. No country other than the United States represent greater than 10% of the Company’s total net sales for any of the years ended June 30, 2015, 2014 and 2013. No customer accounted for 10% or more of the Company's accounts receivable as of June 30, 2015 and 2014.
