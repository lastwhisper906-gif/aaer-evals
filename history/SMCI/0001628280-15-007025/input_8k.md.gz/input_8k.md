# SMCI 8-K — 0001628280-15-006029 filed 2015-08-04

## item codes, every 8-K on or before 2015-09-10

- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2015-09-10

- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-006029:8k_2_02:1]
EX-99.1
2
exhibit991q4-2015.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-15-006029:8k_2_02:2]
Exhibit 991 Q4-2015

[0001628280-15-006029:8k_2_02:3]
Exhibit 99.1

[0001628280-15-006029:8k_2_02:4]
Super Micro Computer, Inc. Announces 4th Quarter 2015 Financial Results

[0001628280-15-006029:8k_2_02:5]
SAN JOSE, Calif., August 4, 2015 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced fourth quarter and full-year financial results for the fiscal year ended June 30, 2015.

[0001628280-15-006029:8k_2_02:6]
Fiscal 4th Quarter Highlights

[0001628280-15-006029:8k_2_02:7]
| • | Quarterly net sales of $573.6 million, up 21.7% from the third quarter of fiscal year 2015 and up 34.0% from the same quarter of last year. |

[0001628280-15-006029:8k_2_02:8]
| • | GAAP net income of $26.7 million, up 15.8% from the third quarter of fiscal year 2015 and up 61.4% from the same quarter of last year. |

[0001628280-15-006029:8k_2_02:9]
| • | GAAP gross margin of 15.6%, down from 16.3% in the third quarter of fiscal year 2015 and up from 15.5% in the same quarter of last year. |

[0001628280-15-006029:8k_2_02:10]
| • | Server solutions accounted for 61.7% of net sales compared with 64.1% in the third quarter of fiscal year 2015 and 55.2% in the same quarter of last year. |

[0001628280-15-006029:8k_2_02:11]
Net sales for the fourth quarter ended June 30, 2015 totaled $573.6 million, up 21.7% from $471.2 million in the third quarter of fiscal year 2015. No customer accounted for more than 10% of net sales during the quarter ended June 30, 2015.

[0001628280-15-006029:8k_2_02:12]
GAAP net income for the fourth quarter of fiscal year 2015 was $26.7 million or $0.51 per diluted share, an increase of 61.4% from net income of $16.5 million, or $0.34 per diluted share in the same period a year ago. Included in net income for the quarter is $4.0 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the fourth quarter was $30.0 million, or $0.57 per diluted share, compared to non-GAAP net income of $19.4 million, or $0.40 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the third quarter of fiscal year 2015 by $5.1 million or $0.10 per diluted share.

[0001628280-15-006029:8k_2_02:13]
GAAP gross margin for the fourth quarter was 15.6% compared to 15.5% in the same period a year ago. Non-GAAP gross margin for the fourth quarter was 15.7% compared to 15.6% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the third quarter of fiscal year 2015 were both 16.3%.

[0001628280-15-006029:8k_2_02:14]
The Company's cash and cash equivalents and short and long term investments at June 30, 2015 were $98.1 million compared to $99.6 million at June 30, 2014. Free cash flow for the year ended June 30, 2015 was $(79.7) million, primarily due to an increase in the Company's cash used by operating activities and the development and construction of improvements on the Company's property, which is completed in the beginning of August 2015.

[0001628280-15-006029:8k_2_02:15]
Fiscal Year 2015 Summary

[0001628280-15-006029:8k_2_02:16]
Net sales for the fiscal year ended June 30, 2015 were $1,991.2 million, up 35.7% from $1,467.2 million for the fiscal year ended June 30, 2014. GAAP net income for fiscal year 2015 increased to $101.9 million, or $2.03 per diluted share, an increase of 88.1% from $54.2 million, or $1.16 per diluted share, for fiscal year 2014. Excluding $9.7 million of stock based-compensation expense and related tax effect, non-GAAP net income for the fiscal year 2015 was $111.6 million or $2.15 per diluted share, an increase of 77.4% compared to $62.9 million or $1.34 per diluted share for fiscal year 2014.

[0001628280-15-006029:8k_2_02:17]
Business Outlook & Management Commentary

[0001628280-15-006029:8k_2_02:18]
The Company expects net sales of $520 million to $580 million for the first quarter of fiscal year 2016 ending September 30, 2015. The Company expects non-GAAP earnings per diluted share of approximately $0.49 to $0.59 for the first quarter.

[0001628280-15-006029:8k_2_02:19]
“Supermicro delivered record revenues in the fourth quarter of 34% growth over last year and posting $1.99 billion for the full fiscal year 2015 which was 35.7% above last year. Revenue related to our storage solutions grew 79% year over year in the fourth quarter as storage has become a strategic growth segment with contributions from both traditional and next generation storage solutions. Our FatTwin solutions were also a key growth driver this quarter with over 100% growth year over year and sales of our new MicroBlade solutions grew strongly for a new product category,” said Charles Liang, Chairman and CEO. “Looking to 2016 we have never been stronger in terms of leading products like Ultra, GPU/Xeon Phi, Storage, MicroBlade, and our software and service offerings. In order to support our growth, we are in the process of completing a 30% capacity addition in our San Jose and Europe manufacturing operations. We believe that we are well positioned for continued growth and market share gains.”

[0001628280-15-006029:8k_2_02:20]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-15-006029:8k_2_02:21]
Conference Call Information

[0001628280-15-006029:8k_2_02:22]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-437-9445 (International callers dial 1-719-325-2281) 10 minutes prior. A recording

[0001628280-15-006029:8k_2_02:23]
of the conference will be available until 11:59 pm (Eastern Time) Tuesday, August 18, 2015 by dialing 1-877-870-5176 (international callers dial 1-858-384-5517) and entering replay PIN 5322120. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-15-006029:8k_2_02:24]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-15-006029:8k_2_02:25]
Use of Non-GAAP Financial Measures

[0001628280-15-006029:8k_2_02:26]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-15-006029:8k_2_02:27]
About Super Micro Computer, Inc.

[0001628280-15-006029:8k_2_02:28]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-15-006029:8k_2_02:29]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-15-006029:8k_2_02:30]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001628280-15-006029:8k_2_02:31]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | June 30, |  | June 30, |
|  |  |  |  | 2015 |  | 2014 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 95,442 |  |  | $ | 96,872 |  |
|  | Accounts receivable, net | 322,594 |  |  | 212,738 |  |
|  | Inventory |  | 463,493 |  |  | 315,837 |  |
|  | Deferred income taxes – current | 17,863 |  |  | 16,842 |  |
|  | Prepaid income taxes | 7,507 |  |  | 5,555 |  |
|  | Prepaid expenses and other current assets | 7,516 |  |  | 6,237 |  |
|  |  | Total current assets | 914,415 |  |  | 654,081 |  |
| Long-term investments | 2,633 |  |  | 2,647 |  |
| Property, plant and equipment, net | 163,038 |  |  | 130,589 |  |
| Deferred income taxes – noncurrent |  | 4,497 |  |  | 6,154 |  |
| Other assets |  |  | 5,226 |  |  | 2,854 |  |
|  |  | Total assets | $ | 1,089,809 |  |  | $ | 796,325 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 299,774 |  |  | $ | 219,354 |  |
|  | Accrued liabilities |  | 46,743 |  |  | 37,564 |  |
|  | Income taxes payable |  | 14,111 |  |  | 11,414 |  |
|  | Short-term debt and current portion of long-term debt | 93,479 |  |  | 42,554 |  |
|  |  | Total current liabilities | 454,107 |  |  | 310,886 |  |
| Long term debt-net of current portion | 933 |  |  | 3,733 |  |
| Other long-term liabilities | 15,684 |  |  | 12,475 |  |
|  |  | Total liabilities | 470,724 |  |  | 327,094 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 247,081 |  |  | 199,062 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (80 | ) |  | (63 | ) |
|  | Retained earnings |  | 373,950 |  |  | 272,087 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 618,921 |  |  | 469,056 |  |
|  | Noncontrolling interest | 164 |  |  | 175 |  |
|  |  | Total stockholders' equity | 619,085 |  |  | 469,231 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,089,809 |  |  | $ | 796,325 |  |

[0001628280-15-006029:8k_2_02:32]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended June 30, |  | Fiscal Year Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 573,594 |  |  | $ | 428,069 |  |  | $ | 1,991,155 |  |  | $ | 1,467,202 |  |
| Cost of sales | 483,828 |  |  | 361,672 |  |  | 1,670,924 |  |  | 1,241,657 |  |
| Gross profit | 89,766 |  |  | 66,397 |  |  | 320,231 |  |  | 225,545 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 27,741 |  |  | 23,023 |  |  | 100,257 |  |  | 84,257 |  |
| Sales and marketing | 14,195 |  |  | 10,755 |  |  | 48,851 |  |  | 38,012 |  |
| General and administrative | 7,043 |  |  | 6,079 |  |  | 24,377 |  |  | 23,017 |  |
| Total operating expenses | 48,979 |  |  | 39,857 |  |  | 173,485 |  |  | 145,286 |  |
| Income from operations | 40,787 |  |  | 26,540 |  |  | 146,746 |  |  | 80,259 |  |
| Interest and other income, net | 23 |  |  | 19 |  |  | 115 |  |  | 92 |  |
| Interest expense | (309 | ) |  | (222 | ) |  | (965 | ) |  | (757 | ) |
| Income before income tax provision | 40,501 |  |  | 26,337 |  |  | 145,896 |  |  | 79,594 |  |
| Income tax provision | 13,799 |  |  | 9,788 |  |  | 44,033 |  |  | 25,437 |  |
| Net income | $ | 26,702 |  |  | $ | 16,549 |  |  | $ | 101,863 |  |  | $ | 54,157 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.56 |  |  | $ | 0.37 |  |  | $ | 2.19 |  |  | $ | 1.24 |  |
| Diluted | $ | 0.51 |  |  | $ | 0.34 |  |  | $ | 2.03 |  |  | $ | 1.16 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 47,327 |  |  | 45,017 |  |  | 46,434 |  |  | 43,599 |  |
| Diluted (b) | 51,990 |  |  | 48,317 |  |  | 50,094 |  |  | 46,512 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended June 30, |  | Fiscal Year Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 250 |  |  | $ | 215 |  |  | $ | 901 |  |  | $ | 941 |  |
| Research and development | 2,495 |  |  | 1,790 |  |  | 8,643 |  |  | 6,783 |  |
| Sales and marketing | 405 |  |  | 335 |  |  | 1,553 |  |  | 1,260 |  |
| General and administrative | 822 |  |  | 539 |  |  | 2,602 |  |  | 2,078 |  |

[0001628280-15-006029:8k_2_02:33]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Fiscal Year Ended June 30, |
|  | 2015 |  | 2014 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 101,863 |  |  | $ | 54,157 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 8,133 |  |  | 6,364 |  |
| Stock-based compensation expense | 13,699 |  |  | 11,062 |  |
| Excess tax benefits from stock-based compensation | (8,089 | ) |  | (2,992 | ) |
| Allowance for doubtful accounts | 326 |  |  | 1,476 |  |
| Provision for inventory | 5,928 |  |  | 2,254 |  |
| Exchange gain | (675 | ) |  | (96 | ) |
| Deferred income taxes, net | 632 |  |  | 65 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (110,182 | ) |  | (64,874 | ) |
| Inventory | (153,584 | ) |  | (63,921 | ) |
| Prepaid expenses and other assets | (2,741 | ) |  | 618 |  |
| Accounts payable | 75,520 |  |  | 46,298 |  |
| Income taxes payable, net | 11,951 |  |  | 10,880 |  |
| Accrued liabilities | 9,551 |  |  | 3,293 |  |
| Other long-term liabilities | 3,032 |  |  | 1,954 |  |
| Net cash provided by (used in) operating activities | (44,636 | ) |  | 6,538 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (35,100 | ) |  | (40,567 | ) |
| Investment in a privately held company | (661 | ) |  | — |  |
| Restricted cash | (416 | ) |  | 406 |  |
| Net cash used in investing activities | (36,177 | ) |  | (40,161 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 84,900 |  |  | 17,354 |  |
| Repayment of debt | (36,000 | ) |  | (6,320 | ) |
| Proceeds from exercise of stock options | 23,338 |  |  | 23,928 |  |
| Excess tax benefits from stock-based compensation | 8,089 |  |  | 2,992 |  |
| Payment of obligations under capital leases | (134 | ) |  | (47 | ) |
| Advances (payments) under receivable financing arrangements | 33 |  |  | (4 | ) |
| Minimum tax withholding paid on behalf of employees for restricted stock awards | (175 | ) |  | (681 | ) |
| Net cash provided by financing activities | 80,051 |  |  | 37,222 |  |
| Effect of exchange rate fluctuations on cash | (668 | ) |  | 235 |  |
| Net increase (decrease) in cash and cash equivalents | (1,430 | ) |  | 3,834 |  |
| Cash and cash equivalents at beginning of period | 96,872 |  |  | 93,038 |  |
| Cash and cash equivalents at end of period | 95,442 |  |  | 96,872 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 933 |  |  | 757 |  |
| Cash paid for taxes, net of refunds | 30,671 |  |  | 13,096 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 442 |  |  | 283 |  |
| Accrued costs for property, plant and equipment purchases | 6,826 |  |  | 2,021 |  |

[0001628280-15-006029:8k_2_02:34]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended June 30, |  | Fiscal Year Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP GROSS PROFIT | $ | 89,766 |  |  | $ | 66,397 |  |  | $ | 320,231 |  |  | $ | 225,545 |  |
|  | Add back stock-based compensation (c) | 250 |  |  | 215 |  |  | 901 |  |  | 941 |  |
| Non-GAAP GROSS PROFIT | $ | 90,016 |  |  | $ | 66,612 |  |  | $ | 321,132 |  |  | $ | 226,486 |  |
| GAAP GROSS MARGIN | 15.6 | % |  | 15.5 | % |  | 16.1 | % |  | 15.4 | % |
|  | Add back stock-based compensation (c) | 0.1 | % |  | 0.1 | % |  | 0.0 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 15.7 | % |  | 15.6 | % |  | 16.1 | % |  | 15.4 | % |
| GAAP INCOME FROM OPERATIONS | $ | 40,787 |  |  | $ | 26,540 |  |  | $ | 146,746 |  |  | $ | 80,259 |  |
|  | Add back stock-based compensation (c) | 3,972 |  |  | 2,879 |  |  | 13,699 |  |  | 11,062 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 44,759 |  |  | $ | 29,419 |  |  | $ | 160,445 |  |  | $ | 91,321 |  |
| GAAP NET INCOME | $ | 26,702 |  |  | $ | 16,549 |  |  | $ | 101,863 |  |  | $ | 54,157 |  |
|  | Add back stock-based compensation (c) | 3,972 |  |  | 2,879 |  |  | 13,699 |  |  | 11,062 |  |
|  | Add back adjustments to tax provision (d) | (681 | ) |  | (31 | ) |  | (3,955 | ) |  | (2,303 | ) |
| Non-GAAP NET INCOME | $ | 29,993 |  |  | $ | 19,397 |  |  | $ | 111,607 |  |  | $ | 62,916 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.56 |  |  | $ | 0.37 |  |  | $ | 2.19 |  |  | $ | 1.24 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.07 |  |  | 0.06 |  |  | 0.21 |  |  | 0.20 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.63 |  |  | $ | 0.43 |  |  | $ | 2.40 |  |  | $ | 1.44 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.51 |  |  | $ | 0.34 |  |  | $ | 2.03 |  |  | $ | 1.16 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.06 |  |  | 0.06 |  |  | 0.12 |  |  | 0.18 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.57 |  |  | $ | 0.40 |  |  | $ | 2.15 |  |  | $ | 1.34 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP (g) | 47,327 |  |  | 45,017 |  |  | 46,434 |  |  | 43,599 |  |
|  | BASIC - Non-GAAP (h) | 47,327 |  |  | 45,018 |  |  | 46,434 |  |  | 43,628 |  |
|  | DILUTED – GAAP (g) | 51,990 |  |  | 48,317 |  |  | 50,094 |  |  | 46,512 |  |
|  | DILUTED - Non-GAAP (h) | 52,609 |  |  | 48,977 |  |  | 51,930 |  |  | 47,075 |  |

[0001628280-15-006029:8k_2_02:35]
(a) Approximately $311 and $36,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:36]
(b) Approximately $290 and $34,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively,.

[0001628280-15-006029:8k_2_02:37]
(c) Amortization of ASC Topic 718 stock-based compensation for the three months and fiscal year ended June 30, 2015 and 2014.

[0001628280-15-006029:8k_2_02:38]
(d) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 32.6% and 30.1% for the three months and fiscal year ended June 30, 2015, respectively, and 33.6% and 30.6%  for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:39]
(e) Approximately $365 and $42,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:40]
(f) Approximately $335 and $39,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:41]
(g) 846 and 29,326 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:42]
(h) 846 and 29,326 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively.

[0001628280-15-006029:8k_2_02:43]
SOURCE: Super Micro Computer, Inc.

[0001628280-15-006029:8k_2_02:44]
Super Micro Computer, Inc.

[0001628280-15-006029:8k_2_02:45]
Howard Hideshima, 408-503-8000

[0001628280-15-006029:8k_2_02:46]
SVP, Chief Financial Officer

[0001628280-15-006029:8k_2_02:47]
ir@supermicro.com

[0001628280-15-006029:8k_2_02:48]
or

[0001628280-15-006029:8k_2_02:49]
Perry G. Hayes

[0001628280-15-006029:8k_2_02:50]
SVP, Investor Relations

[0001628280-15-006029:8k_2_02:51]
ir@supermicro.com

[0001628280-15-006029:8k_2_02:52]
SMCI-F
