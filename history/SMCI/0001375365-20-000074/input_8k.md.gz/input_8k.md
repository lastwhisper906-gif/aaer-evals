# SMCI 8-K — 0001375365-20-000069 filed 2020-11-03

## item codes, every 8-K on or before 2020-11-06

- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2020-11-06

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-20-000069:8k_2_02:1]
EX-99.1
2
exhibit99120200930.htm
EX-99.1

[0001375365-20-000069:8k_2_02:2]
Document

[0001375365-20-000069:8k_2_02:3]
Exhibit 99.1

[0001375365-20-000069:8k_2_02:4]
Supermicro Announces First Quarter Fiscal Year 2021

[0001375365-20-000069:8k_2_02:5]
Financial Results and New Stock Repurchase Authorization

[0001375365-20-000069:8k_2_02:6]
SAN JOSE, Calif. -- November 3, 2020 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced financial results for its first quarter of fiscal year 2021 ended September 30, 2020.

[0001375365-20-000069:8k_2_02:7]
First Quarter Fiscal Year 2021 Highlights

[0001375365-20-000069:8k_2_02:8]
•Net sales of $762 million versus $896 million in the fourth quarter of fiscal year 2020 and $800 million in the same quarter of last year.

[0001375365-20-000069:8k_2_02:9]
•Gross margin of 17.0% versus 13.8% in the fourth quarter of fiscal year 2020 and 16.4% in the same quarter of last year.

[0001375365-20-000069:8k_2_02:10]
•Net income of $27 million versus $18 million in the fourth quarter of fiscal year 2020 and $26 million in the same quarter of last year.

[0001375365-20-000069:8k_2_02:11]
•Diluted net income per common share of $0.49 versus $0.34 in the fourth quarter of fiscal year 2020 and $0.51 in the same quarter of last year.

[0001375365-20-000069:8k_2_02:12]
•Non-GAAP diluted net income per common share of $0.55 versus $0.68 in the fourth quarter of fiscal year 2020 and $0.68 in the same quarter of last year.

[0001375365-20-000069:8k_2_02:13]
•Cash flow from operations of $121 million and capital expenditures of $12 million.

[0001375365-20-000069:8k_2_02:14]
Non-GAAP gross margin for the first quarter of fiscal year 2021 was 17.1%, which adds back stock-based compensation expenses of $0.5 million. Non-GAAP diluted net income per common share for the first quarter of fiscal year 2021 was $0.55, which adds back stock-based compensation expenses of $7.2 million, special performance bonuses of $0.1 million, and other non-recurring expenses of $0.2 million, and excludes a credit of $2.1 million from an executive SEC settlement, all net of the related tax effects.

[0001375365-20-000069:8k_2_02:15]
As of September 30, 2020, total cash, cash equivalents and restricted cash was $302 million and total bank debt was $36 million. Supermicro completed its previously announced $30 million share purchase program during Q1 2020.

[0001375365-20-000069:8k_2_02:16]
“We were pleased to deliver Q1 revenue above the midpoint of our guidance range in a turbulent demand environment,"  said Charles Liang, Chairman and CEO.  "As expected, a number of our enterprise customers slowed their spending last quarter, but we are encouraged to see significant progress and growth with several high profile customers last quarter. A recent improvement in business trends gives us confidence in our outlook to resume sequential growth. We are excited about our robust pipeline of innovative products extending into the next calendar year.  We believe that our Q1 results will mark a near-term bottom as we aim to re-accelerate our growth through the remainder of fiscal 2021 and drive further growth in fiscal 2022."

[0001375365-20-000069:8k_2_02:17]
Second Quarter Fiscal Year 2021 Guidance

[0001375365-20-000069:8k_2_02:18]
The Company expects net sales of $780 million to $880 million, GAAP net income per diluted share of $0.25 to $0.47 and non-GAAP net income per diluted share of $0.35 to $0.58 for the second quarter of fiscal year 2021 ending December 31, 2020. The Company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 16% and a fully diluted share count of 56 million shares. The outlook for Q2 of fiscal year 2021 GAAP net income per diluted share includes approximately $7.0 million in expected stock-based compensation expense that is excluded from non-GAAP net income per diluted share.

[0001375365-20-000069:8k_2_02:19]
Share Repurchase Authorization

[0001375365-20-000069:8k_2_02:20]
The Company also announced today that, its Board of Directors has authorized a new stock repurchase program pursuant to which the Company may repurchase up to $50 million of its common stock. The stock repurchase program is effective until October 31, 2021 or until the maximum amount of common stock is repurchased, whichever occurs first.

[0001375365-20-000069:8k_2_02:21]
"The stock repurchase program reflects our ongoing commitment to creating value for shareholders," said Charles Liang, Chairman and CEO of the Company.  "We are currently taking an opportunistic approach to our stock repurchases while we continue to refine our longer-term capital allocation strategy."

[0001375365-20-000069:8k_2_02:22]
Stock repurchases may be made from time to time at prevailing prices in the open market, including pursuant to a Rule 10b5-1 plan. There can be no assurance of how many shares will be repurchased, and the repurchase program may be suspended for periods or discontinued at any time. The timing and amount of any shares repurchased will be determined based on an evaluation of market conditions and other factors. Share repurchases will be funded with cash on hand.

[0001375365-20-000069:8k_2_02:23]
The Company had approximately 51,782,128 shares of common stock outstanding on October 31, 2020.

[0001375365-20-000069:8k_2_02:24]
Conference Call and Webcast Information

[0001375365-20-000069:8k_2_02:25]
The Company will hold a phone conference to answer questions from institutional investors and financial analysts beginning at 2:00 p.m. Pacific Time (PT) on November 3, 2020.

[0001375365-20-000069:8k_2_02:26]
The conference call can be accessed by registering online at:

[0001375365-20-000069:8k_2_02:27]
http://www.directeventreg.com/registration/event/7507107

[0001375365-20-000069:8k_2_02:28]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes. Registration is open up to the time of the live call, but to ensure access to the entire call, it is recommended that participants register at least 10 minutes before the start of the call.

[0001375365-20-000069:8k_2_02:29]
The webcast can be accessed by registering online at:

[0001375365-20-000069:8k_2_02:30]
https://event.on24.com/wcc/r/2626349/BFCD1F879C4694137390AB44F5B94A45

[0001375365-20-000069:8k_2_02:31]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website

[0001375365-20-000069:8k_2_02:32]
(https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-20-000069:8k_2_02:33]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-20-000069:8k_2_02:34]
could decline in value, (v) the average sales prices for our server solutions could decline if customers do not continue to purchase our latest generation products or additional components, and (vi) adverse economic conditions may harm our business. Additional factors that could cause actual results to differ materially from those projected or suggested in any forward-looking statements are contained in our filings with the Securities and Exchange Commission, including those factors discussed under the caption "Risk Factors" in such filings, particularly in our Annual Report on Form 10-K for our fiscal year ended June 30, 2020.

[0001375365-20-000069:8k_2_02:35]
Use of Non-GAAP Financial Measures

[0001375365-20-000069:8k_2_02:36]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and special performance bonuses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, and other non-recurring expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-20-000069:8k_2_02:37]
About Super Micro Computer, Inc.

[0001375365-20-000069:8k_2_02:38]
Supermicro (Nasdaq:SMCI), the leading innovator in high-performance, high-efficiency server and storage technology is a premier provider of advanced server Building Block Solutions® for Enterprise Data Center, Cloud Computing, Artificial Intelligence, and Edge Computing Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-20-000069:8k_2_02:39]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-20-000069:8k_2_02:40]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-20-000069:8k_2_02:41]
Investor Relations Contact

[0001375365-20-000069:8k_2_02:42]
James Kisner

[0001375365-20-000069:8k_2_02:43]
Vice President, Investor Relations

[0001375365-20-000069:8k_2_02:44]
(669) 284-1259

[0001375365-20-000069:8k_2_02:45]
email: ir@supermicro.com

[0001375365-20-000069:8k_2_02:46]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000069:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-20-000069:8k_2_02:48]
(in thousands)

[0001375365-20-000069:8k_2_02:49]
(unaudited)

[0001375365-20-000069:8k_2_02:50]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 300,089 |  |  | $ | 210,533 |  |
| Accounts receivable, net of allowances | 322,845 |  |  | 403,745 |  |
| Inventories | 773,856 |  |  | 851,498 |  |
| Prepaid expenses and other current assets | 82,731 |  |  | 126,985 |  |
| Total current assets | 1,479,521 |  |  | 1,592,761 |  |
| Investment in equity investee | 5,025 |  |  | 2,703 |  |
| Property, plant and equipment, net | 241,852 |  |  | 233,785 |  |
| Deferred income taxes, net | 55,122 |  |  | 54,898 |  |
| Other assets | 35,173 |  |  | 34,499 |  |
| Total assets | $ | 1,816,693 |  |  | $ | 1,918,646 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 333,359 |  |  | $ | 417,673 |  |
| Accrued liabilities | 121,710 |  |  | 155,401 |  |
| Income taxes payable | 6,325 |  |  | 4,700 |  |
| Short-term debt | 24,047 |  |  | 23,704 |  |
| Deferred revenue | 104,247 |  |  | 106,157 |  |
| Total current liabilities | 589,688 |  |  | 707,635 |  |
| Deferred revenue, non-current | 97,576 |  |  | 97,612 |  |
| Long-term debt, net of debt issuance costs | 11,980 |  |  | 5,697 |  |
| Other long-term liabilities | 44,707 |  |  | 41,995 |  |
| Total liabilities | 743,951 |  |  | 852,939 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 400,157 |  |  | 389,972 |  |
| Treasury stock | (50,491) |  |  | (20,491) |  |
| Accumulated other comprehensive gain (loss) | 95 |  |  | (152) |  |
| Retained earnings | 722,812 |  |  | 696,211 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,072,573 |  |  | 1,065,540 |  |
| Noncontrolling interest | 169 |  |  | 167 |  |
| Total stockholders’ equity | 1,072,742 |  |  | 1,065,707 |  |
| Total liabilities and stockholders’ equity | $ | 1,816,693 |  |  | $ | 1,918,646 |  |

[0001375365-20-000069:8k_2_02:51]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000069:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-20-000069:8k_2_02:53]
(in thousands, except share and per share amounts)

[0001375365-20-000069:8k_2_02:54]
(unaudited)

[0001375365-20-000069:8k_2_02:55]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Net sales | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |
| Cost of sales | 632,335 |  |  | 668,875 |  |  |  |  |  |
| Gross profit | 129,915 |  |  | 130,929 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 54,798 |  |  | 49,572 |  |  |  |  |  |
| Sales and marketing | 20,292 |  |  | 20,194 |  |  |  |  |  |
| General and administrative | 24,379 |  |  | 28,298 |  |  |  |  |  |
| Total operating expenses | 99,469 |  |  | 98,064 |  |  |  |  |  |
| Income from operations | 30,446 |  |  | 32,865 |  |  |  |  |  |
| Other income (expense), net | (841) |  |  | 1,589 |  |  |  |  |  |
| Interest expense | (674) |  |  | (552) |  |  |  |  |  |
| Income before income tax provision | 28,931 |  |  | 33,902 |  |  |  |  |  |
| Income tax provision | (3,660) |  |  | (8,568) |  |  |  |  |  |
| Share of income from equity investee, net of taxes | 1,330 |  |  | 1,011 |  |  |  |  |  |
| Net income | $ | 26,601 |  |  | $ | 26,345 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.51 |  |  | $ | 0.52 |  |  |  |  |  |
| Diluted | $ | 0.49 |  |  | $ | 0.51 |  |  |  |  |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 52,329 |  |  | 50,274 |  |  |  |  |  |
| Diluted | 54,426 |  |  | 51,704 |  |  |  |  |  |

[0001375365-20-000069:8k_2_02:56]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-20-000069:8k_2_02:57]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Cost of sales | $ | 503 |  |  | $ | 395 |  |  |  |  |  |
| Research and development | 3,702 |  |  | 3,130 |  |  |  |  |  |
| Sales and marketing | 517 |  |  | 436 |  |  |  |  |  |
| General and administrative | 2,448 |  |  | 1,093 |  |  |  |  |  |
| Stock-based compensation expense | $ | 7,170 |  |  | $ | 5,054 |  |  |  |  |  |

[0001375365-20-000069:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000069:8k_2_02:59]
SELECTED CASH FLOW INFORMATION

[0001375365-20-000069:8k_2_02:60]
(in thousands)

[0001375365-20-000069:8k_2_02:61]
(unaudited)

[0001375365-20-000069:8k_2_02:62]
|  | Three Months EndedSeptember 30, |
|  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 120,555 |  |  | $ | 5,560 |  |
| Net cash used in investing activities | (11,851) |  |  | (13,325) |  |
| Net cash used in financing activities | (19,327) |  |  | (1,715) |  |
| Effect of exchange rate fluctuations on cash | 185 |  |  | (38) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 89,562 |  |  | (9,518) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 212,390 |  |  | 262,140 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 301,952 |  |  | $ | 252,622 |  |

[0001375365-20-000069:8k_2_02:63]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000069:8k_2_02:64]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000069:8k_2_02:65]
(in thousands, except share and per share amounts)

[0001375365-20-000069:8k_2_02:66]
(unaudited)

[0001375365-20-000069:8k_2_02:67]
|  | Three Months Ended |  |  |
|  | September 30, 2020 |  | June 30,2020 |  | September 30, 2019 |  |  |  |  |
| GAAP GROSS PROFIT | $ | 129,915 |  |  | $ | 123,517 |  |  | $ | 130,929 |  |  |  |  |  |
| Stock-based compensation | 503 |  |  | 355 |  |  | 395 |  |  |  |  |  |
| Special performance bonuses | — |  |  | 1,201 |  |  | — |  |  |  |  |  |
| Other expenses | 20 |  |  | 39 |  |  | — |  |  |  |  |  |
| Non-GAAP GROSS PROFIT | $ | 130,438 |  |  | $ | 125,112 |  |  | $ | 131,324 |  |  |  |  |  |
| GAAP GROSS MARGIN | 17.0 | % |  | 13.8 | % |  | 16.4 | % |  |  |  |  |
| Stock-based compensation expenses | 0.1 | % |  | — | % |  | — | % |  |  |  |  |
| Special performance bonuses | — | % |  | 0.2 | % |  | — | % |  |  |  |  |
| Other expenses | — | % |  | — | % |  | — | % |  |  |  |  |
| Non-GAAP GROSS MARGIN | 17.1 | % |  | 14.0 | % |  | 16.4 | % |  |  |  |  |
| GAAP OPERATING EXPENSE | $ | 99,469 |  |  | $ | 114,089 |  |  | $ | 98,064 |  |  |  |  |  |
| Stock-based compensation | (6,667) |  |  | (5,011) |  |  | (4,659) |  |  |  |  |  |
| Executive SEC settlement | 2,122 |  |  | — |  |  | — |  |  |  |  |  |
| Special performance bonuses | (90) |  |  | (16,224) |  |  | — |  |  |  |  |  |
| Other expenses | (221) |  |  | (638) |  |  | — |  |  |  |  |  |
| Controls remediation | — |  |  | (1,004) |  |  | (7,660) |  |  |  |  |  |
| Non-GAAP OPERATING EXPENSE | $ | 94,613 |  |  | $ | 91,212 |  |  | $ | 85,745 |  |  |  |  |  |
| GAAP INCOME FROM OPERATIONS | $ | 30,446 |  |  | $ | 9,428 |  |  | $ | 32,865 |  |  |  |  |  |
| Stock-based compensation | 7,170 |  |  | 5,366 |  |  | 5,054 |  |  |  |  |  |
| Executive SEC settlement | (2,122) |  |  | — |  |  | — |  |  |  |  |  |
| Special performance bonuses | 90 |  |  | 17,425 |  |  | — |  |  |  |  |  |
| Other expenses | 241 |  |  | 677 |  |  | — |  |  |  |  |  |
| Controls remediation | — |  |  | 1,004 |  |  | 7,660 |  |  |  |  |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 35,825 |  |  | $ | 33,900 |  |  | $ | 45,579 |  |  |  |  |  |
| GAAP NET INCOME | $ | 26,601 |  |  | $ | 18,450 |  |  | $ | 26,345 |  |  |  |  |  |
| Stock-based compensation | 7,170 |  |  | 5,366 |  |  | 5,054 |  |  |  |  |  |
| Executive SEC settlement | (2,122) |  |  | — |  |  | — |  |  |  |  |  |
| Special performance bonuses | 90 |  |  | 17,425 |  |  | — |  |  |  |  |  |
| Other expenses | 241 |  |  | 677 |  |  | — |  |  |  |  |  |
| Controls remediation | — |  |  | 1,004 |  |  | 7,660 |  |  |  |  |  |
| Adjustments to tax provision | (1,183) |  |  | (5,101) |  |  | (3,049) |  |  |  |  |  |
| Non-GAAP NET INCOME | $ | 30,797 |  |  | $ | 37,821 |  |  | $ | 36,010 |  |  |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.51 |  |  | $ | 0.35 |  |  | $ | 0.52 |  |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.08 |  |  | 0.37 |  |  | 0.20 |  |  |  |  |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.59 |  |  | $ | 0.72 |  |  | $ | 0.72 |  |  |  |  |  |

[0001375365-20-000069:8k_2_02:68]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000069:8k_2_02:69]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000069:8k_2_02:70]
(in thousands, except share and per share amounts)

[0001375365-20-000069:8k_2_02:71]
(unaudited)

[0001375365-20-000069:8k_2_02:72]
|  | Three Months Ended |  |  |
|  | September 30, 2020 |  | June 30,2020 |  | September 30, 2019 |  |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.49 |  |  | $ | 0.34 |  |  | $ | 0.51 |  |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.06 |  |  | 0.34 |  |  | 0.17 |  |  |  |  |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.55 |  |  | $ | 0.68 |  |  | $ | 0.68 |  |  |  |  |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 52,329 |  |  | 52,240 |  |  | 50,274 |  |  |  |  |  |
| BASIC - Non-GAAP | 52,329 |  |  | 52,240 |  |  | 50,274 |  |  |  |  |  |
| DILUTED – GAAP | 54,426 |  |  | 54,218 |  |  | 51,704 |  |  |  |  |  |
| DILUTED - Non-GAAP | 55,883 |  |  | 55,595 |  |  | 53,325 |  |  |  |  |  |

## item 5.02 — body, verbatim

[0001375365-20-000069:8k_body:1]
Item 5.02

[0001375365-20-000069:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment Certain Officers; Compensatory Arrangements of Certain Officers

[0001375365-20-000069:8k_body:3]
Appointment of Shiu Leung (Fred) Chan to the Board of Directors

[0001375365-20-000069:8k_body:4]
On October 28, 2020, the Board of Directors (the “Board”) of the Company fixed the number of directors at nine (9) pursuant to provisions in the Amended and Restated Certificate of Incorporation and the Amended and Restated Bylaws of the Company.

[0001375365-20-000069:8k_body:5]
On the same date, Mr. Shiu Leung (Fred) Chan was appointed as a Class III director by the Board to fill the vacancy on the Board resulting from the increase in the authorized number of directors to nine (9), with his term expiring at the Company’s annual meeting of stockholders following fiscal year 2021.

[0001375365-20-000069:8k_body:6]
Mr. Chan is the founder and currently the president of KCR Development, Inc. which has developed real estate projects in excess of $1 billion in California and Hawaii specializing in high-density residential and retail projects.  Mr. Chan also has more than three decades of experience in the high technology sector and as an entrepreneur.  He most recently served as chairman of ESS Technology, Inc., a privately held semiconductor company which he had founded, from 2015 to 2019.  ESS Technology was previously a public company listed on Nasdaq from 1995 until 2008, where he had held a variety of senior executive roles, including as chairman, president and chief executive officer, and served as a director.   Mr. Chan has also previously served as chairman of a privately-held consumer electronic company, founder and an executive officer of a VLSI chip design center providing computer aided design, engineering and other design services, and co-founder and an executive officer of a company in the business of computer aided engineering systems development. Mr. Chan holds B.S.E.E. and M.S.C. degrees from the University of Hawaii.

[0001375365-20-000069:8k_body:7]
Mr. Chan is entitled to receive the Company’s standard indemnity agreement and non-employee director compensation. The Company reimburses non-employee directors for reasonable expenses in connection with attendance at Board and committee meetings. The Company’s non-employee directors receive an annual retainer of $60,000, payable quarterly in cash. In addition, each director serving in a non-chairperson capacity on the Company’s Audit, Compensation or Nominating and Corporate Governance Committees receives an additional annual retainer of $15,000, $10,000 and $7,500 per committee, respectively, payable quarterly in cash. Non-employee directors are entitled to $2,000 per meeting for each meeting attended in excess of (1) the regular meetings of the Board and (2) up to 10 additional meetings beyond such regular meetings, provided that notice of the meeting was properly given, a quorum was present and minutes of the meeting were prepared.  Each non-employee director is entitled to receive an annual grant of RSUs equal in value to $220,000. Initial RSU grants upon election as a director are prorated.
