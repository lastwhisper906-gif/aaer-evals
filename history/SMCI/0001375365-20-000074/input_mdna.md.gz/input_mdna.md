# SMCI MD&A — 0001375365-20-000074


## mdna

[0001375365-20-000074:mdna:1]
[same as prior period, unchanged from 0001375365-20-000033:mdna:1]

[0001375365-20-000074:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2020 (the “2020 10-K”), which includes our consolidated financial statements for the fiscal years ended June 30, 2020 and 2019.

[0001375365-20-000074:mdna:3]
[same as prior period, unchanged from 0001375365-20-000033:mdna:5]

[0001375365-20-000074:mdna:4]
We are a global leader and innovator of application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence, 5G and edge computing. Our solutions include complete servers, storage systems, modular blade servers, blades, workstations, full racks, networking devices, server management software, and server sub-systems. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-20-000074:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended September 30, 2020 increased to $26.6 million from $26.3 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-20-000074:mdna:6]
[same as prior period, unchanged from 0001375365-20-000033:mdna:8]

[0001375365-20-000074:mdna:7]
The global spread of the coronavirus (COVID-19) and the various attempts to contain it have created significant volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders that govern the operations of businesses, require masks be worn and define shelter in place and social distancing protocols. We are an essential critical infrastructure (information technology) business under the relevant federal, state and county regulations. Accordingly, in late March, we responded to the directives from Santa Clara County and the State of California regarding instructions to combat the spread of COVID-19. Our first priority is the safety of our workforce and we have implemented numerous health precautions and work practices to be in compliance with the law and to operate in a safe manner.

[0001375365-20-000074:mdna:8]
We quickly transitioned most of our indirect labor forces to work from home and continued to operate our local assembly in Taiwan and, after an initial period of disruption, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continued to see ongoing demand and do not have significant direct exposure to industries such as retail, oil and gas and hospitality, which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-20-000074:mdna:9]
[same as prior period, unchanged from 0001375365-20-000033:mdna:11]

[0001375365-20-000074:mdna:10]
Logistics has emerged as a new challenge as globally the transportation industry restricted the frequency of departures and increased logistics costs. We experienced increased costs in freight as well as direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect this trend to continue for the duration of the COVID-19 pandemic.

[0001375365-20-000074:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In May 2020, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2021. In June 2020, we entered into a ten-year, non-revolving term loan facility with China Trust and Bank Corp ("CTBC Bank") to obtain financing for use in the expansion and renovation of the our Bade Manufacturing Facility located in Taiwan.

[0001375365-20-000074:mdna:12]
Our management team is focused on guiding our company through the ongoing challenges presented by COVID-19. Currently, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-20-000074:mdna:13]
[same as prior period, unchanged from 0001375365-20-000033:mdna:15]

[0001375365-20-000074:mdna:14]
The following is a summary of our financial highlights of the first quarter of fiscal year 2021:

[0001375365-20-000074:mdna:15]
•Net sales decreased by 4.7% as compared to the three months ended September 30, 2019.

[0001375365-20-000074:mdna:16]
•Gross margin increased to 17.0% in the three months ended September 30, 2020 from 16.4% for the three months ended September 30, 2019.

[0001375365-20-000074:mdna:17]
•Operating expenses increased by 1.4% as compared to the three months ended September 30, 2019, and were equal to 13.0% and 12.3% of net sales in the three months ended September 30, 2020 and 2019, respectively.

[0001375365-20-000074:mdna:18]
•Effective tax rate decreased from 25.3% in the three months ended September 30, 2019 to 12.7% in the three months ended September 30, 2020.

[0001375365-20-000074:mdna:19]
[same as prior period, unchanged from 0001375365-20-000033:mdna:33]

[0001375365-20-000074:mdna:20]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses. We evaluate our estimates and assumptions on an ongoing basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for the judgments we make about the carrying value of assets and liabilities that are not readily apparent from other sources.  Because these estimates can vary depending on the situation, actual results may differ from these estimates.  Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-20-000074:mdna:21]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2020 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Summary of Significant Accounting Policies" in our notes to the condensed consolidated financial statements in this Quarterly Report.

[0001375365-20-000074:mdna:22]
[same as prior period, unchanged from 0001375365-20-000033:mdna:36]

[0001375365-20-000074:mdna:23]
[same as prior period, unchanged from 0001375365-20-000033:mdna:37]

[0001375365-20-000074:mdna:24]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 83.0 | % |  | 83.6 | % |  |  |  |  |
| Gross profit | 17.0 | % |  | 16.4 | % |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 7.2 | % |  | 6.2 | % |  |  |  |  |
| Sales and marketing | 2.7 | % |  | 2.5 | % |  |  |  |  |
| General and administrative | 3.2 | % |  | 3.5 | % |  |  |  |  |
| Total operating expenses | 13.0 | % |  | 12.3 | % |  |  |  |  |
| Income from operations | 4.0 | % |  | 4.1 | % |  |  |  |  |
| Other (expense) income, net | (0.1) | % |  | 0.2 | % |  |  |  |  |
| Interest expense | (0.1) | % |  | (0.1) | % |  |  |  |  |
| Income before income tax provision | 3.8 | % |  | 4.2 | % |  |  |  |  |
| Income tax provision | (0.5) | % |  | (1.1) | % |  |  |  |  |
| Share of income from equity investee, net of taxes | 0.2 | % |  | 0.1 | % |  |  |  |  |
| Net income | 3.5 | % |  | 3.3 | % |  |  |  |  |

[0001375365-20-000074:mdna:25]
[same as prior period, unchanged from 0001375365-20-000033:mdna:39]

[0001375365-20-000074:mdna:26]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact our net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact our net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-20-000074:mdna:27]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs.

[0001375365-20-000074:mdna:28]
The following table presents net sales by product type for the three months ended September 30, 2020 and 2019 (dollars in millions):

[0001375365-20-000074:mdna:29]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617.8 |  |  | $ | 636.0 |  |  | $ | (18.2) |  |  | (2.9) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 81.0 | % |  | 79.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | $ | 144.5 |  |  | $ | 163.8 |  |  | $ | (19.3) |  |  | (11.8) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 19.0 | % |  | 20.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 762.3 |  |  | $ | 799.8 |  |  | $ | (37.5) |  |  | (4.7) | % |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:30]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of server-boards, chassis and accessories.

[0001375365-20-000074:mdna:31]
The period-over-period decrease in net sales of our server and storage systems was due to a 19.1% decrease in the number of units of compute nodes sold offset by 20.0% increase in average selling price. The decline in the number of units of compute nodes shipped was primarily due to fewer shipments of multimode systems compared to the same period last year.

[0001375365-20-000074:mdna:32]
The period-over-period decrease in net sales of our subsystems and accessories is primarily due to a decrease in the volume of subsystems and accessories units sold by approximately 24.4% which was offset by an approximately 16.7% increase in the average selling price.

[0001375365-20-000074:mdna:33]
The following table presents net sales by geographic region for the three months ended September 30, 2020 and 2019 (dollars in millions):

[0001375365-20-000074:mdna:34]
|  | Three Months Ended September 30, |  | Change |  | Change |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| United states | $ | 496.1 |  |  | $ | 468.8 |  |  | $ | 27.3 |  |  | 5.8 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 65.1 | % |  | 58.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe | 112.1 |  |  | 128.1 |  |  | (16.0) |  |  | (12.5) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 14.7 | % |  | 16.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | 126.7 |  |  | 161.6 |  |  | (34.9) |  |  | (21.6) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 16.6 | % |  | 20.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | 27.4 |  |  | 41.3 |  |  | (13.9) |  |  | (33.7) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 3.6 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 762.3 |  |  | $ | 799.8 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:35]
The period-over-period increase in net sales in the United States for the three months ended September 30, 2020 and 2019 was primarily due to higher sales from the expansion of our customer base. The period-over-period decrease in net sales in Asia was due primarily to decreased sales in China, Japan and Korea and partially off-set by increased sales in Singapore and Taiwan. The decrease of net sales in Europe was primarily due to lower sales in the United Kingdom, Germany, Russia, and the rest of other Europe, partially offset by increased sales in France and the Netherlands.

[0001375365-20-000074:mdna:36]
[same as prior period, unchanged from 0001375365-20-000033:mdna:62]

[0001375365-20-000074:mdna:37]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-20-000074:mdna:38]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies.

[0001375365-20-000074:mdna:39]
Cost of sales and gross margin for the three months ended September 30, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000074:mdna:40]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Cost of sales | $ | 632.3 |  |  | $ | 668.9 |  |  | $ | (36.6) |  |  | (5.5) | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 129.9 |  |  | $ | 130.9 |  |  | $ | (1.0) |  |  | (0.8) | % |  |  |  |  |  |  |  |  |
| Gross margin | 17.0 | % |  | 16.4 | % |  |  |  | 0.6 | % |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:41]
The period-over-period decrease in cost of sales was primarily attributed to a decrease of $17.2 million in costs of materials and contract manufacturing expenses primarily related to the decrease in net sales volume, a decrease of $10.3 million in overhead costs attributable primarily to a recovery of costs paid in prior periods and a decrease of excess and obsolete inventory charge of $9.1 million.

[0001375365-20-000074:mdna:42]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components we purchased.

[0001375365-20-000074:mdna:43]
[same as prior period, unchanged from 0001375365-20-000033:mdna:72]

[0001375365-20-000074:mdna:44]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-20-000074:mdna:45]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, costs for trade-shows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-20-000074:mdna:46]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-20-000074:mdna:47]
Operating expenses for the three months ended September 30, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000074:mdna:48]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Research and development | $ | 54.8 |  |  | $ | 49.6 |  |  | $ | 5.2 |  |  | 10.5 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 7.2 | % |  | 6.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 20.3 |  |  | $ | 20.2 |  |  | $ | 0.1 |  |  | 0.5 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.7 | % |  | 2.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 24.4 |  |  | $ | 28.3 |  |  | $ | (3.9) |  |  | (13.8) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 3.2 | % |  | 3.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 99.5 |  |  | $ | 98.1 |  |  | $ | 1.4 |  |  | 1.4 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 13.0 | % |  | 12.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:49]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $5.7 million in personnel expenses as a result of an increase in the number of personnel and an

[0001375365-20-000074:mdna:50]
increase of $1.2 million in costs mainly related to materials, supplies and equipment used in product development offset by an increase of $1.3 million research and development credits from certain suppliers and customers towards our development efforts.

[0001375365-20-000074:mdna:51]
Sales and marketing expenses. The period-over-period sales and marketing expenses for the three months ended September 30, 2020 remained flat as compared to the three months ended September 30, 2019.

[0001375365-20-000074:mdna:52]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to decrease of $6.7 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements and a decrease of $1.0 million in other general and administrative expenses, offset by an increase of $3.7 million in compensation expense due to increased full time personnel and bonuses.

[0001375365-20-000074:mdna:53]
Interest and Other (Expense) Income, Net

[0001375365-20-000074:mdna:54]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-20-000074:mdna:55]
[same as prior period, unchanged from 0001375365-20-000033:mdna:86]

[0001375365-20-000074:mdna:56]
Interest and other (expense) income, net for the three months ended September 30, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000074:mdna:57]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other (expense) income, net | $ | (0.8) |  |  | $ | 1.6 |  |  | $ | (2.4) |  |  | (150.0) | % |  |  |  |  |  |  |  |  |
| Interest expense | (0.7) |  |  | (0.6) |  |  | (0.1) |  |  | 16.7 | % |  |  |  |  |  |  |  |  |
| Interest and other (expense) income, net | $ | (1.5) |  |  | $ | 1.0 |  |  | $ | (2.5) |  |  | (250.0) | % |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:58]
The change of $2.4 million in other (expense) income, net was attributable to a decrease of $1.0 million in interest income on our interest bearing deposits and a $1.5 million foreign exchange loss. The period-over-period change in interest expense was due to an increase of $0.1 million in interest expense primarily as a result of increased interest rates on our loans in the three months ended September 30, 2020 as compared to the three months ended September 30, 2019.

[0001375365-20-000074:mdna:59]
Provision for Income Taxes

[0001375365-20-000074:mdna:60]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, releases from uncertain tax positions, tax benefits from foreign derived intangible income and stock based compensation.

[0001375365-20-000074:mdna:61]
Provision for income taxes and effective tax rates for the three months ended September 30, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000074:mdna:62]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income tax provision | $ | 3.7 |  |  | $ | 8.6 |  |  | $ | (4.9) |  |  | (57.0) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 0.5 | % |  | 1.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective tax rate | 12.7 | % |  | 25.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-20-000074:mdna:63]
The income tax provision and effective tax rate change for the three months ended September 30, 2020 was primarily due to decrease in tax reserves for uncertain tax positions after settlement of certain tax audits and increase in tax benefit from employees’ stock based compensation.

[0001375365-20-000074:mdna:64]
[same as prior period, unchanged from 0001375365-20-000033:mdna:101]

[0001375365-20-000074:mdna:65]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $300.1 million and $210.5 million as of September 30, 2020 and June 30, 2020, respectively. Our cash in foreign locations was $87.7 million and $98.0 million as of September 30, 2020 and June 30, 2020, respectively.

[0001375365-20-000074:mdna:66]
[same as prior period, unchanged from 0001375365-20-000033:mdna:103]

[0001375365-20-000074:mdna:67]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses, continued remediation of the material weakness in the financial reporting, and maturing debt and interest payments for the twelve months following the issuance of these consolidated financial statements. We expect to pay special performance bonuses of approximately $8.6 million to our CEO and certain members of the Board of Directors within the next two years when and if specified market and performance conditions are met. In addition, we made a settlement payment of $17.5 million to the SEC in connection with the conclusion of the investigations in August 2020.

[0001375365-20-000074:mdna:68]
On October 31, 2020, our Board of Directors approved a share repurchase program to repurchase shares of our common stock for up to $50 million at prevailing prices in the open market. The share repurchase program is effective until October 31, 2021 or until the maximum amount of common stock is repurchased, whichever occurs first.

[0001375365-20-000074:mdna:69]
[same as prior period, unchanged from 0001375365-20-000033:mdna:105]

[0001375365-20-000074:mdna:70]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Net cash provided by operating activities | $ | 120.6 |  |  | $ | 5.6 |  |  | $ | 115.0 |  |  |  |  |
| Net cash used in investing activities | $ | (11.9) |  |  | $ | (13.3) |  |  | $ | 1.4 |  |  |  |  |
| Net cash used in financing activities | $ | (19.3) |  |  | $ | (1.7) |  |  | $ | (17.6) |  |  |  |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 89.6 |  |  | $ | (9.5) |  |  | $ | 99.1 |  |  |  |  |

[0001375365-20-000074:mdna:71]
[same as prior period, unchanged from 0001375365-20-000033:mdna:107]

[0001375365-20-000074:mdna:72]
Net cash provided by operating activities increased by $115.0 million for the three months ended September 30, 2020 as compared to the three months ended September 30, 2019. The increase was due primarily to an increase of cash provided by net working capital of $121.2 million driven by decreased accounts receivable as a result of increased collections, utilization of inventories and prepaid expenses and other current assets. Non-cash charges related to depreciation and amortization expense, stock-based compensation expense and unrealized losses on our foreign currency-denominated credit facilities increased $4.0 million. These increases were offset by a decrease of $9.2 million in the non-cash charges related to excess and obsolete inventories.

[0001375365-20-000074:mdna:73]
[same as prior period, unchanged from 0001375365-20-000033:mdna:109]

[0001375365-20-000074:mdna:74]
Net cash used in investing activities was $11.9 million and $13.3 million for the three months ended September 30, 2020 and 2019, respectively, as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-20-000074:mdna:75]
[same as prior period, unchanged from 0001375365-20-000033:mdna:111]

[0001375365-20-000074:mdna:76]
Net cash used by financing activities for the three months ended September 30, 2020 was $19.3 million while net cash used in financing activities for the three months ended September 30, 2019 was $1.7 million. The change in cash flows from financing activities was primarily due to stock repurchases of $28.5 million offset by cash received from the exercise of stock options of $5.0 million net of taxes and $6.4 million of debt proceeds from draws on our CTBC credit and term loan facilities.

[0001375365-20-000074:mdna:77]
[same as prior period, unchanged from 0001375365-20-000033:mdna:113]

[0001375365-20-000074:mdna:78]
2018 Bank of America Credit Facility

[0001375365-20-000074:mdna:79]
In April 2018, as amended in January and June 2019, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility") for up to $250.0 million. In May 2020, we entered into a third amendment to extend the maturity from June 30, 2020 to June 30, 2021, release the real property as a collateral, modify certain payments and covenants provisions, specify that LIBOR cannot be less than 1% for purposes of determining interest rates, and increase the unused line fee from 0.25% per annum to 0.375% per annum. Interest shall accrue at LIBOR plus 2.00% on outstanding borrowings less than $125.0 million and LIBOR plus 2.25% on outstanding borrowings in excess of $125.0 million. As of September 30, 2020, we had no outstanding borrowings and we had a $6.4 million letter of credit outstanding under this facility. Our available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms. In the event of default or if outstanding borrowings are in excess of $220.0 million, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. In addition, we are not permitted to pay any dividends. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-20-000074:mdna:80]
CTBC Bank

[0001375365-20-000074:mdna:81]
2020 CTBC Credit Facility

[0001375365-20-000074:mdna:82]
In August 2020, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans of up to $50.0 million (the "2020 CTBC Credit Facility") and expires in August 2021. During the three months ended September 30, 2020, we have not borrowed or repaid under the revolving line of credit. There were no outstanding borrowings under the 2020 CTBC Credit Facility revolving line of credit as of September 30, 2020. The total outstanding borrowings under the 2020 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.0 million at September 30, 2020. The amount available for future borrowing was $26.3 million as of September 30, 2020. The interest rate for these outstanding term loans was 0.73% per annum as of September 30, 2020. Term loans are secured by certain of our assets, including certain property, plant, and equipment. There are no financial covenants under the 2020 CTBC Credit Facility.

[0001375365-20-000074:mdna:83]
2020 CTBC Term Loan Facility

[0001375365-20-000074:mdna:84]
In May 2020, we entered into a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of our Bade Manufacturing Facility located in Taiwan. Draw downs on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and are drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. We are required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility, including any expansion. Fees paid to the lender as debt issuance costs were immaterial. We borrowed $6.3 million in the three months ended September 30, 2020 with a rate of 0.45% per annum. As of September 30, 2020, the amount outstanding under the 2020 CTBC Term Loan Facility was $12.0 million and the net book value of the property serving as collateral was $17.1 million. We have financial covenants requiring our current ratio, debt service coverage ratio, and financial debt ratio, to be maintained at certain levels. We have been in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-20-000074:mdna:85]
Refer to Part I, Item 1, Note 6, “Short-term and Long-term Debt,” in our notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding debt.

[0001375365-20-000074:mdna:86]
[same as prior period, unchanged from 0001375365-20-000033:mdna:119]

[0001375365-20-000074:mdna:87]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Summary of Significant Accounting Policies,” in our notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q.

[0001375365-20-000074:mdna:88]
[same as prior period, unchanged from 0001375365-20-000033:mdna:121]

[0001375365-20-000074:mdna:89]
[same as prior period, unchanged from 0001375365-20-000033:mdna:122]

[0001375365-20-000074:mdna:90]
37
