# SMCI notes — 0001375365-20-000074


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-20-000074:notes:1]
Summary of Significant Accounting Policies
Significant Accounting Policies and Estimates

[0001375365-20-000074:notes:2]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, Organization and Summary of Significant Accounting Policies, in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19') pandemic.

[0001375365-20-000074:notes:3]
[same as prior period, unchanged from 0001375365-20-000033:notes:4]

[0001375365-20-000074:notes:4]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principals in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.

[0001375365-20-000074:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.

[0001375365-20-000074:notes:6]
[same as prior period, unchanged from 0001375365-20-000033:notes:48]

[0001375365-20-000074:notes:7]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-20-000074:notes:8]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2020 and June 30, 2020, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $0.5 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-20-000074:notes:9]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with

[0001375365-20-000074:notes:10]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2020. No impairment charge was recorded for the three months ended September 30, 2020 and 2019, respectively.

[0001375365-20-000074:notes:11]
The Company sold products worth $0.6 million and $22.1 million to the Corporate Venture in the three months ended September 30, 2020 and 2019, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture in the amounts of $2.3 million and $3.0 million as of September 30, 2020 and June 30, 2020, respectively, have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.6 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of September 30, 2020 and June 30, 2020, respectively.

[0001375365-20-000074:notes:12]
[same as prior period, unchanged from 0001375365-20-000033:notes:53]

[0001375365-20-000074:notes:13]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 22.0% and 28.7% of total purchases for the three months ended September 30, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for 9.8% and 9.7% of total cost of sales for the three months ended September 30, 2020 and 2019, respectively.

[0001375365-20-000074:notes:14]
[same as prior period, unchanged from 0001375365-20-000033:notes:55]

[0001375365-20-000074:notes:15]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2020, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.

[0001375365-20-000074:notes:16]
[same as prior period, unchanged from 0001375365-20-000033:notes:57]

[0001375365-20-000074:notes:17]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments. Under this new guidance, a company is required to estimate credit losses on certain types of financial instruments using an expected-loss model, replacing the current incurred-loss model, and record the estimate through an allowance for credit losses, which results in more timely recognition of credit losses. The Company adopted this guidance on July 1, 2020 using the modified retrospective transition method, which requires a cumulative-effect adjustment, if any, to the opening balance of retained earnings to be recognized on the date of adoption with prior periods not restated. The adoption of the guidance had no material impact on the Company’s condensed consolidated financial statements as of July 1, 2020.

[0001375365-20-000074:notes:18]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three months ended September 30, 2020.

[0001375365-20-000074:notes:19]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of September 30, 2020, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial.  See Note 5 below.

[0001375365-20-000074:notes:20]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.

[0001375365-20-000074:notes:21]
[same as prior period, unchanged from 0001375365-20-000033:notes:61]

[0001375365-20-000074:notes:22]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July

[0001375365-20-000074:notes:23]
1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its consolidated financial statements and disclosures.

[0001375365-20-000074:notes:24]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-20-000074:notes:25]
Revenue
    Disaggregation of Revenue

[0001375365-20-000074:notes:26]
The Company disaggregates revenue by type of product and by geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

[0001375365-20-000074:notes:27]
[same as prior period, unchanged from 0001375365-20-000033:notes:70]

[0001375365-20-000074:notes:28]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617,788 |  |  |  |  | $ | 636,026 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 144,462 |  |  |  |  | 163,778 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 762,250 |  |  |  |  | $ | 799,804 |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-20-000074:notes:29]
[same as prior period, unchanged from 0001375365-20-000033:notes:72]

[0001375365-20-000074:notes:30]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2020 and 2019, of net sales by geographic region (in thousands):

[0001375365-20-000074:notes:31]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 496,086 |  |  | $ | 468,841 |  |  |  |  |  |
| Europe | 112,089 |  |  | 128,059 |  |  |  |  |  |
| Asia | 126,707 |  |  | 161,639 |  |  |  |  |  |
| Others | 27,368 |  |  | 41,265 |  |  |  |  |  |
|  | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |

[0001375365-20-000074:notes:32]
Starting July 1, 2020, the Company no longer separately discloses revenue by products sold to indirect sales channel partners or direct customers and original equipment manufacturers because management does not make business operational decisions based on this set of disaggregation so the disclosure is no longer material to investors.

[0001375365-20-000074:notes:33]
[same as prior period, unchanged from 0001375365-20-000033:notes:77]

[0001375365-20-000074:notes:34]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s unconditional right to consideration for performance obligations either partially or fully completed.

[0001375365-20-000074:notes:35]
[same as prior period, unchanged from 0001375365-20-000033:notes:79]

[0001375365-20-000074:notes:36]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2020, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $28.6 million.

[0001375365-20-000074:notes:37]
Deferred revenue decreased $1.9 million during the three months ended September 30, 2020 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

[0001375365-20-000074:notes:38]
[same as prior period, unchanged from 0001375365-20-000033:notes:82]

[0001375365-20-000074:notes:39]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2020 was $201.8 million. The Company expects to recognize approximately 52% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-20-000074:notes:40]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-20-000074:notes:41]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

[0001375365-20-000074:notes:42]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001375365-20-000074:notes:43]
Net Income Per Common Share
    The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2020 and 2019 (in thousands, except per share amounts):

[0001375365-20-000074:notes:44]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 26,601 |  |  | $ | 26,345 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 52,329 |  |  | 50,274 |  |  |  |  |  |
| Effect of dilutive securities | 2,097 |  |  | 1,430 |  |  |  |  |  |
| Weighted-average diluted shares | 54,426 |  |  | 51,704 |  |  |  |  |  |
| Basic net income per common share | $ | 0.51 |  |  | $ | 0.52 |  |  |  |  |  |
| Diluted net income per common share | $ | 0.49 |  |  | $ | 0.51 |  |  |  |  |  |

[0001375365-20-000074:notes:45]
For the three months ended September 30, 2020 and 2019, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,177,694 and 3,958,789 for three months ended September 30, 2020, and 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-20-000074:notes:46]
Balance Sheet Components
    The following tables provide details of the selected balance sheet items (in thousands):

[0001375365-20-000074:notes:47]
[same as prior period, unchanged from 0001375365-20-000033:notes:118]

[0001375365-20-000074:notes:48]
|  | September 30, 2020 |  | June 30, 2020 |
| Finished goods | $ | 553,950 |  |  | $ | 656,817 |  |
| Work in process | 68,322 |  |  | 38,146 |  |
| Purchased parts and raw materials | 151,584 |  |  | 156,535 |  |
| Total inventories | $ | 773,856 |  |  | $ | 851,498 |  |

[0001375365-20-000074:notes:49]
The Company recorded a (recovery) provision for excess and obsolete inventory to cost of sales totaling $(0.8) million and $10.1 million in the three months ended September 30, 2020 and 2019, respectively. These amounts exclude a provision (recovery) for adjusting the cost of certain inventories to net realizable value of $0.9 million and $(1.8) million for the three months ended September 30, 2020 and 2019, respectively. The recovery is recognized when previously reserved inventories are sold.

[0001375365-20-000074:notes:50]
[same as prior period, unchanged from 0001375365-20-000033:notes:121]

[0001375365-20-000074:notes:51]
|  | September 30, 2020 |  | June 30, 2020 |
| Other receivables (1) | $ | 40,417 |  |  | $ | 94,859 |  |
| Prepaid income tax | 13,846 |  |  | 14,323 |  |
| Prepaid expenses | 5,832 |  |  | 7,075 |  |
| Deferred service costs | 4,431 |  |  | 4,161 |  |
| Restricted cash | 250 |  |  | 250 |  |
| Others | 17,955 |  |  | 6,317 |  |
| Total prepaid expenses and other current assets | $ | 82,731 |  |  | $ | 126,985 |  |

[0001375365-20-000074:notes:52]
__________________________

[0001375365-20-000074:notes:53]
(1) Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $33.6 million and $83.8 million as of September 30, 2020 and June 30, 2020, respectively.

[0001375365-20-000074:notes:54]
[same as prior period, unchanged from 0001375365-20-000033:notes:125]

[0001375365-20-000074:notes:55]
|  | September 30, 2020 |  | June 30, 2020 |
| Cash and cash equivalents | $ | 300,089 |  |  | $ | 210,533 |  |
| Restricted cash included in prepaid expenses and other current assets | 250 |  |  | 250 |  |
| Restricted cash included in other assets | 1,613 |  |  | 1,607 |  |
| Total cash, cash equivalents and restricted cash | $ | 301,952 |  |  | $ | 212,390 |  |

[0001375365-20-000074:notes:56]
[same as prior period, unchanged from 0001375365-20-000033:notes:127]

[0001375365-20-000074:notes:57]
|  | September 30, 2020 |  | June 30, 2020 |
| Buildings | $ | 86,930 |  |  | $ | 86,930 |  |
| Land | 75,264 |  |  | 75,251 |  |
| Machinery and equipment | 87,876 |  |  | 85,381 |  |
| Buildings construction in progress (1) | 54,555 |  |  | 46,311 |  |
| Building and leasehold improvements | 24,886 |  |  | 24,517 |  |
| Software | 22,616 |  |  | 20,597 |  |
| Furniture and fixtures | 21,769 |  |  | 21,544 |  |
|  | 373,896 |  |  | 360,531 |  |
| Accumulated depreciation and amortization | (132,044) |  |  | (126,746) |  |
| Property, plant and equipment, net | $ | 241,852 |  |  | $ | 233,785 |  |

[0001375365-20-000074:notes:58]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California, and new building in Taiwan.

[0001375365-20-000074:notes:59]
[same as prior period, unchanged from 0001375365-20-000033:notes:130]

[0001375365-20-000074:notes:60]
|  | September 30, 2020 |  | June 30, 2020 |
| Operating lease right-of-use asset | $ | 24,075 |  |  | $ | 23,784 |  |
| Deferred service costs, non-current | 4,828 |  |  | 4,632 |  |
| Restricted cash, non-current | 1,613 |  |  | 1,607 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 1,252 |  |  | 1,201 |  |
| Non-marketable equity securities | 128 |  |  | 128 |  |
| Prepaid expense, non-current | 1,706 |  |  | 1,576 |  |
| Total other assets | $ | 35,173 |  |  | $ | 34,499 |  |

[0001375365-20-000074:notes:61]
[same as prior period, unchanged from 0001375365-20-000033:notes:132]

[0001375365-20-000074:notes:62]
|  | September 30, 2020 |  | June 30, 2020 |
| Accrued payroll and related expenses | $ | 34,059 |  |  | $ | 33,577 |  |
| Contract manufacturing liabilities | 20,366 |  |  | 36,249 |  |
| Accrued warranty costs | 11,057 |  |  | 9,984 |  |
| Customer deposits | 10,306 |  |  | 9,942 |  |
| Operating lease liability | 7,027 |  |  | 6,310 |  |
| Accrued cooperative marketing expenses | 5,818 |  |  | 5,925 |  |
| Accrued professional fees | 2,630 |  |  | 5,661 |  |
| Accrued legal liabilities (Note 11) | — |  |  | 18,114 |  |
| Others (accrued liabilities) | 30,447 |  |  | 29,639 |  |
| Total accrued liabilities | $ | 121,710 |  |  | $ | 155,401 |  |

[0001375365-20-000074:notes:63]
[same as prior period, unchanged from 0001375365-20-000033:notes:134]

[0001375365-20-000074:notes:64]
In March 2020, the Board of Directors (the “Board”) approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments will be earned when specified market and performance conditions are achieved.

[0001375365-20-000074:notes:65]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved and the date that the payment is made. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved and the date that the payment is made.

[0001375365-20-000074:notes:66]
Performance bonuses for a senior executive and two members of the Board are earned based on achieving a specified target average closing price for the Company’s common stock over the specified period as determined by the Board at the grant dates and continuous services through the payment dates. A senior executive earned an aggregate cash payment of $0.1 million when the target average closing price was met in the fourth quarter of fiscal year 2020. The two members of the Board can earn aggregate cash payments of $0.3 million in two tranches if the target average closing price reaches $31.61 for the first tranche

[0001375365-20-000074:notes:67]
and $32.99 per share for the second tranche. These awards expire in two equal amounts at September 30, 2021 and June 30, 2022 for the two Board members' awards.

[0001375365-20-000074:notes:68]
The Company accounts for the outstanding performance bonuses as liabilities and estimates fair value of payable amounts using a Monte-Carlo simulation model. The awards are re-measured at each period end with changes in fair value recorded in the Company’s consolidated statement of operations in operating expenses. The cumulative recorded expense at each period end is trued-up to the expected payable amount vested through the period end. The requisite service periods over which expenses are recognized are derived from the Monte-Carlo model for all performance awards, except for the first 50% of the Chief Executive Officer’s award that includes a performance condition. The Company estimates if it is probable that the performance condition will be met through the expiration date of this award. If at the measurement date it is determined to be probable, the Company estimates the requisite period as the longer of the service period derived by the Monte-Carlo model and the implicit service period when the Company expects to make adequate progress in remediating its material weaknesses in its internal control over financial reporting, as reported by the Company's Audit Committee. If it is determined to not be probable, then the Company will reverse any previously recognized expense for this award in the period when it is no longer probable that the performance condition will be achieved.

[0001375365-20-000074:notes:69]
As of September 30, 2020 and June 30, 2020, the fair value of these performance bonuses was $2.2 million and $2.1 million, respectively, of which $2.2 million and $1.5 million, respectively, was recorded within accrued liabilities and $0.0 million and $0.6 million, respectively, was recorded within other long-term liabilities on the Company's consolidated balance sheet. An unrecognized compensation expense of $2.3 million will be recorded over the remaining service periods from 0.26 years to 0.93 years. The fair value of these awards is remeasured each reporting period. The expense recognized during the three months ended September 30, 2020 and September 30, 2019 was $0.1 million and $0.0 million respectively.

[0001375365-20-000074:notes:70]
[same as prior period, unchanged from 0001375365-20-000033:notes:141]

[0001375365-20-000074:notes:71]
|  | September 30, 2020 |  | June 30, 2020 |
| Operating lease liability, non-current | $ | 17,892 |  |  | $ | 18,102 |  |
| Accrued unrecognized tax benefits including related interest and penalties | 16,067 |  |  | 15,496 |  |
| Accrued warranty costs, non-current | 2,670 |  |  | 2,395 |  |
| Others | 8,078 |  |  | 6,002 |  |
| Total other long-term liabilities | $ | 44,707 |  |  | $ | 41,995 |  |

[0001375365-20-000074:notes:72]
[same as prior period, unchanged from 0001375365-20-000033:notes:143]

[0001375365-20-000074:notes:73]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Balance, beginning of the period | $ | 12,379 |  |  | $ | 11,034 |  |  |  |  |  |
| Provision for warranty | 8,347 |  |  | 5,872 |  |  |  |  |  |
| Costs utilized | (7,607) |  |  | (7,662) |  |  |  |  |  |
| Change in estimated liability for pre-existing warranties | 608 |  |  | 2,041 |  |  |  |  |  |
| Balance, end of the period | 13,727 |  |  | 11,285 |  |  |  |  |  |
| Current portion | 11,057 |  |  | 8,655 |  |  |  |  |  |
| Non-current portion | $ | 2,670 |  |  | $ | 2,630 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-20-000074:notes:74]
Fair Value Disclosure    The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2020 and June 30, 2020. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of September 30, 2020.

[0001375365-20-000074:notes:75]
[same as prior period, unchanged from 0001375365-20-000033:notes:147]

[0001375365-20-000074:notes:76]
The following table sets forth the Company’s financial instruments as of September 30, 2020 and June 30, 2020, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-20-000074:notes:77]
| September 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 841 |  |  | $ | — |  |  | $ | — |  |  | $ | 841 |  |
| Certificates of deposit (2) | — |  |  | 845 |  |  | — |  |  | 845 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 841 |  |  | $ | 845 |  |  | $ | 1,571 |  |  | $ | 3,256 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,196 |  |  | $ | — |  |  | $ | 2,196 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,196 |  |  | $ | — |  |  | $ | 2,196 |  |
| June 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,163 |  |
| Certificates of deposit (2) | — |  |  | 836 |  |  | — |  |  | 836 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,163 |  |  | $ | 836 |  |  | $ | 1,571 |  |  | $ | 3,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |

[0001375365-20-000074:notes:78]
(1) $0.0 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2020 and June 30, 2020, respectively.

[0001375365-20-000074:notes:79]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.3 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2020 and June 30, 2020, respectively.

[0001375365-20-000074:notes:80]
(3) As of September 30, 2020 and June 30, 2020, the current portion of the performance awards liability of $2.2 million and $1.5 million, respectively, is included in accrued liabilities and the noncurrent portion of $0.0 million and $0.6 million, respectively, is included in other long-term liabilities in the condensed consolidated balance sheets.

[0001375365-20-000074:notes:81]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three months ended September 30, 2020, the credit losses related to the Company’s investments was not significant.

[0001375365-20-000074:notes:82]
The Company estimated the fair value of performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of September 30, 2020 and June 30, 2020 are as follows:

[0001375365-20-000074:notes:83]
| September 30, 2020 |
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $26.4 |  | 1.0 - 1.75 years |  | 0.13% |  | 53.58% |  | —% |

[0001375365-20-000074:notes:84]
| June 30, 2020 |
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $28.39 |  | 1.25 - 2.0 years |  | 0.16% |  | 53.75% |  | —% |

[0001375365-20-000074:notes:85]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three months ended September 30, 2020 and 2019.

[0001375365-20-000074:notes:86]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three months ended September 30, 2020 and 2019.

[0001375365-20-000074:notes:87]
The following is a summary of the Company’s investment in an auction rate security as of September 30, 2020 and June 30, 2020 (in thousands):

[0001375365-20-000074:notes:88]
|  | September 30, 2020 and June 30, 2020 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179) |  |  | $ | 1,571 |  |

[0001375365-20-000074:notes:89]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three months ended September 30, 2020 and 2019.

[0001375365-20-000074:notes:90]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2020 and June 30, 2020, total debt of $36.0 million and $29.4 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.


## us-gaap:DebtDisclosureTextBlock

[0001375365-20-000074:notes:91]
Short-term and Long-term Debt
    Short-term debt obligations as of September 30, 2020 and June 30, 2020 consisted of the following (in thousands):

[0001375365-20-000074:notes:92]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,047 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 11,980 |  |  | 5,697 |  |
| Total debt | 36,027 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,047 |  |  | 23,704 |  |
| Debt, Non-current | $ | 11,980 |  |  | $ | 5,697 |  |

[0001375365-20-000074:notes:93]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-20-000074:notes:94]
Bank of America

[0001375365-20-000074:notes:95]
2018 Bank of America Credit Facility

[0001375365-20-000074:notes:96]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which was amended on May 12, 2020. The Company paid a fee of $0.7 million and entered into a third amendment of the 2018 Bank of America Credit Facility that extended the maturity of the credit facility to June 30, 2021 and changed certain terms of the original agreement. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Under the terms of the May 12, 2020 amendment of the 2018 Bank of America Credit Facility, in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-20-000074:notes:97]
As of September 30, 2020 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2020 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.5 million and $0.6 million as of September 30, 2020 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-20-000074:notes:98]
CTBC Bank

[0001375365-20-000074:notes:99]
CTBC Credit Facility

[0001375365-20-000074:notes:100]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade,

[0001375365-20-000074:notes:101]
Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

[0001375365-20-000074:notes:102]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.0 million and $23.7 million at September 30, 2020 and June 30, 2020, respectively. As of September 30, 2020 and June 30, 2020, the Company did not have any outstanding borrowings under the CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.73% per annum as of September 30, 2020 and 0.63% per annum as of June 30, 2020. At September 30, 2020, the amount available for future borrowing under the CTBC Credit Facility was $26.0 million. As of September 30, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.3 million.

[0001375365-20-000074:notes:103]
2020 CTBC Term Loan Facility

[0001375365-20-000074:notes:104]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

[0001375365-20-000074:notes:105]
As of September 30, 2020 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $12.0 million and $5.7 million, respectively. The interest rate for these loans were 0.45% per annum as of September 30, 2020 and June 30, 2020. The net book value of the property serving as collateral as of September 30, 2020 was $17.1 million. As of September 30, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-20-000074:notes:106]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2020 and 2019 were as follows (in thousands):

[0001375365-20-000074:notes:107]
|  |  | Three Months EndedSeptember 30, |  |  |
|  |  | 2020 | 2019 |  |  |
| Operating lease expense (including expense for lease agreements with related parties of $347 and $365 for the three months ended September 30, 2020 and 2019, respectively) |  | $ | 2,000 |  | $ | 1,709 |  |  |  |
| Cash payments for operating leases (including payments to related parties of $347 and $357 for the three months ended September 30, 2020 and, 2019, respectively) |  | $ | 1,966 |  | $ | 1,845 |  |  |  |

[0001375365-20-000074:notes:108]
During the three months ended September 30, 2020 and 2019, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable payments expensed in the three months ended September 30, 2020 and September 30, 2019 were immaterial.

[0001375365-20-000074:notes:109]
As of September 30, 2020, the weighted average remaining lease term for operating leases was 4.3 years and the weighted average discount rate was 3.5%. Future minimum lease payments under noncancelable operating lease arrangements as of September 30, 2020 were as follows (in thousands):

[0001375365-20-000074:notes:110]
| Fiscal Year: |  | Minimum lease payments |
| 2021 |  | $ | 5,857 |  |
| 2022 |  | 6,492 |  |
| 2023 |  | 4,933 |  |
| 2024 |  | 4,267 |  |
| 2025 |  | 4,354 |  |
| 2026 and beyond |  | 993 |  |
| Total future lease payments |  | $ | 26,896 |  |
| Less: Imputed interest |  | (1,977) |  |
| Present value of operating lease liabilities |  | $ | 24,919 |  |

[0001375365-20-000074:notes:111]
As of September 30, 2020, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-20-000074:notes:112]
The Company has entered into lease agreements with related parties.  See Note 8, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-20-000074:notes:113]
Related Party Transactions The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and 
Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-20-000074:notes:114]
Dealings with Ablecom

[0001375365-20-000074:notes:115]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-20-000074:notes:116]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 93.6% and 92.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-20-000074:notes:117]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-20-000074:notes:118]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $11.1 million and $23.2 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-20-000074:notes:119]
Dealings with Compuware

[0001375365-20-000074:notes:120]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-20-000074:notes:121]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-20-000074:notes:122]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these

[0001375365-20-000074:notes:123]
materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-20-000074:notes:124]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-20-000074:notes:125]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $21.9 million and $45.7 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-20-000074:notes:126]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2020 and 2019, are as follows (in thousands):

[0001375365-20-000074:notes:127]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 26,324 |  |  | $ | 33,120 |  |  |  |  |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 13,299 |  |  | $ | 5,547 |  |  |  |  |  |
| Purchases (1) | 38,927 |  |  | 33,316 |  |  |  |  |  |

[0001375365-20-000074:notes:128]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-20-000074:notes:129]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2020 and 2019.

[0001375365-20-000074:notes:130]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2020 and June 30, 2020 (in thousands):

[0001375365-20-000074:notes:131]
|  | September 30, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 2,164 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 24,901 |  |  | 40,056 |  |
| Other long-term liabilities (3) | 560 |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,130 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 33,421 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 108 |  |  | 186 |  |

[0001375365-20-000074:notes:132]
____________________________

[0001375365-20-000074:notes:133]
(1) Other receivables include receivables from vendors.

[0001375365-20-000074:notes:134]
(2) Includes current portion of operating lease liabilities.

[0001375365-20-000074:notes:135]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-20-000074:notes:136]
See Note 1, "Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-20-000074:notes:137]
Stock-based Compensation
Equity Incentive Plan

[0001375365-20-000074:notes:138]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "2020 Plan"). The maximum number of shares available under the 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the 2020 Plan. No other awards can be granted under the 2016 Plan. 7,246,000 shares of common stock remain reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the 2020 Plan.

[0001375365-20-000074:notes:139]
As of September 30, 2020, the Company had 4,593,009 authorized shares available for future issuance under the 2020 Plan.

[0001375365-20-000074:notes:140]
Share Repurchase Program

[0001375365-20-000074:notes:141]
On August 9, 2020, the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $30.0 million at market prices. The program is effective until December 31, 2020 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended September 30, 2020, 1,142,294 shares of common stock were repurchased for $30.0 million and the program ended. Repurchased shares were recorded as treasury shares in the Company's condensed consolidated balance sheet.

[0001375365-20-000074:notes:142]
[same as prior period, unchanged from 0001375365-20-000033:notes:88]

[0001375365-20-000074:notes:143]
[same as prior period, unchanged from 0001375365-20-000033:notes:89]

[0001375365-20-000074:notes:144]
[same as prior period, unchanged from 0001375365-20-000033:notes:90]

[0001375365-20-000074:notes:145]
[same as prior period, unchanged from 0001375365-20-000033:notes:91]

[0001375365-20-000074:notes:146]
[same as prior period, unchanged from 0001375365-20-000033:notes:92]

[0001375365-20-000074:notes:147]
[same as prior period, unchanged from 0001375365-20-000033:notes:93]

[0001375365-20-000074:notes:148]
The fair value of stock option grants for the three months ended September 30, 2020 and 2019 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-20-000074:notes:149]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Risk-free interest rate | 0.27 | % |  | 1.58 | % |  |  |  |  |
| Expected term | 5.98 years |  | 6.27 years |  |  |  |  |
| Dividend yield | — | % |  | — | % |  |  |  |  |
| Volatility | 50.43 | % |  | 50.04 | % |  |  |  |  |
| Weighted-average fair value | $ | 14.16 |  |  | $ | 8.72 |  |  |  |  |  |

[0001375365-20-000074:notes:150]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2020 and 2019 (in thousands):

[0001375365-20-000074:notes:151]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Cost of sales | $ | 503 |  |  | $ | 395 |  |  |  |  |  |
| Research and development | 3,702 |  |  | 3,130 |  |  |  |  |  |
| Sales and marketing | 517 |  |  | 436 |  |  |  |  |  |
| General and administrative | 2,448 |  |  | 1,093 |  |  |  |  |  |
| Stock-based compensation expense before taxes | 7,170 |  |  | 5,054 |  |  |  |  |  |
| Income tax impact | (1,955) |  |  | (1,143) |  |  |  |  |  |
| Stock-based compensation expense, net | $ | 5,215 |  |  | $ | 3,911 |  |  |  |  |  |

[0001375365-20-000074:notes:152]
As of September 30, 2020, $7.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.39 years, $39.7 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.56 years and $0.4 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.76 years.

[0001375365-20-000074:notes:153]
[same as prior period, unchanged from 0001375365-20-000033:notes:99]

[0001375365-20-000074:notes:154]
The following table summarizes stock option activity during the three months ended September 30, 2020 under all plans:

[0001375365-20-000074:notes:155]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  |  |  |  |
| Granted |  | 207,270 |  |  | $ | 30.43 |  |  |  |  |  |
| Exercised |  | (350,830) |  |  | $ | 14.31 |  |  |  |  |  |
| Forfeited/Cancelled |  | (21,357) |  |  | $ | 24.42 |  |  |  |  |  |
| Balance as of September 30, 2020 |  | 5,214,851 |  |  | $ | 20.14 |  |  | 4.20 |  |  |
| Options vested and exercisable at September 30, 2020 |  | 4,457,311 |  |  | $ | 19.67 |  |  | 3.43 |  |  |

[0001375365-20-000074:notes:156]
[same as prior period, unchanged from 0001375365-20-000033:notes:102]

[0001375365-20-000074:notes:157]
[same as prior period, unchanged from 0001375365-20-000033:notes:103]

[0001375365-20-000074:notes:158]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. 50% of the PRSUs vested at June 30, 2018 when performance conditions were achieved, while the remainder vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. As of September 30, 2020, an additional 45% of the PRSUs vested and 5% are expected to vest in the three months ended December 31, 2020, in accordance with the terms of the grant.

[0001375365-20-000074:notes:159]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units would vest in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019.

[0001375365-20-000074:notes:160]
The following table summarizes RSU and PRSU activity during the three months ended September 30, 2020 under all plans:

[0001375365-20-000074:notes:161]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2020 | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  | (1) |  | $ | 22.29 |  |
| Granted | 524,357 |  |  | $ | 29.97 |  |  | — |  |  |  | $ | — |  |
| Released | (211,519) |  |  | $ | 20.10 |  |  | (6,000) |  |  |  | $ | 27.10 |  |
| Forfeited | (57,081) |  |  | $ | 22.98 |  |  | — |  |  |  | $ | — |  |
| Balance as of September 30, 2020 | 2,023,784 |  |  | $ | 22.55 |  |  | 36,000 |  |  |  | $ | 21.49 |  |

[0001375365-20-000074:notes:162]
(1)Reflects the number of PRSUs that have been earned based on the achievement of performance metrics.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-20-000074:notes:163]
Income Taxes
    The Company recorded a provision for income taxes of $3.7 million and $8.6 million for the three months ended September 30, 2020 and 2019, respectively. The effective tax rate was 12.7% and 25.3% for the three months ended September 30, 2020 and 2019, respectively. The effective tax rate for the three months ended September 30, 2020 is lower than that for the three months ended September 30, 2019, primarily due to decrease in tax reserves for uncertain tax positions after settlement of certain tax audits, and increase in the tax benefit related to employees’ stock-based compensation.

[0001375365-20-000074:notes:164]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring does not have a material impact on the estimated annual effective tax rate.

[0001375365-20-000074:notes:165]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted. The CARES Act provides temporary relief from certain aspects of the 2017 Tax Reform Act that imposed limitations on the utilization of certain losses, interest expense deductions and alternative minimum tax credits and made a technical correction to the 2017 Tax Reform Act related to the depreciable life of qualified improvement property. The CARES Act does not have a material impact on the Company.

[0001375365-20-000074:notes:166]
As of September 30, 2020, the Company had gross unrecognized tax benefits of $30.5 million, of which, $14.1 million if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2020, there was a $3.3 million increase in gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2020, the Company had accrued $2.3 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-20-000074:notes:167]
[same as prior period, unchanged from 0001375365-20-000033:notes:218]

[0001375365-20-000074:notes:168]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment resulting in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in February 2020. In February 2020, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2019 and proposed a transfer pricing adjustment resulting in an additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of these adjustments on the income statement was offset by the release of previously unrecognized tax benefits related to the fiscal years audited in the periods in which the proposed adjustments were accepted.

[0001375365-20-000074:notes:169]
[same as prior period, unchanged from 0001375365-20-000033:notes:221]

[0001375365-20-000074:notes:170]
The federal statute of limitations remains open in general for tax years ended June 30, 2017 through 2020. Various states statutes of limitations remain open in general for tax years ended June 30, 2016 through 2020. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2015 through 2020. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.2 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-20-000074:notes:171]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  The Court has not set a new date for the motion to dismiss hearing, but expects the hearing will be set in late 2020 or early 2021 following completion of supplemental motion to dismiss briefing. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

[0001375365-20-000074:notes:172]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

[0001375365-20-000074:notes:173]
Other legal proceedings and indemnifications

[0001375365-20-000074:notes:174]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2020 and any prior periods.

[0001375365-20-000074:notes:175]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-20-000074:notes:176]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2020, these remaining noncancelable commitments were $119.7 million, including $33.1 million for related parties.

[0001375365-20-000074:notes:177]
Standby Letter of Credit— In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-20-000074:notes:178]
Segment Reporting
    The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-20-000074:notes:179]
[same as prior period, unchanged from 0001375365-20-000033:notes:234]

[0001375365-20-000074:notes:180]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| Long-lived assets: |  |  |  |
| United States | $ | 179,629 |  |  | $ | 178,812 |  |
| Asia | 59,095 |  |  | 51,605 |  |
| Europe | 3,128 |  |  | 3,368 |  |
|  | $ | 241,852 |  |  | $ | 233,785 |  |

[0001375365-20-000074:notes:181]
The Company’s revenue is presented on a disaggregated basis in Note 2, “Revenue,” by type of product and by geographical market.


## us-gaap:SubsequentEventsTextBlock

[0001375365-20-000074:notes:182]
Subsequent EventsOn October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190 (the “Derivative Action”).  The Company was also named as a nominal defendant.  The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.On October 31, 2020, the Company's Board of Directors approved a share repurchase program to repurchase shares of its common stock for up to $50 million at prevailing prices in the open market. The share repurchase program is effective until October 31, 2021 or until the maximum amount of common stock is repurchased, whichever occurs first.
