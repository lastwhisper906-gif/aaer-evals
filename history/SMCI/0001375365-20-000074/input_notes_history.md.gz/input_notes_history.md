# SMCI note change history — 0001375365-20-000033 → 0001375365-20-000074


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  The Court has not set a new date for the motion to dismiss hearing, but expects the hearing will be set in late 2020 or early 2021 following completion of supplemental motion to dismiss briefing. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.
  (was, 2020-05-11, similarity 0.7454):
[0001375365-20-000033:note_history:1]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

- added (2020-11-06):
[0001375365-20-000074:note_history:2]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

- changed (2020-11-06):
[0001375365-20-000074:note_history:3]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2020 and any prior periods.
  (was, 2020-05-11, similarity 0.9785):
[0001375365-20-000033:note_history:3]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2020 and any prior periods.

- changed (2020-11-06):
[0001375365-20-000074:note_history:4]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2020, these remaining noncancelable commitments were $119.7 million, including $33.1 million for related parties.
  (was, 2020-05-11, similarity 0.848):
[0001375365-20-000033:note_history:4]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2020, these remaining noncancelable commitments were $381.1 million, including $122.2 million for related parties.

- changed (2020-11-06):
[0001375365-20-000074:note_history:5]
Standby Letter of Credit— In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.
  (was, 2020-05-11, similarity 0.6093):
[0001375365-20-000033:note_history:5]
Standby Letter of Credit— In October 2019, Bank of America increased the value of a previously issued standby letter of credit from $3.2 million to $6.4 million to facilitate ongoing operations of the Company. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.

- removed (2020-11-06):
[0001375365-20-000033:note_history:6]
Commitments and Contingencies

- removed (2020-11-06):
[0001375365-20-000033:note_history:7]
SEC Matter— The Company has cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by the Company’s management, which irregularities were disclosed on August 31, 2015. In addition, the Company received subpoenas from the SEC in connection with the matters underlying its inability to timely file the Company's Form 10-K for the fiscal year ended June 30, 2017. The Company also received a subpoena from the SEC following the publication of a false and widely discredited news article in October 2018 concerning its products. The Company has cooperated fully to comply with these government requests. The Company has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Company will pay a penalty of $17.5 million. In addition, the Company’s Chief Executive Officer has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Chief Executive Officer will pay the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. As of March 31, 2020, the Company recorded a liability of $17.5 million for the Company’s potential SEC settlement included in general and administrative expenses and accrued liabilities in the condensed consolidated financial statements. The Chief Executive Officer’s potential payment of $2,122,000 to the Company is a contingent gain and will be recorded if and when it is realized. The Company and the Chief Executive Officer have not reached final resolutions of these matters with the SEC and the Company cannot predict when settlements, if finally agreed, would become final, nor whether any of the proposed terms may change in connection with final resolutions.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-11-06):
[0001375365-20-000074:note_history:8]
Summary of Significant Accounting Policies
Significant Accounting Policies and Estimates

- added (2020-11-06):
[0001375365-20-000074:note_history:9]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, Organization and Summary of Significant Accounting Policies, in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19') pandemic.

- changed (2020-11-06):
[0001375365-20-000074:note_history:10]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principals in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.
  (was, 2020-05-11, similarity 0.7425):
[0001375365-20-000033:note_history:10]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations.

- changed (2020-11-06):
[0001375365-20-000074:note_history:11]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.
  (was, 2020-05-11, similarity 0.7174):
[0001375365-20-000033:note_history:11]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

- added (2020-11-06):
[0001375365-20-000074:note_history:12]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- added (2020-11-06):
[0001375365-20-000074:note_history:13]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2020 and June 30, 2020, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $0.5 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2020-11-06):
[0001375365-20-000074:note_history:14]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with
  (was, 2020-05-11, similarity 0.6291):
[0001375365-20-000033:note_history:14]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2020 and 2019, respectively.

- added (2020-11-06):
[0001375365-20-000074:note_history:15]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2020. No impairment charge was recorded for the three months ended September 30, 2020 and 2019, respectively.

- added (2020-11-06):
[0001375365-20-000074:note_history:16]
The Company sold products worth $0.6 million and $22.1 million to the Corporate Venture in the three months ended September 30, 2020 and 2019, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture in the amounts of $2.3 million and $3.0 million as of September 30, 2020 and June 30, 2020, respectively, have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.6 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of September 30, 2020 and June 30, 2020, respectively.

- added (2020-11-06):
[0001375365-20-000074:note_history:17]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 22.0% and 28.7% of total purchases for the three months ended September 30, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for 9.8% and 9.7% of total cost of sales for the three months ended September 30, 2020 and 2019, respectively.

- changed (2020-11-06):
[0001375365-20-000074:note_history:18]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2020, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.
  (was, 2020-05-11, similarity 0.708):
[0001375365-20-000033:note_history:18]
Financial instruments that potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2020 and 2019. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2020, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

- added (2020-11-06):
[0001375365-20-000074:note_history:19]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments. Under this new guidance, a company is required to estimate credit losses on certain types of financial instruments using an expected-loss model, replacing the current incurred-loss model, and record the estimate through an allowance for credit losses, which results in more timely recognition of credit losses. The Company adopted this guidance on July 1, 2020 using the modified retrospective transition method, which requires a cumulative-effect adjustment, if any, to the opening balance of retained earnings to be recognized on the date of adoption with prior periods not restated. The adoption of the guidance had no material impact on the Company’s condensed consolidated financial statements as of July 1, 2020.

- added (2020-11-06):
[0001375365-20-000074:note_history:20]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three months ended September 30, 2020.

- changed (2020-11-06):
[0001375365-20-000074:note_history:21]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of September 30, 2020, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial.  See Note 5 below.
  (was, 2020-05-11, similarity 0.6193):
[0001375365-20-000033:note_history:21]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The adoption of the new guidance will simplify the disclosure of the fair value measurements for the Company's financial assets and liabilities.

- added (2020-11-06):
[0001375365-20-000074:note_history:22]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.

- changed (2020-11-06):
[0001375365-20-000074:note_history:23]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July
  (was, 2020-05-11, similarity 0.7742):
[0001375365-20-000033:note_history:23]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- added (2020-11-06):
[0001375365-20-000074:note_history:24]
1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its consolidated financial statements and disclosures.

- changed (2020-11-06):
[0001375365-20-000074:note_history:25]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.
  (was, 2020-05-11, similarity 0.7983):
[0001375365-20-000033:note_history:25]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. The LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility terminates on June 30, 2020 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statement disclosures, results of operations and financial position.

- removed (2020-11-06):
[0001375365-20-000033:note_history:26]
Organization and Summary of Significant Accounting Policies

- removed (2020-11-06):
[0001375365-20-000033:note_history:27]
Organization

- removed (2020-11-06):
[0001375365-20-000033:note_history:28]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

- removed (2020-11-06):
[0001375365-20-000033:note_history:29]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. Equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

- removed (2020-11-06):
[0001375365-20-000033:note_history:30]
Use of Estimates

- removed (2020-11-06):
[0001375365-20-000033:note_history:31]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, valuation and recognition of performance awards liability, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the coronavirus ("COVID-19") pandemic on our critical and significant accounting estimates, including assessment of collectibility of customer contracts, valuation of accounts receivable, provision for excess and obsolete inventory and impairment of long-lived assets. Collectibility of customer contracts assessment resulted in delaying revenue recognition of $3.4 million for certain orders shipped during the three months ended March 31, 2020.

- removed (2020-11-06):
[0001375365-20-000033:note_history:32]
Revenue Recognition

- removed (2020-11-06):
[0001375365-20-000033:note_history:33]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

- removed (2020-11-06):
[0001375365-20-000033:note_history:34]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2020-11-06):
[0001375365-20-000033:note_history:35]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns, with a corresponding decrease in revenue, and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs, with a corresponding decrease in cost of sales. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-11-06):
[0001375365-20-000033:note_history:36]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- removed (2020-11-06):
[0001375365-20-000033:note_history:37]
Contracts with multiple promised goods and services. Certain of the Company’s contracts contain multiple promised goods and services. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

- removed (2020-11-06):
[0001375365-20-000033:note_history:38]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

- removed (2020-11-06):
[0001375365-20-000033:note_history:39]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- removed (2020-11-06):
[0001375365-20-000033:note_history:40]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

- removed (2020-11-06):
[0001375365-20-000033:note_history:41]
Product Warranties

- removed (2020-11-06):
[0001375365-20-000033:note_history:42]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product

- removed (2020-11-06):
[0001375365-20-000033:note_history:43]
will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

- removed (2020-11-06):
[0001375365-20-000033:note_history:44]
Research and Development

- removed (2020-11-06):
[0001375365-20-000033:note_history:45]
Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $0.8 million and $2.0 million for the nine months ended March 31, 2020 and 2019, respectively. Such amounts recorded as a reduction of research and development expenses were not significant for the three months ended March 31, 2020 and 2019. During the three and nine months ended March 31, 2020, the Company also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

- removed (2020-11-06):
[0001375365-20-000033:note_history:46]
Inventories

- removed (2020-11-06):
[0001375365-20-000033:note_history:47]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of inventories based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

- removed (2020-11-06):
[0001375365-20-000033:note_history:48]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

- removed (2020-11-06):
[0001375365-20-000033:note_history:49]
Income Taxes

- removed (2020-11-06):
[0001375365-20-000033:note_history:50]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

- removed (2020-11-06):
[0001375365-20-000033:note_history:51]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

- removed (2020-11-06):
[0001375365-20-000033:note_history:52]
Stock-Based Compensation

- removed (2020-11-06):
[0001375365-20-000033:note_history:53]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock options and RSUs awards are recognized to expense on a straight-line basis over the requisite service period. PRSUs awards are recognized to expense using an accelerated method only when it is probable that any performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized as compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

- removed (2020-11-06):
[0001375365-20-000033:note_history:54]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

- removed (2020-11-06):
[0001375365-20-000033:note_history:55]
Leases

- removed (2020-11-06):
[0001375365-20-000033:note_history:56]
Recognition of leases for periods after the Company’s adoption of the new leasing standard as of July 1, 2019

- removed (2020-11-06):
[0001375365-20-000033:note_history:57]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

- removed (2020-11-06):
[0001375365-20-000033:note_history:58]
Operating Leases

- removed (2020-11-06):
[0001375365-20-000033:note_history:59]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

- removed (2020-11-06):
[0001375365-20-000033:note_history:60]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

- removed (2020-11-06):
[0001375365-20-000033:note_history:61]
Finance Leases

- removed (2020-11-06):
[0001375365-20-000033:note_history:62]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

- removed (2020-11-06):
[0001375365-20-000033:note_history:63]
Recognition of leases for periods prior to the Company’s adoption of the new leasing standard as of July 1, 2019

- removed (2020-11-06):
[0001375365-20-000033:note_history:64]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following was true at inception: (a) the present value of minimum lease payments met or exceeded 90% of the fair value of the asset, (b) the lease term was greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contained a bargain purchase option, or (d) title to the property transferred to the Company at the end of the lease. The Company recorded an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets were depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability was accounted for using the effective interest method.

- removed (2020-11-06):
[0001375365-20-000033:note_history:65]
Leases that were not classified as capital leases were accounted for as operating leases. Operating lease agreements that had tenant improvement allowances were evaluated for lease incentives. For leases that contained escalating rent payments, the Company recognized rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

- removed (2020-11-06):
[0001375365-20-000033:note_history:66]
Variable Interest Entities

- removed (2020-11-06):
[0001375365-20-000033:note_history:67]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

- removed (2020-11-06):
[0001375365-20-000033:note_history:68]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary with respect to either Ablecom or Compuware as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

- removed (2020-11-06):
[0001375365-20-000033:note_history:69]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2020 and 2019, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- removed (2020-11-06):
[0001375365-20-000033:note_history:70]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by a third party in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2020 and June 30, 2019, the Company's equity investment in the Corporate Venture was $0 and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheets. The Company's share of losses, net of taxes, of the Corporate Venture were $1.1 million and $0.4 million for the three months ended March 31, 2020 and 2019, respectively, and $1.1 million and $3.6 million for the nine months ended March 31, 2020 and 2019, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations. The Company does not have an obligation or commitment to share in losses of the Corporate Venture above its investment amounts and will discontinue equity method accounting if the investment carrying value is below zero.

- removed (2020-11-06):
[0001375365-20-000033:note_history:71]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of March 31, 2020 and June 30, 2019, the Company had unamortized deferred gain balance of $2.5 million and $2.0 million, respectively, in accrued liabilities and $1.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- removed (2020-11-06):
[0001375365-20-000033:note_history:72]
In addition, the Company sells products to the Corporate Venture. The Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of each period end is eliminated and recorded as a reduction of the Company's investment balance in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company sold products worth $14.0 million and $13.7 million to the Corporate Venture in the three months ended March 31, 2020 and 2019, respectively, and $51.5 million and $35.2 million in the nine months ended March 31, 2020 and 2019, respectively. As of March 31, 2020, the Company recorded $0.5 million related to unrealized intra-entity profits in accrued liabilities in the Company’s condensed consolidated balance sheet. The Company had $10.4 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2020 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- removed (2020-11-06):
[0001375365-20-000033:note_history:73]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. The COVID-19 pandemic has already and may further disrupt our supply chain. One supplier accounted for 26.1% and 20.1% of total purchases for the three months ended March 31, 2020 and 2019, respectively, and 27.9% and 21.2% for the nine months ended March 31, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 9.4% and 9.9% of total cost of sales for the three months ended March 31, 2020 and 2019, respectively, and 9.8% and 9.4% for the nine months ended March 31, 2020 and 2019, respectively.

- removed (2020-11-06):
[0001375365-20-000033:note_history:74]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The new lease accounting guidance supersedes the existing guidance. Under the new lease accounting guidance, lessees are required to recognize assets and liabilities on the balance sheet for most leases and provide enhanced disclosures. Leases will continue to be classified as either finance or operating. The Company adopted the new lease accounting guidance on July 1, 2019 using the modified retrospective approach, and as a result did not restate prior comparative periods. The Company elected the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new lease accounting guidance its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease accounting guidance. In connection with the adoption of the new lease accounting guidance, the Company recorded a transition adjustment to recognize ROU assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, on July 1, 2019, primarily related to real estate leases. See Note 8, "Leases," for further details.

- removed (2020-11-06):
[0001375365-20-000033:note_history:75]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The Company adopted this guidance on July 1, 2019. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.

- removed (2020-11-06):
[0001375365-20-000033:note_history:76]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The Company adopted this guidance on July 1, 2019. The adoption of the guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.

- removed (2020-11-06):
[0001375365-20-000033:note_history:77]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company has started its accounting assessment of the adoption of the new standard, the process of establishing new accounting policies and evaluation of changes to systems and internal controls necessary to support the requirements of the new standard. The Company will continue to update its assessment as more information becomes available. The Company cannot reasonably estimate quantitative information related to the impact of the new guidance on its consolidated financial statements at this time.

- removed (2020-11-06):
[0001375365-20-000033:note_history:78]
In August 2018, the FASB issued authoritative guidance , Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company will adopt the new guidance on a prospective basis for any new hosting arrangement entered into after July 1, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:79]
Short-term and Long-term Debt
    Short-term debt obligations as of September 30, 2020 and June 30, 2020 consisted of the following (in thousands):
  (was, 2020-05-11, similarity 0.8276):
[0001375365-20-000033:note_history:79]
Short-term debt obligations as of March 31, 2020 and June 30, 2019 consisted of the following (in thousands):

- added (2020-11-06):
[0001375365-20-000074:note_history:80]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,047 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 11,980 |  |  | 5,697 |  |
| Total debt | 36,027 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,047 |  |  | 23,704 |  |
| Debt, Non-current | $ | 11,980 |  |  | $ | 5,697 |  |

- added (2020-11-06):
[0001375365-20-000074:note_history:81]
Activities under Revolving Lines of Credit and Term Loans

- added (2020-11-06):
[0001375365-20-000074:note_history:82]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which was amended on May 12, 2020. The Company paid a fee of $0.7 million and entered into a third amendment of the 2018 Bank of America Credit Facility that extended the maturity of the credit facility to June 30, 2021 and changed certain terms of the original agreement. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Under the terms of the May 12, 2020 amendment of the 2018 Bank of America Credit Facility, in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

- added (2020-11-06):
[0001375365-20-000074:note_history:83]
As of September 30, 2020 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2020 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.5 million and $0.6 million as of September 30, 2020 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2020-11-06):
[0001375365-20-000074:note_history:84]
CTBC Credit Facility
  (was, 2020-05-11, similarity 0.6415):
[0001375365-20-000033:note_history:84]
2018 Bank of America Credit Facility

- added (2020-11-06):
[0001375365-20-000074:note_history:85]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade,

- changed (2020-11-06):
[0001375365-20-000074:note_history:86]
Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.
  (was, 2020-05-11, similarity 0.6749):
[0001375365-20-000033:note_history:86]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (iii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

- added (2020-11-06):
[0001375365-20-000074:note_history:87]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.0 million and $23.7 million at September 30, 2020 and June 30, 2020, respectively. As of September 30, 2020 and June 30, 2020, the Company did not have any outstanding borrowings under the CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.73% per annum as of September 30, 2020 and 0.63% per annum as of June 30, 2020. At September 30, 2020, the amount available for future borrowing under the CTBC Credit Facility was $26.0 million. As of September 30, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.3 million.

- added (2020-11-06):
[0001375365-20-000074:note_history:88]
2020 CTBC Term Loan Facility

- added (2020-11-06):
[0001375365-20-000074:note_history:89]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

- added (2020-11-06):
[0001375365-20-000074:note_history:90]
As of September 30, 2020 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $12.0 million and $5.7 million, respectively. The interest rate for these loans were 0.45% per annum as of September 30, 2020 and June 30, 2020. The net book value of the property serving as collateral as of September 30, 2020 was $17.1 million. As of September 30, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

- removed (2020-11-06):
[0001375365-20-000033:note_history:91]
Short-term Debt

- removed (2020-11-06):
[0001375365-20-000033:note_history:92]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank | 10,000 |  |  | — |  |
| Total line of credit | 10,000 |  |  | 1,116 |  |
| CTBC Bank term loan | 23,158 |  |  | 22,531 |  |
| Total short-term debt | $ | 33,158 |  |  | $ | 23,647 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:93]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and was extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

- removed (2020-11-06):
[0001375365-20-000033:note_history:94]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020. The Company is in the process of negotiating an extension of its credit facility with Bank of America and expects this process will be completed by the end of May, 2020.

- removed (2020-11-06):
[0001375365-20-000033:note_history:95]
As of March 31, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2020 and June 30, 2019 were 3.63% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of March 31, 2020 and June 30, 2019. As of March 31, 2020, the Company's

- removed (2020-11-06):
[0001375365-20-000033:note_history:96]
available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- removed (2020-11-06):
[0001375365-20-000033:note_history:97]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

- removed (2020-11-06):
[0001375365-20-000033:note_history:98]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.2 million and $22.5 million at March 31, 2020 and June 30, 2019, respectively. As of March 31, 2020, the total outstanding borrowings under the 2019 CTBC Credit Facility revolving line of credit were $10.0 million in U.S. dollars. At June 30, 2019, the Company did not have any outstanding balance under the 2019 CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.91% per annum as of March 31, 2020 and 0.93% per annum as of June 30, 2019. At March 31, 2020, the amount available for future borrowing under the 2019 CTBC Credit Facility was $16.8 million. As of March 31, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.5 million.

- removed (2020-11-06):
[0001375365-20-000033:note_history:99]
Covenant Compliance

- removed (2020-11-06):
[0001375365-20-000033:note_history:100]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

- removed (2020-11-06):
[0001375365-20-000033:note_history:101]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended

- removed (2020-11-06):
[0001375365-20-000033:note_history:102]
June 30, 2017. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

- removed (2020-11-06):
[0001375365-20-000033:note_history:103]
On December 19, 2019, the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such, the Company complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

- removed (2020-11-06):
[0001375365-20-000033:note_history:104]
CTBC Bank

- removed (2020-11-06):
[0001375365-20-000033:note_history:105]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:106]
Short-term debt obligations as of September 30, 2020 and June 30, 2020 consisted of the following (in thousands):
  (was, 2020-05-11, similarity 0.9505):
[0001375365-20-000033:note_history:106]
Short-term debt obligations as of March 31, 2020 and June 30, 2019 consisted of the following (in thousands):

- added (2020-11-06):
[0001375365-20-000074:note_history:107]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,047 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 11,980 |  |  | 5,697 |  |
| Total debt | 36,027 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,047 |  |  | 23,704 |  |
| Debt, Non-current | $ | 11,980 |  |  | $ | 5,697 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:108]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank | 10,000 |  |  | — |  |
| Total line of credit | 10,000 |  |  | 1,116 |  |
| CTBC Bank term loan | 23,158 |  |  | 22,531 |  |
| Total short-term debt | $ | 33,158 |  |  | $ | 23,647 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:109]
Related Party Transactions The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and 
Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2020-05-11, similarity 0.7712):
[0001375365-20-000033:note_history:109]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2020, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

- changed (2020-11-06):
[0001375365-20-000074:note_history:110]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 93.6% and 92.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2020-05-11, similarity 0.9116):
[0001375365-20-000033:note_history:110]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.1% and 96.0% of the chassis included in the products sold by the Company during the three months ended March 31, 2020 and 2019, respectively; and approximately 95.3% and 95.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2020-11-06):
[0001375365-20-000074:note_history:111]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.
  (was, 2020-05-11, similarity 0.6919):
[0001375365-20-000033:note_history:111]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the

- changed (2020-11-06):
[0001375365-20-000074:note_history:112]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $11.1 million and $23.2 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2020-05-11, similarity 0.9931):
[0001375365-20-000033:note_history:112]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $60.0 million and $31.0 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2020-11-06):
[0001375365-20-000074:note_history:113]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these
  (was, 2020-05-11, similarity 0.8885):
[0001375365-20-000033:note_history:113]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

- added (2020-11-06):
[0001375365-20-000074:note_history:114]
materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

- changed (2020-11-06):
[0001375365-20-000074:note_history:115]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $21.9 million and $45.7 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2020-05-11, similarity 0.6378):
[0001375365-20-000033:note_history:115]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $111.2 million and $70.6 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2020-11-06):
[0001375365-20-000074:note_history:116]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2020 and 2019, are as follows (in thousands):
  (was, 2020-05-11, similarity 0.9385):
[0001375365-20-000033:note_history:116]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2020 and 2019, are as follows (in thousands):

- changed (2020-11-06):
[0001375365-20-000074:note_history:117]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 26,324 |  |  | $ | 33,120 |  |  |  |  |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 13,299 |  |  | $ | 5,547 |  |  |  |  |  |
| Purchases (1) | 38,927 |  |  | 33,316 |  |  |  |  |  |
  (was, 2020-05-11, similarity 0.7295):
[0001375365-20-000033:note_history:117]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 37,607 |  |  | $ | 29,372 |  |  | $ | 115,295 |  |  | $ | 110,290 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 7,503 |  |  | $ | 3,846 |  |  | $ | 19,456 |  |  | $ | 13,628 |  |
| Purchases (1) | 24,908 |  |  | 34,140 |  |  | 91,662 |  |  | 111,629 |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:118]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2020 and 2019.
  (was, 2020-05-11, similarity 0.9064):
[0001375365-20-000033:note_history:118]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2020 and 2019.

- changed (2020-11-06):
[0001375365-20-000074:note_history:119]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2020 and June 30, 2020 (in thousands):
  (was, 2020-05-11, similarity 0.9632):
[0001375365-20-000033:note_history:119]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2020 and June 30, 2019 (in thousands):

- changed (2020-11-06):
[0001375365-20-000074:note_history:120]
|  | September 30, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 2,164 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 24,901 |  |  | 40,056 |  |
| Other long-term liabilities (3) | 560 |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,130 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 33,421 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 108 |  |  | 186 |  |
  (was, 2020-05-11, similarity 0.9726):
[0001375365-20-000033:note_history:120]
|  | March 31, 2020 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 4,749 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 28,928 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 1,036 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 18,046 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 43,935 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 335 |  |  | — |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:121]
See Note 1, "Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.
  (was, 2020-05-11, similarity 0.9431):
[0001375365-20-000033:note_history:121]
See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.

- removed (2020-11-06):
[0001375365-20-000033:note_history:122]
Related Party Transactions

- removed (2020-11-06):
[0001375365-20-000033:note_history:123]
Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:124]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2020 and 2019, are as follows (in thousands):
  (was, 2020-05-11, similarity 0.9385):
[0001375365-20-000033:note_history:124]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2020 and 2019, are as follows (in thousands):

- changed (2020-11-06):
[0001375365-20-000074:note_history:125]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 26,324 |  |  | $ | 33,120 |  |  |  |  |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 13,299 |  |  | $ | 5,547 |  |  |  |  |  |
| Purchases (1) | 38,927 |  |  | 33,316 |  |  |  |  |  |
  (was, 2020-05-11, similarity 0.7295):
[0001375365-20-000033:note_history:125]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 37,607 |  |  | $ | 29,372 |  |  | $ | 115,295 |  |  | $ | 110,290 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 7,503 |  |  | $ | 3,846 |  |  | $ | 19,456 |  |  | $ | 13,628 |  |
| Purchases (1) | 24,908 |  |  | 34,140 |  |  | 91,662 |  |  | 111,629 |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:126]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2020 and 2019.
  (was, 2020-05-11, similarity 0.9064):
[0001375365-20-000033:note_history:126]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2020 and 2019.

- changed (2020-11-06):
[0001375365-20-000074:note_history:127]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2020 and June 30, 2020 (in thousands):
  (was, 2020-05-11, similarity 0.9632):
[0001375365-20-000033:note_history:127]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2020 and June 30, 2019 (in thousands):

- changed (2020-11-06):
[0001375365-20-000074:note_history:128]
|  | September 30, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 2,164 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 24,901 |  |  | 40,056 |  |
| Other long-term liabilities (3) | 560 |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,130 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 33,421 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 108 |  |  | 186 |  |
  (was, 2020-05-11, similarity 0.9726):
[0001375365-20-000033:note_history:128]
|  | March 31, 2020 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 4,749 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 28,928 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 1,036 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 18,046 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 43,935 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 335 |  |  | — |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:129]
(2) Includes current portion of operating lease liabilities.
(3) Represents non-current portion of operating lease liabilities.
  (was, 2020-05-11, similarity 0.6839):
[0001375365-20-000033:note_history:129]
(3) Represents non-current portion of operating lease liabilities.

- removed (2020-11-06):
[0001375365-20-000033:note_history:130]
(2) Includes current portion of operating lease liabilities.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-06):
[0001375365-20-000074:note_history:131]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617,788 |  |  |  |  | $ | 636,026 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 144,462 |  |  |  |  | 163,778 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 762,250 |  |  |  |  | $ | 799,804 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:132]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-05-11, similarity 0.8894):
[0001375365-20-000033:note_history:132]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2020 and 2019, of net sales by geographic region (in thousands):

- added (2020-11-06):
[0001375365-20-000074:note_history:133]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 496,086 |  |  | $ | 468,841 |  |  |  |  |  |
| Europe | 112,089 |  |  | 128,059 |  |  |  |  |  |
| Asia | 126,707 |  |  | 161,639 |  |  |  |  |  |
| Others | 27,368 |  |  | 41,265 |  |  |  |  |  |
|  | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:134]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 571,291 |  |  | $ | 592,783 |  |  | $ | 1,880,043 |  |  | $ | 2,161,321 |  |
| Subsystems and accessories | 201,117 |  |  | 150,716 |  |  | 563,112 |  |  | 484,805 |  |
| Total | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:135]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 422,872 |  |  | $ | 436,734 |  |  | $ | 1,419,117 |  |  | $ | 1,516,262 |  |
| Europe | 158,144 |  |  | 128,789 |  |  | 433,767 |  |  | 472,325 |  |
| Asia | 160,472 |  |  | 146,120 |  |  | 487,827 |  |  | 549,296 |  |
| Others | 30,920 |  |  | 31,856 |  |  | 102,444 |  |  | 108,243 |  |
|  | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:136]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2020 and 2019 (in thousands):

- removed (2020-11-06):
[0001375365-20-000033:note_history:137]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Indirect sales channel | $ | 445,980 |  |  | $ | 284,204 |  |  | $ | 1,292,472 |  |  | $ | 997,983 |  |
| Direct customers and OEMs | 326,428 |  |  | 459,295 |  |  | 1,150,683 |  |  | 1,648,143 |  |
| Total net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2020-11-06):
[0001375365-20-000033:note_history:138]
Revenue Recognition

- removed (2020-11-06):
[0001375365-20-000033:note_history:139]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

- removed (2020-11-06):
[0001375365-20-000033:note_history:140]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2020-11-06):
[0001375365-20-000033:note_history:141]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns, with a corresponding decrease in revenue, and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs, with a corresponding decrease in cost of sales. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-11-06):
[0001375365-20-000033:note_history:142]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- removed (2020-11-06):
[0001375365-20-000033:note_history:143]
Contracts with multiple promised goods and services. Certain of the Company’s contracts contain multiple promised goods and services. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

- removed (2020-11-06):
[0001375365-20-000033:note_history:144]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

- removed (2020-11-06):
[0001375365-20-000033:note_history:145]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- removed (2020-11-06):
[0001375365-20-000033:note_history:146]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001375365-20-000074:note_history:147]
Revenue
    Disaggregation of Revenue
  (was, 2020-05-11, similarity 0.8621):
[0001375365-20-000033:note_history:147]
Disaggregation of Revenue

- added (2020-11-06):
[0001375365-20-000074:note_history:148]
The Company disaggregates revenue by type of product and by geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

- added (2020-11-06):
[0001375365-20-000074:note_history:149]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617,788 |  |  |  |  | $ | 636,026 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 144,462 |  |  |  |  | 163,778 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 762,250 |  |  |  |  | $ | 799,804 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2020-11-06):
[0001375365-20-000074:note_history:150]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-05-11, similarity 0.8894):
[0001375365-20-000033:note_history:150]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2020 and 2019, of net sales by geographic region (in thousands):

- added (2020-11-06):
[0001375365-20-000074:note_history:151]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 496,086 |  |  | $ | 468,841 |  |  |  |  |  |
| Europe | 112,089 |  |  | 128,059 |  |  |  |  |  |
| Asia | 126,707 |  |  | 161,639 |  |  |  |  |  |
| Others | 27,368 |  |  | 41,265 |  |  |  |  |  |
|  | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |

- added (2020-11-06):
[0001375365-20-000074:note_history:152]
Starting July 1, 2020, the Company no longer separately discloses revenue by products sold to indirect sales channel partners or direct customers and original equipment manufacturers because management does not make business operational decisions based on this set of disaggregation so the disclosure is no longer material to investors.

- changed (2020-11-06):
[0001375365-20-000074:note_history:153]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s unconditional right to consideration for performance obligations either partially or fully completed.
  (was, 2020-05-11, similarity 0.7216):
[0001375365-20-000033:note_history:153]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Accounts receivable relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

- changed (2020-11-06):
[0001375365-20-000074:note_history:154]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2020, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $28.6 million.
  (was, 2020-05-11, similarity 0.8135):
[0001375365-20-000033:note_history:154]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and nine months ended March 31, 2020, which was included in the opening deferred revenue balance as of June 30, 2019, was $22.9 million and $71.6 million, respectively.

- added (2020-11-06):
[0001375365-20-000074:note_history:155]
Deferred revenue decreased $1.9 million during the three months ended September 30, 2020 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

- changed (2020-11-06):
[0001375365-20-000074:note_history:156]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2020 was $201.8 million. The Company expects to recognize approximately 52% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2020-05-11, similarity 0.9849):
[0001375365-20-000033:note_history:156]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2020 was approximately $205.5 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- added (2020-11-06):
[0001375365-20-000074:note_history:157]
Capitalized Contract Acquisition Costs and Fulfillment Cost

- added (2020-11-06):
[0001375365-20-000074:note_history:158]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

- added (2020-11-06):
[0001375365-20-000074:note_history:159]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.

- removed (2020-11-06):
[0001375365-20-000033:note_history:160]
Revenue

- removed (2020-11-06):
[0001375365-20-000033:note_history:161]
The Company disaggregates revenue by type of product, by geographical market, and by products sold to indirect sales channel partners or direct customers and original equipment manufacturers ("OEMs") that depict the nature, amount, and timing of revenue and cash flows. Service revenues are not a significant component of total revenue and are aggregated within the respective categories.

- removed (2020-11-06):
[0001375365-20-000033:note_history:162]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 571,291 |  |  | $ | 592,783 |  |  | $ | 1,880,043 |  |  | $ | 2,161,321 |  |
| Subsystems and accessories | 201,117 |  |  | 150,716 |  |  | 563,112 |  |  | 484,805 |  |
| Total | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:163]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 422,872 |  |  | $ | 436,734 |  |  | $ | 1,419,117 |  |  | $ | 1,516,262 |  |
| Europe | 158,144 |  |  | 128,789 |  |  | 433,767 |  |  | 472,325 |  |
| Asia | 160,472 |  |  | 146,120 |  |  | 487,827 |  |  | 549,296 |  |
| Others | 30,920 |  |  | 31,856 |  |  | 102,444 |  |  | 108,243 |  |
|  | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:164]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2020 and 2019 (in thousands):

- removed (2020-11-06):
[0001375365-20-000033:note_history:165]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Indirect sales channel | $ | 445,980 |  |  | $ | 284,204 |  |  | $ | 1,292,472 |  |  | $ | 997,983 |  |
| Direct customers and OEMs | 326,428 |  |  | 459,295 |  |  | 1,150,683 |  |  | 1,648,143 |  |
| Total net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-11-06):
[0001375365-20-000033:note_history:166]
Deferred revenue increased during the nine months ended March 31, 2020 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-11-06):
[0001375365-20-000074:note_history:167]
Subsequent EventsOn October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190 (the “Derivative Action”).  The Company was also named as a nominal defendant.  The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.On October 31, 2020, the Company's Board of Directors approved a share repurchase program to repurchase shares of its common stock for up to $50 million at prevailing prices in the open market. The share repurchase program is effective until October 31, 2021 or until the maximum amount of common stock is repurchased, whichever occurs first.
