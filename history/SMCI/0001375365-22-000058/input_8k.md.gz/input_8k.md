# SMCI 8-K — 0001375365-22-000053 filed 2022-05-03

## item codes, every 8-K on or before 2022-05-06

- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2022-05-06

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-22-000053:8k_2_02:1]
EX-99.1
2
exhibit991_20220331.htm
EX-99.1

[0001375365-22-000053:8k_2_02:2]
Document

[0001375365-22-000053:8k_2_02:3]
Exhibit 99.1

[0001375365-22-000053:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2022 Financial Results

[0001375365-22-000053:8k_2_02:5]
SAN JOSE, Calif. -- May 3, 2022 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced financial results for its third quarter of fiscal year 2022 ended March 31, 2022.

[0001375365-22-000053:8k_2_02:6]
Third Quarter Fiscal Year 2022 Highlights

[0001375365-22-000053:8k_2_02:7]
•Net sales of $1.36 billion versus $1.17 billion in the second quarter of fiscal year 2022 and $896 million in the same quarter of last year.

[0001375365-22-000053:8k_2_02:8]
•Gross margin of 15.5% versus 14.0% in the second quarter of fiscal year 2022 and 13.7% in the same quarter of last year.

[0001375365-22-000053:8k_2_02:9]
•Net income of $77 million versus $42 million in the second quarter of fiscal year 2022 and $18 million in the same quarter of last year.

[0001375365-22-000053:8k_2_02:10]
•Diluted net income per common share of $1.43 versus $0.78 in the second quarter of fiscal year 2022 and $0.35 in the same quarter of last year.

[0001375365-22-000053:8k_2_02:11]
•Non-GAAP diluted net income per common share of $1.55 versus $0.88 in the second quarter of fiscal year 2022 and $0.50 in the same quarter of last year.

[0001375365-22-000053:8k_2_02:12]
•Cash flow used in operations for the third quarter of fiscal year 2022 of $228 million and capital expenditures of $11 million.

[0001375365-22-000053:8k_2_02:13]
Non-GAAP gross margin for the third quarter of fiscal year 2022 was 15.6%, which adds back stock-based compensation expenses of $0.5 million. Non-GAAP diluted net income per common share for the third quarter of fiscal year 2022 was $1.55, which adds back stock-based compensation expenses of $7.7 million, litigation expenses of $2.2 million, and $2.0 million of litigation settlement costs net of the related tax effects.

[0001375365-22-000053:8k_2_02:14]
As of March 31, 2022, total cash and cash equivalents was $247 million and total bank debt was $547 million.

[0001375365-22-000053:8k_2_02:15]
“This is Supermicro’s fourth consecutive quarter of revenues exceeding a billion dollars and with a trailing four quarter revenue run rate of $4.6 billion, it gives me strong confidence that we are well ahead of our long-term targets,” said Charles Liang, Chairman and CEO.  “Our robust growth and EPS progress demonstrates the efficiency of our global operational

[0001375365-22-000053:8k_2_02:16]
leverage and our customers recognizing the value of our rack-scale Total IT Solutions in key market segments across AI, enterprise, cloud, edge/telco and others. Along with our product optimization, time to market advantage, and green computing cost-savings presented by our Total IT Solutions, our growth momentum should continue to fuel our emergence as the leading company in the industry in the coming quarters and years ahead.”

[0001375365-22-000053:8k_2_02:17]
Business Outlook and Management Commentary

[0001375365-22-000053:8k_2_02:18]
For the fourth quarter of fiscal year 2022 ending June 30, 2022, the Company expects net sales of $1.4 billion to $1.48 billion, GAAP net income per diluted share of $1.45 to $1.64 and non-GAAP net income per diluted share of $1.51 to $1.69. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 17.4% and 19.4%, respectively, and a fully diluted share count of 54.3 million shares for GAAP and fully diluted share count of 55.7 million shares for non-GAAP. The outlook for Q4 of fiscal year 2022 GAAP net income per diluted share includes approximately $8.0 million in expected stock-based compensation expense and $1.0 million in other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000053:8k_2_02:19]
For fiscal year 2022 ending June 30, 2022, the Company raises its previous guidance of net sales from $4.2 billion to $4.6 billion to a new range of $4.96 billion to $5.04 billion, and raises its GAAP net income per diluted share of at least $2.77 to a new range of $4.16 to $4.35 and non-GAAP net income per diluted share of at least $3.20 to a new range of $4.53 to $4.71. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 16.5% and 18.7%, respectively, and a fully diluted share count of 53.6 million shares for GAAP and fully diluted share count of 55.1 million shares for non-GAAP. The outlook for fiscal year 2022 GAAP net income per diluted share includes approximately $39.0 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000053:8k_2_02:20]
Conference Call and Webcast Information

[0001375365-22-000053:8k_2_02:21]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its third quarter of fiscal year 2022.

[0001375365-22-000053:8k_2_02:22]
Those wishing to access the live webcast may use the following link:

[0001375365-22-000053:8k_2_02:23]
https://events.q4inc.com/attendee/634441043

[0001375365-22-000053:8k_2_02:24]
The conference call can be accessed by registering online at:

[0001375365-22-000053:8k_2_02:25]
https://conferencingportals.com/event/fIceWmPv

[0001375365-22-000053:8k_2_02:26]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-22-000053:8k_2_02:27]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-22-000053:8k_2_02:28]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-22-000053:8k_2_02:29]
Use of Non-GAAP Financial Measures

[0001375365-22-000053:8k_2_02:30]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, litigation expenses, litigation settlement costs and other expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-22-000053:8k_2_02:31]
About Super Micro Computer, Inc.

[0001375365-22-000053:8k_2_02:32]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-22-000053:8k_2_02:33]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-22-000053:8k_2_02:34]
Investor Relations Contact

[0001375365-22-000053:8k_2_02:35]
Nicole Noutsios

[0001375365-22-000053:8k_2_02:36]
email: ir@supermicro.com

[0001375365-22-000053:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000053:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-22-000053:8k_2_02:39]
(in thousands)

[0001375365-22-000053:8k_2_02:40]
(unaudited)

[0001375365-22-000053:8k_2_02:41]
|  | March 31, |  | June 30, |
|  | 2022 |  | 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 247,424 |  |  | $ | 232,266 |  |
| Accounts receivable, net of allowances | 679,785 |  |  | 463,834 |  |
| Inventories | 1,588,542 |  |  | 1,040,964 |  |
| Prepaid expenses and other current assets | 162,964 |  |  | 130,195 |  |
| Total current assets | 2,678,715 |  |  | 1,867,259 |  |
| Investment in equity investee | 4,778 |  |  | 4,578 |  |
| Property, plant and equipment, net | 282,319 |  |  | 274,713 |  |
| Deferred income taxes, net | 66,518 |  |  | 63,288 |  |
| Other assets | 38,847 |  |  | 32,126 |  |
| Total assets | $ | 3,071,177 |  |  | $ | 2,241,964 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 779,561 |  |  | $ | 612,336 |  |
| Accrued liabilities | 181,448 |  |  | 178,850 |  |
| Income taxes payable | 17,413 |  |  | 12,741 |  |
| Short-term debt | 403,045 |  |  | 63,490 |  |
| Deferred revenue | 114,688 |  |  | 101,479 |  |
| Total current liabilities | 1,496,155 |  |  | 968,896 |  |
| Deferred revenue, non-current | 115,063 |  |  | 100,838 |  |
| Long-term debt, net of debt issuance costs | 144,423 |  |  | 34,700 |  |
| Other long-term liabilities | 41,617 |  |  | 41,132 |  |
| Total liabilities | 1,797,258 |  |  | 1,145,566 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 471,088 |  |  | 438,012 |  |
| Accumulated other comprehensive income | 554 |  |  | 453 |  |
| Retained earnings | 802,101 |  |  | 657,760 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,273,743 |  |  | 1,096,225 |  |
| Noncontrolling interest | 176 |  |  | 173 |  |
| Total stockholders’ equity | 1,273,919 |  |  | 1,096,398 |  |
| Total liabilities and stockholders’ equity | $ | 3,071,177 |  |  | $ | 2,241,964 |  |

[0001375365-22-000053:8k_2_02:42]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000053:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-22-000053:8k_2_02:44]
(in thousands except per share amounts)

[0001375365-22-000053:8k_2_02:45]
(unaudited)

[0001375365-22-000053:8k_2_02:46]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,355,490 |  |  | $ | 895,881 |  |  | $ | 3,560,639 |  |  | $ | 2,488,437 |  |
| Cost of sales | 1,144,715 |  |  | 772,864 |  |  | 3,047,982 |  |  | 2,099,410 |  |
| Gross profit | 210,775 |  |  | 123,017 |  |  | 512,657 |  |  | 389,027 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 70,869 |  |  | 57,912 |  |  | 201,483 |  |  | 165,439 |  |
| Sales and marketing | 22,356 |  |  | 21,826 |  |  | 65,940 |  |  | 62,858 |  |
| General and administrative | 27,773 |  |  | 26,224 |  |  | 75,280 |  |  | 75,864 |  |
| Total operating expenses | 120,998 |  |  | 105,962 |  |  | 342,703 |  |  | 304,161 |  |
| Income from operations | 89,777 |  |  | 17,055 |  |  | 169,954 |  |  | 84,866 |  |
| Other (expense) income, net | 4,663 |  |  | 2,017 |  |  | 4,106 |  |  | (1,363) |  |
| Interest expense | (1,531) |  |  | (607) |  |  | (3,485) |  |  | (1,850) |  |
| Income before income tax provision | 92,909 |  |  | 18,465 |  |  | 170,575 |  |  | 81,653 |  |
| Income tax benefit (provision) | (16,192) |  |  | 227 |  |  | (27,116) |  |  | (8,541) |  |
| Share of income (loss) from equity investee, net of taxes | 255 |  |  | (264) |  |  | 882 |  |  | (409) |  |
| Net income | $ | 76,972 |  |  | $ | 18,428 |  |  | $ | 144,341 |  |  | $ | 72,703 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.49 |  |  | $ | 0.36 |  |  | $ | 2.82 |  |  | $ | 1.41 |  |
| Diluted | $ | 1.43 |  |  | $ | 0.35 |  |  | $ | 2.70 |  |  | $ | 1.35 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 51,708 |  |  | 50,553 |  |  | 51,269 |  |  | 51,465 |  |
| Diluted | 53,786 |  |  | 53,218 |  |  | 53,401 |  |  | 53,747 |  |

[0001375365-22-000053:8k_2_02:47]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-22-000053:8k_2_02:48]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of sales | $ | 460 |  |  | $ | 402 |  |  | $ | 1,378 |  |  | $ | 1,312 |  |
| Research and development | 4,141 |  |  | 3,328 |  |  | 12,124 |  |  | 10,369 |  |
| Sales and marketing | 504 |  |  | 503 |  |  | 1,517 |  |  | 1,517 |  |
| General and administrative | 2,636 |  |  | 3,261 |  |  | 8,913 |  |  | 7,919 |  |
| Stock-based compensation expense | $ | 7,741 |  |  | $ | 7,494 |  |  | $ | 23,932 |  |  | $ | 21,117 |  |

[0001375365-22-000053:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000053:8k_2_02:50]
SELECTED CASH FLOW INFORMATION

[0001375365-22-000053:8k_2_02:51]
(in thousands)

[0001375365-22-000053:8k_2_02:52]
(unaudited)

[0001375365-22-000053:8k_2_02:53]
|  | Nine Months EndedMarch 31, |
|  | 2022 |  | 2021 |
| Net cash (used in) provided by operating activities | $ | (415,658) |  |  | $ | 59,392 |  |
| Net cash used in investing activities | (35,257) |  |  | (44,627) |  |
| Net cash provided by (used in) financing activities | 466,365 |  |  | (48,445) |  |
| Effect of exchange rate fluctuations on cash | (304) |  |  | 362 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 15,146 |  |  | (33,318) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 233,449 |  |  | 212,390 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 248,595 |  |  | $ | 179,072 |  |

[0001375365-22-000053:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000053:8k_2_02:55]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000053:8k_2_02:56]
(in thousands except per share amounts)

[0001375365-22-000053:8k_2_02:57]
(unaudited)

[0001375365-22-000053:8k_2_02:58]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2022 |  |  | 2021 |  | 2022 |  | 2021 |
| GAAP GROSS PROFIT | $ | 210,775 |  |  |  | $ | 123,017 |  |  | $ | 512,657 |  |  | $ | 389,027 |  |
| Stock-based compensation | 460 |  |  |  | 402 |  |  | 1,378 |  |  | 1,312 |  |
| Other expenses | — |  |  |  | — |  |  | 295 |  |  | 20 |  |
| NON-GAAP GROSS PROFIT | $ | 211,235 |  |  |  | $ | 123,419 |  |  | $ | 514,330 |  |  | $ | 390,359 |  |
| GAAP GROSS MARGIN | 15.5 | % |  |  | 13.7 | % |  | 14.4 | % |  | 15.6 | % |
| Stock-based compensation expenses | 0.1 | % |  |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Other expenses | — | % |  |  | — | % |  | 0.0 | % |  | 0.0 | % |
| NON-GAAP GROSS MARGIN | 15.6 | % |  |  | 13.8 | % |  | 14.5 | % |  | 15.7 | % |
| GAAP OPERATING EXPENSE | $ | 120,998 |  |  |  | $ | 105,962 |  |  | $ | 342,703 |  |  | $ | 304,161 |  |
| Stock-based compensation | (7,281) |  |  |  | (7,092) |  |  | (22,554) |  |  | (19,805) |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | 2,122 |  |
| Litigation settlement costs | (2,000) |  |  |  | — |  |  | (2,000) |  |  | — |  |
| Special performance bonuses | — |  |  |  | (2,508) |  |  | (158) |  |  | (5,129) |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | (221) |  |
| Litigation expenses | (2,210) |  |  |  | (1,239) |  |  | (4,133) |  |  | (1,239) |  |
| NON-GAAP OPERATING EXPENSE | $ | 109,507 |  |  |  | $ | 95,123 |  |  | $ | 313,858 |  |  | $ | 279,889 |  |
| GAAP INCOME FROM OPERATIONS | $ | 89,777 |  |  |  | $ | 17,055 |  |  | $ | 169,954 |  |  | $ | 84,866 |  |
| Stock-based compensation | 7,741 |  |  |  | 7,494 |  |  | 23,932 |  |  | 21,117 |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | (2,122) |  |
| Litigation settlement costs | 2,000 |  |  |  | — |  |  | 2,000 |  |  | — |  |
| Special performance bonuses | — |  |  |  | 2,508 |  |  | 453 |  |  | 5,129 |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | 241 |  |
| Litigation expenses | 2,210 |  |  |  | 1,239 |  |  | 4,133 |  |  | 1,239 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 101,728 |  |  |  | $ | 28,296 |  |  | $ | 200,472 |  |  | $ | 110,470 |  |
| GAAP OPERATING MARGIN | 6.6 | % |  |  | 1.9 | % |  | 4.8 | % |  | 3.4 | % |
| Stock-based compensation | 0.6 | % |  |  | 0.9 | % |  | 0.7 | % |  | 0.8 | % |
| Executive SEC settlement | — | % |  |  | — | % |  | — | % |  | (0.1) | % |
| Litigation settlement costs | 0.1 | % |  |  | — | % |  | 0.1 | % |  | — | % |
| Special performance bonuses | — | % |  |  | 0.3 | % |  | 0.0 | % |  | 0.2 | % |
| Other expenses | — | % |  |  | — | % |  | — | % |  | 0.0 | % |
| Litigation expenses | 0.2 | % |  |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| NON-GAAP OPERATING MARGIN | 7.5 | % |  |  | 3.2 | % |  | 5.7 | % |  | 4.4 | % |
| GAAP TAX EXPENSE | $ | 16,192 |  |  |  | $ | (227) |  |  | $ | 27,116 |  |  | $ | 8,541 |  |
| Adjustments to tax provision | 3,415 |  |  |  | 2,473 |  |  | 9,584 |  |  | 5,633 |  |
| NON-GAAP TAX EXPENSE | $ | 19,607 |  |  |  | $ | 2,246 |  |  | $ | 36,700 |  |  | $ | 14,174 |  |
| GAAP NET INCOME | $ | 76,972 |  |  |  | $ | 18,428 |  |  | $ | 144,341 |  |  | $ | 72,703 |  |

[0001375365-22-000053:8k_2_02:59]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000053:8k_2_02:60]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000053:8k_2_02:61]
(in thousands except per share amounts)

[0001375365-22-000053:8k_2_02:62]
(unaudited)

[0001375365-22-000053:8k_2_02:63]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2022 |  |  | 2021 |  | 2022 |  | 2021 |
| Stock-based compensation | 7,741 |  |  |  | 7,494 |  |  | 23,932 |  |  | 21,117 |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | (2,122) |  |
| Special performance bonuses | — |  |  |  | 2,508 |  |  | 453 |  |  | 5,129 |  |
| Litigation settlement costs | 2,000 |  |  |  | — |  |  | 2,000 |  |  | — |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | 241 |  |
| Litigation expenses | 2,210 |  |  |  | 1,239 |  |  | 4,133 |  |  | 1,239 |  |
| Adjustments to tax provision | (3,415) |  |  |  | (2,473) |  |  | (9,584) |  |  | (5,633) |  |
| NON-GAAP NET INCOME | $ | 85,508 |  |  |  | $ | 27,196 |  |  | $ | 165,275 |  |  | $ | 92,674 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 1.49 |  |  |  | $ | 0.36 |  |  | $ | 2.82 |  |  | $ | 1.41 |  |
| Impact of Non-GAAP adjustments | 0.16 |  |  |  | 0.18 |  |  | 0.40 |  |  | 0.39 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 1.65 |  |  |  | $ | 0.54 |  |  | $ | 3.22 |  |  | $ | 1.80 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 1.43 |  |  |  | $ | 0.35 |  |  | $ | 2.70 |  |  | $ | 1.35 |  |
| Impact of Non-GAAP adjustments | 0.12 |  |  |  | 0.15 |  |  | 0.31 |  |  | 0.33 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 1.55 |  |  |  | $ | 0.50 |  |  | $ | 3.01 |  |  | $ | 1.68 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 51,708 |  |  |  | 50,553 |  |  | 51,269 |  |  | 51,465 |  |
| BASIC – NON-GAAP | 51,708 |  |  |  | 50,553 |  |  | 51,269 |  |  | 51,465 |  |
| DILUTED – GAAP | 53,786 |  |  |  | 53,218 |  |  | 53,401 |  |  | 53,747 |  |
| DILUTED – NON-GAAP | 55,194 |  |  |  | 54,525 |  |  | 54,831 |  |  | 55,185 |  |
