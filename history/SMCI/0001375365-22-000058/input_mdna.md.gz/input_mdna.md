# SMCI MD&A — 0001375365-22-000058


## mdna

[0001375365-22-000058:mdna:1]
[same as prior period, unchanged from 0001375365-22-000013:mdna:1]

[0001375365-22-000058:mdna:2]
[same as prior period, unchanged from 0001375365-22-000013:mdna:2]

[0001375365-22-000058:mdna:3]
[same as prior period, unchanged from 0001375365-22-000013:mdna:3]

[0001375365-22-000058:mdna:4]
[same as prior period, unchanged from 0001375365-22-000013:mdna:4]

[0001375365-22-000058:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended March 31, 2022 increased to $77.0 million from $18.4 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, NVIDIA Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc., Broadcom Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-22-000058:mdna:6]
[same as prior period, unchanged from 0001375365-22-000013:mdna:6]

[0001375365-22-000058:mdna:7]
The coronavirus (COVID-19) and its variants have continued to create volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders that govern the operations of businesses. We are an essential critical infrastructure (information technology) business under the relevant federal, state and county regulations. Our first priority is the safety of our workforce and we have therefore implemented numerous health precautions and work practices to be in compliance with the law and to operate in a safe manner.

[0001375365-22-000058:mdna:8]
We have continued to see ongoing demand for our IT solutions and do not have significant direct exposure to industries which have been impacted the greatest. The pandemic has created additional demand for many server applications, that support the global movement towards a digital economy. These applications include greater use of online transactions for everyday purchases by consumers of food, clothing, entertainment from gaming and video streaming, as well as tele-health, social networking, messaging, email, autonomous driving solutions and video conferencing companies.

[0001375365-22-000058:mdna:9]
We have actively managed our supply chain for potential shortage risk by building inventories of critical components required such as CPUs, memory, SSDs and GPUs to support our ability to fulfill customer orders. Our architecture, which is based on a “Building Block Solutions” design approach, has also assisted us during the pandemic, to qualify different components for compatibility with our systems to help us overcome some shortages.

[0001375365-22-000058:mdna:10]
Logistics has continued to be a challenge during this pandemic as the global transportation industry, and particularly ocean transportation, has been challenged by shortages of containers, laborers, truckers and crowded ports. Shipping by air, has been used more frequently despite that it is more expensive and there are fewer flights during the COVID-19 pandemic than there were previously. We have experienced increased costs in freight as well as direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect this trend to continue until the COVID-19 pandemic ends.

[0001375365-22-000058:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In June 2021, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2026 and, in March 2022, further negotiated an increase in the size of our credit facility with Bank of America from $200 million to $350 million. In July 2021, we replaced our prior credit facility and term loan facility with CTBC Bank, with a new facility for omnibus credit lines. In September 2021, we replaced our prior credit facility with E.SUN Bank, with new credit facility and term facility. In September 2021 and April 2022, we entered into a term loan facility and credit line, respectively, with Mega Bank which will be used to support our manufacturing activities (such as purchase of materials and components) and provide medium-term working capital. In October 2021, we entered into a credit facility with Chang Hwa Bank and in January 2022 we entered into a loan agreement with HSBC Bank which will both be used to support the growth of our Taiwan business. See “- Liquidity and Capital Resources – Other Factors Affecting Liquidity and Capital Resources.”

[0001375365-22-000058:mdna:12]
Our management team is focused on guiding our company through the ongoing challenges presented by COVID-19, including the emergence of any new variants. There are positive signs with the expiration of various COVID-19 mandates, vaccine availability and the rollout of boosters; however, with the possibility of the emergence of other new virus strains and vaccine supply constraints, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-22-000058:mdna:13]
[same as prior period, unchanged from 0001375365-22-000013:mdna:13]

[0001375365-22-000058:mdna:14]
The following is a summary of our financial highlights of the third quarter of fiscal year 2022:

[0001375365-22-000058:mdna:15]
•Net sales increased by 51.3% in the three months ended March 31, 2022 as compared to the three months ended March 31, 2021.

[0001375365-22-000058:mdna:16]
•Gross margin increased to 15.5% in the three months ended March 31, 2022 from 13.7% in the three months ended March 31, 2021.

[0001375365-22-000058:mdna:17]
•Operating expenses increased by 14.2% as compared to the three months ended March 31, 2021, and were equal to 8.9% and 11.8% of net sales in the three months ended March 31, 2022 and 2021, respectively.

[0001375365-22-000058:mdna:18]
•Effective tax rate increased to 17.4% in the three months ended March 31, 2022 from (1.2)% in the three months ended March 31, 2021.

[0001375365-22-000058:mdna:19]
[same as prior period, unchanged from 0001375365-22-000013:mdna:19]

[0001375365-22-000058:mdna:20]
[same as prior period, unchanged from 0001375365-22-000013:mdna:20]

[0001375365-22-000058:mdna:21]
[same as prior period, unchanged from 0001375365-22-000013:mdna:21]

[0001375365-22-000058:mdna:22]
[same as prior period, unchanged from 0001375365-22-000013:mdna:22]

[0001375365-22-000058:mdna:23]
[same as prior period, unchanged from 0001375365-22-000013:mdna:23]

[0001375365-22-000058:mdna:24]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.5 | % |  | 86.3 | % |  | 85.6 | % |  | 84.4 | % |
| Gross profit | 15.5 | % |  | 13.7 | % |  | 14.4 | % |  | 15.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.2 | % |  | 6.5 | % |  | 5.7 | % |  | 6.6 | % |
| Sales and marketing | 1.6 | % |  | 2.4 | % |  | 1.9 | % |  | 2.5 | % |
| General and administrative | 2.0 | % |  | 2.9 | % |  | 2.1 | % |  | 3.0 | % |
| Total operating expenses | 8.9 | % |  | 11.8 | % |  | 9.6 | % |  | 12.2 | % |
| Income from operations | 6.6 | % |  | 1.9 | % |  | 4.8 | % |  | 3.4 | % |
| Other (expense) income, net | 0.3 | % |  | 0.2 | % |  | 0.1 | % |  | (0.1) | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 6.9 | % |  | 2.1 | % |  | 4.8 | % |  | 3.3 | % |
| Income tax provision | (1.2) | % |  | — | % |  | (0.8) | % |  | (0.3) | % |
| Share of income (loss) from equity investee, net of taxes | — | % |  | — | % |  | — | % |  | — | % |
| Net income | 5.7 | % |  | 2.1 | % |  | 4.1 | % |  | 2.9 | % |

[0001375365-22-000058:mdna:25]
[same as prior period, unchanged from 0001375365-22-000013:mdna:25]

[0001375365-22-000058:mdna:26]
[same as prior period, unchanged from 0001375365-22-000013:mdna:26]

[0001375365-22-000058:mdna:27]
[same as prior period, unchanged from 0001375365-22-000013:mdna:27]

[0001375365-22-000058:mdna:28]
The following table presents net sales by product type for the three and nine months ended March 31, 2022 and 2021 (dollars in millions):

[0001375365-22-000058:mdna:29]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Server and storage systems | $ | 1,145.9 |  |  | $ | 693.3 |  |  | $ | 452.6 |  |  | 65.3 | % |  | $ | 2,981.8 |  |  | $ | 1,953.8 |  |  | $ | 1,028.0 |  |  | 52.6 | % |
| Percentage of total net sales | 84.5 | % |  | 77.4 | % |  |  |  |  |  | 83.7 | % |  | 78.5 | % |  |  |  |  |
| Subsystems and accessories | $ | 209.6 |  |  | $ | 202.5 |  |  | $ | 7.1 |  |  | 3.5 | % |  | $ | 578.9 |  |  | $ | 534.6 |  |  | $ | 44.3 |  |  | 8.3 | % |
| Percentage of total net sales | 15.5 | % |  | 22.6 | % |  |  |  |  |  | 16.3 | % |  | 21.5 | % |  |  |  |  |
| Total net sales | $ | 1,355.5 |  |  | $ | 895.9 |  |  | $ | 459.6 |  |  | 51.3 | % |  | $ | 3,560.7 |  |  | $ | 2,488.4 |  |  | $ | 1,072.3 |  |  | 43.1 | % |

[0001375365-22-000058:mdna:30]
[same as prior period, unchanged from 0001375365-22-000013:mdna:30]

[0001375365-22-000058:mdna:31]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:32]
The period-over-period increase in net sales of our server and storage systems was due to a 19.7% increase in the number of units of compute nodes sold and a 41.0% increase in the average selling price.

[0001375365-22-000058:mdna:33]
The period-over-period increase in net sales for our subsystems and accessories is only at 3.5% increase and this is primarily driven by an increase in the number of units sold and due to change in product mix, largely offset by lower pricing per unit.

[0001375365-22-000058:mdna:34]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:35]
The period-over-period increase in net sales of our server and storage systems was due to a 25.2% increase in the number of units of compute nodes sold and a 24.3% increase in the average selling price.

[0001375365-22-000058:mdna:36]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the number of units sold by 24.9% offset by a decrease in the average selling prices by 13.3%, driven by product mix.

[0001375365-22-000058:mdna:37]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2022 and 2021 (dollars in millions):

[0001375365-22-000058:mdna:38]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| United States | $ | 762.4 |  |  | $ | 499.1 |  |  | $ | 263.3 |  |  | 52.8 | % |  | $ | 1,961.6 |  |  | $ | 1,458.2 |  |  | $ | 503.4 |  |  | 34.5 | % |
| Percentage of total net sales | 56.2 | % |  | 55.7 | % |  |  |  |  |  | 55.1 | % |  | 58.6 | % |  |  |  |  |
| Asia | $ | 310.0 |  |  | $ | 207.2 |  |  | $ | 102.8 |  |  | 49.6 | % |  | $ | 857.2 |  |  | $ | 495.3 |  |  | $ | 361.9 |  |  | 73.1 | % |
| Percentage of total net sales | 22.9 | % |  | 23.1 | % |  |  |  |  |  | 24.1 | % |  | 19.9 | % |  |  |  |  |
| Europe | $ | 205.4 |  |  | $ | 162.3 |  |  | $ | 43.1 |  |  | 26.6 | % |  | $ | 600.6 |  |  | $ | 429.2 |  |  | $ | 171.4 |  |  | 39.9 | % |
| Percentage of total net sales | 15.2 | % |  | 18.1 | % |  |  |  |  |  | 16.9 | % |  | 17.2 | % |  |  |  |  |
| Others | $ | 77.7 |  |  | $ | 27.3 |  |  | $ | 50.4 |  |  | 184.6 | % |  | $ | 141.4 |  |  | $ | 105.7 |  |  | $ | 35.7 |  |  | 33.8 | % |
| Percentage of total net sales | 5.7 | % |  | 3.0 | % |  |  |  |  |  | 4.0 | % |  | 4.2 | % |  |  |  |  |
| Total net sales | $ | 1,355.5 |  |  | $ | 895.9 |  |  |  |  |  |  | $ | 3,560.6 |  |  | $ | 2,488.4 |  |  |  |  |  |

[0001375365-22-000058:mdna:39]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:40]
The period-over-period increase in net sales in the United States was primarily due to higher sales driven by higher server and storage systems unit volume, driven by increased sales in the East Coast region combined with higher average selling price. The period-over-period increase in net sales in Asia was due primarily to increased sales in China and Singapore. The increase of net sales in Europe was primarily due to higher sales in the Netherlands and Germany, partially offset by lower sales in Russia. The period-over-period increase in net sales in other countries was primarily due to higher sales in Brazil.

[0001375365-22-000058:mdna:41]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:42]
The period-over-period increase in net sales in the United States was primarily due to higher sales driven by higher server and storage systems unit volume, driven by increased sales in the East Coast region combined with higher average selling price. The period-over-period increase in net sales in Asia was due primarily to increased sales in China, Singapore, Taiwan and Korea. The period-over-period increase of net sales in Europe was primarily due to higher sales in Germany and the Netherlands. The period-over-period increase in net sales in other countries was primarily due to higher sales in Brazil and U.A.E., partially offset by lower sales in Mexico.

[0001375365-22-000058:mdna:43]
[same as prior period, unchanged from 0001375365-22-000013:mdna:43]

[0001375365-22-000058:mdna:44]
[same as prior period, unchanged from 0001375365-22-000013:mdna:44]

[0001375365-22-000058:mdna:45]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-22-000058:mdna:46]
Cost of sales and gross margin for the three and nine months ended March 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000058:mdna:47]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Cost of sales | $ | 1,144.7 |  |  | $ | 772.9 |  |  | $ | 371.8 |  |  | 48.1 | % |  | $ | 3,048.0 |  |  | $ | 2,099.4 |  |  | $ | 948.6 |  |  | 45.2 | % |
| Gross profit | $ | 210.8 |  |  | $ | 123.0 |  |  | $ | 87.8 |  |  | 71.4 | % |  | $ | 512.7 |  |  | $ | 389.0 |  |  | $ | 123.7 |  |  | 31.8 | % |
| Gross margin | 15.5 | % |  | 13.7 | % |  |  |  | 1.8 | % |  | 14.4 | % |  | 15.6 | % |  |  |  | (1.2) | % |

[0001375365-22-000058:mdna:48]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:49]
The period-over-period increase in cost of sales was primarily attributed to an increase of $342.4 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $15.8 million increase in freight costs, a $2.7 million increase in overhead costs and a $8.1 million increase in excess and obsolete inventory charges.

[0001375365-22-000058:mdna:50]
The period-over-period increase in the gross margin percentage was primarily due to sales price increases. Since the start of the COVID-19 pandemic, we have experienced an increase in costs of sales, logistics costs as well as direct labor costs as we incentivize our employees. For the quarter ended March 31, 2022, we were able to mitigate the impact of these higher costs by charging higher prices for our products and services.

[0001375365-22-000058:mdna:51]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:52]
The period-over-period increase in cost of sales was primarily attributed to an increase of $854.8 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $48.3 million increase in freight charges, a $19.6 million increase due to lower cost recovery of cost paid in prior periods, a $9.9 million increase in excess and obsolete inventory charges and a $7.2 million increase in overhead costs.

[0001375365-22-000058:mdna:53]
[same as prior period, unchanged from 0001375365-22-000013:mdna:50]

[0001375365-22-000058:mdna:54]
[same as prior period, unchanged from 0001375365-22-000013:mdna:54]

[0001375365-22-000058:mdna:55]
[same as prior period, unchanged from 0001375365-22-000013:mdna:55]

[0001375365-22-000058:mdna:56]
[same as prior period, unchanged from 0001375365-22-000013:mdna:56]

[0001375365-22-000058:mdna:57]
[same as prior period, unchanged from 0001375365-22-000013:mdna:57]

[0001375365-22-000058:mdna:58]
Operating expenses for the three and nine months ended March 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000058:mdna:59]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Research and development | $ | 70.9 |  |  | $ | 57.9 |  |  | $ | 13.0 |  |  | 22.5 | % |  | $ | 201.5 |  |  | $ | 165.4 |  |  | $ | 36.1 |  |  | 21.8 | % |
| Percentage of total net sales | 5.2 | % |  | 6.5 | % |  |  |  |  |  | 5.7 | % |  | 6.6 | % |  |  |  |  |
| Sales and marketing | $ | 22.4 |  |  | $ | 21.8 |  |  | $ | 0.6 |  |  | 2.8 | % |  | $ | 65.9 |  |  | $ | 62.9 |  |  | $ | 3.0 |  |  | 4.8 | % |
| Percentage of total net sales | 1.6 | % |  | 2.4 | % |  |  |  |  |  | 1.9 | % |  | 2.5 | % |  |  |  |  |
| General and administrative | $ | 27.8 |  |  | $ | 26.2 |  |  | $ | 1.6 |  |  | 6.1 | % |  | $ | 75.3 |  |  | $ | 75.9 |  |  | $ | (0.6) |  |  | (0.8) | % |
| Percentage of total net sales | 2.0 | % |  | 2.9 | % |  |  |  |  |  | 2.1 | % |  | 3.0 | % |  |  |  |  |
| Total operating expenses | $ | 121.0 |  |  | $ | 106.0 |  |  | $ | 15.0 |  |  | 14.2 | % |  | $ | 342.7 |  |  | $ | 304.2 |  |  | $ | 38.5 |  |  | 12.7 | % |
| Percentage of total net sales | 8.9 | % |  | 11.8 | % |  |  |  |  |  | 9.6 | % |  | 12.2 | % |  |  |  |  |

[0001375365-22-000058:mdna:60]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:61]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $10.7 million increase in personnel expenses due to salary increases and a higher headcount and $2.1 million lower non-recurring engineering ("'NRE") payments from certain suppliers and customers towards our development efforts.

[0001375365-22-000058:mdna:62]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $2.9 million increase in personnel expenses, offset by a $1.4 million increase in marketing development funds received and a $1.4 million decrease in advertising and other expenses.

[0001375365-22-000058:mdna:63]
General and administrative expenses. The period-over-period change in general and administrative expenses was primarily due to an increase of $1.5 million in compensation and other expenses, $2.5 million increase in professional fees and litigation settlement expenses, offset by $2.5 million decrease in expense relating to special performance awards.

[0001375365-22-000058:mdna:64]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:65]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $26.8 million increase in personnel expenses due to salary increases and a higher headcount, $5.8 million lower NRE payments from certain suppliers and customers towards our development efforts and a $2.5 million increase in product development costs.

[0001375365-22-000058:mdna:66]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $6.5 million increase in personnel expenses, offset by a $2.9 million increase in marketing development funds received and a $0.6 million decrease in advertising and other expenses.

[0001375365-22-000058:mdna:67]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $2.6 million in professional fees driven by lower expenses incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements and a $6.3 million decrease in expense from special performance awards, offset by a $4.1 million increase in legal and litigation settlement expenses and $4.2 million increase in compensation expenses and other expenses.

[0001375365-22-000058:mdna:68]
Interest and Other (Expense) Income, Net

[0001375365-22-000058:mdna:69]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-22-000058:mdna:70]
[same as prior period, unchanged from 0001375365-22-000013:mdna:70]

[0001375365-22-000058:mdna:71]
Interest and other (expense) income, net for the three and nine months ended March 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000058:mdna:72]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Other (expense) income, net | $ | 4.7 |  |  | $ | 2.0 |  |  | $ | 2.7 |  |  | 135.0 | % |  | $ | 4.1 |  |  | $ | (1.4) |  |  | $ | 5.5 |  |  | (392.9) | % |
| Interest expense | $ | (1.5) |  |  | $ | (0.6) |  |  | $ | (0.9) |  |  | 150.0 | % |  | $ | (3.5) |  |  | $ | (1.8) |  |  | $ | (1.7) |  |  | 94.4 | % |
| Interest and other (expense) income, net | $ | 3.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | 128.6 | % |  | $ | 0.6 |  |  | $ | (3.2) |  |  | $ | 3.8 |  |  | (118.8) | % |

[0001375365-22-000058:mdna:73]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:74]
The change of $1.8 million in interest and other (expense) income, net was primarily attributable to a $2.7 million increase in foreign exchange gain due to favorable currency fluctuations offset by a $0.9 million increase in interest expense due to increase in loan balances and interest rates.

[0001375365-22-000058:mdna:75]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:76]
The change of $3.8 million in interest and other (expense) income, net was primarily attributable to a $5.5 million increase in foreign exchange gain due to favorable currency fluctuations offset by a $1.7 million increase in interest expense due to increase in loan balances and interest rates.

[0001375365-22-000058:mdna:77]
[same as prior period, unchanged from 0001375365-22-000013:mdna:77]

[0001375365-22-000058:mdna:78]
[same as prior period, unchanged from 0001375365-22-000013:mdna:78]

[0001375365-22-000058:mdna:79]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000058:mdna:80]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Income tax provision | $ | 16.2 |  |  | $ | (0.2) |  |  | $ | 16.4 |  |  | (8,200.0) | % |  | $ | 27.1 |  |  | $ | 8.5 |  |  | $ | 18.6 |  |  | 218.8 | % |
| Percentage of total net sales | 1.2 | % |  | — | % |  |  |  |  |  | 0.8 | % |  | 0.3 | % |  |  |  |  |
| Effective tax rate | 17.4 | % |  | (1.2) | % |  |  |  |  |  | 15.9 | % |  | 10.5 | % |  |  |  |  |

[0001375365-22-000058:mdna:81]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:82]
The income tax provision and effective tax rate for the three months ended March 31, 2022 is higher than that for the three months ended March 31, 2021, primarily due to a significant increase in taxable income while the deductible expenses stayed the same as the same period for the prior year.

[0001375365-22-000058:mdna:83]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:84]
The income tax provision and effective tax rate for the nine months ended March 31, 2022 is higher than that for the nine months ended March 31, 2021, primarily due to a significant increase in the nine months taxable income and our forecast of annual taxable income, while the tax deductible expenses and R&D tax credit stayed the same as the same period for the prior year.

[0001375365-22-000058:mdna:85]
Share of Income (Loss) from Equity Investee, Net of Taxes

[0001375365-22-000058:mdna:86]
Share of income (loss) from equity investee, net of taxes represents the Company’s share of income from the Corporate Venture in which the Company has 30% ownership.

[0001375365-22-000058:mdna:87]
Share of income (loss) from equity investee, net of taxes for the three and nine months ended March 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000058:mdna:88]
|  | Three Months EndedMarch 31, |  | Change | Nine Months EndedMarch 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 0.3 |  |  | $ | (0.3) |  |  | $ | 0.6 |  |  | (200.0)% |  | $ | 0.9 |  |  | $ | (0.4) |  |  | $ | 1.3 |  |  | (325.0)% |
| Percentage of total net sales | 0.02 | % |  | — | % |  |  |  |  |  | 0.02 | % |  | — | % |  |  |  |  |

[0001375365-22-000058:mdna:89]
Comparison of Three Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:90]
The period-over-period increase of $0.6 million in share of income (loss) from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-22-000058:mdna:91]
Comparison of Nine Months Ended March 31, 2022 and 2021

[0001375365-22-000058:mdna:92]
The period-over-period increase of $1.3 million in share of income (loss) from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-22-000058:mdna:93]
[same as prior period, unchanged from 0001375365-22-000013:mdna:93]

[0001375365-22-000058:mdna:94]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as an increase in the need for working capital due to longer supply chain manufacturing and delivery times and funds received from the exercise of employee stock options. Our cash and cash equivalents were $247.4 million and $232.3 million as of March 31, 2022 and June 30, 2021, respectively. Our cash in foreign locations was $150.6 million and $152.6 million as of March 31, 2022 and June 30, 2021, respectively.

[0001375365-22-000058:mdna:95]
[same as prior period, unchanged from 0001375365-22-000013:mdna:95]

[0001375365-22-000058:mdna:96]
[same as prior period, unchanged from 0001375365-22-000013:mdna:96]

[0001375365-22-000058:mdna:97]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. The Company had $150.0 million of remaining availability under the share repurchase program as of March 31, 2022.

[0001375365-22-000058:mdna:98]
[same as prior period, unchanged from 0001375365-22-000013:mdna:98]

[0001375365-22-000058:mdna:99]
|  | Nine Months EndedMarch 31, |  | Change |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (415.7) |  |  | $ | 59.4 |  |  | $ | (475.1) |  |  |  |  |
| Net cash used in investing activities | $ | (35.3) |  |  | $ | (44.6) |  |  | $ | 9.3 |  |  |  |  |
| Net cash provided by (used in) financing activities | $ | 466.4 |  |  | $ | (48.4) |  |  | $ | 514.8 |  |  |  |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 15.1 |  |  | $ | (33.3) |  |  | $ | 48.4 |  |  |  |  |

[0001375365-22-000058:mdna:100]
[same as prior period, unchanged from 0001375365-22-000013:mdna:100]

[0001375365-22-000058:mdna:101]
Net cash provided by operating activities decreased by $475.1 million for the nine months ended March 31, 2022 as compared to the nine months ended March 31, 2021. The decrease was primarily due to an increase in net cash required for net working capital of $552.5 million to meet customer demand, support expected business growth and mitigate supply chain risk due to the COVID-19 pandemic environment and $8.5 million decrease in unrealized gain and loss. These decreases are partially offset by increases in provision for excess and obsolete inventories of $9.0 million and net income of $71.6 million. Since the beginning of the pandemic and resulting supply chain disruptions our management decided to increase all components of our inventory (finished goods, work in process and purchased parts and raw materials). This decision reflected our belief that we had opportunities to increase our net sales if we could mitigate the risks of being unable to satisfy customer demand because of these disruptions, including longer lead times. We expect disruption of the supply chain and longer lead times to continue for the foreseeable future and therefore expect to continue to carry larger amounts of inventory than we would if the supply chain were functioning more normally and predictably.

[0001375365-22-000058:mdna:102]
[same as prior period, unchanged from 0001375365-22-000013:mdna:102]

[0001375365-22-000058:mdna:103]
Net cash used in investing activities decreased by $9.3 million for the nine months ended March 31, 2022 as compared to the nine months ended March 31, 2021 as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-22-000058:mdna:104]
[same as prior period, unchanged from 0001375365-22-000013:mdna:104]

[0001375365-22-000058:mdna:105]
Net cash provided by financing activities for the nine months ended March 31, 2022 was $466.4 million while net cash used by financing activities for the nine months ended March 31, 2021 was $48.4 million. The change in cash flows from financing activities was primarily due to an increase of $402.3 million in proceeds from borrowings net of repayment, offset by a $117.9 million decrease in stock repurchases.

[0001375365-22-000058:mdna:106]
[same as prior period, unchanged from 0001375365-22-000013:mdna:106]

[0001375365-22-000058:mdna:107]
[same as prior period, unchanged from 0001375365-22-000013:mdna:107]

[0001375365-22-000058:mdna:108]
2018 Bank of America Credit Facility

[0001375365-22-000058:mdna:109]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and change provisions relating to payments and LIBOR replacement mechanics to secured overnight financing rate (“SOFR"). The obligations bear a base interest rate plus 0.5% to 1.5% based on the SOFR availability. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Prior to that, on June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026 and increase the maximum amount that the Company can request the facility be increased from $100 million to $150 million. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-22-000058:mdna:110]
As of March 31, 2022, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $241.5 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2022 and June 30, 2021 range from 1.50% to 1.54%. The balance of debt issuance costs outstanding as of March 31, 2022 and June 30, 2021 was $0.8 million and $0.5 million, respectively. The Company is in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of March 31, 2022, the Company's available borrowing capacity was $108.5 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-22-000058:mdna:111]
On March 23, 2022 (the “Effective Date”), the Company through its Taiwan subsidiary entered into an Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch (the “2022 Bank of America Credit Facility”), for an

[0001375365-22-000058:mdna:112]
amount not to exceed in aggregate $20.0 million. The interest rate will be quoted by Bank of America – Taipei Branch for each drawdown. As of March 31, 2022, there were no outstanding borrowings under this Bank of America Credit Facility.

[0001375365-22-000058:mdna:113]
[same as prior period, unchanged from 0001375365-22-000013:mdna:111]

[0001375365-22-000058:mdna:114]
[same as prior period, unchanged from 0001375365-22-000013:mdna:112]

[0001375365-22-000058:mdna:115]
The Company through its Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

[0001375365-22-000058:mdna:116]
On July 20, 2021 (the “Effective Date”), the Company through its Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million  U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million  U.S. dollar equivalents) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

[0001375365-22-000058:mdna:117]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-22-000058:mdna:118]
As of March 31, 2022 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $41.7 million and $34.7 million, respectively. The interest rates for these loans were 0.70% per annum as of March 31, 2022, and 0.45% as of June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $5.5 million on March 31, 2022. The interest rates for this loan was 0.90% per annum as of March 31, 2022. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

[0001375365-22-000058:mdna:119]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $0.0 million and $25.1 million at March 31, 2022 and June 30, 2021, respectively. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. The interest rate for the 2021 CTBC Credit Facility term loan was 0.75% per annum as of June 30, 2021. As of March 31, 2022 and June 30, 2021, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were $101.0 million and $18.0 million, respectively. The interest rates for these loans ranges from 0.94% to 1.40% per annum as of March 31, 2022 and 0.98% per annum as of June 30, 2021. As of March 31, 2022, the amount available for future borrowing under the 2021 CTBC Credit Facility was $4.0 million. As of March 31, 2022, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million. The financial covenants under the 2021 CTBC Credit Lines will be reviewed by CTBC Bank every six months on June 30 and December 31.

[0001375365-22-000058:mdna:120]
[same as prior period, unchanged from 0001375365-22-000013:mdna:118]

[0001375365-22-000058:mdna:121]
2021 E.SUN Bank Credit Facility

[0001375365-22-000058:mdna:122]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30.0 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility expired on September 18, 2021.

[0001375365-22-000058:mdna:123]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements to be reviewed on a yearly basis at fiscal year end.

[0001375365-22-000058:mdna:124]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of March 31, 2022, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $28.1 million and the interest rates for these loans were 1.245% per annum. As of March 31, 2022 and June 30, 2021, the amounts outstanding under the Import Loan were $23.0 million and $20.4 million, respectively. The interest rate for the quarter ended March 31, 2022 ranges from 1.09% to 1.33%. The interest rate for the quarter ended June 30, 2021 ranges from 1.00% to 1.29% per annum. At March 31, 2022, the amount available for future borrowing under the Import Loan was $7.0 million.

[0001375365-22-000058:mdna:125]
[same as prior period, unchanged from 0001375365-22-000013:mdna:124]

[0001375365-22-000058:mdna:126]
[same as prior period, unchanged from 0001375365-22-000013:mdna:125]

[0001375365-22-000058:mdna:127]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. The first drawdown date was on October 4, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranges from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of March 31, 2022, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $41.8 million and the interest rates ranged from 0.895% to 1.095% per annum.

[0001375365-22-000058:mdna:128]
Credit Agreement with Mega Bank

[0001375365-22-000058:mdna:129]
On April 25, 2022, the Company through its Taiwan subsidiary, entered into a $20.0 million (or foreign currency equivalent) (the “Credit Limit”) Omnibus Credit Authorization Agreement (the “Omnibus Credit Authorization Agreement”) with Mega Bank. The Omnibus Credit Authorization Agreement permits individual credit authorizations subject to specified drawdown conditions up to the Credit Limit (on a revolving basis) to be used as loans for the purchase of materials or supplies. During the loan period, the Company is required to maintain 100% direct or indirect share ownership of the Taiwan subsidiary.

[0001375365-22-000058:mdna:130]
Pursuant to the Omnibus Credit Authorization Agreement, the Taiwan subsidiary also entered into both a Credit Authorization Agreement (the “Credit Authorization Agreement”) and Credit Authorization Approval Notice (the “Credit Authorization Approval Notice”) with Mega Bank and associated branch of Mega Bank, respectively. Pursuant to such Agreement and Notice, Mega Bank permits the Taiwan subsidiary to make drawdowns up to the Credit Limit for short-term loans for material purchases with a tenor not to exceed 120 days on a revolving basis. Drawdowns under the Mega Bank facility may be made through March 2023. The interest rate for each individual credit authorization is adjusted according to the Mega Bank’s USD basic loan interest rate at the time of signing the agreement which was 0.90% per annum. Interest on such drawdowns is based upon TAIFX OFFER for six months plus 0.23% and divided by 0.946, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to the bank’s right of set off. The interest rate shall be adjusted once every month but shall not be lower than the USD basic loan interest rate plus 0.1%. If the loan involves the acceptance of bill of exchange, the Company would pay handling fee at the annual rate of 0.75% calculated based on the number of actual acceptance days.  The fee is paid in full upon acceptance and a minimum handling fee of NTD 400 is charged for each transaction. Amounts borrowed are otherwise unsecured, and the Credit Authorization Agreement has customary default provisions permitting Mega Bank to reduce the extension of credit, shorten the term for loan repayment or declare all of the amounts immediately due and payable. The Company is not a guarantor under the Credit Authorization Agreement or Credit Authorization Approval Notice.

[0001375365-22-000058:mdna:131]
[same as prior period, unchanged from 0001375365-22-000013:mdna:127]

[0001375365-22-000058:mdna:132]
Chang Hwa Bank Credit Facility

[0001375365-22-000058:mdna:133]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed. As of March 31, 2022, the total outstanding borrowings under the Chang Hwa Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $34.8 million and the interest rate is 1.05% per annum.

[0001375365-22-000058:mdna:134]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants.

[0001375365-22-000058:mdna:135]
[same as prior period, unchanged from 0001375365-22-000013:mdna:131]

[0001375365-22-000058:mdna:136]
HSBC Bank Credit Facility

[0001375365-22-000058:mdna:137]
On January 7, 2022 (the “HSBC Bank Effective Date”), the Company through its Taiwan subsidiary entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with the Taiwan affiliate of HSBC Bank (“HSBC Bank”).  The Loan Agreement provides for borrowings in the form of loans, export/import financings, overdrafts, commercial paper guaranties, and other types of drawdown instruments.  The Loan Agreement has customary default provisions permitting HSBC Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event its Taiwan subsidiary fails to make payment of sums under another agreement which permits acceleration of maturity of such indebtedness. The Company is not a guarantor of the Loan Agreement.

[0001375365-22-000058:mdna:138]
Terms for specific drawdown instruments issued under the Loan Agreement, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, may be set forth in Facility Letters (a “Facility Letter”) negotiated with the HSBC Bank. Under a Facility Letter entered into on the HSBC Bank Effective Date, the Taiwan subsidiary and the HSBC Bank have agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on the HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date.

[0001375365-22-000058:mdna:139]
As of March 31, 2022, the outstanding borrowings under the 2022 HSBC Bank Credit Facility revolving line of credit were $30.0 million. The interest rates for these loans were approximately 0.96% per annum as of March 31, 2022. As of March 31, 2022, there was no amount available for future borrowing under the 2022 HSBC Bank Credit Facility.

[0001375365-22-000058:mdna:140]
[same as prior period, unchanged from 0001375365-22-000013:mdna:135]

[0001375365-22-000058:mdna:141]
[same as prior period, unchanged from 0001375365-22-000013:mdna:136]

[0001375365-22-000058:mdna:142]
We intend to continue to focus our capital expenditures in fiscal year 2022 to support the growth of our operations. We anticipate our capital expenditures for the remainder of fiscal year 2022 will be approximately $10 to $15 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our information systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-22-000058:mdna:143]
[same as prior period, unchanged from 0001375365-22-000013:mdna:138]

[0001375365-22-000058:mdna:144]
[same as prior period, unchanged from 0001375365-22-000013:mdna:139]
