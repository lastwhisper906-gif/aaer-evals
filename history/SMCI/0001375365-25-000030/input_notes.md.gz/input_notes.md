# SMCI notes — 0001375365-25-000030


## us-gaap:SubsequentEventsTextBlock

[0001375365-25-000030:notes:1]
Note 14.               Subsequent Events


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-25-000030:notes:2]
Note 1.                 Organization and Summary of Significant Accounting Policies

[0001375365-25-000030:notes:3]
[same as prior period, unchanged from 0001375365-25-000014:notes:2]

[0001375365-25-000030:notes:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“U.S. GAAP”) and applicable rules and regulations of the Securities and Exchange Commission regarding interim financial reporting. Certain information and note disclosures normally included in the financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations. As such, the information included in this Quarterly Report on Form 10-Q should be read in conjunction with the consolidated financial statements and accompanying notes included in the Annual Report on Form 10-K for the fiscal year ended June 30, 2025, of Super Micro Computer, Inc., a Delaware corporation, and its consolidated entities (collectively, the “Company”). The condensed consolidated balance sheet as of June 30, 2025 included herein was derived from the audited financial statements as of that date but does not include all disclosures including notes required by U.S. GAAP.

[0001375365-25-000030:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial condition, results of operations, and cash flows for the periods presented. All intercompany balances and transactions have been eliminated. Interim results are not necessarily indicative of the results for the full year ending June 30, 2026.

[0001375365-25-000030:notes:6]
[same as prior period, unchanged from 0001375365-25-000014:notes:5]

[0001375365-25-000030:notes:7]
There have been no material changes to our significant accounting policies included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001375365-25-000030:notes:8]
Concentration of Credit Risk and Significant Customers

[0001375365-25-000030:notes:9]
Financial instruments that potentially subject us to a significant concentration of credit risk consist of cash and cash equivalents, restricted cash, and accounts receivable. Cash and cash equivalents are maintained with high-quality financial institutions, the composition and maturities of which are regularly monitored by management.

[0001375365-25-000030:notes:10]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

[0001375365-25-000030:notes:11]
[same as prior period, unchanged from 0001375365-25-000014:notes:14]

[0001375365-25-000030:notes:12]
|  | September 30, 2025 |  | June 30, 2025 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 29.5% |  | 33.4% |
| Customer B | * |  | 13.6% |
| Customer C | 19.7% |  | * |
| Customer D | 12.5% |  | * |

[0001375365-25-000030:notes:13]
[same as prior period, unchanged from 0001375365-25-000014:notes:16]

[0001375365-25-000030:notes:14]
[same as prior period, unchanged from 0001375365-25-000014:notes:17]

[0001375365-25-000030:notes:15]
Receivables Purchase Agreement

[0001375365-25-000030:notes:16]
On July 16, 2025, we entered into a Receivables Purchase Agreement (as amended, supplemented or otherwise modified from time to time, the “Receivables Purchase Agreement”), by and among, us, as seller and guarantor, MUFG Bank, Ltd. (“MUFG”), Crédit Agricole Corporate and Investment Bank, and certain other entities from time to time party thereto as purchasers (the “Purchasers”), and MUFG as administrative agent (in such capacity, the “Administrative Agent”).

[0001375365-25-000030:notes:17]
Pursuant to the Receivables Purchase Agreement, we may, subject to the terms and conditions set out therein, sell certain of our accounts receivable and related rights to the Purchasers (the “Purchased Receivables”). The Receivables Purchase Agreement provides for an uncommitted facility with an initial aggregate facility limit of $1,790.0 million. The Purchasers may elect in their sole direction to purchase eligible accounts receivable offered by us under the Receivables Purchase Agreement at the applicable purchase discount. The purchase price for any Purchased Receivable will be the net invoice amount of the Purchased Receivable, minus the applicable discount, which is set at Term SOFR (as defined in the Receivables Purchase Agreement) plus a specified discount assigned to each account debtor in the range of 1.15% - 2.80%, and calculated on the basis of a specified discount period. In the event the purchase of such Purchased Receivables is not characterized as a sale, we will be deemed to have granted a security interest in such Purchased Receivables and the proceeds thereof in favor of the Purchasers.

[0001375365-25-000030:notes:18]
Either us, the Administrative Agent, or the Required Purchasers (as defined in the Receivables Purchase Agreement) have the right to terminate the Receivables Purchase Agreement with 30 days’ prior written notice to the other party, or, if a Termination Event (as defined in the Receivables Purchase Agreement) shall have occurred and be continuing, the Receivables Purchase Agreement may be terminated by the Administrative Agent or the Required Purchasers immediately upon written notice to us.

[0001375365-25-000030:notes:19]
As of September 30, 2025 no receivables have been sold under the agreement.

[0001375365-25-000030:notes:20]
Accounting Pronouncements Recently Adopted

[0001375365-25-000030:notes:21]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the Board’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the Board’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this Update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.

[0001375365-25-000030:notes:22]
[same as prior period, unchanged from 0001375365-25-000014:notes:21]

[0001375365-25-000030:notes:23]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.

[0001375365-25-000030:notes:24]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements other than additional disclosures.

[0001375365-25-000030:notes:25]
In May 2025, the FASB issued ASU 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810): Determining the Accounting Acquirer in the Acquisition of a Variable Interest Entity, which revises current guidance for determining the accounting acquirer for a transaction effected primarily by exchanging equity interests in which the legal acquiree is a variable interest entity that meets the definition of a business. The amendments require that an entity consider the same factors that are currently required for determining which entity is the accounting acquirer in other acquisition transactions. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-25-000030:notes:26]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments–Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides all entities with a practical expedient and entities other than public business entities with an accounting policy election when applying the guidance in Topic 326, Financial Instruments–Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. The ASU is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2026. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-25-000030:notes:27]
Reclassification

[0001375365-25-000030:notes:28]
Certain prior period amounts have been reclassified to conform to the current period presentation. Such reclassifications did not result in changes to condensed consolidated balance sheets, statements of operations, or statements of cash flows.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001375365-25-000030:notes:29]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Percentage of total net sales |  |  |  |  |  |  |  |
| Customer A | 11.6% |  | 20.8% |  |  |  |  |
| Customer B | * |  | 28.7% |  |  |  |  |
| Customer C | * |  | 11.9% |  |  |  |  |
| Customer D | 17.3% |  | * |  |  |  |  |

[0001375365-25-000030:notes:30]
^The customer references of A-D above may represent different customers than those reported in a previous period.
*Below 10%


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-25-000030:notes:31]
Note 2.                 Segment Information

[0001375365-25-000030:notes:32]
We operate in one operating segment that develops and provides high-performance server solutions based upon an innovative, modular and open-standard architecture. Our Chief Executive Officer is the chief operating decision maker (“CODM”) and is responsible for assessing our performance. Our organizational structure is based on functional lines, with department heads and shared resources reporting either directly to the CODM or to a direct report of the CODM. The CODM reviews financial information presented on a consolidated basis and uses net income for purposes of evaluating financial performance and making operating decisions for us.

[0001375365-25-000030:notes:33]
The CODM reviews significant operating expenses as components of net income, including research and development expenses, sales and marketing expenses, and general and administrative expenses, which are each separately disclosed and presented in the condensed consolidated statements of operations.

[0001375365-25-000030:notes:34]
Additionally, the CODM reviews significant segment expenses including the net excess and obsolete inventory write-down, recorded to cost of sales, which is separately disclosed in Note 6, “Balance Sheet Components”, and stock-based compensation, which is separately disclosed in Note 11, “Stock-based Compensation and Stockholders’ Equity” in the notes to the condensed consolidated financial statements.

[0001375365-25-000030:notes:35]
The measure of segment assets is reported on the condensed consolidated balance sheets as total consolidated assets. The accounting policies of our consolidated segment are the same as those described in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001375365-25-000030:notes:36]
Disaggregation of Revenue

[0001375365-25-000030:notes:37]
Total revenue recognized from all service and software for the three months ended September 30, 2025 and 2024 was  $87.6 million and $95.8 million, respectively. Of this, revenue related to services recognized over time ratably over the contract term was $71.9 million and $50.1 million for the three months ended September 30, 2025 and 2024, respectively.

[0001375365-25-000030:notes:38]
International net sales are based on the country to which the products were shipped. The following is a summary of net sales by geographic region (in thousands):

[0001375365-25-000030:notes:39]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | % of Total |  | 2024 |  | % of Total |  |  |  |  |
| United States | $ | 1,834,477 |  |  | 36.6 | % |  | $ | 4,241,349 |  |  | 71.4 | % |  |  |  |  |
| Malaysia | 1,115,149 |  |  | 22.2 | % |  | 222,585 |  |  | 3.7 | % |  |  |  |  |
| Indonesia | 578,706 |  |  | 11.5 | % |  | 1,796 |  |  | — | % |  |  |  |  |
| Other (1) | 1,489,458 |  |  | 29.7 | % |  | 1,471,526 |  |  | 24.9 | % |  |  |  |  |
| Total | $ | 5,017,790 |  |  | 100.0 | % |  | $ | 5,937,256 |  |  | 100.0 | % |  |  |  |  |

[0001375365-25-000030:notes:40]
(1) all other countries were individually less than 10%.

[0001375365-25-000030:notes:41]
Concentration of Customer Risk

[0001375365-25-000030:notes:42]
Contract Balances

[0001375365-25-000030:notes:43]
Generally, the payment terms of our offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables represent our unconditional right to consideration for performance obligations that are either partially or fully completed.

[0001375365-25-000030:notes:44]
Contract assets are rights to consideration in exchange for goods or services that we have transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to our condensed consolidated financial statements.

[0001375365-25-000030:notes:45]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede our satisfaction of the associated performance obligations. Our deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three months ended September 30, 2025, which was included in the opening deferred revenue balance as of June 30, 2025 of $731.4 million, was $182.8 million. Revenue recognized during the three months ended September 30, 2024, which was included in the opening deferred revenue balance as of June 30, 2024 of $416.4 million, was $68.2 million.

[0001375365-25-000030:notes:46]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-25-000030:notes:47]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. We apply the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services, that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to the remaining performance obligations as of September 30, 2025 was approximately $1,028.0 million. We expect to recognize approximately 58% of such value in the next 12 months, and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-25-000030:notes:48]
Note 3.                 Financial Instruments and Fair Value Measurements

[0001375365-25-000030:notes:49]
We classify our financial instruments, except for our investment in an auction rate security and other investments in privately held companies, within Level 1 or Level 2 in the fair value hierarchy because we use quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-25-000030:notes:50]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0001375365-25-000030:notes:51]
Cash and cash equivalents, certificates of deposit, investment in an auction rate security, and marketable securities, included in prepaid expenses and other current assets and other assets in the condensed consolidated balance sheets, are carried at fair value.

[0001375365-25-000030:notes:52]
The following table sets forth our financial instruments as of September 30, 2025 and June 30, 2025, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-25-000030:notes:53]
|  | As of September 30, 2025 |  | As of June 30, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 21 |  |  | $ | — |  |  | $ | — |  |  | $ | 21 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |
| Certificates of deposit | — |  |  | 507 |  |  | — |  |  | 507 |  |  | — |  |  | 519 |  |  | — |  |  | 519 |  |
| Marketable equity security | 14,213 |  |  | — |  |  | — |  |  | 14,213 |  |  | 6,239 |  |  | — |  |  | — |  |  | 6,239 |  |
| Available-for-Sale Investment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Auction rate security | — |  |  | — |  |  | 1,750 |  |  | 1,750 |  |  | — |  |  | — |  |  | 1,750 |  |  | 1,750 |  |
| Total assets | $ | 14,234 |  |  | $ | 507 |  |  | $ | 1,750 |  |  | $ | 16,491 |  |  | $ | 6,283 |  |  | $ | 519 |  |  | $ | 1,750 |  |  | $ | 8,552 |  |

[0001375365-25-000030:notes:54]
(1) All of the money market funds are included in cash and cash equivalents in the condensed consolidated balance sheets as of September 30, 2025 and June 30, 2025, respectively.

[0001375365-25-000030:notes:55]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in prepaid expenses and other current assets in the condensed consolidated balance sheets. The unrealized gains and losses of the investment are included in other income, net in our condensed consolidated statements of operations. An unrealized gain of $8.0 million and $1.4 million was recorded in other income, net in the condensed consolidated statements of operations for the three months ended September 30, 2025 and 2024, respectively.

[0001375365-25-000030:notes:56]
Our investment in an auction rate security is classified as an available for sale security within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2025 and June 30, 2025. See Note 1, “Organization and Summary of Significant Accounting Policies” in the notes to the consolidated financial statements of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a discussion of our policies regarding the fair value hierarchy. We are using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and using the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period, and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. We performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount would not result in a significantly higher or lower fair value measurement of the auction rate security as of September 30, 2025.

[0001375365-25-000030:notes:57]
On a quarterly basis, we also evaluate the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, current economic conditions, and reasonable economic forecasts that affect collectability. For the three months ended September 30, 2025 and 2024, the credit losses related to our investments were not material.

[0001375365-25-000030:notes:58]
There were no transfers between Level 1, Level 2, or Level 3 financial instruments during the three months ended September 30, 2025 and 2024.

[0001375365-25-000030:notes:59]
[same as prior period, unchanged from 0001375365-25-000014:notes:81]

[0001375365-25-000030:notes:60]
Accounts receivable, accounts payable, and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments. We estimate the fair value of outstanding debt, including our 3.50% Convertible Senior Notes due 2029 (“2029 Convertible Notes”), 2.25% Convertible Senior Notes due 2028 (“2028 Convertible Notes”), and 0.00% Convertible Senior Notes due 2030 (“2030 Convertible Notes”), for disclosure purposes on a recurring basis. Non-current accounts receivable, included in other assets in the condensed consolidated balance sheets, are carried at amortized cost, and bear interest at rates that approximate current market rates for similar credit. We believe the carrying amounts approximate fair value because there have been no significant changes in market rates or credit risk.

[0001375365-25-000030:notes:61]
As of September 30, 2025 and June 30, 2025, our total lines of credit and term loans of $125.8 million and $112.5 million, respectively, are reported at amortized cost. The outstanding debt was categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-25-000030:notes:62]
The estimated fair value as of September 30, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,744.5 million, $792.3 million, and $2,526.7 million, respectively. The estimated fair values as of June 30, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,801.9 million, $818.5 million, and $2,576.6 million. The estimated fair value of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes was determined based on level 2 inputs of quoted market prices.


## smci:NonMarketableEquityInvestmentsTextBlock

[0001375365-25-000030:notes:63]
Note 4.                 Non-marketable Equity Securities

[0001375365-25-000030:notes:64]
Our non-marketable equity securities, included in other assets in the condensed consolidated balance sheets, consist of investments in privately held companies without readily determinable fair values. The following table shows our non-marketable equity securities that were measured using the measurement alternative and equity method (in thousands):

[0001375365-25-000030:notes:65]
|  | September 30, 2025 |  | June 30, 2025 |
| Non-marketable equity securities: |  |  |  |
| Opening gross investment balance | $ | 122,217 |  |  | $ | 66,217 |  |
| Investment made during the period | — |  |  | 56,000 |
| Cumulative impairment adjustment | (23,600) |  |  | (11,600) |  |
| Total carrying value - before the adjustments under equity method | 98,617 |  |  | 110,617 |  |
| Securities under equity method - cumulative adjustment | (37) |  |  | — |  |
| Total carrying value | $ | 98,580 |  |  | $ | 110,617 |  |

[0001375365-25-000030:notes:66]
Our non-marketable equity securities include $92.5 million invested in an unrelated party (the "Sub-licensee") to which we have subleased the entire space in Vernon, California. The Sub-licensee does not meet the criteria of a related party. Additionally, the Sub licensee has been a customer of ours, and we concluded that equity investment agreements and sub-licensing agreements are separate from revenue contracts as all transactions have been recorded at the respective fair values. Please refer to Note 9, “Leases” for further discussion.
We recognized an impairment loss of $12.0 million during the three months ended September 30, 2025


## us-gaap:EarningsPerShareTextBlock

[0001375365-25-000030:notes:67]
Note 5.                 Net Income per Common Share

[0001375365-25-000030:notes:68]
The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2025 and 2024 (in thousands, except per share amounts):

[0001375365-25-000030:notes:69]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 168,285 |  |  | $ | 424,327 |  |  |  |  |  |
| Convertible notes interest charge, net of tax | 1,680 |  |  | 2,749 |  |  |  |  |  |
| Net income - diluted | $ | 169,965 |  |  | $ | 427,076 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 595,624 |  |  | 589,558 |  |  |  |  |  |
| Effect of dilutive convertible notes | 41,665 |  |  | 12,860 |  |  |  |  |  |
| Effect of dilutive securities | 25,946 |  |  | 36,730 |  |  |  |  |  |
| Weighted-average shares outstanding - diluted | 663,235 |  |  | 639,148 |  |  |  |  |  |
| Net income per common share - basic | $ | 0.28 |  |  | $ | 0.72 |  |  |  |  |  |
| Net income per common share - diluted | $ | 0.26 |  |  | $ | 0.67 |  |  |  |  |  |
| Anti-dilutive shares excluded from diluted net income per share: |  |  |  |  |  |  |  |
| Stock-based awards | 12,000 |  |  | 3,586 |  |  |  |  |  |
| Convertible notes | 32,138 |  |  | — |  |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-25-000030:notes:70]
Note 6.                 Balance Sheet Components

[0001375365-25-000030:notes:71]
[same as prior period, unchanged from 0001375365-25-000014:notes:50]

[0001375365-25-000030:notes:72]
Cash, Cash Equivalents, and Restricted Cash

[0001375365-25-000030:notes:73]
|  | September 30, 2025 |  | June 30, 2025 |
| Cash and cash equivalents | $ | 4,196,867 |  |  | $ | 5,169,911 |  |
| Restricted cash included in other assets | 2,388 |  |  | 2,390 |  |
| Total cash, cash equivalents and restricted cash | $ | 4,199,255 |  |  | $ | 5,172,301 |  |

[0001375365-25-000030:notes:74]
Inventories

[0001375365-25-000030:notes:75]
|  | September 30, 2025 |  | June 30, 2025 |
| Finished goods | $ | 3,877,754 |  |  | $ | 3,465,352 |  |
| Work in process | 1,259,183 |  |  | 674,613 |  |
| Purchased parts and raw materials | 593,065 |  |  | 540,410 |  |
| Total inventories | $ | 5,730,002 |  |  | $ | 4,680,375 |  |

[0001375365-25-000030:notes:76]
During the three months ended September 30, 2025 and 2024, we recorded write down adjustments for excess and obsolete inventory and lower of cost and net realizable value adjustments to cost of sales totaling $36.2 million and $9.1 million, respectively.

[0001375365-25-000030:notes:77]
Property, Plant, and Equipment, net

[0001375365-25-000030:notes:78]
|  | September 30, 2025 |  | June 30, 2025 |
| Land | $ | 172,202 |  |  | $ | 162,848 |  |
| Buildings | 186,781 |  |  | 182,466 |  |
| Machinery and equipment | 120,417 |  |  | 111,331 |  |
| Building and leasehold improvements | 123,447 |  |  | 121,665 |  |
| Furniture and fixtures | 39,147 |  |  | 36,268 |  |
| Software | 7,198 |  |  | 7,117 |  |
| Construction in progress | 1,275 |  |  | 1,038 |  |
| Property, plant, and equipment, gross | 650,467 |  |  | 622,733 |  |
| Accumulated depreciation and amortization | (129,755) |  |  | (118,245) |  |
| Property, plant, and equipment, net | $ | 520,712 |  |  | $ | 504,488 |  |

[0001375365-25-000030:notes:79]
Depreciation expense for the three months ended September 30, 2025 and 2024 was $12.1 million and $9.0 million, respectively.

[0001375365-25-000030:notes:80]
Other Assets

[0001375365-25-000030:notes:81]
|  | September 30, 2025 |  | June 30, 2025 |
| Non-current accounts receivable | $ | 76,355 |  |  | $ | 166,405 |  |
| Operating lease ROU asset | 375,968 |  |  | 293,692 |  |
| Long-term investments | 100,330 |  |  | 112,367 |  |
| Deferred service costs, non-current | 10,828 |  |  | 10,713 |  |
| Deposits | 4,528 |  |  | 4,980 |  |
| Restricted cash, non-current | 2,388 |  |  | 2,390 |  |
| Other | 16,337 |  |  | 14,324 |  |
| Total other assets | $ | 586,734 |  |  | $ | 604,871 |  |

[0001375365-25-000030:notes:82]
Accrued Liabilities

[0001375365-25-000030:notes:83]
|  | September 30, 2025 |  | June 30, 2025 |
| Accrued payroll and related expenses | $ | 82,674 |  |  | $ | 82,156 |  |
| Customer deposits | 47,031 |  |  | 260,131 |  |
| Accrued cooperative marketing expenses | 29,421 |  |  | 26,775 |  |
| Accrued warranty costs | 13,612 |  |  | 9,753 |  |
| Operating lease liability | 30,082 |  |  | 21,189 |  |
| Accrued professional fees | 5,752 |  |  | 8,098 |  |
| Accrued interest - convertible notes | 8,356 |  |  | 27,701 |  |
| Customer-related liabilities | 18,275 |  |  | 32,858 |  |
| Input tax payable | 19,555 |  |  | 39,161 |  |
| Other | 58,635 |  |  | 57,815 |  |
| Total accrued liabilities | $ | 313,393 |  |  | $ | 565,637 |  |

[0001375365-25-000030:notes:84]
Product Warranties

[0001375365-25-000030:notes:85]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Balance, beginning of the period | $ | 16,954 |  |  | $ | 17,815 |  |  |  |  |  |
| Provision for warranty | 16,902 |  |  | 11,534 |  |  |  |  |  |
| Costs utilized | (12,873) |  |  | (10,999) |  |  |  |  |  |
| Change in estimated liability for pre-existing warranties | 281 |  |  | (397) |  |  |  |  |  |
| Balance, end of the period | $ | 21,264 |  |  | $ | 17,953 |  |  |  |  |  |
| Current portion | $ | 13,612 |  |  | $ | 9,872 |  |  |  |  |  |
| Non-current portion | $ | 7,652 |  |  | $ | 8,081 |  |  |  |  |  |

[0001375365-25-000030:notes:86]
The portion of the accrued warranty costs expected to be incurred within the next 12 months is included within accrued liabilities, while the remaining balance is included within other long-term liabilities on the condensed consolidated balance sheets.


## us-gaap:DebtDisclosureTextBlock

[0001375365-25-000030:notes:87]
Note 7.                 Lines of Credit and Term Loans

[0001375365-25-000030:notes:88]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands):

[0001375365-25-000030:notes:89]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 17,705 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 9,836 |  |  | — |  |
| E.SUN Bank Credit Lines | 30,000 |  |  | 30,000 |  |
| First Bank Credit Lines | — |  |  | — |  |
| Total line of credit | 57,541 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 8,880 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,229 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,391 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 10,492 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 8,169 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 13,115 |  |  | 17,098 |  |
| Total term loans | 68,276 |  |  | 82,475 |  |
| Total lines of credit and term loans | 125,817 |  |  | 112,475 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Term loans, non-current | $ | 25,199 |  |  | $ | 37,415 |  |

[0001375365-25-000030:notes:90]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-25-000030:notes:91]
Available borrowings and interest rates as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):

[0001375365-25-000030:notes:92]
|  | September 30, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 167,295 |  |  | 2.11% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 14,071 |  |  | 1.88% - 4.74% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 30,000 |  |  | 2.02% - 5.12% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 20,000 |  |  | 2.03% - 5.26% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |

[0001375365-25-000030:notes:93]
See Note 7, “Lines of Credit and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.

[0001375365-25-000030:notes:94]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-25-000030:notes:95]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2026 |  | $ | 89,943 |  |
| 2027 |  | 18,770 |  |
| 2028 |  | 6,331 |  |
| 2029 |  | 5,621 |  |
| 2030 |  | 5,152 |  |
| Total lines of credit and term loans |  | $ | 125,817 |  |

[0001375365-25-000030:notes:96]
As of September 30, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 7, “Lines of Credit and Term Loans”.

[0001375365-25-000030:notes:97]
We entered into a new agreement during the three months ended September 30, 2025 with the following terms:

[0001375365-25-000030:notes:98]
Chang Hwa Bank

[0001375365-25-000030:notes:99]
Chang Hwa Bank Credit Lines

[0001375365-25-000030:notes:100]
On September 18, 2025 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “2025 Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the “New Credit Facility” in 2024 to renew a Loan Contract for a general working capital loan (the “General Working Capital Loan”). The credit limit thereunder has been adjusted to a total cap of NTD 1,000.0 million, which includes $20.0 million from the Chang Hwa Bank Credit Facility, a credit limit of NTD 300.0 million (together, the “CHB Credit Lines”), and the remaining balance of “Chang Hwa Bank Term Loan Facility”.

[0001375365-25-000030:notes:101]
Terms for specific drawdown instruments issued under the 2025 Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Chang Hwa Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”), with the interest rate thereunder based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%. Only the Loan Contract referred to in (b) is subject to renewal or re-execution, while the other agreements under (a) remain unchanged.

[0001375365-25-000030:notes:102]
First Bank

[0001375365-25-000030:notes:103]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. As of September 30, 2025, there were no outstanding borrowings under the First Bank credit line.

[0001375365-25-000030:notes:104]
Note 8.                 Convertible Notes

[0001375365-25-000030:notes:105]
The following table summarizes our convertible notes as of September 30, 2025:

[0001375365-25-000030:notes:106]
|  | Issuance Date |  | Principal (in millions) |  | Coupon Interest |  | Maturity |  | Conversion price |  | Carrying Value (in millions) |  | Effective Interest Rate |
| 2028 Convertible Notes | 2/20/2025 |  | $ | 700.0 |  |  | 2.25 | % |  | 7/15/2028 |  | $ | 61.06 |  |  | $ | 686.5 |  |  | 2.97 | % |
| 2029 Convertible Notes | 2/29/2024 |  | $ | 1,725.0 |  |  | 3.50 | % |  | 3/1/2029 |  | $ | 83.44 |  |  | $ | 1,705.1 |  |  | 3.86 | % |
| 2030 Convertible Notes | 6/23/2025 |  | $ | 2,300.0 |  |  | 0.00 | % |  | 6/15/2030 |  | $ | 55.20 |  |  | $ | 2,258.3 |  |  | 0.39 | % |

[0001375365-25-000030:notes:107]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of September 30, 2025.

[0001375365-25-000030:notes:108]
2029 Convertible Notes

[0001375365-25-000030:notes:109]
We issued $1,725.0 million of 0.00% Convertible Senior Notes due 2029 (“Original 2029 Notes”) in February 2024. On February 20, 2025, we executed privately negotiated subscription and supplemental indenture agreements to amend the Original 2029 Notes (the “2029 Amendments”). Key changes included (i) establishing a 3.50% annual coupon, payable semi-annually on March 1 and September 1 beginning September 2025, and (ii) adjusting the conversion rate to 11.9842 shares per $1,000 principal amount, equivalent to a conversion price of approximately $83.44 per share. All other material terms remained substantially unchanged.

[0001375365-25-000030:notes:110]
The amendment was accounted for as an extinguishment of the original debt and issuance of new debt under Accounting Standards Codification (“ASC”) 470-50, resulting in a $30.3 million extinguishment loss recorded in other income, net, during the quarter ended March 31, 2025. Debt issuance costs are amortized to interest expense using the effective interest method.

[0001375365-25-000030:notes:111]
Holders may convert their notes upon the occurrence of certain conditions, including: (1) if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) if the trading price of the notes is below 98% of the product of the stock price and conversion rate; (3) upon certain corporate events or distributions; (4) if we call the notes for redemption; or (5) at any time from and after September 1, 2028 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, at our option beginning March 1, 2027 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-25-000030:notes:112]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $19.9 million and $21.3 million, respectively. The interest expense for the three months ended September 30, 2025 totaled $16.4 million, including $1.4 million from the amortization of debt issuance costs. Interest expense for the three months ended September 30, 2024 totaled $1.5 million, all of which is amortization of issuance costs.

[0001375365-25-000030:notes:113]
In connection with the issuance, we entered into 2029 Capped Call Transactions with certain financial institutions to reduce potential dilution upon conversion or offset cash payments exceeding principal. The capped calls were initially structured with a $134.14 strike price and $195.10 cap price and were amended in February 2025 to reflect the updated conversion rate. The amended cap price is $94.17 per share. These instruments are equity-classified under ASC 815-40, and no incremental value was recorded upon amendment.

[0001375365-25-000030:notes:114]
2028 Convertible Notes

[0001375365-25-000030:notes:115]
On February 20, 2025, we issued $700.0 million aggregate principal amount of 2028 Convertible Notes under an indenture with U.S. Bank Trust Company, N.A., as trustee. The notes were issued concurrently with the amended 2029 Convertible Notes and are convertible, at our election, into cash, shares of common stock, or a combination of both. The initial conversion rate is 16.3784 shares per $1,000 principal amount, equivalent to a conversion price of approximately $61.06 per share.

[0001375365-25-000030:notes:116]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2028 Convertible Notes Indenture; (4) if we call the 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000030:notes:117]
Interest accrues from February 20, 2025, and is payable semi-annually on January 15 and July 15, beginning July 15, 2025. The notes mature on July 15, 2028, unless earlier converted, redeemed, or repurchased. Redemption may occur on or after March 1, 2026, if the stock price exceeds 150% of the conversion price for a specified period.

[0001375365-25-000030:notes:118]
The notes include customary provisions for conversion, redemption, and repurchase following a fundamental change. Upon such an event, holders may require us to repurchase all or part of their notes for cash equal to 100% of principal plus accrued interest, and the conversion rate may be increased for holders converting in connection with a qualifying corporate event or redemption.

[0001375365-25-000030:notes:119]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $13.5 million and $14.6 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $5.1 million, including $1.1 million from the amortization of debt issuance costs.

[0001375365-25-000030:notes:120]
2030 Convertible Notes

[0001375365-25-000030:notes:121]
On June 23, 2025, we issued $2,300 million aggregate principal amount of 2030 Convertible Notes, including the $300.0 million overallotment option. Net proceeds were approximately $2,256.0 million after issuance costs.

[0001375365-25-000030:notes:122]
The 2030 Convertible Notes are convertible at an initial rate of 18.1154 shares per $1,000 principal amount, equivalent to a conversion price of approximately $55.20 per share. Conversion prior to December 17, 2029 is permitted only if specified conditions are met (similar to those of the 2028 Convertible Notes and the 2029 Convertible Notes). After that date, the notes become convertible at any time up to two trading days before maturity.

[0001375365-25-000030:notes:123]
Holders may convert their 2030 Convertible Notes upon the occurrence of certain conditions, including: (1) during any calendar quarter commencing after the calendar quarter ending on September 30, 2025, if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon certain corporate events or distributions on our common stock, as described in the Indenture; (4) if we call the notes for redemption; or (5) at any time from and after December 17, 2029 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, beginning June 15, 2028 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-25-000030:notes:124]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $41.7 million and $43.9 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $2.2 million, all of which are amortization of debt issuance costs.

[0001375365-25-000030:notes:125]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-25-000030:notes:126]
Note 9.                 Leases

[0001375365-25-000030:notes:127]
We lease offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2025 and 2024 were as follows (in thousands):

[0001375365-25-000030:notes:128]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Operating lease expense (including expense for lease agreements with related parties of $204 and $165 for the three months ended September 30, 2025 and 2024, respectively) | $ | 13,031 |  |  | $ | 3,226 |  |  |  |  |  |
| Cash payments for operating leases (including payments to related parties of $220 and $165 for the three months ended September 30, 2025 and 2024, respectively) | $ | 9,136 |  |  | $ | 2,863 |  |  |  |  |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 90,542 |  |  | $ | 17,782 |  |  |  |  |  |

[0001375365-25-000030:notes:129]
During the three months ended September 30, 2025 and 2024, our costs related to short-term lease arrangements were immaterial. Variable lease payments expensed in the three months ended September 30, 2025 and 2024 were immaterial.

[0001375365-25-000030:notes:130]
ROU assets and lease liabilities are recorded in the condensed consolidated balance sheets as follows (in thousands):

[0001375365-25-000030:notes:131]
|  | September 30, 2025 |  | June 30, 2025 |  |  |  |  |
| Other assets | $ | 375,968 |  |  | $ | 293,692 |  |  |  |  |  |
| Accrued liabilities | $ | 30,082 |  |  | $ | 21,189 |  |  |  |  |  |
| Other long-term liabilities | 359,813 |  |  | 280,368 |  |  |  |  |  |
| Total lease liabilities | $ | 389,895 |  |  | $ | 301,557 |  |  |  |  |  |
| Weighted average remaining lease term | 9.2 years |  | 9.1 years |  |  |  |  |
| Weighted average discount rate (1) | 5.8 | % |  | 5.8 | % |  |  |  |  |

[0001375365-25-000030:notes:132]
(1) As the interest rate in the lease contract is typically not readily available, we estimate the incremental borrowing rate considering credit notching approach based on information available at lease commencement.

[0001375365-25-000030:notes:133]
In June 2024, we entered into a lease agreement for a 21 megawatt (“MW”) data center co-location space located in Vernon, California (the “Data Center Space”) that will expire on September 30, 2035. We do not have an option to extend (or to terminate) the lease. The lease agreement consists of three tranches, with the first tranche of 6 MW having commenced on January 24, 2025, the second tranche of 9 MW commenced on May 12, 2025, and the third tranche of 6 MW commenced on August 15, 2025. As of September 30, 2025, the ROU asset and lease liability arising from the commencement of the three tranches totaled $297.4 million. Variable lease payments not dependent on a rate or index associated with our leases are recognized when the event, activity, or circumstance in the lease agreement on which those payments are assessed as probable. Variable lease payments are presented as operating expenses in the condensed consolidated statements of operations.

[0001375365-25-000030:notes:134]
Simultaneously, we entered into a Sublicense agreement, the term of which coincides with our Data Center Space lease. We accounted for the lease as an operating lease and the Sublicense as a sublease under Accounting Standards Codification Topic 842, Leases. The Sublicense did not relieve our original obligation under the Data Center Space lease, and therefore we did not adjust the operating lease ROU asset and related liability. Sublicense income is recognized on a straight-line basis and the rental income is included in other income, net on the condensed consolidated statements of operations.

[0001375365-25-000030:notes:135]
Rental income is included in other income, net on the condensed consolidated statements of operations (in thousands):

[0001375365-25-000030:notes:136]
|  | Three Months Ended September 30, |
|  | 2025 |  | 2024 |
| Sublease income | $ | 8,133 |  |  | $ | — |  |

[0001375365-25-000030:notes:137]
As of September 30, 2025, the future total minimum Sublicense receipts expected to be received are as follows (in thousands):

[0001375365-25-000030:notes:138]
| Fiscal Year: |  | Future minimum Sublicense receipts |
| Remainder of 2026 |  | $ | 28,108 |  |
| 2027 |  | 38,443 |  |
| 2028 |  | 39,596 |  |
| 2029 |  | 40,784 |  |
| 2030 |  | 42,008 |  |
| 2031 and beyond |  | 246,229 |  |
| Total Sublicense receipts - Lessor |  | $ | 435,168 |  |

[0001375365-25-000030:notes:139]
Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of September 30, 2025 were as follows (in thousands):

[0001375365-25-000030:notes:140]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2026 |  | $ | 39,777 |  |
| 2027 |  | 54,488 |  |
| 2028 |  | 54,302 |  |
| 2029 |  | 54,812 |  |
| 2030 |  | 56,273 |  |
| 2031 and beyond |  | 255,103 |  |
| Total future lease payments |  | 514,755 |  |
| Less: Imputed interest |  | (124,860) |  |
| Present value of operating lease liabilities |  | 389,895 |  |
| Less: Current portion |  | 30,082 |  |
| Long-term portion of operating lease liabilities |  | $ | 359,813 |  |

[0001375365-25-000030:notes:141]
Related party leases

[0001375365-25-000030:notes:142]
We have entered into lease agreements with related parties. See Note 10, “Related Party Transactions” for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-25-000030:notes:143]
Note 10.               Related Party Transactions

[0001375365-25-000030:notes:144]
We have a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Both Ablecom and Compuware are a major contract manufacturer for us and Compuware is also a distributor of our products. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of September 30, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2025. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and we do not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director of ours, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-25-000030:notes:145]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of September 30, 2025 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.9 million and $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid.

[0001375365-25-000030:notes:146]
Dealings with Ablecom

[0001375365-25-000030:notes:147]
We have entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-25-000030:notes:148]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.6% and 96.8% of the chassis purchased by us during the three months ended September 30, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-25-000030:notes:149]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and we provide certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to us. For the components purchased from us, Ablecom sells the components back to us at a price equal to the price at which we sold the components to Ablecom. There is no revenue recognized by us from these transactions. We and Ablecom frequently review and negotiate the prices of the chassis we purchase from Ablecom. In addition to inventory purchases, we also incur other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-25-000030:notes:150]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on September 30, 2025 and June 30, 2025 were $50.1 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000030:notes:151]
Dealings with Compuware

[0001375365-25-000030:notes:152]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, and Australia. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

[0001375365-25-000030:notes:153]
We also have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We have extended a $65.0 million trade credit line with a net 60 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000030:notes:154]
Under these agreements, we outsource a portion of our design activities, a  significant part of our power supplies manufacturing and an immaterial portion of other components to Compuware. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to our specifications and further agree to build the tools needed to manufacture the products. We pay Compuware for the design and engineering services and further agrees to pay Compuware for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from third parties and uses these materials to manufacture the products and then sell those products to us. We and Compuware frequently review and negotiate the prices of the power supplies we purchase from Compuware.

[0001375365-25-000030:notes:155]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for us. We sell to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to us at a purchase price equal to the price at which we sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by us from these transactions. We and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products we purchase from Compuware. In addition to the inventory purchases, we also incur costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-25-000030:notes:156]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on September 30, 2025 and June 30, 2025 were $156.6 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-25-000030:notes:157]
Dealings with Leadtek Research Inc.

[0001375365-25-000030:notes:158]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, our authorized reseller. During the three months ended September 30, 2025, we engaged in transactions whereby we sold $0.3 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the three months ended September 30, 2024, we engaged in transactions in which it sold $0.1 million of servers to Leadtek and purchased $0.4 million of graphics cards from Leadtek.

[0001375365-25-000030:notes:159]
Dealings with Investment in a Corporate Venture

[0001375365-25-000030:notes:160]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture is 30% owned by us and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-25-000030:notes:161]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025.

[0001375365-25-000030:notes:162]
We sold products worth $2.8 million and $4.8 million to the Corporate Venture during three months ended September 30, 2025 and 2024, respectively, and our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2025 has been eliminated and have reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $1.8 million and less than $0.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2025 and June 30, 2025, respectively.

[0001375365-25-000030:notes:163]
Other Transactions

[0001375365-25-000030:notes:164]
For the three months ended September 30, 2025, and 2024, we had no and immaterial sales to and purchases from, respectively, Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Green Earth.

[0001375365-25-000030:notes:165]
For the three months ended September 30, 2025 and 2024, we had no transactions directly or indirectly to Aeon Lighting Technology Inc. (“Aeon Lighting”). Aeon Lighting is a company which is owned more than 10% by James Liang, a brother of our Chief Executive Officer. James Liang is also a director of Aeon Lighting and serves as the Chief Executive Officer of such entity. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Aeon Lighting.

[0001375365-25-000030:notes:166]
For the three months ended September 30, 2025, we had no sale or purchases transactions with Ampera, Inc. (“Ampera”). We represent approximately 33% on the board of directors as we have one board of director seat on a board of three. With the combination of our 11% equity interest and board representation, we have the ability to exercise significant influence over the operating and financial policies of Ampera. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Ampera.

[0001375365-25-000030:notes:167]
We had the following balances related to transactions with our related parties as of September 30, 2025 and June 30, 2025 (in thousands):

[0001375365-25-000030:notes:168]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2 |  |  | $ | 684 |  |  | $ | 53,062 |  |  | $ | 746 |  |  | $ | 55 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 36 |  |  | $ | 518 |  |  | $ | 52,517 |  |  | $ | 852 |  |  | $ | 402 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 1,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 177 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2,064 |  |  | $ | 1,202 |  |  | $ | 105,579 |  |  | $ | 1,598 |  |  | $ | 457 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

[0001375365-25-000030:notes:169]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.

[0001375365-25-000030:notes:170]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-25-000030:notes:171]
(3) Other long-term liabilities include non-current portion of lease liabilities.

[0001375365-25-000030:notes:172]
Our results from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

[0001375365-25-000030:notes:173]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 42 |  |  | $ | 69,841 |  |  | $ | 1,655 |  |  | $ | 828 |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 2 |  |  | $ | 137,507 |  |  | $ | 4,492 |  |  | $ | 1,862 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 5,874 |  |  | $ | 85,487 |  |  | $ | 149 |  |  | $ | 188 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 9,975 |  |  | $ | 102,117 |  |  | $ | 357 |  |  | $ | 380 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 2,768 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,827 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 267 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 71 |  |  | $ | 427 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 8,951 |  |  | $ | 155,328 |  |  | $ | 1,804 |  |  | $ | 1,016 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 14,875 |  |  | $ | 240,051 |  |  | $ | 4,849 |  |  | $ | 2,242 |  |  | $ | — |  |

[0001375365-25-000030:notes:174]
Our cash flow impact from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

[0001375365-25-000030:notes:175]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1) |  |  | $ | 375 |  |  | $ | (2,398) |  |  | $ | (7) |  |  | $ | (59) |  |  | $ | 3,879 |  |  | $ | 1,655 |  |
| Three months ended September 30, 2024 | $ | (2) |  |  | $ | (466) |  |  | $ | 29,999 |  |  | $ | 300 |  |  | $ | 237 |  |  | $ | 2,925 |  |  | $ | 3,906 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 249 |  |  | $ | 12,168 |  |  | $ | (21,775) |  |  | $ | 561 |  |  | $ | (92) |  |  | $ | 8 |  |  | $ | 141 |  |
| Three months ended September 30, 2024 | $ | (6,895) |  |  | $ | (2,669) |  |  | $ | 6,784 |  |  | $ | (70) |  |  | $ | — |  |  | $ | 204 |  |  | $ | 153 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,819) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,142 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (100) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 958 |  |  | $ | — |  |  | $ | (59) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,671) |  |  | $ | 12,543 |  |  | $ | (24,173) |  |  | $ | 554 |  |  | $ | (151) |  |  | $ | 3,887 |  |  | $ | 1,796 |  |
| Three months ended September 30, 2024 | $ | (1,797) |  |  | $ | (3,135) |  |  | $ | 36,724 |  |  | $ | 230 |  |  | $ | 237 |  |  | $ | 3,129 |  |  | $ | 4,059 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-25-000030:notes:176]
Note 11.               Stock-based Compensation and Stockholders’ Equity

[0001375365-25-000030:notes:177]
[same as prior period, unchanged from 0001375365-25-000014:notes:193]

[0001375365-25-000030:notes:178]
We have 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by the Board at the time of issuance of such shares. As of September 30, 2025 and June 30, 2025, there were no shares of preferred stock issued and outstanding.

[0001375365-25-000030:notes:179]
[same as prior period, unchanged from 0001375365-25-000014:notes:195]

[0001375365-25-000030:notes:180]
We may issue up to 1,000,000,000 shares of common stock, $0.001 par value per share. The holders of our common stock are entitled to one vote for each share held of record on all matters submitted to a vote of stockholders.

[0001375365-25-000030:notes:181]
[same as prior period, unchanged from 0001375365-25-000014:notes:197]

[0001375365-25-000030:notes:182]
Our 2020 Equity and Incentive Compensation Plan (the “2020 Plan”) was approved by stockholders on June 5, 2020, authorizing 50,000,000 plus 10,450,000 shares carried over from the 2016 Equity Incentive Plan (the “2016 Plan”). No new awards may be granted under the 2016 Plan, though 72,460,000 shares remained reserved for outstanding awards at the time of adoption. Stockholders approved amendments to the 2020 Plan in May 2022, January 2024, and June 2025, increasing the share reserve by 20,000,000, 15,000,000, and 18,000,000 respectively. Awards under the 2020 Plan include stock options, restricted stock units, performance shares, and other equity-based awards. Stock options are granted at a price not less than fair value (110% for 10% stockholders), and generally expire ten years after the date of the grant. Stock options and RSUs generally vest over four years (25% after one year and quarterly thereafter).

[0001375365-25-000030:notes:183]
As of September 30, 2025, we had 14,263,384 authorized shares available for future issuance under the 2020 Plan.

[0001375365-25-000030:notes:184]
[same as prior period, unchanged from 0001375365-25-000014:notes:206]

[0001375365-25-000030:notes:185]
We measure RSUs at the grant-date stock price and stock options using the Black-Scholes model, with inputs for expected term, volatility, zero dividend yield, and U.S. Treasury risk-free rates, amortized over the vesting period.

[0001375365-25-000030:notes:186]
The fair value of stock option grants for the three months ended September 30, 2025 and 2024 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-25-000030:notes:187]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Risk-free interest rate | 3.73% - 4.00% |  | 3.82% - 4.00% |  |  |  |  |
| Expected term | 3.44 years - 5.95 years |  | 3.00 years - 5.98 years |  |  |  |  |
| Dividend yield | —% |  | —% |  |  |  |  |
| Volatility | 76.16% - 92.16% |  | 63.67% - 69.97% |  |  |  |  |
| Weighted-average fair value of options | $39.81 |  | $40.71 |  |  |  |  |

[0001375365-25-000030:notes:188]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2025 and 2024 (in thousands):

[0001375365-25-000030:notes:189]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Cost of sales | $ | 7,075 |  |  | $ | 3,959 |  |  |  |  |  |
| Research and development | 57,433 |  |  | 36,527 |  |  |  |  |  |
| Sales and marketing | 11,100 |  |  | 7,763 |  |  |  |  |  |
| General and administrative | 13,531 |  |  | 15,765 |  |  |  |  |  |
| Stock-based compensation expense before taxes | 89,139 |  |  | 64,014 |  |  |  |  |  |
| Income tax impact | (19,201) |  |  | (15,873) |  |  |  |  |  |
| Stock-based compensation expense, net | $ | 69,938 |  |  | $ | 48,141 |  |  |  |  |  |

[0001375365-25-000030:notes:190]
During the three months ended September 30, 2025, there was no stock-based compensation expense capitalized to our condensed consolidated balance sheets. During the three months ended September 30, 2024, stock-based compensation expense capitalized to our condensed consolidated balance sheets was $0.1 million.

[0001375365-25-000030:notes:191]
[same as prior period, unchanged from 0001375365-25-000014:notes:217]

[0001375365-25-000030:notes:192]
[same as prior period, unchanged from 0001375365-25-000014:notes:227]

[0001375365-25-000030:notes:193]
In November 2023, the Compensation Committee granted the CEO a stock option for 5,000,000 shares at an exercise price of $45.00. Vesting occurs in five tranches upon achievement of specified stock price targets ($45.00 to $110.00 per share) and revenue-based operational milestones, subject to continued service. Shares exercised before November 14, 2026 must be held until that date, except for those sold to cover exercise costs and taxes.

[0001375365-25-000030:notes:194]
The achievement status of the operational and stock price milestones as of September 30, 2025 was as follows:

[0001375365-25-000030:notes:195]
| Annualized Revenue Milestone (in billions)(1) |  | Achievement Status |  | Stock Price Milestone(1) |  | Achievement Status |
| $13.0 |  | Achieved (6) |  | $45.00 |  | Achieved (2) |
| $15.0 |  | Achieved (7) |  | $60.00 |  | Achieved (3) |
| $17.0 |  | Achieved (8) |  | $75.00 |  | Achieved (4) |
| $19.0 |  | Achieved (9) |  | $90.00 |  | Achieved (5) |
| $21.0 |  | Achieved (10) |  | $110.00 |  | Not yet achieved |

[0001375365-25-000030:notes:196]
[same as prior period, unchanged from 0001375365-25-000014:notes:231]

[0001375365-25-000030:notes:197]
(2)On March 2, 2024, the Compensation Committee certified achievement of the $45.00 stock price milestone based upon the 60 trading day average stock price from November 29, 2023 through February 26, 2024.

[0001375365-25-000030:notes:198]
(3)On April 1, 2024, the Compensation Committee certified achievement of the $60.00 stock price milestone based upon the 60 trading day average stock price from December 15, 2023 through March 13, 2024.

[0001375365-25-000030:notes:199]
(4)On April 1, 2024, the Compensation Committee certified achievement of the $75.00 stock price milestone based upon the 60 trading day average stock price from January 4, 2024 through April 1, 2024.

[0001375365-25-000030:notes:200]
(5)On May 5, 2024, the Compensation Committee certified achievement of the $90.00 stock price milestone based upon the 60 trading day average stock price from January 31, 2024 through April 25, 2024.

[0001375365-25-000030:notes:201]
(6)On February 27, 2025, the Compensation Committee certified achievement of the $13.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of June 30, 2024.

[0001375365-25-000030:notes:202]
(7)On April 22, 2025, the Compensation Committee certified achievement of the $15.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000030:notes:203]
(8)On April 22, 2025, the Compensation Committee certified achievement of the $17.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000030:notes:204]
(9)On April 22, 2025, the Compensation Committee certified achievement of the $19.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of December 31, 2024.

[0001375365-25-000030:notes:205]
(10)On August 26, 2025, the Compensation Committee certified achievement of the $21.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of March 31, 2025.

[0001375365-25-000030:notes:206]
During the three months ended September 30, 2025 and 2024, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $1.0 million and $7.7 million, respectively. As of September 30, 2025, we had $4.5 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of September 30, 2025 is expected to be recognized over a period of 1.25 years.

[0001375365-25-000030:notes:207]
The following table summarizes stock option activity during the three months ended September 30, 2025 under all plans:

[0001375365-25-000030:notes:208]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm (in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2025 |  | 34,848,133 |  |  | $ | 22.47 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Granted |  | 1,218,411 |  |  | $ | 58.19 |  |  | $ | 39.81 |  |  | — |  |  | $ | — |  |
| Exercised |  | (631,240) |  |  | $ | 8.88 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Forfeited/Cancelled |  | (231,410) |  |  | $ | 33.88 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balance as of September 30, 2025 |  | 35,203,894 |  |  | $ | 23.87 |  |  | $ | — |  |  | 6.85 |  | $ | 925,363 |  |
| Options exercisable at September 30, 2025 |  | 23,837,964 |  |  | $ | 16.12 |  |  | $ | — |  |  | 6.00 |  | $ | 779,627 |  |

[0001375365-25-000030:notes:209]
The total pretax intrinsic value of options exercised during the three months ended September 30, 2025 and 2024 was $23.4 million and $63.1 million, respectively.

[0001375365-25-000030:notes:210]
As of September 30, 2025, $241.8 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.65 years.

[0001375365-25-000030:notes:211]
[same as prior period, unchanged from 0001375365-25-000014:notes:246]

[0001375365-25-000030:notes:212]
The following table summarizes RSU activity during the three months ended September 30, 2025 under all plans:

[0001375365-25-000030:notes:213]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2025 | 20,428,647 |  |  | $ | 34.22 |  |  |  |  |  |  |
| Granted | 2,430,495 |  |  | $ | 58.20 |  |  |  |  |  |  |
| Released | (2,994,432) |  |  | $ | 30.31 |  |  |  |  |  |  |
| Forfeited | (463,822) |  |  | $ | 39.22 |  |  |  |  |  |  |
| Balance as of September 30, 2025 | 19,400,888 |  |  | $ | 37.71 |  |  |  |  |  |  |

[0001375365-25-000030:notes:214]
As of September 30, 2025, $668.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.62 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-25-000030:notes:215]
Note 12.               Income Taxes

[0001375365-25-000030:notes:216]
We recorded a provision for income taxes of $40.2 million and $74.7 million for the three months ended September 30, 2025 and 2024, respectively. The effective tax rate was 19.3% and 15.0% for the three months ended September 30, 2025 and 2024, respectively. The effective tax rate for the three months ended September 30, 2025 was higher than that for the three months ended September 30, 2024, primarily due to the significant decrease in tax deductions related to stock-based compensation and research tax credit, due to a lower stock vesting price in the three months ended September 30, 2025, combined with an increase of state taxes which was attributable to a change in our jurisdictional mix of income. The effective tax rates for the three months ended September 30, 2025 and 2024 were both lower than the U.S. federal statutory rate of 21%, primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit.

[0001375365-25-000030:notes:217]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law and contains several changes to key U.S. federal income tax laws, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027.  As of September 30, 2025, we have recognized the tax effects of certain OBBBA provisions. We will continue to evaluate the impact of OBBBA upon our future effective tax rate, tax liabilities, and cash taxes.

[0001375365-25-000030:notes:218]
We believe that we have adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than our current position. Accordingly, our provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-25-000030:notes:219]
In general, the federal statute of limitations remains open for tax years ended June 30, 2022 through 2025. Various states' statutes of limitations remain open in general for tax years ended June 30, 2021 through 2025. Certain statutes of limitations in major foreign jurisdictions remain open for the tax years ended June 30, 2019 through 2025. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $5.5 million, in the next 12 months, due to the lapse of the statute of limitations in certain jurisdictions. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-25-000030:notes:220]
Note 13.               Commitments and Contingencies

[0001375365-25-000030:notes:221]
Litigation and claims

[0001375365-25-000030:notes:222]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Court finalized the appointment of Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint with the Court on September 22, 2025. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000030:notes:223]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000030:notes:224]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Company filed Motion to Dismiss, and the hearing is scheduled for December 8, 2025. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000030:notes:225]
In late 2024, we received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. We are cooperating with the government by providing responsive documents.

[0001375365-25-000030:notes:226]
Other legal proceedings and indemnifications

[0001375365-25-000030:notes:227]
In addition to the matters described above, from time to time, we have been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters has not had a material impact on our condensed consolidated financial condition, results of operations, or liquidity as of September 30, 2025, and any prior periods.

[0001375365-25-000030:notes:228]
We have entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-25-000030:notes:229]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2025, these remaining non-cancelable commitments were $11.6 billion, including $206.7 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized as of September 30, 2025 and June 30, 2025.

[0001375365-25-000030:notes:230]
Lease Commitments— See Note 9, “Leases”, for a discussion of our operating lease commitments.
