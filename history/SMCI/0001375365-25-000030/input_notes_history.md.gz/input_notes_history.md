# SMCI note change history — 0001375365-25-000014 → 0001375365-25-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:1]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Court finalized the appointment of Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint with the Court on September 22, 2025. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.
  (was, 2025-05-12, similarity 0.8064):
[0001375365-25-000014:note_history:1]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Averza and Covey Financial complaints are pending Court appointment of a lead plaintiff. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- changed (2025-11-07):
[0001375365-25-000030:note_history:2]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.
  (was, 2025-05-12, similarity 0.9045):
[0001375365-25-000014:note_history:2]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- changed (2025-11-07):
[0001375365-25-000030:note_history:3]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Company filed Motion to Dismiss, and the hearing is scheduled for December 8, 2025. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.
  (was, 2025-05-12, similarity 0.7015):
[0001375365-25-000014:note_history:3]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

- added (2025-11-07):
[0001375365-25-000030:note_history:4]
In late 2024, we received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. We are cooperating with the government by providing responsive documents.

- changed (2025-11-07):
[0001375365-25-000030:note_history:5]
In addition to the matters described above, from time to time, we have been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters has not had a material impact on our condensed consolidated financial condition, results of operations, or liquidity as of September 30, 2025, and any prior periods.
  (was, 2025-05-12, similarity 0.7238):
[0001375365-25-000014:note_history:5]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of March 31, 2025 and any prior periods.

- added (2025-11-07):
[0001375365-25-000030:note_history:6]
We have entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce its exposure to such obligations.

- added (2025-11-07):
[0001375365-25-000030:note_history:7]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2025, these remaining non-cancelable commitments were $11.6 billion, including $206.7 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized as of September 30, 2025 and June 30, 2025.

- changed (2025-11-07):
[0001375365-25-000030:note_history:8]
Lease Commitments— See Note 9, “Leases”, for a discussion of our operating lease commitments.
  (was, 2025-05-12, similarity 0.9278):
[0001375365-25-000014:note_history:8]
Lease Commitments— See Note 8 “Leases”, for a discussion of the Company's operating lease commitments.

- removed (2025-11-07):
[0001375365-25-000014:note_history:9]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. The Company is cooperating with these document requests and there have been no charges brought against any person as of the date of this filing.

- removed (2025-11-07):
[0001375365-25-000014:note_history:10]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

- removed (2025-11-07):
[0001375365-25-000014:note_history:11]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2025, these remaining non-cancelable commitments were $1.8 billion, including $107.5 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of March 31, 2025 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:12]
Note 1.                 Organization and Summary of Significant Accounting Policies
  (was, 2025-05-12, similarity 0.8522):
[0001375365-25-000014:note_history:12]
Note 1.                 Summary of Significant Accounting Policies

- changed (2025-11-07):
[0001375365-25-000030:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“U.S. GAAP”) and applicable rules and regulations of the Securities and Exchange Commission regarding interim financial reporting. Certain information and note disclosures normally included in the financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations. As such, the information included in this Quarterly Report on Form 10-Q should be read in conjunction with the consolidated financial statements and accompanying notes included in the Annual Report on Form 10-K for the fiscal year ended June 30, 2025, of Super Micro Computer, Inc., a Delaware corporation, and its consolidated entities (collectively, the “Company”). The condensed consolidated balance sheet as of June 30, 2025 included herein was derived from the audited financial statements as of that date but does not include all disclosures including notes required by U.S. GAAP.
  (was, 2025-05-12, similarity 0.9812):
[0001375365-25-000014:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) and applicable rules and regulations of the Securities and Exchange Commission regarding interim financial reporting. Certain information and note disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to such rules and regulations. As such, the information included in this quarterly report on Form 10-Q should be read in conjunction with the consolidated financial statements and accompanying notes included in the Annual Report on Form 10-K for the year ended June 30, 2024, of Super Micro Computer, Inc., a Delaware corporation, and its consolidated entities (collectively, the “Company”). The condensed consolidated balance sheet as of March 31, 2025 included herein was derived from the audited financial statements as of that date, but does not include all disclosures including notes required by GAAP.

- changed (2025-11-07):
[0001375365-25-000030:note_history:14]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial condition, results of operations, and cash flows for the periods presented. All intercompany balances and transactions have been eliminated. Interim results are not necessarily indicative of the results for the full year ending June 30, 2026.
  (was, 2025-05-12, similarity 0.9916):
[0001375365-25-000014:note_history:14]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. All intercompany balances and transactions have been eliminated. Interim results are not necessarily indicative of the results for the full year ending June 30, 2025.

- changed (2025-11-07):
[0001375365-25-000030:note_history:15]
There have been no material changes to our significant accounting policies included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.
  (was, 2025-05-12, similarity 0.8918):
[0001375365-25-000014:note_history:15]
There have been no material changes to the Company's significant accounting policies from its Annual Report on Form 10-K for the fiscal year ended June 30, 2024.

- changed (2025-11-07):
[0001375365-25-000030:note_history:16]
Concentration of Credit Risk and Significant Customers
  (was, 2025-05-12, similarity 0.6829):
[0001375365-25-000014:note_history:16]
Concentration of Credit Risk

- added (2025-11-07):
[0001375365-25-000030:note_history:17]
Financial instruments that potentially subject us to a significant concentration of credit risk consist of cash and cash equivalents, restricted cash, and accounts receivable. Cash and cash equivalents are maintained with high-quality financial institutions, the composition and maturities of which are regularly monitored by management.

- added (2025-11-07):
[0001375365-25-000030:note_history:18]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

- changed (2025-11-07):
[0001375365-25-000030:note_history:19]
|  | September 30, 2025 |  | June 30, 2025 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 29.5% |  | 33.4% |
| Customer B | * |  | 13.6% |
| Customer C | 19.7% |  | * |
| Customer D | 12.5% |  | * |
  (was, 2025-05-12, similarity 0.8735):
[0001375365-25-000014:note_history:19]
|  | March 31, 2025 |  | June 30, 2024 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 46.4% |  | 15.4% |
| Customer C | 17.4% |  | * |
| Customer D | * |  | 44.8% |

- added (2025-11-07):
[0001375365-25-000030:note_history:20]
Receivables Purchase Agreement

- added (2025-11-07):
[0001375365-25-000030:note_history:21]
On July 16, 2025, we entered into a Receivables Purchase Agreement (as amended, supplemented or otherwise modified from time to time, the “Receivables Purchase Agreement”), by and among, us, as seller and guarantor, MUFG Bank, Ltd. (“MUFG”), Crédit Agricole Corporate and Investment Bank, and certain other entities from time to time party thereto as purchasers (the “Purchasers”), and MUFG as administrative agent (in such capacity, the “Administrative Agent”).

- added (2025-11-07):
[0001375365-25-000030:note_history:22]
Pursuant to the Receivables Purchase Agreement, we may, subject to the terms and conditions set out therein, sell certain of our accounts receivable and related rights to the Purchasers (the “Purchased Receivables”). The Receivables Purchase Agreement provides for an uncommitted facility with an initial aggregate facility limit of $1,790.0 million. The Purchasers may elect in their sole direction to purchase eligible accounts receivable offered by us under the Receivables Purchase Agreement at the applicable purchase discount. The purchase price for any Purchased Receivable will be the net invoice amount of the Purchased Receivable, minus the applicable discount, which is set at Term SOFR (as defined in the Receivables Purchase Agreement) plus a specified discount assigned to each account debtor in the range of 1.15% - 2.80%, and calculated on the basis of a specified discount period. In the event the purchase of such Purchased Receivables is not characterized as a sale, we will be deemed to have granted a security interest in such Purchased Receivables and the proceeds thereof in favor of the Purchasers.

- added (2025-11-07):
[0001375365-25-000030:note_history:23]
Either us, the Administrative Agent, or the Required Purchasers (as defined in the Receivables Purchase Agreement) have the right to terminate the Receivables Purchase Agreement with 30 days’ prior written notice to the other party, or, if a Termination Event (as defined in the Receivables Purchase Agreement) shall have occurred and be continuing, the Receivables Purchase Agreement may be terminated by the Administrative Agent or the Required Purchasers immediately upon written notice to us.

- added (2025-11-07):
[0001375365-25-000030:note_history:24]
As of September 30, 2025 no receivables have been sold under the agreement.

- added (2025-11-07):
[0001375365-25-000030:note_history:25]
Accounting Pronouncements Recently Adopted

- added (2025-11-07):
[0001375365-25-000030:note_history:26]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the Board’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the Board’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this Update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.

- changed (2025-11-07):
[0001375365-25-000030:note_history:27]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.
  (was, 2025-05-12, similarity 0.7195):
[0001375365-25-000014:note_history:27]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.

- changed (2025-11-07):
[0001375365-25-000030:note_history:28]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements other than additional disclosures.
  (was, 2025-05-12, similarity 0.949):
[0001375365-25-000014:note_history:28]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

- added (2025-11-07):
[0001375365-25-000030:note_history:29]
In May 2025, the FASB issued ASU 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810): Determining the Accounting Acquirer in the Acquisition of a Variable Interest Entity, which revises current guidance for determining the accounting acquirer for a transaction effected primarily by exchanging equity interests in which the legal acquiree is a variable interest entity that meets the definition of a business. The amendments require that an entity consider the same factors that are currently required for determining which entity is the accounting acquirer in other acquisition transactions. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

- added (2025-11-07):
[0001375365-25-000030:note_history:30]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments–Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides all entities with a practical expedient and entities other than public business entities with an accounting policy election when applying the guidance in Topic 326, Financial Instruments–Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. The ASU is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2026. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

- added (2025-11-07):
[0001375365-25-000030:note_history:31]
Reclassification

- added (2025-11-07):
[0001375365-25-000030:note_history:32]
Certain prior period amounts have been reclassified to conform to the current period presentation. Such reclassifications did not result in changes to condensed consolidated balance sheets, statements of operations, or statements of cash flows.

- removed (2025-11-07):
[0001375365-25-000014:note_history:33]
Concentration of Supplier Risk

- removed (2025-11-07):
[0001375365-25-000014:note_history:34]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry.

- removed (2025-11-07):
[0001375365-25-000014:note_history:35]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 67.7% |  | 69.8% |  | 65.4% |  | 65.8% |
| Supplier B | 5.1% |  | n/a |  | 3.9% |  | n/a |
| Supplier C | 4.9% |  | 5.1% |  | 5.5% |  | 7.1% |

- removed (2025-11-07):
[0001375365-25-000014:note_history:36]
^The supplier references of A-C above may represent different suppliers than those reported in a previous period.

- removed (2025-11-07):
[0001375365-25-000014:note_history:37]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, “Related Party Transactions”), accounted for a combined 2.8% and 4.0% of total cost of sales for the three months ended March 31, 2025 and 2024, respectively, and a combined 3.4% and 4.4% of total cost of sales for the nine months ended March 31, 2025 and 2024, respectively.

- removed (2025-11-07):
[0001375365-25-000014:note_history:38]
Concentration of Customer Risk

- removed (2025-11-07):
[0001375365-25-000014:note_history:39]
The concentration of customer risk refers to the potential adverse impact on a business due to a high dependency on a limited number of customers. This risk arises when a significant portion of the Company's revenue is generated from a small group of clients. If any of these key customers reduce their orders, delay payments, or terminate their contracts, the business could face substantial financial instability.

- removed (2025-11-07):
[0001375365-25-000014:note_history:40]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total net sales |  |  |  |  |  |  |  |
| Customer A | 22.5% |  | 21.2% |  | 23.5% |  | 23.7% |
| Customer B | 14.1% |  | * |  | * |  | * |
| Customer C | * |  | 16.8% |  | 13.5% |  | * |
| Customer D | * |  | * |  | 15.1% |  | * |

- removed (2025-11-07):
[0001375365-25-000014:note_history:41]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash and accounts receivable. The Company deposits cash with high-quality financial institutions. These deposits are guaranteed by the federal deposit insurance corporation up to an insurance limit.

- removed (2025-11-07):
[0001375365-25-000014:note_history:42]
Significant customer information is as follows:

- removed (2025-11-07):
[0001375365-25-000014:note_history:43]
^The customer references of A-D above may represent different customers than those reported in a previous period.

- removed (2025-11-07):
[0001375365-25-000014:note_history:44]
*Below 10%

- removed (2025-11-07):
[0001375365-25-000014:note_history:45]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.

- removed (2025-11-07):
[0001375365-25-000014:note_history:46]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. The ASU affects a variety of Topics in the Codification. The amendments apply to all reporting entities within the scope of the affected accounting guidance. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect this ASU to have a material impact on its consolidated financial statements and disclosures.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-07):
[0001375365-25-000030:note_history:47]
The following table summarizes our convertible notes as of September 30, 2025:

- added (2025-11-07):
[0001375365-25-000030:note_history:48]
|  | Issuance Date |  | Principal (in millions) |  | Coupon Interest |  | Maturity |  | Conversion price |  | Carrying Value (in millions) |  | Effective Interest Rate |
| 2028 Convertible Notes | 2/20/2025 |  | $ | 700.0 |  |  | 2.25 | % |  | 7/15/2028 |  | $ | 61.06 |  |  | $ | 686.5 |  |  | 2.97 | % |
| 2029 Convertible Notes | 2/29/2024 |  | $ | 1,725.0 |  |  | 3.50 | % |  | 3/1/2029 |  | $ | 83.44 |  |  | $ | 1,705.1 |  |  | 3.86 | % |
| 2030 Convertible Notes | 6/23/2025 |  | $ | 2,300.0 |  |  | 0.00 | % |  | 6/15/2030 |  | $ | 55.20 |  |  | $ | 2,258.3 |  |  | 0.39 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:49]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands):
  (was, 2025-05-12, similarity 0.9709):
[0001375365-25-000014:note_history:49]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-11-07):
[0001375365-25-000030:note_history:50]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 17,705 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 9,836 |  |  | — |  |
| E.SUN Bank Credit Lines | 30,000 |  |  | 30,000 |  |
| First Bank Credit Lines | — |  |  | — |  |
| Total line of credit | 57,541 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 8,880 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,229 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,391 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 10,492 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 8,169 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 13,115 |  |  | 17,098 |  |
| Total term loans | 68,276 |  |  | 82,475 |  |
| Total lines of credit and term loans | 125,817 |  |  | 112,475 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Term loans, non-current | $ | 25,199 |  |  | $ | 37,415 |  |
  (was, 2025-05-12, similarity 0.9165):
[0001375365-25-000014:note_history:50]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 24,166 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 24,166 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,957 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,756 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,980 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 14,500 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,490 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 18,125 |  |  | 27,644 |  |
| Total term loans | 82,808 |  |  | 114,557 |  |
| Total lines of credit and term loans | 106,974 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Term loans, non-current | $ | 43,003 |  |  | $ | 74,083 |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:51]
Available borrowings and interest rates as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):
  (was, 2025-05-12, similarity 0.9632):
[0001375365-25-000014:note_history:51]
Available borrowings and interest rates as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-11-07):
[0001375365-25-000030:note_history:52]
|  | September 30, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 167,295 |  |  | 2.11% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 14,071 |  |  | 1.88% - 4.74% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 30,000 |  |  | 2.02% - 5.12% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 20,000 |  |  | 2.03% - 5.26% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |
  (was, 2025-05-12, similarity 0.6804):
[0001375365-25-000014:note_history:52]
|  | March 31, 2025 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 160,834 |  |  | 2.63% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,062 |  |  | 1.88% - 5.18% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | — |  |  | n/a |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 2.02% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  |  | n/a |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 46,822 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |

- added (2025-11-07):
[0001375365-25-000030:note_history:53]
See Note 7, “Lines of Credit and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.

- changed (2025-11-07):
[0001375365-25-000030:note_history:54]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2026 |  | $ | 89,943 |  |
| 2027 |  | 18,770 |  |
| 2028 |  | 6,331 |  |
| 2029 |  | 5,621 |  |
| 2030 |  | 5,152 |  |
| Total lines of credit and term loans |  | $ | 125,817 |  |
  (was, 2025-05-12, similarity 0.9251):
[0001375365-25-000014:note_history:54]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2025 |  | $ | 34,118 |  |
| 2026 |  | 39,805 |  |
| 2027 |  | 17,293 |  |
| 2028 |  | 5,833 |  |
| 2029 |  | 5,178 |  |
| 2030 and thereafter |  | 4,747 |  |
| Total lines of credit and term loans |  | $ | 106,974 |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:55]
As of September 30, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 7, “Lines of Credit and Term Loans”.
  (was, 2025-05-12, similarity 0.9257):
[0001375365-25-000014:note_history:55]
As of March 31, 2025, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6 “Lines of Credit and Term Loans”.

- changed (2025-11-07):
[0001375365-25-000030:note_history:56]
We entered into a new agreement during the three months ended September 30, 2025 with the following terms:
  (was, 2025-05-12, similarity 0.8488):
[0001375365-25-000014:note_history:56]
The Company entered into new agreements during the nine months ended March 31, 2025 with the following terms:

- changed (2025-11-07):
[0001375365-25-000030:note_history:57]
Chang Hwa Bank
  (was, 2025-05-12, similarity 0.64):
[0001375365-25-000014:note_history:57]
Cathay Bank

- changed (2025-11-07):
[0001375365-25-000030:note_history:58]
Chang Hwa Bank Credit Lines
  (was, 2025-05-12, similarity 0.7755):
[0001375365-25-000014:note_history:58]
HSBC Bank Credit Lines

- added (2025-11-07):
[0001375365-25-000030:note_history:59]
On September 18, 2025 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “2025 Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the “New Credit Facility” in 2024 to renew a Loan Contract for a general working capital loan (the “General Working Capital Loan”). The credit limit thereunder has been adjusted to a total cap of NTD 1,000.0 million, which includes $20.0 million from the Chang Hwa Bank Credit Facility, a credit limit of NTD 300.0 million (together, the “CHB Credit Lines”), and the remaining balance of “Chang Hwa Bank Term Loan Facility”.

- added (2025-11-07):
[0001375365-25-000030:note_history:60]
Terms for specific drawdown instruments issued under the 2025 Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Chang Hwa Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”), with the interest rate thereunder based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%. Only the Loan Contract referred to in (b) is subject to renewal or re-execution, while the other agreements under (a) remain unchanged.

- changed (2025-11-07):
[0001375365-25-000030:note_history:61]
First Bank
  (was, 2025-05-12, similarity 0.6316):
[0001375365-25-000014:note_history:61]
CTBC Bank

- added (2025-11-07):
[0001375365-25-000030:note_history:62]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. As of September 30, 2025, there were no outstanding borrowings under the First Bank credit line.

- added (2025-11-07):
[0001375365-25-000030:note_history:63]
The following table summarizes our convertible notes as of September 30, 2025:

- added (2025-11-07):
[0001375365-25-000030:note_history:64]
|  | Issuance Date |  | Principal (in millions) |  | Coupon Interest |  | Maturity |  | Conversion price |  | Carrying Value (in millions) |  | Effective Interest Rate |
| 2028 Convertible Notes | 2/20/2025 |  | $ | 700.0 |  |  | 2.25 | % |  | 7/15/2028 |  | $ | 61.06 |  |  | $ | 686.5 |  |  | 2.97 | % |
| 2029 Convertible Notes | 2/29/2024 |  | $ | 1,725.0 |  |  | 3.50 | % |  | 3/1/2029 |  | $ | 83.44 |  |  | $ | 1,705.1 |  |  | 3.86 | % |
| 2030 Convertible Notes | 6/23/2025 |  | $ | 2,300.0 |  |  | 0.00 | % |  | 6/15/2030 |  | $ | 55.20 |  |  | $ | 2,258.3 |  |  | 0.39 | % |

- added (2025-11-07):
[0001375365-25-000030:note_history:65]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of September 30, 2025.

- added (2025-11-07):
[0001375365-25-000030:note_history:66]
We issued $1,725.0 million of 0.00% Convertible Senior Notes due 2029 (“Original 2029 Notes”) in February 2024. On February 20, 2025, we executed privately negotiated subscription and supplemental indenture agreements to amend the Original 2029 Notes (the “2029 Amendments”). Key changes included (i) establishing a 3.50% annual coupon, payable semi-annually on March 1 and September 1 beginning September 2025, and (ii) adjusting the conversion rate to 11.9842 shares per $1,000 principal amount, equivalent to a conversion price of approximately $83.44 per share. All other material terms remained substantially unchanged.

- added (2025-11-07):
[0001375365-25-000030:note_history:67]
The amendment was accounted for as an extinguishment of the original debt and issuance of new debt under Accounting Standards Codification (“ASC”) 470-50, resulting in a $30.3 million extinguishment loss recorded in other income, net, during the quarter ended March 31, 2025. Debt issuance costs are amortized to interest expense using the effective interest method.

- added (2025-11-07):
[0001375365-25-000030:note_history:68]
Holders may convert their notes upon the occurrence of certain conditions, including: (1) if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) if the trading price of the notes is below 98% of the product of the stock price and conversion rate; (3) upon certain corporate events or distributions; (4) if we call the notes for redemption; or (5) at any time from and after September 1, 2028 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, at our option beginning March 1, 2027 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

- added (2025-11-07):
[0001375365-25-000030:note_history:69]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $19.9 million and $21.3 million, respectively. The interest expense for the three months ended September 30, 2025 totaled $16.4 million, including $1.4 million from the amortization of debt issuance costs. Interest expense for the three months ended September 30, 2024 totaled $1.5 million, all of which is amortization of issuance costs.

- added (2025-11-07):
[0001375365-25-000030:note_history:70]
In connection with the issuance, we entered into 2029 Capped Call Transactions with certain financial institutions to reduce potential dilution upon conversion or offset cash payments exceeding principal. The capped calls were initially structured with a $134.14 strike price and $195.10 cap price and were amended in February 2025 to reflect the updated conversion rate. The amended cap price is $94.17 per share. These instruments are equity-classified under ASC 815-40, and no incremental value was recorded upon amendment.

- added (2025-11-07):
[0001375365-25-000030:note_history:71]
On February 20, 2025, we issued $700.0 million aggregate principal amount of 2028 Convertible Notes under an indenture with U.S. Bank Trust Company, N.A., as trustee. The notes were issued concurrently with the amended 2029 Convertible Notes and are convertible, at our election, into cash, shares of common stock, or a combination of both. The initial conversion rate is 16.3784 shares per $1,000 principal amount, equivalent to a conversion price of approximately $61.06 per share.

- changed (2025-11-07):
[0001375365-25-000030:note_history:72]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2028 Convertible Notes Indenture; (4) if we call the 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.
  (was, 2025-05-12, similarity 0.9724):
[0001375365-25-000014:note_history:72]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2028 Convertible Notes Indenture; (4) if the Company calls such 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

- added (2025-11-07):
[0001375365-25-000030:note_history:73]
Interest accrues from February 20, 2025, and is payable semi-annually on January 15 and July 15, beginning July 15, 2025. The notes mature on July 15, 2028, unless earlier converted, redeemed, or repurchased. Redemption may occur on or after March 1, 2026, if the stock price exceeds 150% of the conversion price for a specified period.

- added (2025-11-07):
[0001375365-25-000030:note_history:74]
The notes include customary provisions for conversion, redemption, and repurchase following a fundamental change. Upon such an event, holders may require us to repurchase all or part of their notes for cash equal to 100% of principal plus accrued interest, and the conversion rate may be increased for holders converting in connection with a qualifying corporate event or redemption.

- added (2025-11-07):
[0001375365-25-000030:note_history:75]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $13.5 million and $14.6 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $5.1 million, including $1.1 million from the amortization of debt issuance costs.

- added (2025-11-07):
[0001375365-25-000030:note_history:76]
2030 Convertible Notes

- added (2025-11-07):
[0001375365-25-000030:note_history:77]
On June 23, 2025, we issued $2,300 million aggregate principal amount of 2030 Convertible Notes, including the $300.0 million overallotment option. Net proceeds were approximately $2,256.0 million after issuance costs.

- added (2025-11-07):
[0001375365-25-000030:note_history:78]
The 2030 Convertible Notes are convertible at an initial rate of 18.1154 shares per $1,000 principal amount, equivalent to a conversion price of approximately $55.20 per share. Conversion prior to December 17, 2029 is permitted only if specified conditions are met (similar to those of the 2028 Convertible Notes and the 2029 Convertible Notes). After that date, the notes become convertible at any time up to two trading days before maturity.

- added (2025-11-07):
[0001375365-25-000030:note_history:79]
Holders may convert their 2030 Convertible Notes upon the occurrence of certain conditions, including: (1) during any calendar quarter commencing after the calendar quarter ending on September 30, 2025, if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon certain corporate events or distributions on our common stock, as described in the Indenture; (4) if we call the notes for redemption; or (5) at any time from and after December 17, 2029 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, beginning June 15, 2028 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

- added (2025-11-07):
[0001375365-25-000030:note_history:80]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $41.7 million and $43.9 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $2.2 million, all of which are amortization of debt issuance costs.

- added (2025-11-07):
[0001375365-25-000030:note_history:81]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date.

- removed (2025-11-07):
[0001375365-25-000014:note_history:82]
See Note 7 “Lines of Credit and Term Loans” of the Company’s 2024 Annual Report on Form 10-K for the fiscal year ended June 30, 2024 (“2024 10-K”) to the condensed consolidated financial statements in this Quarterly Report for a more complete description of the Company's credit facilities.

- removed (2025-11-07):
[0001375365-25-000014:note_history:83]
Bank of America

- removed (2025-11-07):
[0001375365-25-000014:note_history:84]
Bridge Term Loan Facility

- removed (2025-11-07):
[0001375365-25-000014:note_history:85]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder.

- removed (2025-11-07):
[0001375365-25-000014:note_history:86]
On November 1, 2024, the Company prepaid in full and terminated its obligations under the Term Loan Agreement.

- removed (2025-11-07):
[0001375365-25-000014:note_history:87]
2018 Bank of America Credit Facility

- removed (2025-11-07):
[0001375365-25-000014:note_history:88]
On July 19, 2024, the Company entered into an Eighth Amendment to Loan and Security Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as administrative agent for the lenders (the “ABL Agent”), which amends the Loan and Security Agreement, dated as of April 19, 2018 (the “ABL Agreement”) to, among other things, allow for the Company’s entry into and borrowing under the Term Loan Facility.

- removed (2025-11-07):
[0001375365-25-000014:note_history:89]
On September 27, 2024, the Company entered into the Ninth Amendment to the ABL Agreement, by and among the Company, the lenders party thereto, and the ABL Agent, which amended the ABL Agreement to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year ended June 30, 2024 under the ABL Agreement and added a $70 million availability block to the U.S borrowing base thereunder.

- removed (2025-11-07):
[0001375365-25-000014:note_history:90]
On November 20, 2024, the Company prepaid in full and terminated its obligations under the ABL Agreement.

- removed (2025-11-07):
[0001375365-25-000014:note_history:91]
2022 Bank of America Credit Facility

- removed (2025-11-07):
[0001375365-25-000014:note_history:92]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the “Taiwan Subsidiary”), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

- removed (2025-11-07):
[0001375365-25-000014:note_history:93]
Cathay Bank Line of Credit

- removed (2025-11-07):
[0001375365-25-000014:note_history:94]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the “Cathay Bank Loan Agreement”), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sub-limit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

- removed (2025-11-07):
[0001375365-25-000014:note_history:95]
2025 CTBC Facility Letter

- removed (2025-11-07):
[0001375365-25-000014:note_history:96]
On February 27, 2025, the Taiwan Subsidiary received a new facility letter from CTBC Bank (“2025 Facility”), issued under the general agreement for omnibus credit lines with CTBC Bank, dated February 16, 2024 (the “2024 CTBC Agreement”). As a result, the credit arrangements under the 2024 CTBC Agreement now include the previously issued long and medium-term loan facility of New Taiwan Dollar (“NTD”) 1,550 million entered into in 2020 and 2021 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,800 million and NTD 100 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40 million (the “USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105 million for exports and imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80 million (the “Import O/A Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “2025 CTBC Credit Lines”). Aggregate borrowings under all the 2025 CTBC Credit Lines are subject to a cap of $185 million as set forth under the 2024 CTBC Agreement.

- removed (2025-11-07):
[0001375365-25-000014:note_history:97]
The 2025 Facility expires on February 28, 2026. As of March 31, 2025, the outstanding borrowings under the 2025 CTBC Bank Credit Lines were $24.2 million.

- removed (2025-11-07):
[0001375365-25-000014:note_history:98]
E.SUN Bank

- removed (2025-11-07):
[0001375365-25-000014:note_history:99]
E.SUN Bank Term Loan Facilities and Credit Lines

- removed (2025-11-07):
[0001375365-25-000014:note_history:100]
On November 14, 2024, the Taiwan Subsidiary entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements issued by the Taiwan Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

- removed (2025-11-07):
[0001375365-25-000014:note_history:101]
HSBC Bank

- removed (2025-11-07):
[0001375365-25-000014:note_history:102]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Taiwan Subsidiary had entered into with the Taiwan affiliate of HSBC Bank (the “HSBC Loan Agreement”) was terminated and not renewed. The balance of $50 million under the HSBC Loan Agreement was fully repaid on September 9, 2024, and the loan had remained undrawn since such date.

- removed (2025-11-07):
[0001375365-25-000014:note_history:103]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 0.00% Convertible Senior Notes due 2029 (the “Original 2029 Convertible Notes”). On February 11, 2025, the Company entered into privately negotiated subscription agreements with certain holders of the Original 2029 Convertible Notes (the “Convertible Note SPAs”) to, among other things, amend certain terms of, and obtain waivers with respect to, the Original 2029 Convertible Notes and to issue $700.0 million aggregate principal amount of the 2028 Convertible Notes (as further described below). On February 12, 2025, pricing of the amended 2029 Convertible Notes and 2028 Convertible Notes was set pursuant to the Convertible Note SPAs, establishing a binding commitment by the parties to the Convertible Note SPAs. On February 20, 2025, the Company amended and supplemented that certain indenture governing the Original 2029 Convertible Notes (the “Original 2029 Notes Indenture”), dated as of February 27, 2024, by and between the Company U.S. Bank Trust Company, National Association, as trustee (the “Trustee”) by entering into a first supplemental indenture and a second supplemental indenture (the Original 2029 Notes Indenture, as so amended, the “2029 Convertible Notes Indenture”), in each case with the Trustee. Pursuant to the 2029 Convertible Notes Indenture, the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes which is equivalent to a conversion price of approximately $83.44 per share of the Company’s common stock, in each case subject to adjustment as set forth in 2029 Convertible Notes Indenture (such amendments, the “Amendments”). The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election. The other terms of the 2029 Convertible Notes remained substantially unchanged. The amendment was treated as an extinguishment of the original debt and an issuance of the new debt, in which a debt extinguishment loss of $30.3 million was recognized during the quarter ended March 31, 2025.

- removed (2025-11-07):
[0001375365-25-000014:note_history:104]
The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture. The debt issuance costs and premium are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

- removed (2025-11-07):
[0001375365-25-000014:note_history:105]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2029 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2029 Convertible Notes for each trading day of the 2029 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

- removed (2025-11-07):
[0001375365-25-000014:note_history:106]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

- removed (2025-11-07):
[0001375365-25-000014:note_history:107]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date.

- removed (2025-11-07):
[0001375365-25-000014:note_history:108]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. No sinking fund is provided for the 2029 Convertible Notes.

- removed (2025-11-07):
[0001375365-25-000014:note_history:109]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2028 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

- removed (2025-11-07):
[0001375365-25-000014:note_history:110]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs and premium of $23.9 million, was $1,701.1 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs and premium was $0.8 million and interest was $8.2 million for the quarter ended March 31, 2025. The effective interest rate is 3.88%.

- removed (2025-11-07):
[0001375365-25-000014:note_history:111]
In connection with the Amendment, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to discussion below under “Capped Calls”.

- removed (2025-11-07):
[0001375365-25-000014:note_history:112]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of its 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture by and between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Convertible Notes Indenture”). The Company received proceeds from the offering of approximately $700.0 million before deducting any issuance costs and fees payable to the placement agents. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier repurchased, redeemed or converted.

- removed (2025-11-07):
[0001375365-25-000014:note_history:113]
The 2028 Convertible Notes bear interest from February 20, 2025 at an annual rate of 2.25%, payable semi-annually in arrears on each January 15 and July 15, beginning on July 15, 2025. The 2028 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of the Company’s common stock, at the Company’s election, at an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2028 Convertible Notes Indenture. The Company may pay special interest, if any, at its election as the sole remedy relating to a failure to comply with its reporting obligations and will be obligated to pay additional interest, if any, under the circumstances set forth in the 2028 Convertible Notes Indenture. The 2028 Convertible Notes do not contain financial maintenance covenants.

- removed (2025-11-07):
[0001375365-25-000014:note_history:114]
If the Company undergoes a fundamental change (as defined in the 2028 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2028 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2028 Convertible Notes to be repurchased, plus any accrued and unpaid interest, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2028 Convertible Notes in connection with such corporate event or during the relevant redemption period.

- removed (2025-11-07):
[0001375365-25-000014:note_history:115]
The 2028 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2026 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 150% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the 2028 Convertible Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date.

- removed (2025-11-07):
[0001375365-25-000014:note_history:116]
The 2028 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2028 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2028 Convertible Notes. No sinking fund is provided for the 2028 Convertible Notes.

- removed (2025-11-07):
[0001375365-25-000014:note_history:117]
The 2028 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2028 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2029 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2028 Convertible Notes to convert their notes early had been met. Therefore, the 2028 Convertible Notes are classified as long-term debt.

- removed (2025-11-07):
[0001375365-25-000014:note_history:118]
The Company accounted for the issuance of the 2028 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

- removed (2025-11-07):
[0001375365-25-000014:note_history:119]
The carrying value of the 2028 Convertible Notes, net of unamortized issuance costs of $15.8 million, was $684.2 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs was $0.5 million and for interest was $1.8 million for the quarter ended March 31, 2025. The effective interest rate is 2.97%.

- removed (2025-11-07):
[0001375365-25-000014:note_history:120]
Capped Calls

- removed (2025-11-07):
[0001375365-25-000014:note_history:121]
On February 12, 2025, in connection with the Amendments, the Company also entered into agreements to amend certain terms of the privately negotiated capped call transactions (collectively and as amended, the “Capped Call Transactions”) originally entered into with certain financial institutions (the “Capped Call Counterparties”) on February 22, 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the strike price and cap price. The strike price, after giving effect to the amendments, is initially $83.44 per share of the Company's common stock. The cap price, after giving effect to the amendments, is initially $94.17 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls. The number of shares underlying the Capped Calls increased from 7.455 to 11.984 per $1,000 principal amount of 2029 Convertible Notes.

- removed (2025-11-07):
[0001375365-25-000014:note_history:122]
The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. 
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. The amendment to the Capped Call Transactions did not change the recognition of the Capped Call Transactions as shareholders’ equity and did not result in any incremental value requiring recognition. The amended 2029 Convertible Notes and the amended Capped Call Transactions have been integrated for tax purposes. The impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:123]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands):
  (was, 2025-05-12, similarity 0.9709):
[0001375365-25-000014:note_history:123]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-11-07):
[0001375365-25-000030:note_history:124]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 17,705 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 9,836 |  |  | — |  |
| E.SUN Bank Credit Lines | 30,000 |  |  | 30,000 |  |
| First Bank Credit Lines | — |  |  | — |  |
| Total line of credit | 57,541 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 8,880 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,229 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,391 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 10,492 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 8,169 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 13,115 |  |  | 17,098 |  |
| Total term loans | 68,276 |  |  | 82,475 |  |
| Total lines of credit and term loans | 125,817 |  |  | 112,475 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Term loans, non-current | $ | 25,199 |  |  | $ | 37,415 |  |
  (was, 2025-05-12, similarity 0.9165):
[0001375365-25-000014:note_history:124]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 24,166 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 24,166 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,957 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,756 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,980 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 14,500 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,490 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 18,125 |  |  | 27,644 |  |
| Total term loans | 82,808 |  |  | 114,557 |  |
| Total lines of credit and term loans | 106,974 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Term loans, non-current | $ | 43,003 |  |  | $ | 74,083 |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:125]
Available borrowings and interest rates as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):
  (was, 2025-05-12, similarity 0.9632):
[0001375365-25-000014:note_history:125]
Available borrowings and interest rates as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-11-07):
[0001375365-25-000030:note_history:126]
|  | September 30, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 167,295 |  |  | 2.11% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 14,071 |  |  | 1.88% - 4.74% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 30,000 |  |  | 2.02% - 5.12% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 20,000 |  |  | 2.03% - 5.26% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |
  (was, 2025-05-12, similarity 0.6804):
[0001375365-25-000014:note_history:126]
|  | March 31, 2025 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 160,834 |  |  | 2.63% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,062 |  |  | 1.88% - 5.18% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | — |  |  | n/a |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 2.02% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  |  | n/a |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 46,822 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |

- removed (2025-11-07):
[0001375365-25-000014:note_history:127]
Activities under Revolving Lines of Credit and Term Loans


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:128]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2026 |  | $ | 89,943 |  |
| 2027 |  | 18,770 |  |
| 2028 |  | 6,331 |  |
| 2029 |  | 5,621 |  |
| 2030 |  | 5,152 |  |
| Total lines of credit and term loans |  | $ | 125,817 |  |
  (was, 2025-05-12, similarity 0.9251):
[0001375365-25-000014:note_history:128]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2025 |  | $ | 34,118 |  |
| 2026 |  | 39,805 |  |
| 2027 |  | 17,293 |  |
| 2028 |  | 5,833 |  |
| 2029 |  | 5,178 |  |
| 2030 and thereafter |  | 4,747 |  |
| Total lines of credit and term loans |  | $ | 106,974 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:129]
We have a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Both Ablecom and Compuware are a major contract manufacturer for us and Compuware is also a distributor of our products. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of September 30, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2025. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and we do not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director of ours, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.
  (was, 2025-05-12, similarity 0.8651):
[0001375365-25-000014:note_history:129]
The Company has a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

- added (2025-11-07):
[0001375365-25-000030:note_history:130]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of September 30, 2025 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.9 million and $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid.

- added (2025-11-07):
[0001375365-25-000030:note_history:131]
We have entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

- added (2025-11-07):
[0001375365-25-000030:note_history:132]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.6% and 96.8% of the chassis purchased by us during the three months ended September 30, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

- added (2025-11-07):
[0001375365-25-000030:note_history:133]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and we provide certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to us. For the components purchased from us, Ablecom sells the components back to us at a price equal to the price at which we sold the components to Ablecom. There is no revenue recognized by us from these transactions. We and Ablecom frequently review and negotiate the prices of the chassis we purchase from Ablecom. In addition to inventory purchases, we also incur other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- added (2025-11-07):
[0001375365-25-000030:note_history:134]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on September 30, 2025 and June 30, 2025 were $50.1 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

- added (2025-11-07):
[0001375365-25-000030:note_history:135]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, and Australia. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

- changed (2025-11-07):
[0001375365-25-000030:note_history:136]
We also have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We have extended a $65.0 million trade credit line with a net 60 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.
  (was, 2025-05-12, similarity 0.9335):
[0001375365-25-000014:note_history:136]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. The Company has extended a $65.0 million trade credit line with a net 60 days payment terms to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

- added (2025-11-07):
[0001375365-25-000030:note_history:137]
Under these agreements, we outsource a portion of our design activities, a  significant part of our power supplies manufacturing and an immaterial portion of other components to Compuware. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to our specifications and further agree to build the tools needed to manufacture the products. We pay Compuware for the design and engineering services and further agrees to pay Compuware for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from third parties and uses these materials to manufacture the products and then sell those products to us. We and Compuware frequently review and negotiate the prices of the power supplies we purchase from Compuware.

- added (2025-11-07):
[0001375365-25-000030:note_history:138]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for us. We sell to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to us at a purchase price equal to the price at which we sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by us from these transactions. We and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products we purchase from Compuware. In addition to the inventory purchases, we also incur costs associated with design services, tooling assets, and miscellaneous costs.

- added (2025-11-07):
[0001375365-25-000030:note_history:139]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on September 30, 2025 and June 30, 2025 were $156.6 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- added (2025-11-07):
[0001375365-25-000030:note_history:140]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, our authorized reseller. During the three months ended September 30, 2025, we engaged in transactions whereby we sold $0.3 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the three months ended September 30, 2024, we engaged in transactions in which it sold $0.1 million of servers to Leadtek and purchased $0.4 million of graphics cards from Leadtek.

- changed (2025-11-07):
[0001375365-25-000030:note_history:141]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture is 30% owned by us and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.
  (was, 2025-05-12, similarity 0.7457):
[0001375365-25-000014:note_history:141]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is approximately 30% owned by the Company and approximately 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- added (2025-11-07):
[0001375365-25-000030:note_history:142]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025.

- added (2025-11-07):
[0001375365-25-000030:note_history:143]
We sold products worth $2.8 million and $4.8 million to the Corporate Venture during three months ended September 30, 2025 and 2024, respectively, and our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2025 has been eliminated and have reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $1.8 million and less than $0.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2025 and June 30, 2025, respectively.

- added (2025-11-07):
[0001375365-25-000030:note_history:144]
For the three months ended September 30, 2025, and 2024, we had no and immaterial sales to and purchases from, respectively, Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Green Earth.

- added (2025-11-07):
[0001375365-25-000030:note_history:145]
For the three months ended September 30, 2025 and 2024, we had no transactions directly or indirectly to Aeon Lighting Technology Inc. (“Aeon Lighting”). Aeon Lighting is a company which is owned more than 10% by James Liang, a brother of our Chief Executive Officer. James Liang is also a director of Aeon Lighting and serves as the Chief Executive Officer of such entity. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Aeon Lighting.

- added (2025-11-07):
[0001375365-25-000030:note_history:146]
For the three months ended September 30, 2025, we had no sale or purchases transactions with Ampera, Inc. (“Ampera”). We represent approximately 33% on the board of directors as we have one board of director seat on a board of three. With the combination of our 11% equity interest and board representation, we have the ability to exercise significant influence over the operating and financial policies of Ampera. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Ampera.

- changed (2025-11-07):
[0001375365-25-000030:note_history:147]
We had the following balances related to transactions with our related parties as of September 30, 2025 and June 30, 2025 (in thousands):
  (was, 2025-05-12, similarity 0.8958):
[0001375365-25-000014:note_history:147]
The Company had the following balances related to transactions with its related parties as of March 31, 2025 and June 30, 2024 (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:148]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2 |  |  | $ | 684 |  |  | $ | 53,062 |  |  | $ | 746 |  |  | $ | 55 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 36 |  |  | $ | 518 |  |  | $ | 52,517 |  |  | $ | 852 |  |  | $ | 402 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 1,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 177 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2,064 |  |  | $ | 1,202 |  |  | $ | 105,579 |  |  | $ | 1,598 |  |  | $ | 457 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:149]
(3) Other long-term liabilities include non-current portion of lease liabilities.
  (was, 2025-05-12, similarity 0.9939):
[0001375365-25-000014:note_history:149]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

- changed (2025-11-07):
[0001375365-25-000030:note_history:150]
Our results from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):
  (was, 2025-05-12, similarity 0.8951):
[0001375365-25-000014:note_history:150]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2025 and 2024, are as follows (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:151]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 42 |  |  | $ | 69,841 |  |  | $ | 1,655 |  |  | $ | 828 |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 2 |  |  | $ | 137,507 |  |  | $ | 4,492 |  |  | $ | 1,862 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 5,874 |  |  | $ | 85,487 |  |  | $ | 149 |  |  | $ | 188 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 9,975 |  |  | $ | 102,117 |  |  | $ | 357 |  |  | $ | 380 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 2,768 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,827 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 267 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 71 |  |  | $ | 427 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 8,951 |  |  | $ | 155,328 |  |  | $ | 1,804 |  |  | $ | 1,016 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 14,875 |  |  | $ | 240,051 |  |  | $ | 4,849 |  |  | $ | 2,242 |  |  | $ | — |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:152]
Our cash flow impact from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):
  (was, 2025-05-12, similarity 0.8779):
[0001375365-25-000014:note_history:152]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:153]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1) |  |  | $ | 375 |  |  | $ | (2,398) |  |  | $ | (7) |  |  | $ | (59) |  |  | $ | 3,879 |  |  | $ | 1,655 |  |
| Three months ended September 30, 2024 | $ | (2) |  |  | $ | (466) |  |  | $ | 29,999 |  |  | $ | 300 |  |  | $ | 237 |  |  | $ | 2,925 |  |  | $ | 3,906 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 249 |  |  | $ | 12,168 |  |  | $ | (21,775) |  |  | $ | 561 |  |  | $ | (92) |  |  | $ | 8 |  |  | $ | 141 |  |
| Three months ended September 30, 2024 | $ | (6,895) |  |  | $ | (2,669) |  |  | $ | 6,784 |  |  | $ | (70) |  |  | $ | — |  |  | $ | 204 |  |  | $ | 153 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,819) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,142 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (100) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 958 |  |  | $ | — |  |  | $ | (59) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,671) |  |  | $ | 12,543 |  |  | $ | (24,173) |  |  | $ | 554 |  |  | $ | (151) |  |  | $ | 3,887 |  |  | $ | 1,796 |  |
| Three months ended September 30, 2024 | $ | (1,797) |  |  | $ | (3,135) |  |  | $ | 36,724 |  |  | $ | 230 |  |  | $ | 237 |  |  | $ | 3,129 |  |  | $ | 4,059 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:154]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on Nasdaq in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of March 31, 2025 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.7 million and $16.4 million, respectively.

- removed (2025-11-07):
[0001375365-25-000014:note_history:155]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

- removed (2025-11-07):
[0001375365-25-000014:note_history:156]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.0% and 95.2% of the chassis purchased by the Company during the three months ended March 31, 2025 and 2024, respectively, and 95.2% and 92.7% of the chassis purchased by the Company during the nine months ended March 31, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2025-11-07):
[0001375365-25-000014:note_history:157]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. There is no revenue recognized by the Company from these transactions. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- removed (2025-11-07):
[0001375365-25-000014:note_history:158]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on March 31, 2025 were $54.4 million and $25.6 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

- removed (2025-11-07):
[0001375365-25-000014:note_history:159]
The Company appointed Compuware as a non-exclusive authorized distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility of installing the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

- removed (2025-11-07):
[0001375365-25-000014:note_history:160]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

- removed (2025-11-07):
[0001375365-25-000014:note_history:161]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by the Company from these transactions. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

- removed (2025-11-07):
[0001375365-25-000014:note_history:162]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on March 31, 2025 were $109.1 million and $81.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- removed (2025-11-07):
[0001375365-25-000014:note_history:163]
In October 2023, Ablecom and Compuware together acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended March 31, 2025, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the nine months ended March 31, 2025, the Company engaged in transactions in which it sold $0.5 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.

- removed (2025-11-07):
[0001375365-25-000014:note_history:164]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.7 million and $4.6 million as of March 31, 2025 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of March 31, 2025 and June 30, 2024. No impairment charge was recorded for the three and nine months ended March 31, 2025 and 2024.

- removed (2025-11-07):
[0001375365-25-000014:note_history:165]
The Company sold products worth $4.2 million and $4.3 million to the Corporate Venture during the three months ended March 31, 2025 and 2024, respectively, and $9.0 million and $16.5 million to the Corporate Venture during the nine months ended March 31, 2025 and 2024, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2025 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.1 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2025 and June 30, 2024, respectively.

- removed (2025-11-07):
[0001375365-25-000014:note_history:166]
For the three months ended March 31, 2025, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the nine months ended March 31, 2025, the Company had immaterial chargebacks from Green Earth. As of March 31, 2025, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth were immaterial.

- removed (2025-11-07):
[0001375365-25-000014:note_history:167]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  |  |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |
| Accounts receivable | $ | 1 |  |  | $ | 1 |  |  | $ | 94 |  |  | $ | 142 |  |  | $ | 85 |  |  | $ | 5,075 |  |  |  |  | $ | 136 |  |  | $ | 976 |  |  | $ | 316 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,350 |  |  | $ | 1,927 |  |  | $ | 13,371 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 14,721 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 50,359 |  |  | $ | 98,629 |  |  | $ | 64,945 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 230 |  |  | $ | 115,304 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 487 |  |  | $ | — |  |  | $ | 254 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 741 |  |  | $ | 170 |  |
| Other Long-term liabilities (3) | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | — |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:168]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 3 |  |  | $ | 2 |  |  | $ | 3,278 |  |  | $ | 21,501 |  |  | $ | 4,201 |  |  | $ | 4,301 |  |  |  |  | $ | 165 |  |  | $ | — |  |  | $ | 7,647 |  |  | $ | 25,804 |  |
| Purchases - inventory | $ | 50,147 |  |  | $ | 65,933 |  |  | $ | 65,372 |  |  | $ | 64,464 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 115,519 |  |  | $ | 130,397 |  |
| Purchases - other miscellaneous items | $ | 8,748 |  |  | $ | 4,401 |  |  | $ | 460 |  |  | $ | 343 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 9,208 |  |  | $ | 4,744 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:169]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

- removed (2025-11-07):
[0001375365-25-000014:note_history:170]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 10 |  |  | $ | 8 |  |  | $ | 24,318 |  |  | $ | 42,498 |  |  | $ | 8,977 |  |  | $ | 16,474 |  |  |  |  | $ | 494 |  |  | $ | — |  |  | $ | 33,799 |  |  | $ | 58,980 |  |
| Purchases - inventory | $ | 252,426 |  |  | $ | 163,131 |  |  | $ | 238,720 |  |  | $ | 192,817 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  |  | $ | 491,680 |  |  | $ | 355,948 |  |
| Purchases - other miscellaneous items | $ | 18,866 |  |  | $ | 12,616 |  |  | $ | 1,491 |  |  | $ | 1,092 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 20,357 |  |  | $ | 13,708 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:171]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Changes in accounts receivable | $ | — |  |  | $ | (1) |  |  | $ | 48 |  |  | $ | 3,260 |  |  | $ | 4,990 |  |  | $ | 1,104 |  |  |  |  | $ | 840 |  |  | $ | — |  |  | $ | 5,878 |  |  | $ | 4,363 |  |
| Changes in other receivable | $ | 577 |  |  | $ | 1,022 |  |  | $ | (3,359) |  |  | $ | (3,539) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | (2,782) |  |  | $ | (2,517) |  |
| Changes in accounts payable | $ | (48,270) |  |  | $ | 18,480 |  |  | $ | (1,491) |  |  | $ | (5,032) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (230) |  |  | $ | — |  |  | $ | (49,991) |  |  | $ | 13,448 |  |
| Changes in accrued liabilities | $ | 487 |  |  | $ | (538) |  |  | $ | 84 |  |  | $ | 5,319 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 4,781 |  |
| Changes in other long-term liabilities | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (178) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | (178) |  |
| Purchases of property, plant and equipment | $ | 10,137 |  |  | $ | 8,935 |  |  | $ | 371 |  |  | $ | 197 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 10,508 |  |  | $ | 9,132 |  |
| Unpaid property, plant and equipment | $ | 7,111 |  |  | $ | 1,492 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 7,111 |  |  | $ | 1,492 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:172]
We had the following balances related to transactions with our related parties as of September 30, 2025 and June 30, 2025 (in thousands):
  (was, 2025-05-12, similarity 0.8958):
[0001375365-25-000014:note_history:172]
The Company had the following balances related to transactions with its related parties as of March 31, 2025 and June 30, 2024 (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:173]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2 |  |  | $ | 684 |  |  | $ | 53,062 |  |  | $ | 746 |  |  | $ | 55 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 36 |  |  | $ | 518 |  |  | $ | 52,517 |  |  | $ | 852 |  |  | $ | 402 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 1,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 177 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2,064 |  |  | $ | 1,202 |  |  | $ | 105,579 |  |  | $ | 1,598 |  |  | $ | 457 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:174]
(3) Other long-term liabilities include non-current portion of lease liabilities.
  (was, 2025-05-12, similarity 0.9939):
[0001375365-25-000014:note_history:174]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

- changed (2025-11-07):
[0001375365-25-000030:note_history:175]
Our results from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):
  (was, 2025-05-12, similarity 0.8951):
[0001375365-25-000014:note_history:175]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2025 and 2024, are as follows (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:176]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 42 |  |  | $ | 69,841 |  |  | $ | 1,655 |  |  | $ | 828 |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 2 |  |  | $ | 137,507 |  |  | $ | 4,492 |  |  | $ | 1,862 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 5,874 |  |  | $ | 85,487 |  |  | $ | 149 |  |  | $ | 188 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 9,975 |  |  | $ | 102,117 |  |  | $ | 357 |  |  | $ | 380 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 2,768 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,827 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 267 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 71 |  |  | $ | 427 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 8,951 |  |  | $ | 155,328 |  |  | $ | 1,804 |  |  | $ | 1,016 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 14,875 |  |  | $ | 240,051 |  |  | $ | 4,849 |  |  | $ | 2,242 |  |  | $ | — |  |

- changed (2025-11-07):
[0001375365-25-000030:note_history:177]
Our cash flow impact from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):
  (was, 2025-05-12, similarity 0.8779):
[0001375365-25-000014:note_history:177]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:178]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1) |  |  | $ | 375 |  |  | $ | (2,398) |  |  | $ | (7) |  |  | $ | (59) |  |  | $ | 3,879 |  |  | $ | 1,655 |  |
| Three months ended September 30, 2024 | $ | (2) |  |  | $ | (466) |  |  | $ | 29,999 |  |  | $ | 300 |  |  | $ | 237 |  |  | $ | 2,925 |  |  | $ | 3,906 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 249 |  |  | $ | 12,168 |  |  | $ | (21,775) |  |  | $ | 561 |  |  | $ | (92) |  |  | $ | 8 |  |  | $ | 141 |  |
| Three months ended September 30, 2024 | $ | (6,895) |  |  | $ | (2,669) |  |  | $ | 6,784 |  |  | $ | (70) |  |  | $ | — |  |  | $ | 204 |  |  | $ | 153 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,819) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,142 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (100) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 958 |  |  | $ | — |  |  | $ | (59) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,671) |  |  | $ | 12,543 |  |  | $ | (24,173) |  |  | $ | 554 |  |  | $ | (151) |  |  | $ | 3,887 |  |  | $ | 1,796 |  |
| Three months ended September 30, 2024 | $ | (1,797) |  |  | $ | (3,135) |  |  | $ | 36,724 |  |  | $ | 230 |  |  | $ | 237 |  |  | $ | 3,129 |  |  | $ | 4,059 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:179]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  |  |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |
| Accounts receivable | $ | 1 |  |  | $ | 1 |  |  | $ | 94 |  |  | $ | 142 |  |  | $ | 85 |  |  | $ | 5,075 |  |  |  |  | $ | 136 |  |  | $ | 976 |  |  | $ | 316 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,350 |  |  | $ | 1,927 |  |  | $ | 13,371 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 14,721 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 50,359 |  |  | $ | 98,629 |  |  | $ | 64,945 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 230 |  |  | $ | 115,304 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 487 |  |  | $ | — |  |  | $ | 254 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 741 |  |  | $ | 170 |  |
| Other Long-term liabilities (3) | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | — |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:180]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 3 |  |  | $ | 2 |  |  | $ | 3,278 |  |  | $ | 21,501 |  |  | $ | 4,201 |  |  | $ | 4,301 |  |  |  |  | $ | 165 |  |  | $ | — |  |  | $ | 7,647 |  |  | $ | 25,804 |  |
| Purchases - inventory | $ | 50,147 |  |  | $ | 65,933 |  |  | $ | 65,372 |  |  | $ | 64,464 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 115,519 |  |  | $ | 130,397 |  |
| Purchases - other miscellaneous items | $ | 8,748 |  |  | $ | 4,401 |  |  | $ | 460 |  |  | $ | 343 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 9,208 |  |  | $ | 4,744 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:181]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

- removed (2025-11-07):
[0001375365-25-000014:note_history:182]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 10 |  |  | $ | 8 |  |  | $ | 24,318 |  |  | $ | 42,498 |  |  | $ | 8,977 |  |  | $ | 16,474 |  |  |  |  | $ | 494 |  |  | $ | — |  |  | $ | 33,799 |  |  | $ | 58,980 |  |
| Purchases - inventory | $ | 252,426 |  |  | $ | 163,131 |  |  | $ | 238,720 |  |  | $ | 192,817 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  |  | $ | 491,680 |  |  | $ | 355,948 |  |
| Purchases - other miscellaneous items | $ | 18,866 |  |  | $ | 12,616 |  |  | $ | 1,491 |  |  | $ | 1,092 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 20,357 |  |  | $ | 13,708 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:183]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Changes in accounts receivable | $ | — |  |  | $ | (1) |  |  | $ | 48 |  |  | $ | 3,260 |  |  | $ | 4,990 |  |  | $ | 1,104 |  |  |  |  | $ | 840 |  |  | $ | — |  |  | $ | 5,878 |  |  | $ | 4,363 |  |
| Changes in other receivable | $ | 577 |  |  | $ | 1,022 |  |  | $ | (3,359) |  |  | $ | (3,539) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | (2,782) |  |  | $ | (2,517) |  |
| Changes in accounts payable | $ | (48,270) |  |  | $ | 18,480 |  |  | $ | (1,491) |  |  | $ | (5,032) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (230) |  |  | $ | — |  |  | $ | (49,991) |  |  | $ | 13,448 |  |
| Changes in accrued liabilities | $ | 487 |  |  | $ | (538) |  |  | $ | 84 |  |  | $ | 5,319 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 4,781 |  |
| Changes in other long-term liabilities | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (178) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | (178) |  |
| Purchases of property, plant and equipment | $ | 10,137 |  |  | $ | 8,935 |  |  | $ | 371 |  |  | $ | 197 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 10,508 |  |  | $ | 9,132 |  |
| Unpaid property, plant and equipment | $ | 7,111 |  |  | $ | 1,492 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 7,111 |  |  | $ | 1,492 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001375365-25-000030:note_history:184]
The following is a summary of net sales by geographic region (in thousands):
  (was, 2025-05-12, similarity 0.8163):
[0001375365-25-000014:note_history:184]
The following is a summary of net sales by product type (in thousands):

- added (2025-11-07):
[0001375365-25-000030:note_history:185]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | % of Total |  | 2024 |  | % of Total |  |  |  |  |
| United States | $ | 1,834,477 |  |  | 36.6 | % |  | $ | 4,241,349 |  |  | 71.4 | % |  |  |  |  |
| Malaysia | 1,115,149 |  |  | 22.2 | % |  | 222,585 |  |  | 3.7 | % |  |  |  |  |
| Indonesia | 578,706 |  |  | 11.5 | % |  | 1,796 |  |  | — | % |  |  |  |  |
| Other (1) | 1,489,458 |  |  | 29.7 | % |  | 1,471,526 |  |  | 24.9 | % |  |  |  |  |
| Total | $ | 5,017,790 |  |  | 100.0 | % |  | $ | 5,937,256 |  |  | 100.0 | % |  |  |  |  |

- added (2025-11-07):
[0001375365-25-000030:note_history:186]
(1) all other countries were individually less than 10%.

- removed (2025-11-07):
[0001375365-25-000014:note_history:187]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Server and storage systems | $ | 4,458,895 |  |  | $ | 3,698,446 |  |  | $ | 15,693,826 |  |  | $ | 9,100,616 |  |
| Subsystems and accessories | 141,018 |  |  | 151,620 |  |  | 521,305 |  |  | 534,046 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:188]
The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):

- removed (2025-11-07):
[0001375365-25-000014:note_history:189]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 2,768,181 |  |  | $ | 2,685,213 |  |  | $ | 10,856,490 |  |  | $ | 6,910,312 |  |
| Asia | 1,354,346 |  |  | 764,614 |  |  | 3,077,166 |  |  | 1,646,302 |  |
| Europe | 290,108 |  |  | 297,653 |  |  | 1,869,722 |  |  | 776,949 |  |
| Other | 187,278 |  |  | 102,586 |  |  | 411,753 |  |  | 301,099 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2025-11-07):
[0001375365-25-000014:note_history:190]
Note 2.                 Revenue

- removed (2025-11-07):
[0001375365-25-000014:note_history:191]
Disaggregation of Revenue

- removed (2025-11-07):
[0001375365-25-000014:note_history:192]
The Company disaggregates revenue by type of product and geographical region to depict the nature, amount, and timing of revenue and cash flows. Service and software revenues, which are less than 10%, are not a significant component of total revenue and are aggregated with server and storage systems revenue.

- removed (2025-11-07):
[0001375365-25-000014:note_history:193]
The following is a summary of net sales by product type (in thousands):

- removed (2025-11-07):
[0001375365-25-000014:note_history:194]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Server and storage systems | $ | 4,458,895 |  |  | $ | 3,698,446 |  |  | $ | 15,693,826 |  |  | $ | 9,100,616 |  |
| Subsystems and accessories | 141,018 |  |  | 151,620 |  |  | 521,305 |  |  | 534,046 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:195]
Server and storage systems constitute an assembly and integration of subsystems and accessories, software, and related services. Subsystems and accessories are comprised of server boards, chassis and accessories.

- removed (2025-11-07):
[0001375365-25-000014:note_history:196]
Revenue related to services for the three months ended March 31, 2025 and 2024 was $57.2 million and $38.3 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the nine months ended March 31, 2025 and 2024 was $161.8 million and $110.7 million, respectively, which is recognized over time ratably over the contract term.

- removed (2025-11-07):
[0001375365-25-000014:note_history:197]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):

- removed (2025-11-07):
[0001375365-25-000014:note_history:198]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 2,768,181 |  |  | $ | 2,685,213 |  |  | $ | 10,856,490 |  |  | $ | 6,910,312 |  |
| Asia | 1,354,346 |  |  | 764,614 |  |  | 3,077,166 |  |  | 1,646,302 |  |
| Europe | 290,108 |  |  | 297,653 |  |  | 1,869,722 |  |  | 776,949 |  |
| Other | 187,278 |  |  | 102,586 |  |  | 411,753 |  |  | 301,099 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |

- removed (2025-11-07):
[0001375365-25-000014:note_history:199]
Contract Balances

- removed (2025-11-07):
[0001375365-25-000014:note_history:200]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables represent the Company’s unconditional right to consideration for performance obligations either partially or fully completed.

- removed (2025-11-07):
[0001375365-25-000014:note_history:201]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s condensed consolidated financial statements.

- removed (2025-11-07):
[0001375365-25-000014:note_history:202]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2025, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $38.5 million and $154.0 million, respectively. Revenue recognized during the three and nine months ended March 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $28.9 million and $104.1 million, respectively.

- removed (2025-11-07):
[0001375365-25-000014:note_history:203]
Deferred revenue increased $249.4 million as of March 31, 2025 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $116.7 million increase in non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales which are expected to be fulfilled in the next 12 months.

- removed (2025-11-07):
[0001375365-25-000014:note_history:204]
Transaction Price Allocated to the Remaining Performance Obligations

- removed (2025-11-07):
[0001375365-25-000014:note_history:205]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to the remaining performance obligations as of March 31, 2025 was approximately $665.8 million. The Company expects to recognize approximately 53% of such value in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-11-07):
[0001375365-25-000030:note_history:206]
Note 14.               Subsequent Events
