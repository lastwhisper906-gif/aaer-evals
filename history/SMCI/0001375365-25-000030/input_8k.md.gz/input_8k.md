# SMCI 8-K — 0001375365-25-000029 filed 2025-11-04

## item codes, every 8-K on or before 2025-11-07

- 2025-11-04 0001375365-25-000029 — 2.02, 9.01
- 2025-10-23 0001628280-25-045989 — 2.02, 9.01
- 2025-08-05 0001375365-25-000023 — 2.02, 9.01
- 2025-07-21 0001375365-25-000022 — 1.01, 2.03, 9.01
- 2025-06-27 0001375365-25-000020 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-06-23 0001375365-25-000018 — 8.01, 9.01
- 2025-06-06 0001375365-25-000016 — 5.02, 5.07, 9.01
- 2025-05-06 0001375365-25-000013 — 2.02, 9.01
- 2025-04-29 0001375365-25-000012 — 2.02, 9.01
- 2025-03-31 0001375365-25-000008 — 5.02, 7.01, 9.01
- 2025-02-26 0001375365-25-000007 — 3.01, 5.08, 8.01, 9.01
- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2025-11-07

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-25-000029:8k_2_02:1]
EX-99.1
2
exhibit991_20250930.htm
EX-99.1

[0001375365-25-000029:8k_2_02:2]
Document

[0001375365-25-000029:8k_2_02:3]
Exhibit 99.1

[0001375365-25-000029:8k_2_02:4]
Supermicro Announces First Quarter Fiscal Year 2026 Financial Results

[0001375365-25-000029:8k_2_02:5]
SAN JOSE, Calif. -- November 4, 2025 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced unaudited financial results for its first quarter of fiscal year 2026 ended September 30, 2025.

[0001375365-25-000029:8k_2_02:6]
First Quarter Fiscal Year 2026 Highlights

[0001375365-25-000029:8k_2_02:7]
•Net sales of $5.0 billion versus $5.8 billion in Q4'25 and $5.9 billion in Q1'25

[0001375365-25-000029:8k_2_02:8]
•Gross margin of 9.3% versus 9.5% in Q4'25 and 13.1% in Q1'25

[0001375365-25-000029:8k_2_02:9]
•Net income of $168 million versus $195 million in Q4'25 and $424 million in Q1'25

[0001375365-25-000029:8k_2_02:10]
•Diluted net income per common share of $0.26 versus $0.31 in Q4'25 and $0.67 in Q1'25

[0001375365-25-000029:8k_2_02:11]
•Non-GAAP diluted net income per common share of $0.35 versus $0.73 in Q1'25

[0001375365-25-000029:8k_2_02:12]
•Cash flow used by operations for Q1'26 of $918 million and capital expenditures of $32 million

[0001375365-25-000029:8k_2_02:13]
“Powered by DCBBS, Supermicro is expanding/transforming into a leading AI and datacenter infrastructure company, delivering total solutions that simplify deployment, accelerate time-to-market, and reduce TCO," said Charles Liang, Founder, President and CEO of Supermicro. “With a rapidly expanding order book, including more than $13B in Blackwell Ultra orders, we expect at least $36 billion in revenue for fiscal year 2026.”

[0001375365-25-000029:8k_2_02:14]
The Non-GAAP gross margin for the first quarter of fiscal year 2026 was 9.5% with adjustments for stock-based compensation expenses of $7 million. The Non-GAAP diluted net income per common share for the first quarter of fiscal year 2026 was $0.35.

[0001375365-25-000029:8k_2_02:15]
As of September 30, 2025, total cash and cash equivalents was $4.2 billion and total bank debt and convertible notes were $4.8 billion.

[0001375365-25-000029:8k_2_02:16]
Business Outlook

[0001375365-25-000029:8k_2_02:17]
The Company expects net sales of $10.0 billion to $11.0 billion for the second quarter of fiscal year 2026 ending December 31, 2025, GAAP net income per diluted share of $0.37 to $0.45 and non-GAAP net income per diluted share of $0.46 to $0.54. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 15.6% and 16.8%, respectively, and a fully diluted share count of 666 million shares for GAAP and fully diluted share count of 680 million shares for non-GAAP. The outlook for the second quarter of fiscal year 2026 GAAP net income per diluted share includes approximately $64 million in expected stock-based compensation, net of related tax effects of $18 million that are excluded from non-GAAP net income per diluted share.

[0001375365-25-000029:8k_2_02:18]
For fiscal year 2026, the Company expects net sales of at least $36.0 billion.

[0001375365-25-000029:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-25-000029:8k_2_02:20]
Supermicro will present a live audio webcast of a conference call to review its first quarter of fiscal year 2026 financial results on Tuesday, November 4, 2025, at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-25-000029:8k_2_02:21]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-25-000029:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-25-000029:8k_2_02:23]
About Super Micro Computer, Inc.

[0001375365-25-000029:8k_2_02:24]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-25-000029:8k_2_02:25]
Supermicro, Server Building Block Solution, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-25-000029:8k_2_02:26]
All other brands, names, and trademarks are the property of their respective owners.

[0001375365-25-000029:8k_2_02:27]
Investor Relations Contact:

[0001375365-25-000029:8k_2_02:28]
Nicole Noutsios

[0001375365-25-000029:8k_2_02:29]
Stratos Advisors

[0001375365-25-000029:8k_2_02:30]
email: ir@supermicro.com

[0001375365-25-000029:8k_2_02:31]
Source: Super Micro Computer, Inc.

[0001375365-25-000029:8k_2_02:32]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-25-000029:8k_2_02:34]
(in thousands)

[0001375365-25-000029:8k_2_02:35]
(unaudited)

[0001375365-25-000029:8k_2_02:36]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,196,867 |  |  | $ | 5,169,911 |  |
| Accounts receivable, net of allowance for credit losses | 2,525,039 |  |  | 2,203,942 |  |
| Inventories | 5,730,002 |  |  | 4,680,375 |  |
| Prepaid expenses and other current assets | 209,426 |  |  | 247,426 |  |
| Total current assets | 12,661,334 |  |  | 12,301,654 |  |
| Property, plant, and equipment, net | 520,712 |  |  | 504,488 |  |
| Deferred income taxes, net | 617,257 |  |  | 607,416 |  |
| Other assets | 586,734 |  |  | 604,871 |  |
| Total assets | $ | 14,386,037 |  |  | $ | 14,018,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,279,667 |  |  | $ | 1,281,977 |  |
| Accrued liabilities | 313,393 |  |  | 565,637 |  |
| Income taxes payable | 56,235 |  |  | 53,381 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Deferred revenue | 597,322 |  |  | 368,737 |  |
| Total current liabilities | 2,347,235 |  |  | 2,344,792 |  |
| Deferred revenue, non-current | 430,682 |  |  | 362,645 |  |
| Term loans, non-current | 25,199 |  |  | 37,415 |  |
| Convertible notes | 4,649,889 |  |  | 4,645,178 |  |
| Other long-term liabilities | 409,472 |  |  | 326,528 |  |
| Total liabilities | 7,862,477 |  |  | 7,716,558 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 2,919,868 |  |  | 2,866,449 |  |
| Accumulated other comprehensive income | 698 |  |  | 705 |  |
| Retained earnings | 3,602,824 |  |  | 3,434,539 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 6,523,390 |  |  | 6,301,693 |  |
| Non-controlling interest | 170 |  |  | 178 |  |
| Total stockholders’ equity | 6,523,560 |  |  | 6,301,871 |  |
| Total liabilities and stockholders’ equity | $ | 14,386,037 |  |  | $ | 14,018,429 |  |

[0001375365-25-000029:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-25-000029:8k_2_02:39]
(in thousands, except per share amounts)

[0001375365-25-000029:8k_2_02:40]
(unaudited)

[0001375365-25-000029:8k_2_02:41]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Net sales | $ | 5,017,790 |  |  | $ | 5,937,256 |  |  |  |  |  |  |  |
| Cost of sales | 4,550,417 |  |  | 5,161,676 |  |  |  |  |  |  |  |
| Gross profit | 467,373 |  |  | 775,580 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 173,314 |  |  | 132,243 |  |  |  |  |  |  |  |
| Sales and marketing | 47,928 |  |  | 68,854 |  |  |  |  |  |  |  |
| General and administrative | 63,875 |  |  | 65,284 |  |  |  |  |  |  |  |
| Total operating expenses | 285,117 |  |  | 266,381 |  |  |  |  |  |  |  |
| Income from operations | 182,256 |  |  | 509,199 |  |  |  |  |  |  |  |
| Other income, net | 51,227 |  |  | 7,233 |  |  |  |  |  |  |  |
| Interest expense | (24,931) |  |  | (17,354) |  |  |  |  |  |  |  |
| Income before income tax provision | 208,552 |  |  | 499,078 |  |  |  |  |  |  |  |
| Income tax provision | (40,161) |  |  | (74,732) |  |  |  |  |  |  |  |
| Share of loss from equity investee, net of taxes | (106) |  |  | (19) |  |  |  |  |  |  |  |
| Net income | $ | 168,285 |  |  | $ | 424,327 |  |  |  |  |  |  |  |
| Net income per common share (A): |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.28 |  |  | $ | 0.72 |  |  |  |  |  |  |  |
| Diluted | $ | 0.26 |  |  | $ | 0.67 |  |  |  |  |  |  |  |
| Weighted-average shares used in the calculation of net income per common share (A): |  |  |  |  |  |  |  |  |  |
| Basic | 595,624 |  |  | 589,558 |  |  |  |  |  |  |  |
| Diluted | 663,235 |  |  | 639,148 |  |  |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:42]
(A) Reflects a ten-for-one stock split on September 30, 2024.

[0001375365-25-000029:8k_2_02:43]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-25-000029:8k_2_02:44]
|  |  | Three Months Ended September 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |  |  |
| Cost of sales |  | $ | 7,075 |  |  | $ | 3,959 |  |  |  |  |  |  |  |
| Research and development |  | 57,433 |  |  | 36,527 |  |  |  |  |  |  |  |
| Sales and marketing |  | 11,100 |  |  | 7,763 |  |  |  |  |  |  |  |
| General and administrative |  | 13,531 |  |  | 15,765 |  |  |  |  |  |  |  |
| Stock-based compensation expense, before taxes |  | $ | 89,139 |  |  | $ | 64,014 |  |  |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:45]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000029:8k_2_02:47]
(in thousands)

[0001375365-25-000029:8k_2_02:48]
(unaudited)

[0001375365-25-000029:8k_2_02:49]
|  | Three Months Ended September 30, |
|  | 2025 |  | 2024 |  |
| OPERATING ACTIVITIES: |  |  |  |  |
| Net income | $ | 168,285 |  |  | $ | 424,327 |  |  |
| Reconciliation of net income to net cash (used in) provided by operating activities: |  |  |  |  |
| Depreciation and amortization | 12,341 |  |  | 9,374 |  |  |
| Amortization of right-of-use (“ROU”) assets | 8,266 |  |  | 2,785 |  |  |
| Amortization of debt discount and issuance costs | 4,743 |  |  | 1,921 |  |  |
| Excess and obsolete inventories write-down | 36,199 |  |  | 9,156 |  |  |
| Stock-based compensation expense | 89,139 |  |  | 64,014 |  |  |
| Impairment loss | 12,000 |  |  | — |  |  |
| Share of loss from equity investee | 106 |  |  | 19 |  |  |
| Unrealized foreign currency exchange (gain) loss | (1,017) |  |  | 924 |  |  |
| Deferred income taxes, net | (12,201) |  |  | (46,552) |  |  |
| Other non-cash income, net | (7,539) |  |  | (3,346) |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net | (321,244) |  |  | 15,288 |  |  |
| Inventories | (1,087,010) |  |  | (606,873) |  |  |
| Prepaid expenses and other assets | 134,087 |  |  | 86,774 |  |  |
| Accounts payable | 901 |  |  | 220,353 |  |  |
| Accrued liabilities | (259,350) |  |  | 25,974 |  |  |
| Income taxes payable | 4,978 |  |  | 61,440 |  |  |
| Deferred revenue | 296,622 |  |  | 141,806 |  |  |
| Other long-term liabilities | 3,171 |  |  | 1,520 |  |  |
| Net cash (used in) provided by operating activities | (917,523) |  |  | 408,904 |  |  |
| INVESTING ACTIVITIES: |  |  |  |  |
| Purchases of property, plant, and equipment | (32,270) |  |  | (44,300) |  |  |
| Net cash used in investing activities | (32,270) |  |  | (44,300) |  |  |
| FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from lines of credit and term loans | 28,588 |  |  | 1,185,034 |  |  |
| Repayment of lines of credit and term loans | (11,540) |  |  | (1,106,178) |  |  |
| Proceeds from exercise of stock options | 7,922 |  |  | 6,527 |  |  |
| Payment for withholding taxes related to settlement of equity awards | (43,642) |  |  | (35,537) |  |  |
| Other | 7 |  |  | 8 |  |  |
| Net cash (used in) provided by financing activities | (18,665) |  |  | 49,854 |  |  |
| Effect of exchange rate fluctuations on cash | (4,588) |  |  | 4,500 |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | (973,046) |  |  | 418,958 |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 5,172,301 |  |  | 1,670,273 |  |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 4,199,255 |  |  | $ | 2,089,231 |  |  |

[0001375365-25-000029:8k_2_02:50]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000029:8k_2_02:52]
(in thousands)

[0001375365-25-000029:8k_2_02:53]
(unaudited)

[0001375365-25-000029:8k_2_02:54]
| Supplemental disclosure of cash flow information: |  |  |  |  |
| Cash paid for interest | $ | 39,244 |  |  | $ | 11,454 |  |  |
| Cash paid for taxes, net of refunds | $ | 38,502 |  |  | $ | 3,336 |  |  |
| Non-cash investing and financing activities: |  |  |  |  |
| Unpaid property, plant, and equipment purchases | $ | 11,127 |  |  | $ | 21,190 |  |  |
| ROU assets obtained in exchange for operating lease commitments | $ | 90,542 |  |  | $ | 17,782 |  |  |
| Transfer of inventory to property, plant, and equipment, net | $ | 1,184 |  |  | $ | 122 |  |  |

[0001375365-25-000029:8k_2_02:55]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:56]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000029:8k_2_02:57]
(in thousands, except per share amounts)

[0001375365-25-000029:8k_2_02:58]
(unaudited)

[0001375365-25-000029:8k_2_02:59]
Use of Non-GAAP Financial Measures

[0001375365-25-000029:8k_2_02:60]
To supplement its condensed consolidated financial results presented in accordance with United States Generally Accepted Accounting Principles (“GAAP”), the Company uses non-GAAP measures that are adjusted for certain items from the most directly comparable GAAP measures. The specific non-GAAP measures presented below are: gross profit, gross margin; operating expenses; net income; net income per common share; diluted net income; diluted net income per common share, adjusted earnings before interest, taxes, depreciation, and amortization, ("Adjusted EBITDA"); and effective tax rate. Management believes these non-GAAP measures provide useful information to investors by offering a consistent basis for comparing the Company's performance across periods, excluding items that are not reflective of our core operating results. These non-GAAP measures are not prepared in accordance with GAAP or intended to be a replacement for GAAP financial data; and therefore, should be reviewed together with the GAAP measures and are not intended to serve as a substitute for results under GAAP, and may be different from non-GAAP measures used by other companies.

[0001375365-25-000029:8k_2_02:61]
We exclude the following adjustments from our non-GAAP financial measures:

[0001375365-25-000029:8k_2_02:62]
Non-GAAP Adjustments

[0001375365-25-000029:8k_2_02:63]
•Stock-based compensation: Stock-based compensation relates primarily to our equity incentive awards. Stock-based compensation is a non-cash expense that is dependent on market forces that are difficult to predict. We believe that this adjustment for stock-based compensation provides investors with a basis to measure the company's core performance, including compared with the performance of other companies, without the period-to-period variability created by stock-based compensation.

[0001375365-25-000029:8k_2_02:64]
•Adjusted EBITDA adjustments: When calculating Adjusted EBITDA, in addition to the adjustments described above, we exclude the impact of Interest expense, Income tax (provision) benefit, and Depreciation and amortization during the period.

[0001375365-25-000029:8k_2_02:65]
Pursuant to the requirements of SEC Regulation G, please see the tables below for the reconciliations of GAAP to Non-GAAP measures. These should be read together with the preceding financial statements prepared in accordance with GAAP.

[0001375365-25-000029:8k_2_02:66]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:67]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000029:8k_2_02:68]
(in thousands, except per share amounts)

[0001375365-25-000029:8k_2_02:69]
(unaudited)

[0001375365-25-000029:8k_2_02:70]
Reconciliation of GAAP Net Income to Adjusted EBITDA:

[0001375365-25-000029:8k_2_02:71]
|  | Three Months Ended |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |
| GAAP Net Income | $ | 168,285 |  |  |  |  | $ | 424,327 |  |  |  |  |  |
| Interest expense | 24,931 |  |  |  |  | 17,354 |  |  |  |  |  |
| Income tax provision | 40,161 |  |  |  |  | 74,732 |  |  |  |  |  |
| Depreciation and amortization | 12,341 |  |  |  |  | 9,374 |  |  |  |  |  |
| Stock-based compensation | 89,139 |  |  |  |  | 64,014 |  |  |  |  |  |
| Adjusted EBITDA | $ | 334,857 |  |  |  |  | $ | 589,801 |  |  |  |  |  |
| Adjusted EBITDA % of net sales | 6.7 | % |  |  |  | 9.9 | % |  |  |  |  |

[0001375365-25-000029:8k_2_02:72]
Reconciliation of GAAP to Non-GAAP Gross Margin:

[0001375365-25-000029:8k_2_02:73]
|  | Three Months Ended |  |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |  |
| GAAP Gross Profit | $ | 467,373 |  |  |  |  | $ | 775,580 |  |  |  |  |  |  |
| Stock-based compensation | 7,075 |  |  |  |  | 3,959 |  |  |  |  |  |  |
| Non-GAAP Gross Profit | $ | 474,448 |  |  |  |  | $ | 779,539 |  |  |  |  |  |  |
| GAAP gross margin (%) | 9.3 | % |  |  |  | 13.1 | % |  |  |  |  |  |
| Stock-based compensation (%) | 0.2 | % |  |  |  | — | % | * |  |  |  |  |
| Non-GAAP gross margin (%) | 9.5 | % |  |  |  | 13.1 | % |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:74]
*Represents an amount less than 0.1%.

[0001375365-25-000029:8k_2_02:75]
Reconciliation of GAAP to Non-GAAP Operating Expenses:

[0001375365-25-000029:8k_2_02:76]
|  | Three Months Ended |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |
| GAAP Operating Expenses | $ | 285,117 |  |  |  |  | $ | 266,381 |  |  |  |  |  |
| Adjustments to operating expenses |  |  |  |  |  |  |  |  |  |
| GAAP R&D operating expenses | 173,314 |  |  |  |  | 132,243 |  |  |  |  |  |
| Stock-based compensation | 57,433 |  |  |  |  | 36,527 |  |  |  |  |  |
| Non-GAAP R&D operating expenses | 115,881 |  |  |  |  | 95,716 |  |  |  |  |  |
| GAAP S&M operating expenses | 47,928 |  |  |  |  | 68,854 |  |  |  |  |  |
| Stock-based compensation | 11,100 |  |  |  |  | 7,763 |  |  |  |  |  |
| Non-GAAP S&M operating expenses | 36,828 |  |  |  |  | 61,091 |  |  |  |  |  |
| GAAP G&A operating expenses | 63,875 |  |  |  |  | 65,284 |  |  |  |  |  |
| Stock-based compensation | 13,531 |  |  |  |  | 15,765 |  |  |  |  |  |
| Non-GAAP G&A operating expenses | 50,344 |  |  |  |  | 49,519 |  |  |  |  |  |
| Non-GAAP Operating Expenses | $ | 203,053 |  |  |  |  | $ | 206,326 |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:77]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:78]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000029:8k_2_02:79]
(in thousands, except per share amounts)

[0001375365-25-000029:8k_2_02:80]
(unaudited)

[0001375365-25-000029:8k_2_02:81]
Reconciliation of GAAP to Non-GAAP Net Income:

[0001375365-25-000029:8k_2_02:82]
|  | Three Months Ended |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |
| GAAP Net Income - basic | $ | 168,285 |  |  |  |  | $ | 424,327 |  |  |  |  |  |
| Adjustments related to stock-based compensation: |  |  |  |  |  |  |  |  |  |
| Cost of sales | 7,075 |  |  |  |  | 3,959 |  |  |  |  |  |
| Operating expenses | 82,064 |  |  |  |  | 60,055 |  |  |  |  |  |
| Total adjustments to GAAP income before income tax provision | 89,139 |  |  |  |  | 64,014 |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments | (19,201) |  |  |  |  | (15,873) |  |  |  |  |  |
| Non-GAAP net income - basic | $ | 238,223 |  |  |  |  | $ | 472,468 |  |  |  |  |  |
| GAAP net income - basic | $ | 168,285 |  |  |  |  | $ | 424,327 |  |  |  |  |  |
| Convertible notes interest charge, net of tax | 1,680 |  |  |  |  | 2,749 |  |  |  |  |  |
| GAAP net income - diluted | $ | 169,965 |  |  |  |  | $ | 427,076 |  |  |  |  |  |
| Non-GAAP net income - basic | $ | 238,223 |  |  |  |  | $ | 472,468 |  |  |  |  |  |
| Convertible notes interest charge, net of tax | 1,680 |  |  |  |  | 2,749 |  |  |  |  |  |
| Non-GAAP net income - diluted | $ | 239,903 |  |  |  |  | $ | 475,217 |  |  |  |  |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |  |  |
| Basic - GAAP | 595,624 |  |  |  |  | 589,558 |  |  |  |  |  |
| Basic - Non-GAAP | 595,624 |  |  |  |  | 589,558 |  |  |  |  |  |
| Diluted - GAAP | 663,235 |  |  |  |  | 639,148 |  |  |  |  |  |
| Non-GAAP adjustment | 13,782 |  |  |  |  | 8,930 |  |  |  |  |  |
| Diluted - Non-GAAP | 677,017 |  |  |  |  | 648,078 |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:83]
Reconciliation of GAAP to Non-GAAP EPS:

[0001375365-25-000029:8k_2_02:84]
|  | Three Months Ended |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |
| GAAP Net Income per common share - basic | $ | 0.28 |  |  |  |  | $ | 0.72 |  |  |  |  |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - basic | 0.15 |  |  |  |  | 0.11 |  |  |  |  |  |
| Income tax - basic | (0.03) |  |  |  |  | (0.03) |  |  |  |  |  |
| Non-GAAP Net Income per common share - basic | $ | 0.40 |  |  |  |  | $ | 0.80 |  |  |  |  |  |
| GAAP net income per common share - diluted | $ | 0.26 |  |  |  |  | $ | 0.67 |  |  |  |  |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - diluted | 0.13 |  |  |  |  | 0.09 |  |  |  |  |  |
| Income tax - diluted | (0.04) |  |  |  |  | (0.03) |  |  |  |  |  |
| Non-GAAP Net Income per common share – diluted | $ | 0.35 |  |  |  |  | $ | 0.73 |  |  |  |  |  |

[0001375365-25-000029:8k_2_02:85]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000029:8k_2_02:86]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000029:8k_2_02:87]
(in thousands, except per share amounts)

[0001375365-25-000029:8k_2_02:88]
(unaudited)

[0001375365-25-000029:8k_2_02:89]
GAAP to Non-GAAP Effective Tax Rate:

[0001375365-25-000029:8k_2_02:90]
|  | Three Months Ended |  |  |
|  | September 30, 2025 |  |  |  | September 30, 2024 |  |  |  |  |
| GAAP effective tax rate | 19.3 | % |  |  |  | 15.0 | % |  |  |  |  |
| Total adjustments to GAAP provision to income tax | 0.6 | % |  |  |  | 1.1 | % |  |  |  |  |
| Non-GAAP effective tax rate | 19.9 | % |  |  |  | 16.1 | % |  |  |  |  |
