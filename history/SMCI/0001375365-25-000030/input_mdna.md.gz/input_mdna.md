# SMCI MD&A — 0001375365-25-000030


## mdna

[0001375365-25-000030:mdna:1]
[same as prior period, unchanged from 0001375365-25-000014:mdna:1]

[0001375365-25-000030:mdna:2]
The following discussion and analysis should be read in conjunction with the condensed consolidated financial statements and the related footnotes included elsewhere in this Quarterly Report on Form 10-Q, and the Annual Report on Form 10-K for the fiscal year ended June 30, 2025, which includes our consolidated financial statements for the fiscal years ended June 30, 2025 and 2024.

[0001375365-25-000030:mdna:3]
[same as prior period, unchanged from 0001375365-25-000014:mdna:3]

[0001375365-25-000030:mdna:4]
We are a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, we are committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. As a Total IT Solutions manufacturer, our offerings include server, artificial intelligence (“AI”) systems, storage, IoT devices, switches, software, and support services. Supermicro's expertise in motherboard, power, and chassis design drives our ability to develop and produce next-generation innovations, from cloud to edge, for our global customers. Our products are designed and manufactured in-house across facilities in the United States, Taiwan, and the Netherlands. Leveraging our global operations for scale and efficiency, we optimize solutions to improve TCO while reducing environmental impact through Green Computing initiatives. Our award-winning portfolio of Server Building Block Solutions empowers customers to tailor systems precisely to their exact workloads and applications. By selecting from a broad family of flexible and reusable building blocks, customers can configure a comprehensive range of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions, including air-conditioned, free air, and liquid cooling solutions.

[0001375365-25-000030:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. For the three months ended September 30, 2025 and 2024, our net income was $168.3 million and $424.3 million, respectively.

[0001375365-25-000030:mdna:6]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offerings and enhance customer service and support, particularly as we increase our focus on large enterprise and data center customers. A key component of our strategy is our DCBBS, which significantly reduces data center build time and enables full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services, and ongoing maintenance. To further expand our market share, we also recognize the need to strengthen our network of sales partners and distribution channels.

[0001375365-25-000030:mdna:7]
We measure our financial success based on various key indicators, including growth in net sales, gross profit margin, operating margin, and net income per common share. In addition to these financial metrics, a critical non-financial indicator of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. To support this, we work closely with the developers and manufacturers of key components, allowing us to integrate emerging technologies as they become available. Our ability to quickly bring new products to market, which we believe is enabled by our Building Block Solution architecture and has historically enabled us to capitalize on major technology transitions such as the launch of new GPUs, microprocessors and storage technologies. Accordingly, we closely monitor the product introduction cycles of industry leaders, including NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others. This strategic focus directly informs our research and development investments, as we continue to allocate resources toward both our current initiatives and future product innovation.

[0001375365-25-000030:mdna:8]
SMCI | Q1 2026 Form 10-Q | 33

[0001375365-25-000030:mdna:9]
AI and Data Centers

[0001375365-25-000030:mdna:10]
The growing use of AI, which requires enhanced datacenter capabilities, has substantially increased demand for our products. We expect this trend to continue, with further demand for datacenter expansion driven by the AI market. As a result, we will continue to enhance our product capabilities and expand our service offerings, including DCBBS to address the growing demand in the AI market and datacenter markets. We believe that our ability to tailor certain products to the unique needs of these sectors sets us apart from many competitors and positions us to capture an even greater market share going forward.

[0001375365-25-000030:mdna:11]
[same as prior period, unchanged from 0001375365-25-000014:mdna:11]

[0001375365-25-000030:mdna:12]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints, tariffs, and global economic and geopolitical developments, have had and may continue to have direct and indirect impacts on our business and results of operations, particularly demand for our products and net sales. While difficult to isolate and quantify, these macroeconomic factors have also impacted and may continue to impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Further, while many of these macroeconomic factors could have a long term impact, others may have a short term impact which could lead to our financial results not being comparable on a period-to-period basis.

[0001375365-25-000030:mdna:13]
[same as prior period, unchanged from 0001375365-25-000014:mdna:13]

[0001375365-25-000030:mdna:14]
The following is a summary of our financial highlights for the three months ended September 30, 2025 and 2024:

[0001375365-25-000030:mdna:15]
|  |  | Three Months Ended September 30, |
|  |  | 2025 |  | 2024 |
| Net sales |  | $ | 5,017,790 |  |  | $ | 5,937,256 |  |
| Gross profit |  | $ | 467,373 |  |  | $ | 775,580 |  |
| Total operating expenses |  | $ | 285,117 |  |  | $ | 266,381 |  |
| Income from operations |  | $ | 182,256 |  |  | $ | 509,199 |  |
| Net income |  | $ | 168,285 |  |  | $ | 424,327 |  |
| Net income per diluted share |  | $ | 0.26 |  |  | $ | 0.67 |  |

[0001375365-25-000030:mdna:16]
•Net sales decreased by 15.5% in the three months ended September 30, 2025 as compared to the three months ended September 30, 2024, primarily due to the timing of several substantial customer orders received only in late September, which prevented the related GPU and SuperRack products from being shipped within the quarter. The decrease also reflects changes in product mix and a modest reduction in average selling prices as we continued to price our products competitively.

[0001375365-25-000030:mdna:17]
•Gross margin decreased to 9.3% in the three months ended September 30, 2025 from 13.1% in the three months ended September 30, 2024, primarily due to our strategy to offer competitive pricing to gain market share, change in product and customer mix, and higher manufacturing related expenses.

[0001375365-25-000030:mdna:18]
•Operating expenses increased by 7.0% in the three months ended September 30, 2025 as compared to the three months ended September 30, 2024, primarily due to higher headcount and increases in salary and stock-based compensation.

[0001375365-25-000030:mdna:19]
•Net income decreased to $168.3 million in the three months ended September 30, 2025 as compared to $424.3 million in the three months ended September 30, 2024, which was primarily due to decrease in gross profit and increase in operating and other expenses.

[0001375365-25-000030:mdna:20]
SMCI | Q1 2026 Form 10-Q | 34

[0001375365-25-000030:mdna:21]
[same as prior period, unchanged from 0001375365-25-000014:mdna:20]

[0001375365-25-000030:mdna:22]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which are prepared in accordance with U.S. GAAP. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. On an ongoing basis, we regularly evaluate our accounting estimates based on historical experience and on various other assumptions that we believe are reasonable under the circumstances. The actual impact on our financial performance could differ from these estimates under different assumptions or conditions.

[0001375365-25-000030:mdna:23]
An accounting estimate is considered critical if both (i) the nature of the estimates or assumptions is material due to the levels of subjectivity and judgment involved, and (ii) the impact within a reasonable range of outcomes of the estimates and assumptions is material to our condensed consolidated financial statements. Critical accounting estimates in the areas of inventories, revenue recognition, and income taxes, when applicable, have the greatest potential impact on our condensed consolidated financial statements. Therefore, we consider these to be our critical accounting estimates.

[0001375365-25-000030:mdna:24]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001375365-25-000030:mdna:25]
[same as prior period, unchanged from 0001375365-25-000014:mdna:23]

[0001375365-25-000030:mdna:26]
[same as prior period, unchanged from 0001375365-25-000014:mdna:24]

[0001375365-25-000030:mdna:27]
[same as prior period, unchanged from 0001375365-25-000014:mdna:25]

[0001375365-25-000030:mdna:28]
Net sales primarily consist of sales of our server and storage solutions, including systems and related services, subsystems, and accessories. The key factors that impact net sales of our server and storage systems are the number of servers and racks sold, as well as the average selling prices per server or rack. For subsystems and accessories, the main drivers of net sales are the number of units shipped and the average selling price per unit. The prices for our server and storage systems can vary widely depending on the configuration, including factors such as speed, functionality and performance of key components, including CPUs, GPUs, SSDs, cooling systems, and memory. Similarly, the prices for our subsystems and accessories fluctuate depending on the relative value of the specific item being purchased, such as power supplies, server boards, chassis or other accessories.

[0001375365-25-000030:mdna:29]
SMCI | Q1 2026 Form 10-Q | 35

[0001375365-25-000030:mdna:30]
[same as prior period, unchanged from 0001375365-25-000014:mdna:27]

[0001375365-25-000030:mdna:31]
[same as prior period, unchanged from 0001375365-25-000014:mdna:28]

[0001375365-25-000030:mdna:32]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 3.4% and 4.6% of cost of sales on our condensed consolidated statements of operations for the three months ended September 30, 2025 and 2024, respectively. For further details on our dealings with related parties, see Note 10, “Related Party Transactions” in the notes to the condensed consolidated financial statements.

[0001375365-25-000030:mdna:33]
[same as prior period, unchanged from 0001375365-25-000014:mdna:29]

[0001375365-25-000030:mdna:34]
[same as prior period, unchanged from 0001375365-25-000014:mdna:30]

[0001375365-25-000030:mdna:35]
[same as prior period, unchanged from 0001375365-25-000014:mdna:31]

[0001375365-25-000030:mdna:36]
[same as prior period, unchanged from 0001375365-25-000014:mdna:32]

[0001375365-25-000030:mdna:37]
[same as prior period, unchanged from 0001375365-25-000014:mdna:34]

[0001375365-25-000030:mdna:38]
[same as prior period, unchanged from 0001375365-25-000014:mdna:35]

[0001375365-25-000030:mdna:39]
Other Income, Net and Interest Expense

[0001375365-25-000030:mdna:40]
Other income, net and interest expense consists primarily of interest earned on our investments and cash balances, interest incurred on our debt, and foreign exchange gains and losses.

[0001375365-25-000030:mdna:41]
Income Tax Provision

[0001375365-25-000030:mdna:42]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income, and stock-based compensation.

[0001375365-25-000030:mdna:43]
SMCI | Q1 2026 Form 10-Q | 36

[0001375365-25-000030:mdna:44]
The following table presents certain items of our condensed consolidated statements of operations for the three months ended September 30, 2025 and 2024 (in millions):

[0001375365-25-000030:mdna:45]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net sales | $ | 5,017.8 |  |  | $ | 5,937.3 |  |  |  |  |  |
| Cost of sales | 4,550.4 |  |  | 5,161.7 |  |  |  |  |  |
| Gross profit | 467.4 |  |  | 775.6 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 173.3 |  |  | 132.2 |  |  |  |  |  |
| Sales and marketing | 47.9 |  |  | 68.9 |  |  |  |  |  |
| General and administrative | 63.9 |  |  | 65.3 |  |  |  |  |  |
| Total operating expenses | 285.1 |  |  | 266.4 |  |  |  |  |  |
| Income from operations | 182.3 |  |  | 509.2 |  |  |  |  |  |
| Other income, net | 51.2 |  |  | 7.2 |  |  |  |  |  |
| Interest expense | (24.9) |  |  | (17.4) |  |  |  |  |  |
| Income before income tax provision | 208.6 |  |  | 499.0 |  |  |  |  |  |
| Income tax provision | (40.2) |  |  | (74.7) |  |  |  |  |  |
| Share of loss from equity investee, net of taxes | (0.1) |  |  | — |  |  |  |  |  |
| Net income | $ | 168.3 |  |  | $ | 424.3 |  |  |  |  |  |

[0001375365-25-000030:mdna:46]
The following table presents certain items of our condensed consolidated statements of operations expressed as a percentage of net sales for the three months ended September 30, 2025 and 2024:

[0001375365-25-000030:mdna:47]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |  |  |
| Cost of sales | 90.7 | % |  | 86.9 | % |  |  |  |  |  |  |
| Gross profit | 9.3 | % |  | 13.1 | % |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 3.5 | % |  | 2.2 | % |  |  |  |  |  |  |
| Sales and marketing | 1.0 | % |  | 1.2 | % |  |  |  |  |  |  |
| General and administrative | 1.3 | % |  | 1.1 | % |  |  |  |  |  |  |
| Total operating expenses | 5.8 | % |  | 4.5 | % |  |  |  |  |  |  |
| Income from operations | 3.5 | % |  | 8.6 | % |  |  |  |  |  |  |
| Other income, net | 1.0 | % |  | 0.1 | % |  |  |  |  |  |  |
| Interest expense | (0.5) | % |  | (0.3) | % |  |  |  |  |  |  |
| Income before income tax provision | 4.0 | % |  | 8.4 | % |  |  |  |  |  |  |
| Income tax provision | (0.8) | % |  | (1.3) | % |  |  |  |  |  |  |
| Share of loss from equity investee, net of taxes | — | % | * | — | % | * |  |  |  |  |  |
| Net income | 3.2 | % |  | 7.1 | % |  |  |  |  |  |  |

[0001375365-25-000030:mdna:48]
[same as prior period, unchanged from 0001375365-25-000014:mdna:46]

[0001375365-25-000030:mdna:49]
SMCI | Q1 2026 Form 10-Q | 37

[0001375365-25-000030:mdna:50]
Nets Sales

[0001375365-25-000030:mdna:51]
The following table presents net sales for the three months ended September 30, 2025 and 2024 (dollars in millions):

[0001375365-25-000030:mdna:52]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,017.8 |  |  | $ | 5,937.3 |  |  | $ | (919.5) |  |  | (15.5) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:53]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:54]
The $919.5 million or 15.5% decrease in net sales was primarily due to the timing of several substantial orders, which were only received in late September, such that the products covered by those orders could not be shipped during the quarter ended September 30, 2025. This was caused principally by customer configuration upgrades and delays in data center readiness. A decrease in our average selling price compared to the prior quarter ended September 30, 2024 also contributed modestly to the decline in net sales of server and storage systems, as we maintained our strategy of pricing our products competitively to retain and or gain market shares. This was most pronounced in declining billings for GPU & Super Racks of $527.8 million or 11.7% year over year, including liquid-cooled and air-cooled servers that are generally more complex and of higher average selling price. Additionally, sales across other product categories decreased by $349.9 million, or 28.5%, including Traditional Storage, SuperBlade, Ultra Server, and other product lines.

[0001375365-25-000030:mdna:55]
[same as prior period, unchanged from 0001375365-25-000014:mdna:58]

[0001375365-25-000030:mdna:56]
The following table presents net sales by geographic region for the three months ended September 30, 2025 and 2024 (dollars in millions):

[0001375365-25-000030:mdna:57]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| United States | $ | 1,834.5 |  |  | $ | 4,241.3 |  |  | $ | (2,406.8) |  |  | (56.7) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 36.6 | % |  | 71.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 2,318.3 |  |  | $ | 954.6 |  |  | $ | 1,363.7 |  |  | 142.9 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 46.2 | % |  | 16.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe | $ | 716.3 |  |  | $ | 645.9 |  |  | $ | 70.4 |  |  | 10.9 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 14.3 | % |  | 10.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | $ | 148.7 |  |  | $ | 95.5 |  |  | $ | 53.2 |  |  | 55.7 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.9 | % |  | 1.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 5,017.8 |  |  | $ | 5,937.3 |  |  | $ | (919.5) |  |  | (15.5) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:58]
SMCI | Q1 2026 Form 10-Q | 38

[0001375365-25-000030:mdna:59]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:60]
The $919.5 million or 15.5% decrease in total net sales was primarily driven by the timing of several substantial customer orders that were received only in late September, which prevented the related products including GPU servers, HPC systems, and rack-scale solutions, which generally have higher average selling prices, from being shipped during the quarter ended September 30, 2025. This was caused principally by customer configuration upgrades and delays in data center readiness. The decrease also reflects a shift in product mix and a modest reduction in average selling prices as we continued to price our products competitively to retain and gain market share. This impact was most notable in the United States, where net sales decreased by $2,406.8 million, or 56.7%, compared to the prior quarter ended September 30, 2024.

[0001375365-25-000030:mdna:61]
Cost of Sales, Gross Profit, and Gross Margin

[0001375365-25-000030:mdna:62]
Cost of sales and gross margin for the three months ended September 30, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000030:mdna:63]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Cost of sales | $ | 4,550.4 |  | $ | 5,161.7 |  | $ | (611.3) |  |  | (11.8) | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 467.4 |  | $ | 775.6 |  | $ | (308.2) |  |  | (39.7) | % |  |  |  |  |  |  |  |  |
| Gross margin | 9.3 | % |  | 13.1 | % |  |  |  | (3.8) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:64]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:65]
The $611.3 million or 11.8% decrease in cost of sales was primarily driven by a net decrease of approximately  $754.5 million or 14.1% in certain products including GPU servers, HPC, and rack-scale solutions, consistent with the lower shipment volume during the three months ended September 30, 2025 as compared to the three months ended September 30, 2024, resulting from the timing of several substantial orders that were received near the end of the quarter and therefore could not be fulfilled. This was caused principally by customer configuration upgrades and delays in data center readiness. This decrease was partially offset by a $91.3 million or 29.8% decrease in vendor rebates, a $42.1 million or 398.3% increase in tariff expenses driven by new trade policies, as well as a $27.4 million or 299.3% increase in inventory write-down adjustments from aged inventory.

[0001375365-25-000030:mdna:66]
The 3.8% decrease in the gross margin percentage was due to a change in product and customer mix.

[0001375365-25-000030:mdna:67]
[same as prior period, unchanged from 0001375365-25-000014:mdna:76]

[0001375365-25-000030:mdna:68]
Operating expenses for the three months ended September 30, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000030:mdna:69]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Research and development | $ | 173.3 |  | $ | 132.2 |  | $ | 41.1 |  |  | 31.1 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 3.5 | % |  | 2.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 47.9 |  | $ | 68.9 |  | $ | (21.0) |  |  | (30.5) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.0 | % |  | 1.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 63.9 |  | $ | 65.3 |  | $ | (1.4) |  |  | (2.1) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.3 | % |  | 1.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 285.1 |  | $ | 266.4 |  | $ | 18.7 |  |  | 7.0 | % |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:70]
SMCI | Q1 2026 Form 10-Q | 39

[0001375365-25-000030:mdna:71]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:72]
Research and development expenses. The $41.1 million or 31.1% increase in research and development expenses was primarily driven by an increase in employee-related costs of $41.7 million, or 33.4%, mainly comprised of a $20.9 million, or 57.2%, increase in stock-based compensation, and $17.8 million, or 22.0%, increase in salaries, as we expanded our workforce and invested in key talent. These increases along with other immaterial cost increases were partially offset by a $2.0 million, or 29.3%, increase in research and development fees received from certain suppliers and customers.

[0001375365-25-000030:mdna:73]
Sales and marketing expenses. The $21.0 million or 30.5% decrease in sales and marketing expenses was primarily driven by a $19.9 million, or 289.3%, decrease in advertising and promotion expenses due to a marketing reimbursement of $17.2 million, or 291.6%, received from certain business partners for reimbursed product release and promotion efforts, and a $8.9 million, or 34.7%, decrease in sales commission bonuses during the three months ended September 30, 2025 as compared to the three months ended September 30, 2024. These decreases along with other minor cost decreases were partially offset by an increase in employee-related costs, mainly due to a $4.5 million, or 21.7%, increase in salaries and a $3.3 million, or 43.0%, increase in stock-based compensation, similarly to our research and development expenses as we expanded our workforce and invested in key talent company-wide.

[0001375365-25-000030:mdna:74]
General and administrative expenses. The $1.4 million or 2.1% decrease in general and administrative expenses was primarily attributable to a $6.8 million or 63.3%  reduction in audit and tax fees, driven by an absence of additional costs related to the delayed filing of our fiscal 2024 Form 10-K, and a $2.1 million or 68.8% reduction in excise tax expense driven by decrease in sales compared to prior-year quarter which reduced the related tax expense. These reductions were partially offset by a $2.1 million or 39.3% increase in consulting fees, driven by greater use of external consultants to support and enhance our financing activities and other initiatives. Additionally, there was a $3.6 million or 30.3% net increase in employee-related costs including salaries, bonus, and stock-based compensation as we expanded our workforce and invested in key talent, and a $1.9 million or 6.2% increase in facilities costs such as rental costs, utility costs, and indirect depreciation costs, which are related to our efforts to expand our production capacity in order to support growing customer demands.

[0001375365-25-000030:mdna:75]
Other Income, Net and Interest Expense

[0001375365-25-000030:mdna:76]
Other income, net and interest expense for the three months ended September 30, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000030:mdna:77]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income, net | $ | 51.2 |  |  | $ | 7.2 |  |  | $ | 44.0 |  |  | 611.1 | % |  |  |  |  |  |  |  |  |
| Interest expense | (24.9) |  |  | (17.4) |  |  | (7.5) |  |  | 43.1 | % |  |  |  |  |  |  |  |  |
| Other income, net and interest expense | $ | 26.3 |  |  | $ | (10.2) |  |  | $ | 36.5 |  |  | (357.8) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:78]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:79]
The $44.0 million or 611.1% increase in other income, net was primarily driven by higher interest income and favorable foreign exchange rate fluctuations. This is mainly comprised of an increase of $43.3 million or 543.2% in interest income for the three months ended September 30, 2025 as compared to the three months ended September 30, 2024, reflecting increased cash deposits funded by the proceeds from our convertible notes issuance, a $6.5 million or 459.6% gain from mark-to-market adjustments on a marketable equity securities investment, and a $4.4 million or 1687.7% from foreign currency exchange rate fluctuations resulting from a stronger U.S. dollar in the first quarter of fiscal 2026. These gains were partially offset by a $12.0 million impairment  loss related to our non-marketable investment during the first quarter of fiscal 2026.

[0001375365-25-000030:mdna:80]
The $7.5 million or 43.1% increase in interest expense was primarily driven by a $21.9 million or 1187.3% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025. This increase was partially offset by a $13.9 million or 94.1% decrease in interest expense associated with our Bank of America line of credit and term loans, which were fully repaid in November 2024.

[0001375365-25-000030:mdna:81]
SMCI | Q1 2026 Form 10-Q | 40

[0001375365-25-000030:mdna:82]
Income Tax Provision

[0001375365-25-000030:mdna:83]
Income tax provision and effective tax rates for the three months ended September 30, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000030:mdna:84]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income tax provision | $ | (40.2) |  |  | $ | (74.7) |  | $ | 34.5 |  |  | (46.2) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | (0.8) | % |  | (1.3) | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective tax rate | (19.3) | % |  | (15.0) | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-25-000030:mdna:85]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001375365-25-000030:mdna:86]
Income tax provision decreased by $34.5 million or 46.2% primarily due to a decline in worldwide income before income tax provision that reduced tax expense by $58.4 million which was offset by a lower tax benefit from stock-based compensation of approximately $14.5 million, and the effects of other immaterial tax items of approximately $9.4 million. The income before income tax provision for the first quarter of fiscal 2026 was $208.6 million, which is a decrease of $290.5 million or 58.2%.

[0001375365-25-000030:mdna:87]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended September 30, 2025, is higher than that for the three months ended September 30, 2024, primarily due to a significant decrease in stock-based compensation tax deduction and lower research tax credit because of lower stock vesting price in the three months ended September 30, 2025.

[0001375365-25-000030:mdna:88]
[same as prior period, unchanged from 0001375365-25-000014:mdna:105]

[0001375365-25-000030:mdna:89]
We have financed our growth primarily with funds generated from operations, as well as utilizing borrowing facilities, selling our common stock, and issuing convertible notes. Recent drivers of liquidity changes included an increase in the need for working capital due to higher levels of inventory required to support future growing revenues, greater requests for longer payment terms from customers due to increasing system costs and to a lesser extent longer supply chain lead times on certain key components. Our cash and cash equivalents were $4.2 billion and $5.2 billion as of September 30, 2025 and June 30, 2025, respectively. Our cash and cash equivalents held in foreign locations was $974.2 million and $607.2 million as of September 30, 2025 and June 30, 2025, respectively.

[0001375365-25-000030:mdna:90]
Amounts held outside of the United States are typically used to meet non-U.S. liquidity needs. Repatriations of these funds are generally not subject to U.S. federal income tax, though state income or foreign withholding taxes may apply. In cases where local restrictions prevent the intercompany transfer of funds, our strategy is to retain cash balances outside the U.S. and meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes on the repatriation of amounts held outside the U.S. to materially affect our overall liquidity, financial condition, or results of operations.

[0001375365-25-000030:mdna:91]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these condensed consolidated financial statements. We continue to assess financing options that may be necessary to support the growth of our business.

[0001375365-25-000030:mdna:92]
SMCI | Q1 2026 Form 10-Q | 41

[0001375365-25-000030:mdna:93]
Our key cash flow metrics were as follows (in millions):

[0001375365-25-000030:mdna:94]
|  | Three Months Ended September 30, |  | Change |  |  |  |
|  | 2025 |  | 2024 |  | $ |  |  |  |
| Net cash (used in) provided by operating activities | $ | (917.5) |  |  | $ | 408.9 |  |  | $ | (1,326.4) |  |  |  |  |
| Net cash used in investing activities | (32.3) |  |  | (44.3) |  |  | 12.0 |  |  |  |  |
| Net cash (used in) provided by financing activities | (18.7) |  |  | 49.9 |  |  | (68.6) |  |  |  |  |
| Effect of exchange rate fluctuations on cash | (4.6) |  |  | 4.5 |  |  | (9.1) |  |  |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (973.1) |  |  | $ | 419.0 |  |  | $ | (1,392.1) |  |  |  |  |

[0001375365-25-000030:mdna:95]
[same as prior period, unchanged from 0001375365-25-000014:mdna:112]

[0001375365-25-000030:mdna:96]
Net cash used in operating activities during the three months ended September 30, 2025 mostly consisted of $168.3 million net income adjusted for certain non-cash items, such as $89.1 million of share-based compensation expense, $12.3 million of depreciation and amortization expense, and changes in working capital. The decrease in cash flows from operating activities during the three months ended September 30, 2025 compared to the three months ended September 30, 2024 was due to a decrease in net income, and increase in an inventory purchases, partially offset by higher stock-based compensation, and other operational spending.

[0001375365-25-000030:mdna:97]
[same as prior period, unchanged from 0001375365-25-000014:mdna:114]

[0001375365-25-000030:mdna:98]
Net cash used in investing activities during the three months ended September 30, 2025 mostly consisted of $32.3 million of purchases of property, plant, and equipment as we continued to invest in real estate, servers, data centers, and network infrastructure. The decrease in cash used in investing activities during the three months ended September 30, 2025 compared to the three months ended September 30, 2024, was due to decreases in purchases of property, plant, and equipment.

[0001375365-25-000030:mdna:99]
[same as prior period, unchanged from 0001375365-25-000014:mdna:116]

[0001375365-25-000030:mdna:100]
Net cash used in financing activities during the three months ended September 30, 2025 mostly consisted of payment for withholding taxes related to settlement of equity awards of $43.6 million, partially offset by net proceeds from lines of credit and term loans of $17.0 million. The increase in cash used by financing activities during the three months ended September 30, 2025 compared to the three months ended September 30, 2024, was mostly due to decrease in net proceeds from lines of credits and term loans.

[0001375365-25-000030:mdna:101]
[same as prior period, unchanged from 0001375365-25-000014:mdna:118]

[0001375365-25-000030:mdna:102]
Refer to Note 7, “Lines of Credit and Term Loans”, in the notes to the condensed consolidated financial statements in this Quarterly Report for further information on our outstanding debt.

[0001375365-25-000030:mdna:103]
Refer to Note 8, “Convertible Notes”, in the notes to the condensed consolidated financial statements in this Quarterly Report for further information on the amendment of the terms of the 2029 Convertible Notes, and the issuance of the 2028 Convertible Notes and the 2030 Convertible Notes.

[0001375365-25-000030:mdna:104]
[same as prior period, unchanged from 0001375365-25-000014:mdna:121]

[0001375365-25-000030:mdna:105]
We anticipate our capital expenditures for the remainder of fiscal year 2026 will be in range of $200.0 million to $220.0 million, primarily relating to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on net sales growth, productivity, expenses, service levels and customer retention).

[0001375365-25-000030:mdna:106]
SMCI | Q1 2026 Form 10-Q | 42

[0001375365-25-000030:mdna:107]
Our future capital requirements will depend on a variety of factors, including our growth rate, the timing and scale of investments to support product development, the expansion of sales and marketing efforts, the launch of new and enhanced software and services offerings, and continued investments in our office facilities and IT system infrastructure.

[0001375365-25-000030:mdna:108]
Contractual Obligations

[0001375365-25-000030:mdna:109]
Our estimated future obligations as of September 30, 2025, include both current and long-term obligations. For our long-term debt, as noted in Note 7, “Lines of Credit and Term Loans” in the notes to the condensed consolidated financial statements, we have a current obligation of $100.6 million and a long-term obligation of $25.2 million. Additionally, as noted in Note 8, “Convertible Notes” in the notes to the condensed consolidated financial statements, we have a convertible debt obligation of $4,725.0 million. Under our operating leases as noted in Note 9, “Leases” in the notes to the condensed consolidated financial statements, we have a current obligation of $30.1 million and a long-term obligation of $359.8 million. As noted in Note 13, “Commitments and Contingencies” in the notes to the condensed consolidated financial statements, we have current obligations related to non-cancelable purchase commitments of $11.6 billion.

[0001375365-25-000030:mdna:110]
[same as prior period, unchanged from 0001375365-25-000014:mdna:124]

[0001375365-25-000030:mdna:111]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Note 1, “Organization and Summary of Significant Accounting Policies”, in our notes to the condensed consolidated financial statements in this Quarterly Report.

[0001375365-25-000030:mdna:112]
SMCI | Q1 2026 Form 10-Q | 43
