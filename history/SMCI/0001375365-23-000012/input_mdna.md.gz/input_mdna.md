# SMCI MD&A — 0001375365-23-000012


## mdna

[0001375365-23-000012:mdna:1]
[same as prior period, unchanged from 0001375365-22-000119:mdna:1]

[0001375365-23-000012:mdna:2]
[same as prior period, unchanged from 0001375365-22-000119:mdna:2]

[0001375365-23-000012:mdna:3]
[same as prior period, unchanged from 0001375365-22-000119:mdna:3]

[0001375365-23-000012:mdna:4]
[same as prior period, unchanged from 0001375365-22-000119:mdna:4]

[0001375365-23-000012:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended December 31, 2022 increased to $176.2 million from $41.9 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We also believe that we must continue to expand our software and customer service and support offerings, particularly as we increasingly focus on AI/ML applications and larger enterprise customers. Additionally, we intend to focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor, GPU and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessor, GPU, memory and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-23-000012:mdna:6]
SMCI | Q2 2023 Form 10-Q | 33

[0001375365-23-000012:mdna:7]
[same as prior period, unchanged from 0001375365-22-000119:mdna:7]

[0001375365-23-000012:mdna:8]
The following is a summary of our financial highlights of the second quarter of fiscal year 2023:

[0001375365-23-000012:mdna:9]
•Net sales increased by 53.8% in the three months ended December 31, 2022 as compared to the three months ended December 31, 2021.

[0001375365-23-000012:mdna:10]
•Gross margin increased to 18.7% in the three months ended December 31, 2022 from 14.0% in the three months ended December 31, 2021.

[0001375365-23-000012:mdna:11]
•Operating expenses increased by 8.5% as compared to the three months ended December 31, 2021 and were equal to 6.7% and 9.6% of net sales in the three months ended December 31, 2022 and 2021, respectively.

[0001375365-23-000012:mdna:12]
•Effective tax rate decreased to 14.3% in the three months ended December 31, 2022 from 15.4% in the three months ended December 31, 2021.

[0001375365-23-000012:mdna:13]
[same as prior period, unchanged from 0001375365-22-000119:mdna:13]

[0001375365-23-000012:mdna:14]
[same as prior period, unchanged from 0001375365-22-000119:mdna:14]

[0001375365-23-000012:mdna:15]
[same as prior period, unchanged from 0001375365-22-000119:mdna:15]

[0001375365-23-000012:mdna:16]
SMCI | Q2 2023 Form 10-Q | 34

[0001375365-23-000012:mdna:17]
[same as prior period, unchanged from 0001375365-22-000119:mdna:17]

[0001375365-23-000012:mdna:18]
[same as prior period, unchanged from 0001375365-22-000119:mdna:18]

[0001375365-23-000012:mdna:19]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 81.3 | % |  | 86.0 | % |  | 81.3 | % |  | 86.3 | % |
| Gross profit | 18.7 | % |  | 14.0 | % |  | 18.7 | % |  | 13.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 3.9 | % |  | 5.6 | % |  | 4.0 | % |  | 5.9 | % |
| Sales and marketing | 1.6 | % |  | 1.9 | % |  | 1.6 | % |  | 2.0 | % |
| General and administrative | 1.2 | % |  | 2.2 | % |  | 1.2 | % |  | 2.2 | % |
| Total operating expenses | 6.7 | % |  | 9.6 | % |  | 6.8 | % |  | 10.1 | % |
| Income from operations | 12.0 | % |  | 4.4 | % |  | 11.9 | % |  | 3.6 | % |
| Other income, net | (0.4) | % |  | (0.1) | % |  | 0.1 | % |  | — | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.2) | % |  | (0.1) | % |
| Income before income tax provision | 11.5 | % |  | 4.2 | % |  | 11.8 | % |  | 3.5 | % |
| Income tax provision | (1.6) | % |  | (0.6) | % |  | (1.9) | % |  | (0.5) | % |
| Share of income (loss) from equity investee, net of taxes | (0.1) | % |  | — | % |  | (0.1) | % |  | — | % |
| Net income | 9.8 | % |  | 3.6 | % |  | 9.8 | % |  | 3.1 | % |

[0001375365-23-000012:mdna:20]
[same as prior period, unchanged from 0001375365-22-000119:mdna:20]

[0001375365-23-000012:mdna:21]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of systems and compute nodes sold and the average selling prices per system and node. The number of nodes and systems shipped will vary each quarter depending on our customers specific server application or workload. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as GPUs, SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-23-000012:mdna:22]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPU/GPU, memory and storage.

[0001375365-23-000012:mdna:23]
SMCI | Q2 2023 Form 10-Q | 35

[0001375365-23-000012:mdna:24]
The following table presents net sales by product type for the three and six months ended December 31, 2022 and 2021 (dollars in millions):

[0001375365-23-000012:mdna:25]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Server and storage systems | $ | 1,660.9 |  |  | $ | 986.1 |  |  | $ | 674.8 |  |  | 68.4 | % |  | $ | 3,374.0 |  |  | $ | 1,835.9 |  |  | $ | 1,538.1 |  |  | 83.8 | % |
| Percentage of total net sales | 92.1 | % |  | 84.1 | % |  |  |  |  |  | 92.3 | % |  | 83.3 | % |  |  |  |  |
| Subsystems and accessories | $ | 142.3 |  |  | $ | 186.3 |  |  | $ | (44.0) |  |  | (23.6) | % |  | $ | 281.3 |  |  | $ | 369.2 |  |  | $ | (87.9) |  |  | (23.8) | % |
| Percentage of total net sales | 7.9 | % |  | 15.9 | % |  |  |  |  |  | 7.7 | % |  | 16.7 | % |  |  |  |  |
| Total net sales | $ | 1,803.2 |  |  | $ | 1,172.4 |  |  | $ | 630.8 |  |  | 53.8 | % |  | $ | 3,655.3 |  |  | $ | 2,205.1 |  |  | $ | 1,450.2 |  |  | 65.8 | % |

[0001375365-23-000012:mdna:26]
[same as prior period, unchanged from 0001375365-22-000119:mdna:26]

[0001375365-23-000012:mdna:27]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:28]
The period-over-period increase in net sales of our server and storage systems was due to a 20.6% increase in the number of units of compute nodes sold and a 41.1% increase in the average selling price.

[0001375365-23-000012:mdna:29]
The period-over-period decrease in net sales for our subsystems and accessories of 23.6% was primarily due to the focus on allocating constrained components as a result of supply chain shortage to build and ship server and storage systems rather than selling them as part of subsystems and accessories.

[0001375365-23-000012:mdna:30]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:31]
The period-over-period increase in net sales of our server and storage systems was due to a 27.8% increase in the number of units of compute nodes sold and a 45.7% increase in the average selling price. The increase in the number of units of compute nodes shipped was primarily due to increased demand of GPU systems.

[0001375365-23-000012:mdna:32]
The period-over-period decrease in net sales for our subsystems and accessories of 23.8% was primarily due to the focus on allocating constrained components as a result of supply chain shortage to build and ship server and storage systems rather than selling them as part of subsystems and accessories.

[0001375365-23-000012:mdna:33]
The following table presents net sales by geographic region for the three and six months ended December 31, 2022 and 2021 (dollars in millions):

[0001375365-23-000012:mdna:34]
|  | Three Months Ended December 31, |  | Change |  | Change |  | Six Months Ended December 31, |  | Change |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| United States | $ | 1,091.4 |  |  | $ | 638.2 |  |  | $ | 453.2 |  |  | 71.0 | % |  | $ | 2,386.9 |  |  | $ | 1,199.2 |  |  | $ | 1,187.7 |  |  | 99.0 | % |
| Percentage of total net sales | 60.5 | % |  | 54.4 | % |  |  |  |  |  | 65.3 | % |  | 54.4 | % |  |  |  |  |
| Asia | $ | 330.7 |  |  | $ | 284.1 |  |  | $ | 46.6 |  |  | 16.4 | % |  | $ | 600.7 |  |  | $ | 547.2 |  |  | $ | 53.5 |  |  | 9.8 | % |
| Percentage of total net sales | 18.4 | % |  | 24.2 | % |  |  |  |  |  | 16.4 | % |  | 24.8 | % |  |  |  |  |
| Europe | $ | 312.5 |  |  | $ | 215.5 |  |  | $ | 97.0 |  |  | 45.0 | % |  | $ | 547.6 |  |  | $ | 395.1 |  |  | $ | 152.5 |  |  | 38.6 | % |
| Percentage of total net sales | 17.3 | % |  | 18.4 | % |  |  |  |  |  | 15.0 | % |  | 17.9 | % |  |  |  |  |
| Others | $ | 68.6 |  |  | $ | 34.7 |  |  | $ | 33.9 |  |  | 97.7 | % |  | $ | 120.1 |  |  | $ | 63.7 |  |  | $ | 56.4 |  |  | 88.5 | % |
| Percentage of total net sales | 3.8 | % |  | 3.0 | % |  |  |  |  |  | 3.3 | % |  | 2.9 | % |  |  |  |  |
| Total net sales | $ | 1,803.2 |  |  | $ | 1,172.4 |  |  |  |  |  |  | $ | 3,655.3 |  |  | $ | 2,205.1 |  |  |  |  |  |

[0001375365-23-000012:mdna:35]
SMCI | Q2 2023 Form 10-Q | 36

[0001375365-23-000012:mdna:36]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:37]
The period-over-period increase in overall net sales is the result of increased selling prices led primarily by higher priced GPU based products and increased quantity of overall product shipments. The increase in the United States is primarily due to higher sales driven by high demand of GPU based server and storage systems. The increase of net sales in Europe was primarily due to increases in net sales in Netherlands, UK and Germany.

[0001375365-23-000012:mdna:38]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:39]
The period-over-period increase in overall net sales is the result of increased selling prices led primarily by higher priced GPU based products and increased quantity of overall product shipments. The increase in the United States is primarily due to higher sales driven by high demand of GPU based server and storage systems. The increase of net sales in Europe was primarily due to increases in net sales in Netherlands, UK and Germany.

[0001375365-23-000012:mdna:40]
[same as prior period, unchanged from 0001375365-22-000119:mdna:35]

[0001375365-23-000012:mdna:41]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production as well as efficiencies or leverage gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in average selling prices are not matched by corresponding changes in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions.

[0001375365-23-000012:mdna:42]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-23-000012:mdna:43]
Cost of sales and gross margin for the three and six months ended December 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000012:mdna:44]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Cost of sales | $ | 1,465.8 |  |  | $ | 1,008.7 |  |  | $ | 457.1 |  |  | 45.3 | % |  | $ | 2,970.4 |  |  | $ | 1,903.3 |  |  | $ | 1,067.1 |  |  | 56.1 | % |
| Gross profit | $ | 337.4 |  |  | $ | 163.7 |  |  | $ | 173.7 |  |  | 106.1 | % |  | $ | 685.0 |  |  | $ | 301.9 |  |  | $ | 383.1 |  |  | 126.9 | % |
| Gross margin | 18.7 | % |  | 14.0 | % |  |  |  | 4.7 | % |  | 18.7 | % |  | 13.7 | % |  |  |  | 5.0 | % |

[0001375365-23-000012:mdna:45]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:46]
The period-over-period increase in cost of sales was primarily attributed to an increase of $433.1 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $22.1 million increase in overhead costs, a $15.8 million increase in inventory charges offset by a $13.9 million decrease in freight costs.

[0001375365-23-000012:mdna:47]
The period-over-period increase in the gross margin percentage was primarily due to a reduction in the cost of freight and certain key components as well as efficiencies or leverage gained from higher production volume in our facilities. These key components included hard disk drives, solid-state drives, motherboards and other components.

[0001375365-23-000012:mdna:48]
SMCI | Q2 2023 Form 10-Q | 37

[0001375365-23-000012:mdna:49]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:50]
The period-over-period increase in cost of sales was primarily attributed to an increase of $1,017.2 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $41.5 million increase in overhead costs, a $21.7 million increase in excess and obsolete inventory charges offset by a $13.3 million decrease in freight costs.

[0001375365-23-000012:mdna:51]
The period-over-period increase in the gross margin percentage was primarily due to a reduction in the cost of freight and certain key components as well as efficiencies or leverage gained from higher production volume in our facilities. These key components included hard disk drives, solid-state drives, motherboards and other components.

[0001375365-23-000012:mdna:52]
[same as prior period, unchanged from 0001375365-22-000119:mdna:43]

[0001375365-23-000012:mdna:53]
[same as prior period, unchanged from 0001375365-22-000119:mdna:44]

[0001375365-23-000012:mdna:54]
[same as prior period, unchanged from 0001375365-22-000119:mdna:45]

[0001375365-23-000012:mdna:55]
[same as prior period, unchanged from 0001375365-22-000119:mdna:47]

[0001375365-23-000012:mdna:56]
Operating expenses for the three and six months ended December 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000012:mdna:57]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Research and development | $ | 70.7 |  |  | $ | 65.5 |  |  | $ | 5.2 |  |  | 7.9 | % |  | $ | 145.0 |  |  | $ | 130.6 |  |  | $ | 14.4 |  |  | 11.0 | % |
| Percentage of total net sales | 3.9 | % |  | 5.6 | % |  |  |  |  |  | 4.0 | % |  | 5.9 | % |  |  |  |  |
| Sales and marketing | $ | 28.4 |  |  | $ | 22.0 |  |  | $ | 6.4 |  |  | 29.1 | % |  | $ | 57.8 |  |  | $ | 43.6 |  |  | $ | 14.2 |  |  | 32.6 | % |
| Percentage of total net sales | 1.6 | % |  | 1.9 | % |  |  |  |  |  | 1.6 | % |  | 2.0 | % |  |  |  |  |
| General and administrative | $ | 23.1 |  |  | $ | 25.3 |  |  | $ | (2.2) |  |  | (8.7) | % |  | $ | 46.9 |  |  | $ | 47.5 |  |  | $ | (0.6) |  |  | (1.3) | % |
| Percentage of total net sales | 1.2 | % |  | 2.2 | % |  |  |  |  |  | 1.2 | % |  | 2.2 | % |  |  |  |  |
| Total operating expenses | $ | 122.2 |  |  | $ | 112.7 |  |  | $ | 9.5 |  |  | 8.4 | % |  | $ | 249.7 |  |  | $ | 221.7 |  |  | $ | 28.0 |  |  | 12.6 | % |
| Percentage of total net sales | 6.7 | % |  | 9.6 | % |  |  |  |  |  | 6.8 | % |  | 10.1 | % |  |  |  |  |

[0001375365-23-000012:mdna:58]
SMCI | Q2 2023 Form 10-Q | 38

[0001375365-23-000012:mdna:59]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:60]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $12.6 million increase in personnel expenses primarily due to increase in headcount and equity grants partially offset by $7.4 million higher in research and development credits provided from certain suppliers and customers for our development efforts.

[0001375365-23-000012:mdna:61]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $6.7 million increase in personnel expenses primarily due to increased headcount partially offset by $0.3 million lower in advertising and other expenses.

[0001375365-23-000012:mdna:62]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a $2.3 million decrease in legal and litigation settlement expenses partially offset by an increase of $0.1 million in personnel related expenses and other expenses.

[0001375365-23-000012:mdna:63]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:64]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $20.3 million increase in personnel expenses, a $1.4 million increase in product development costs partially offset by $7.3 million higher research and development credits provided by certain suppliers and customers for our development efforts.

[0001375365-23-000012:mdna:65]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $12.2 million increase in personnel expenses as a result of a higher head count and an increase of $1.3 million in advertising and other expenses.

[0001375365-23-000012:mdna:66]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a $2.3 million decrease in legal and litigation settlement expenses partially offset by an increase of $1.7 million in personnel expenses and other expenses.

[0001375365-23-000012:mdna:67]
Interest Expense and Other (Expense) Income, Net

[0001375365-23-000012:mdna:68]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-23-000012:mdna:69]
[same as prior period, unchanged from 0001375365-22-000119:mdna:56]

[0001375365-23-000012:mdna:70]
Interest expense and other (expense) income, net for the three and six months ended December 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000012:mdna:71]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Other (expense) income, net | $ | (6.3) |  |  | $ | (0.6) |  |  | $ | (5.7) |  |  | 950.0 | % |  | $ | 1.7 |  |  | $ | (0.6) |  |  | $ | 2.3 |  |  | (383.3) | % |
| Interest expense | (1.8) |  |  | (1.2) |  |  | (0.6) |  |  | 50.0 | % |  | (5.7) |  |  | (2.0) |  |  | (3.7) |  |  | 185.0 | % |
| Interest expense and other (expense) income, net | $ | (8.1) |  |  | $ | (1.8) |  |  | $ | (6.3) |  |  | 350.0 | % |  | $ | (4.0) |  |  | $ | (2.6) |  |  | $ | (1.4) |  |  | 53.8 | % |

[0001375365-23-000012:mdna:72]
SMCI | Q2 2023 Form 10-Q | 39

[0001375365-23-000012:mdna:73]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:74]
The change of $6.3 million in interest expense and other expense, net was primarily attributable to a $5.7 million increase in foreign exchange loss due to unfavorable currency fluctuations and $0.6 million increase in interest expense due to both an increase in average loan balances and interest rates.

[0001375365-23-000012:mdna:75]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:76]
The change of $1.4 million in interest expense and other (expense) income, net was primarily attributable to a $2.3 million increase in foreign exchange gain due to favorable currency fluctuations offset by a $3.7 million increase in interest expense due to both an increase in average loan balances and interest rates.

[0001375365-23-000012:mdna:77]
[same as prior period, unchanged from 0001375365-22-000119:mdna:62]

[0001375365-23-000012:mdna:78]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock-based compensation.

[0001375365-23-000012:mdna:79]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000012:mdna:80]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Income tax provision | $ | 29.6 |  |  | $ | 7.6 |  |  | $ | 22.0 |  |  | 289.5 | % |  | $ | 68.5 |  |  | $ | 10.9 |  |  | $ | 57.6 |  |  | 528.4 | % |
| Percentage of total net sales | 1.6 | % |  | 0.6 | % |  |  |  |  |  | 1.9 | % |  | 0.5 | % |  |  |  |  |
| Effective tax rate | 14.3 | % |  | 15.4 | % |  |  |  |  |  | 15.9 | % |  | 14.1 | % |  |  |  |  |

[0001375365-23-000012:mdna:81]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:82]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended December 31, 2022, is lower than that for the three months ended December 31, 2021, primarily due to an increase of stock compensation tax deduction for the three months ended December 31, 2022, and due to the release of tax reserves.

[0001375365-23-000012:mdna:83]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:84]
The income tax provision and effective tax rate for the six months ended December 31, 2022 is higher than that for the six months ended December 31, 2021, primarily due to significant increase in taxable income in the first two quarters of fiscal year 2023, whereas the income tax deduction for items such as R&D credit and foreign tax deduction comparably did not increase in the same proportion.

[0001375365-23-000012:mdna:85]
[same as prior period, unchanged from 0001375365-22-000119:mdna:68]

[0001375365-23-000012:mdna:86]
[same as prior period, unchanged from 0001375365-22-000119:mdna:69]

[0001375365-23-000012:mdna:87]
SMCI | Q2 2023 Form 10-Q | 40

[0001375365-23-000012:mdna:88]
Share of (loss) income from equity investee, net of taxes for the three and six months ended December 31, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000012:mdna:89]
|  | Three Months EndedDecember 31, |  | Change | Six Months EndedDecember 31, |  | Change |
|  | 2022 |  | 2021 |  | $ |  | % |  | 2022 |  | 2021 |  | $ |  | % |
| Share of (loss) income from equity investee, net of taxes | $ | (1.4) |  |  | $ | 0.2 |  |  | $ | (1.6) |  |  | n/m (1) |  | $ | (2.2) |  |  | $ | 0.6 |  |  | $ | (2.8) |  |  | n/m (1) |
| Percentage of total net sales | (0.1) | % |  | — | % |  |  |  |  |  | (0.1) | % |  | — | % |  |  |  |  |

[0001375365-23-000012:mdna:90]
(1) n/m - Not meaningful

[0001375365-23-000012:mdna:91]
Comparison of Three Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:92]
The period-over-period decrease of $1.6 million in share of (loss) income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-23-000012:mdna:93]
Comparison of Six Months Ended December 31, 2022 and 2021

[0001375365-23-000012:mdna:94]
The period-over-period decrease of $2.8 million in share of (loss) income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-23-000012:mdna:95]
[same as prior period, unchanged from 0001375365-22-000119:mdna:75]

[0001375365-23-000012:mdna:96]
We have financed our growth primarily with funds generated from increased profits from operations, in addition to utilizing borrowing facilities. We draw on our credit facilities to fund working capital requirements due to the higher level of inventories and accounts receivable based on increasing sales as well as financing the acquisition of property, plant and equipment. We also received funds from the exercise of employee stock options. Our cash and cash equivalents were $304.6 million and $267.4 million as of December 31, 2022 and June 30, 2022, respectively. Our cash in foreign locations was $168.5 million and $169.5 million as of December 31, 2022 and June 30, 2022, respectively.

[0001375365-23-000012:mdna:97]
[same as prior period, unchanged from 0001375365-22-000119:mdna:77]

[0001375365-23-000012:mdna:98]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these consolidated financial statements. In August 2022, we entered into a new general credit agreement with E.SUN Bank. This New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million in loans that will support the growth of our Taiwan business.

[0001375365-23-000012:mdna:99]
[same as prior period, unchanged from 0001375365-22-000119:mdna:79]

[0001375365-23-000012:mdna:100]
SMCI | Q2 2023 Form 10-Q | 41

[0001375365-23-000012:mdna:101]
[same as prior period, unchanged from 0001375365-22-000119:mdna:80]

[0001375365-23-000012:mdna:102]
|  | Six Months EndedDecember 31, |  | Change |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 474.7 |  |  | $ | (187.7) |  |  | $ | 662.4 |  |  |  |  |
| Net cash (used in) investing activities | $ | (20.6) |  |  | $ | (24.3) |  |  | $ | 3.7 |  |  |  |  |
| Net cash (used in) provided by financing activities | $ | (415.8) |  |  | $ | 227.2 |  |  | $ | (643.0) |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 36.5 |  |  | $ | 15.1 |  |  | $ | 21.4 |  |  |  |  |

[0001375365-23-000012:mdna:103]
[same as prior period, unchanged from 0001375365-22-000119:mdna:82]

[0001375365-23-000012:mdna:104]
Net cash provided by operating activities increased by $662.4 million for the six months ended December 31, 2022 as compared to the six months ended December 31, 2021. The increase was primarily due to an increase of $369.2 million of various non-cash items, including the collection of accounts receivables from the higher sales as well lower levels of inventory needed from an improved supply chain in the quarter ended December 31, 2022, and an increase in net income of $293.2 million.

[0001375365-23-000012:mdna:105]
[same as prior period, unchanged from 0001375365-22-000119:mdna:84]

[0001375365-23-000012:mdna:106]
Net cash used in investing activities decreased by $3.7 million for the six months ended December 31, 2022 as compared to the six months ended December 31, 2021 primarily due to decrease in purchases of property, plant and equipment in the six months ended December 31, 2022.

[0001375365-23-000012:mdna:107]
[same as prior period, unchanged from 0001375365-22-000119:mdna:86]

[0001375365-23-000012:mdna:108]
Net cash used by financing activities for the six months ended December 31, 2022 was $415.8 million while net cash provided by financing activities for the six months ended December 31, 2021 was $227.2 million. The change in cash flows from financing activities of $643.0 million was primarily due to a decrease of $443.7 million in proceeds from borrowings and an increase of $197.4 million in repayment of debt.

[0001375365-23-000012:mdna:109]
[same as prior period, unchanged from 0001375365-22-000119:mdna:89]

[0001375365-23-000012:mdna:110]
[same as prior period, unchanged from 0001375365-22-000119:mdna:90]

[0001375365-23-000012:mdna:111]
[same as prior period, unchanged from 0001375365-22-000119:mdna:91]

[0001375365-23-000012:mdna:112]
We anticipate our capital expenditures for the remainder of fiscal year 2023 will be approximately $33 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We are evaluating an expansion of our manufacturing into Malaysia, and during the second quarter of fiscal year 2023 entered into a letter of understanding to acquire land in Malaysia. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. In the event we acquire such land, we anticipate additional future capital expenditures for the remainder of fiscal year 2023 of approximately $14 million for such initiative. In addition, we will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-23-000012:mdna:113]
We intend to continue to focus our capital expenditures in fiscal year 2023 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our office facilities and our IT system infrastructure.

[0001375365-23-000012:mdna:114]
SMCI | Q2 2023 Form 10-Q | 42

[0001375365-23-000012:mdna:115]
[same as prior period, unchanged from 0001375365-22-000119:mdna:94]

[0001375365-23-000012:mdna:116]
[same as prior period, unchanged from 0001375365-22-000119:mdna:95]

[0001375365-23-000012:mdna:117]
SMCI | Q2 2023 Form 10-Q | 43
