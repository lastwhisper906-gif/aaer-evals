# SMCI notes — 0001375365-23-000012


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-23-000012:notes:1]
[same as prior period, unchanged from 0001375365-22-000119:notes:1]

[0001375365-23-000012:notes:2]
[same as prior period, unchanged from 0001375365-22-000119:notes:2]

[0001375365-23-000012:notes:3]
[same as prior period, unchanged from 0001375365-22-000119:notes:3]

[0001375365-23-000012:notes:4]
[same as prior period, unchanged from 0001375365-22-000119:notes:4]

[0001375365-23-000012:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.

[0001375365-23-000012:notes:6]
[same as prior period, unchanged from 0001375365-22-000119:notes:6]

[0001375365-23-000012:notes:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 14.1% and 17.6% of total purchases for the three months ended December 31, 2022, and two suppliers accounted for 22.1% and 6.5% of total purchases for the three months ended December 31, 2021. Two suppliers accounted for 15.3% and 22.3% of total purchases for the six months ended December 31, 2022, and two suppliers accounted for 21.2% and 6.4% of total purchases for the six months ended December 31, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.7% and 9.4% of total cost of sales for the three months ended December 31, 2022 and 2021, respectively, and a combined 6.6% and 9.5% of total cost of sales for the six months ended December 31, 2022 and 2021, respectively.

[0001375365-23-000012:notes:8]
[same as prior period, unchanged from 0001375365-22-000119:notes:8]

[0001375365-23-000012:notes:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended December 31, 2022, and one customer accounted for 15.8% of the net sales for the six months ended December 31, 2022. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2021. No single customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2022. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.

[0001375365-23-000012:notes:10]
[same as prior period, unchanged from 0001375365-22-000119:notes:10]

[0001375365-23-000012:notes:11]
[same as prior period, unchanged from 0001375365-22-000119:notes:11]

[0001375365-23-000012:notes:12]
[same as prior period, unchanged from 0001375365-22-000119:notes:12]

[0001375365-23-000012:notes:13]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In December 2022, FASB issued an Accounting Standards Update (ASU) for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The ASU defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC and Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have material impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-23-000012:notes:14]
[same as prior period, unchanged from 0001375365-22-000119:notes:14]

[0001375365-23-000012:notes:15]
[same as prior period, unchanged from 0001375365-22-000119:notes:15]

[0001375365-23-000012:notes:16]
[same as prior period, unchanged from 0001375365-22-000119:notes:16]

[0001375365-23-000012:notes:17]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Server and storage systems | $ | 1,660,931 |  |  | $ | 986,052 |  |  | $ | 3,373,987 |  |  | $ | 1,835,908 |  |
| Subsystems and accessories | 142,264 |  |  | 186,367 |  |  | 281,338 |  |  | 369,241 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |

[0001375365-23-000012:notes:18]
[same as prior period, unchanged from 0001375365-22-000119:notes:18]

[0001375365-23-000012:notes:19]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2022 and 2021, of net sales by geographic region (in thousands):

[0001375365-23-000012:notes:20]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 1,091,391 |  |  | $ | 638,207 |  |  | $ | 2,386,895 |  |  | $ | 1,199,155 |  |
| Asia | 330,711 |  |  | 284,107 |  |  | 600,735 |  |  | 547,193 |  |
| Europe | 312,533 |  |  | 215,451 |  |  | 547,607 |  |  | 395,145 |  |
| Other | 68,560 |  |  | 34,654 |  |  | 120,088 |  |  | 63,656 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |

[0001375365-23-000012:notes:21]
[same as prior period, unchanged from 0001375365-22-000119:notes:21]

[0001375365-23-000012:notes:22]
[same as prior period, unchanged from 0001375365-22-000119:notes:22]

[0001375365-23-000012:notes:23]
[same as prior period, unchanged from 0001375365-22-000119:notes:23]

[0001375365-23-000012:notes:24]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2022, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $27.5 million and $61.0 million, respectively.

[0001375365-23-000012:notes:25]
Deferred revenue increased $46.2 million as of December 31, 2022 as compared to the fiscal year ended June 30, 2022 and was mainly due to the deferral on invoiced amounts for service contracts during the period exceeded the recognition of revenue from contracts entered into in prior periods. The service contracts deferral increase was offset partly by a $2.4 million decrease in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-23-000012:notes:26]
[same as prior period, unchanged from 0001375365-22-000119:notes:26]

[0001375365-23-000012:notes:27]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2022 was $280.0 million. The Company expects to recognize approximately 43% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-23-000012:notes:28]
[same as prior period, unchanged from 0001375365-22-000119:notes:28]

[0001375365-23-000012:notes:29]
[same as prior period, unchanged from 0001375365-22-000119:notes:29]

[0001375365-23-000012:notes:30]
[same as prior period, unchanged from 0001375365-22-000119:notes:30]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-23-000012:notes:31]
The following is a summary for the three and six months ended December 31, 2022 and 2021, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-23-000012:notes:32]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2022 and 2021 (in thousands, except per share amounts):

[0001375365-23-000012:notes:33]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 176,167 |  |  | $ | 41,932 |  |  | $ | 360,583 |  |  | $ | 67,369 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 53,160 |  |  | 51,314 |  |  | 52,726 |  |  | 51,055 |  |
| Effect of dilutive securities | 2,984 |  |  | 2,197 |  |  | 2,701 |  |  | 2,158 |  |
| Weighted-average diluted shares | 56,144 |  |  | 53,511 |  |  | 55,427 |  |  | 53,213 |  |
| Basic net income per common share | $ | 3.31 |  |  | $ | 0.82 |  |  | $ | 6.84 |  |  | $ | 1.32 |  |
| Diluted net income per common share | $ | 3.14 |  |  | $ | 0.78 |  |  | $ | 6.51 |  |  | $ | 1.27 |  |

[0001375365-23-000012:notes:34]
For the three and six months ended December 31, 2022 and 2021, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 211,729 and 419,423 for the three months ended December 31, 2022 and 2021, respectively, and 259,562 and 1,501,560 for the six months ended December 31, 2022 and 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-23-000012:notes:35]
[same as prior period, unchanged from 0001375365-22-000119:notes:35]

[0001375365-23-000012:notes:36]
[same as prior period, unchanged from 0001375365-22-000119:notes:36]

[0001375365-23-000012:notes:37]
|  | December 31, 2022 |  | June 30, 2022 |
| Finished goods | $ | 972,150 |  |  | $ | 1,025,555 |  |
| Work in process | 155,739 |  |  | 209,576 |  |
| Purchased parts and raw materials | 293,928 |  |  | 310,475 |  |
| Total inventories | $ | 1,421,817 |  |  | $ | 1,545,606 |  |

[0001375365-23-000012:notes:38]
During the three and six months ended December 31, 2022, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $15.8 million and $25.4 million, respectively, and $0.2 million and $3.7 million, for the three and six months ended December 31, 2021, respectively. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.

[0001375365-23-000012:notes:39]
[same as prior period, unchanged from 0001375365-22-000119:notes:39]

[0001375365-23-000012:notes:40]
|  | December 31, 2022 |  | June 30, 2022 |
| Other receivables (1) | $ | 133,034 |  |  | $ | 138,054 |  |
| Prepaid expenses | 9,507 |  | 5,632 |
| Deferred service costs | 6,626 |  | 5,562 |
| Prepaid income tax | — |  |  | 2,352 |
| Restricted cash | — |  |  | 251 |  |
| Other | 5,757 |  |  | 6,948 |  |
| Total prepaid expenses and other current assets | $ | 154,924 |  |  | $ | 158,799 |  |

[0001375365-23-000012:notes:41]
(1) Other receivables are receivables from contract manufacturers based on certain buy-sell arrangements of $116.3 million and $98.9 million as of December 31, 2022 and June 30, 2022, respectively.

[0001375365-23-000012:notes:42]
Cash, Cash Equivalents and Restricted Cash:

[0001375365-23-000012:notes:43]
|  | December 31, 2022 |  | June 30, 2022 |
| Cash and cash equivalents | $ | 304,595 |  |  | $ | 267,397 |  |
| Restricted cash included in prepaid expenses and other current assets | — |  |  | 251 |  |
| Restricted cash included in other assets | 493 |  |  | 911 |  |
| Total cash, cash equivalents and restricted cash | $ | 305,088 |  |  | $ | 268,559 |  |

[0001375365-23-000012:notes:44]
[same as prior period, unchanged from 0001375365-22-000119:notes:44]

[0001375365-23-000012:notes:45]
|  | December 31, 2022 |  | June 30, 2022 |
| Buildings | $ | 143,496 |  |  | $ | 143,509 |  |
| Machinery and equipment | 122,634 |  |  | 113,665 |  |
| Land | 84,616 |  |  | 84,616 |  |
| Furniture and fixtures | 49,328 |  |  | 43,282 |  |
| Building and leasehold improvements | 45,812 |  |  | 45,169 |  |
| Software | 23,610 |  |  | 23,186 |  |
| Building construction in progress | 303 |  |  | 303 |  |
|  | 469,799 |  |  | 453,730 |  |
| Accumulated depreciation and amortization | (180,544) |  |  | (167,758) |  |
| Property, plant and equipment, net | $ | 289,255 |  |  | $ | 285,972 |  |

[0001375365-23-000012:notes:46]
[same as prior period, unchanged from 0001375365-22-000119:notes:46]

[0001375365-23-000012:notes:47]
|  | December 31, 2022 |  | June 30, 2022 |
| Operating lease right-of-use asset | $ | 20,827 |  |  | $ | 23,679 |  |
| Deferred service costs, non-current | 8,875 |  |  | 6,316 |  |
| Prepaid expense, non-current | 1,935 |  |  | 2,011 |  |
| Deposits | 1,685 |  |  | 1,069 |  |
| Investment in auction rate security | 1,590 |  |  | 1,590 |  |
| Restricted cash, non-current | 493 |  |  | 911 |  |
| Other | 1,841 |  |  | 1,956 |  |
| Total other assets | $ | 37,246 |  |  | $ | 37,532 |  |

[0001375365-23-000012:notes:48]
[same as prior period, unchanged from 0001375365-22-000119:notes:48]

[0001375365-23-000012:notes:49]
|  | December 31, 2022 |  | June 30, 2022 |
| Accrued payroll and related expenses | $ | 51,400 |  |  | $ | 57,736 |  |
| Contract manufacturers liabilities | 34,440 |  |  | 41,125 |  |
| Customer deposits | 24,136 |  |  | 30,421 |  |
| Accrued legal liabilities (Note 11) | — |  |  | 18,250 |  |
| Accrued cooperative marketing expenses | 9,973 |  |  | 8,757 |  |
| Accrued warranty costs | 8,668 |  |  | 9,073 |  |
| Operating lease liability | 7,117 |  |  | 7,139 |  |
| Accrued professional fees | 2,497 |  |  | 4,281 |  |
| Other | 31,636 |  |  | 35,637 |  |
| Total accrued liabilities | $ | 169,866 |  |  | $ | 212,419 |  |

[0001375365-23-000012:notes:50]
[same as prior period, unchanged from 0001375365-22-000119:notes:50]

[0001375365-23-000012:notes:51]
[same as prior period, unchanged from 0001375365-22-000119:notes:51]

[0001375365-23-000012:notes:52]
[same as prior period, unchanged from 0001375365-22-000119:notes:52]

[0001375365-23-000012:notes:53]
In September 2021, after the Company had closed its books for the year ended June 30, 2021, the Board decided to exercise its discretion to reduce the amount to be paid to the Chief Executive Officer for the first tranche to $2.0 million, which was paid in the quarter ended December 31, 2021. As a result of the Board’s decision to reduce the amount to be paid under the first tranche, the Company adjusted the $3.6 million expense previously recorded for the first tranche to the new amount of $2.0 million, which resulted in the Company recognizing a $1.6 million benefit from this adjustment during the quarter ended September 30, 2021. This performance award to the Chief Executive Officer was concluded in the year ended June 30, 2022. As such, there is no further transaction thereafter. There was no benefit recognized during the three and six months ended December 31, 2022. The benefit recognized during the three and six months ended December 31, 2021 was none and $1.6 million, respectively.

[0001375365-23-000012:notes:54]
[same as prior period, unchanged from 0001375365-22-000119:notes:54]

[0001375365-23-000012:notes:55]
|  | December 31, 2022 |  | June 30, 2022 |
| Accrued unrecognized tax benefits including related interests and penalties, non-current | $ | 18,315 |  |  | $ | 18,866 |  |
| Operating lease liability, non-current | 13,924 |  | 16,661 |
| Accrued warranty costs, non-current | 4,608 |  |  | 3,064 |  |
| Other | 466 |  |  | 549 |  |
| Total other long-term liabilities | $ | 37,313 |  |  | $ | 39,140 |  |

[0001375365-23-000012:notes:56]
[same as prior period, unchanged from 0001375365-22-000119:notes:56]

[0001375365-23-000012:notes:57]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Balance, beginning of the period | $ | 12,703 |  |  | $ | 12,233 |  |  | $ | 12,136 |  |  | $ | 12,863 |  |
| Provision for warranty | 8,933 |  |  | 6,057 |  |  | 17,550 |  |  | 12,442 |  |
| Costs utilized | (8,553) |  |  | (6,722) |  |  | (17,026) |  |  | (13,920) |  |
| Change in estimated liability for pre-existing warranties | 193 |  |  | 15 |  |  | 616 |  |  | 198 |  |
| Balance, end of the period | 13,276 |  |  | 11,583 |  |  | 13,276 |  |  | 11,583 |  |
| Current portion | 8,668 |  |  | 8,903 |  |  | 8,668 |  |  | 8,903 |  |
| Non-current portion | $ | 4,608 |  |  | $ | 2,680 |  |  | $ | 4,608 |  |  | $ | 2,680 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-23-000012:notes:58]
Fair Value DisclosureThe financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of December 31, 2022 and June 30, 2022. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-23-000012:notes:59]
[same as prior period, unchanged from 0001375365-22-000119:notes:59]

[0001375365-23-000012:notes:60]
The following table sets forth the Company’s financial instruments as of December 31, 2022 and June 30, 2022, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-23-000012:notes:61]
| December 31, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,419 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,419 |  |
| Certificates of deposit (2) | — |  |  | 573 |  |  | — |  |  | 573 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,419 |  |  | $ | 573 |  |  | $ | 1,590 |  |  | $ | 22,582 |  |
| June 30, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,220 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,220 |  |
| Certificates of deposit (2) | — |  |  | 832 |  |  | — |  |  | 832 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,220 |  |  | $ | 832 |  |  | $ | 1,590 |  |  | $ | 22,642 |  |

[0001375365-23-000012:notes:62]
(1) $20.3 million and $20.0 million in money market funds are included cash and cash equivalents and $0.1 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2022 and June 30, 2022, respectively.

[0001375365-23-000012:notes:63]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.1 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.3 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2022 and June 30, 2022, respectively.

[0001375365-23-000012:notes:64]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. Based on this assessment during the three and six months ended December 31, 2022, there were no indications that the Company’s investments had credit losses.

[0001375365-23-000012:notes:65]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and six months ended December 31, 2022 and 2021.

[0001375365-23-000012:notes:66]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and six months ended December 31, 2022 and 2021.

[0001375365-23-000012:notes:67]
The following is a summary of the Company’s investment in an auction rate security as of December 31, 2022 and June 30, 2022 (in thousands):

[0001375365-23-000012:notes:68]
[same as prior period, unchanged from 0001375365-22-000119:notes:68]

[0001375365-23-000012:notes:69]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and six months ended December 31, 2022 and 2021.

[0001375365-23-000012:notes:70]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of December 31, 2022 and June 30, 2022, total debt of $170.1 million and $596.8 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-23-000012:notes:71]
[same as prior period, unchanged from 0001375365-22-000119:notes:71]

[0001375365-23-000012:notes:72]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $1.2 million as of December 31, 2022 and June 30, 2022. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three and six months ended December 31, 2022 and 2021, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three and six months ended December 31, 2022 and 2021.


## us-gaap:DebtDisclosureTextBlock

[0001375365-23-000012:notes:73]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands):

[0001375365-23-000012:notes:74]
|  | December 31, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| 2022 CTBC Credit Line | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | — |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,070 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 38,904 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,501 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,859 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 40,372 |  |
| Total term loans | 170,142 |  |  | 162,919 |  |
| Total debt | 170,142 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 27,869 |  |  | 449,146 |  |
| Debt, non-current | $ | 142,273 |  |  | $ | 147,618 |  |

[0001375365-23-000012:notes:75]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-23-000012:notes:76]
Available borrowings and interest rates as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

[0001375365-23-000012:notes:77]
|  | December 31, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 5.56% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.88% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 30,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.425% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.075% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.275% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 2,594 |  | 1.62% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.62% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |

[0001375365-23-000012:notes:78]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 9. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022 for a more complete description of the Company's credit facilities.

[0001375365-23-000012:notes:79]
The Company entered into a new General Credit Agreement with ESUN Bank during the six months ended December 31, 2022 with the following terms:

[0001375365-23-000012:notes:80]
E.SUN Bank

[0001375365-23-000012:notes:81]
2022 E.SUN Bank Credit Facility

[0001375365-23-000012:notes:82]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through Super Micro Computer Inc., Taiwan, a Taiwan corporation and wholly-owned subsidiary of the Company (the “Taiwan Subsidiary”), entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US $30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan Subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

[0001375365-23-000012:notes:83]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Taiwan Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the New E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan Subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Taiwan Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of December 31, 2022, the amount outstanding under the Import O/A Loan was denominated in NTD and remeasured into US dollars of $55.8 million. The interest rate as of December 31, 2022 was 1.62% per annum. As of December 31, 2022 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $0.0 million and $7.8 million, respectively. The interest rate as of December 31, 2022 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of December 31, 2022, the amount available for future borrowing under the Import O/A Loan was $30.0 million.

[0001375365-23-000012:notes:84]
CTBC Bank

[0001375365-23-000012:notes:85]
2022 CTBC Credit Line

[0001375365-23-000012:notes:86]
Pursuant to banking practices in Taiwan to confirm loan agreements annually, on October 3, 2022, the Company through the Taiwan Subsidiary entered into an Agreement for Individually Negotiated Terms and Conditions with CTBC Bank Co., Ltd. (“CTBC Bank”) (such credit line, the “2022 CTBC Credit Line”) related to the prior 2021 CTBC credit lines (the “2021 CTBC Credit Lines”). The terms of the 2022 CTBC Credit Line remain substantially similar to the 2021 CTBC Credit Line, except the 2022 CTBC Credit Line made certain minor amendments to the monthly interest payment date. The total borrowing cap under the whole arrangement is $105.0 million and NTD 1,550.0 million ($55.4 million U.S. dollar equivalent).

[0001375365-23-000012:notes:87]
The Company, through the Taiwan Subsidiary, was party to that certain credit agreement, dated May 6, 2020, with CTBC Bank, which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent). As of December 31, 2022 and June 30, 2022, the amounts outstanding under the 2020 CTBC Term Loan Facility were $38.9 million and $40.4 million, respectively. The interest rates for these loans were 1.075% per annum as of December 31, 2022 and 0.825% as of June 30, 2022.

[0001375365-23-000012:notes:88]
The 2021 Credit Lines permitted borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the previously-existing ten-year, non-revolving term loan facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”). As of December 31, 2022 and June 30, 2022, under the 2021 CTBC Machine Loan, the amounts outstanding were $5.5 million and $5.5 million, respectively. The interest rates for these loans were 1.275% per annum as of December 31, 2022 and 1.025% as of June 30, 2022. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. As of December 31, 2022 and June 30, 2022, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were none and $84.8 million, respectively. The interest rates for these loans was 3.33% per annum as of December 31, 2022 and ranged from 1.80% to 2.52% as of June 30, 2022.

[0001375365-23-000012:notes:89]
As of December 31, 2022, the amount available for future borrowing under the 2022 CTBC Credit Line was $105 million. As of December 31, 2022, the net book value of land and building located in Bade, Taiwan, collateralizing the 2022 CTBC Credit Line was $76.1 million. The Company was in compliance with all financial covenants under 2022 CTBC Credit Line as of December 31, 2022.

[0001375365-23-000012:notes:90]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-23-000012:notes:91]
Fiscal Year:                                                                                                                                                                                             Principal Payments

[0001375365-23-000012:notes:92]
| Remainder of 2023 | $ | 10,453 |  |
| 2024 | 38,776 |  |
| 2025 | 42,720 |  |
| 2026 | 42,720 |  |
| 2027 | 18,559 |  |
| 2028 and thereafter | 16,914 |  |
| Total short-term and long-term debt | $ | 170,142 |  |

[0001375365-23-000012:notes:93]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-23-000012:notes:94]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2022 and 2021 were as follows (in thousands):

[0001375365-23-000012:notes:95]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating lease expense (including expense for lease agreements with related parties of $140 and $284 for the three and six months ended December 31, 2022, respectively, and $179 and $425 for the three and six months ended December 31, 2021, respectively) | $ | 2,115 |  |  | $ | 1,983 |  |  | $ | 4,225 |  |  | $ | 4,166 |  |
| Cash payments for operating leases (including payments to related parties of $127 and $257 for the three and six months ended December 31, 2022, respectively, and $211 and $490 for the three and six months ended December 31, 2021, respectively) | $ | 2,025 |  |  | $ | 2,008 |  |  | $ | 4,063 |  |  | $ | 4,213 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 274 |  |  | $ | 1,260 |  |  | $ | 1,024 |  |  | $ | 7,379 |  |

[0001375365-23-000012:notes:96]
During the three and six months ended December 31, 2022 and 2021, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three and six months ended December 31, 2022 were $0.4 million and $0.9 million, respectively. Non-lease variable payments expensed in the three and six months ended December 31, 2021 were $0.2 million and $0.5 million, respectively.

[0001375365-23-000012:notes:97]
As of December 31, 2022, the weighted average remaining lease term for operating leases was 3.4 years and the weighted average discount rate was 2.9%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of December 31, 2022 were as follows (in thousands):

[0001375365-23-000012:notes:98]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2023 |  | $ | 4,168 |  |
| 2024 |  | 6,927 |  |
| 2025 |  | 6,368 |  |
| 2026 |  | 2,625 |  |
| 2027 |  | 1,564 |  |
| 2028 and beyond |  | 535 |  |
| Total future lease payments |  | 22,187 |  |
| Less: Imputed interest |  | (1,146) |  |
| Present value of operating lease liabilities |  | $ | 21,041 |  |

[0001375365-23-000012:notes:99]
As of December 31, 2022, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-23-000012:notes:100]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 8, "Related Party Transactions," for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-23-000012:notes:101]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-23-000012:notes:102]
Dealings with Ablecom

[0001375365-23-000012:notes:103]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-23-000012:notes:104]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.5% and 88.3% of the chassis included in the products sold by the Company during the three months ended December 31, 2022 and 2021, respectively, and 91.8% and 90.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-23-000012:notes:105]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-23-000012:notes:106]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on December 31, 2022 were $27.4 million and $26.8 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-23-000012:notes:107]
Dealings with Compuware

[0001375365-23-000012:notes:108]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-23-000012:notes:109]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-23-000012:notes:110]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-23-000012:notes:111]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-23-000012:notes:112]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on December 31, 2022 were $170.2 million and $70.1 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-23-000012:notes:113]
Dealings with Investment in a Corporate Venture

[0001375365-23-000012:notes:114]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-23-000012:notes:115]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of December 31, 2022 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-23-000012:notes:116]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2022. No impairment charge was recorded for the three and six months ended December 31, 2022 or 2021.

[0001375365-23-000012:notes:117]
The Company sold products worth $6.0 million and $38.3 million to the Corporate Venture during the three months ended December 31, 2022 and 2021, respectively, and sold products worth $17.3 million and $53.5 million to the Corporate Venture during the six months ended December 31, 2022 and 2021, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2022 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $5.0 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of December 31, 2022 and June 30, 2022, respectively.

[0001375365-23-000012:notes:118]
The Company had the following balances related to transactions with its related parties as of December 31, 2022 and June 30, 2022 (in thousands):

[0001375365-23-000012:notes:119]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 |  |  | December 31, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 267 |  | $ | 404 |  | $ | 4,951 |  | $ | 7,992 |  |  |  | $ | 5,220 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,452 |  | $ | 4,816 |  | $ | 43,885 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 47,337 |  | $ | 24,412 |  |
| Accounts payable | $ | 38,874 |  | $ | 42,463 |  | $ | 49,232 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 88,106 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,522 |  | $ | 3,531 |  | $ | 18,005 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 19,527 |  | $ | 18,676 |  |

[0001375365-23-000012:notes:120]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-23-000012:notes:121]
The Company's results from transactions with its related parties for each of the three months ended December 31, 2022 and 2021, are as follows (in thousands):

[0001375365-23-000012:notes:122]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 3 |  | $ | 14,113 |  | $ | 3,302 |  | $ | 5,958 |  | $ | 38,311 |  | $ | — |  | $ | — |  | $ | 20,073 |  | $ | 41,616 |  |
| Purchases - inventory | $ | 46,715 |  | $ | 47,520 |  | $ | 52,028 |  | $ | 46,821 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,387 |  | $ | 98,743 |  | $ | 96,728 |  |
| Purchases - other miscellaneous items | $ | 2,763 |  | $ | 2,867 |  | $ | 279 |  | $ | 347 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,042 |  | $ | 3,214 |  |

[0001375365-23-000012:notes:123]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

[0001375365-23-000012:notes:124]
The Company's results from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):

[0001375365-23-000012:notes:125]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 3 |  | $ | 10 |  | $ | 27,872 |  | $ | 19,004 |  | $ | 17,251 |  | $ | 53,524 |  | $ | — |  | $ | — |  | $ | 45,126 |  | $ | 72,538 |  |
| Purchases - inventory | $ | 94,562 |  | $ | 98,309 |  | $ | 100,717 |  | $ | 82,050 |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,056 |  | $ | 195,279 |  | $ | 184,415 |  |
| Purchases - other miscellaneous items | $ | 7,526 |  | $ | 4,983 |  | $ | 537 |  | $ | 686 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 8,063 |  | $ | 5,669 |  |

[0001375365-23-000012:notes:126]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):

[0001375365-23-000012:notes:127]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 137 |  | $ | (66) |  | $ | 3,041 |  | $ | (25,789) |  | $ | — |  | $ | — |  | $ | 3,178 |  | $ | (25,854) |  |
| Changes in other receivable | $ | 1,364 |  | $ | 641 |  | $ | (24,289) |  | $ | (11,673) |  | $ | — |  | $ | — |  | $ | — |  | $ | (133) |  | $ | (22,925) |  | $ | (11,165) |  |
| Changes in accounts payable | $ | (3,589) |  | $ | 3,573 |  | $ | 4,340 |  | $ | 22,367 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 751 |  | $ | 25,940 |  |
| Changes in accrued liabilities | $ | (2,009) |  | $ | (212) |  | $ | 2,860 |  | $ | 2,713 |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | 851 |  | $ | 1,501 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 4,366 |  | $ | 1,678 |  | $ | 148 |  | $ | 92 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,514 |  | $ | 1,770 |  |
| Unpaid property, plant and equipment | $ | 1,764 |  | $ | 2,312 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,764 |  | $ | 2,312 |  |

[0001375365-23-000012:notes:128]
Tripartite Agreement

[0001375365-23-000012:notes:129]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated, and during the quarter ended December 31, 2022, the Agreement was terminated.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-23-000012:notes:130]
[same as prior period, unchanged from 0001375365-22-000119:notes:121]

[0001375365-23-000012:notes:131]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "Original 2020 Plan"). The maximum number of shares available under the Original 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan (as amended and restated, the “2020 Plan”) which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-23-000012:notes:132]
[same as prior period, unchanged from 0001375365-22-000119:notes:123]

[0001375365-23-000012:notes:133]
As of December 31, 2022, the Company had 2,711,240 authorized shares available for future issuance under the 2020 Plan.

[0001375365-23-000012:notes:134]
[same as prior period, unchanged from 0001375365-22-000119:notes:125]

[0001375365-23-000012:notes:135]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company's Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. No shares were repurchased under any share repurchase programs during the three and six months ended December 31, 2022.

[0001375365-23-000012:notes:136]
[same as prior period, unchanged from 0001375365-22-000119:notes:127]

[0001375365-23-000012:notes:137]
[same as prior period, unchanged from 0001375365-22-000119:notes:128]

[0001375365-23-000012:notes:138]
[same as prior period, unchanged from 0001375365-22-000119:notes:129]

[0001375365-23-000012:notes:139]
[same as prior period, unchanged from 0001375365-22-000119:notes:130]

[0001375365-23-000012:notes:140]
[same as prior period, unchanged from 0001375365-22-000119:notes:131]

[0001375365-23-000012:notes:141]
[same as prior period, unchanged from 0001375365-22-000119:notes:132]

[0001375365-23-000012:notes:142]
The fair value of stock option grants for the three and six months ended December 31, 2022 and 2021 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-23-000012:notes:143]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Risk-free interest rate | 4.16% - 4.25% |  | 0.81% |  | 2.81% - 4.25% |  | 0.81% - 0.45% |
| Expected term | 6.07 years |  | 6.09 years |  | 6.07 years |  | 6.09 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 51.64% - 51.68% |  | 49.69% |  | 50.62% - 51.68% |  | 49.69% - 49.71% |
| Weighted-average fair value | $36.37 |  | $17.94 |  | $34.60 |  | $17.59 |

[0001375365-23-000012:notes:144]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2022 and 2021 (in thousands):

[0001375365-23-000012:notes:145]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of sales | $ | 1,486 |  |  | $ | 471 |  |  | $ | 2,370 |  |  | $ | 918 |  |
| Research and development | 9,334 |  |  | 4,103 |  |  | 15,452 |  |  | 7,983 |  |
| Sales and marketing | 1,448 |  |  | 496 |  |  | 2,257 |  |  | 1,013 |  |
| General and administrative | 4,713 |  |  | 4,106 |  |  | 7,916 |  |  | 6,277 |  |
| Stock-based compensation expense before taxes | 16,981 |  |  | 9,176 |  |  | 27,995 |  |  | 16,191 |  |
| Income tax impact | (3,381) |  |  | (2,310) |  |  | (4,720) |  |  | (4,198) |  |
| Stock-based compensation expense, net | $ | 13,600 |  |  | $ | 6,866 |  |  | $ | 23,275 |  |  | $ | 11,993 |  |

[0001375365-23-000012:notes:146]
As of December 31, 2022, $17.0 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.01 years and $78.8 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.63 years. Additionally, as described below, $2.4 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 1.50 years.

[0001375365-23-000012:notes:147]
[same as prior period, unchanged from 0001375365-22-000119:notes:138]

[0001375365-23-000012:notes:148]
[same as prior period, unchanged from 0001375365-22-000119:notes:139]

[0001375365-23-000012:notes:149]
The achievement status of the operational and stock price milestones as of December 31, 2022 was as follows:

[0001375365-23-000012:notes:150]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Achieved |  | $75 |  | Achieved (3) |  |  |
| $6.8 |  | Probable |  | $95 |  | Not yet achieved |  |  |
| $8.0 |  | Probable |  | $120 |  | Not yet achieved |  |  |

[0001375365-23-000012:notes:151]
[same as prior period, unchanged from 0001375365-22-000119:notes:142]

[0001375365-23-000012:notes:152]
(2)The vesting of the second tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company's Compensation Committee in October 2022.

[0001375365-23-000012:notes:153]
(3)The vesting of the third tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company's Compensation Committee on January 4, 2023.

[0001375365-23-000012:notes:154]
[same as prior period, unchanged from 0001375365-22-000119:notes:144]

[0001375365-23-000012:notes:155]
During the three and six months ended December 31, 2022, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $1.9 million and $3.2 million, respectively. During the three and six months ended December 31, 2021, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $2.9 million and $3.8 million, respectively. As of December 31, 2022 and June 30, 2022, the Company had $2.4 million and $5.6 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of December 31, 2022 is expected to be recognized over a period of more than 1.50 years.

[0001375365-23-000012:notes:156]
The following table summarizes stock option activity during the six months ended December 31, 2022 under all plans:

[0001375365-23-000012:notes:157]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2022 |  | 4,311,416 |  |  | $ | 29.99 |  |  |  |  |  |
| Granted |  | 240,002 |  |  | $ | 61.44 |  |  |  |  |  |
| Exercised |  | (752,892) |  |  | $ | 20.36 |  |  |  |  |  |
| Forfeited/Cancelled |  | (15,541) |  |  | $ | 25.10 |  |  |  |  |  |
| Balance as of December 31, 2022 |  | 3,782,985 |  |  | $ | 33.93 |  |  | 5.89 |  |  |
| Options vested and exercisable at December 31, 2022 |  | 2,302,409 |  |  | $ | 27.48 |  |  | 4.18 |  |  |

[0001375365-23-000012:notes:158]
[same as prior period, unchanged from 0001375365-22-000119:notes:148]

[0001375365-23-000012:notes:159]
The following table summarizes RSU and PRSU activity during the six months ended December 31, 2022 under all plans:

[0001375365-23-000012:notes:160]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2022 | 1,879,073 |  |  | $ | 33.72 |  |  |  |  |  |  |
| Granted | 745,937 |  |  | $ | 62.77 |  |  |  |  |  |  |
| Released | (484,003) |  |  | $ | 36.14 |  |  |  |  |  |  |
| Forfeited | (77,613) |  |  | $ | 38.22 |  |  |  |  |  |  |
| Balance as of December 31, 2022 | 2,063,394 |  |  | $ | 43.49 |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-23-000012:notes:161]
Income Taxes
The Company recorded a provision for income taxes of $29.6 million and $68.5 million for the three and six months ended December 31, 2022, respectively, and $7.6 million and $10.9 million for the three and six months ended December 31, 2021, respectively. The effective tax rate was 14.3% and 15.9% for the three and six months ended December 31, 2022, respectively, and 15.4% and 14.1% for the three and six months ended December 31, 2021, respectively. The effective tax rate for the three months ended December 31, 2022 is lower than that for the three months ended December 31, 2021, primarily due to an increase in the tax deduction for stock compensation, and a tax reserve release in the three months ended December 31, 2022. The effective tax rate for the six months ended December 31, 2022 is higher than that for the six months ended December 31, 2021, primarily due to the significant increase in taxable income in the first two quarters of fiscal year 2023, while the income tax deductions for items such as the R&D credit and foreign tax deduction in those quarters did not increase in the same proportion.

[0001375365-23-000012:notes:162]
The Tax Cuts and Jobs Act of 2017 eliminated the option to deduct research and development ("R&D") expenses in the year incurred and instead requires taxpayers to capitalize R&D expenses, including software development cost, and subsequently amortize such expenses over five years for R&D activities conducted in the United States and over fifteen years for R&D activities conducted outside of the United States beginning in the Company's fiscal year 2023. Although Congress has considered legislation that would defer, modify, and repeal the capitalization and amortization requirement, there is no assurance the provision will be deferred, repealed, or otherwise modified.

[0001375365-23-000012:notes:163]
As of December 31, 2022, the Company had gross unrecognized tax benefits of $41.1 million, of which, $23.4 million if recognized, would affect the Company's effective tax rate. During the six months ended December 31, 2022, there was a $3.9 million decrease in gross unrecognized tax benefits. The Company's policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of December 31, 2022, the Company had accrued $3.3 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-23-000012:notes:164]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts that may be asserted by tax authorities could be greater or less than the Company's current position. Accordingly, the Company's provision for federal, state, and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-23-000012:notes:165]
[same as prior period, unchanged from 0001375365-22-000119:notes:156]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-23-000012:notes:166]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 5, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. All settlement funds have been transferred into an account controlled by the settlement’s escrow agent. No settlement funds will be distributed until the Court grants final approval. On November 8, 2022, the Court granted preliminary approval and calendared a hearing on March 2, 2023 for final approval. This settlement, if finally approved by the Court, will fully resolve the action.

[0001375365-23-000012:notes:167]
Other legal proceedings and indemnifications

[0001375365-23-000012:notes:168]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2022 and any prior periods.

[0001375365-23-000012:notes:169]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-23-000012:notes:170]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-23-000012:notes:171]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2022, these remaining noncancelable commitments were $422.9 million, including $97.0 million for related parties.

[0001375365-23-000012:notes:172]
Lease Commitments - See Part I, Item 1, Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-23-000012:notes:173]
[same as prior period, unchanged from 0001375365-22-000119:notes:164]

[0001375365-23-000012:notes:174]
[same as prior period, unchanged from 0001375365-22-000119:notes:165]

[0001375365-23-000012:notes:175]
|  | December 31, |  | June 30, |
|  | 2022 |  | 2022 |
| Long-lived assets: |  |  |  |
| United States | $ | 181,754 |  |  | $ | 180,846 |  |
| Asia | 104,724 |  |  | 102,241 |  |
| Europe | 2,777 |  |  | 2,885 |  |
|  | $ | 289,255 |  |  | $ | 285,972 |  |

[0001375365-23-000012:notes:176]
[same as prior period, unchanged from 0001375365-22-000119:notes:167]
