# SMCI 8-K — 0001375365-23-000009 filed 2023-01-31

## item codes, every 8-K on or before 2023-02-03

- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2023-02-03

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-23-000009:8k_2_02:1]
EX-99.1
2
exhibit991_20221231.htm
EX-99.1

[0001375365-23-000009:8k_2_02:2]
Document

[0001375365-23-000009:8k_2_02:3]
Exhibit 99.1

[0001375365-23-000009:8k_2_02:4]
Supermicro Announces Second Quarter Fiscal Year 2023 Financial Results

[0001375365-23-000009:8k_2_02:5]
SAN JOSE, Calif. -- January 31, 2023 (BUSINESS WIRE) -- Supermicro (Nasdaq: SMCI), a Total IT Solution Provider for Cloud, AI/ML, Storage, and 5G/Edge, today announced financial results for its second quarter of fiscal year 2023 ended December 31, 2022.

[0001375365-23-000009:8k_2_02:6]
Second Quarter Fiscal Year 2023 Highlights

[0001375365-23-000009:8k_2_02:7]
•Net sales of $1.80 billion versus $1.85 billion in the first quarter of fiscal year 2023 and $1.17 billion in the same quarter of last year.

[0001375365-23-000009:8k_2_02:8]
•Gross margin of 18.7% versus 18.8% in the first quarter of fiscal year 2023 and 14.0% in the same quarter of last year.

[0001375365-23-000009:8k_2_02:9]
•Net income of $176 million versus $184 million in the first quarter of fiscal year 2023 and $42 million in the same quarter of last year.

[0001375365-23-000009:8k_2_02:10]
•Diluted net income per common share of $3.14 versus $3.35 in the first quarter of fiscal year 2023 and $0.78 in the same quarter of last year.

[0001375365-23-000009:8k_2_02:11]
•Non-GAAP diluted net income per common share of $3.26 versus $3.42 in the first quarter of fiscal year 2023 and $0.88 in the same quarter of last year.

[0001375365-23-000009:8k_2_02:12]
•Cash flow provided by operations for the second quarter of fiscal year 2023 of $161 million and capital expenditures of $10 million.

[0001375365-23-000009:8k_2_02:13]
Non-GAAP gross margin for the second quarter of fiscal year 2023 was 18.8% which adds back stock-based compensation expenses of $1 million. Non-GAAP diluted net income per common share for the second quarter of fiscal year 2023 was $3.26, with adjustments for stock-based compensation expenses of $17 million and $2 million litigation expense recovery, net of the related tax effects of $4 million.

[0001375365-23-000009:8k_2_02:14]
As of December 31, 2022, total cash and cash equivalents was $305 million and total bank debt was $170 million.

[0001375365-23-000009:8k_2_02:15]
“Our fiscal Q2 2023 saw another record quarter with revenue just over $1.8 billion, up 54% YoY, making it the eighth consecutive quarter of outstanding growth that effectively doubled our annual revenue,” said Charles Liang, Chairman and CEO, Supermicro. “We continue to lead the market with the best designs and best in class Total IT Solutions. In fact, the structural shifts in the end markets favor our solution strategy.  I remain confident and excited for fiscal 2023 and beyond, as we are in the beginning of many new platform launches that should continue to support our share gain momentum in the long run.”

[0001375365-23-000009:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-23-000009:8k_2_02:17]
For the third quarter of fiscal year 2023 ending March 31, 2023, the Company expects net sales of $1.42 billion to $1.52 billion, GAAP net income per diluted share of $1.75 to $2.02 and non-GAAP net income per diluted share of $1.88 to $2.14. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 15.9% and 16.9%, respectively, and a fully diluted share count of 57 million shares for GAAP and fully diluted share count of 58 million shares for non-GAAP. The outlook for Q3 of fiscal year 2023 GAAP net income per diluted share includes approximately $9 million in expected stock-based compensation and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-23-000009:8k_2_02:18]
For fiscal year 2023 ending June 30, 2023, the Company maintains its guidance for net sales from a range of  $6.5 billion to $7.5 billion, GAAP net income per diluted share from a range of $8.50 to $11.00, and non-GAAP net income per diluted share from a range of $9.00 to $11.30. The Company’s projections for annual GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 19.2% and 19.8%, respectively, and a fully diluted share count of 57 million shares for GAAP and fully diluted share count of 58 million shares for non-GAAP. The outlook for fiscal year 2023 GAAP net income per diluted share includes approximately $33 million in expected stock-based compensation and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-23-000009:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-23-000009:8k_2_02:20]
Supermicro will hold a public webcast at 2:00 p.m. PST today to discuss the results for its second quarter of fiscal year 2023.

[0001375365-23-000009:8k_2_02:21]
Those wishing to access the live webcast may use the following link:

[0001375365-23-000009:8k_2_02:22]
https://events.q4inc.com/attendee/374434608

[0001375365-23-000009:8k_2_02:23]
The conference call can be accessed by registering online at:

[0001375365-23-000009:8k_2_02:24]
https://conferencingportals.com/event/fIceWmPv

[0001375365-23-000009:8k_2_02:25]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-23-000009:8k_2_02:26]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-23-000009:8k_2_02:27]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-23-000009:8k_2_02:28]
Use of Non-GAAP Financial Measures

[0001375365-23-000009:8k_2_02:29]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses and litigation expense (recovery) adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-23-000009:8k_2_02:30]
About Super Micro Computer, Inc.

[0001375365-23-000009:8k_2_02:31]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-23-000009:8k_2_02:32]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-23-000009:8k_2_02:33]
Investor Relations Contact

[0001375365-23-000009:8k_2_02:34]
Nicole Noutsios

[0001375365-23-000009:8k_2_02:35]
email: ir@supermicro.com

[0001375365-23-000009:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000009:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-23-000009:8k_2_02:38]
(in thousands)

[0001375365-23-000009:8k_2_02:39]
(unaudited)

[0001375365-23-000009:8k_2_02:40]
|  | December 31, |  | June 30, |
|  | 2022 |  | 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 304,595 |  |  | $ | 267,397 |  |
| Accounts receivable, net of allowance for credit losses | 768,167 |  |  | 834,513 |  |
| Inventories | 1,421,817 |  |  | 1,545,606 |  |
| Prepaid expenses and other current assets | 154,924 |  |  | 158,799 |  |
| Total current assets | 2,649,503 |  |  | 2,806,315 |  |
| Investment in equity investee | 3,197 |  |  | 5,329 |  |
| Property, plant and equipment, net | 289,255 |  |  | 285,972 |  |
| Deferred income taxes, net | 95,741 |  |  | 69,929 |  |
| Other assets | 37,246 |  |  | 37,532 |  |
| Total assets | $ | 3,074,942 |  |  | $ | 3,205,077 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 559,962 |  |  | $ | 655,403 |  |
| Accrued liabilities | 169,866 |  |  | 212,419 |  |
| Income taxes payable | 38,713 |  |  | 41,743 |  |
| Short-term debt | 27,869 |  |  | 449,146 |  |
| Deferred revenue | 120,530 |  |  | 111,313 |  |
| Total current liabilities | 916,940 |  |  | 1,470,024 |  |
| Deferred revenue, non-current | 159,574 |  |  | 122,548 |  |
| Long-term debt | 142,273 |  |  | 147,618 |  |
| Other long-term liabilities | 37,313 |  |  | 39,140 |  |
| Total liabilities | 1,256,100 |  |  | 1,779,330 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 514,559 |  |  | 481,741 |  |
| Accumulated other comprehensive income | 612 |  |  | 911 |  |
| Retained earnings | 1,303,506 |  |  | 942,923 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,818,677 |  |  | 1,425,575 |  |
| Noncontrolling interest | 165 |  |  | 172 |  |
| Total stockholders’ equity | 1,818,842 |  |  | 1,425,747 |  |
| Total liabilities and stockholders’ equity | $ | 3,074,942 |  |  | $ | 3,205,077 |  |

[0001375365-23-000009:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000009:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-23-000009:8k_2_02:43]
(in thousands except per share amounts)

[0001375365-23-000009:8k_2_02:44]
(unaudited)

[0001375365-23-000009:8k_2_02:45]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |
| Cost of sales | 1,465,773 |  |  | 1,008,676 |  |  | 2,970,368 |  |  | 1,903,267 |  |
| Gross profit | 337,422 |  |  | 163,743 |  |  | 684,957 |  |  | 301,882 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 70,700 |  |  | 65,471 |  |  | 144,943 |  |  | 130,614 |  |
| Sales and marketing | 28,445 |  |  | 21,960 |  |  | 57,808 |  |  | 43,584 |  |
| General and administrative | 23,095 |  |  | 25,263 |  |  | 46,901 |  |  | 47,507 |  |
| Total operating expenses | 122,240 |  |  | 112,694 |  |  | 249,652 |  |  | 221,705 |  |
| Income from operations | 215,182 |  |  | 51,049 |  |  | 435,305 |  |  | 80,177 |  |
| Other (expense) income, net | (6,335) |  |  | (607) |  |  | 1,719 |  |  | (557) |  |
| Interest expense | (1,756) |  |  | (1,150) |  |  | (5,694) |  |  | (1,954) |  |
| Income before income tax provision | 207,091 |  |  | 49,292 |  |  | 431,330 |  |  | 77,666 |  |
| Income tax (provision) | (29,573) |  |  | (7,599) |  |  | (68,507) |  |  | (10,924) |  |
| Share of (loss) income from equity investee, net of taxes | (1,351) |  |  | 239 |  |  | (2,240) |  |  | 627 |  |
| Net income | $ | 176,167 |  |  | $ | 41,932 |  |  | $ | 360,583 |  |  | $ | 67,369 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 3.31 |  |  | $ | 0.82 |  |  | $ | 6.84 |  |  | $ | 1.32 |  |
| Diluted | $ | 3.14 |  |  | $ | 0.78 |  |  | $ | 6.51 |  |  | $ | 1.27 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 53,160 |  |  | 51,314 |  |  | 52,726 |  |  | 51,055 |  |
| Diluted | 56,144 |  |  | 53,511 |  |  | 55,427 |  |  | 53,213 |  |

[0001375365-23-000009:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-23-000009:8k_2_02:47]
|  | Three Months EndedDecember 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of sales | $ | 1,486 |  |  | $ | 471 |  |  | $ | 2,370 |  |  | $ | 918 |  |
| Research and development | 9,334 |  |  | 4,103 |  |  | 15,452 |  |  | 7,983 |  |
| Sales and marketing | 1,448 |  |  | 496 |  |  | 2,257 |  |  | 1,013 |  |
| General and administrative | 4,713 |  |  | 4,106 |  |  | 7,916 |  |  | 6,277 |  |
| Stock-based compensation expense | $ | 16,981 |  |  | $ | 9,176 |  |  | $ | 27,995 |  |  | $ | 16,191 |  |

[0001375365-23-000009:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000009:8k_2_02:49]
SELECTED CASH FLOW INFORMATION

[0001375365-23-000009:8k_2_02:50]
(in thousands)

[0001375365-23-000009:8k_2_02:51]
(unaudited)

[0001375365-23-000009:8k_2_02:52]
|  | Six Months EndedDecember 31, |
|  | 2022 |  | 2021 |
| Net cash provided by (used in) operating activities | $ | 474,674 |  |  | $ | (187,722) |  |
| Net cash (used in) investing activities | (20,631) |  |  | (24,306) |  |
| Net cash (used in) provided by financing activities | (415,821) |  |  | 227,173 |  |
| Effect of exchange rate fluctuations on cash | (1,693) |  |  | (9) |  |
| Net increase in cash, cash equivalents and restricted cash | 36,529 |  |  | 15,136 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 268,559 |  |  | 233,449 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 305,088 |  |  | $ | 248,585 |  |

[0001375365-23-000009:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000009:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000009:8k_2_02:55]
(in thousands except per share amounts)

[0001375365-23-000009:8k_2_02:56]
(unaudited)

[0001375365-23-000009:8k_2_02:57]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP GROSS PROFIT | $ | 337,422 |  |  | $ | 163,743 |  |  | $ | 684,957 |  |  | $ | 301,882 |  |
| Stock-based compensation | 1,486 |  |  | 471 |  |  | 2,370 |  |  | 918 |  |
| Other expenses | — |  |  | — |  |  | — |  |  | 295 |  |
| NON-GAAP GROSS PROFIT | $ | 338,908 |  |  | $ | 164,214 |  |  | $ | 687,327 |  |  | $ | 303,095 |  |
| GAAP GROSS MARGIN | 18.7 | % |  | 14.0 | % |  | 18.7 | % |  | 13.7 | % |
| Stock-based compensation | 0.1 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |
| Other expenses | — | % |  | — | % |  | — | % |  | 0.0 | % |
| NON-GAAP GROSS MARGIN | 18.8 | % |  | 14.0 | % |  | 18.8 | % |  | 13.7 | % |
| GAAP OPERATING EXPENSE | $ | 122,240 |  |  | $ | 112,694 |  |  | $ | 249,652 |  |  | $ | 221,705 |  |
| Stock-based compensation | (15,495) |  |  | (8,705) |  |  | (25,625) |  |  | (15,273) |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | (158) |  |
| Litigation recovery (expense) | 2,230 |  |  | (597) |  |  | 2,230 |  |  | (1,923) |  |
| NON-GAAP OPERATING EXPENSE | $ | 108,975 |  |  | $ | 103,392 |  |  | $ | 226,257 |  |  | $ | 204,351 |  |
| GAAP INCOME FROM OPERATIONS | $ | 215,182 |  |  | $ | 51,049 |  |  | $ | 435,305 |  |  | $ | 80,177 |  |
| Stock-based compensation | 16,981 |  |  | 9,176 |  |  | 27,995 |  |  | 16,191 |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |
| Litigation (recovery) expense | (2,230) |  |  | 597 |  |  | (2,230) |  |  | 1,923 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 229,933 |  |  | $ | 60,822 |  |  | $ | 461,070 |  |  | $ | 98,744 |  |
| GAAP OPERATING MARGIN | 11.9 | % |  | 4.4 | % |  | 11.9 | % |  | 3.6 | % |
| Stock-based compensation | 1.0 | % |  | 0.8 | % |  | 0.8 | % |  | 0.7 | % |
| Special performance bonuses | — | % |  | — | % |  | — | % |  | 0.1 | % |
| Litigation (recovery) expense | (0.1) | % |  | 0.0 | % |  | (0.1) | % |  | 0.1 | % |
| NON-GAAP OPERATING MARGIN | 12.8 | % |  | 5.2 | % |  | 12.6 | % |  | 4.5 | % |
| GAAP TAX EXPENSE | $ | 29,573 |  |  | $ | 7,599 |  |  | $ | 68,507 |  |  | $ | 10,924 |  |
| Adjustments to tax provision | 4,300 |  |  | 3,339 |  |  | 7,530 |  |  | 6,169 |  |
| NON-GAAP TAX EXPENSE | $ | 33,873 |  |  | $ | 10,938 |  |  | $ | 76,037 |  |  | $ | 17,093 |  |
| GAAP NET INCOME | $ | 176,167 |  |  | $ | 41,932 |  |  | $ | 360,583 |  |  | $ | 67,369 |  |
| Stock-based compensation | 16,981 |  |  | 9,176 |  |  | 27,995 |  |  | 16,191 |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |
| Litigation (recovery) expense | (2,230) |  |  | 597 |  |  | (2,230) |  |  | 1,923 |  |
| Adjustments to tax provision | (4,300) |  |  | (3,339) |  |  | (7,530) |  |  | (6,169) |  |
| NON-GAAP NET INCOME | $ | 186,618 |  |  | $ | 48,366 |  |  | $ | 378,818 |  |  | $ | 79,767 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.31 |  |  | $ | 0.82 |  |  | $ | 6.84 |  |  | $ | 1.32 |  |
| Impact of Non-GAAP adjustments | 0.20 |  |  | 0.12 |  |  | 0.34 |  |  | 0.24 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.51 |  |  | $ | 0.94 |  |  | $ | 7.18 |  |  | $ | 1.56 |  |

[0001375365-23-000009:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000009:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000009:8k_2_02:60]
(in thousands except per share amounts)

[0001375365-23-000009:8k_2_02:61]
(unaudited)

[0001375365-23-000009:8k_2_02:62]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.14 |  |  | $ | 0.78 |  |  | $ | 6.51 |  |  | $ | 1.27 |  |
| Impact of Non-GAAP adjustments | 0.12 |  |  | 0.10 |  |  | 0.18 |  |  | 0.19 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.26 |  |  | $ | 0.88 |  |  | $ | 6.69 |  |  | $ | 1.46 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 53,160 |  |  | 51,314 |  |  | 52,726 |  |  | 51,055 |  |
| BASIC – NON-GAAP | 53,160 |  |  | 51,314 |  |  | 52,726 |  |  | 51,055 |  |
| DILUTED – GAAP | 56,144 |  |  | 53,511 |  |  | 55,427 |  |  | 53,213 |  |
| DILUTED – NON-GAAP | 57,318 |  |  | 54,947 |  |  | 56,641 |  |  | 54,655 |  |

[0001375365-23-000009:8k_2_02:63]
Non-GAAP diluted net income per common share for the first quarter of fiscal year 2023 ended September 30, 2022 was $3.42, which adds back the impact of stock-based compensation expenses, net of the related tax effects of $0.07 per common share.
