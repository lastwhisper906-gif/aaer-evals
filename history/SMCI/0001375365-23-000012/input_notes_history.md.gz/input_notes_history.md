# SMCI note change history — 0001375365-22-000119 → 0001375365-23-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 5, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. All settlement funds have been transferred into an account controlled by the settlement’s escrow agent. No settlement funds will be distributed until the Court grants final approval. On November 8, 2022, the Court granted preliminary approval and calendared a hearing on March 2, 2023 for final approval. This settlement, if finally approved by the Court, will fully resolve the action.
  (was, 2022-11-04, similarity 0.9185):
[0001375365-22-000119:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. Consequently, the parties expect the Court will grant preliminary approval and calendar a future hearing for final approval. This settlement, if finally approved by the Court, will fully resolve the action.

- changed (2023-02-03):
[0001375365-23-000012:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2022 and any prior periods.
  (was, 2022-11-04, similarity 0.9893):
[0001375365-22-000119:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2022 and any prior periods.

- changed (2023-02-03):
[0001375365-23-000012:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2022, these remaining noncancelable commitments were $422.9 million, including $97.0 million for related parties.
  (was, 2022-11-04, similarity 0.6362):
[0001375365-22-000119:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2022, these remaining noncancelable commitments were $512.3 million, including $97.7 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.
  (was, 2022-11-04, similarity 0.7142):
[0001375365-22-000119:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.

- changed (2023-02-03):
[0001375365-23-000012:note_history:5]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 14.1% and 17.6% of total purchases for the three months ended December 31, 2022, and two suppliers accounted for 22.1% and 6.5% of total purchases for the three months ended December 31, 2021. Two suppliers accounted for 15.3% and 22.3% of total purchases for the six months ended December 31, 2022, and two suppliers accounted for 21.2% and 6.4% of total purchases for the six months ended December 31, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.7% and 9.4% of total cost of sales for the three months ended December 31, 2022 and 2021, respectively, and a combined 6.6% and 9.5% of total cost of sales for the six months ended December 31, 2022 and 2021, respectively.
  (was, 2022-11-04, similarity 0.8065):
[0001375365-22-000119:note_history:5]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 16.1% and 25.7% of total purchases for the three months ended September 30, 2022, and two suppliers accounted for 20.1% and 6.3% of total purchases for the three months ended September 30, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% and 9.6% of total cost of sales for the three months ended September 30, 2022 and 2021, respectively.

- changed (2023-02-03):
[0001375365-23-000012:note_history:6]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended December 31, 2022, and one customer accounted for 15.8% of the net sales for the six months ended December 31, 2022. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2021. No single customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2022. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.
  (was, 2022-11-04, similarity 0.7297):
[0001375365-22-000119:note_history:6]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022 and no single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021. Two customers accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2022 which accounted for 11.0% and 10.3%. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.

- changed (2023-02-03):
[0001375365-23-000012:note_history:7]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In December 2022, FASB issued an Accounting Standards Update (ASU) for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The ASU defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC and Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have material impact on its consolidated financial statements and disclosures.
  (was, 2022-11-04, similarity 0.9723):
[0001375365-22-000119:note_history:7]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendments are effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In April 2022, FASB issued a proposed accounting standard update for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The proposed amendment defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have material impact on its consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:8]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands):
  (was, 2022-11-04, similarity 0.9829):
[0001375365-22-000119:note_history:8]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:9]
|  | December 31, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| 2022 CTBC Credit Line | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | — |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,070 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 38,904 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,501 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,859 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 40,372 |  |
| Total term loans | 170,142 |  |  | 162,919 |  |
| Total debt | 170,142 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 27,869 |  |  | 449,146 |  |
| Debt, non-current | $ | 142,273 |  |  | $ | 147,618 |  |
  (was, 2022-11-04, similarity 0.7211):
[0001375365-22-000119:note_history:9]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 60,284 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | 11,000 |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | 9,000 |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 80,284 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,487 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 37,785 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,706 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 40,304 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,373 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,785 |  |  | 40,372 |  |
| Total term loans | 169,440 |  |  | 162,919 |  |
| Total debt | 249,724 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 101,173 |  |  | 449,146 |  |
| Debt, non-current | $ | 148,551 |  |  | $ | 147,618 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:10]
Available borrowings and interest rates as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):
  (was, 2022-11-04, similarity 0.9818):
[0001375365-22-000119:note_history:10]
Available borrowings and interest rates as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

- changed (2023-02-03):
[0001375365-23-000012:note_history:11]
|  | December 31, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 5.56% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.88% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 30,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.425% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.075% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.275% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 2,594 |  | 1.62% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.62% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |
  (was, 2022-11-04, similarity 0.9624):
[0001375365-22-000119:note_history:11]
|  | September 30, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 289,716 |  | 4.03% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | 105,000 |  | 1.80% - 2.52% |  | $ | 20,200 |  | 1.80% - 2.52% |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.14% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 19,000 |  | 3.84% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | 1.81% |  | $ | 22,200 |  | 1.81% |
| 2022 E.SUN Bank Credit Facility | $ | 21,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.30% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 0.95% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | 5,193 |  | 1.15% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.495% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.495% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |

- added (2023-02-03):
[0001375365-23-000012:note_history:12]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 9. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022 for a more complete description of the Company's credit facilities.

- changed (2023-02-03):
[0001375365-23-000012:note_history:13]
The Company entered into a new General Credit Agreement with ESUN Bank during the six months ended December 31, 2022 with the following terms:
  (was, 2022-11-04, similarity 0.9531):
[0001375365-22-000119:note_history:13]
The Company entered into a new General Credit Agreement with ESUN Bank during the three months ended September 30, 2022 with the following terms:

- changed (2023-02-03):
[0001375365-23-000012:note_history:14]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through Super Micro Computer Inc., Taiwan, a Taiwan corporation and wholly-owned subsidiary of the Company (the “Taiwan Subsidiary”), entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US $30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan Subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.
  (was, 2022-11-04, similarity 0.9376):
[0001375365-22-000119:note_history:14]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

- changed (2023-02-03):
[0001375365-23-000012:note_history:15]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Taiwan Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the New E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan Subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Taiwan Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of December 31, 2022, the amount outstanding under the Import O/A Loan was denominated in NTD and remeasured into US dollars of $55.8 million. The interest rate as of December 31, 2022 was 1.62% per annum. As of December 31, 2022 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $0.0 million and $7.8 million, respectively. The interest rate as of December 31, 2022 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of December 31, 2022, the amount available for future borrowing under the Import O/A Loan was $30.0 million.
  (was, 2022-11-04, similarity 0.9798):
[0001375365-22-000119:note_history:15]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of September 30, 2022 the amount outstanding under the Import O/A Loan was $16.4 million. The interest rate as of September 30, 2022 was 1.495% per annum. As of September 30, 2022 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $9.0 million and $7.8 million, respectively. The interest rate as of September 30, 2022 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of September 30, 2022, the amount available for future borrowing under the Import O/A Loan was $21.0 million.

- added (2023-02-03):
[0001375365-23-000012:note_history:16]
CTBC Bank

- added (2023-02-03):
[0001375365-23-000012:note_history:17]
2022 CTBC Credit Line

- added (2023-02-03):
[0001375365-23-000012:note_history:18]
Pursuant to banking practices in Taiwan to confirm loan agreements annually, on October 3, 2022, the Company through the Taiwan Subsidiary entered into an Agreement for Individually Negotiated Terms and Conditions with CTBC Bank Co., Ltd. (“CTBC Bank”) (such credit line, the “2022 CTBC Credit Line”) related to the prior 2021 CTBC credit lines (the “2021 CTBC Credit Lines”). The terms of the 2022 CTBC Credit Line remain substantially similar to the 2021 CTBC Credit Line, except the 2022 CTBC Credit Line made certain minor amendments to the monthly interest payment date. The total borrowing cap under the whole arrangement is $105.0 million and NTD 1,550.0 million ($55.4 million U.S. dollar equivalent).

- added (2023-02-03):
[0001375365-23-000012:note_history:19]
The Company, through the Taiwan Subsidiary, was party to that certain credit agreement, dated May 6, 2020, with CTBC Bank, which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent). As of December 31, 2022 and June 30, 2022, the amounts outstanding under the 2020 CTBC Term Loan Facility were $38.9 million and $40.4 million, respectively. The interest rates for these loans were 1.075% per annum as of December 31, 2022 and 0.825% as of June 30, 2022.

- added (2023-02-03):
[0001375365-23-000012:note_history:20]
The 2021 Credit Lines permitted borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the previously-existing ten-year, non-revolving term loan facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”). As of December 31, 2022 and June 30, 2022, under the 2021 CTBC Machine Loan, the amounts outstanding were $5.5 million and $5.5 million, respectively. The interest rates for these loans were 1.275% per annum as of December 31, 2022 and 1.025% as of June 30, 2022. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. As of December 31, 2022 and June 30, 2022, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were none and $84.8 million, respectively. The interest rates for these loans was 3.33% per annum as of December 31, 2022 and ranged from 1.80% to 2.52% as of June 30, 2022.

- added (2023-02-03):
[0001375365-23-000012:note_history:21]
As of December 31, 2022, the amount available for future borrowing under the 2022 CTBC Credit Line was $105 million. As of December 31, 2022, the net book value of land and building located in Bade, Taiwan, collateralizing the 2022 CTBC Credit Line was $76.1 million. The Company was in compliance with all financial covenants under 2022 CTBC Credit Line as of December 31, 2022.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:22]
Short-term and long-term debt obligations as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands):
  (was, 2022-11-04, similarity 0.9785):
[0001375365-22-000119:note_history:22]
Short-term and long-term debt obligations as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:23]
|  | December 31, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| 2022 CTBC Credit Line | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | — |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,070 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 38,904 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,501 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,859 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 38,904 |  |  | 40,372 |  |
| Total term loans | 170,142 |  |  | 162,919 |  |
| Total debt | 170,142 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 27,869 |  |  | 449,146 |  |
| Debt, non-current | $ | 142,273 |  |  | $ | 147,618 |  |
  (was, 2022-11-04, similarity 0.7211):
[0001375365-22-000119:note_history:23]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 60,284 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | 11,000 |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | 9,000 |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 80,284 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,487 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 37,785 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,706 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 40,304 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,373 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,785 |  |  | 40,372 |  |
| Total term loans | 169,440 |  |  | 162,919 |  |
| Total debt | 249,724 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 101,173 |  |  | 449,146 |  |
| Debt, non-current | $ | 148,551 |  |  | $ | 147,618 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:24]
Available borrowings and interest rates as of December 31, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):
  (was, 2022-11-04, similarity 0.9818):
[0001375365-22-000119:note_history:24]
Available borrowings and interest rates as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

- changed (2023-02-03):
[0001375365-23-000012:note_history:25]
|  | December 31, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 5.56% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.88% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 30,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.425% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.075% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.275% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 2,594 |  | 1.62% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.62% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |
  (was, 2022-11-04, similarity 0.9624):
[0001375365-22-000119:note_history:25]
|  | September 30, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 289,716 |  | 4.03% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | 105,000 |  | 1.80% - 2.52% |  | $ | 20,200 |  | 1.80% - 2.52% |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.14% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 19,000 |  | 3.84% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | 1.81% |  | $ | 22,200 |  | 1.81% |
| 2022 E.SUN Bank Credit Facility | $ | 21,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.30% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 0.95% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | 5,193 |  | 1.15% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.495% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.495% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- removed (2023-02-03):
[0001375365-22-000119:note_history:26]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:27]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2022-11-04, similarity 0.9972):
[0001375365-22-000119:note_history:27]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- added (2023-02-03):
[0001375365-23-000012:note_history:28]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.5% and 88.3% of the chassis included in the products sold by the Company during the three months ended December 31, 2022 and 2021, respectively, and 91.8% and 90.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2023-02-03):
[0001375365-23-000012:note_history:29]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on December 31, 2022 were $27.4 million and $26.8 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2022-11-04, similarity 0.997):
[0001375365-22-000119:note_history:29]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2022 were $37.1 million and $28.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2023-02-03):
[0001375365-23-000012:note_history:30]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on December 31, 2022 were $170.2 million and $70.1 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2022-11-04, similarity 0.9957):
[0001375365-22-000119:note_history:30]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2022 were $198.9 million and $69.0 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2023-02-03):
[0001375365-23-000012:note_history:31]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of December 31, 2022 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2022-11-04, similarity 0.9883):
[0001375365-22-000119:note_history:31]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2022 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2023-02-03):
[0001375365-23-000012:note_history:32]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2022. No impairment charge was recorded for the three and six months ended December 31, 2022 or 2021.
  (was, 2022-11-04, similarity 0.9697):
[0001375365-22-000119:note_history:32]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2022. No impairment charge was recorded for the three months ended September 30, 2022 or 2021.

- added (2023-02-03):
[0001375365-23-000012:note_history:33]
The Company sold products worth $6.0 million and $38.3 million to the Corporate Venture during the three months ended December 31, 2022 and 2021, respectively, and sold products worth $17.3 million and $53.5 million to the Corporate Venture during the six months ended December 31, 2022 and 2021, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2022 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $5.0 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of December 31, 2022 and June 30, 2022, respectively.

- changed (2023-02-03):
[0001375365-23-000012:note_history:34]
The Company had the following balances related to transactions with its related parties as of December 31, 2022 and June 30, 2022 (in thousands):
  (was, 2022-11-04, similarity 0.9815):
[0001375365-22-000119:note_history:34]
The Company had the following balances related to transactions with its related parties as of September 30, 2022 and June 30, 2022 (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:35]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 |  |  | December 31, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 267 |  | $ | 404 |  | $ | 4,951 |  | $ | 7,992 |  |  |  | $ | 5,220 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,452 |  | $ | 4,816 |  | $ | 43,885 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 47,337 |  | $ | 24,412 |  |
| Accounts payable | $ | 38,874 |  | $ | 42,463 |  | $ | 49,232 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 88,106 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,522 |  | $ | 3,531 |  | $ | 18,005 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 19,527 |  | $ | 18,676 |  |
  (was, 2022-11-04, similarity 0.9768):
[0001375365-22-000119:note_history:35]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 |  |  | September 30, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 882 |  | $ | 404 |  | $ | 9,365 |  | $ | 7,992 |  |  |  | $ | 10,249 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,540 |  | $ | 4,816 |  | $ | 31,011 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 34,551 |  | $ | 24,412 |  |
| Accounts payable | $ | 43,127 |  | $ | 42,463 |  | $ | 50,902 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 94,029 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,999 |  | $ | 3,531 |  | $ | 26,262 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 28,261 |  | $ | 18,676 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:36]
The Company's results from transactions with its related parties for each of the three months ended December 31, 2022 and 2021, are as follows (in thousands):
  (was, 2022-11-04, similarity 0.9833):
[0001375365-22-000119:note_history:36]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:37]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 3 |  | $ | 14,113 |  | $ | 3,302 |  | $ | 5,958 |  | $ | 38,311 |  | $ | — |  | $ | — |  | $ | 20,073 |  | $ | 41,616 |  |
| Purchases - inventory | $ | 46,715 |  | $ | 47,520 |  | $ | 52,028 |  | $ | 46,821 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,387 |  | $ | 98,743 |  | $ | 96,728 |  |
| Purchases - other miscellaneous items | $ | 2,763 |  | $ | 2,867 |  | $ | 279 |  | $ | 347 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,042 |  | $ | 3,214 |  |
  (was, 2022-11-04, similarity 0.9733):
[0001375365-22-000119:note_history:37]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 7 |  | $ | 13,760 |  | $ | 15,702 |  | $ | 11,293 |  | $ | 15,213 |  | $ | — |  | $ | — |  | $ | 25,055 |  | $ | 30,922 |  |
| Purchases - inventory | $ | 47,847 |  | $ | 50,788 |  | $ | 48,689 |  | $ | 35,229 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,670 |  | $ | 96,536 |  | $ | 87,687 |  |
| Purchases - other miscellaneous items | $ | 4,763 |  | $ | 2,116 |  | $ | 258 |  | $ | 339 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,021 |  | $ | 2,455 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:38]
The Company's results from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):
  (was, 2022-11-04, similarity 0.8954):
[0001375365-22-000119:note_history:38]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

- added (2023-02-03):
[0001375365-23-000012:note_history:39]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 3 |  | $ | 10 |  | $ | 27,872 |  | $ | 19,004 |  | $ | 17,251 |  | $ | 53,524 |  | $ | — |  | $ | — |  | $ | 45,126 |  | $ | 72,538 |  |
| Purchases - inventory | $ | 94,562 |  | $ | 98,309 |  | $ | 100,717 |  | $ | 82,050 |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,056 |  | $ | 195,279 |  | $ | 184,415 |  |
| Purchases - other miscellaneous items | $ | 7,526 |  | $ | 4,983 |  | $ | 537 |  | $ | 686 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 8,063 |  | $ | 5,669 |  |

- added (2023-02-03):
[0001375365-23-000012:note_history:40]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:41]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 137 |  | $ | (66) |  | $ | 3,041 |  | $ | (25,789) |  | $ | — |  | $ | — |  | $ | 3,178 |  | $ | (25,854) |  |
| Changes in other receivable | $ | 1,364 |  | $ | 641 |  | $ | (24,289) |  | $ | (11,673) |  | $ | — |  | $ | — |  | $ | — |  | $ | (133) |  | $ | (22,925) |  | $ | (11,165) |  |
| Changes in accounts payable | $ | (3,589) |  | $ | 3,573 |  | $ | 4,340 |  | $ | 22,367 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 751 |  | $ | 25,940 |  |
| Changes in accrued liabilities | $ | (2,009) |  | $ | (212) |  | $ | 2,860 |  | $ | 2,713 |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | 851 |  | $ | 1,501 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 4,366 |  | $ | 1,678 |  | $ | 148 |  | $ | 92 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,514 |  | $ | 1,770 |  |
| Unpaid property, plant and equipment | $ | 1,764 |  | $ | 2,312 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,764 |  | $ | 2,312 |  |
  (was, 2022-11-04, similarity 0.8516):
[0001375365-22-000119:note_history:41]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | — |  | $ | (478) |  | $ | (1,134) |  | $ | (1,373) |  | $ | (4,181) |  | $ | — |  | $ | — |  | $ | (1,851) |  | $ | (5,315) |  |
| Changes in other receivable | $ | 1,276 |  | $ | 1,147 |  | $ | (11,415) |  | $ | (3,517) |  | $ | — |  | $ | — |  | $ | — |  | $ | (76) |  | $ | (10,139) |  | $ | (2,446) |  |
| Changes in accounts payable | $ | 664 |  | $ | 2,578 |  | $ | 6,010 |  | $ | 5,080 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,674 |  | $ | 7,658 |  |
| Changes in accrued liabilities | $ | (1,532) |  | $ | (1,229) |  | $ | 11,117 |  | $ | 3,304 |  | $ | — |  | $ | (500) |  | $ | — |  | $ | — |  | $ | 9,585 |  | $ | 1,575 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 146 |  | $ | 62 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 400 |  |
| Unpaid property, plant and equipment | $ | 3,782 |  | $ | 1,360 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,782 |  | $ | 1,360 |  |

- added (2023-02-03):
[0001375365-23-000012:note_history:42]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- changed (2023-02-03):
[0001375365-23-000012:note_history:43]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated, and during the quarter ended December 31, 2022, the Agreement was terminated.
  (was, 2022-11-04, similarity 0.8758):
[0001375365-22-000119:note_history:43]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. While the Agreement is currently still in effect, Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated.

- removed (2023-02-03):
[0001375365-22-000119:note_history:44]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.4% and 92.5% of the chassis included in the products sold by the Company during the three months ended September 30, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2023-02-03):
[0001375365-22-000119:note_history:45]
The Company sold products worth $11.6 million and $15.2 million to the Corporate Venture for the three months ended September 30, 2022 and 2021, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2022 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $9.4 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of September 30, 2022 and June 30, 2022, respectively.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001375365-23-000012:note_history:46]
The Company had the following balances related to transactions with its related parties as of December 31, 2022 and June 30, 2022 (in thousands):
  (was, 2022-11-04, similarity 0.9815):
[0001375365-22-000119:note_history:46]
The Company had the following balances related to transactions with its related parties as of September 30, 2022 and June 30, 2022 (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:47]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 | December 31, 2022 | June 30, 2022 |  |  | December 31, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 267 |  | $ | 404 |  | $ | 4,951 |  | $ | 7,992 |  |  |  | $ | 5,220 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,452 |  | $ | 4,816 |  | $ | 43,885 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 47,337 |  | $ | 24,412 |  |
| Accounts payable | $ | 38,874 |  | $ | 42,463 |  | $ | 49,232 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 88,106 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,522 |  | $ | 3,531 |  | $ | 18,005 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 19,527 |  | $ | 18,676 |  |
  (was, 2022-11-04, similarity 0.9768):
[0001375365-22-000119:note_history:47]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 |  |  | September 30, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 882 |  | $ | 404 |  | $ | 9,365 |  | $ | 7,992 |  |  |  | $ | 10,249 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,540 |  | $ | 4,816 |  | $ | 31,011 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 34,551 |  | $ | 24,412 |  |
| Accounts payable | $ | 43,127 |  | $ | 42,463 |  | $ | 50,902 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 94,029 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,999 |  | $ | 3,531 |  | $ | 26,262 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 28,261 |  | $ | 18,676 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:48]
The Company's results from transactions with its related parties for each of the three months ended December 31, 2022 and 2021, are as follows (in thousands):
  (was, 2022-11-04, similarity 0.9833):
[0001375365-22-000119:note_history:48]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:49]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 3 |  | $ | 14,113 |  | $ | 3,302 |  | $ | 5,958 |  | $ | 38,311 |  | $ | — |  | $ | — |  | $ | 20,073 |  | $ | 41,616 |  |
| Purchases - inventory | $ | 46,715 |  | $ | 47,520 |  | $ | 52,028 |  | $ | 46,821 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,387 |  | $ | 98,743 |  | $ | 96,728 |  |
| Purchases - other miscellaneous items | $ | 2,763 |  | $ | 2,867 |  | $ | 279 |  | $ | 347 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,042 |  | $ | 3,214 |  |
  (was, 2022-11-04, similarity 0.9733):
[0001375365-22-000119:note_history:49]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 7 |  | $ | 13,760 |  | $ | 15,702 |  | $ | 11,293 |  | $ | 15,213 |  | $ | — |  | $ | — |  | $ | 25,055 |  | $ | 30,922 |  |
| Purchases - inventory | $ | 47,847 |  | $ | 50,788 |  | $ | 48,689 |  | $ | 35,229 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,670 |  | $ | 96,536 |  | $ | 87,687 |  |
| Purchases - other miscellaneous items | $ | 4,763 |  | $ | 2,116 |  | $ | 258 |  | $ | 339 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,021 |  | $ | 2,455 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:50]
The Company's results from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):
  (was, 2022-11-04, similarity 0.8954):
[0001375365-22-000119:note_history:50]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

- added (2023-02-03):
[0001375365-23-000012:note_history:51]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 3 |  | $ | 10 |  | $ | 27,872 |  | $ | 19,004 |  | $ | 17,251 |  | $ | 53,524 |  | $ | — |  | $ | — |  | $ | 45,126 |  | $ | 72,538 |  |
| Purchases - inventory | $ | 94,562 |  | $ | 98,309 |  | $ | 100,717 |  | $ | 82,050 |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,056 |  | $ | 195,279 |  | $ | 184,415 |  |
| Purchases - other miscellaneous items | $ | 7,526 |  | $ | 4,983 |  | $ | 537 |  | $ | 686 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 8,063 |  | $ | 5,669 |  |

- added (2023-02-03):
[0001375365-23-000012:note_history:52]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2022 and 2021, are as follows (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:53]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 137 |  | $ | (66) |  | $ | 3,041 |  | $ | (25,789) |  | $ | — |  | $ | — |  | $ | 3,178 |  | $ | (25,854) |  |
| Changes in other receivable | $ | 1,364 |  | $ | 641 |  | $ | (24,289) |  | $ | (11,673) |  | $ | — |  | $ | — |  | $ | — |  | $ | (133) |  | $ | (22,925) |  | $ | (11,165) |  |
| Changes in accounts payable | $ | (3,589) |  | $ | 3,573 |  | $ | 4,340 |  | $ | 22,367 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 751 |  | $ | 25,940 |  |
| Changes in accrued liabilities | $ | (2,009) |  | $ | (212) |  | $ | 2,860 |  | $ | 2,713 |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | 851 |  | $ | 1,501 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (168) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 4,366 |  | $ | 1,678 |  | $ | 148 |  | $ | 92 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 4,514 |  | $ | 1,770 |  |
| Unpaid property, plant and equipment | $ | 1,764 |  | $ | 2,312 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,764 |  | $ | 2,312 |  |
  (was, 2022-11-04, similarity 0.8516):
[0001375365-22-000119:note_history:53]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | — |  | $ | (478) |  | $ | (1,134) |  | $ | (1,373) |  | $ | (4,181) |  | $ | — |  | $ | — |  | $ | (1,851) |  | $ | (5,315) |  |
| Changes in other receivable | $ | 1,276 |  | $ | 1,147 |  | $ | (11,415) |  | $ | (3,517) |  | $ | — |  | $ | — |  | $ | — |  | $ | (76) |  | $ | (10,139) |  | $ | (2,446) |  |
| Changes in accounts payable | $ | 664 |  | $ | 2,578 |  | $ | 6,010 |  | $ | 5,080 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,674 |  | $ | 7,658 |  |
| Changes in accrued liabilities | $ | (1,532) |  | $ | (1,229) |  | $ | 11,117 |  | $ | 3,304 |  | $ | — |  | $ | (500) |  | $ | — |  | $ | — |  | $ | 9,585 |  | $ | 1,575 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 146 |  | $ | 62 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 400 |  |
| Unpaid property, plant and equipment | $ | 3,782 |  | $ | 1,360 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,782 |  | $ | 1,360 |  |

- added (2023-02-03):
[0001375365-23-000012:note_history:54]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0001375365-23-000012:note_history:55]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Server and storage systems | $ | 1,660,931 |  |  | $ | 986,052 |  |  | $ | 3,373,987 |  |  | $ | 1,835,908 |  |
| Subsystems and accessories | 142,264 |  |  | 186,367 |  |  | 281,338 |  |  | 369,241 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:56]
The following is a summary for the three and six months ended December 31, 2022 and 2021, of net sales by geographic region (in thousands):
  (was, 2022-11-04, similarity 0.9486):
[0001375365-22-000119:note_history:56]
The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:57]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 1,091,391 |  |  | $ | 638,207 |  |  | $ | 2,386,895 |  |  | $ | 1,199,155 |  |
| Asia | 330,711 |  |  | 284,107 |  |  | 600,735 |  |  | 547,193 |  |
| Europe | 312,533 |  |  | 215,451 |  |  | 547,607 |  |  | 395,145 |  |
| Other | 68,560 |  |  | 34,654 |  |  | 120,088 |  |  | 63,656 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |
  (was, 2022-11-04, similarity 0.7323):
[0001375365-22-000119:note_history:57]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 1,295,504 |  |  | $ | 560,948 |  |  |  |  |  |
| Asia | 270,024 |  |  | 263,086 |  |  |  |  |  |
| Europe | 235,074 |  |  | 179,694 |  |  |  |  |  |
| Other | 51,528 |  |  | 29,002 |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |

- removed (2023-02-03):
[0001375365-22-000119:note_history:58]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713,056 |  |  |  |  | $ | 849,856 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 139,074 |  |  |  |  | 182,874 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  |  |  | $ | 1,032,730 |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0001375365-23-000012:note_history:59]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Server and storage systems | $ | 1,660,931 |  |  | $ | 986,052 |  |  | $ | 3,373,987 |  |  | $ | 1,835,908 |  |
| Subsystems and accessories | 142,264 |  |  | 186,367 |  |  | 281,338 |  |  | 369,241 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:60]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2022 and 2021, of net sales by geographic region (in thousands):
  (was, 2022-11-04, similarity 0.9122):
[0001375365-22-000119:note_history:60]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):

- changed (2023-02-03):
[0001375365-23-000012:note_history:61]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 1,091,391 |  |  | $ | 638,207 |  |  | $ | 2,386,895 |  |  | $ | 1,199,155 |  |
| Asia | 330,711 |  |  | 284,107 |  |  | 600,735 |  |  | 547,193 |  |
| Europe | 312,533 |  |  | 215,451 |  |  | 547,607 |  |  | 395,145 |  |
| Other | 68,560 |  |  | 34,654 |  |  | 120,088 |  |  | 63,656 |  |
| Total | $ | 1,803,195 |  |  | $ | 1,172,419 |  |  | $ | 3,655,325 |  |  | $ | 2,205,149 |  |
  (was, 2022-11-04, similarity 0.7323):
[0001375365-22-000119:note_history:61]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 1,295,504 |  |  | $ | 560,948 |  |  |  |  |  |
| Asia | 270,024 |  |  | 263,086 |  |  |  |  |  |
| Europe | 235,074 |  |  | 179,694 |  |  |  |  |  |
| Other | 51,528 |  |  | 29,002 |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |

- changed (2023-02-03):
[0001375365-23-000012:note_history:62]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2022, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $27.5 million and $61.0 million, respectively.
  (was, 2022-11-04, similarity 0.956):
[0001375365-22-000119:note_history:62]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2022, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $33.5 million.

- changed (2023-02-03):
[0001375365-23-000012:note_history:63]
Deferred revenue increased $46.2 million as of December 31, 2022 as compared to the fiscal year ended June 30, 2022 and was mainly due to the deferral on invoiced amounts for service contracts during the period exceeded the recognition of revenue from contracts entered into in prior periods. The service contracts deferral increase was offset partly by a $2.4 million decrease in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.
  (was, 2022-11-04, similarity 0.7244):
[0001375365-22-000119:note_history:63]
Deferred revenue increased $86.0 million as of September 30, 2022 as compared to the fiscal year ended June 30, 2022 of which $69.6 million was due to the increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

- changed (2023-02-03):
[0001375365-23-000012:note_history:64]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2022 was $280.0 million. The Company expects to recognize approximately 43% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2022-11-04, similarity 0.9962):
[0001375365-22-000119:note_history:64]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2022 was $319.8 million. The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2023-02-03):
[0001375365-22-000119:note_history:65]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713,056 |  |  |  |  | $ | 849,856 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 139,074 |  |  |  |  | 182,874 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  |  |  | $ | 1,032,730 |  |  |  |  |  |  |  |  |  |  |  |
