# SMCI MD&A — 0001375365-19-000039


## mdna

[0001375365-19-000039:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-19-000039:mdna:2]
Background of Investigation, Procedures and Analysis

[0001375365-19-000039:mdna:3]
See "Explanatory Note" to this Annual Report on Form-10K.

[0001375365-19-000039:mdna:4]
Nasdaq Delisting of our Common Stock

[0001375365-19-000039:mdna:5]
As a result of the delay in filing our periodic reports with the SEC and failure to hold an annual meeting, we were unable to comply with the Nasdaq listing standards and our common stock was suspended from trading on the Nasdaq Global Select Market effective August 23, 2018 and formally delisted effective March 22, 2019. Following the suspension of trading, our common stock has been quoted on the OTC Market and is currently traded under the symbol “SMCI.” For further information regarding trading in our common stock, refer to Part II, Item 5, “Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities” in this Annual Report on Form 10-K.

[0001375365-19-000039:mdna:6]
Overview

[0001375365-19-000039:mdna:7]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise, big data, high performance computing ("HPC" and internet of things ("IoT")/embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services.

[0001375365-19-000039:mdna:8]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2017, 2016 and 2015, our net income was $66.9 million, $72.1 million and $92.6 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin as key measures of profitability, and cash conversion cycle as a key measure of working capital management. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., and Nvidia Corporation carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-19-000039:mdna:9]
Financial Highlights

[0001375365-19-000039:mdna:10]
The following is a summary of other financial highlights of fiscal year 2017:

[0001375365-19-000039:mdna:11]
| • | Net sales increased by 11.7% as compared to fiscal year 2016 primarily due to increased unit shipments, reflecting the successful execution of our strategy to ship more complete systems, which increased by 13.5% as compared to fiscal year 2016. |

[0001375365-19-000039:mdna:12]
| • | Gross margin declined to 14.1% from 14.9% in fiscal year 2016 primarily due to increased component prices for memory and storage relative to our ability to pass cost increases to our customers as well as increased sales where pricing is typically more competitive and lower total capacity utilization while we ramp up use of our new facilities. |

[0001375365-19-000039:mdna:13]
| • | Operating expenses increased by 14.4% as compared to fiscal year 2016, but remained approximately 10% of sales as we continued to increase our human talent, primarily with respect to further investments in research and development. |

[0001375365-19-000039:mdna:14]
| • | Net income declined to $66.9 million as compared to $72.1 million in fiscal 2016, which was primarily due to a $16.1 million decline in income before taxes, which was partially offset by a reduction in our effective tax rate to 26.8% as compared to 32.9% in fiscal 2016. |

[0001375365-19-000039:mdna:15]
| • | Our cash and cash equivalents were $110.6 million at the end of fiscal year 2017, compared with $178.8 million at the end of fiscal year 2016. The decrease in our cash and cash equivalents at the end of fiscal year 2017 was primarily due to $96.2 million of cash used in our operating activities and $29.4 million of purchases of property, plant and equipment, of which $16.1 million was related to property and equipment in connection with the construction of buildings at our Green Computing Park in San Jose, California, partially offset by $66.6 million of borrowings, net of repayments. |

[0001375365-19-000039:mdna:16]
| • | The cash conversion cycle is the sum of days of sales outstanding (“DSO”) and days of inventory outstanding (“DIO”), less days of purchases outstanding (“DPO”). Cash conversion cycle at the end of fiscal year 2017 was 86 days compared with 76 at the end of fiscal year 2016. DSO and DIO at the end of fiscal year 2017 were 3 days higher and 6 days higher, respectively, than at the end of fiscal year 2016. DPO at the end of fiscal year 2017 was 1 day lower than at the end of fiscal year 2016. |

[0001375365-19-000039:mdna:17]
| • | Our inventory balance was $736.7 million at the end of fiscal year 2017, compared with $516.8 million at the end |

[0001375365-19-000039:mdna:18]
of fiscal year 2016. The increase in inventory was to meet current demand and expected future sales volume growth.

[0001375365-19-000039:mdna:19]
| • | Our purchase commitments with contract manufacturers and suppliers were $309.1 million at the end of fiscal year 2017 and $334.0 million at the end of fiscal year 2016. |

[0001375365-19-000039:mdna:20]
Subsequent Events

[0001375365-19-000039:mdna:21]
For details, see Part II, Item 8, Note 18, “Subsequent Events” in our notes to the consolidated financial statements in this Annual Report on Form 10-K.

[0001375365-19-000039:mdna:22]
Fiscal Year

[0001375365-19-000039:mdna:23]
Our fiscal year ends on June 30. References to fiscal year 2017, for example, refer to the fiscal year ended June 30, 2017.

[0001375365-19-000039:mdna:24]
Critical Accounting Policies

[0001375365-19-000039:mdna:25]
General

[0001375365-19-000039:mdna:26]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates.

[0001375365-19-000039:mdna:27]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report on Form 10-K. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-19-000039:mdna:28]
Revenue Recognition

[0001375365-19-000039:mdna:29]
Product sales. We recognize revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of our products to customers, unless customer acceptance is uncertain or significant obligations to the customer remain: (i) persuasive evidence of an arrangement exists through customer contracts and orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

[0001375365-19-000039:mdna:30]
We estimate reserves for future sales returns based on a review of our history of actual returns for each major product line. We also reduce revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

[0001375365-19-000039:mdna:31]
We may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement between the distributor and us.

[0001375365-19-000039:mdna:32]
Services sales. Our sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000039:mdna:33]
Multiple-element arrangements. Certain of our arrangements contain multiple elements, consisting of both our products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

[0001375365-19-000039:mdna:34]
We allocate arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available. We do not have VSOE for deliverables in our arrangements, and TPE is generally not available because our products are highly differentiated, and we are unable to obtain reliable information on the products and pricing practices of our competitors. BESP reflects our estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

[0001375365-19-000039:mdna:35]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. We determine BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.

[0001375365-19-000039:mdna:36]
Product Warranties

[0001375365-19-000039:mdna:37]
We offer product warranties ranging from 15 to 39 months against any defective products. We accrue for estimated returns of defective products at the time revenue is recognized based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. We adjust the changes in estimates on an ongoing basis as a result of new product introductions or changes in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, and we account for the changes in estimates prospectively.

[0001375365-19-000039:mdna:38]
Inventories

[0001375365-19-000039:mdna:39]
Inventories are stated at weighted average cost, subject to lower of cost or market. Inventories consist of purchased parts and raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value for purchased parts and raw materials. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon usage and sales, anticipated sales price, product obsolescence and other factors. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped.

[0001375365-19-000039:mdna:40]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates are recognized as a reduction of cost of inventories and reduces the cost of sales in the period when the related inventory is sold.

[0001375365-19-000039:mdna:41]
Income Taxes

[0001375365-19-000039:mdna:42]
We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-19-000039:mdna:43]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related charge in our tax provision during the period in which we make such determination.

[0001375365-19-000039:mdna:44]
Stock-Based Compensation

[0001375365-19-000039:mdna:45]
We measure and recognize compensation expense for all share-based awards made to employees, consultants and non-employee members of our Board of Directors including stock options and restricted stock units ("RSUs"). We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of RSUs is based on the closing market price of our common stock on the date of grant. We estimated the fair value of stock options granted using a Black-Scholes option-pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000039:mdna:46]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001375365-19-000039:mdna:47]
Variable Interest Entities

[0001375365-19-000039:mdna:48]
We determine at the inception of each arrangement whether an entity in which we hold an investment or in which we have other variable interests in is considered a variable interest entity ("VIE"). We consolidate VIEs when we are the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE; and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, we assess whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether we are the primary beneficiary. If we are not the primary beneficiary in a VIE, we account for the investment under the equity method or cost method in accordance with the applicable GAAP.

[0001375365-19-000039:mdna:49]
We have concluded that Ablecom Technology, Inc. ("Ablecom") and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary as we do not have the power to direct the activities that are most significant to the entities and therefore, we do not consolidate these entities. In performing this analysis, our management considered our explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between us and these two companies, management considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests from suffering losses. Management determined that no implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-19-000039:mdna:50]
We and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the “Management Company”) in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. We have concluded that the Management Company is a VIE, and although the operations of the Management Company are independent, through governance rights we have the power to direct the activities that are most significant to the Management Company. Therefore, we concluded that we are the primary beneficiary of the Management Company. For the fiscal years ended 2017, 2016 and 2015, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom’s interests in the net assets and operations of the Management Company. In fiscal years 2017, 2016 and 2015, $(14,000), $20,000 and $(11,000) of net income (loss) attributable to Ablecom’s interest was included in our general and administrative expenses in the consolidated statements of operations, respectively.

[0001375365-19-000039:mdna:51]
Results of Operations

[0001375365-19-000039:mdna:52]
Net Sales

[0001375365-19-000039:mdna:53]
Net sales consist of sales of our server solutions, including server systems and related services, subsystems, accessories. The main factors that impact our net sales are the number of compute nodes sold, the average selling prices per node for our server system sales and units shipped and the average selling price per unit for our subsystem and accessories. The prices for our server systems range widely depending upon the configuration, including the number of compute nodes, and the prices for our subsystems and accessories vary based on the type. A compute node is a hardware configuration having its own CPU, RAM and storage and that is capable of running its own instance of a non-virtualized operating system. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based products, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products.

[0001375365-19-000039:mdna:54]
The following table presents net sales by product type for fiscal years 2017, 2016 and 2015 (dollars in millions):

[0001375365-19-000039:mdna:55]
|  | Fiscal Years Ended June 30, |  | 2017 over 2016 Change |  | 2016 over 2015 Change |
|  | 2017 |  | 2016 |  | 2015 |  | $ |  | % |  | $ |  | % |
| Server systems | $ | 1,740.6 |  |  | $ | 1,533.4 |  |  | $ | 1,186.3 |  |  | $ | 207.2 |  |  | 13.5 | % |  | $ | 347.1 |  |  | 29.3 | % |
| Percentage of total net sales | 70.0 | % |  | 68.9 | % |  | 60.7 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 744.3 |  |  | 691.6 |  |  | 768.1 |  |  | 52.7 |  |  | 7.6 | % |  | (76.5 | ) |  | (10.0 | )% |
| Percentage of total net sales | 30.0 | % |  | 31.1 | % |  | 39.3 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 2,484.9 |  |  | $ | 2,225.0 |  |  | $ | 1,954.4 |  |  | $ | 259.9 |  |  | 11.7 | % |  | $ | 270.6 |  |  | 13.8 | % |

[0001375365-19-000039:mdna:56]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:57]
The year-over-year increase of $259.9 million in our net sales in fiscal year 2017 compared with fiscal year 2016 was primarily due to an increase in sales of our server systems.

[0001375365-19-000039:mdna:58]
The year-over-year increase in server system sales was primarily due to an increase of average selling price per node from $2,902 in fiscal year 2016 to $3,118 in fiscal year 2017. The increase in average selling prices of our server systems was primarily due to higher sales of our complete server systems that offer higher density computing and more memory and hard drive capacity. The year-over-year increase in net sales of our subsystems and accessories in fiscal year 2017 was primarily due to higher sales of server accessories to our distributors.

[0001375365-19-000039:mdna:59]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:60]
The year-over-year increase of $270.6 million in our net sales in fiscal year 2016 compared with fiscal year 2015 was due to an increase in sales of our server systems partially offset by reduced sales of subsystems.

[0001375365-19-000039:mdna:61]
The year-over-year increase in server system sales was primarily due to an approximately 15% increase in server system shipping volume and an increase of average selling price per node from $2,661 in fiscal year 2015 to $2,902 in fiscal year 2016. The increase in average selling prices of our server systems was primarily due to higher sales of our complete server

[0001375365-19-000039:mdna:62]
systems that offer higher density computing and more memory and hard drive capacity. The year-over-year decrease in net sales of our subsystems and accessories in fiscal year 2016 was primarily due lower sales of hard drives and memory bundled with our server solutions to our distributors and system integrators as we continued to promote our sales of complete server systems to our OEM and direct customers.

[0001375365-19-000039:mdna:63]
The following table presents the percentages of net sales from products sold to distributors and OEMs and direct customers for fiscal years 2017, 2016 and 2015:

[0001375365-19-000039:mdna:64]
|  | Years Ended June 30, |  | 2017 over 2016 |  | 2016 over 2015 |
|  | 2017 |  | 2016 |  | 2015 |  | % |  | % |
| Distributors | 47.8 | % |  | 45.8 | % |  | 49.6 | % |  | 2 | % |  | (3.8 | )% |
| OEMs and direct customers | 52.2 | % |  | 54.2 | % |  | 50.4 | % |  | (2 | )% |  | 3.8 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001375365-19-000039:mdna:65]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:66]
The year-over-year increase in net sales to distributors in fiscal year 2017 as a percentage of total net sales as compared with fiscal year 2016 was primarily due to the higher sales to our system integrator customers. The year-over-year decrease in net sales to direct and OEM customers in fiscal year 2017 as a percentage of total net sales as compared with fiscal year 2016 was primarily due to lower demand for our complete server systems from cloud computing and internet data center customers.

[0001375365-19-000039:mdna:67]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:68]
The year-over-year decrease in net sales to distributors in fiscal year 2016 as a percentage of total net sales as compared with fiscal year 2015 was primarily due to the lower sales of our subsystem and accessories, which are typically sold through distributors. The year-over-year increase in net sales to direct and OEM customers in fiscal year 2016 as a percentage of total net sales as compared with fiscal year 2015 was primarily due to the higher sales of our complete server systems to our cloud computing and internet data center customers.

[0001375365-19-000039:mdna:69]
The following table presents percentages of net sales by geographic region for fiscal years 2017, 2016 and 2015:

[0001375365-19-000039:mdna:70]
|  | Years Ended June 30, |  | 2017 over 2016 |  | 2016 over 2015 |
|  | 2017 |  | 2016 |  | 2015 |  | % |  | % |
| United States | 57.2 | % |  | 63.3 | % |  | 58.8 | % |  | (6.1 | )% |  | 4.5 | % |
| Asia | 20.2 | % |  | 14.4 | % |  | 16.0 | % |  | 5.8 | % |  | (1.6 | )% |
| Europe | 18.3 | % |  | 17.4 | % |  | 18.8 | % |  | 0.9 | % |  | (1.4 | )% |
| Others | 4.3 | % |  | 4.9 | % |  | 6.4 | % |  | (0.6 | )% |  | (1.5 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001375365-19-000039:mdna:71]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:72]
The year-over-year decrease in net sales in the United States in fiscal year 2017 was primarily due to the lower sales of our server systems to our cloud computing and internet data center customers. As a result, our United States sales as a percentage of total net sales decreased in fiscal year 2017 compared with fiscal year 2016. The year-over-year increase in net sales in Asia and Europe in fiscal 2017 as a percentage of total net sales as compared with fiscal year 2016 was due primarily to increased sales to our channel partners in China, Taiwan, Japan and the United Kingdom.

[0001375365-19-000039:mdna:73]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:74]
The year-over-year increase in net sales in the United States in fiscal year 2016 as a percentage of total net sales as compared with fiscal year 2015 was primarily due to the higher sales of our server systems to our cloud computing and internet data center customers, which sales represent a higher portion of sales in the United States than in other regions. The year-over-year decrease in net sales in Asia and Europe in fiscal year 2016 as a percentage of total net sales as compared with fiscal year

[0001375365-19-000039:mdna:75]
2015 was primarily due to lower sales growth of our server systems in China and the United Kingdom as compared to other regions.

[0001375365-19-000039:mdna:76]
Cost of Sales and Gross Margin

[0001375365-19-000039:mdna:77]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change in the cost of materials based on market conditions. As a result, our cost of sales as a percentage of sales in any period can be negatively impacted by significant component price increases resulting from component shortages.

[0001375365-19-000039:mdna:78]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2017, we continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 11.1%, 12.8% and 13.8% of our cost of sales for fiscal years 2017, 2016 and 2015, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 11, “Related Party Transactions.”

[0001375365-19-000039:mdna:79]
Cost of sales and gross margin for fiscal years 2017, 2016 and 2015, are as follows (dollars in millions):

[0001375365-19-000039:mdna:80]
|  | Years Ended June 30, |  | 2017 over 2016 Change |  | 2016 over 2015 Change |
|  | 2017 |  | 2016 |  | 2015 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 2,135.0 |  |  | $ | 1,894.5 |  |  | $ | 1,647.8 |  |  | $ | 240.5 |  |  | 12.7 | % |  | $ | 246.7 |  |  | 15.0 | % |
| Gross profit | 350.0 |  |  | 330.5 |  |  | 306.6 |  |  | 19.5 |  |  | 5.9 | % |  | 23.9 |  |  | 7.8 | % |
| Gross margin | 14.1 | % |  | 14.9 | % |  | 15.7 | % |  |  |  | (0.8 | )% |  |  |  | (0.8 | )% |

[0001375365-19-000039:mdna:81]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:82]
The year-over-year increase of $240.5 million in cost of sales in fiscal year 2017 compared with fiscal year 2016 was primarily attributable to an increase of $225.1 million in product cost as related to the increase in net sales and shortages of memory and SSD components, an increase of $6.3 million in inventory provision primarily due to an increase in aged inventory and an increase in reserves for specific product issues, an increase of $4.4 million in warranty provision due to higher cost of servicing warranty claims from increased net sales in fiscal year 2017, and an increase of $4.2 million in compensation and benefits including stock-based compensation as a result of an increase in annual salaries and an increase of 81 operations personnel to support the growth of our business.

[0001375365-19-000039:mdna:83]
The year-over-year decrease in the gross margin percentage in fiscal year 2017 compared with fiscal year 2016 was primarily due to higher costs related to shortages of memory and SSD components, as well as a higher percentage of sales of our server systems being comprised of mature, late life cycle processors that generally are lower margin sales. In addition, in fiscal year 2017 as compared with fiscal year 2016, we had higher sales in Asia where pricing is typically more competitive, which had a negative impact on our gross margin percentage.

[0001375365-19-000039:mdna:84]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:85]
The year-over-year increase of $246.7 million in cost of sales in fiscal year 2016 compared with fiscal year 2015 was primarily attributable to an increase of $222.2 million in product cost as related to the increase in net sales, an increase of $9.1 million in compensation and benefits including stock-based compensation as a result of an increase in annual salaries and an

[0001375365-19-000039:mdna:86]
increase of 137 operations personnel to support the growth of our business, an increase of $4.7 million in facility expense, an increase of $3.5 million in inventory provision due to more reserves for specific products, an increase of $1.7 million in warranty provision due to higher cost of servicing warranty claims from increased net sales in fiscal year 2016 and an increase of $1.6 million of depreciation expenses.

[0001375365-19-000039:mdna:87]
The year-over-year decrease in the gross margin percentage in fiscal year 2016 compared with fiscal year 2015 was primarily due to significantly lower gross margins from sales of our subsystem and accessories and lower utilization of manufacturing capacity partially offset by higher sales of our complete server systems such as storage servers which have a higher gross margin.

[0001375365-19-000039:mdna:88]
Operating Expenses

[0001375365-19-000039:mdna:89]
Research and development expenses consist of the personnel and related expenses including stock-based compensation of our research and development teams, and materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering (“NRE”) funding from certain suppliers and customers for joint development. Under these programs, we are reimbursed for certain research and development costs that we incur as part of the joint development of our products and those of our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-19-000039:mdna:90]
Sales and marketing expenses consist primarily of salaries, stock-based compensation and incentive bonuses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these programs, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with significant product releases by our suppliers.

[0001375365-19-000039:mdna:91]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses, financial reporting, information technology, corporate governance and compliance and outside legal, audit and tax fees.

[0001375365-19-000039:mdna:92]
Operating expenses for fiscal years 2017, 2016 and 2015 are as follows (dollars in millions):

[0001375365-19-000039:mdna:93]
|  | Years Ended June 30, |  | 2017 over 2016 Change |  | 2016 over 2015 Change |
|  | 2017 |  | 2016 |  | 2015 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 144.0 |  |  | $ | 124.2 |  |  | $ | 101.4 |  |  | $ | 19.8 |  |  | 15.9 | % |  | $ | 22.8 |  |  | 22.5 | % |
| Percentage of total net sales | 5.8 | % |  | 5.6 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 66.4 |  |  | $ | 58.3 |  |  | $ | 47.5 |  |  | $ | 8.1 |  |  | 13.9 | % |  | $ | 10.8 |  |  | 22.7 | % |
| Percentage of total net sales | 2.7 | % |  | 2.6 | % |  | 2.4 | % |  |  |  |  |  |  |  |  |
| General and administrative | $ | 44.7 |  |  | $ | 40.5 |  |  | $ | 25.0 |  |  | $ | 4.2 |  |  | 10.4 | % |  | $ | 15.5 |  |  | 62.0 | % |
| Percentage of total net sales | 1.8 | % |  | 1.8 | % |  | 1.3 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 255.1 |  |  | $ | 223.0 |  |  | $ | 173.9 |  |  | $ | 32.1 |  |  | 14.4 | % |  | $ | 49.1 |  |  | 28.2 | % |
| Percentage of total net sales | 10.3 | % |  | 10.0 | % |  | 8.9 | % |  |  |  |  |  |  |  |  |

[0001375365-19-000039:mdna:94]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:95]
Research and development expenses increased by $19.8 million, or 15.9% in fiscal year 2017 as compared with fiscal year 2016 primarily due to an increase of $21.0 million in compensation and benefits expense, including stock-based compensation expense and an increase of $1.4 million in product development expenses for prototype materials. The increase was partially offset by an increase of $3.4 million reimbursement received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products. Our compensation and benefit expense increased primarily as a result of an increase in annual salaries and an increase of 168 research and development personnel to support our expanded product development initiatives in the United States and in Taiwan and to support the growth of our business.

[0001375365-19-000039:mdna:96]
Sales and marketing expenses increased by $8.1 million, or 13.9%, in fiscal year 2017 as compared with fiscal year 2016 primarily due to an increase of $4.8 million in compensation and benefits, including stock-based compensation, as a result of an increase in annual salaries and an increase of 47 sales and marketing personnel, and an increase of $1.5 million in advertising and promotion expenses.

[0001375365-19-000039:mdna:97]
General and administrative expenses increased by $4.2 million, or 10.4% in fiscal year 2017 as compared with fiscal year 2016. The increase was primarily due to an increase of $7.1 million in compensation and benefits including stock-based compensation expense, partially offset by a $2.4 million decrease in legal and professional fees. Our compensation and benefit expense in general and administrative expenses increased primarily as a result of an increase in annual salaries and an increase of 45 personnel to support our expanded business.

[0001375365-19-000039:mdna:98]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:99]
Research and development expenses increased by $22.8 million, or 22.5% in fiscal year 2016 compared with fiscal year 2015 primarily due to an increase of $18.1 million in compensation and benefits, including stock-based compensation expense and an increase of $3.3 million in development expenses for prototype materials. Our compensation and benefit expense increased primarily as a result of an increase in annual salaries and an increase of 146 research and development personnel to support our expanded product development initiatives in the United States and in Taiwan and to support the growth of our business in many market verticals.

[0001375365-19-000039:mdna:100]
Sales and marketing expenses increased by $10.8 million, or 22.7%, in fiscal year 2016 as compared with fiscal year 2015 primarily due to an increase of $7.4 million in compensation and benefits, including stock-based compensation as a result of an increase in annual salaries and an increase of 42 sales and marketing personnel, and an increase of $2.5 million in advertising and promotion expenses.

[0001375365-19-000039:mdna:101]
General and administrative expenses increased by $15.5 million, or 62.0% in fiscal year 2016 as compared with fiscal year 2015. The increase was primarily due to an increase of $9.8 million in compensation and benefits including stock-based compensation expense, an increase of $4.8 million increase in legal, audit and accounting fees primarily due to costs incurred in connection with an out of period correction of errors in the first quarter of fiscal year 2016 and remediation of internal control deficiencies and an increase of $1.1 million in bad debt expenses. Our compensation and benefit expense in general and administrative expenses increased primarily as a result of an increase in annual salaries and an increase of 83 personnel to support our expanded business.

[0001375365-19-000039:mdna:102]
Interest and Other Income (Expense), Net

[0001375365-19-000039:mdna:103]
Other income (expense), net consists primarily of interest earned on our investment and cash balances, share of loss from equity investee and foreign exchange gains and losses.

[0001375365-19-000039:mdna:104]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-19-000039:mdna:105]
Interest and other income (expense), net for fiscal years 2017, 2016 and 2015 are as follows (dollars in millions):

[0001375365-19-000039:mdna:106]
|  | Years Ended June 30, |  | 2017 over 2016 Change |  | 2016 over 2015 Change |
|  | 2017 |  | 2016 |  | 2015 |  | $ |  | % |  | $ |  | % |
| Other income (expense), net | $ | (1.3 | ) |  | $ | 1.5 |  |  | $ | 1.0 |  |  | $ | (2.8 | ) |  | (186.7 | )% |  | $ | 0.5 |  |  | 50.0 | % |
| Interest expense | (2.3 | ) |  | (1.6 | ) |  | (1.0 | ) |  | (0.7 | ) |  | 43.8 | % |  | (0.6 | ) |  | 60.0 | % |
| Interest and other income (expense), net | $ | (3.6 | ) |  | $ | (0.1 | ) |  | $ | — |  |  | $ | (3.5 | ) |  | * |  |  | $ | (0.1 | ) |  | * |  |

[0001375365-19-000039:mdna:107]
* Not meaningful

[0001375365-19-000039:mdna:108]
Interest and other income (expense), net. Interest and other income (expense), net increased by $3.5 million in fiscal year 2017 compared with fiscal year 2016. The increase was primarily due to an unrealized foreign currency loss related the remeasurement of our NTD$700.0 million term loan denominated in NTD. Interest and other expense, net remained consistent in fiscal year 2016 as compared with fiscal year 2015.

[0001375365-19-000039:mdna:109]
Provision for Income Taxes

[0001375365-19-000039:mdna:110]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits and the domestic production activities deduction which were partially offset by state taxes and unrecognized tax benefits related to permanent establishment exposures. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 13, “Income Taxes” to the consolidated financial statements in this Annual Report on Form 10-K.

[0001375365-19-000039:mdna:111]
Provision for income taxes and effective tax rates for fiscal years 2017, 2016 and 2015 are as follows (dollars in millions):

[0001375365-19-000039:mdna:112]
|  | Years Ended June 30, |  | 2017 over 2016 Change |  | 2016 over 2015 Change |
|  | 2017 |  | 2016 |  | 2015 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 24.4 |  |  | $ | 35.3 |  |  | $ | 40.1 |  |  | $ | (10.9 | ) |  | (30.9 | )% |  | $ | (4.8 | ) |  | (12.0 | )% |
| Percentage of total net sales | 1.0 | % |  | 1.6 | % |  | 2.1 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 26.8 | % |  | 32.9 | % |  | 30.2 | % |  |  |  |  |  |  |  |  |

[0001375365-19-000039:mdna:113]
Fiscal Year 2017 compared with Fiscal Year 2016

[0001375365-19-000039:mdna:114]
Provision for income taxes decreased by $10.9 million, or 30.9% in fiscal year 2017 compared with fiscal year 2016. The lower income tax provision for fiscal year 2017 was primarily attributable to our lower income from operations as compared with fiscal year 2016. The effective tax rate for fiscal year 2017, was lower than in fiscal year 2016 and the statutory tax rate of 35%, primarily due to tax benefits resulting from the completion of U.S. federal income tax audit and an income tax audit in a foreign jurisdiction as well as research and development tax credit and domestic production activities deductions.

[0001375365-19-000039:mdna:115]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001375365-19-000039:mdna:116]
Provision for income taxes decreased by $4.8 million, or 12.0% in fiscal year 2016 compared with fiscal year 2015. The lower income tax provision for fiscal year 2016 was primarily attributable to our lower operating income as compared with fiscal year 2015. The effective tax rate for fiscal year 2016 was higher as compared with fiscal year 2015 primarily due to the lower foreign rate benefits and foreign unrecognized tax benefits offset in part by the increase in federal research and development credit as a result of the enactment of the Protecting Americans from Tax Hikes ("PATH") Act of 2015.

[0001375365-19-000039:mdna:117]
Liquidity and Capital Resources

[0001375365-19-000039:mdna:118]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents were $110.6 million and $178.8 million as of June 30, 2017 and 2016, respectively. Our cash in foreign locations was $50.8 million and $46.5 million as of June 30, 2017 and 2016, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations. We believe that our current cash and cash equivalents are adequate to meet our needs, including any debt balances due at maturity, for the next twelve months from the issuance of these consolidated financial statements.

[0001375365-19-000039:mdna:119]
Fiscal Year 2017

[0001375365-19-000039:mdna:120]
Operating Activities. Net cash used in operating activities was $96.2 million in fiscal year 2017.

[0001375365-19-000039:mdna:121]
Net cash used in our operating activities for fiscal year 2017 was primarily due to an increase in inventories of $235.6 million and an increase in accounts receivable of $149.5 million, which were partially offset by an increase in accounts payable of $135.3 million, our net income of $66.9 million, an increase in accrued liabilities of $27.6 million, stock-based compensation expense of $19.7 million, an increase in other long term liabilities of $17.9 million, provision for excess and obsolete inventories of $15.7 million, and depreciation and amortization expense of $16.4 million. The increase in accounts receivable was primarily due to higher sales volume in the fourth quarter of fiscal year 2017. The increase in inventories and accounts payable was primarily due to increased sales as well as increased market prices for inventories related to memory and SSD components. In addition, we staged inventory to support new product launches.

[0001375365-19-000039:mdna:122]
Investing activities. Net cash used in our investing activities was $29.7 million in fiscal year 2017 due primarily to $29.4 million associated with investments in property, plant and equipment, of which $16.1 million was related to the construction of buildings at our Green Computing Park in San Jose, California.

[0001375365-19-000039:mdna:123]
Financing activities. Net cash provided by our financing activities was $57.7 million for fiscal year 2017. In fiscal year 2017, we drew down $207.0 million on our revolving credit facility with Bank of America and CTBC Bank and repaid $140.5 million in loans. We received $10.9 million in connection with the exercise of stock options in fiscal year 2017. Further, we used $18.5 million in the repurchase of our outstanding common stock.

[0001375365-19-000039:mdna:124]
Fiscal Year 2016

[0001375365-19-000039:mdna:125]
Operating Activities. Net cash provided by operating activities was $108.0 million for fiscal year 2016. Net cash provided by our operating activities for fiscal year 2016 was primarily due to our net income of $72.1 million, a decrease in accounts receivable of $53.6 million, an increase in other long term liabilities of $20.0 million, stock-based compensation expense of $16.9 million, depreciation and amortization expense of $13.3 million, provision for excess and obsolete inventories of $9.4 million and an increase in accrued liabilities of $12.9 million, which were partially offset by a decrease in accounts payable of $65.8 million and an increase in prepaid expenses and other current assets of $23.5 million. The decrease for fiscal year 2016 as compared with fiscal year 2015 in accounts receivable was primarily due to lower sales volume in the fourth quarter of fiscal year 2016. The decrease for fiscal year 2016 as compared with fiscal year 2015 in inventories and accounts payable was primarily due to anticipated lower sales volume in the first quarter of fiscal year 2017.

[0001375365-19-000039:mdna:126]
Investing activities. Net cash used in our investing activities was $35.1 million in fiscal year 2016, which was primarily due to $34.1 million associated with investments in property, plant and equipment, of which $16.7 million was related to the construction of buildings at our Green Computing Park in San Jose, California, and of which $3.4 million was related to the implementation of a new ERP system for our United States headquarters and our subsidiaries.

[0001375365-19-000039:mdna:127]
Financing activities. Net cash provided by our financing activities was $13.1 million for fiscal year 2016. In fiscal year 2016, we drew down $34.2 million on our revolving lines of credit with Bank of America and CTBC Bank and repaid $34.1 million in loans. Further, we received $12.2 million in connection with the exercise of stock options in fiscal year 2016.

[0001375365-19-000039:mdna:128]
Fiscal Year 2015

[0001375365-19-000039:mdna:129]
Operating Activities. Net cash used in operating activities was $46.1 million for fiscal year 2015. Net cash used in our operating activities for fiscal year 2015 was primarily due to an increase in inventories of $177.6 million and an increase in accounts receivable of $78.2 million, which were partially offset by our net income of $92.6 million, an increase in accounts payable of $81.7 million, stock-based compensation expense of $14.4 million, an increase in net income taxes payable of $9.0 million, an increase in accrued liabilities of $13.9 million, depreciation and amortization expense of $8.1 million, increase in other long-term liabilities of $7.7 million and provision for excess and obsolete inventories of $5.9 million. The increase in accounts receivable was primarily due to an increase in our sales late in the fourth quarter. The increase in inventories and accounts payable was primarily due to higher purchases to support the anticipated level of growth in our net sales in fiscal year 2016.

[0001375365-19-000039:mdna:130]
Investing activities. Net cash used in our investing activities was $36.2 million in fiscal year 2015, which was primary due to a $35.1 million investment in property, plant and equipment, of which $21.8 million related to the development and construction of our first manufacturing building and warehouse at our Green Computing Park in San Jose, California, which was completed in August 2015, and of which $4.8 million related to the implementation of a new ERP system.

[0001375365-19-000039:mdna:131]
Financing activities. Net cash provided by our financing activities was $80.0 million for fiscal year 2015. In fiscal year 2015, we drew down $84.9 million on our revolving line of credit from Bank of America and CTBC Bank and repaid $36.0 million in loans. Further, we received $23.3 million in connection with the exercise of stock options in fiscal year 2015.

[0001375365-19-000039:mdna:132]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on our revolving credit facility or through other debt financing. However, we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will

[0001375365-19-000039:mdna:133]
be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources.

[0001375365-19-000039:mdna:134]
Other factors affecting liquidity and capital resources

[0001375365-19-000039:mdna:135]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000039:mdna:136]
Bank of America

[0001375365-19-000039:mdna:137]
2015 Bank of America Credit Facility

[0001375365-19-000039:mdna:138]
In June 2015, we entered into an amendment to our then existing credit agreement with Bank of America N.A. (“Bank of America”) which provided for (i) a $65.0 million revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14.0 million term loan facility (collectively, the “2015 Bank of America Credit Facility”). The term loan was secured by three buildings located in San Jose, California and the principal and interest was payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, we extended the revolving line of credit to mature on June 30, 2016.

[0001375365-19-000039:mdna:139]
2016 Bank of America Credit Facility

[0001375365-19-000039:mdna:140]
In June 2016, we entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that was to mature on June 30, 2017 and (ii) a five-year $50.0 million term loan facility (collectively, the “2016 Bank of America Credit Facility”). The 2016 Bank of America Credit Facility replaced the 2015 Bank of America Credit Facility. The 2016 Bank of America Credit Facility term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the 2016 Bank of America Credit Facility revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 1.04% at June 30, 2017. The letter of credit bears interest at a rate of 1.25% per annum. In May 2017, we entered into an amendment to the 2016 Bank of America Credit Facility to increase the revolving line of credit to $85.0 million and extended the maturity date of the revolving lines of credit to October 31, 2018. Prior to the maturity, in April 2018, we repaid and terminated the 2016 Bank of America Credit Facility with proceeds from a new revolving line of credit (the "2018 Bank of America Credit Facility").

[0001375365-19-000039:mdna:141]
In June 2016, we also entered into a separate credit agreement as a part of the 2016 Bank of America Credit Facility, which provided for a revolving line of credit of $10.0 million for our Taiwan and Netherlands subsidiaries that was to mature on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds. In December 2016, we entered into an amendment to this separate credit agreement to increase the revolving line of credit from $10.0 million to $20.0 million. We extended the revolving line of credit to mature on October 31, 2018. Under the terms of this separate credit agreement, we cannot directly or indirectly pay any dividends, except in limited situations.

[0001375365-19-000039:mdna:142]
As of June 30, 2017 and 2016, the total outstanding borrowings under the 2016 Bank of America Credit Facility term loans was $40.0 million and $0.9 million, respectively. The total outstanding borrowings under the 2016 Bank of America Credit Facility revolving lines of credit was $83.2 million and $62.2 million as of June 30, 2017 and 2016, respectively. The interest rates for these loans ranged from 1.61% to 2.46% per annum as of June 30, 2017 and from 1.02% to 1.96% per annum as of June 30, 2016, respectively. As of June 30, 2017, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $21.8 million. As of June 30, 2017, assets amounting to $1,168.6 million collateralized the line of credit with Bank of America under the credit agreement, which represent our total assets of the United States headquarters, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of June 30, 2017, total assets collateralizing the term loan with Bank of America under the credit agreement were $67.9 million.

[0001375365-19-000039:mdna:143]
2018 Bank of America Credit Facility

[0001375365-19-000039:mdna:144]
In April 2018, we entered into the 2018 Bank of America Credit Facility, which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders. The 2018 Bank of America Credit Facility expires after 364 days, or at our option, and if certain conditions are satisfied, including being current on all of our delinquent quarterly and annual filings with the SEC, may convert into a 5-year revolving credit facility. If and upon such conversion, the lenders for the

[0001375365-19-000039:mdna:145]
2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the 5-year revolving credit facility, interest shall be at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the 5-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of our assets. Upon conversion to the 5-year revolving credit facility both Super Micro Computer’s assets, and at our option, Super Micro Computer B.V.'s assets will be used as collateral. Under the terms of the 2018 Bank of America Credit Facility, we cannot pay any dividends.

[0001375365-19-000039:mdna:146]
On January 31, 2019, we paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date of the 2018 Bank of America Credit Facility from April 19, 2019 to June 30, 2019.

[0001375365-19-000039:mdna:147]
CTBC Bank

[0001375365-19-000039:mdna:148]
In April 2016, we entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by our land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which was adjusted monthly, which term loan facility also included a 12-month line of guarantee up to NTD$100.0 million or $3.1 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “CTBC Credit Facility”). The total borrowings allowed under the CTBC Credit Facility was capped at $40.0 million. We extended the CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000039:mdna:149]
In May 2017, we renewed the credit agreement with respect to the CTBC Credit Facility, such that it provides for (i) a 12-month NTD$700.0 million or $23.0 million U.S. dollar equivalent term loan facility secured by our land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also included a 12-month line of guarantee up to NTD$100.0 million or $3.3 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which is adjusted monthly. The total borrowings allowed under the CTBC Credit Facility were capped at $50.0 million.

[0001375365-19-000039:mdna:150]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in Taiwanese dollars and remeasured into U.S. dollars of $19.7 million and $20.4 million at June 30, 2017 and 2016, respectively. At June 30, 2017 and 2016, the total outstanding borrowings under the CTBC Credit Facility revolving line of credit was $19.0 million and $10.1 million, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.93% and 2.00% at June 30, 2017 and 0.90% and 1.25% per annum at June 30, 2016. At June 30, 2017, the amount available for future borrowing under the CTBC Credit Facility was $11.3 million. As of June 30, 2017, the net book value of land and building located in Bade, Taiwan collateralizing the CTBC Credit Facility term loan was $26.4 million. Under the terms of the May 2017 renewed credit agreement, the CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity we entered into a new credit agreement with CTBC Bank in January 2018.

[0001375365-19-000039:mdna:151]
In January 2018, we entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD$700.0 million or $23.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month line of guarantee up to NTD$100.0 million or $3.4 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month NTD$1,500.0 million or $50.5 million U.S. dollar equivalent term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, (collectively, the “2018 CTBC Credit Facility”). The 2018 CTBC Credit Facility replaced the CTBC Credit Facility. The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018, was reduced to $40.0 million. In April 2019, we extended the maturity of 2018 CTBC Credit Facility to June 30, 2019.

[0001375365-19-000039:mdna:152]
Covenant Compliance

[0001375365-19-000039:mdna:153]
2018 Bank of America Credit Facility

[0001375365-19-000039:mdna:154]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us. The credit agreement contains a financial covenant, which requires that we maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. We have maintained compliance with this covenant.

[0001375365-19-000039:mdna:155]
On September 7, 2018, Bank of America issued an extension letter to us in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, we entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019, of our audited consolidated financial statements for the fiscal year ended June 30, 2017. In April 2019, we paid a fee to extend the delivery of our audited consolidated financial statements for the fiscal year ended June 30, 2017 to June 30, 2019. We intend to negotiate the further extension for delivery of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018.

[0001375365-19-000039:mdna:156]
CTBC Bank

[0001375365-19-000039:mdna:157]
There are no financial covenants associated with the CTBC Credit Facility or the 2018 CTBC Credit Facility.

[0001375365-19-000039:mdna:158]
Share Repurchase Program

[0001375365-19-000039:mdna:159]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100.0 million of our common stock in the open market or in private transactions during the next twelve months at prevailing market prices. In fiscal year 2017, we purchased 888,097 shares of our common stock in the open market at a weighted average price of $20.79 per share for approximately $18.5 million. Repurchases were made under the program using our cash resources. The repurchase program ended in July 2017.

[0001375365-19-000039:mdna:160]
Contractual Obligations

[0001375365-19-000039:mdna:161]
The following table describes our contractual obligations as of June 30, 2017:

[0001375365-19-000039:mdna:162]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,844 |  |  | $ | 8,505 |  |  | $ | 3,605 |  |  | $ | 3,951 |  |  | $ | 20,905 |  |
| Capital leases, including interest | 309 |  |  | 433 |  |  | 140 |  |  | — |  |  | 882 |  |
| Debt, including interest (1) | 163,823 |  |  | — |  |  | — |  |  | — |  |  | 163,823 |  |
| Purchase commitments (2) | 309,120 |  |  | — |  |  | — |  |  | — |  |  | 309,120 |  |
| Total (3) | $ | 478,096 |  |  | $ | 8,938 |  |  | $ | 3,745 |  |  | $ | 3,951 |  |  | $ | 494,730 |  |

[0001375365-19-000039:mdna:163]
__________________________

[0001375365-19-000039:mdna:164]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at June 30, 2017. In 2018, we amended our existing credit agreement with CTBC Bank, which changed our maximum borrowing capacity to $40.0 million and in January 2019 extended the maturity to June 30, 2019. In April 2018, we repaid and terminated the 2016 Bank of America Credit Facility with proceeds from the 2018 Bank of America Credit Facility. The 2018 Bank of America Credit Facility increases our borrowing capacity from $155.0 million to $250.0 million with Bank of America. In January 2019, we extended the maturity of the 2018 Bank of America Credit Facility from April 19, 2019 to June 30, 2019. |

[0001375365-19-000039:mdna:165]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. See Part II, Item 8, Note 14, “Commitments and Contingencies” to the consolidated financial statements in this Annual Report on Form 10-K for a discussion of purchase commitments. |

[0001375365-19-000039:mdna:166]
| (3) | The table above excludes liabilities for deferred revenue of $80.5 million, $6.3 million of deferred gain related to our remaining performance obligations in association with the contribution of certain technology rights to a privately-held company located in China, and unrecognized tax benefits and related interest and penalties accrual of $13.3 million. |

[0001375365-19-000039:mdna:167]
Deferred revenue represents billed services in advance which include extended warranty, on-site technical support, and hardware and software maintenance. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Part II, Item 8, Note 13, “Income Taxes” to the consolidated financial statements in this Annual Report on Form 10-K for a discussion of income taxes.

[0001375365-19-000039:mdna:168]
We expect to fund our remaining contractual obligations from our ongoing operations and existing cash and cash equivalents on hand.

[0001375365-19-000039:mdna:169]
Recent Accounting Pronouncements

[0001375365-19-000039:mdna:170]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report on Form 10-K.

[0001375365-19-000039:mdna:171]
Off-Balance Sheet Arrangements

[0001375365-19-000039:mdna:172]
We do not have any off-balance sheet arrangements.
