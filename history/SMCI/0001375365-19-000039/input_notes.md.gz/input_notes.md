# SMCI notes — 0001375365-19-000039


## smci:PropertyPlantAndEquipmentUsefulLifeTableTextBlock

[0001375365-19-000039:notes:1]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-19-000039:notes:2]
| Purchased software | 3 to 5 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |


## smci:SummaryOfAllowanceForDoubtfulAccountsAndSalesReturnsTableTextBlock

[0001375365-19-000039:notes:3]
Accounts receivable allowances as of June 30, 2017, 2016 and 2015 consisted of the following (in thousands):

[0001375365-19-000039:notes:4]
|  | BeginningBalance |  | Charged toCost andExpenses |  | Additions/(Deductions) |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2017 | $ | 2,033 |  |  | $ | 334 |  |  | $ | 3 |  |  | $ | 2,370 |  |
| Year ended June 30, 2016 | 952 |  |  | 1,216 |  |  | (135 | ) |  | 2,033 |  |
| Year ended June 30, 2015 | 1,474 |  |  | 80 |  |  | (602 | ) |  | 952 |  |
| Allowance for sales returns |  |  |  |  |  |  |  |
| Year ended June 30, 2017 | $ | 380 |  |  | $ | 1,745 |  |  | $ | (1,796 | ) |  | $ | 329 |  |
| Year ended June 30, 2016 | 430 |  |  | 2,288 |  |  | (2,338 | ) |  | 380 |  |
| Year ended June 30, 2015 | 448 |  |  | 2,069 |  |  | (2,087 | ) |  | 430 |  |


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001375365-19-000039:notes:5]
Restatement of Previously Issued Consolidated Financial Statements

[0001375365-19-000039:notes:6]
In August 2017, prior to the issuance of the Company’s consolidated financial statements for the fiscal year ended June 30, 2017, the audit committee (the “Audit Committee”) of the Company’s Board of Directors (the “Board”) commenced an investigation (the “Investigation”) into certain accounting and internal control matters at the Company, principally focused on certain revenue recognition matters. The Investigation was conducted with the assistance of outside counsel, which retained forensic accountants to assist them in their work. Following the conclusion of the Investigation, the Audit Committee directed its outside counsel and its forensic accountants to conduct additional procedures on an expanded scope of revenue recognition matters. Concurrent with these additional procedures, new members of the Company’s management, under the direction of the Audit Committee, performed a thorough analysis of the Company’s historical financial statements, accounting policies and financial reporting, as well as the Company’s disclosure controls and procedures and its internal control over financial reporting. During the course of the Investigation, the further procedures by outside counsel and the management analysis (collectively, the “Investigation, Procedures and Analysis”), the Audit Committee and management determined certain employees had violated the Company’s Code of Business Conduct and Ethics and discovered accounting and financial reporting errors and certain irregularities. On November 14, 2018, the Board, upon the recommendation, and with the concurrence of the Audit Committee and new members of management, concluded that certain previously filed consolidated financial statements and related financial information should no longer be relied upon.

[0001375365-19-000039:notes:7]
As a result, within these consolidated financial statements, the Company has included the restated consolidated financial statements as of and for the years ended June 30, 2016 and June 30, 2015, which is referred to as the "Restatement". The Restatement corrects errors and certain irregularities which are discussed in detail within this footnote.

[0001375365-19-000039:notes:8]
The errors and certain irregularities primarily related to the timing of recognition of (i) revenue, (ii) expenses related to certain inventory used for engineering and marketing purposes and (iii) expenses related to defective products under warranty not returned by customers. Additionally, errors were identified whereby the Company had derecognized inventory while control over such inventory was retained because the Company was obligated to buy it back.

[0001375365-19-000039:notes:9]
Restatement

[0001375365-19-000039:notes:10]
The following is a discussion of the restatement adjustments that were made to the Company’s previously issued consolidated financial statements.

[0001375365-19-000039:notes:11]
(a) Product revenue

[0001375365-19-000039:notes:12]
During the fiscal years ended June 30, 2016 and 2015, product revenue was recognized prematurely. As a result of the information gathered in the Investigation, Procedures and Analysis, it was determined that there was an aggressive focus on quarterly revenue without sufficient focus on compliance by an appropriate number of competent resources, and all relevant information was not communicated among the Company’s internal functions as well as the management to both the Audit Committee and the independent auditors that resulted in the inappropriate recording of revenue with insufficient documentation or rigorous assessment of revenue transactions. The Company found instances where (i) title and risk of loss had not transferred to the customer, (ii) persuasive evidence of an arrangement with the customer consistent with the Company’s customary business practices was not present, (iii) the distributor’s price was not fixed or determinable, or (iv) collectibility was not reasonably assured, all of which resulted in premature recognition of revenue.

[0001375365-19-000039:notes:13]
Also, during the fiscal years ended June 30, 2016 and 2015, revenue was misstated as it was determined from the information gathered in the Investigation, Procedures and Analysis there was a misapplication of accounting principles related to the classification of consideration paid to customers under the Company’s cooperative marketing arrangements for which the Company did not receive an identifiable benefit.

[0001375365-19-000039:notes:14]
To correct the errors and certain irregularities related to premature revenue recognition, the related revenue and cost of sales were reversed in the period in which the accounting errors took place and have been recognized in subsequent periods when all of the revenue recognition criteria were met. The correction of these errors resulted in net sales for 2016 being increased by $8.8 million, and net sales for 2015 being decreased by $21.5 million, and cost of sales for 2016 increased by $11.1 million, and for 2015 decreased by $21.7 million from amounts previously reported. Additionally, certain related adjustments to reverse accounts receivable, net, of $60.6 million and to recognize inventories of $48.7 million were made to amounts previously reported as of June 30, 2016. Additionally, certain related adjustments to accounts payable and accrued liabilities, which also impacted cost of sales and sales and marketing expense, were made to the consolidated financial statements in which the accounting errors and certain irregularities occurred.

[0001375365-19-000039:notes:15]
The Company corrected errors related to consideration paid to customers under the Company’s cooperative marketing arrangements for which the Company did not receive an identifiable benefit, as well as the value of free samples provided to customers. These transactions were incorrectly recorded as sales and marketing expense and have now been corrected and recorded as a reduction of revenue. The correction of these errors resulted in net sales and sales and marketing expense for 2016 and 2015 being reduced by $3.6 million and $2.5 million, respectively, from amounts previously reported.

[0001375365-19-000039:notes:16]
(b) Services revenue

[0001375365-19-000039:notes:17]
During the fiscal years ended June 30, 2016 and 2015, services revenue was misstated as it was determined that as a result of the information gathered in the Investigation, Procedures and Analysis there were errors related to inaccurate allocation of contract consideration for multiple element arrangements resulting from (a) lack of proper identification or accounting for contractual service obligations, (b) incorrect allocation of discounts to service related deliverables, and (c) lack of a robust process resulting in inaccurate determination of BESP. Additionally, there were misalignments of the revenue recognition period and the contractual requisite service period. Consequently, certain contracts for extended warranties on products or on-site services in multiple element arrangements were incorrectly recorded as revenue at the time of sale of the product instead of being deferred and amortized over the contractual warranty or service period. The Company had previously identified a portion of these errors in the amount of $9.0 million related to extended warranty in a prior period and had adjusted the consolidated financial statements for the fiscal year ended June 30, 2016 for their cumulative effect with an out-of-period correction to revenues.

[0001375365-19-000039:notes:18]
To correct these errors, the Company reversed the revenue and the out-of-period correction to revenues in the period in which the accounting errors or out-of-period adjustment took place, quantified an amount for these services by determining a best estimated selling price for these services based on a percentage of the separately priced product deliverables in the arrangement, and deferred and amortized the quantified amount of revenue over the contractual warranty or service period. Additionally, certain related adjustments to deferred revenues, which are included in accrued liabilities and other long-term liabilities, were made to the consolidated balance sheet at the end of the period in which the errors occurred. The correction of these errors resulted in net sales for 2016 being increased by $3.9 million and net sales for 2015 being reduced by $11.3 million, accrued liabilities being increased by $9.3 million and other long-term liabilities being increased by $4.6 million as of June 30, 2016 from amounts previously reported.

[0001375365-19-000039:notes:19]
(c) Inventory

[0001375365-19-000039:notes:20]
As of June 30, 2016 and 2015, inventories were overstated due to misapplication of accounting principles, whereby materials issued from inventory to research and development projects and marketing with no alternative use were included as inventory and expensed upon completion of a project rather than being expensed upon consumption.

[0001375365-19-000039:notes:21]
Also as of June 30, 2016 and 2015, inventories were understated due to misapplication of accounting principles, whereby (i) inventory of materials transferred to certain contract manufacturers was improperly derecognized upon transfer that the Company retained control over the materials because it was obligated to buy them back; and (ii) in-transit inventory was not being recorded in the appropriate period due to improper cut-off procedures.

[0001375365-19-000039:notes:22]
To correct the errors related to inventory overstatement, the Company has recorded the materials as a research and development expense, or a marketing expense, in the period that inventory was consumed. The correction of the overstatement errors resulted in a $2.1 million decrease in inventories as of June 30, 2016 from amounts previously reported.

[0001375365-19-000039:notes:23]
To correct the errors related to inventory understatement, the Company has adjusted the carrying value of inventory in the periods in which the errors took place. The correction of these understatement errors resulted in a $20.8 million increase in inventories, as well as $16.1 million increase in accrued liabilities as of June 30, 2016 from amounts previously reported. Additionally, certain related adjustments to cost of sales, inventories, accounts payable and accrued liabilities were made to the consolidated financial statements in the period in which the errors occurred.

[0001375365-19-000039:notes:24]
(d) Other

[0001375365-19-000039:notes:25]
The Company corrected the following errors impacting the consolidated financial statements:

[0001375365-19-000039:notes:26]
| • | The Company did not correctly record receivables from suppliers as prepaid expenses and other current assets. The correction of this error resulted in a $56.3 million decrease in accounts receivable, net, a $63.6 million increase in prepaid expenses and other current assets, and an increase to accounts payable of $7.3 million as of June 30, 2016 from amounts previously reported. |

[0001375365-19-000039:notes:27]
| • | The Company did not record the payments for certain payroll tax related liabilities, as well as did not accrue certain withholding tax liabilities, in the appropriate periods. The correction of the error resulted in a $2.1 million decrease in cash and cash equivalents, and a corresponding decrease in accrued liabilities as of June 30, 2016 from amounts previously reported. |

[0001375365-19-000039:notes:28]
The Company corrected other immaterial misstatements relating to (i) sales taxes, (ii) stock-based compensation expense, (iii) accounts receivable and related allowances, (iv) other assets, (v) accounts payable, and (vi) prepaid expenses and other current assets.

[0001375365-19-000039:notes:29]
Additionally, the Company changed the presentation of foreign exchange gains and losses of $1.5 million and $0.7 million for 2016 and 2015, respectively, from general and administrative expenses, as previously reported, to other income (expense), net in the consolidated statement of operations.

[0001375365-19-000039:notes:30]
(e) Income taxes

[0001375365-19-000039:notes:31]
The Company has recorded tax adjustments to reflect the impacts of the Restatement and other income tax related error corrections.

[0001375365-19-000039:notes:32]
Impact on Consolidated Statements of Operations

[0001375365-19-000039:notes:33]
The effect of the Restatement described above on the accompanying consolidated statements of operations for the fiscal years ended June 30, 2016 and 2015 is as follows (in thousands, except per share amounts):

[0001375365-19-000039:notes:34]
|  | For the Year Ended June 30, 2016 |
|  | As Previously Reported |  | Product Revenue |  | Services Revenue |  | Inventories |  | Other |  | Income Taxes |  | As Restated |
| Net sales (1) | $ | 2,215,573 |  |  | $ | 5,582 |  |  | $ | 3,867 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,225,022 |  |
| Cost of sales (1) | 1,884,048 |  |  | 11,410 |  |  | — |  |  | (926 | ) |  | (11 | ) |  | — |  |  | 1,894,521 |  |
| Gross profit | 331,525 |  |  | (5,828 | ) |  | 3,867 |  |  | 926 |  |  | 11 |  |  | — |  |  | 330,501 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 123,994 |  |  | — |  |  | — |  |  | (367 | ) |  | 596 |  |  | — |  |  | 124,223 |  |
| Sales and marketing | 62,841 |  |  | (4,255 | ) |  | — |  |  | (364 | ) |  | 116 |  |  | — |  |  | 58,338 |  |
| General and administrative | 37,840 |  |  | — |  |  | — |  |  | — |  |  | 2,609 |  |  | — |  |  | 40,449 |  |
| Total operating expenses | 224,675 |  |  | (4,255 | ) |  | — |  |  | (731 | ) |  | 3,321 |  |  | — |  |  | 223,010 |  |
| Income from operations | 106,850 |  |  | (1,573 | ) |  | 3,867 |  |  | 1,657 |  |  | (3,310 | ) |  | — |  |  | 107,491 |  |
| Other income (expense), net | 171 |  |  | — |  |  | — |  |  | — |  |  | 1,336 |  |  | — |  |  | 1,507 |  |
| Interest expense | (1,594 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,594 | ) |
| Income before income tax provision | 105,427 |  |  | (1,573 | ) |  | 3,867 |  |  | 1,657 |  |  | (1,974 | ) |  | — |  |  | 107,404 |  |
| Income tax provision | 33,406 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,917 |  |  | 35,323 |  |
| Net income | $ | 72,021 |  |  | $ | (1,573 | ) |  | $ | 3,867 |  |  | $ | 1,657 |  |  | $ | (1,974 | ) |  | $ | (1,917 | ) |  | $ | 72,081 |  |
| Net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.50 |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.50 |  |
| Diluted | $ | 1.39 |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.39 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 47,917 |  |  |  |  |  |  |  |  |  |  |  |  | 47,917 |  |
| Diluted | 51,836 |  |  |  |  |  |  |  |  |  |  |  |  | 51,836 |  |

[0001375365-19-000039:notes:35]
__________________________

[0001375365-19-000039:notes:36]
(1) Transactions with related parties are included in the line items above as follows:

[0001375365-19-000039:notes:37]
|  | Year Ended June 30, |
|  | 2016 |  |  |  | 2016 |
|  | As Previously Reported |  | Adjustments |  | As Restated |
| Net sales | $ | 19,453 |  |  | $ | 9,657 |  |  | $ | 29,110 |  |
| Cost of sales* | 241,836 |  |  | 802 |  |  | 242,638 |  |

[0001375365-19-000039:notes:38]
* Represents purchases from related parties.

[0001375365-19-000039:notes:39]
|  | For the Year Ended June 30, 2015 |
|  | As Previously Reported |  | Product Revenue |  | Services Revenue |  | Inventories |  | Other |  | Income Taxes |  | As Restated |
| Net sales (1) | $ | 1,991,155 |  |  | $ | (25,542 | ) |  | $ | (11,260 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,954,353 |  |
| Cost of sales (1) | 1,670,924 |  |  | (23,229 | ) |  | — |  |  | (13 | ) |  | 87 |  |  | — |  |  | 1,647,769 |  |
| Gross profit | 320,231 |  |  | (2,313 | ) |  | (11,260 | ) |  | 13 |  |  | (87 | ) |  | — |  |  | 306,584 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 100,257 |  |  | — |  |  | — |  |  | 501 |  |  | 644 |  |  | — |  |  | 101,402 |  |
| Sales and marketing | 48,851 |  |  | (1,814 | ) |  | — |  |  | 386 |  |  | 73 |  |  | — |  |  | 47,496 |  |
| General and administrative | 24,377 |  |  | — |  |  | — |  |  | — |  |  | 663 |  |  | — |  |  | 25,040 |  |
| Total operating expenses | 173,485 |  |  | (1,814 | ) |  | — |  |  | 887 |  |  | 1,380 |  |  | — |  |  | 173,938 |  |
| Income from operations | 146,746 |  |  | (499 | ) |  | (11,260 | ) |  | (874 | ) |  | (1,467 | ) |  | — |  |  | 132,646 |  |
| Other income (expense), net | 115 |  |  | — |  |  | — |  |  | — |  |  | 841 |  |  | — |  |  | 956 |  |
| Interest expense | (965 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (965 | ) |
| Income before income tax provision | 145,896 |  |  | (499 | ) |  | (11,260 | ) |  | (874 | ) |  | (626 | ) |  | — |  |  | 132,637 |  |
| Income tax provision | 44,033 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (3,951 | ) |  | 40,082 |  |
| Net income | $ | 101,863 |  |  | $ | (499 | ) |  | $ | (11,260 | ) |  | $ | (874 | ) |  | $ | (626 | ) |  | $ | 3,951 |  |  | $ | 92,555 |  |
| Net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 2.19 |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.99 |  |
| Diluted | $ | 2.03 |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.85 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 46,434 |  |  |  |  |  |  |  |  |  |  |  |  | 46,434 |  |
| Diluted | 50,094 |  |  |  |  |  |  |  |  |  |  |  |  | 50,094 |  |

[0001375365-19-000039:notes:40]
|  | Year Ended June 30, |
|  | 2015 |  |  |  | 2015 |
|  | As Previously Reported |  | Adjustments |  | As Restated |
| Net sales | $ | 58,013 |  |  | $ | (10,329 | ) |  | $ | 47,684 |  |
| Cost of sales* | 227,562 |  |  | 99 |  |  | 227,661 |  |

[0001375365-19-000039:notes:41]
Impact on Consolidated Balance Sheet

[0001375365-19-000039:notes:42]
The effect of the Restatement described above on the accompanying consolidated balance sheet as of June 30, 2016 is as follows (in thousands):

[0001375365-19-000039:notes:43]
|  | As of June 30, 2016 |
|  | As Previously Reported |  | Product Revenue |  | Services Revenue |  | Inventories |  | Other |  | Income Taxes |  | As Restated |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 180,964 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (2,144 | ) |  | $ | — |  |  | $ | 178,820 |  |
| Accounts receivable, net (1)* | 288,941 |  |  | (60,590 | ) |  | — |  |  | — |  |  | (53,418 | ) |  | — |  |  | 174,933 |  |
| Inventories | 448,980 |  |  | 48,714 |  |  | — |  |  | 18,205 |  |  | 908 |  |  | — |  |  | 516,807 |  |
| Prepaid income taxes | 5,682 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,341 | ) |  | 4,341 |  |
| Prepaid expenses and other current assets (1) | 13,435 |  |  | — |  |  | — |  |  | — |  |  | 65,992 |  |  | — |  |  | 79,427 |  |
| Total current assets | 938,002 |  |  | (11,876 | ) |  | — |  |  | 18,205 |  |  | 11,338 |  |  | (1,341 | ) |  | 954,328 |  |
| Long-term investments | 2,643 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,643 |  |
| Property, plant, and equipment, net | 187,949 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 187,949 |  |
| Deferred income taxes, net | 28,460 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,218 |  |  | 33,678 |  |
| Other assets | 8,546 |  |  | — |  |  | — |  |  | — |  |  | 4,339 |  |  | — |  |  | 12,885 |  |
| Total assets | $ | 1,165,600 |  |  | $ | (11,876 | ) |  | $ | — |  |  | $ | 18,205 |  |  | $ | 15,677 |  |  | $ | 3,877 |  |  | $ | 1,191,483 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable (1) | $ | 249,239 |  |  | $ | 5 |  |  | $ | — |  |  | $ | 2,981 |  |  | $ | 15,166 |  |  | $ | — |  |  | $ | 267,391 |  |
| Accrued liabilities (1) | 55,618 |  |  | (128 | ) |  | 9,313 |  |  | 16,251 |  |  | 2,542 |  |  | — |  |  | 83,596 |  |
| Income taxes payable | 5,172 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (118 | ) |  | 5,054 |  |
| Short-term debt and current portion of long-term debt | 53,589 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 53,589 |  |
| Total current liabilities | 363,618 |  |  | (123 | ) |  | 9,313 |  |  | 19,232 |  |  | 17,708 |  |  | (118 | ) |  | 409,630 |  |
| Long-term debt | 40,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40,000 |  |
| Other long-term liabilities | 40,603 |  |  | — |  |  | 4,597 |  |  | — |  |  | — |  |  | — |  |  | 45,200 |  |
| Total liabilities | 444,221 |  |  | (123 | ) |  | 13,910 |  |  | 19,232 |  |  | 17,708 |  |  | (118 | ) |  | 494,830 |  |
| Stockholders' equity: |  |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital | 277,339 |  |  | — |  |  | — |  |  | — |  |  | 2,067 |  |  | 59 |  |  | 279,465 |  |
| Treasury stock | (2,030 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,030 | ) |
| Accumulated other comprehensive loss | (85 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (85 | ) |
| Retained earnings | 445,971 |  |  | (11,753 | ) |  | (13,910 | ) |  | (1,027 | ) |  | (4,098 | ) |  | 3,936 |  |  | 419,119 |  |
| Total Super Micro Computer, Inc. stockholders' equity | 721,195 |  |  | (11,753 | ) |  | (13,910 | ) |  | (1,027 | ) |  | (2,031 | ) |  | 3,995 |  |  | 696,469 |  |
| Noncontrolling interest | 184 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 184 |  |
| Total stockholders’ equity | 721,379 |  |  | (11,753 | ) |  | (13,910 | ) |  | (1,027 | ) |  | (2,031 | ) |  | 3,995 |  |  | 696,653 |  |
| Total liabilities and stockholders' equity | $ | 1,165,600 |  |  | $ | (11,876 | ) |  | $ | — |  |  | $ | 18,205 |  |  | $ | 15,677 |  |  | $ | 3,877 |  |  | $ | 1,191,483 |  |

[0001375365-19-000039:notes:44]
* Previously reported allowances for accounts receivable as of June 30, 2016 were $2,721, now corrected and restated to $2,413.

[0001375365-19-000039:notes:45]
|  | As of June 30, 2016 |
|  | As Reported |  | Adjustments |  | As Restated |
| Accounts receivable, net | $ | 4,678 |  |  | $ | (4,629 | ) |  | $ | 49 |  |
| Prepaid expenses and other current assets | — |  |  | 9,622 |  |  | 9,622 |  |
| Accounts payable | 39,152 |  |  | 5,789 |  |  | 44,941 |  |
| Accrued liabilities | — |  |  | 5,354 |  |  | 5,354 |  |

[0001375365-19-000039:notes:46]
Cumulative Effect of Prior Period Adjustments

[0001375365-19-000039:notes:47]
The following table presents the impact of the Restatement on the beginning stockholders’ equity as of June 30, 2014 (in thousands):

[0001375365-19-000039:notes:48]
|  | Common Stock and Additional Paid-in Capital |  | Treasury Stock |  | Accumulated Other Comprehensive Loss |  | Retained Earnings |  | Total Super Micro Computer Stockholders’ Equity |  | Non-controlling interest |  | Total Stockholders’ Equity |
| Balance, June 30, 2014 (As previously reported) | $ | 199,062 |  |  | $ | (2,030 | ) |  | $ | (63 | ) |  | $ | 272,087 |  |  | $ | 469,056 |  |  | $ | 175 |  |  | $ | 469,231 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue recognition | — |  |  | — |  |  | — |  |  | (9,681 | ) |  | (9,681 | ) |  | — |  |  | (9,681 | ) |
| Service revenue | — |  |  | — |  |  | — |  |  | (6,518 | ) |  | (6,518 | ) |  | — |  |  | (6,518 | ) |
| Inventory | — |  |  | — |  |  | — |  |  | (1,809 | ) |  | (1,809 | ) |  | — |  |  | (1,809 | ) |
| Other | 531 |  |  | — |  |  | — |  |  | (1,498 | ) |  | (967 | ) |  | — |  |  | (967 | ) |
| Restatement tax impacts | — |  |  | — |  |  | — |  |  | 1,902 |  |  | 1,902 |  |  | — |  |  | 1,902 |  |
| Cumulative restatement adjustments | 531 |  |  | — |  |  | — |  |  | (17,604 | ) |  | (17,073 | ) |  | — |  |  | (17,073 | ) |
| Balance, June 30, 2014 (As Restated) | $ | 199,593 |  |  | $ | (2,030 | ) |  | $ | (63 | ) |  | $ | 254,483 |  |  | $ | 451,983 |  |  | $ | 175 |  |  | $ | 452,158 |  |

[0001375365-19-000039:notes:49]
Other changes to the consolidated statements of stockholders’ equity for the years ended June 30, 2016 and 2015 as a result of the Restatement are due to the changes in net income and changes to additional paid in capital related to the impact of the correction of errors to stock-based compensation expense.

[0001375365-19-000039:notes:50]
Impact on Consolidated Statements of Comprehensive Loss

[0001375365-19-000039:notes:51]
The only change to the consolidated statements of comprehensive loss for the years ended June 30, 2016 and 2015 as a result of the Restatement is due to the changes in net income.

[0001375365-19-000039:notes:52]
Impact on Consolidated Statements of Cash Flows

[0001375365-19-000039:notes:53]
The effect of the Restatement described above on the accompanying consolidated statements of cash flows for the years ended June 30, 2016 and 2015 is as follows (in thousands):

[0001375365-19-000039:notes:54]
|  | Year Ended June 30, 2016 |
|  | As Previously Reported |  | RestatementAdjustments |  | As Restated |
| OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income | $ | 72,021 |  |  | $ | 60 |  |  | $ | 72,081 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 13,282 |  |  | — |  |  | 13,282 |  |
| Stock-based compensation expense | 16,131 |  |  | 799 |  |  | 16,930 |  |
| Excess tax benefits from stock-based compensation | (2,855 | ) |  | 43 |  |  | (2,812 | ) |
| Allowance for doubtful accounts | 1,278 |  |  | (62 | ) |  | 1,216 |  |
| Provision for excess and obsolete inventories | 9,313 |  |  | 71 |  |  | 9,384 |  |
| Foreign currency exchange gain | (1,233 | ) |  | (106 | ) |  | (1,339 | ) |
| Deferred income taxes, net | (6,133 | ) |  | 921 |  |  | (5,212 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net (1) | 32,375 |  |  | 21,200 |  |  | 53,575 |  |
| Inventories | 5,200 |  |  | 2,509 |  |  | 7,709 |  |
| Prepaid expenses and other assets (1) | (8,210 | ) |  | (15,329 | ) |  | (23,539 | ) |
| Accounts payable (1) | (54,301 | ) |  | (11,534 | ) |  | (65,835 | ) |
| Income taxes payable | (3,260 | ) |  | 2,874 |  |  | (386 | ) |
| Accrued liabilities (1) | 9,027 |  |  | 3,884 |  |  | 12,911 |  |
| Other long-term liabilities | 24,874 |  |  | (4,852 | ) |  | 20,022 |  |
| Net cash provided by operating activities | 107,509 |  |  | 478 |  |  | 107,987 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property, plant and equipment (1) | (34,108 | ) |  | — |  |  | (34,108 | ) |
| Change in restricted cash | (1,020 | ) |  | — |  |  | (1,020 | ) |
| Net cash used in investing activities | (35,128 | ) |  | — |  |  | (35,128 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from debt, net of issuance costs | 34,200 |  |  | — |  |  | 34,200 |  |
| Repayment of debt | (34,100 | ) |  | — |  |  | (34,100 | ) |
| Proceeds from exercise of stock options | 12,186 |  |  | — |  |  | 12,186 |  |
| Excess tax benefits from stock-based compensation | 2,855 |  |  | (43 | ) |  | 2,812 |  |
| Payments of obligations under capital leases | (189 | ) |  | — |  |  | (189 | ) |
| Payments under receivable financing arrangements | (21 | ) |  | — |  |  | (21 | ) |
| Payment of withholding tax on vesting of restricted stock units | (1,786 | ) |  | — |  |  | (1,786 | ) |
| Net cash provided by financing activities | 13,145 |  |  | (43 | ) |  | 13,102 |  |
| Effect of exchange rate fluctuations on cash | (4 | ) |  | (57 | ) |  | (61 | ) |
| Net increase in cash and cash equivalents | 85,522 |  |  | 378 |  |  | 85,900 |  |
| Cash and cash equivalents at beginning of year | 95,442 |  |  | (2,522 | ) |  | 92,920 |  |
| Cash and cash equivalents at end of year | $ | 180,964 |  |  | $ | (2,144 | ) |  | $ | 178,820 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |
| Cash paid for interest | $ | 1,632 |  |  | $ | — |  |  | $ | 1,632 |  |
| Cash paid for taxes, net of refunds | $ | 36,951 |  |  | $ | — |  |  | $ | 36,951 |  |
| Non-cash investing and financing activities: |  |  |  |  |  |
| Equipment purchased under capital leases | $ | 299 |  |  | $ | — |  |  | $ | 299 |  |
| Unpaid property, plant and equipment purchases (1) | $ | 10,888 |  |  | $ | (39 | ) |  | $ | 10,849 |  |

[0001375365-19-000039:notes:55]
|  | Years Ended June 30, |
|  | 2016 |  |  |  | 2016 |
|  | As Reported |  | Adjustments |  | As Restated |
| OPERATING ACTIVITIES: |  |  |  |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Accounts receivable, net | $ | 8,508 |  |  | $ | (8,428 | ) |  | $ | 80 |  |
| Prepaid expenses and other assets | — |  |  | 652 |  |  | 652 |  |
| Accounts payable | (19,863 | ) |  | (2,024 | ) |  | (21,887 | ) |
| Accrued liabilities | — |  |  | (340 | ) |  | (340 | ) |
| INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (4,641 | ) |  | (4,641 | ) |
| NON-CASH INVESTING AND FINANCING ACTIVITIES: |  |  |  |  |  |
| Unpaid property, plant and equipment purchases | — |  |  | 2,246 |  |  | 2,246 |  |

[0001375365-19-000039:notes:56]
|  | Year Ended June 30, 2015 |
|  | As Previously Reported |  | RestatementAdjustments |  | As Restated |
| OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income | $ | 101,863 |  |  | $ | (9,308 | ) |  | $ | 92,555 |  |
| Reconciliation of net income to net cash used in operating activities: |  |  |  |  |  |
| Depreciation and amortization | 8,133 |  |  | (39 | ) |  | 8,094 |  |
| Stock-based compensation expense | 13,699 |  |  | 737 |  |  | 14,436 |  |
| Excess tax benefits from stock-based compensation | (8,089 | ) |  | 43 |  |  | (8,046 | ) |
| Allowance for doubtful accounts | 326 |  |  | (246 | ) |  | 80 |  |
| Provision for excess and obsolete inventories | 5,928 |  |  | 2 |  |  | 5,930 |  |
| Foreign currency exchange gain | (675 | ) |  | (155 | ) |  | (830 | ) |
| Deferred income taxes, net | 632 |  |  | (4,208 | ) |  | (3,576 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Accounts receivable, net (1) | (110,182 | ) |  | 31,996 |  |  | (78,186 | ) |
| Inventories | (153,584 | ) |  | (23,973 | ) |  | (177,557 | ) |
| Prepaid expenses and other assets (1) | (2,741 | ) |  | (8,585 | ) |  | (11,326 | ) |
| Accounts payable (1) | 75,520 |  |  | 6,181 |  |  | 81,701 |  |
| Income taxes payable | 11,951 |  |  | (2,972 | ) |  | 8,979 |  |
| Accrued liabilities (1) | 9,551 |  |  | 4,342 |  |  | 13,893 |  |
| Other long-term liabilities | 3,032 |  |  | 4,696 |  |  | 7,728 |  |
| Net cash used in operating activities | (44,636 | ) |  | (1,489 | ) |  | (46,125 | ) |
| INVESTING ACTIVITIES: |  |  |  |  |  |
| Purchases of property, plant and equipment (1) | (35,100 | ) |  | — |  |  | (35,100 | ) |
| Change in restricted cash | (416 | ) |  | — |  |  | (416 | ) |
| Investment in a privately held company | (661 | ) |  | — |  |  | (661 | ) |
| Net cash used in investing activities | (36,177 | ) |  | — |  |  | (36,177 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |
| Proceeds from debt, net of issuance costs | 84,900 |  |  | — |  |  | 84,900 |  |
| Repayments of debt | (36,000 | ) |  | — |  |  | (36,000 | ) |
| Proceeds from exercise of stock options | 23,338 |  |  | — |  |  | 23,338 |  |
| Excess tax benefits from stock-based compensation | 8,089 |  |  | (43 | ) |  | 8,046 |  |
| Payment of obligations under capital leases | (134 | ) |  | — |  |  | (134 | ) |
| Advances under receivable financing arrangements | 33 |  |  | — |  |  | 33 |  |
| Payment of withholding tax on vesting of restricted stock units | (175 | ) |  | — |  |  | (175 | ) |
| Net cash provided by financing activities | 80,051 |  |  | (43 | ) |  | 80,008 |  |
| Effect of exchange rate fluctuations on cash | (668 | ) |  | 400 |  |  | (268 | ) |
| Net decrease in cash and cash equivalents | (1,430 | ) |  | (1,132 | ) |  | (2,562 | ) |
| Cash and cash equivalents at beginning of year | 96,872 |  |  | (1,390 | ) |  | 95,482 |  |
| Cash and cash equivalents at end of year | $ | 95,442 |  |  | $ | (2,522 | ) |  | $ | 92,920 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |
| Cash paid for interest | $ | 933 |  |  | $ | — |  |  | $ | 933 |  |
| Cash paid for taxes, net of refunds | $ | 30,671 |  |  | $ | — |  |  | $ | 30,671 |  |
| Non-cash investing and financing activities: |  |  |  |  |  |
| Equipment purchased under capital leases | $ | 442 |  |  | $ | — |  |  | $ | 442 |  |
| Unpaid property, plant and equipment purchases (1) | $ | 6,826 |  |  | $ | 236 |  |  | $ | 7,062 |  |

[0001375365-19-000039:notes:57]
|  | Years Ended June 30, |
|  | 2015 |  |  |  | 2015 |
|  | As Reported |  | Adjustments |  | As Restated |
| OPERATING ACTIVITIES: |  |  |  |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Accounts receivable, net | $ | (12,565 | ) |  | $ | 13,057 |  |  | $ | 492 |  |
| Prepaid expenses and other assets | — |  |  | (10,274 | ) |  | (10,274 | ) |
| Accounts payable | 10,046 |  |  | 12,142 |  |  | 22,188 |  |
| Accrued liabilities | — |  |  | 1,364 |  |  | 1,364 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (4,070 | ) |  | (4,070 | ) |
| NON-CASH INVESTING AND FINANCING ACTIVITIES: |  |  |  |  |  |
| Unpaid property, plant and equipment purchases | — |  |  | 724 |  |  | 724 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001375365-19-000039:notes:58]
Accrued Liabilities

[0001375365-19-000039:notes:59]
Accrued liabilities as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:60]
|  | June 30, |
|  | 2017 |  | 2016 |
| Deferred revenue (1) | $ | 32,957 |  |  | $ | 22,731 |  |
| Accrued payroll and related expenses | 19,370 |  |  | 15,499 |  |
| Customer deposits | 14,630 |  |  | 8,781 |  |
| Accrued cooperative marketing expenses | 7,292 |  |  | 7,308 |  |
| Accrued warranty costs | 5,976 |  |  | 5,816 |  |
| Others (2) | 32,599 |  |  | 23,461 |  |
| Total accrued liabilities | $ | 112,824 |  |  | $ | 83,596 |  |

[0001375365-19-000039:notes:61]
(1) Deferred revenue as of June 30, 2017 and 2016, is comprised primarily of a deferred extended warranty revenue of $17.5 million and $15.5 million, respectively, deferred on-site service revenue of $13.7 million and $6.2 million, respectively, and other deferred revenue of $1.8 million and $1.0 million, respectively.

[0001375365-19-000039:notes:62]
(2) Includes payables to contract manufacturers for the Company's buy-back liability of $20.3 million and $16.1 million as of June 30, 2017 and June 30, 2016, respectively. Also, included in others as of June 30, 2017 is $1.4 million of deferred gain related to investment in Corporate Venture.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001375365-19-000039:notes:63]
Advertising Costs

[0001375365-19-000039:notes:64]
Advertising costs are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001375365-19-000039:notes:65]
Cash and Cash Equivalents

[0001375365-19-000039:notes:66]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposits with original maturities of less than three months.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-19-000039:notes:67]
Commitments and Contingencies

[0001375365-19-000039:notes:68]
Litigation and Claims— In February 2018, the Company became a party to legal proceedings whereby complainants have alleged that it has violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions. See Note 18, "Subsequent Events" for further details. From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001375365-19-000039:notes:69]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-19-000039:notes:70]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through the next 12 months. As of June 30, 2017, these remaining noncancelable commitments were $309.1 million, including $79.9 million for related parties.

[0001375365-19-000039:notes:71]
Lease Commitments—The Company leases offices and equipment under noncancelable operating leases which expire at various dates through 2026. In addition, the Company leases certain of its equipment under capital leases. The future minimum lease commitments under all leases are as follows (in thousands):

[0001375365-19-000039:notes:72]
| Year ending: | CapitalLeases |  | OperatingLeases |
| June 30, 2018 | $ | 309 |  |  | $ | 4,844 |  |
| June 30, 2019 | 271 |  |  | 4,399 |  |
| June 30, 2020 | 162 |  |  | 4,106 |  |
| June 30, 2021 | 101 |  |  | 2,033 |  |
| June 30, 2022 | 39 |  |  | 1,572 |  |
| Thereafter | — |  |  | 3,951 |  |
| Total minimum lease payments | 882 |  |  | $ | 20,905 |  |
| Less: Amounts representing interest | 70 |  |  |  |
| Present value of minimum lease payments | 812 |  |  |  |
| Less: Long-term portion | 539 |  |  |  |
| Current portion | $ | 273 |  |  |  |

[0001375365-19-000039:notes:73]
Rent expense for the fiscal years ended June 30, 2017, 2016 and 2015, was $5.0 million, $4.6 million and $3.7 million, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001375365-19-000039:notes:74]
Basis of Presentation

[0001375365-19-000039:notes:75]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations, and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. Equity investments for which the Company is able to exercise significant influence over but does not control the investee and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments for which the Company is not able to exercise significant influence over the investee are accounted for under the cost method.

[0001375365-19-000039:notes:76]
The accompanying consolidated financial statements have been prepared assuming that the Company will continue as a going concern. Periodically, the Company has generated negative cash flows from operations and has financed its operations through working capital debt. Management believes that the Company’s current cash and cash equivalents are adequate to meet its needs, including any debt balances due at maturity, for the next twelve months from the issuance of these consolidated financial statements.


## us-gaap:CostOfSalesPolicyTextBlock

[0001375365-19-000039:notes:77]
Cost of Sales

[0001375365-19-000039:notes:78]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or market and excess and obsolete inventory.


## us-gaap:DebtDisclosureTextBlock

[0001375365-19-000039:notes:79]
Short-term and Long-term Obligations

[0001375365-19-000039:notes:80]
Short-term and long-term obligations as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:81]
|  | June 30, |
|  | 2017 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 83,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 19,000 |  |  | 10,100 |  |
| Total line of credit | 102,199 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 40,000 |  |  | 933 |  |
| CTBC Bank | 19,721 |  |  | 20,357 |  |
| Total term loans | 59,721 |  |  | 21,290 |  |
| Total debt | 161,920 |  |  | 93,589 |  |
| Less: debt issuance costs | (473 | ) |  | — |  |
| Total debt, net of debt issuance costs | 161,447 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (161,447 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | — |  |  | $ | 40,000 |  |

[0001375365-19-000039:notes:82]
(1) In July 2016, $50.0 million of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and $40.0 million was reclassified to long-term debt as of June 30, 2016.

[0001375365-19-000039:notes:83]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000039:notes:84]
Bank of America

[0001375365-19-000039:notes:85]
2015 Bank of America Credit Facility

[0001375365-19-000039:notes:86]
In June 2015, the Company entered into an amendment to the then existing credit agreement with Bank of America N.A. (“Bank of America”) which provided for (i) a $65.0 million revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14.0 million term loan facility (collectively, the “2015 Bank of America Credit Facility”). The term loan was secured by three buildings located in San Jose, California and the principal and interest was payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, the Company extended the revolving line of credit to mature on June 30, 2016.

[0001375365-19-000039:notes:87]
2016 Bank of America Credit Facility

[0001375365-19-000039:notes:88]
In June 2016, the Company entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that was to mature on June 30, 2017 and (ii) a five-year $50.0 million term loan facility (collectively, the “2016 Bank of America Credit Facility”). The 2016 Bank of America Credit Facility replaced the 2015 Bank of America Credit Facility. The 2016 Bank of America Credit Facility term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the 2016 Bank of America Credit Facility revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 1.04% at June 30, 2017. The letter of credit bears interest at a rate of 1.25% per annum. In May 2017, the Company entered into an amendment to the 2016 Bank of America Credit Facility to increase the revolving line of credit to $85.0 million and extended the maturity date of the revolving lines of credit to October 31, 2018. Prior to the maturity, in April 2018, the Company repaid and terminated the 2016 Bank of America Credit Facility with proceeds from a new revolving line of credit (the "2018 Bank of America Credit Facility").

[0001375365-19-000039:notes:89]
In June 2016, the Company also entered into a separate credit agreement as a part of the 2016 Bank of America Credit Facility, which provided for a revolving line of credit of $10.0 million for its Taiwan and Netherlands subsidiaries that was to mature on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds. In December 2016, the Company entered into an amendment to this separate credit agreement to increase the revolving line of credit from $10.0 million to $20.0 million. The Company extended the revolving line of credit to mature on October 31, 2018. Under the terms of this separate credit agreement, the Company cannot directly or indirectly pay any dividends, except in limited situations.

[0001375365-19-000039:notes:90]
As of June 30, 2017 and 2016, the total outstanding borrowings under the 2016 Bank of America Credit Facility term loans was $40.0 million and $0.9 million, respectively. The total outstanding borrowings under the 2016 Bank of America Credit Facility revolving lines of credit was $83.2 million and $62.2 million as of June 30, 2017 and 2016, respectively. The interest rates for these loans ranged from 1.61% to 2.46% per annum as of June 30, 2017 and from 1.02% to 1.96% per annum as of June 30, 2016, respectively. As of June 30, 2017, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $21.8 million. As of June 30, 2017, assets amounting to $1,168.6 million collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarters of the Company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of June 30, 2017, total assets collateralizing the term loan with Bank of America under the credit agreement were $67.9 million.

[0001375365-19-000039:notes:91]
2018 Bank of America Credit Facility

[0001375365-19-000039:notes:92]
In April 2018, the Company entered into the 2018 Bank of America Credit Facility which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders. The 2018 Bank of America Credit Facility expires after 364 days, or at the option of the Company, and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, may convert into a 5-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the 5-year revolving credit facility, interest shall be at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the 5-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V.. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. Upon conversion to the 5-year revolving credit facility Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral. Under the terms of the 2018 Bank of America Credit Facility, the Company cannot pay any dividends.

[0001375365-19-000039:notes:93]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date of the 2018 Bank of America Credit Facility from April 19, 2019 to June 30, 2019.

[0001375365-19-000039:notes:94]
CTBC Bank

[0001375365-19-000039:notes:95]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which was adjusted monthly, which term loan facility also included a 12-month line of guarantee up to NTD$100.0 million or $3.1 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “CTBC Credit Facility”). The total borrowings allowed under the CTBC Credit Facility was capped at $40.0 million. The Company extended the CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000039:notes:96]
In May 2017, the Company renewed the credit agreement with respect to the CTBC Credit Facility, such that it provides for (i) a 12-month NTD$700.0 million or $23.0 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also included a 12-month line of guarantee up to NTD$100.0 million or $3.3 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which is adjusted monthly. The total borrowings allowed under the CTBC Credit Facility were capped at $50.0 million.

[0001375365-19-000039:notes:97]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in Taiwanese dollars and remeasured into U.S. dollars of $19.7 million and $20.4 million at June 30, 2017 and 2016, respectively. At June 30, 2017 and 2016, the total outstanding borrowings under the CTBC Credit Facility revolving line of credit was $19.0 million and $10.1 million, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.93% and 2.00% at June 30, 2017 and 0.90% and 1.25% per annum at June 30, 2016. At June 30, 2017, the amount available for future borrowing under the CTBC Credit Facility was $11.3 million. As of June 30, 2017, the net book value of land and building located in Bade, Taiwan collateralizing the CTBC Credit Facility term loan was $26.4 million. Under the terms of the May 2017 renewed credit agreement, the CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity the Company entered into a new credit agreement with CTBC Bank in January 2018.

[0001375365-19-000039:notes:98]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD$700.0 million or $23.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month line of guarantee up to NTD$100.0 million or $3.4 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month NTD$1,500.0 million or $50.5 million U.S. dollar equivalent term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The 2018 CTBC Credit Facility replaced the CTBC Credit Facility. The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In April 2019, the Company extended the maturity of 2018 CTBC Credit Facility to June 30, 2019.

[0001375365-19-000039:notes:99]
Covenant Compliance

[0001375365-19-000039:notes:100]
The credit agreement with respect to the 2016 Bank of America Credit Facility contained customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contained certain financial covenants, including the following:

[0001375365-19-000039:notes:101]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001375365-19-000039:notes:102]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; and |

[0001375365-19-000039:notes:103]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $40.0 million, measured quarterly as of the last day of each fiscal quarter. |

[0001375365-19-000039:notes:104]
As of June 30, 2017, the Company was in compliance with the above stated financial covenants associated with the term loan and lines of credit with Bank of America under the credit agreement.

[0001375365-19-000039:notes:105]
On October 28, 2017, Bank of America issued an extension letter to the Company that extended the date by which the Company was obligated to deliver its audited consolidated financial statements and compliance certificate for the fiscal year ended June 30, 2017 from October 28, 2017 to January 15, 2018. On January 12, 2018, Bank of America issued another extension letter to the Company that extended the date by which the Company was obligated to deliver (i) its audited consolidated financial statements and compliance certificate for the fiscal year ended June 30, 2017 from January 15, 2018 to March 13, 2018 and (ii) its unaudited condensed consolidated financial statements and compliance certificate for the fiscal quarters ended September 30, 2017 and December 31, 2017 to March 13, 2018.

[0001375365-19-000039:notes:106]
On March 12, 2018, the Company entered into an amendment of the credit agreement with respect to the 2016 Bank of America Credit Facility to, among other matters, add provisions requiring (i) a new financing commitment by March 30, 2018 to repay all obligations under the 2016 Bank of America Credit Agreement, (ii) repayment of the obligations under the 2016 Bank of America Credit Agreement no later than April 20, 2018, and (iii) delivery of cash flow forecasts. In addition, the amendment suspended the requirement that the Company deliver certain financial statements and SEC filings, provided that no event of default had occurred. In April 2018, the 2016 Bank of America Credit Facility was replaced by the 2018 Bank of America Credit Facility.

[0001375365-19-000039:notes:107]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect.

[0001375365-19-000039:notes:108]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company’s audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company’s audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2017. In April 2019, the Company paid a fee to extend the delivery of its audited consolidated financial statements for the fiscal year ended June 30, 2017 to June 30, 2019. The Company intends to negotiate the further extension for delivery of the Company’s audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018.

[0001375365-19-000039:notes:109]
There are no financial covenants associated with the CTBC Credit Facility or the 2018 CTBC Credit Facility.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001375365-19-000039:notes:110]
Prepaid expenses and other current assets as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:111]
|  | June 30, |
|  | 2017 |  | 2016 |
| Receivables from vendors (1) | $ | 78,656 |  |  | $ | 71,470 |  |
| Prepaid expenses | 5,736 |  |  | 5,405 |  |
| Deferred service costs | 2,910 |  |  | 1,451 |  |
| Others | 1,911 |  |  | 1,101 |  |
| Total prepaid expenses and other current assets | $ | 89,213 |  |  | $ | 79,427 |  |

[0001375365-19-000039:notes:112]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $73.8 million and $63.6 million as of June 30, 2017 and June 30, 2016, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-19-000039:notes:113]
Stock-based Compensation and Stockholders’ Equity

[0001375365-19-000039:notes:114]
Share Repurchase Program

[0001375365-19-000039:notes:115]
In July 2016, the Company’s Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100.0 million of the Company’s common stock in the open market or in private transactions during the following twelve months at prevailing market prices. In fiscal year 2017, the Company purchased 888,097 shares of the Company's common stock in the open market at a weighted average price of $20.79 for $18.5 million. Repurchases were made under the program using the Company’s cash resources. The repurchase program ended in July 2017.

[0001375365-19-000039:notes:116]
Equity Incentive Plan

[0001375365-19-000039:notes:117]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of the date the 2016 Plan became effective, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006 Plan"). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan but that are forfeited in the future will become available for use under the 2016 Plan. In addition, 1,153,412 shares of common stock originally reserved for issuance under the 2006 Plan were cancelled upon the adoption of the 2016 Plan. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of June 30, 2017, the Company had 2,785,792 authorized shares available for future issuance under the 2016 Plan.

[0001375365-19-000039:notes:118]
Determining Fair Value

[0001375365-19-000039:notes:119]
The Company's fair value of RSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000039:notes:120]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and the Company's historical experience.

[0001375365-19-000039:notes:121]
Expected Volatility—Expected volatility is based on a combination of the Company's implied and historical volatility.

[0001375365-19-000039:notes:122]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-19-000039:notes:123]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-19-000039:notes:124]
The fair value of stock option grants for the fiscal years ended June 30, 2017, 2016 and 2015 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-19-000039:notes:125]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Risk-free interest rate | 1.12% - 2.03% |  |  | 1.37% - 1.57% |  |  | 1.35% - 1.76% |  |
| Expected term | 5.31 - 5.38 years |  |  | 5.31 - 5.33 years |  |  | 5.40 - 5.44 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 43.36% - 49.64% |  |  | 46.65% - 50.89% |  |  | 46.93% - 49.31% |  |
| Weighted-average fair value | $ | 10.71 |  |  | $ | 12.07 |  |  | $ | 12.72 |  |

[0001375365-19-000039:notes:126]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2017, 2016 and 2015 (in thousands):

[0001375365-19-000039:notes:127]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Cost of sales | $ | 1,382 |  |  | $ | 1,157 |  |  | $ | 962 |  |
| Research and development | 12,559 |  |  | 10,651 |  |  | 9,195 |  |
| Sales and marketing | 2,144 |  |  | 1,934 |  |  | 1,601 |  |
| General and administrative | 3,580 |  |  | 3,188 |  |  | 2,678 |  |
| Stock-based compensation expense before taxes | 19,665 |  |  | 16,930 |  |  | 14,436 |  |
| Income tax impact | (5,946 | ) |  | (4,767 | ) |  | (4,247 | ) |
| Stock-based compensation expense, net | $ | 13,719 |  |  | $ | 12,163 |  |  | $ | 10,189 |  |

[0001375365-19-000039:notes:128]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options and vesting of RSUs in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $1.8 million, $3.6 million and $11.3 million of excess tax benefits recorded in additional paid-in capital in the fiscal years ended June 30, 2017, 2016 and 2015, respectively. The Company had excess tax benefits classified as cash from financing activities of $2.3 million, $2.8 million and $8.0 million in the fiscal years ended June 30, 2017, 2016 and 2015, respectively, for options issued since July 1, 2006.

[0001375365-19-000039:notes:129]
As of June 30, 2017, $9.8 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.21 years and $27.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.72 years.

[0001375365-19-000039:notes:130]
Stock Option Activity

[0001375365-19-000039:notes:131]
The following table summarizes stock option activity during the fiscal years ended June 30, 2017, 2016 and 2015 under all plans:

[0001375365-19-000039:notes:132]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 (7,558,631 shares exercisable at weighted average exercise price of $11.05 per share) |  | 10,905,602 |  |  | $ | 12.24 |  |  |  |  |  |
| Granted (weighted average fair value of $12.72) |  | 1,093,920 |  |  | 28.28 |  |  |  |  |  |
| Exercised |  | (2,124,401 | ) |  | 10.99 |  |  |  |  |  |
| Forfeited |  | (172,278 | ) |  | 18.68 |  |  |  |  |  |
| Balance as of June 30, 2015 (7,208,475 shares exercisable at weighted average exercise price of $12.24 per share) |  | 9,702,843 |  |  | 14.21 |  |  |  |  |  |
| Granted (weighted average fair value of $12.07) |  | 316,580 |  |  | 26.86 |  |  |  |  |  |
| Exercised |  | (1,013,430 | ) |  | 12.03 |  |  |  |  |  |
| Forfeited |  | (45,126 | ) |  | 19.45 |  |  |  |  |  |
| Balance as of June 30, 2016 (7,495,131 shares exercisable at weighted average exercise price of $13.35 per share) |  | 8,960,867 |  |  | 14.88 |  |  |  |  |  |
| Granted (weighted average fair value of $10.71) |  | 473,000 |  |  | 24.27 |  |  |  |  |  |
| Exercised |  | (1,007,065 | ) |  | 10.80 |  |  |  |  |  |
| Forfeited |  | (51,143 | ) |  | 17.96 |  |  |  |  |  |
| Balance as of June 30, 2017 (7,348,320 shares exercisable at weighted average exercise price of $14.58 per share) |  | 8,375,659 |  |  | $ | 15.88 |  |  | 4.37 |  | $ | 78,501 |  |
| Options vested and expected to vest at June 30, 2017 |  | 8,298,251 |  |  | $ | 15.79 |  |  | 4.34 |  | $ | 78,434 |  |
| Options vested and exercisable at June 30, 2017 |  | 7,348,320 |  |  | $ | 14.58 |  |  | 3.99 |  | $ | 76,932 |  |

[0001375365-19-000039:notes:133]
The total pretax intrinsic value of options exercised during the fiscal years ended June 30, 2017, 2016 and 2015 was $14.0 million, $18.0 million and $48.1 million, respectively. Additional information regarding options outstanding as of June 30, 2017, is as follows:

[0001375365-19-000039:notes:134]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $4.63 - 8.36 |  | 1,109,538 |  |  | 1.65 |  | $ | 6.92 |  |  | 1,109,538 |  |  | $ | 6.92 |  |
| 8.47 - 10.66 |  | 1,435,967 |  |  | 2.98 |  | 10.18 |  |  | 1,435,967 |  |  | 10.18 |  |
| 10.68 - 12.68 |  | 837,728 |  |  | 3.95 |  | 11.80 |  |  | 837,728 |  |  | 11.80 |  |
| 12.92 - 14.23 |  | 1,089,103 |  |  | 4.26 |  | 13.75 |  |  | 1,058,336 |  |  | 13.74 |  |
| 15.22 - 17.29 |  | 883,555 |  |  | 4.24 |  | 16.34 |  |  | 883,555 |  |  | 16.34 |  |
| 17.69 - 18.93 |  | 1,055,904 |  |  | 5.15 |  | 18.55 |  |  | 947,204 |  |  | 18.55 |  |
| 20.54 - 25.44 |  | 1,065,708 |  |  | 6.51 |  | 23.48 |  |  | 587,336 |  |  | 23.29 |  |
| 26.60 - 35.07 |  | 827,496 |  |  | 7.20 |  | 29.16 |  |  | 441,261 |  |  | 29.30 |  |
| 37.06 |  | 35,160 |  |  | 5.62 |  | 37.06 |  |  | 19,770 |  |  | 37.06 |  |
| 39.19 |  | 35,500 |  |  | 7.62 |  | 39.19 |  |  | 27,625 |  |  | 39.19 |  |
| $4.63 - $39.19 |  | 8,375,659 |  |  | 4.37 |  | $ | 15.88 |  |  | 7,348,320 |  |  | $ | 14.58 |  |

[0001375365-19-000039:notes:135]
RSU Activity

[0001375365-19-000039:notes:136]
In January 2015, the Company began to grant RSUs to employees. The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting. The following table summarizes restricted stock unit activity during the fiscal years ended June 30, 2017 and 2016 under all plans:

[0001375365-19-000039:notes:137]
|  |  | RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 |  | — |  |  | $ | — |  |  |  |
| Granted |  | 374,720 |  |  | 35.82 |  |  |  |
| Released |  | (14,685 | ) |  | 35.23 |  |  |  |
| Forfeited |  | (56,711 | ) |  | 34.90 |  |  |  |
| Balance as of June 30, 2015 |  | 303,324 |  |  | 36.02 |  |  |  |
| Granted |  | 845,870 |  |  | 28.45 |  |  |  |
| Released |  | (177,707 | ) |  | 31.80 |  |  |  |
| Forfeited |  | (44,504 | ) |  | 29.72 |  |  |  |
| Balance as of June 30, 2016 |  | 926,983 |  |  | 30.23 |  |  |  |
| Granted |  | 808,020 |  |  | 23.73 |  |  |  |
| Released |  | (411,739 | ) |  | 27.41 |  |  |  |
| Forfeited |  | (96,907 | ) |  | 26.40 |  |  |  |
| Balance as of June 30, 2017 |  | 1,226,357 |  |  | $ | 26.11 |  |  | $ | 30,230 |  |

[0001375365-19-000039:notes:138]
The total pretax intrinsic value of RSUs vested was $11.3 million, $4.9 million and $0.5 million for the fiscal years ended June 30, 2017, 2016 and 2015, respectively. In fiscal years 2017, 2016 and 2015, upon vesting, 411,739, 177,707 and 14,685 shares of RSUs were partially net share-settled such that the Company withheld 144,994, 65,164 and 5,278 shares, respectively, with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $3.6 million, $1.8 million and $0.2 million for the fiscal years ended June 30, 2017, 2016 and 2015, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001375365-19-000039:notes:139]
Net Income Per Common Share

[0001375365-19-000039:notes:140]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested RSUs.

[0001375365-19-000039:notes:141]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001375365-19-000039:notes:142]
Investment in a Corporate Venture

[0001375365-19-000039:notes:143]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of June 30, 2017, the Company's equity investment in the Corporate Venture was $6.1 million and was recorded under investment in equity investee on the Company's consolidated balance sheet. The Company's share of losses of the Corporate Venture were immaterial for the fiscal year ended June 30, 2017 and were included in other income (expense), net in the Company's consolidated statements of operations. The Company recorded a deferred gain related to the contribution of certain technology rights of $7.0 million in the third fiscal quarter of 2017. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of June 30, 2017, the Company had unamortized deferred gain balance of $1.4 million in accrued liabilities and $4.9 million in other long-term liabilities in the Company’s consolidated balance sheets. The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if determined that an impairment charge is required. No impairment charge was recorded for the fiscal year ended June 30, 2017.

[0001375365-19-000039:notes:144]
Additionally, the Company sold products worth $10.9 million to the Corporate Venture in the fiscal year ended June 30, 2017 and the Company's share of intra-entity profits on the products which remained unsold by the Corporate Venture as of June 30, 2017 have been eliminated and reduced the Company's investment in the Corporate Venture. The Company had a $6.7 million accounts receivable due from the Corporate Venture as of June 30, 2017.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001375365-19-000039:notes:145]
The following table sets forth the Company’s cash equivalents, certificates of deposit, and long-term investments as of June 30, 2017 and 2016 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-19-000039:notes:146]
| June 30, 2017 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,126 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,126 |  |
| Certificates of deposit (2) | — |  |  | 1,151 |  |  | — |  |  | 1,151 |  |
| Auction rate securities | — |  |  | — |  |  | 2,625 |  |  | 2,625 |  |
| Total assets measured at fair value | $ | 1,126 |  |  | $ | 1,151 |  |  | $ | 2,625 |  |  | $ | 4,902 |  |
| June 30, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 727 |  |  | $ | — |  |  | $ | — |  |  | $ | 727 |  |
| Certificates of deposit (2) | — |  |  | 1,316 |  |  | — |  |  | 1,316 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total assets measured at fair value | $ | 727 |  |  | $ | 1,316 |  |  | $ | 2,643 |  |  | $ | 4,686 |  |

[0001375365-19-000039:notes:147]
(1) $0.3 million and $0.3 million in money market funds are included within cash and cash equivalents and $0.8 million and $0.4 million in money market funds are included in restricted cash within other assets on the consolidated balance sheets as of June 30, 2017 and 2016, respectively.

[0001375365-19-000039:notes:148]
(2) $0.2 million and $0.3 million in certificates of deposit are included in cash and cash equivalents and $1.0 million and $1.0 million in certificates of deposit are included in restricted cash within other assets on the consolidated balance sheets as of June 30, 2017 and 2016, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001375365-19-000039:notes:149]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for fiscal years 2017 and 2016 (in thousands):

[0001375365-19-000039:notes:150]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |
| Balance as of the beginning of the fiscal year | $ | 2,643 |  |  | $ | 2,633 |  |
| Total unrealized gains (losses) included in other comprehensive income | (18 | ) |  | 10 |  |
| Balance as of the end of the fiscal year | $ | 2,625 |  |  | $ | 2,643 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-19-000039:notes:151]
Fair Value Disclosure

[0001375365-19-000039:notes:152]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and long-term investments. The Company classifies its cash equivalents and other assets within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s long-term investments in auction rate securities are classified within Level 3 of the fair value hierarchy as the determination of their fair values was not based on observable inputs as of June 30, 2017 and 2016. See Note 1, "Organization and Summary of Significant Accounting Policies", for a discussion of the Company’s policies regarding the fair value hierarchy. The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of June 30, 2017 and 2016. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-19-000039:notes:153]
The above table excludes $110.1 million and $178.2 million of cash included in cash and cash equivalents on the consolidated balance sheets and $0.4 million and $0.5 million of restricted cash included in other assets on the consolidated balance sheets held by the Company as of June 30, 2017 and 2016, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in fiscal years 2017 and 2016.

[0001375365-19-000039:notes:154]
The following is a summary of the Company’s long-term investments as of June 30, 2017 and 2016 (in thousands):

[0001375365-19-000039:notes:155]
|  | June 30, 2017 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (125 | ) |  | $ | 2,625 |  |
|  | June 30, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |

[0001375365-19-000039:notes:156]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2017 and 2016, total debt of $161.4 million and $93.6 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.

[0001375365-19-000039:notes:157]
During fiscal year 2017 and 2016, the Company did not record any other-than-temporary impairments on financial assets required to be measured at fair value on a nonrecurring basis.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001375365-19-000039:notes:158]
Foreign Currency Transactions

[0001375365-19-000039:notes:159]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, with the exception of Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in the local currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the local currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the local currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations in other income (expense), net.

[0001375365-19-000039:notes:160]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD$”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive loss in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001375365-19-000039:notes:161]
Long-Lived Assets

[0001375365-19-000039:notes:162]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-19-000039:notes:163]
Income Taxes

[0001375365-19-000039:notes:164]
The components of income before income tax provision for the fiscal years ended June 30, 2017, 2016 and 2015 are as follows (in thousands):

[0001375365-19-000039:notes:165]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| United States | $ | 82,078 |  |  | $ | 97,921 |  |  | $ | 108,437 |  |
| Foreign | 9,210 |  |  | 9,483 |  |  | 24,200 |  |
| Income before income tax provision | $ | 91,288 |  |  | $ | 107,404 |  |  | $ | 132,637 |  |

[0001375365-19-000039:notes:166]
The income tax provision for the fiscal years ended June 30, 2017, 2016 and 2015, consists of the following (in thousands):

[0001375365-19-000039:notes:167]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Current: |  |  |  |  |  |
| Federal | $ | 26,033 |  |  | $ | 29,647 |  |  | $ | 33,765 |  |
| State | 695 |  |  | 638 |  |  | (633 | ) |
| Foreign | 4,001 |  |  | 10,741 |  |  | 10,953 |  |
|  | 30,729 |  |  | 41,026 |  |  | 44,085 |  |
| Deferred: |  |  |  |  |  |
| Federal | (6,782 | ) |  | (5,976 | ) |  | (5,492 | ) |
| State | 353 |  |  | 12 |  |  | 2,406 |  |
| Foreign | 134 |  |  | 261 |  |  | (917 | ) |
|  | (6,295 | ) |  | (5,703 | ) |  | (4,003 | ) |
| Income tax provision | $ | 24,434 |  |  | $ | 35,323 |  |  | $ | 40,082 |  |

[0001375365-19-000039:notes:168]
The Company’s net deferred tax assets as of June 30, 2017 and 2016 consist of the following (in thousands):

[0001375365-19-000039:notes:169]
|  | June 30, |
|  | 2017 |  | 2016 |
| Inventory valuation | $ | 15,240 |  |  | $ | 12,329 |  |
| Stock-based compensation | 6,277 |  |  | 5,610 |  |
| Deferred revenue | 6,241 |  |  | 6,802 |  |
| Payables to foreign subsidiaries | 3,912 |  |  | 1,824 |  |
| R&D credit | 3,167 |  |  | 10 |  |
| Accrued vacation and bonus | 2,635 |  |  | 2,616 |  |
| Warranty accrual | 1,952 |  |  | 2,213 |  |
| Foreign exchange unrealized gains and losses | 1,884 |  |  | 710 |  |
| Marketing fund accrual | 1,605 |  |  | 1,791 |  |
| Other | 2,836 |  |  | 2,821 |  |
| Total deferred income tax assets | 45,749 |  |  | 36,726 |  |
| Deferred tax liabilities-depreciation and other | (3,617 | ) |  | (3,048 | ) |
| Valuation allowance | (3,013 | ) |  | — |  |
| Deferred income tax assets, net | $ | 39,119 |  |  | $ | 33,678 |  |

[0001375365-19-000039:notes:170]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2017, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of California R&D tax credits that have not met the “more-likely than not” realization threshold criteria. Starting from fiscal year 2016 California tax return which was filed in the fourth quarter of fiscal year 2017, on an annual basis and pursuant to current law, the Company generates more California credits than California tax. As a result, at June 30, 2017, the gross excess credits of $4.6 million, or net of federal tax benefit of $3.0 million, are subject to a full valuation allowance. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2017 and 2016 was $39.1 million and $33.7 million, respectively.

[0001375365-19-000039:notes:171]
The cumulative undistributed earnings of the Company's foreign subsidiaries of $40.6 million at June 30, 2017 are considered to be indefinitely reinvested and accordingly, no provisions for federal and state income taxes have been provided thereon. The Company determined that the calculation of the amount of unrecognized deferred tax liability related to these cumulative unremitted earnings was not practicable. Upon distribution of those earnings in the form of dividends or otherwise, the Company would be subject to both United States income taxes (subject to an adjustment for foreign tax credits) and withholding taxes payable to various foreign countries.

[0001375365-19-000039:notes:172]
Subsequent to June 30, 2017, but before the issuance of the consolidated financial statements, the 2017 Tax Act was enacted on December 22, 2017. Some of the significant new requirements of the 2017 Tax Act include, but are not limited to, a one-time mandatory deemed repatriation transition tax on previously deferred foreign earnings which the Company estimates would not have a material impact to the consolidated financial statements in the year of enactment, a re-measurement of our deferred taxes due to the change in the corporate tax rate which the Company is estimating could have a $11.0 million to $15.0 million impact to the consolidated financial statements in the year of enactment, taxation of certain global intangible low-taxed income under the international tax provisions which the Company estimates would not have a material impact to the consolidated financial statements in the year of enactment, and limitations on the deductibility of performance-based compensation for officers which the Company estimates would not have a material impact to the consolidated financial statements in the year of enactment. The tax impacts of the 2017 Tax Act have not been included in the income tax provision for fiscal years ended June 30, 2017, 2016 and 2015. The Company will account for the tax effects of the 2017 Tax Act in the period it was enacted, which is in the fiscal year ended June 30, 2018.

[0001375365-19-000039:notes:173]
Prior to the enactment of the 2017 Tax Act, the Company considered earnings from foreign operations to be indefinitely reinvested outside of the United States. The Company is currently evaluating whether to change its indefinite reinvestment assertion in light of the 2017 Tax Act and the Company considers that assessment to be incomplete as the financial statements for fiscal year 2018 have not been finalized.

[0001375365-19-000039:notes:174]
The following is a reconciliation for the fiscal years ended June 30, 2017, 2016 and 2015, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-19-000039:notes:175]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Tax at statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income tax, net of federal tax benefit |  | 4.6 |  |  | 3.2 |  |  | 3.3 |  |
| Stock-based compensation |  | 2.5 |  |  | 2.3 |  |  | 2.6 |  |
| Settlement with tax authority |  | 2.0 |  |  | — |  |  | — |  |
| Foreign withholding tax |  | 1.1 |  |  | 3.2 |  |  | 3.3 |  |
| Foreign tax rate differences |  | 0.8 |  |  | 1.2 |  |  | (2.7 | ) |
| Subpart F income inclusion |  | — |  |  | (2.9 | ) |  | (3.2 | ) |
| Qualified production activity deduction |  | (3.0 | ) |  | (2.8 | ) |  | (1.4 | ) |
| Uncertain tax positions |  | (7.6 | ) |  | (1.6 | ) |  | (0.8 | ) |
| Research and development tax credit |  | (9.4 | ) |  | (7.0 | ) |  | (3.8 | ) |
| Other |  | 0.8 |  |  | 2.3 |  |  | (2.1 | ) |
| Effective tax rate |  | 26.8 | % |  | 32.9 | % |  | 30.2 | % |

[0001375365-19-000039:notes:176]
As of June 30, 2017, the Company had state research and development tax credit carryforwards of $16.6 million. The state research and development tax credits will carryforward indefinitely to offset future state income taxes. $6.7 million of the state research and development tax credit carryforwards were attributable to excess tax deductions from stock option exercises, and were not included in the deferred tax assets shown above. The benefit of these carryforwards will be credited to equity when realized.

[0001375365-19-000039:notes:177]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-19-000039:notes:178]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2014 | $ | 9,615 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,855 |  |
| For prior years’ tax positions | 793 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (971 | ) |
| Balance at June 30, 2015 | 13,292 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,167 |  |
| For prior years’ tax positions | 2,074 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (2,138 | ) |
| Balance at June 30, 2016 | 19,395 |  |
| Gross increases: |  |
| For current year’s tax positions | 5,732 |  |
| For prior years’ tax positions | 1,119 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (7,029 | ) |
| Balance at June 30, 2017 | $ | 19,217 |  |

[0001375365-19-000039:notes:179]
________________________

[0001375365-19-000039:notes:180]
*excludes interest, penalties, federal benefit of state reserves

[0001375365-19-000039:notes:181]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $15.6 million and $16.7 million as of June 30, 2017 and 2016, respectively.

[0001375365-19-000039:notes:182]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes in the consolidated statements of operations. As of June 30, 2017 and 2016, the Company had accrued $1.0 million and $1.0 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively. During fiscal years 2017, 2016 and 2015, there was no material change in the total amount of the liability for accrued interest and penalties related to the unrecognized tax benefits.

[0001375365-19-000039:notes:183]
The Company is subject to United States federal income tax as well as income taxes in many state and foreign jurisdictions. In the fourth quarter of fiscal year 2017, the U.S. Internal Revenue Service (“IRS”) completed its examination procedures including all appeals and administrative review for tax years ended June 30, 2013 and 2014 U.S. federal income tax returns. The IRS proposed an adjustment on the Company’s research and development credit claimed which resulted in additional tax liability of $1.9 million. The Company accepted and paid for the amount in June 2017. The impact of this one-time adjustment on the income statement was mostly offset by the recognition of other previously unrecognized tax benefits related to the years audited.

[0001375365-19-000039:notes:184]
In December 2018, the tax authorities completed their audit in Taiwan for fiscal year 2017, which was related to local income taxes in response to the Taiwan tax authority’s proposed adjustment on the Company’s transfer pricing that resulted in additional tax liability of $1.5 million. The Company accepted and paid the $1.5 million in January 2019. The impact of this one-time adjustment on the income statement was predominantly offset by the recognition of previously unrecognized tax benefits related to the years audited.

[0001375365-19-000039:notes:185]
The Company believes that it has adequately provided reserves for all uncertain tax positions, however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001375365-19-000039:notes:186]
The federal statute of limitations remains open in general for tax years ended June 30, 2016 through 2018. The state statute of limitations remains open in general for tax years ended June 30, 2015 through 2018. The statutes of limitations in major foreign jurisdictions remain open for examination in general for tax years ended June 30, 2013 through 2018. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:IncomeTaxPolicyTextBlock

[0001375365-19-000039:notes:187]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-19-000039:notes:188]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such determination.


## us-gaap:InventoryDisclosureTextBlock

[0001375365-19-000039:notes:189]
Inventories

[0001375365-19-000039:notes:190]
Inventories as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:191]
|  | June 30, |
|  | 2017 |  | 2016 |
| Finished goods | $ | 577,345 |  |  | $ | 399,776 |  |
| Purchased parts and raw materials | 124,981 |  |  | 95,344 |  |
| Work in process | 34,342 |  |  | 21,687 |  |
| Total inventories | $ | 736,668 |  |  | $ | 516,807 |  |

[0001375365-19-000039:notes:192]
During fiscal years 2017, 2016 and 2015, the Company recorded a provision for excess and obsolete inventory to cost of sales totaling $15.7 million, $9.4 million and $5.9 million, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001375365-19-000039:notes:193]
Inventories are stated at weighted average cost, subject to lower of cost or market. Inventories consist of purchased parts and raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value for purchased parts and raw materials. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units based upon usage and sales, anticipated sales price, product obsolescence and other factors. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped.

[0001375365-19-000039:notes:194]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates are recognized as a reduction of cost of inventories and reduces the cost of sales in the period when the related inventory is sold.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001375365-19-000039:notes:195]
Leases

[0001375365-19-000039:notes:196]
Leases are evaluated and recorded as capital leases if one of the following is true at inception: (a) the present value of minimum lease payments meets or exceeds 90% of the fair value of the asset, (b) the lease term is greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contains a bargain purchase option, or (d) title to the property transfers to the Company at the end of the lease. The Company records an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets are depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability are accounted for using the effective interest method.

[0001375365-19-000039:notes:197]
Leases that are not classified as capital leases are accounted for as operating leases. Operating lease agreements that have tenant improvement allowances are evaluated for lease incentives. For leases that contain escalating rent payments, the Company recognizes rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-19-000039:notes:198]
Accounts Receivable Allowances

[0001375365-19-000039:notes:199]
The Company has established an allowance for doubtful accounts and an allowance for sales returns. The allowance for doubtful accounts is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. The Company also provides its customers with product return rights. A provision for such returns is provided for in the same period that the related sales are recorded based upon contractual return rights and historical trends. Accounts receivable allowances as of June 30, 2017, 2016 and 2015 consisted of the following (in thousands):


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001375365-19-000039:notes:200]
Recent Accounting Pronouncements

[0001375365-19-000039:notes:201]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. The new guidance provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to the new revenue standard.

[0001375365-19-000039:notes:202]
The new standard is effective for the Company from July 1, 2018. The Company intends to adopt the new standard using the modified retrospective method. The Company has completed its preliminary accounting assessment of the adoption of the new standard. The Company is in the process of finalizing the accounting assessment, establishing new accounting policies, implementing systems and processes and internal controls necessary to support the requirements of the new standard. The Company will continue to update its assessment as more information becomes available. The Company cannot reasonably estimate quantitative information related to the impact of the new guidance on its consolidated financial statements at this time but expects the implementation of the new guidance to impact the recognition of its revenue as follows:

[0001375365-19-000039:notes:203]
| • | Substantially all of the Company's current revenue is from the sale of hardware products. The Company does not expect any material changes to the timing or amount of revenue for these types of sales under the new guidance, except for sales to distributors where the Company currently accounts for such sales on a sell-through basis, in which case the new guidance is expected to accelerate recognition of revenue. |

[0001375365-19-000039:notes:204]
| • | For extended warranty and on-site services and software, the Company is assessing the impact and timing to revenue from the implementation of the new guidance. However, the Company does not currently expect the new guidance to have a material impact on its revenue for these types of arrangements. |

[0001375365-19-000039:notes:205]
| • | For costs incurred to fulfill or obtain a customer contract, the Company is assessing the impact from the implementation of the new guidance. However, the Company does not currently expect the new guidance to have a material impact related to these costs. |

[0001375365-19-000039:notes:206]
| • | The Company's revenue disclosures are expected to expand. |

[0001375365-19-000039:notes:207]
In April 2015, the FASB issued an amendment to the accounting guidance, Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance, Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements. This amendment clarifies that an entity may defer, and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These amendments should be applied retrospectively to all prior periods presented in the consolidated financial statements. The Company adopted these amendments in the first quarter of fiscal year 2017. There was no material impact on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:208]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company from July 1, 2018. The Company does not expect this guidance to have a material impact on the consolidated financial statements and related disclosures.

[0001375365-19-000039:notes:209]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. Since its issuance, the FASB has issued several amendments to the new lease standard. The standard is effective for the Company from July 1, 2019 and the Company will apply this standard using the modified retrospective approach. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:210]
In March 2016, the FASB issued new accounting guidance, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. Early adoption is permitted for any interim or annual periods. This guidance is effective for the Company from July 1, 2017. The adoption of this guidance will result in the recognition of excess tax benefits in the Company's provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of its change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. The new guidance also requires the Company to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:211]
In March 2016, the FASB issued new accounting guidance Investments - Equity Method and Joint Ventures: Simplifying the Transition to Equity Method of Accounting. The amendments in this update eliminate the requirement that an entity retroactively adopt the equity method of accounting if an investment qualifies for use of the equity method as a result of increase in ownership interest or degree of influence. In accordance with the amendments, an equity method investor will begin to apply the equity method when the investor obtains significant influence without having to retroactively adjust the investment and record a cumulative catch up for the years when the investment did not qualify for the equity method of accounting. The guidance is effective for the Company from July 1, 2017. The Company does not expect this guidance to have a material impact on the consolidated financial statements and related disclosures.

[0001375365-19-000039:notes:212]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:213]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. This amendment is effective for the Company from July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated statement of cash flows.

[0001375365-19-000039:notes:214]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. This amendment is effective for the Company from July 1, 2018. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:215]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This amendment is effective for the Company from July 1, 2018. Early adoption is permitted. The Company does not expect this amendment to have a material impact, though it will change the presentation of the consolidated statement of cash flows.

[0001375365-19-000039:notes:216]
In February 2017, the FASB issued new accounting guidance, Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets: Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets. This guidance clarifies the scope and application on the sale or transfer of nonfinancial assets and in substance nonfinancial assets to noncustomers, including partial sales. The amendments are effective at the same time as the new revenue standard. This amendment is effective for the Company from July 1, 2018. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosure, results of operations and financial position.

[0001375365-19-000039:notes:217]
In February 2018, the FASB issued amended guidance to allow a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Act"). Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Tax Act and will improve the usefulness of information reported to financial statement users. However, because the amendments only relate to the reclassification of the income tax effects of the 2017 Tax Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. The amendments also require certain disclosures about stranded tax effects. The new standard is effective for the Company from July 1, 2019. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:218]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The new amendment is effective for the Company from July 1, 2019. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000039:notes:219]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the Concepts Statement, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

[0001375365-19-000039:notes:220]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018. The SEC staff subsequently indicated that it would not object if a filer’s first presentation of changes in shareholders’ equity is included in its Form 10-Q for the quarter that begins after the final rule’s effective date. Among the amendments is the requirement to present the changes in shareholders’ equity in the interim financial statements (either in a separate statement or footnote) in Quarterly Reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The Company will include the first presentation of changes in consolidated statement of stockholders’ equity on Form 10-Q in its first quarter of fiscal 2019.

[0001375365-19-000039:notes:221]
In August 2018, the FASB issued amended guidance to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-19-000039:notes:222]
Organization and Summary of Significant Accounting Policies

[0001375365-19-000039:notes:223]
Organization

[0001375365-19-000039:notes:224]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

[0001375365-19-000039:notes:225]
Use of Estimates

[0001375365-19-000039:notes:226]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates.

[0001375365-19-000039:notes:227]
Fair Value of Financial Instruments

[0001375365-19-000039:notes:228]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-19-000039:notes:229]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001375365-19-000039:notes:230]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001375365-19-000039:notes:231]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001375365-19-000039:notes:232]
Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposits and long-term investments are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms.

[0001375365-19-000039:notes:233]
Long-term Investments

[0001375365-19-000039:notes:234]
The Company classifies its long-term investments in auction rate securities ("auction rate securities") as non-current available-for-sale investments. Auction rate securities consist of municipal securities. The discounted cash flow model is used to estimate the fair value of the auction rate securities. These investments are recorded in the consolidated balance sheets at fair value. Unrealized gains and losses on these investments are included as a component of accumulated other comprehensive loss, net of tax.

[0001375365-19-000039:notes:235]
Property, Plant and Equipment

[0001375365-19-000039:notes:236]
For assets acquired and financed under capital leases, the present value of the future minimum lease payments is recorded at the date of acquisition as property, plant and equipment with the corresponding amount recorded as a capital lease obligation, and the amortization is computed on a straight-line basis over the shorter of the lease term or estimated useful life.

[0001375365-19-000039:notes:237]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge has been recorded in any of the periods presented.

[0001375365-19-000039:notes:238]
Investments in Equity Securities

[0001375365-19-000039:notes:239]
The Company has an investment in a privately-held company, which is discussed in Note 7, "Investment in a Corporate Venture." Investments in equity securities that do not have a readily determinable fair value are accounted for under the cost method when the Company does not have significant influence over the investee. Adjustments are made to the cost of the investments when performance indicators suggest that the investment is impaired. Dividends received are recorded to other income (expense), net. Investments in equity securities are accounted for using the equity method when the Company has significant influence over the investee. Adjustments are made to the investment for any earnings or losses incurred and are recorded in other income (expense), net. Dividends are considered a return of capital that reduces the cost of the investment.

[0001375365-19-000039:notes:240]
Revenue Recognition

[0001375365-19-000039:notes:241]
Product sales. The Company recognizes revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of its products to customers, unless customer acceptance is uncertain or significant obligations to the customer remain: (i) persuasive evidence of an arrangement exists through customer contracts and orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

[0001375365-19-000039:notes:242]
The Company estimates and reserves for future sales returns based on a review of its history of actual returns for each major product line. The Company also reduces revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

[0001375365-19-000039:notes:243]
The Company may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement between the Company and distributor.

[0001375365-19-000039:notes:244]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000039:notes:245]
Multiple-element arrangements. Certain of the Company’s arrangements contain multiple elements, consisting of both the Company’s products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

[0001375365-19-000039:notes:246]
The Company allocates arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available.

[0001375365-19-000039:notes:247]
The Company does not have VSOE for deliverables in its arrangements, and TPE is generally not available because its products are highly differentiated, and the Company is unable to obtain reliable information on the products and pricing practices of the Company’s competitors. BESP reflects the Company’s estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

[0001375365-19-000039:notes:248]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. The Company determines BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.

[0001375365-19-000039:notes:249]
Allowances for Doubtful Accounts

[0001375365-19-000039:notes:250]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer concentrations, customer-credit-worthiness, and current economic trends to evaluate the adequacy of the allowance for doubtful accounts. The Company's provision for bad debt was $0.3 million, $1.2 million and $0.1 million in fiscal years 2017, 2016 and 2015, respectively.

[0001375365-19-000039:notes:251]
Product Warranties

[0001375365-19-000039:notes:252]
The Company offers product warranties ranging from 15 to 39 months against any defective products. The Company accrues for estimated returns of defective products at the time revenue is recognized based on historical warranty experience and recent trends. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. The Company adjusts its changes in estimates on an ongoing basis as a result of new product introductions or changes in unit volumes compared with its historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, and the Company accounts for the changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2017, 2016 and 2015, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-19-000039:notes:253]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Balance, beginning of year | $ | 7,129 |  |  | $ | 7,700 |  |  | $ | 7,083 |  |
| Provision for warranty | 21,642 |  |  | 19,579 |  |  | 15,975 |  |
| Costs utilized | (21,256 | ) |  | (18,041 | ) |  | (15,154 | ) |
| Change in estimated liability for pre-existing warranties | 206 |  |  | (2,109 | ) |  | (204 | ) |
| Balance, end of year | $ | 7,721 |  |  | $ | 7,129 |  |  | $ | 7,700 |  |
| Current portion | 5,976 |  |  | 5,816 |  |  | 6,015 |  |
| Long-term portion | $ | 1,745 |  |  | $ | 1,313 |  |  | $ | 1,685 |  |

[0001375365-19-000039:notes:254]
Research and Development

[0001375365-19-000039:notes:255]
Research and development costs are expensed as incurred and consist primarily of salaries, consulting services, other direct expenses and other engineering expenses. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $10.3 million, $6.9 million and $6.3 million for the fiscal years ended June 30, 2017, 2016 and 2015, respectively.

[0001375365-19-000039:notes:256]
Cooperative Marketing Arrangements

[0001375365-19-000039:notes:257]
The Company has arrangements with resellers of its products to reimburse the resellers for cooperative marketing costs meeting specified criteria. The Company accrues the cooperative marketing costs based on these arrangements and its estimate for resellers’ claims for marketing activities. These costs are recorded as a reduction of revenue in the consolidated statements of operations, as the fair value of the benefit identified from these costs cannot be reasonably estimated. Total cooperative marketing costs recorded as reductions to revenue for the fiscal years ended June 30, 2017, 2016 and 2015, were $8.1 million, $7.7 million and $7.7 million, respectively.

[0001375365-19-000039:notes:258]
Advertising costs are expensed as incurred. Total advertising and promotional expenses were $5.4 million, $4.1 million and $3.0 million for the fiscal years ended June 30, 2017, 2016 and 2015, respectively.

[0001375365-19-000039:notes:259]
Stock-Based Compensation

[0001375365-19-000039:notes:260]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors, including stock options and restricted stock units ("RSUs"). The Company is required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of RSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimated the fair value of stock options granted using a Black-Scholes option pricing model and a single option award approach. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000039:notes:261]
The expected term represents the period that the Company's stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and historical experience. The expected volatility is based on a combination of the Company's implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option and RSU forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001375365-19-000039:notes:262]
Shipping and Handling Fees

[0001375365-19-000039:notes:263]
The Company records costs related to shipping and handling in sales and marketing expenses. Shipping and handling fees billed to customers are included in net sales.

[0001375365-19-000039:notes:264]
Variable Interest Entities

[0001375365-19-000039:notes:265]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests in is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE; and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment under the equity method or cost method in accordance with the applicable GAAP.

[0001375365-19-000039:notes:266]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company’s management considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, management considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. Management determined that no implicit arrangements exist with Ablecom, Compuware or their shareholders.

[0001375365-19-000039:notes:267]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and although the operations of the Management Company are independent of the Company, through governance rights, the Company has the power to direct the activities that are most significant to the Management Company. Therefore, the Company concluded that it is the primary beneficiary of the Management Company. For the fiscal years ended 2017, 2016 and 2015, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In fiscal years 2017, 2016 and 2015, $(14,000), $20,000 and $(11,000) of net income (loss) attributable to Ablecom's interest was included in the Company’s general and administrative expenses in the consolidated statements of operations, respectively.

[0001375365-19-000039:notes:268]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-19-000039:notes:269]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 66,854 |  |  | $ | 72,081 |  |  | $ | 92,555 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 48,383 |  |  | 47,917 |  |  | 46,434 |  |
| Effect of dilutive securities | 3,296 |  |  | 3,919 |  |  | 3,660 |  |
| Weighted-average diluted shares | 51,679 |  |  | 51,836 |  |  | 50,094 |  |
| Basic net income per common share | $ | 1.38 |  |  | $ | 1.50 |  |  | $ | 1.99 |  |
| Diluted net income per common share | $ | 1.29 |  |  | $ | 1.39 |  |  | $ | 1.85 |  |

[0001375365-19-000039:notes:270]
For the fiscal years ended June 30, 2017, 2016 and 2015, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,620,000, 1,196,000 and 3,805,000 for the fiscal years ended June 30, 2017, 2016 and 2015, respectively.

[0001375365-19-000039:notes:271]
Concentration of Supplier Risk

[0001375365-19-000039:notes:272]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 31.0%, 35.2%, and 28.7% of total purchases for the fiscal years ended June 30, 2017, 2016 and 2015, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 11, "Related Party Transactions", accounted for 11.1%, 12.8% and 13.8% of total cost of sales for the fiscal years ended June 30, 2017, 2016 and 2015, respectively.

[0001375365-19-000039:notes:273]
Concentration of Credit Risk

[0001375365-19-000039:notes:274]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, long-term investments and accounts receivable. No single customer accounted for 10% or more of net sales in fiscal year 2017. In fiscal years 2016 and 2015, one customer accounted for 11.4% and 10.4%, respectively, of net sales. No customer accounted for 10% or more of accounts receivable as of June 30, 2017, and one customer accounted for 10.5% of the Company's accounts receivables as of June 30, 2016.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001375365-19-000039:notes:275]
Prepaid Expenses and Other Assets

[0001375365-19-000039:notes:276]
Other long-term assets as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:277]
|  | June 30, |
|  | 2017 |  | 2016 |
| Long-term deferred service costs | $ | 3,253 |  |  | $ | 3,497 |  |
| Prepaid software license | 2,593 |  |  | 3,870 |  |
| Restricted cash (1) | 2,191 |  |  | 1,851 |  |
| Cost method investments | 1,529 |  |  | 1,881 |  |
| Prepaid royalty license | 499 |  |  | 748 |  |
| Deposits | 368 |  |  | 909 |  |
| Others | 144 |  |  | 129 |  |
| Total other assets | $ | 10,577 |  |  | $ | 12,885 |  |

[0001375365-19-000039:notes:278]
(1) As of June 30, 2017 and 2016, restricted cash consisted primarily of certificates of deposits pledged as security for one irrevocable letter of credit related to a warehouse lease, three deposits to an escrow account required by the Company's worker's compensation program, one deposit required for the Company's bonded warehouse in Taiwan, deposits to bank guarantees for import duty required by the customs authority in Taiwan and bank guarantees in connection with office leases in the Netherlands.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001375365-19-000039:notes:279]
Other Long-term Liabilities

[0001375365-19-000039:notes:280]
Other long-term liabilities as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:281]
|  | June 30, |
|  | 2017 |  | 2016 |
| Deferred revenue, non-current (1) | $ | 47,548 |  |  | $ | 26,538 |  |
| Accrued unrecognized tax benefits including related interest and penalties, non-current | 13,285 |  |  | 16,056 |  |
| Accrued warranty, non-current | 1,745 |  |  | 1,313 |  |
| Others (2) | 6,176 |  |  | 1,293 |  |
| Total other long-term liabilities | $ | 68,754 |  |  | $ | 45,200 |  |

[0001375365-19-000039:notes:282]
(1) Deferred revenue, non-current as of June 30, 2017 and 2016 was comprised of deferred extended warranty revenue of $22.3 million and $16.7 million, respectively, deferred on-site service revenue of $23.4 million and $8.6 million, respectively, and other deferred revenue of $1.8 million and $1.2 million, respectively.

[0001375365-19-000039:notes:283]
(2) Included in others as of June 30, 2017 is $4.9 million of deferred gain related to investment in Corporate Venture.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-19-000039:notes:284]
Retirement Plans

[0001375365-19-000039:notes:285]
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2017, 2016 and 2015.

[0001375365-19-000039:notes:286]
Beginning in March 2003, employees of Super Micro Computer, B.V. have the option to deduct a portion of their gross wages and invest the amount in a defined contribution plan. The Company has agreed to match 10% of the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the fiscal years ended June 30, 2017, 2016 and 2015, the Company’s matching contribution was $0.4 million, $0.3 million and $0.2 million, respectively.

[0001375365-19-000039:notes:287]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2017, 2016 and 2015, the Company’s contribution was $1.9 million, $1.0 million and $0.9 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-19-000039:notes:288]
Property, Plant, and Equipment

[0001375365-19-000039:notes:289]
Property, plant and equipment as of June 30, 2017 and 2016 consisted of the following (in thousands):

[0001375365-19-000039:notes:290]
|  | June 30, |
|  | 2017 |  | 2016 |
| Buildings | $ | 71,665 |  |  | $ | 71,665 |  |
| Land | 70,495 |  |  | 70,454 |  |
| Machinery and equipment | 60,593 |  |  | 53,282 |  |
| Buildings construction in progress (1) | 24,039 |  |  | 15,803 |  |
| Buildings and leasehold improvements | 14,942 |  |  | 10,941 |  |
| Purchased software | 14,576 |  |  | 14,452 |  |
| Furniture and fixtures | 13,353 |  |  | 10,364 |  |
|  | 269,663 |  |  | 246,961 |  |
| Accumulated depreciation and amortization | (74,087 | ) |  | (59,012 | ) |
| Property, plant and equipment, net | $ | 195,576 |  |  | $ | 187,949 |  |

[0001375365-19-000039:notes:291]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001375365-19-000039:notes:292]
Quarterly Financial Information (Unaudited)

[0001375365-19-000039:notes:293]
The following table presents the Company’s unaudited consolidated quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company’s quarterly results of operations for these periods are not necessarily indicative of future results of operations.

[0001375365-19-000039:notes:294]
|  | Three Months Ended |
|  | Sep. 30, 2015 |  | Dec. 31, 2015 |  | Mar. 31, 2016 |  | Jun. 30, 2016 (1) |  | Sep. 30, 2016 |  | Dec. 31, 2016 |  | Mar. 31, 2017 |  | Jun. 30, 2017 |
|  | (As Restated) |  |  |
|  | (In thousands, except per share data) |
| Net sales | $ | 539,104 |  |  | $ | 641,235 |  |  | $ | 513,468 |  |  | $ | 531,215 |  |  | $ | 528,763 |  |  | $ | 663,200 |  |  | $ | 614,798 |  |  | $ | 678,168 |  |
| Gross profit | $ | 77,475 |  |  | $ | 103,187 |  |  | $ | 78,983 |  |  | $ | 70,856 |  |  | $ | 82,552 |  |  | $ | 96,136 |  |  | $ | 85,337 |  |  | $ | 85,933 |  |
| Net income | $ | 17,351 |  |  | $ | 33,204 |  |  | $ | 16,046 |  |  | $ | 5,480 |  |  | $ | 15,373 |  |  | $ | 22,876 |  |  | $ | 15,350 |  |  | $ | 13,255 |  |
| Net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.70 |  |  | $ | 0.33 |  |  | $ | 0.10 |  |  | $ | 0.32 |  |  | $ | 0.48 |  |  | $ | 0.32 |  |  | $ | 0.26 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.64 |  |  | $ | 0.31 |  |  | $ | 0.10 |  |  | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 0.30 |  |  | $ | 0.25 |  |

[0001375365-19-000039:notes:295]
(1)  The error corrections made in the three months ended June 30, 2016 are similar in nature to those discussed in Note 19, "Restatement of Previously Issued Consolidated Financial Statements." The correction of the errors resulted in net sales being increased by $6.9 million, gross profit reduced by $2.9 million and net income reduced by $1.5 million, respectively, for the three months ended June 30, 2016, from amounts previously reported.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-19-000039:notes:296]
Related Party Transactions

[0001375365-19-000039:notes:297]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of June 30, 2017, Ablecom owned approximately 0.4% of the Company’s common stock. As of June 30, 2017, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, together owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of June 30, 2017. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and other Liang family members, including other brothers of Charles Liang, own approximately 36.0% of Ablecom’s stock. Bill Liang, a brother of both Charles Liang and Steve Liang, also is a member of the Board of Directors of Ablecom.

[0001375365-19-000039:notes:298]
Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-19-000039:notes:299]
Dealings with Ablecom

[0001375365-19-000039:notes:300]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-19-000039:notes:301]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its manufacturing of components, particularly server chassis. Ablecom manufactured approximately 95% and 96% of the chassis included in the products sold by the Company during fiscal years 2017 and 2016, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-19-000039:notes:302]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from outside markets and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-19-000039:notes:303]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $23.5 million and $22.8 million at June 30, 2017 and 2016, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-19-000039:notes:304]
Dealings with Compuware

[0001375365-19-000039:notes:305]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-19-000039:notes:306]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-19-000039:notes:307]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its manufacturing of components, particularly power supplies. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-19-000039:notes:308]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-19-000039:notes:309]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $56.4 million and $40.0 million at June 30, 2017 and 2016, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-19-000039:notes:310]
The Company’s results from transactions with Ablecom and Compuware for each of the fiscal years ended June 30, 2017, 2016, and 2015 are as follows (in thousands):

[0001375365-19-000039:notes:311]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Ablecom |  |  |  |  |  |
| Net sales | $ | 7 |  |  | $ | 57 |  |  | $ | 60 |  |
| Purchases (1) | 123,734 |  |  | 125,537 |  |  | 127,967 |  |
| Compuware |  |  |  |  |  |
| Net sales | 22,959 |  |  | 29,053 |  |  | 47,624 |  |
| Purchases (1) | 118,912 |  |  | 126,051 |  |  | 105,362 |  |

[0001375365-19-000039:notes:312]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-19-000039:notes:313]
The Company had the following balances related to transactions with Ablecom and Compuware as of June 30, 2017 and 2016 (in thousands):

[0001375365-19-000039:notes:314]
|  | June 30, |
|  | 2017 |  | 2016 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,556 |  |  | $ | 6,017 |  |
| Accounts payable and accrued liabilities | 30,762 |  |  | 29,788 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | 7,908 |  |  | 3,654 |  |
| Accounts payable and accrued liabilities | 32,216 |  |  | 20,507 |  |

[0001375365-19-000039:notes:315]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 7, "Investment in a Corporate Venture" for a discussion of the investment and the transactions that took place during the fiscal year 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001375365-19-000039:notes:316]
The following is a summary of net sales by product type (in thousands):

[0001375365-19-000039:notes:317]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 1,740,633 |  |  | 70.0 | % |  | $ | 1,533,382 |  |  | 68.9 | % |  | $ | 1,186,258 |  |  | 60.7 | % |
| Subsystems and accessories | 744,296 |  |  | 30.0 | % |  | 691,640 |  |  | 31.1 | % |  | 768,095 |  |  | 39.3 | % |
| Total | $ | 2,484,929 |  |  | 100.0 | % |  | $ | 2,225,022 |  |  | 100.0 | % |  | $ | 1,954,353 |  |  | 100.0 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001375365-19-000039:notes:318]
The following is a summary for the fiscal years ended June 30, 2017, 2016 and 2015, of net sales by geographic region (in thousands):

[0001375365-19-000039:notes:319]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| United States | $ | 1,422,667 |  |  | $ | 1,409,601 |  |  | $ | 1,148,135 |  |
| Asia | 500,956 |  |  | 319,581 |  |  | 313,550 |  |
| Europe | 453,798 |  |  | 387,711 |  |  | 367,538 |  |
| Other | 107,508 |  |  | 108,129 |  |  | 125,130 |  |
|  | $ | 2,484,929 |  |  | $ | 2,225,022 |  |  | $ | 1,954,353 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001375365-19-000039:notes:320]
The following is a summary of property, plant and equipment (in thousands):

[0001375365-19-000039:notes:321]
|  | June 30, |
|  | 2017 |  | 2016 |
| United States | $ | 152,310 |  |  | $ | 142,764 |  |
| Asia | 40,854 |  |  | 42,052 |  |
| Europe | 2,412 |  |  | 3,133 |  |
|  | $ | 195,576 |  |  | $ | 187,949 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-19-000039:notes:322]
Segment Reporting

[0001375365-19-000039:notes:323]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-19-000039:notes:324]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the fiscal years ended June 30, 2017, 2016 and 2015, of net sales by geographic region (in thousands):

[0001375365-19-000039:notes:325]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories, and related services.


## us-gaap:SubsequentEventsTextBlock

[0001375365-19-000039:notes:326]
Subsequent Events

[0001375365-19-000039:notes:327]
In December 2017, the 2017 Tax Act was signed into law. The 2017 Tax Act reduces the U.S. federal corporate tax rate from 35% to 21% and imposes a one-time repatriation transition tax among other provisions. For details, see Note 13, "Income Taxes."

[0001375365-19-000039:notes:328]
On February 8, 2018, two putative class action complaints were filed against the Company, its Chief Executive Officer, and former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints claim that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff and it filed an amended complaint naming the Company's Senior Vice President of Investor Relations, as an additional defendant. The court approved the parties’ agreement to permit a further amendment of the complaint, which was filed on January 22, 2019. The Company believes the allegations filed are without merit, and intends to vigorously defend against the lawsuit.

[0001375365-19-000039:notes:329]
In April 2018, the Company repaid and terminated the 2016 Bank of America Credit Facility with proceeds from the 2018 Bank of America Credit Facility. As a result, the Company’s borrowing capacity increased from $155.0 million to $250.0 million. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, extend the maturity date of this credit facility from April 19, 2019 to June 30, 2019. For details, see Note 9, "Short-term and Long-term Obligations."

[0001375365-19-000039:notes:330]
Effective at the open of business on August 23, 2018, the Company’s common stock was suspended from trading on the Nasdaq Global Select Market. Effective March 22, 2019, the Company’s common stock was delisted from the Nasdaq Global Select Market. Since the date the Company’s common stock was suspended from trading on the Nasdaq Global Select Market, its common stock has been quoted on the OTC Market and is currently traded under the symbol “SMCI.”
