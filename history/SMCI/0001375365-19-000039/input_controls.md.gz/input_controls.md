# SMCI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001375365-19-000039:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-19-000039:item_9a:2]
Background

[0001375365-19-000039:item_9a:3]
In August 2017, prior to the issuance of the Company’s consolidated financial statements for the fiscal year ended June 30, 2017, the audit committee (the “Audit Committee”) of the Company’s Board of Directors (the “Board”) commenced an investigation (the “Investigation”) into certain accounting and internal control matters at the Company, principally focused on certain revenue recognition matters. The Investigation was conducted with the assistance of outside counsel, which retained forensic accountants to assist them in their work. Following the conclusion of the Investigation, the Audit Committee directed its outside counsel and its forensic accountants to conduct additional procedures on an expanded scope of revenue recognition matters. Concurrently with these additional procedures, new members of the Company’s management, under the direction of the Audit Committee, performed a thorough analysis of the Company’s historical financial statements, accounting policies and financial reporting, as well as the Company’s disclosure controls and procedures and its internal control over financial reporting. During the course of the Investigation, the further procedures by outside counsel and the management analysis (collectively, the “Investigation, Procedures and Analysis”), the Audit Committee and management discovered accounting and financial reporting errors and certain irregularities.

[0001375365-19-000039:item_9a:4]
The Audit Committee and management also discovered internal control deficiencies and determined that certain employees had violated the Company’s Code of Business Conduct and Ethics (“Code of Conduct”). In connection with the preparation and filing of this Annual Report on Form 10-K, we have conducted the requisite evaluations of the effectiveness of our disclosure controls and procedures and of our internal control over financial reporting both as of June 30, 2017. These conclusions are explained below.

[0001375365-19-000039:item_9a:5]
Evaluation of Disclosure Controls and Procedures

[0001375365-19-000039:item_9a:6]
Under the supervision, and with the participation, of our current management, including our CEO and CFO, we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of June 30, 2017. Based on this evaluation of our disclosure controls and procedures, our CEO and CFO have concluded that our disclosure controls and procedures were not effective as of June 30, 2017 because of certain material weaknesses in our internal control over financial reporting, as further described below.

[0001375365-19-000039:item_9a:7]
Notwithstanding the conclusion by our CEO and CFO that our disclosure controls and procedures as of June 30, 2017 were not effective, and notwithstanding the material weaknesses in our internal control over financial reporting described below, management believes that the consolidated financial statements and related financial information included in this Annual Report on Form 10-K fairly present in all material respects our financial condition, results of operations and cash flows as of the dates presented, and for the periods ended on such dates, in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”).

[0001375365-19-000039:item_9a:8]
Management’s Report on Internal Control Over Financial Reporting

[0001375365-19-000039:item_9a:9]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f).

[0001375365-19-000039:item_9a:10]
Internal control over financial reporting is a process designed by, or under the supervision of, our CEO and CFO to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our consolidated financial statements for external purposes in accordance with U.S. GAAP. Management’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets, (ii) provide reasonable assurance that transactions are appropriately recorded to permit preparation of financial statements in accordance with U.S. GAAP and that our receipts and expenditures are made only in accordance with authorizations of management, acting under authority delegated to them by the Board, and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on our financial statements.

[0001375365-19-000039:item_9a:11]
Management, including our CEO and CFO, assessed our internal control over financial reporting as of June 30, 2017. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control - Integrated Framework (2013) (the “COSO Framework”). Based on this assessment, management has determined that we did not maintain effective internal control over financial reporting as of June 30, 2017 because of the material weaknesses described below.

[0001375365-19-000039:item_9a:12]
A material weakness in internal controls is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. Because of its inherent limitations, even appropriate internal control over financial reporting may not prevent or detect misstatements.

[0001375365-19-000039:item_9a:13]
In connection with management’s assessment of the Company’s internal control over financial reporting described above, management has identified the deficiencies described below that constituted material weaknesses in our internal control over financial reporting as of June 30, 2017. These deficiencies led to material errors in our previously issued financial statements, which in turn led to the restatement of those previously issued financial statements, as described in Note 19 to our consolidated financial statements included in this Annual Report on Form 10-K.

[0001375365-19-000039:item_9a:14]
Control Environment

[0001375365-19-000039:item_9a:15]
We have identified deficiencies in the control environment component of the COSO Framework that constitute material weaknesses, either individually or in the aggregate. These deficiencies related to all the principles associated with the control environment component of the COSO Framework. Contributing factors include:

[0001375365-19-000039:item_9a:16]
| • | We had a culture of aggressively focusing on quarterly revenue without sufficient focus on compliance. Senior management did not establish and promote a control environment with an appropriate tone of compliance and control consciousness throughout the entire Company. The Company did not sufficiently promote, monitor or enforce adherence to the Code of Conduct. In the pursuit of quarterly revenue, certain of our sales, finance and operations personnel, including officers and managers, were aware of, condoned or were involved in actions that reflected an inappropriate tone at the top, that violated our Code of Conduct and our accounting policies and procedures, and that were inconsistent with a commitment to integrity and ethical values. These actions included (i) shipping products in advance of customer requested delivery dates, (ii) shipping products to storage facilities at the end of a quarter for later delivery to customers, (iii) in certain cases entering into side agreements with customers, (iv) in certain cases, shipping products before manufacturing was completed, (v) altering source documents related to some sales transactions and (vi) failing to disclose or obscuring material facts about sales transactions. As a result of those actions, we recognized revenue from numerous sales transactions in the incorrect period, although these valid sales transactions were recognized in one or more subsequent quarters in the aforementioned restatement. Some employees, including officers and managers, also failed to raise issues with material accounting consequences to the Audit Committee and our external auditors, and with respect to one transaction, appear to have attempted to minimize material facts about a sales transaction to, or obscure those facts from, the Audit Committee and our external auditors. Finally, we did not, on a consistent basis, (i) timely and thoroughly detect and address failures to comply with the Code of Conduct and (ii) train employees adequately to identify and report issues to management and the Audit Committee. |

[0001375365-19-000039:item_9a:17]
| • | The Company did not maintain a sufficient complement of management, accounting, financial reporting, sales, operations, engineering and information technology personnel who had appropriate levels of knowledge, experience, and training in accounting and internal control matters commensurate with the nature, growth and complexity of our business. The lack of sufficient appropriately skilled and trained personnel contributed to our failure to (i) adequately identify potential risks, (ii) include in the scope of our internal controls framework certain systems relevant to financial reporting and the preparation of our consolidated financial statements, (iii) design and implement certain risk-mitigating internal controls and (iv) consistently operate certain of our internal controls. The lack of sufficient appropriately skilled and trained personnel also contributed to deficiencies in establishing and maintaining policies and procedures, establishing and enforcing standards for maintaining documents for revenue recognition purposes and establishing accountability for internal controls across the entire Company. |

[0001375365-19-000039:item_9a:18]
Due to the interdependencies between the COSO Framework components, the weaknesses in our control environment contributed to other material weaknesses within our system of internal control over financial reporting.

[0001375365-19-000039:item_9a:19]
Risk Assessment

[0001375365-19-000039:item_9a:20]
We have identified deficiencies in the risk assessment component of the COSO Framework that aggregate to a material weakness. These deficiencies related to the principles associated with the risk assessment component of the COSO Framework, specifically principles within the component related to: (i) identifying, assessing, and communicating appropriate control objectives, (ii) identifying and analyzing risks to achieve these objectives, (iii) contemplating fraud risks, and (iv) identifying and assessing changes in the business that could impact our system of internal controls.

[0001375365-19-000039:item_9a:21]
Control Activities

[0001375365-19-000039:item_9a:22]
We have identified deficiencies in the control activities component of the COSO Framework that aggregate to a material weakness. These deficiencies related to principles associated with the control activities component of the COSO Framework, specifically principles within the component related to (i) selecting and developing control activities that mitigate risks (ii) selecting and developing general controls over technology and (iii) deploying control activities through policies that establish what is expected and procedures that put policies into action. We did not design or operate certain control activities to sufficiently respond to potential risks of material misstatement in the area of revenue recognition. We did not effectively select and develop certain information technology (“IT”) general controls and we also had control deficiencies at both the IT administrator and end-user levels across multiple applications relevant to financial reporting. We also had deficiencies related to segregation of duties. Deficiencies in control activities contributed to material accounting errors, and the potential for there to have been material accounting errors, in substantially all financial statements account balances and disclosures.

[0001375365-19-000039:item_9a:23]
Information and Communication

[0001375365-19-000039:item_9a:24]
We have identified deficiencies in the information and communication component of the COSO Framework that aggregate to a material weakness. These deficiencies related to principles associated with the information and communications component of the COSO Framework, specifically principles within the component related to (i) generating and using relevant quality information, (ii) internally communicating information, including objectives and responsibilities for internal control, necessary to support the functioning of internal control and (iii) communicating with external parties regarding matters affecting the functioning of internal control. We rely on manual business processes to compensate for a lack of extensive integration in our information systems. We also rely heavily on each of our various functions, such as sales, operations, accounting, legal and management, to communicate to the other functions information that the entire organization needs to operate an effective internal control environment. In certain areas, our control activity deficiencies resulted from insufficient communication of information among our internal functions as well as from officers and managers to both the Audit Committee and our external auditors.

[0001375365-19-000039:item_9a:25]
Monitoring of Controls

[0001375365-19-000039:item_9a:26]
We have identified deficiencies in the monitoring of controls component of the COSO Framework that aggregate to a material weakness. There were deficiencies related to principles associated with the monitoring of controls component of the COSO Framework, specifically principles within the component related to (i) selecting, developing and performing ongoing and/or separate evaluations and (ii) evaluating and communicating deficiencies in a timely manner. We lacked controls (i) to determine whether components of internal control were present and functioning, (ii) to mitigate the risk of management overriding internal controls and (iii) to detect incorrect accounting practices. Consequently, we did not identify internal control deficiencies, or did not raise such deficiencies in a timely manner to those parties responsible for internal controls. In addition, we did not always ensure that these deficiencies were remediated thoroughly and timely.

[0001375365-19-000039:item_9a:27]
The material weaknesses noted above contributed to the following additional material weaknesses:

[0001375365-19-000039:item_9a:28]
Revenue Recognition Accounting

[0001375365-19-000039:item_9a:29]
We have identified deficiencies in revenue recognition accounting controls that resulted in material errors constituting material weaknesses, either individually or in the aggregate, as we did not appropriately design, or effectively operate, internal controls over certain aspects of accurate recording, presentation, and disclosure of revenue and related costs. The following were contributing factors to the material weaknesses in revenue recognition accounting:

[0001375365-19-000039:item_9a:30]
| • | The Company’s internal controls did not consistently identify and properly account for key non-standard contract or arrangement terms for sales transactions that involved multiple elements (such as when the price of a system includes an extended warranty period and/or our agreement to provide services to our customer). Specifically, the Company’s internal controls failed to identify, accumulate and assess the accounting impact of situations in which we recognized revenue before all the elements necessary to establish “delivery” had occurred. |

[0001375365-19-000039:item_9a:31]
| • | With respect to sales transactions near quarter-end, our internal controls failed to consistently identify transactions where the terms of the sales arrangements with our customers were not properly documented in a form that fully reflected the final understanding between the parties as to the specific nature and terms of the agreed-upon transaction. |

[0001375365-19-000039:item_9a:32]
| • | Our internal controls failed to consistently identify, resolve, document in our accounting system and allow for proper accounting where there were inconsistencies among the various documents underlying our sales transactions, and we did not always communicate the existence or resolution of those inconsistencies to our accounting organization to enable the proper recognition of revenue. |

[0001375365-19-000039:item_9a:33]
| • | We lacked a control to ensure a consistent approach for reviewing our pricing and establishing supportable estimates of best estimated selling prices in allocating revenue between multiple elements. Consequently, we did not always correctly calculate the portions of the total revenue recognized from sales transactions allocated among the various elements. |

[0001375365-19-000039:item_9a:34]
Information Technology General Controls

[0001375365-19-000039:item_9a:35]
We have identified deficiencies related to IT general controls that represent a material weakness, either individually or in the aggregate. The following were contributing factors:

[0001375365-19-000039:item_9a:36]
| • | We have a decentralized approach to developing IT policies and practices and to monitoring our IT controls. As a result, our internal procedures for granting and monitoring employee access, and managing changes to various applications and infrastructure layers relevant to our financial reporting are not consistent across those applications and infrastructure layers. In addition, some of our internally-developed applications relevant to financial reporting lack logging capabilities to monitor access changes or application changes. We have also authorized certain users with broad access, both as a user and as an administrator, to all parts of our primary accounting system without adequate monitoring or recording of how they used that access. As a result of these factors, we have material weaknesses related to access controls and change management. The fact that we had material weaknesses related to access controls and change management means that it is possible that our business process controls that depend on the affected information systems, or that depend on data or financial reports generated from affected information systems, could be adversely affected due to the access control and change management issues, although we have identified no instances of any adverse effect due to these deficiencies. |

[0001375365-19-000039:item_9a:37]
The effectiveness of our internal control over financial reporting as of June 30, 2017 has been audited by Deloitte & Touche LLP, our independent registered public accounting firm, as stated in its report that is included herein.

[0001375365-19-000039:item_9a:38]
Remediation Plan and Status

[0001375365-19-000039:item_9a:39]
Our management is committed to remediating identified control deficiencies (including both those that rise to the level of a material weakness and those that do not), fostering continuous improvement in our internal controls and enhancing our overall internal controls environment. Our management believes that these remediation actions, along with additional actions, when fully implemented, will remediate the material weaknesses we have identified and strengthen our internal control over financial reporting. We are committed to improving our internal control processes and intend to continue to review and improve our financial reporting controls and procedures. As we continue to evaluate and work to improve our internal control over financial reporting, we may take additional measures to address control deficiencies with the overall objective to design and operate internal controls that mitigate identified risks and enable an effective system of internal control over external financial reporting.

[0001375365-19-000039:item_9a:40]
To date, we have taken the following remediation actions:

[0001375365-19-000039:item_9a:41]
| • | Restructured our sales organization, which resulted in the resignations of the Senior Vice President of International Sales, the Senior Vice President of Worldwide Sales, the Vice President, Strategic Accounts, the Vice President, Strategic Sales, the Vice President, Business Development and certain other sales personnel. |

[0001375365-19-000039:item_9a:42]
| • | Appointed experienced professionals to key accounting and finance and compliance leadership positions, including the appointments of a new Chief Financial Officer and a new Corporate Controller in January 2018, and the creation of, and appointments to, two newly established roles of Chief Compliance Officer and Vice President of Internal Audit in May 2018 and August 2018, respectively. |

[0001375365-19-000039:item_9a:43]
| • | Reviewed and amended our Code of Conduct to align with the organizational changes described above and to strengthen certain provisions regarding compliance and reporting. |

[0001375365-19-000039:item_9a:44]
| • | Adopted an Internal Audit Charter setting forth the responsibilities of the internal audit function and establishing that the Vice President of Internal Audit reports directly to the Audit Committee and that the Audit Committee has authority to provide adequate funding for this function. |

[0001375365-19-000039:item_9a:45]
| • | Changed our organizational structure to narrow the scope of responsibilities of certain of our senior executives and to revise various reporting relationships, which included the appointment of a new Senior Vice President of Worldwide Sales, and a new Senior Vice President of Operations. |

[0001375365-19-000039:item_9a:46]
| • | Conducted training in the following areas: |

[0001375365-19-000039:item_9a:47]
| − | Revenue recognition training for our global sales force, various operations personnel, and certain senior executives, including our CEO, which included detailed examples of acceptable and unacceptable sales practices, |

[0001375365-19-000039:item_9a:48]
| − | Reviewing with our senior management team our amended Code of Conduct, |

[0001375365-19-000039:item_9a:49]
−     Reviewing with our CEO enhanced processes for periodic evaluations by the CEO and the CFO of the effectiveness of our disclosure controls and procedures, and the periodic assessments by the CEO and the CFO of the effectiveness of our internal control over financial reporting, and other compliance matters, and

[0001375365-19-000039:item_9a:50]
−     Shipping and cut-off training for accounting and operations personnel that included new requirements for quarter-end procedures.

[0001375365-19-000039:item_9a:51]
| • | Upgraded our accounting department to include the new roles of Senior Director of Tax, Financial Audit Director and Information Technology Audit Director, as well as replaced certain of our accounting personnel with more experienced individuals, including rebuilding and expanding our revenue recognition team. |

[0001375365-19-000039:item_9a:52]
| • | Enhanced the sales sub-certification document that supports our CEO’s and CFO’s financial statement certifications and expanded the sub-certification participation population to the global sales force. |

[0001375365-19-000039:item_9a:53]
Our management believes that meaningful progress has been made on the remaining remediation efforts. Although timetables vary, management regards successful completion of our remaining remediation actions as an important priority. Some of the more significant remaining remediation activities include:

[0001375365-19-000039:item_9a:54]
| • | Developing and implementing an ongoing compliance training program regarding significant accounting and financial reporting matters, as well as broad compliance matters, for accounting, financial reporting, sales and operations personnel, as well as for our CEO, our other corporate executives and the Board. |

[0001375365-19-000039:item_9a:55]
| • | Integrating the responsibility for internal controls across business functions to ensure accountability for internal controls beyond the accounting and finance team. |

[0001375365-19-000039:item_9a:56]
| • | Continuing to assess current staffing levels and competencies to ensure the optimal complement of personnel with appropriate qualifications and skill sets. |

[0001375365-19-000039:item_9a:57]
| • | Reevaluating and revising our Sarbanes-Oxley compliance program (our “SOX Program”), and making improvements to our SOX Program governance, risk assessment processes, testing methodologies and corrective action mechanisms. |

[0001375365-19-000039:item_9a:58]
| • | Redesigning and implementing necessary changes to the existing system of internal controls in the context of the revised and more comprehensive risk assessment. |

[0001375365-19-000039:item_9a:59]
104

[0001375365-19-000039:item_9a:60]
| • | Assigning accountability for certain internal controls to our Compliance Department, such as our organizational-wide quarterly sales certification process. |

[0001375365-19-000039:item_9a:61]
| • | Reevaluating the boundary applications that interface with our primary accounting and reporting application and redesigning logical access and program change controls to enhance the reliability of information used to conduct other internal controls. |

[0001375365-19-000039:item_9a:62]
| • | Continuing to re-assess risks and controls related to the accurate recording, presentation, and disclosure of revenue and related costs |

[0001375365-19-000039:item_9a:63]
Changes in Internal Control Over Financial Reporting

[0001375365-19-000039:item_9a:64]
There were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the three months ended June 30, 2017 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-19-000039:item_9a:65]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-19-000039:item_9a:66]
To the Board of Directors and Stockholders of

[0001375365-19-000039:item_9a:67]
Super Micro Computer, Inc.

[0001375365-19-000039:item_9a:68]
San Jose, California

[0001375365-19-000039:item_9a:69]
We have audited the internal control over financial reporting of Super Micro Computer, Inc. and subsidiaries (the “Company”) as of June 30, 2017, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”). The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit.

[0001375365-19-000039:item_9a:70]
We conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-19-000039:item_9a:71]
A company’s internal control over financial reporting is a process designed by, or under the supervision of, the company's principal executive and principal financial officers, or persons performing similar functions, and effected by the company’s board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-19-000039:item_9a:72]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-19-000039:item_9a:73]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company’s annual or interim financial statements will not be prevented or detected on a timely basis. The following material weaknesses have been identified and included in management's assessment:

[0001375365-19-000039:item_9a:74]
Control Environment - The Company identified deficiencies in the control environment component of the COSO framework that constitute material weaknesses, either individually or in the aggregate. These deficiencies related to all the principles associated with the control environment component of the COSO framework, and contributing factors include:

[0001375365-19-000039:item_9a:75]
| • | The Company had a culture of aggressively focusing on quarterly revenue without sufficient focus on compliance. Senior management, did not establish and promote a control environment with an appropriate tone of compliance and control consciousness throughout the entire Company. The Company did not sufficiently promote, monitor or enforce adherence to the Code of Business Conduct and Ethics (“Code of Conduct”). In the pursuit of quarterly revenue, certain sales, finance and operations personnel, including officers and managers, were aware of, condoned or were involved in actions that reflected an inappropriate tone at the top, that violated the Code of Conduct and accounting policies and procedures, and that were inconsistent with a commitment to integrity and ethical values. As a result of those actions, the Company recognized revenue from numerous sales transactions in the incorrect period. Some Company employees, including officers and managers, also failed to raise issues with material accounting consequences to the Audit Committee and to us, as its external auditors, and with respect to one transaction, appear to have attempted to minimize material facts about a sales transaction to, or obscure those facts from, the Audit Committee and us, as its external auditors. Finally, the Company did not, on a consistent basis, (i) timely and thoroughly detect and address failures to comply with the Code of Conduct and (ii) train employees adequately to identify and report issues to management and the Audit Committee. |

[0001375365-19-000039:item_9a:76]
| • | The Company did not maintain a sufficient complement of management, accounting, financial reporting, sales, operations, engineering and information technology personnel who had appropriate levels of knowledge, experience, and training in accounting and internal control matters. The lack of sufficient appropriately skilled and trained personnel also contributed to deficiencies in establishing and maintaining policies and procedures, establishing and enforcing standards for maintaining documents for revenue recognition purposes and establishing accountability for internal controls across the entire Company. |

[0001375365-19-000039:item_9a:77]
Due to the interdependencies between the COSO framework components, the material weaknesses in the control environment contributed to other material weaknesses within the Company’s system of internal control over financial reporting.

[0001375365-19-000039:item_9a:78]
Risk Assessment - The Company identified deficiencies in the risk assessment component of the COSO framework that aggregate to a material weakness.  These deficiencies related to the principles associated with the risk assessment component of the COSO framework, specifically principles within the component related to: (i) identifying, assessing, and communicating appropriate control objectives, (ii) identifying and analyzing risks to achieve these objectives, (iii) contemplating fraud risks, and (iv) identifying and assessing changes in the business that could impact the system of internal controls.

[0001375365-19-000039:item_9a:79]
Control Activities - The Company identified deficiencies in the control activities component of the COSO framework that aggregate to a material weakness. These deficiencies related to principles associated with the control activities component of the COSO framework, specifically principles within the component related to (i) selecting and developing control activities that mitigate risks (ii) selecting and developing general controls over technology and (iii) deploying control activities through policies that establish what is expected and procedures that put policies into action. The Company did not design or operate certain control activities to sufficiently respond to potential risks of material misstatement in the area of revenue recognition. The Company had deficiencies related to segregation of duties. Deficiencies in control activities contributed to material accounting errors, and the potential for there to have been material accounting errors, in substantially all financial statements account balances and disclosures.

[0001375365-19-000039:item_9a:80]
Information and Communication -  The Company identified deficiencies in the information and communication component of the COSO framework that aggregate to a material weakness. These deficiencies related to principles associated with the information and communications component of the COSO framework, specifically principles within the component related to (i) generating and using relevant quality information and (ii) internally communicating information, including objectives and responsibilities for internal control, necessary to support the functioning of internal control and (iii) communicating with external parties regarding matters affecting the functioning of internal control. In certain areas, the Company’s control activity deficiencies resulted from insufficient communication of information among its internal functions as well as from officers and managers to both the Audit Committee and to us, as its external auditors.

[0001375365-19-000039:item_9a:81]
Monitoring of Controls - The Company identified deficiencies in the monitoring of controls component of the COSO framework that aggregate to a material weakness.  There were deficiencies related to principles associated with the monitoring of controls component of the COSO framework, specifically principles within the component related to (i) selecting, developing and performing ongoing and/or separate evaluations and (ii) evaluating and communicating deficiencies in a timely manner. The Company lacked controls (i) to determine whether components of internal control were present and functioning, (ii) to mitigate the risk of management overriding internal controls and (iii) to detect incorrect accounting practices. Consequently, the Company did not identify internal control deficiencies, or did not raise such deficiencies in a timely manner to those parties responsible for internal controls. In addition, the Company did not always ensure that these deficiencies were remediated thoroughly and timely.

[0001375365-19-000039:item_9a:82]
107

[0001375365-19-000039:item_9a:83]
The material weaknesses noted above contributed to the following additional material weaknesses:

[0001375365-19-000039:item_9a:84]
Revenue Recognition Accounting - The Company identified deficiencies in revenue recognition accounting controls that resulted in material errors constituting material weaknesses, either individually or in the aggregate, as the Company did not appropriately design, or effectively operate, internal controls over certain aspects of accurate recording, presentation, and disclosure of revenue and related costs. The following were contributing factors to the material weaknesses in revenue recognition accounting:

[0001375365-19-000039:item_9a:85]
| • | The Company’s internal controls did not consistently identify and properly account for key non-standard contract or arrangement terms for sales transactions that involved multiple elements (such as when the price of a system includes an extended warranty period and/or the Company’s agreement to provide services to its customer). Specifically, the Company’s internal controls failed to identify, accumulate and assess the accounting impact of situations in which they recognized revenue before all the elements necessary to establish “delivery” had occurred. |

[0001375365-19-000039:item_9a:86]
| • | With respect to sales transactions near quarter-end, the Company’s internal controls failed to consistently identify transactions where the terms of the sales arrangements with its customers were not properly documented in a form that fully reflected the final understanding between the parties as to the specific nature and terms of the agreed-upon transaction. |

[0001375365-19-000039:item_9a:87]
| • | The Company’s internal controls failed to consistently identify, resolve, document in its accounting system and allow for proper accounting where there were inconsistencies among the various documents underlying its sales transactions, and the Company did not always communicate the existence or resolution of those inconsistencies to its accounting organization to enable the proper recognition of revenue. |

[0001375365-19-000039:item_9a:88]
| • | The Company lacked a control to ensure a consistent approach for reviewing its pricing and establishing supportable estimates of best estimated selling prices in allocating revenue between multiple elements. Consequently, the Company did not always correctly calculate the portions of the total revenue recognized from sales transactions allocated among the various elements. |

[0001375365-19-000039:item_9a:89]
Information Technology General Controls - The Company identified deficiencies related to information technology (“IT”) general controls that represent a material weakness, either individually or in the aggregate. The following were contributing factors:

[0001375365-19-000039:item_9a:90]
| • | Procedures for granting and monitoring employee access to, and managing changes to, various applications and infrastructure layers relevant to financial reporting were not consistent across those applications and infrastructure layers. In addition, some internally-developed applications relevant to financial reporting lacked logging capabilities to monitor access changes or application changes. Also, certain users were authorized to have broad access, both as a user and as an administrator, to all parts of primary accounting system without adequate monitoring or recording of how they used that access. As a result of these factors, the Company has material weaknesses related to access controls and change management. The fact that the Company had material weaknesses related to access controls and change management means that it is possible that its business process controls that depend on the affected information systems, or that depend on data or financial reports generated from affected information systems, could be adversely affected due to the access control and change management issues. |

[0001375365-19-000039:item_9a:91]
These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements as of and for the year ended June 30, 2017, of the Company and this report does not affect our report on such financial statements.

[0001375365-19-000039:item_9a:92]
In our opinion, because of the effect of the material weaknesses identified above on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of June 30, 2017, based on the criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001375365-19-000039:item_9a:93]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements as of and for the year ended June 30, 2017, of the Company and our report dated May 16, 2019 expressed an unqualified opinion on those financial statements and included explanatory paragraphs regarding

[0001375365-19-000039:item_9a:94]
the accompanying 2016 and 2015 consolidated financial statements, which have been restated to correct misstatements, and significant purchases from and sales to two related parties.

[0001375365-19-000039:item_9a:95]
/s/ Deloitte & Touche LLP

[0001375365-19-000039:item_9a:96]
San Jose, California

[0001375365-19-000039:item_9a:97]
May 16, 2019

[0001375365-19-000039:item_9a:98]
109
