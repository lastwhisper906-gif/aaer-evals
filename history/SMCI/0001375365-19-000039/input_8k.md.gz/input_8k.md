# SMCI 8-K — 0001375365-19-000041 filed 2019-05-17

## item codes, every 8-K on or before 2019-05-17

- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2019-05-17

- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-19-000041:8k_2_02:1]
EX-99.1
2
exhibit991_20190516x202.htm
EXHIBIT 99.1

[0001375365-19-000041:8k_2_02:2]
Exhibit

[0001375365-19-000041:8k_2_02:3]
Exhibit 99.1

[0001375365-19-000041:8k_2_02:4]
Supermicro® Announces Third Quarter Fiscal 2019 Preliminary

[0001375365-19-000041:8k_2_02:5]
Financial Information and Files 2017 Form 10-K and Form 10-Q/As

[0001375365-19-000041:8k_2_02:6]
SAN JOSE, Calif. -- May 17, 2019 (BUSINESS WIRE) -- Super Micro Computer, Inc. (SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced preliminary financial information for its fiscal third quarter ended March 31, 2019.

[0001375365-19-000041:8k_2_02:7]
Preliminary Fiscal Third Quarter Highlights

[0001375365-19-000041:8k_2_02:8]
The Company expects to report the following financial results for the quarter ended March 31, 2019:

[0001375365-19-000041:8k_2_02:9]
| • | Net sales in a range of $742 million to $752 million compared to its previous guidance range of $800 million to $860 million |

[0001375365-19-000041:8k_2_02:10]
| • | GAAP and non-GAAP gross margin in the range of 15.5% to 15.7% |

[0001375365-19-000041:8k_2_02:11]
| • | GAAP fully diluted earnings per share in the range of $0.22 to $0.26; non-GAAP fully diluted earnings per share in the range of $0.48 to $0.52 |

[0001375365-19-000041:8k_2_02:12]
| • | Cash flow from operations of $112 million and capital expenditures of $7 million |

[0001375365-19-000041:8k_2_02:13]
GAAP gross margin for the fiscal third quarter of 2019 that the Company expects to report is in the range of 15.5% to 15.7% and GAAP fully diluted earnings per share is in the range of $0.22 to $0.26.

[0001375365-19-000041:8k_2_02:14]
Non-GAAP gross margin for the fiscal third quarter of 2019 that the Company expects to report is in the range of 15.5% to 15.7%, which excludes stock-based compensation expense of $0.4 million. Non-GAAP fully diluted earnings per share is expected to be in the range of $0.48 to $0.52, which excludes stock-based compensation expense of $5.0 million and Audit Committee investigation and review expense and other non-recurring expense of $13.9 million and the related tax effects of both.

[0001375365-19-000041:8k_2_02:15]
As of March 31, 2019, total cash, cash equivalents and short-term investments was $187.0 million and bank debt was $ 22.9 million.

[0001375365-19-000041:8k_2_02:16]
Supermicro Files 2017 Form 10-K and Form 10-Q/As, and Files Form 8-K

[0001375365-19-000041:8k_2_02:17]
Also today, the Company filed its Annual Report on Form 10-K for the fiscal year ended June 30, 2017 and amended Quarterly Reports on Form 10-Q/A for the fiscal quarters ended September 30, 2016, December 31, 2016 and March 31, 2017.   The 2017 Form 10-K includes the Company’s audited financial statements for fiscal 2017, and restates certain other information as set forth therein.  The Quarterly Reports on Form 10-Q/A restate certain information as set forth therein.

[0001375365-19-000041:8k_2_02:18]
Financial Information Is Preliminary and May Be Subject To Change

[0001375365-19-000041:8k_2_02:19]
The unaudited interim financial information presented in this press release is preliminary. The final financial results reported for this period may also differ from the results reported in this release as a result of the work

[0001375365-19-000041:8k_2_02:20]
necessary for the preparation of financial statements taking into account the results of the Audit Committee investigation, procedures and analysis.

[0001375365-19-000041:8k_2_02:21]
Fourth Quarter Fiscal 2019 Guidance

[0001375365-19-000041:8k_2_02:22]
The Company expects net sales in a range of $770 million to $830 million for the fourth quarter of fiscal year 2019 ending June 30, 2019.

[0001375365-19-000041:8k_2_02:23]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-19-000041:8k_2_02:24]
Use of Non-GAAP Financial Measures

[0001375365-19-000041:8k_2_02:25]
Non-GAAP gross margin and fully diluted earnings per share discussed in this press release exclude as applicable stock-based compensation expense, costs associated with the Audit Committee investigation and review and other non-recurring expenses described above, and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, the reconciliation between the Company's GAAP gross margin and non-GAAP gross margin is stock-based compensation of $0.4 million and the reconciliation between the Company’s GAAP fully diluted earnings per share and non-GAAP fully diluted earnings per share is stock-based compensation of $5.0 million, and Audit Committee investigation and review expense and other non-recurring expense of $13.9 million less related tax effect of $4.3 million.

[0001375365-19-000041:8k_2_02:26]
About Super Micro Computer, Inc.

[0001375365-19-000041:8k_2_02:27]
Supermicro® (SMCI), the leading innovator in high-performance, high-efficiency server technology is a premier provider of advanced Server Building Block Solutions® for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-19-000041:8k_2_02:28]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-19-000041:8k_2_02:29]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-19-000041:8k_2_02:30]
SMCI-F

[0001375365-19-000041:8k_2_02:31]
Investor Relations Contact

[0001375365-19-000041:8k_2_02:32]
Super Micro Computer, Inc.

[0001375365-19-000041:8k_2_02:33]
Perry G. Hayes,

[0001375365-19-000041:8k_2_02:34]
SVP, Investor Relations

[0001375365-19-000041:8k_2_02:35]
408-895-6570

## item 5.02 — body, verbatim

[0001375365-19-000041:8k_body:1]
Item 5.02

[0001375365-19-000041:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001375365-19-000041:8k_body:3]
Effective May 15, 2019, Sara Liu, a Co-Founder of the Company, transitioned from her positions as Chief Administrative Officer and Treasurer to a new position of Senior Vice President.  She remains a director of the Company.
