# SMCI MD&A — 0001375365-20-000064


## mdna

[0001375365-20-000064:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-20-000064:mdna:2]
Nasdaq Relisting of our Common Stock

[0001375365-20-000064:mdna:3]
As a result of the delay in filing our periodic reports with the SEC and failure to hold an annual meeting, we were unable to comply with the Nasdaq listing standards and our common stock was suspended from trading on the Nasdaq Global Select Market effective August 23, 2018 and formally delisted effective March 22, 2019. Following the suspension of trading, our common stock was quoted on the OTC Market and traded under the symbol “SMCI.” On January 14, 2020, our common stock was relisted on the NASDAQ Global Select Market under the symbol “SMCI". For further information regarding trading in our common stock, refer to Part II, Item 5, “Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities” in this Annual Report.

[0001375365-20-000064:mdna:4]
Overview

[0001375365-20-000064:mdna:5]
We are a global leader and innovator of application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence, 5G and edge computing. Our solutions include complete servers, storage systems, modular blade servers, blades, workstations, full racks, networking devices, server management software, and server sub-systems. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-20-000064:mdna:6]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2020, 2019 and 2018, our net income was $84.3 million, $71.9 million and $46.2 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-20-000064:mdna:7]
Coronavirus (COVID-19) Pandemic Impact

[0001375365-20-000064:mdna:8]
The global spread of the coronavirus (COVID-19) and the various attempts to contain it have created significant volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders to close all businesses not deemed “essential,” shelter in place, and practice social distancing when engaging in essential activities. We are an essential critical infrastructure (information technology) business under the relevant Federal, State and County regulations. In late March, we responded to the directives from Santa Clara County and the State of California regarding shelter in place instructions to combat the spread of COVID-19. Our first priority is the safety of our workforce and we immediately began to implement numerous health precautions and work practices to operate in a safe manner.

[0001375365-20-000064:mdna:9]
We quickly transitioned most of our indirect labor forces to work from home and continued to operate our local assembly in Taiwan and, after an initial period of disruption, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continue to see ongoing demand as we enter the first quarter of fiscal year 2021 and do not have significant direct exposure to industries such as retail and oil and gas, which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-20-000064:mdna:10]
We have actively managed our supply chain for potential shortage risk by first building inventories of critical components required for our motherboards and other system printed circuit boards in response to the early outbreak of COVID-19 in China. Since that time, we have continued to add to our inventories of key components such as CPUs, memory, SSDs and to a lesser extent GPUs such that customer orders can be fulfilled as they are received.

[0001375365-20-000064:mdna:11]
Logistics has emerged as a new challenge as globally the transportation industry restricted the frequency of departures and increased logistics costs. We experienced increased costs in freight as well as direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect this trend to continue for the duration of the uncertainties related to the COVID-19 pandemic.

[0001375365-20-000064:mdna:12]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In May 2020, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2021. In June 2020, we entered into a ten-year, non-revolving term loan facility with China Trust and Bank Corp ("CTBC Bank") to obtain financing for use in the expansion and renovation of the our Bade Manufacturing Facility located in Taiwan.

[0001375365-20-000064:mdna:13]
Our management team is focused on guiding our company through the unfolding and emerging challenges presented by COVID-19. Currently, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-20-000064:mdna:14]
Financial Highlights

[0001375365-20-000064:mdna:15]
The following is a summary of financial highlights of fiscal years 2020 and 2019:

[0001375365-20-000064:mdna:16]
| • | Net sales declined by 4.6% in fiscal year 2020 as compared to fiscal year 2019. |

[0001375365-20-000064:mdna:17]
| • | Gross margin increased to 15.8% in fiscal year 2020 from 14.2% in fiscal year 2019, primarily due to lower prices for key components and increased services and software revenues that have higher margins. |

[0001375365-20-000064:mdna:18]
| • | Operating expenses increased by 10.6% in fiscal year 2020 as compared to fiscal year 2019, primarily due to the special performance bonuses to our employees and the accrual for our settlement with the SEC. |

[0001375365-20-000064:mdna:19]
| • | Net income increased to $84.3 million in fiscal year 2020 as compared to $71.9 million in fiscal year 2019, which was primarily due to a reduction in our effective tax rate to 3.4% in fiscal year 2020 as compared to 16.6% in fiscal year 2019. |

[0001375365-20-000064:mdna:20]
| • | Our cash and cash equivalents were $210.5 million and $248.2 million at the end of fiscal years 2020 and 2019, respectively. In fiscal year 2020, we used net cash of $49.8 million, of which $30.3 million was used in operating activities related primarily to additional working capital requirements such as building increased inventories of critical components. We also invested $44.3 million in purchases of property and equipment, including construction of a new facility in San Jose, California, and generated $23.8 million in financing activities primarily from the proceeds from exercises of stock options. |

[0001375365-20-000064:mdna:21]
Subsequent Events

[0001375365-20-000064:mdna:22]
For details, see Part II, Item 8, Note 20, “Subsequent Events” in our notes to the consolidated financial statements in this Annual Report.

[0001375365-20-000064:mdna:23]
Critical Accounting Policies

[0001375365-20-000064:mdna:24]
General

[0001375365-20-000064:mdna:25]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are

[0001375365-20-000064:mdna:26]
not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-20-000064:mdna:27]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-20-000064:mdna:28]
Revenue Recognition

[0001375365-20-000064:mdna:29]
We generate revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-20-000064:mdna:30]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold are delivered via shipment from our facilities or drop shipment directly to our customer from our vendor. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-20-000064:mdna:31]
As part of determining the transaction price in contracts with customers, we estimate reserves for future sales returns based on a review of our history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. We also reduce revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-20-000064:mdna:32]
Services sales. Our sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-20-000064:mdna:33]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-20-000064:mdna:34]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-20-000064:mdna:35]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-20-000064:mdna:36]
We consider shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.

[0001375365-20-000064:mdna:37]
Product Warranties

[0001375365-20-000064:mdna:38]
We offer product warranties typically ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and we do not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, we accrue for estimated returns of defective products at the time revenue is recognized. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are recorded to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with our historical experience, and the changes in the cost of servicing warranty claims. We account for the effect of such changes in estimates prospectively.

[0001375365-20-000064:mdna:39]
Inventories

[0001375365-20-000064:mdna:40]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-20-000064:mdna:41]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-20-000064:mdna:42]
Income Taxes

[0001375365-20-000064:mdna:43]
We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-20-000064:mdna:44]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-20-000064:mdna:45]
Stock-Based Compensation

[0001375365-20-000064:mdna:46]
We measure and recognize compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. We base initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period.

[0001375365-20-000064:mdna:47]
That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-20-000064:mdna:48]
The fair value of RSUs and PRSUs is based on the closing market price of our common stock on the date of grant. We estimate the fair value of stock options granted using a Black-Scholes option pricing model. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the historical volatility of our common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-20-000064:mdna:49]
Variable Interest Entities

[0001375365-20-000064:mdna:50]
We determine at the inception of each arrangement whether an entity in which we hold an investment or in which we have other variable interests is considered a variable interest entity ("VIE"). We consolidate VIEs when we are the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, we assess whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether we are the primary beneficiary. If we are not the primary beneficiary in a VIE, we account for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-20-000064:mdna:51]
We have concluded that Ablecom Technology, Inc. ("Ablecom") and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs; however, we are not the primary beneficiary as we do not have the power to direct the activities that are most significant to the entities and therefore, we do not consolidate these entities. In performing this analysis, we considered our explicit arrangements with Ablecom and Compuware, including all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between us and these two companies, we considered whether any implicit arrangements exist that would cause us to protect these related parties’ interests from suffering losses. We determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-20-000064:mdna:52]
We and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the “Management Company”) in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. In fiscal year 2012, each party contributed $0.2 million for a 50% ownership interest of the Management Company. We have concluded that the Management Company is a VIE and we are the primary beneficiary as we have the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2020, 2019 and 2018, the accounts of the Management Company were consolidated with our accounts, and a noncontrolling interest was recorded for Ablecom’s interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom’s interest was not material for the periods presented and was included in general and administrative expenses in our consolidated statements of operations.

[0001375365-20-000064:mdna:53]
36

[0001375365-20-000064:mdna:54]
Results of Operations

[0001375365-20-000064:mdna:55]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of revenue.

[0001375365-20-000064:mdna:56]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.2 | % |  | 85.8 | % |  | 87.2 | % |
| Gross profit | 15.8 | % |  | 14.2 | % |  | 12.8 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 6.6 | % |  | 5.1 | % |  | 4.9 | % |
| Sales and marketing | 2.5 | % |  | 2.2 | % |  | 2.1 | % |
| General and administrative | 4.1 | % |  | 4.0 | % |  | 2.9 | % |
| Total operating expenses | 13.2 | % |  | 11.3 | % |  | 9.9 | % |
| Income from operations | 2.6 | % |  | 2.9 | % |  | 2.9 | % |
| Other (expense) income, net | — | % |  | — | % |  | — | % |
| Interest expense | (0.1 | )% |  | (0.2 | )% |  | (0.2 | )% |
| Income before income tax provision | 2.5 | % |  | 2.7 | % |  | 2.7 | % |
| Income tax provision | (0.1 | )% |  | (0.4 | )% |  | (1.1 | )% |
| Share of income (loss) from equity investee, net of taxes | 0.1 | % |  | (0.1 | )% |  | (0.1 | )% |
| Net income | 2.5 | % |  | 2.2 | % |  | 1.5 | % |

[0001375365-20-000064:mdna:57]
Net Sales

[0001375365-20-000064:mdna:58]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact our net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact our net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-20-000064:mdna:59]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs.

[0001375365-20-000064:mdna:60]
The following table presents net sales by product type for fiscal years 2020, 2019 and 2018 (dollars in millions):

[0001375365-20-000064:mdna:61]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 2,620.8 |  |  | $ | 2,858.7 |  |  | $ | 2,663.6 |  |  | $ | (237.9 | ) |  | (8.3 | )% |  | $ | 195.1 |  |  | 7.3 | % |
| Percentage of total net sales | 78.5 | % |  | 81.7 | % |  | 79.3 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 718.5 |  |  | 641.7 |  |  | 696.9 |  |  | 76.8 |  |  | 12.0 | % |  | (55.2 | ) |  | (7.9 | )% |
| Percentage of total net sales | 21.5 | % |  | 18.3 | % |  | 20.7 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,339.3 |  |  | $ | 3,500.4 |  |  | $ | 3,360.5 |  |  | $ | (161.1 | ) |  | (4.6 | )% |  | $ | 139.9 |  |  | 4.2 | % |

[0001375365-20-000064:mdna:62]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:63]
During fiscal year 2020 we continued to experience a steady demand for server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year decrease in net sales of server and storage systems was primarily due to a decrease of average selling prices per compute node by approximately 11%, offset by a slight increase in the number of units of compute nodes sold. We typically adjust our prices as component costs rise and fall. The decline in average selling prices was primarily due to substantially lower costs for key components, specifically for memory and storage, as compared to the previous fiscal year. Our services and software revenue, included in server and storage systems revenue, increased by $39.8 million year-over-year. The year-over-year increase in net sales of subsystems and accessories was primarily due to an increase of approximately 19% in the volume of subsystems and accessories sold, mainly due to increased demand from our indirect sales channel offset by an approximately 6% decrease in average selling prices due primarily to the decrease in costs of the components.

[0001375365-20-000064:mdna:64]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:65]
The year-over-year increase in server and storage systems sales was primarily due to an increase of average selling price per compute node by approximately 15%, offset by a decrease of approximately 8% in the number of units of compute nodes sold. The decrease in the number of units of compute notes was primarily attributable to an overall market slowdown in the second half of fiscal year 2019. The increase in the average selling prices of our server and storage systems was primarily due to higher sales of our complete systems configured with higher density computing and more memory and storage capacity. During the first half of fiscal year 2019, we increased our average selling prices primarily to remain consistent with the increases in the cost of memory and SSDs on a year-over year basis. During October 2018, a 10% tariff was applied to certain key components made in China and was partially incorporated into our average selling prices to the extent that component sourcing alternatives were not available. As costs for memory and SSDs began to decline in the second half of fiscal year 2019, our average selling prices to customers declined accordingly. Our services revenue, included in server and storage systems revenue, increased by $41.6 million year-over-year. The year-over-year decrease in net sales of our subsystems and accessories in fiscal year 2019 was primarily due to a decrease of average selling prices of approximately 8%.

[0001375365-20-000064:mdna:66]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs for fiscal years 2020, 2019 and 2018 (dollars in millions):

[0001375365-20-000064:mdna:67]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Indirect sales channel | $ | 1,771.6 |  |  | $ | 1,376.7 |  |  | $ | 1,395.8 |  |  | $ | 394.9 |  |  | 28.7 | % |  | $ | (19.1 | ) |  | (1.4 | )% |
| Percentage of total net sales | 53.1 | % |  | 39.3 | % |  | 41.5 | % |  |  |  |  |  |  |  |  |
| Direct customers and OEMs | 1,567.7 |  |  | 2,123.7 |  |  | 1,964.7 |  |  | (556.0 | ) |  | (26.2 | )% |  | 159.0 |  |  | 8.1 | % |
| Percentage of total net sales | 46.9 | % |  | 60.7 | % |  | 58.5 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,339.3 |  |  | $ | 3,500.4 |  |  | $ | 3,360.5 |  |  | $ | (161.1 | ) |  | (4.6 | )% |  | $ | 139.9 |  |  | 4.2 | % |

[0001375365-20-000064:mdna:68]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:69]
The period-over-period increase in net sales through our indirect sales channel was primarily due to increased demand from the channel supporting large end users and partially offset by the lower average selling prices for our server and storage systems, caused by lower component pricing. Some direct customers also elected to move a part or all of their purchases to be through an indirect sales channel. The period-over-period decrease in net sales to our direct customers and OEMs was primarily due to a decline in demand from our internet datacenter and cloud customers and our enterprise datacenter customers.

[0001375365-20-000064:mdna:70]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:71]
The year-over-year decrease in net sales through our indirect sales channel was primarily due to the higher sales to our direct customers and OEMs. The year-over-year increase in net sales to direct customers and OEMs was primarily due to higher sales of our server and storage systems to internet data center and cloud, enterprise and OEM customers.

[0001375365-20-000064:mdna:72]
The following table presents percentages of net sales by geographic region for fiscal years 2020, 2019 and 2018 (dollars in millions):

[0001375365-20-000064:mdna:73]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| United States | $ | 1,957.3 |  |  | $ | 2,032.9 |  |  | $ | 1,902.1 |  |  | $ | (75.6 | ) |  | (3.7 | )% |  | $ | 130.8 |  |  | 6.9 | % |
| Percentage of total net sales | 58.6 | % |  | 58.1 | % |  | 56.6 | % |  |  |  |  |  |  |  |  |
| Asia | 650.7 |  |  | 712.2 |  |  | 762.7 |  |  | (61.5 | ) |  | (8.6 | )% |  | (50.5 | ) |  | (6.6 | )% |
| Percentage of total net sales | 19.5 | % |  | 20.3 | % |  | 22.7 | % |  |  |  |  |  |  |  |  |
| Europe | 598.6 |  |  | 611.0 |  |  | 547.5 |  |  | (12.4 | ) |  | (2.0 | )% |  | 63.5 |  |  | 11.6 | % |
| Percentage of total net sales | 17.9 | % |  | 17.5 | % |  | 16.3 | % |  |  |  |  |  |  |  |  |
| Others | 132.7 |  |  | 144.3 |  |  | 148.2 |  |  | (11.6 | ) |  | (8.0 | )% |  | (3.9 | ) |  | (2.6 | )% |
| Percentage of total net sales | 4.0 | % |  | 4.1 | % |  | 4.4 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,339.3 |  |  | $ | 3,500.4 |  |  | $ | 3,360.5 |  |  |  |  |  |  |  |  |  |

[0001375365-20-000064:mdna:74]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:75]
The year-over-year decrease in net sales in the United States was primarily due to a decrease in net sales of our server and storage systems to our direct customers and OEMs. The year-over-year decrease in net sales in Asia was primarily due to a decrease in net sales of our server and storage systems to OEMs in China, India and Japan, partially offset by a slight increase in the net sales of subsystems and accessories in China and of server and storage systems in the rest of Asia region. The year-over-year decrease in net sales in Europe was primarily due to a decrease in net sales of our server and storage systems to our direct customers and OEMs in the Netherlands, partially offset by an increase in net sales of our subsystems and accessories to our indirect sales channel in Germany and an increase in sales to our indirect sales channel in France.

[0001375365-20-000064:mdna:76]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:77]
The year-over-year increase in net sales in the United States was primarily due to the higher sales of our server and storage systems to our direct customers and OEMs. The year-over-year decrease in net sales in Asia was due primarily to decreased sales through our indirect sales channel in China, partially offset by increased sales in Taiwan to enterprise datacenter customers. The increased percentage of net sales in Europe was primarily due to higher sales in the Netherlands to enterprise and cloud computing customers.

[0001375365-20-000064:mdna:78]
Cost of Sales and Gross Margin

[0001375365-20-000064:mdna:79]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-20-000064:mdna:80]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the fiscal years 2020, we continued to expand manufacturing and service operations in Taiwan primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware combined represented 10.1%, 9.2% and 9.0% of our cost of sales for fiscal years 2020, 2019 and 2018, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 13, “Related Party Transactions.”

[0001375365-20-000064:mdna:81]
Cost of sales and gross margin for fiscal years 2020, 2019 and 2018, are as follows (dollars in millions):

[0001375365-20-000064:mdna:82]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 2,813.1 |  |  | $ | 3,004.8 |  |  | $ | 2,930.5 |  |  | $ | (191.7 | ) |  | (6.4 | )% |  | $ | 74.3 |  |  | 2.5 | % |
| Gross profit | 526.2 |  |  | 495.5 |  |  | 430.0 |  |  | 30.7 |  |  | 6.2 | % |  | 65.5 |  |  | 15.2 | % |
| Gross margin | 15.8 | % |  | 14.2 | % |  | 12.8 | % |  |  |  | 1.6 | % |  |  |  |  | 1.4 | % |

[0001375365-20-000064:mdna:83]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:84]
The year-over-year decrease in cost of sales was primarily attributable to a decrease of $214.3 million in inventory costs related primarily to the decrease in the prices of components and a decrease of $14.6 million in the provision of excess inventory and obsolescence due to fewer excess and obsolescence items identified in the fiscal year 2020. This was offset by an increase of $19.6 million in overhead costs attributable primarily to increased tariffs and an increase of $11.3 million in personnel expenses, which included a special performance bonus of $4.1 million. Warranty and repairs costs also increased by $5.7 million in the fiscal year 2020 as compared to the fiscal year 2019.

[0001375365-20-000064:mdna:85]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components and due to the increase in services and software revenue which have higher margins than product sales. Since the start of the COVID-19 pandemic, we have experienced an increase in both logistics costs as well as direct labor costs as we incentivize our employees to continue to work and assist us in serving our customers.  This increase in costs negatively impacts our gross margins, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-20-000064:mdna:86]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:87]
The year-over-year decrease in cost of sales was primarily attributable to an increase of $25.8 million in inventory costs related to the increase in net sales volume, increased expense of $23.3 million in the provision for excess inventory and obsolescence, an increase in overhead costs of $10.7 million attributable to increased tariffs for import of components from China, an increase of $8.6 million in compensation and benefits including stock-based compensation as a result of an increase in annual salaries and benefits and an increase in the number of operations personnel, and an increase of warranty provision of $5.4 million related to the increase in net sales.

[0001375365-20-000064:mdna:88]
The year-over-year increase in the gross margin percentage was primarily due to lower costs of memory and SSDs components in the second half of fiscal year 2019 and the timing of adjusting our average selling prices, as well as the increase in services and software revenue which have higher margins than product sales. In addition, in fiscal year 2020 as compared with fiscal year 2019, we had lower net sales in Asia where pricing is typically lower and the market there is more competitive which resulted in a shift in geographic mix that had a positive impact on our gross margin percentage.

[0001375365-20-000064:mdna:89]
Operating Expenses

[0001375365-20-000064:mdna:90]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-20-000064:mdna:91]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs

[0001375365-20-000064:mdna:92]
can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-20-000064:mdna:93]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-20-000064:mdna:94]
Operating expenses for fiscal years 2020, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000064:mdna:95]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 221.5 |  |  | $ | 179.9 |  |  | $ | 165.1 |  |  | $ | 41.6 |  |  | 23.1 | % |  | $ | 14.8 |  |  | 9.0 | % |
| Sales and marketing | 85.1 |  |  | 77.2 |  |  | 71.6 |  |  | 7.9 |  |  | 10.2 | % |  | 5.6 |  |  | 7.8 | % |
| General and administrative | 133.9 |  |  | 141.2 |  |  | 98.6 |  |  | (7.3 | ) |  | (5.2 | )% |  | 42.6 |  |  | 43.2 | % |
| Total operating expenses | $ | 440.5 |  |  | $ | 398.3 |  |  | $ | 335.3 |  |  | 42.2 |  |  | 10.6 | % |  | 63.0 |  |  | 18.8 | % |

[0001375365-20-000064:mdna:96]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:97]
The year-over-year increase in research and development expenses was primarily due to an increase of $41.3 million in personnel expenses as a result of an increase in the number of research and development employees and a special performance bonus of $17.3 million, a decrease of $0.7 million in reimbursements received for certain research and development costs that we incurred as part of joint product development; an increase of $6.7 million in costs mainly related to materials, supplies and equipment used in product development; and an increase of $1.8 million in facilities expenses. During fiscal year 2020, we also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-20-000064:mdna:98]
The year-over-year increase in sales and marketing expenses was primarily due to an increase of $8.1 million in personnel expenses as a result of an increase in the number of sales and marketing personnel and a special performance bonus of $1.8 million

[0001375365-20-000064:mdna:99]
The year-over-year decrease in general and administrative expenses was due to a decrease of $33.9 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements; a decrease of $10.2 million in bad debt provision expenses due to recovery of previously provisioned receivables from certain international customers, offset by an increase of $17.5 million related to an expense accrual for the settlement with the SEC; an increase of $14.1 million in personnel expenses as a result of an increase in the number of personnel and a special performance bonus of $4.5 million; an increase of $3.2 million in insurance expense; and an increase of $1.7 million related primarily to facilities expenses.

[0001375365-20-000064:mdna:100]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:101]
The year-over-year increase in research and development expenses was due to an increase of $16.0 million in personnel expenses, an decrease of $3.3 million in reimbursements received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products, offset by a decrease of $6.1 million in product development costs. Our personnel expenses increased primarily as a result of an increase in annual salaries and benefits, and an increase in the number of research and development personnel to support our expanded product development initiatives and to support the growth of our business in many market verticals.

[0001375365-20-000064:mdna:102]
The year-over-year increase in sales and marketing expenses was due to an increase of $6.1 million in personnel expenses, as a result of an increase in annual salaries and benefits and an increase in the number of sales and marketing personnel, offset by a $1.5 million decrease in expenses related to advertising and promotion activities.

[0001375365-20-000064:mdna:103]
The year-over-year increase in general and administrative expenses was attributable to an increase of $31.7 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, an increase of $7.2 million in bad debt provision expenses primarily as a result of our inability to collect receivables from

[0001375365-20-000064:mdna:104]
certain international customers and an increase of $2.7 million primarily attributable to increase in sales tax accrual and insurance costs.

[0001375365-20-000064:mdna:105]
Interest and Other Income (Expense), Net

[0001375365-20-000064:mdna:106]
Other income (expense), net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-20-000064:mdna:107]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-20-000064:mdna:108]
Interest and other income (expense), net for fiscal years 2020, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000064:mdna:109]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Other income (expense), net | $ | 1.4 |  |  | $ | (1.0 | ) |  | $ | (0.8 | ) |  | $ | 2.4 |  |  | (240.0 | )% |  | $ | (0.2 | ) |  | 25.0 | % |
| Interest expense | (2.2 | ) |  | (6.7 | ) |  | (5.7 | ) |  | 4.5 |  |  | (67.2 | )% |  | (1.0 | ) |  | 17.5 | % |
| Interest and other expense, net | $ | (0.8 | ) |  | $ | (7.7 | ) |  | $ | (6.5 | ) |  | $ | 6.9 |  |  | (89.6 | )% |  | $ | (1.2 | ) |  | 18.5 | % |

[0001375365-20-000064:mdna:110]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:111]
The year-over-year change in interest expense of $4.5 million is primarily a result of lower interest rates and reduced levels of borrowings in fiscal year 2020 as compared to fiscal year 2019. The change of $2.4 million in other income (expense), net was attributable to an increase of $1.6 million in interest income on our interest bearing deposits and a decrease of $0.8 million in other expenses.

[0001375365-20-000064:mdna:112]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:113]
The year-over-year increase in interest and other expense, net was primarily due to an increase of $1.0 million in interest expense related to amortization of loan origination fees in connection with refinancing of our debt in the last quarter of fiscal year 2018, an increase in other expense of $2.1 million as a result of an impairment recorded for certain investments, offset by an increase of $1.9 million attributable to increase in interest income on our interest bearing deposits and foreign exchange gain due to favorable foreign currency fluctuations.

[0001375365-20-000064:mdna:114]
Provision for Income Taxes

[0001375365-20-000064:mdna:115]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, releases from uncertain tax positions, tax benefits from foreign derived intangible income and stock based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 15, “Income Taxes” to the consolidated financial statements in this Annual Report.

[0001375365-20-000064:mdna:116]
Provision for income taxes and effective tax rates for fiscal years 2020, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000064:mdna:117]
|  | Years Ended June 30, |  | 2020 over 2019 Change |  | 2019 over 2018 Change |
|  | 2020 |  | 2019 |  | 2018 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 2.9 |  |  | $ | 14.9 |  |  | $ | 38.4 |  |  | $ | (12.0 | ) |  | (80.5 | )% |  | $ | (23.5 | ) |  | (61.2 | )% |
| Effective tax rate | 3.4 | % |  | 16.6 | % |  | 43.6 | % |  |  |  |  |  |  |  |  |

[0001375365-20-000064:mdna:118]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-20-000064:mdna:119]
The year-over-year decrease in the effective tax rate was primarily due to an increase in tax benefits from research and development tax credits, stock based compensation, releases of uncertain tax positions, and U.S. sales to foreign jurisdictions, partially offset by the tax impact from the non-deductible settlement with the SEC.

[0001375365-20-000064:mdna:120]
Fiscal Year 2019 Compared with Fiscal Year 2018

[0001375365-20-000064:mdna:121]
The year-over-year decrease in the effective tax rate was primarily due to a reduction of the statutory tax rate from 28.1% to 21% as a result of the tax reform, and a prior year recording of a one-time $12.9 million write down of U.S. deferred tax assets and liabilities, and a one-time transition tax of $2.8 million, all as a result of the 2017 Tax Reform Act.

[0001375365-20-000064:mdna:122]
Liquidity and Capital Resources

[0001375365-20-000064:mdna:123]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $210.5 million and $248.2 million as of June 30, 2020 and 2019, respectively. Our cash in foreign locations was $98.0 million and $124.6 million as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:mdna:124]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective, but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-20-000064:mdna:125]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be generally sufficient to support our operating businesses, expansion of our manufacturing facilities, continued remediation of the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, and maturing debt and interest payments for the twelve months following the issuance of these consolidated financial statements. We expect to pay special performance bonuses of approximately $8.6 million to our CEO and certain members of the Board of Directors within the next two years when and if specified market and performance conditions are met. In addition, we made a settlement payment of $17.5 million to the SEC in connection with the conclusion of the ongoing investigations in August 2020.

[0001375365-20-000064:mdna:126]
On August 9, 2020, our Board of Directors approved a share repurchase program to repurchase shares of common stock for up to $30.0 million at prevailing prices in the open market. The share repurchase program is effective until December 31, 2020 or until the maximum amount of common stock is repurchased.

[0001375365-20-000064:mdna:127]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-20-000064:mdna:128]
|  | Years Ended June 30, |  | 2020 over 2019 |  | 2019 over 2018 |
|  | 2020 |  | 2019 |  | 2018 |  |  |
| Net cash (used in) provided by operating activities | $ | (30.3 | ) |  | $ | 262.6 |  |  | $ | 84.3 |  |  | $ | (292.9 | ) |  | $ | 178.3 |  |
| Net cash used in investing activities | $ | (43.6 | ) |  | $ | (24.8 | ) |  | $ | (25.9 | ) |  | $ | (18.8 | ) |  | $ | 1.1 |  |
| Net cash provided by (used in) financing activities | $ | 23.8 |  |  | $ | (95.8 | ) |  | $ | (50.8 | ) |  | $ | 119.6 |  |  | $ | (45.0 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (49.8 | ) |  | $ | 141.8 |  |  | $ | 7.6 |  |  | $ | (191.6 | ) |  | $ | 134.2 |  |

[0001375365-20-000064:mdna:129]
Operating Activities

[0001375365-20-000064:mdna:130]
Net cash provided by operating activities decreased by $292.9 million for fiscal year 2020 as compared to fiscal year 2019.  While net income increased by $12.4 million in fiscal year 2020 as compared to fiscal year 2019, the decrease in cash flows from operating activities was due primarily to an increase of cash used for net working capital requirements of $281.3 million, including a $181.3 million increase in inventories to meet customer demand, support expected business growth and mitigate supply chain risk due to the COVID-19 pandemic environment. Non-cash charges related to excess and obsolete inventory decreased by $14.6 million, related to bad debt reserve decreased by $10.1 million, related to income (loss) from equity investee decreased by $5.1 million, and related to impairment of investments decreased by $2.7 million in fiscal year 2020 compared to fiscal year 2019.  These decreases were offset by an increase of $8.9 million in the non-cash charges related to the change in our deferred income tax assets, unrealized losses on our foreign currency-denominated credit facilities, and depreciation and amortization expense resulting from the amortization of operating lease right-of-use assets.

[0001375365-20-000064:mdna:131]
Net cash provided by operating activities increased by $178.3 million for fiscal year 2019 as compared to fiscal year 2018. The increase was due primarily to a reduction of net working capital of $160.6 million due to improved working capital management and reduced costs for key components in the second half of fiscal year 2019, higher net income in fiscal year 2019 of $25.8 million, the change in the non-cash charges related to an increase in excess and obsolete inventory of $23.3 million for

[0001375365-20-000064:mdna:132]
aged inventory and $7.2 million for bad debt, partially offset by a reduction of $30.7 million in the non-cash charges related to the change in our deferred income tax assets, primarily as a result of the 2017 Tax Reform Act and a decrease of $8.0 million from the change in deferred revenue compared to prior year, related to the lower growth in services business year-over-year.

[0001375365-20-000064:mdna:133]
Investing Activities

[0001375365-20-000064:mdna:134]
Net cash used in investing activities was $43.6 million, $24.8 million and $25.9 million for the fiscal years 2020, 2019 and 2018, respectively, as we invested in our Green Computing Park in San Jose to expand our capacity and office space we purchased and expanded our Bade Facility in Taiwan and made purchases of property, plant and equipment.

[0001375365-20-000064:mdna:135]
Financing Activities

[0001375365-20-000064:mdna:136]
Net cash used in financing activities decreased by $119.6 million for fiscal year 2020 as compared to fiscal year 2019 primarily due to decreased net repayments of debt of $96.4 million, and cash receipts from exercises of stock options of $28.3 million offset by increased cash payments for withholding taxes from the vesting of restricted stock of $5.2 million. Net cash used in financing activities increased by $45.0 million for fiscal year 2019 as compared to fiscal year 2018 primarily due to increased debt repayments of $43.1 million.

[0001375365-20-000064:mdna:137]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-20-000064:mdna:138]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-20-000064:mdna:139]
Bank of America

[0001375365-20-000064:mdna:140]
2018 Bank of America Credit Facility

[0001375365-20-000064:mdna:141]
In April 2018, as amended in January and June 2019, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility") for up to $250.0 million. In May 2020, we entered into a third amendment to extend the maturity from June 30, 2020 to June 30, 2021, release the real property as a collateral, modify certain payments and covenants provisions, specify that LIBOR cannot be less than 1% for purposes of determining interest rates, and increase the unused line fee from 0.25% per annum to 0.375% per annum. Interest shall accrue at LIBOR plus 2.00% on outstanding borrowings less than $125.0 million and LIBOR plus 2.25% on outstanding borrowings in excess of $125.0 million. As of June 30, 2020, we had no outstanding borrowings and we had a $6.4 million letter of credit outstanding under this facility. Our available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms. In the event of default or if outstanding borrowings are in excess of $220.0 million, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. In addition, we are not permitted to pay any dividends. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-20-000064:mdna:142]
CTBC Bank

[0001375365-20-000064:mdna:143]
2019 CTBC Credit Facility

[0001375365-20-000064:mdna:144]
In June 2019, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans denominated in NTD of up to $50.0 million (the "2019 CTBC Credit Facility") and had an original maturity of June 30, 2020. We have since extended the maturity of the 2019 CTBC Credit Facility to August 31, 2021. During the year ended June 30, 2020, we borrowed and repaid $10.0 million under the revolving line of credit. The total outstanding borrowings under the 2019 CTBC Credit Facility were $23.7 million as of June 30, 2020. The amount available for future borrowing was $26.3 million as of June 30, 2020. The interest rate for these outstanding term loans was 0.45% per annum as of June 30, 2020. Term loans are secured by certain of our assets, including certain property, plant, and equipment. There are no financial covenants under the 2019 CTBC Credit Facility.

[0001375365-20-000064:mdna:145]
2020 CTBC Term Loan Facility

[0001375365-20-000064:mdna:146]
In June 2020, we entered into a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of our Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and are drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. We are required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility, including any expansion. Fees paid to the lender as debt issuance costs were immaterial.  We borrowed $5.7 million in June 2020 with a rate of 0.45% per annum. As of June 30, 2020, the amount outstanding under the 2020 CTBC Term Loan Facility was $5.7 million and the net book value of the property serving as collateral was $10.1 million. We have financial covenants requiring our current ratio, debt service coverage ratio, and financial debt ratio, to be maintained at certain levels. We have been in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-20-000064:mdna:147]
Contractual Obligations

[0001375365-20-000064:mdna:148]
The following table describes our contractual obligations as of June 30, 2020:

[0001375365-20-000064:mdna:149]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating lease obligations | $ | 7,073 |  |  | $ | 9,942 |  |  | $ | 8,530 |  |  | $ | 956 |  |  | $ | 26,501 |  |
| Debt, including interest (1) | 23,740 |  |  | 70 |  |  | 1,675 |  |  | 4,055 |  |  | 29,540 |  |
| Purchase commitments (2) | 192,419 |  |  | 1,181 |  |  | — |  |  | — |  |  | 193,600 |  |
| Total (3) | $ | 223,232 |  |  | $ | 11,193 |  |  | $ | 10,205 |  |  | $ | 5,011 |  |  | $ | 249,641 |  |

[0001375365-20-000064:mdna:150]
__________________________

[0001375365-20-000064:mdna:151]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rates under our 2018 Bank of America Credit Facility, our 2019 CTBC Credit Facility and 2020 CTBC Credit Facility at June 30, 2020. |

[0001375365-20-000064:mdna:152]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. See Part II, Item 8, Note 16, “Commitments and Contingencies” to the consolidated financial statements in this Annual Report for a discussion of purchase commitments. |

[0001375365-20-000064:mdna:153]
| (3) | The table above excludes liabilities for deferred revenue of $203.8 million and unrecognized tax benefits and related interest and penalties accrual of $15.5 million. Deferred revenue represents billed services in advance which include extended warranty, on-site technical support, and software maintenance. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Part II, Item 8, Note 15, “Income Taxes” to the consolidated financial statements in this Annual Report for a discussion of income taxes. |

[0001375365-20-000064:mdna:154]
We expect to fund our remaining contractual obligations from our ongoing operations and existing cash and cash equivalents on hand.

[0001375365-20-000064:mdna:155]
Recent Accounting Pronouncements

[0001375365-20-000064:mdna:156]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report.

[0001375365-20-000064:mdna:157]
Off-Balance Sheet Arrangements

[0001375365-20-000064:mdna:158]
We do not have any off-balance sheet arrangements.
