# SMCI notes — 0001375365-20-000064


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001375365-20-000064:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001375365-20-000064:notes:2]
None


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-20-000064:notes:3]
Organization and Summary of Significant Accounting Policies

[0001375365-20-000064:notes:4]
Organization

[0001375365-20-000064:notes:5]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

[0001375365-20-000064:notes:6]
Basis of Presentation

[0001375365-20-000064:notes:7]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations, and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

[0001375365-20-000064:notes:8]
Use of Estimates

[0001375365-20-000064:notes:9]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to revenue recognition, allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the COVID-19 pandemic on its critical and significant accounting estimates, including an assessment of the collectability of each customer contract as part of the revenue recognition process, assessment of the valuation of accounts receivable, assessment of provision for excess and obsolete inventory and an impairment of long-lived assets.

[0001375365-20-000064:notes:10]
Fair Value of Financial Instruments

[0001375365-20-000064:notes:11]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-20-000064:notes:12]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001375365-20-000064:notes:13]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001375365-20-000064:notes:14]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001375365-20-000064:notes:15]
Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposit and the investment in an auction rate security are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms.

[0001375365-20-000064:notes:16]
Cash and Cash Equivalents

[0001375365-20-000064:notes:17]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months.

[0001375365-20-000064:notes:18]
Restricted Cash and Cash Equivalents

[0001375365-20-000064:notes:19]
Restricted cash is comprised of amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to the Company’s workers’ compensation program. These restricted cash balances have been excluded from the Company's cash and cash equivalents balance.

[0001375365-20-000064:notes:20]
Investments in Auction Rate Securities

[0001375365-20-000064:notes:21]
The Company classifies its investments in auction rate securities ("auction rate securities") as non-current available-for-sale investments. The auction rate securities consist of municipal securities, which are debt securities. The Company uses discounted cash flow to estimate the fair value of any auction rate securities. These auction rate securities are recorded within other assets in the consolidated balance sheets at fair value. Unrealized gains and losses on auction rate securities are included as a component of accumulated other comprehensive (loss) income, net of tax.

[0001375365-20-000064:notes:22]
Inventories

[0001375365-20-000064:notes:23]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based upon the Company's inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-20-000064:notes:24]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-20-000064:notes:25]
Property, Plant and Equipment

[0001375365-20-000064:notes:26]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-20-000064:notes:27]
| Software | 3 to 5 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |

[0001375365-20-000064:notes:28]
Long-Lived Assets

[0001375365-20-000064:notes:29]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge for long-lived assets has been recorded in any of the periods presented.

[0001375365-20-000064:notes:30]
Revenue Recognition

[0001375365-20-000064:notes:31]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-20-000064:notes:32]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customers from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-20-000064:notes:33]
The Company applies judgment in determining the transaction price as the Company may be required to estimate variable consideration when determining the amount of revenue to recognize. As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-20-000064:notes:34]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-20-000064:notes:35]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-20-000064:notes:36]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable

[0001375365-20-000064:notes:37]
through past transactions, the Company applies judgment to estimate the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-20-000064:notes:38]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-20-000064:notes:39]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.

[0001375365-20-000064:notes:40]
Allowances for Doubtful Accounts

[0001375365-20-000064:notes:41]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability and intent to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer concentrations, customer-credit-worthiness, and current economic trends to evaluate the adequacy of the allowance for doubtful accounts. The Company's (recovery of) provision for bad debt was $(3.1) million, $7.1 million, and $(0.1) million in fiscal years 2020, 2019 and 2018, respectively.

[0001375365-20-000064:notes:42]
Cost of Sales

[0001375365-20-000064:notes:43]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or net realizable value and excess and obsolete inventory.

[0001375365-20-000064:notes:44]
Product Warranties

[0001375365-20-000064:notes:45]
The Company offers product warranties typically ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are recorded to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2020, 2019 and 2018, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-20-000064:notes:46]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Balance, beginning of the year | $ | 11,034 |  |  | $ | 9,884 |  |  | $ | 7,721 |  |
| Provision for warranty | 35,962 |  |  | 22,991 |  |  | 20,868 |  |
| Costs utilized | (34,502 | ) |  | (26,281 | ) |  | (19,904 | ) |
| Change in estimated liability for pre-existing warranties | (115 | ) |  | 4,440 |  |  | 1,199 |  |
| Balance, end of the year | $ | 12,379 |  |  | $ | 11,034 |  |  | $ | 9,884 |  |
| Current portion | 9,984 |  |  | 8,661 |  |  | 7,589 |  |
| Non-current portion | $ | 2,395 |  |  | $ | 2,373 |  |  | $ | 2,295 |  |

[0001375365-20-000064:notes:47]
Research and Development

[0001375365-20-000064:notes:48]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for the Company's research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to the Company's research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $2.1 million, $2.8 million, and $6.1 million for the fiscal years ended June 30, 2020, 2019 and 2018, respectively. During the fiscal year ended June 30, 2020, the Company also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-20-000064:notes:49]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-20-000064:notes:50]
Advertising Costs

[0001375365-20-000064:notes:51]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred. Total advertising and promotional expenses were $3.0 million, $2.4 million, and $3.5 million for the fiscal years ended June 30, 2020, 2019 and 2018, respectively.

[0001375365-20-000064:notes:52]
Stock-Based Compensation

[0001375365-20-000064:notes:53]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-20-000064:notes:54]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-20-000064:notes:55]
Leases

[0001375365-20-000064:notes:56]
Recognition of leases for periods after the Company’s adoption of the new leasing standard as of July 1, 2019

[0001375365-20-000064:notes:57]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-20-000064:notes:58]
Operating Leases

[0001375365-20-000064:notes:59]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-20-000064:notes:60]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

[0001375365-20-000064:notes:61]
Finance Leases

[0001375365-20-000064:notes:62]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-20-000064:notes:63]
Recognition of leases for periods prior to the Company’s adoption of the new leasing standard as of July 1, 2019

[0001375365-20-000064:notes:64]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following was true at inception: (a) the present value of minimum lease payments met or exceeded 90% of the fair value of the asset, (b) the lease term was greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contained a bargain purchase option, or (d) title to the property transferred to the Company at the end of the lease. The Company recorded an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets were depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability was accounted for using the effective interest method.

[0001375365-20-000064:notes:65]
Leases that were not classified as capital leases were accounted for as operating leases. Operating lease agreements that had tenant improvement allowances were evaluated for lease incentives. For leases that contained escalating rent payments, the Company recognized rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

[0001375365-20-000064:notes:66]
Income Taxes

[0001375365-20-000064:notes:67]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-20-000064:notes:68]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of

[0001375365-20-000064:notes:69]
being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

[0001375365-20-000064:notes:70]
Variable Interest Entities

[0001375365-20-000064:notes:71]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-20-000064:notes:72]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect these related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-20-000064:notes:73]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each party contributed $0.2 million for a 50% ownership interest of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2020, 2019 and 2018, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's consolidated statements of operations.

[0001375365-20-000064:notes:74]
Foreign Currency Transactions

[0001375365-20-000064:notes:75]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, with the exception of Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in foreign currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the foreign currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the foreign currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations in other expense, net.

[0001375365-20-000064:notes:76]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-20-000064:notes:77]
The Company has an investment in a privately-held company that is accounted for under the equity method  (the "Corporate Venture").  The functional currency of the Corporate Venture is the Chinese Yuan. Adjustments for the Company's share of the effects of foreign currency translation from local currency to U.S. dollars are recorded as increases or decreases to the carrying value of the investment and included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-20-000064:notes:78]
Net Income Per Common Share

[0001375365-20-000064:notes:79]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested RSUs and PRSUs. Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-20-000064:notes:80]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs and PRSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.

[0001375365-20-000064:notes:81]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-20-000064:notes:82]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 84,308 |  |  | $ | 71,918 |  |  | $ | 46,165 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 50,987 |  |  | 49,917 |  |  | 49,345 |  |
| Effect of dilutive securities | 1,851 |  |  | 1,799 |  |  | 2,806 |  |
| Weighted-average diluted shares | 52,838 |  |  | 51,716 |  |  | 52,151 |  |
| Basic net income per common share | $ | 1.65 |  |  | $ | 1.44 |  |  | $ | 0.94 |  |
| Diluted net income per common share | $ | 1.60 |  |  | $ | 1.39 |  |  | $ | 0.89 |  |

[0001375365-20-000064:notes:83]
For the fiscal years ended June 30, 2020, 2019 and 2018, the Company had stock options, RSUs and PRSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 2,208,000, 3,758,000, and 2,221,000 for the fiscal years ended June 30, 2020, 2019 and 2018, respectively.

[0001375365-20-000064:notes:84]
Concentration of Supplier Risk

[0001375365-20-000064:notes:85]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 26.8%, 21.8%, and 26.0% of total purchases for the fiscal years ended June 30, 2020, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 13, "Related Party Transactions,"

[0001375365-20-000064:notes:86]
accounted for 10.1%, 9.2%, and 9.0% of total cost of sales for the fiscal years ended June 30, 2020, 2019 and 2018, respectively.

[0001375365-20-000064:notes:87]
Concentration of Credit Risk

[0001375365-20-000064:notes:88]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales in fiscal years 2020, 2019 and 2018. One customer accounted for 10.1% and 17.0% of accounts receivable, net as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:notes:89]
Accounting Pronouncements Recently Adopted

[0001375365-20-000064:notes:90]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The new lease accounting guidance supersedes the existing guidance. Under the new lease accounting guidance, lessees are required to recognize assets and liabilities on the balance sheet for most leases and provide enhanced disclosures. Leases will continue to be classified as either finance or operating. The Company adopted the new lease accounting guidance on July 1, 2019 using the modified retrospective approach, and as a result did not restate prior comparative periods. The Company elected to apply the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new lease accounting guidance its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease accounting guidance. In connection with the adoption of the new lease accounting guidance, the Company recorded a transition adjustment to recognize ROU assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, on July 1, 2019, primarily related to real estate leases. See Note 12, "Leases," for further details.

[0001375365-20-000064:notes:91]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The Company adopted this guidance on July 1, 2019. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.

[0001375365-20-000064:notes:92]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The Company adopted this guidance on July 1, 2019. The adoption of the guidance did not have an impact on the Company's consolidated financial statements and related disclosures.

[0001375365-20-000064:notes:93]
Accounting Pronouncements Not Yet Adopted

[0001375365-20-000064:notes:94]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The adoption of the guidance is expected to result in the presentation of allowances for credit losses separately from the amortized cost of financial instruments that are not classified as available-for-sale debt securities.  The adoption is also expected to change the presentation of the Company’s available-for-sale debt securities to include the amortized cost and the allowance for credit losses parenthetically. The adoption will have an immaterial effect on the allowance for credit losses for trade receivables and beginning retained earnings and will have an immaterial effect on the Company’s financial statement disclosures.

[0001375365-20-000064:notes:95]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The adoption of the new guidance will require the Company to present, on a prospective basis, narrative information regarding the uncertainty of the fair value measurements from the use of unobservable

[0001375365-20-000064:notes:96]
inputs used in recurring fair value measurements categorized in Level 3 of the fair value hierarchy, to disclose the amount of gains and losses recognized in other comprehensive income for the period for financial instruments categorized within Level 3 of the fair value hierarchy, and quantitative information for the significant unobservable inputs used to develop the Level 3 fair value measurements. The adoption of the new guidance will also allow the Company to discontinue the presentation of information regarding transfers between Level 1 and Level 2 of the fair value hierarchy. As at June 30, 2020 the only financial instrument of the Company for which the recurring fair value measurements are categorized in Level 3 of the fair value hierarchy is its investment in an auction rate security.

[0001375365-20-000064:notes:97]
In August 2018, the FASB issued authoritative guidance , Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, an entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires an entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company will adopt the new guidance on a prospective basis for any new hosting arrangement entered into after July 1, 2020 and does not expect the adoption of the guidance to have a material impact on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-20-000064:notes:98]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its consolidated financial statements.

[0001375365-20-000064:notes:99]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-20-000064:notes:100]
Fair Value Disclosure

[0001375365-20-000064:notes:101]
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2  in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of June 30, 2020 and 2019. See Note 1, "Organization and Summary of Significant Accounting Policies," for a discussion of the Company’s policies regarding the fair value hierarchy. The Company used discounted cash flows to estimate the fair value of the auction rate security as of June 30, 2020 and 2019. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-20-000064:notes:102]
Financial Assets and Liabilities Measured on a Recurring Basis

[0001375365-20-000064:notes:103]
The following table sets forth the Company’s financial instruments as of June 30, 2020 and 2019, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-20-000064:notes:104]
| June 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,163 |  |
| Certificates of deposit (2) | — |  |  | 836 |  |  | — |  |  | 836 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,163 |  |  | $ | 836 |  |  | $ | 1,571 |  |  | $ | 3,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| June 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,162 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,162 |  |
| Certificates of deposit (2) | — |  |  | 1,285 |  |  | — |  |  | 1,285 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,162 |  |  | $ | 1,285 |  |  | $ | 1,571 |  |  | $ | 4,018 |  |

[0001375365-20-000064:notes:105]
(1) $0.4 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:notes:106]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0 in certificates of deposit are included in prepaid expenses and other assets, and $0.3 million and $1.1 million in certificates of deposit are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:notes:107]
(3) As of June 30, 2020, the current portion of the performance awards liability of $1.5 million is included in accrued liabilities and the noncurrent portion of $0.6 million is included in other long-term liabilities in the consolidated balance sheets. There was no such liability outstanding as of June 30, 2019.

[0001375365-20-000064:notes:108]
The performance awards liability consists of one-time employee performance bonuses for the Company's Chief Executive Officer and two members of the Board that are payable when specified market and performance conditions are achieved. The Company estimated the fair value of these performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of June 30, 2020 are as follows:

[0001375365-20-000064:notes:109]
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $28.39 |  | 1.25 - 2.00 years |  | 0.16% |  | 53.75% |  | — |

[0001375365-20-000064:notes:110]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for fiscal years 2020 and 2019.

[0001375365-20-000064:notes:111]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in fiscal years 2020 and 2019.

[0001375365-20-000064:notes:112]
The following is a summary of the Company’s investment in an auction rate security as of June 30, 2020 and 2019 (in thousands):

[0001375365-20-000064:notes:113]
|  | June 30, 2020 and 2019 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-20-000064:notes:114]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2020 and 2019, total debt of $29.4 million and $23.6 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-20-000064:notes:115]
Other Financial Assets - Investments into Non-Marketable Equity Securities

[0001375365-20-000064:notes:116]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $0.1 million and $0.9 million as of June 30, 2020 and 2019, respectively. The Company accounts for these investments at cost minus impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the years ended June 30, 2020 and 2019, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during fiscal year 2020. During fiscal year 2019, the Company recorded impairment charges of $2.7 million for its non-marketable equity securities which had an initial cost basis of $2.7 million as it was determined the carrying value of the investments were not recoverable. During fiscal year 2018, the Company did not record any other-than-temporary impairments on financial assets required to be measured at fair value on a non-recurring basis.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-20-000064:notes:117]
Revenue

[0001375365-20-000064:notes:118]
Disaggregation of Revenue

[0001375365-20-000064:notes:119]
The Company disaggregates revenue by type of product, by geographical market, and by products sold to indirect sales channel partners or direct customers and original equipment manufacturers ("OEMs") that depict the nature, amount, and timing of revenue and cash flows. Service revenues are not a significant component of total revenue and are aggregated within the respective categories.

[0001375365-20-000064:notes:120]
The following is a summary of net sales by product type (in thousands):

[0001375365-20-000064:notes:121]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Server and storage systems | $ | 2,620,754 |  |  | $ | 2,858,644 |  |  | $ | 2,663,580 |  |
| Subsystems and accessories | 718,527 |  |  | 641,716 |  |  | 696,912 |  |
| Total | $ | 3,339,281 |  |  | $ | 3,500,360 |  |  | $ | 3,360,492 |  |

[0001375365-20-000064:notes:122]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

[0001375365-20-000064:notes:123]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-20-000064:notes:124]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the fiscal years ended June 30, 2020, 2019 and 2018, of net sales by geographic region (in thousands):

[0001375365-20-000064:notes:125]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 1,957,329 |  |  | $ | 2,032,948 |  |  | $ | 1,902,106 |  |
| Asia | 650,652 |  |  | 712,211 |  |  | 762,701 |  |
| Europe | 598,558 |  |  | 611,014 |  |  | 547,507 |  |
| Other | 132,742 |  |  | 144,187 |  |  | 148,178 |  |
| Total | $ | 3,339,281 |  |  | $ | 3,500,360 |  |  | $ | 3,360,492 |  |

[0001375365-20-000064:notes:126]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for fiscal years 2020, 2019 and 2018 (in thousands):

[0001375365-20-000064:notes:127]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Indirect sales channel | $ | 1,771,614 |  |  | $ | 1,376,633 |  |  | $ | 1,395,841 |  |
| Direct customers and OEMs | 1,567,667 |  |  | 2,123,727 |  |  | 1,964,651 |  |
| Total net sales | $ | 3,339,281 |  |  | $ | 3,500,360 |  |  | $ | 3,360,492 |  |

[0001375365-20-000064:notes:128]
Contract Balances

[0001375365-20-000064:notes:129]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

[0001375365-20-000064:notes:130]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s consolidated financial statements.

[0001375365-20-000064:notes:131]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during fiscal year 2020, which was included in the opening deferred revenue balance as of June 30, 2019, was $91.9 million.

[0001375365-20-000064:notes:132]
Deferred revenue decreased during the fiscal year ended June 30, 2020 because the recognition of revenue from contracts entered into in prior periods exceeded the value of the transaction price allocated for service contracts obligations during the current period.

[0001375365-20-000064:notes:133]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-20-000064:notes:134]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of June 30, 2020 was approximately $203.8 million. The Company expects to recognize approximately 52% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-20-000064:notes:135]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-20-000064:notes:136]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Such contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

[0001375365-20-000064:notes:137]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-20-000064:notes:138]
Accounts Receivable Allowances

[0001375365-20-000064:notes:139]
The Company has established an allowance for doubtful accounts. The allowance for doubtful accounts is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2020, 2019 and 2018 consisted of the following (in thousands):

[0001375365-20-000064:notes:140]
|  | BeginningBalance |  | Charged toCost andExpenses (Recovered), net |  | Write-offs |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2020 | $ | 8,906 |  |  | $ | (3,081 | ) |  | $ | (1,239 | ) |  | $ | 4,586 |  |
| Year ended June 30, 2019 | 1,945 |  |  | 7,058 |  |  | (97 | ) |  | 8,906 |  |
| Year ended June 30, 2018 | 2,370 |  |  | (96 | ) |  | (329 | ) |  | 1,945 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001375365-20-000064:notes:141]
Inventories as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:142]
|  | June 30, |
|  | 2020 |  | 2019 |
| Finished goods | $ | 656,817 |  |  | $ | 492,387 |  |
| Work in process | 38,146 |  |  | 43,598 |  |
| Purchased parts and raw materials | 156,535 |  |  | 134,203 |  |
| Total inventories | $ | 851,498 |  |  | $ | 670,188 |  |

[0001375365-20-000064:notes:143]
During fiscal years 2020, 2019 and 2018, the Company recorded a provision for excess and obsolete inventory to cost of sales totaling $22.6 million, $28.5 million and $9.4 million, respectively, excluding a (recovery) provision for adjusting the cost of certain inventories to net realizable value of $(4.2) million and $4.4 million in fiscal years 2020 and 2019, respectively. The adjustment for lower of cost or net realizable value and lower of cost or market was not material in fiscal year 2018. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-20-000064:notes:144]
Property, Plant, and Equipment

[0001375365-20-000064:notes:145]
Property, plant and equipment as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:146]
|  | June 30, |
|  | 2020 |  | 2019 |
| Buildings | $ | 86,930 |  |  | $ | 86,136 |  |
| Land | 75,251 |  |  | 74,926 |  |
| Machinery and equipment | 85,381 |  |  | 79,946 |  |
| Buildings construction in progress (1) | 46,311 |  |  | 14,189 |  |
| Building and leasehold improvements | 24,517 |  |  | 22,307 |  |
| Software | 20,597 |  |  | 18,415 |  |
| Furniture and fixtures | 21,544 |  |  | 20,193 |  |
|  | 360,531 |  |  | 316,112 |  |
| Accumulated depreciation and amortization | (126,746 | ) |  | (108,775 | ) |
| Property, plant and equipment, net | $ | 233,785 |  |  | $ | 207,337 |  |

[0001375365-20-000064:notes:147]
__________________________

[0001375365-20-000064:notes:148]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California, and, to a lesser extent, in Taiwan.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001375365-20-000064:notes:149]
Prepaid Expenses and Other Assets

[0001375365-20-000064:notes:150]
Prepaid expenses and other current assets as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:151]
|  | June 30, |
|  | 2020 |  | 2019 |
| Receivables from vendors (1) | $ | 94,859 |  |  | $ | 83,050 |  |
| Prepaid income tax | 14,323 |  |  | 607 |  |
| Prepaid expenses | 7,075 |  |  | 7,269 |  |
| Deferred service costs | 4,161 |  |  | 3,374 |  |
| Restricted cash | 250 |  |  | 11,673 |  |
| Others | 6,317 |  |  | 3,822 |  |
| Total prepaid expenses and other current assets | $ | 126,985 |  |  | $ | 109,795 |  |

[0001375365-20-000064:notes:152]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $83.8 million and $82.0 million as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:notes:153]
Other assets as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:154]
|  | June 30, |
|  | 2020 |  | 2019 |
| Operating lease right-of-use asset | $ | 23,784 |  |  | $ | — |  |
| Deferred service costs, non-current | 4,632 |  |  | 3,572 |  |
| Restricted cash, non-current | 1,607 |  |  | 2,303 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 1,201 |  |  | 686 |  |
| Non-marketable equity securities | 128 |  |  | 878 |  |
| Prepaid expense, non-current | 1,576 |  |  | 1,649 |  |
| Total other assets | $ | 34,499 |  |  | $ | 10,659 |  |

[0001375365-20-000064:notes:155]
Cash, cash equivalents and restricted cash as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:156]
|  | June 30, |
|  | 2020 |  | 2019 |
| Cash and cash equivalents | $ | 210,533 |  |  | $ | 248,164 |  |
| Restricted cash included in prepaid expenses and other current assets | 250 |  |  | 11,673 |  |
| Restricted cash included in other assets | 1,607 |  |  | 2,303 |  |
| Total cash, cash equivalents and restricted cash | $ | 212,390 |  |  | $ | 262,140 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001375365-20-000064:notes:157]
Investment in a Corporate Venture

[0001375365-20-000064:notes:158]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-20-000064:notes:159]
The Company recorded a deferred gain related to the contribution of certain technology rights of $7.0 million in the third fiscal quarter of 2017. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of June 30, 2020 and 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $1.0 million and $3.0 million, respectively, in other long-term liabilities in the Company’s consolidated balance sheets.

[0001375365-20-000064:notes:160]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several related entities. The Company is working with the Corporate Venture management to ensure that any future related parties transactions with the Corporate Venture are in accordance with the new restrictions and does not believe that the equity investment carrying value is impacted as of June 30, 2020. The Company did not recognize any impairment in the years ended June 30, 2020, 2019 and 2018.

[0001375365-20-000064:notes:161]
As of June 30, 2020 and June 30, 2019, the Company's equity investment in the Corporate Venture was $2.7 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's consolidated balance sheet.

[0001375365-20-000064:notes:162]
The Company's share of income (losses), net of taxes, of the Corporate Venture net of taxes were $2.4 million, $(2.7) million, and $(3.6) million for the fiscal years ended June 30, 2020, June 30, 2019, and June 30, 2018, respectively.

[0001375365-20-000064:notes:163]
Additionally, the Company sold products worth $61.9 million, $52.2 million, $21.7 million to the Corporate Venture in the fiscal years 2020, 2019, 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture in the amounts of $3.0 million and $1.7 million as of June 30, 2020 and June 30, 2019 have been eliminated and have reduced the carrying value of the Company's investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $7.8 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of June 30, 2020 and 2019, respectively, in its consolidated balance sheets.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001375365-20-000064:notes:164]
Accrued Liabilities

[0001375365-20-000064:notes:165]
Accrued liabilities as of June 30, 2019 and 2018 consisted of the following (in thousands):

[0001375365-20-000064:notes:166]
|  | June 30, |
|  | 2020 |  | 2019 |
| Accrued payroll and related expenses | $ | 33,577 |  |  | $ | 25,552 |  |
| Contract manufacturers liability | 36,249 |  |  | 25,308 |  |
| Accrued legal liabilities | 18,114 |  |  | — |  |
| Accrued professional fees | 5,661 |  |  | 11,756 |  |
| Customer deposits | 9,942 |  |  | 11,133 |  |
| Accrued warranty costs | 9,984 |  |  | 8,661 |  |
| Operating lease liability | 6,310 |  |  | — |  |
| Accrued cooperative marketing expenses | 5,925 |  |  | 5,830 |  |
| Others | 29,639 |  |  | 26,438 |  |
| Total accrued liabilities | $ | 155,401 |  |  | $ | 114,678 |  |

[0001375365-20-000064:notes:167]
Performance Awards Liability

[0001375365-20-000064:notes:168]
In March 2020, the Company’s Board of Directors (the “Board”) approved $25.3 million of special performance bonuses to employees, which included $8.0 million paid in cash during the fourth quarter of fiscal year 2020 and $17.3 million paid in cash upon the occurrence of the average closing price for the Company's common stock equaling or exceeding $21.39 for any period of 10 consecutive trading days following March 26, 2020. The entire amount of the special performance bonuses to employees was paid in the fourth quarter of fiscal year 2020.

[0001375365-20-000064:notes:169]
The Board also approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments will be earned when specified market and performance conditions are achieved.

[0001375365-20-000064:notes:170]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved and the date that the payment is made. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved and the date that the payment is made.

[0001375365-20-000064:notes:171]
Performance bonuses for a senior executive and two members of the Board are earned based on achieving a specified target average closing price for the Company’s common stock over the specified period as determined by the Board at the grant

[0001375365-20-000064:notes:172]
dates and continuous services through the payment dates. A senior executive earned an aggregate cash payment of $0.1 million when the target average closing price was met in the fourth quarter of fiscal year 2020. The two members of the Board can earn aggregate cash payments of $0.3 million in two tranches if the target average closing price reaches $31.61 for the first tranche and $32.99 per share for the second tranche. These awards expire in two equal amounts at September 30, 2021 and June 30, 2022 for the two Board members' awards.

[0001375365-20-000064:notes:173]
The Company accounts for the outstanding performance bonuses as liabilities and estimates fair value of payable amounts using a Monte-Carlo simulation model. The awards are re-measured at each period end with changes in fair value recorded in the Company’s consolidated statement of operations in cost of sales and operating expenses. The cumulative recorded expense at each period end is trued-up to the expected payable amount vested through the period end. The requisite service periods over which expenses are recognized are derived from the Monte-Carlo model for all performance awards, except for the first 50% of the Chief Executive Officer’s award that includes a performance condition. The Company estimates if it is probable that the performance condition will be met through the expiration date of this award. If at the measurement date it is determined to be probable, the Company estimates the requisite period as the longer of the service period derived by the Monte-Carlo model and the implicit service period when the Company expects to make adequate progress in remediating its material weaknesses in its internal control over financial reporting, as reported by the Company's Audit Committee. If it is determined to not be probable, then the Company will reverse any previously recognized expense for this award in the period when it is no longer probable that the performance condition will be achieved.

[0001375365-20-000064:notes:174]
As of June 30, 2020, the Company's outstanding balance related to performance bonuses was $2.1 million of which $1.5 million is recorded within accrued liabilities and $0.6 million is recorded within other long-term liabilities on the Company's consolidated balance sheet. An unrecognized compensation expense of $3.3 million will be recorded over the remaining service periods from 0.19 years to 1.18 years. The unrecognized expense and remaining service periods will be remeasured each reporting period.


## us-gaap:DebtDisclosureTextBlock

[0001375365-20-000064:notes:175]
Short-term and Long-term Debt

[0001375365-20-000064:notes:176]
Short-term and long-term debt obligations as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:177]
|  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| Term loans: |  |  |  |
| CTBC Bank, due August 31, 2020 | 23,704 |  |  | 22,531 |  |
| CTBC Bank, due June 4, 2030 | 5,697 |  |  | — |  |
| Total term loans | 29,401 |  |  | 22,531 |  |
| Total debt | 29,401 |  |  | 23,647 |  |
| Short-term debt and current portion of long-term debt | 23,704 |  |  | 23,647 |  |
| Debt, Non-current | $ | 5,697 |  |  | $ | — |  |

[0001375365-20-000064:notes:178]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-20-000064:notes:179]
Bank of America

[0001375365-20-000064:notes:180]
2018 Bank of America Credit Facility

[0001375365-20-000064:notes:181]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and on

[0001375365-20-000064:notes:182]
January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020. On May 12, 2020, the Company paid a fee of $0.7 million and entered into a third amendment of the 2018 Bank of America Credit Facility that extended the maturity of the credit facility to June 30, 2021 and changed certain terms of the original agreement. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Under the original terms, interest accrued at the LIBOR rate plus 2.75% per annum, while under the third amendment, interest shall accrue at LIBOR rate plus 2.00% on outstanding borrowings less than $125.0 million and LIBOR rate plus 2.25% on outstanding borrowings in excess of $125.0 million. Under the terms of the third amendment of the 2018 Bank of America Credit Facility, in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the third amendment released the real property of Super Micro Computer as a collateral. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain Fixed Charge Coverage Ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-20-000064:notes:183]
As of June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of June 30, 2020 and 2019 were 3.0% per annum and 4.5% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. and in October 2019, the letter of credit amount was increased to $6.4 million. The balance of debt issuance costs outstanding were $0.6 million and $0.3 million as of June 30, 2020 and 2019, respectively.  The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of June 30, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-20-000064:notes:184]
CTBC Bank

[0001375365-20-000064:notes:185]
2019 CTBC Credit Facility

[0001375365-20-000064:notes:186]
In January 2018, the Company entered into a credit agreement with China Trust and Bank Corp ("CTBC Bank") that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-20-000064:notes:187]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with

[0001375365-20-000064:notes:188]
an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the 2019 CTBC Credit Facility. On June 30, 2020, the maturity date of the 2019 CTBC credit facility was extended to August 31, 2020. On August 24, 2020, the maturity of the 2019 CTBC credit facility was further extended to August 31, 2021.

[0001375365-20-000064:notes:189]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.7 million and $22.5 million at June 30, 2020 and 2019, respectively. As of June 30, 2020 and 2019, the Company did not have any outstanding borrowings under the 2019 CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.45% per annum as of June 30, 2020 and 0.93% per annum as of June 30, 2019. At June 30, 2020, the amount available for future borrowing under the 2019 CTBC Credit Facility was $26.3 million. As of June 30, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.4 million.

[0001375365-20-000064:notes:190]
2020 CTBC Term Loan Facility

[0001375365-20-000064:notes:191]
In June 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

[0001375365-20-000064:notes:192]
The Company borrowed $5.7 million in June 2020 with an interest rate of 0.45% per annum. As of June 30, 2020, the amount outstanding under the 2020 CTBC Term Loan Facility was $5.7 million and the net book value of the property serving as collateral was $10.1 million. As of June 30, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-20-000064:notes:193]
Principal payments on short-term and long-term debt obligations are due as follows (in thousands):

[0001375365-20-000064:notes:194]
| Fiscal Year: | Principal Payments |
| 2021 | $ | 23,704 |  |
| 2022 | — |  |
| 2023 | 68 |  |
| 2024 | 814 |  |
| 2025 | 814 |  |
| 2026 and thereafter | 4,001 |  |
| Total short-term and long-term debt | $ | 29,401 |  |


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001375365-20-000064:notes:195]
Other Long-term Liabilities

[0001375365-20-000064:notes:196]
Other long-term liabilities as of June 30, 2020 and 2019 consisted of the following (in thousands):

[0001375365-20-000064:notes:197]
|  | June 30, |
|  | 2020 |  | 2019 |
| Operating lease liability, non-current | $ | 18,102 |  |  | $ | — |  |
| Accrued unrecognized tax benefits including related interest and penalties | 15,496 |  |  | 20,102 |  |
| Accrued warranty costs, non-current | 2,395 |  |  | 2,373 |  |
| Others | 6,002 |  |  | 3,708 |  |
| Total other long-term liabilities | $ | 41,995 |  |  | $ | 26,183 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-20-000064:notes:198]
Leases
Upon adoption of the new lease accounting guidance, the Company recognized operating lease liabilities of approximately $15.2 million based on the present value of the remaining minimum rental payments using an incremental borrowing rate of approximately 4%. The Company also recognized corresponding operating lease ROU assets of approximately $14.8 million. The difference relates to adjustments made to operating lease ROU assets for prepaid rent and deferred rent that existed as of the date of adoption. These operating lease ROU assets relate to offices, warehouses and other premises leased under non-cancelable operating leases expiring through June 2026 and vehicles and certain equipment leased under non-cancelable operating leases expiring through August 2023.

[0001375365-20-000064:notes:199]
Operating lease expense recognized and supplemental cash flow information related to operating leases for the years ended June 30, 2020 and 2019 were as follows (in thousands):

[0001375365-20-000064:notes:200]
|  |  | Years Ended June 30, |
|  |  | 2020 |
| Operating lease expense (including expense for lease agreements with related parties of $1,421 and $0 for the years ended June 30, 2020 and 2019, respectively) |  | $ | 6,993 |  |
| Cash payments for operating leases (including payments to related parties of $1,443 and $0 for the years ended June 30, 2020 and 2019, respectively) |  | $ | 6,411 |  |
| New operating lease assets obtained in exchange for operating lease liabilities |  | $ | 15,229 |  |

[0001375365-20-000064:notes:201]
During the years ended June 30, 2020 and 2019, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the years ended June 30, 2020, 2019 and 2018 were $1.3 million, $0.0 million and $0.0 million respectively.

[0001375365-20-000064:notes:202]
As of June 30, 2020, the weighted average remaining lease term for operating leases was 4.6 and the weighted average discount rate was 3.5%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of June 30, 2020 were as follows (in thousands):

[0001375365-20-000064:notes:203]
| Fiscal Year: |  | Maturities of operating leases |
| 2021 |  | $ | 7,073 |  |
| 2022 |  | 5,696 |  |
| 2023 |  | 4,246 |  |
| 2024 |  | 4,221 |  |
| 2025 |  | 4,309 |  |
| 2026 and beyond |  | 956 |  |
| Total future lease payments |  | $ | 26,501 |  |
| Less: Imputed interest |  | (2,089 | ) |
| Present value of operating lease liabilities |  | $ | 24,412 |  |

[0001375365-20-000064:notes:204]
As of June 30, 2019, prior to the adoption of the new lease accounting guidance, future minimum payments under operating leases having initial or remaining non-cancelable lease terms in excess of one year were as follows (in thousands):

[0001375365-20-000064:notes:205]
| Fiscal Year: |  | Minimum lease payments |
| 2020 |  | $ | 6,582 |  |
| 2021 |  | 3,831 |  |
| 2022 |  | 2,439 |  |
| 2023 |  | 1,175 |  |
| 2024 |  | 1,166 |  |
| 2025 and beyond |  | 2,279 |  |
| Total minimum lease payments |  | $ | 17,472 |  |

[0001375365-20-000064:notes:206]
As of June 30, 2020, commitments under short-term lease and financing lease arrangements were immaterial. As of June 30, 2020, operating and financing leases that have not yet commenced were immaterial.

[0001375365-20-000064:notes:207]
The Company has entered into lease agreements with related parties.  See Note 13, "Related Party Transactions," for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-20-000064:notes:208]
Related Party Transactions

[0001375365-20-000064:notes:209]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of June 30, 2020. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of June 30, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang or Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware's capital stock.

[0001375365-20-000064:notes:210]
Dealings with Ablecom

[0001375365-20-000064:notes:211]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-20-000064:notes:212]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.5%, 96.3% and 97.0% of the chassis included in the products sold by the Company during fiscal years 2020, 2019 and 2018 respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-20-000064:notes:213]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-20-000064:notes:214]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $23.2 million and $31.0 million at June 30, 2020 and 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-20-000064:notes:215]
Dealings with Compuware

[0001375365-20-000064:notes:216]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-20-000064:notes:217]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-20-000064:notes:218]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-20-000064:notes:219]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware

[0001375365-20-000064:notes:220]
uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-20-000064:notes:221]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $45.7 million and $70.6 million at June 30, 2020 and 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-20-000064:notes:222]
The Company’s results from transactions with Ablecom and Compuware for each of the fiscal years ended June 30, 2020, 2019, and 2018 are as follows (in thousands):

[0001375365-20-000064:notes:223]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |
| Purchases (1) | $ | 160,084 |  |  | $ | 145,273 |  |  | $ | 152,332 |  |
| Compuware |  |  |  |  |  |
| Net sales | $ | 23,867 |  |  | $ | 17,651 |  |  | $ | 46,921 |  |
| Purchases (1) | 131,763 |  |  | 139,579 |  |  | 119,548 |  |

[0001375365-20-000064:notes:224]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-20-000064:notes:225]
The Company's net sales to Ablecom were not material for the fiscal years ended June 30, 2020, 2019, and 2018.

[0001375365-20-000064:notes:226]
The Company had the following balances related to transactions with Ablecom and Compuware as of June 30, 2020 and 2019 (in thousands):

[0001375365-20-000064:notes:227]
|  | June 30, |
|  | 2020 |  | 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,379 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 40,056 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 513 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | 14,323 |  |  | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 46,518 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 186 |  |  | — |  |

[0001375365-20-000064:notes:228]
(1) Other receivables include receivables from vendors.

[0001375365-20-000064:notes:229]
(2) Includes current portion of operating lease liabilities.

[0001375365-20-000064:notes:230]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-20-000064:notes:231]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 8, "Investment in a Corporate Venture" for a discussion of the investment and the transactions that took place during the fiscal years 2020, 2019, and 2018.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-20-000064:notes:232]
Stock-based Compensation and Stockholders’ Equity

[0001375365-20-000064:notes:233]
Equity Incentive Plan

[0001375365-20-000064:notes:234]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "2020 Plan"). The maximum number of shares available under the 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the 2020 Plan.

[0001375365-20-000064:notes:235]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-20-000064:notes:236]
As of June 30, 2020, the Company had 5,249,198 authorized shares available for future issuance under the 2020 Plan.

[0001375365-20-000064:notes:237]
Determining Fair Value

[0001375365-20-000064:notes:238]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-20-000064:notes:239]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience.

[0001375365-20-000064:notes:240]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-20-000064:notes:241]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-20-000064:notes:242]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-20-000064:notes:243]
The fair value of stock option grants for the fiscal years ended June 30, 2020, 2019 and 2018 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-20-000064:notes:244]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Risk-free interest rate | 0.47% - 1.72% |  |  | 2.32% - 2.97% |  |  | 1.92% - 2.86% |  |
| Expected term | 6.27 years |  |  | 6.05 years |  |  | 5.82 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 49.61% - 50.46% |  |  | 47.34% - 50.28% |  |  | 45.32% - 48.07% |  |
| Weighted-average fair value | $ | 9.59 |  |  | $ | 9.25 |  |  | $ | 10.98 |  |

[0001375365-20-000064:notes:245]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2020, 2019 and 2018 (in thousands):

[0001375365-20-000064:notes:246]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Cost of sales | $ | 1,504 |  |  | $ | 1,663 |  |  | $ | 1,812 |  |
| Research and development | 12,202 |  |  | 12,981 |  |  | 13,893 |  |
| Sales and marketing | 1,680 |  |  | 1,805 |  |  | 1,980 |  |
| General and administrative | 4,803 |  |  | 4,735 |  |  | 6,971 |  |
| Stock-based compensation expense before taxes | 20,189 |  |  | 21,184 |  |  | 24,656 |  |
| Income tax impact | (6,814 | ) |  | (4,349 | ) |  | (6,902 | ) |
| Stock-based compensation expense, net | $ | 13,375 |  |  | $ | 16,835 |  |  | $ | 17,754 |  |

[0001375365-20-000064:notes:247]
As of June 30, 2020, $5.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.19 years, $31.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.52 years and $0.5 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.90 year.

[0001375365-20-000064:notes:248]
Stock Option Activity

[0001375365-20-000064:notes:249]
The following table summarizes stock option activity during the fiscal years ended June 30, 2020, 2019 and 2018 under all plans:

[0001375365-20-000064:notes:250]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2017 |  | 8,375,659 |  |  | $ | 15.88 |  |  |  |  |  |
| Granted |  | 489,705 |  |  | $ | 23.58 |  |  |  |  |  |
| Exercised |  | (267,970 | ) |  | $ | 11.36 |  |  |  |  |  |
| Forfeited/Cancelled |  | (296,256 | ) |  | $ | 15.36 |  |  |  |  |  |
| Balance as of June 30, 2018 |  | 8,301,138 |  |  | $ | 16.50 |  |  |  |  |  |
| Granted |  | 434,320 |  |  | $ | 18.58 |  |  |  |  |  |
| Forfeited/Cancelled |  | (1,360,823 | ) |  | $ | 8.94 |  |  |  |  |  |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |  |  |
| Granted |  | 273,260 |  |  | $ | 19.61 |  |  |  |  |  |
| Exercised |  | (1,812,000 | ) |  | $ | 15.74 |  |  |  |  |  |
| Forfeited/Cancelled |  | (456,127 | ) |  | $ | 11.97 |  |  |  |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  | 4.07 |  | $ | 50,245 |  |
| Options vested and exercisable at June 30, 2020 |  | 4,723,734 |  |  | $ | 19.25 |  |  | 3.46 |  | $ | 44,932 |  |

[0001375365-20-000064:notes:251]
The total pretax intrinsic value of options exercised during the fiscal year ended June 30, 2020, 2019 and 2018 was $19.3 million, $0 and $4.0 million, respectively. Additional information regarding options outstanding as of June 30, 2020, is as follows:

[0001375365-20-000064:notes:252]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $9.24 - $11.76 |  | 613,268 |  |  | 2.35 |  | $ | 10.26 |  |  | 613,268 |  |  | $ | 10.26 |  |
| 12.37 - 13.67 |  | 554,260 |  |  | 2.62 |  | $ | 13.01 |  |  | 489,132 |  |  | $ | 13.01 |  |
| 14.23 - 15.22 |  | 583,989 |  |  | 2.84 |  | $ | 14.65 |  |  | 559,995 |  |  | $ | 14.64 |  |
| 15.54 - 17.60 |  | 588,616 |  |  | 3.69 |  | $ | 17.29 |  |  | 454,312 |  |  | $ | 17.20 |  |
| 17.69 - 18.93 |  | 776,839 |  |  | 2.65 |  | $ | 18.51 |  |  | 776,839 |  |  | $ | 18.51 |  |
| 20.37 - 22.05 |  | 546,617 |  |  | 5.61 |  | $ | 20.93 |  |  | 385,163 |  |  | $ | 20.98 |  |
| 22.10 - 25.44 |  | 786,440 |  |  | 6.40 |  | $ | 23.98 |  |  | 562,458 |  |  | $ | 24.51 |  |
| 26.60 - 28.45 |  | 652,579 |  |  | 5.66 |  | $ | 27.15 |  |  | 606,617 |  |  | $ | 27.09 |  |
| 28.71 - 37.06 |  | 249,160 |  |  | 4.76 |  | $ | 34.28 |  |  | 247,950 |  |  | $ | 34.31 |  |
| 39.19 |  | 28,000 |  |  | 4.62 |  | $ | 39.19 |  |  | 28,000 |  |  | $ | 39.19 |  |
| $9.24 - $39.19 |  | 5,379,768 |  |  | 4.07 |  | $ | 19.38 |  |  | 4,723,734 |  |  | $ | 19.25 |  |

[0001375365-20-000064:notes:253]
RSU and PRSU Activity

[0001375365-20-000064:notes:254]
In January 2015, the Company began to grant RSUs to employees. The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are typically service based share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting.

[0001375365-20-000064:notes:255]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. The first award was a one-year PRSU and the second award was a two-year PRSU.

[0001375365-20-000064:notes:256]
The one-year PRSUs were earned based on the Company’s performance as it related to a revenue growth metric and a minimum non-GAAP operating margin metric during the fiscal year ended June 30, 2018 with eligibility up to 200% of the targeted number of units based on revenue growth if the minimum non-GAAP operating margin was achieved. Upon achievement of the performance metrics, 50% of the PRSUs vested at June 30, 2018 while the remainder vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors determined that the Company achieved the revenue and non-GAAP operating margin metrics for the fiscal year ended June 30, 2018 at a level that entitled the Chief Executive Officer to 200% of the originally targeted number of shares subject to the one-year PRSU. 50% of the PRSUs so earned were vested as of June 30, 2018, and an additional 40% of the PRSUs vested during the eight quarters ended June 30, 2020, in accordance with the terms of the grant.

[0001375365-20-000064:notes:257]
The two-year PRSUs are earned based on the Company’s performance for the average non-GAAP operating margin metric for the two fiscal years ended June 30, 2019 with eligibility up to 100% of the targeted number of units. If the performance metrics were met, 50% of the PRSUs would have vested at June 30, 2019 while the remainder would have been vested in equal amounts over the following ten quarters if the Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Board determined that the Company did not achieve the required performance metrics for the two-year PRSUs and none of the two-year PRSUs vested.

[0001375365-20-000064:notes:258]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units would vest in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019.

[0001375365-20-000064:notes:259]
The following table summarizes RSUs and PRSUs activity during the fiscal years ended June 30, 2020 and 2019 under all plans:

[0001375365-20-000064:notes:260]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUs Outstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2017 |  | 1,226,357 |  |  | $ | 26.11 |  |  | — |  |  |  |  |
| Granted |  | 986,680 |  |  | $ | 21.90 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Released (2) |  | (572,789 | ) |  | $ | 26.34 |  |  | — |  |  |  |  |
| Forfeited |  | (159,643 | ) |  | $ | 24.90 |  |  | — |  |  |  |  |
| Balance as of June 30, 2018 |  | 1,480,605 |  |  | $ | 23.34 |  |  | 120,000 |  |  |  | $ | 27.10 |  |
| Granted |  | 1,086,911 |  |  | $ | 18.37 |  |  | — |  |  |  |  |
| Released (2) |  | (549,886 | ) |  | $ | 24.87 |  |  | — |  |  |  |  |
| Forfeited |  | (144,528 | ) |  | $ | 20.25 |  |  | — |  |  |  |  |
| Balance as of June 30, 2019 |  | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  |  |  | $ | 27.10 |  |
| Granted |  | 943,650 |  |  | $ | 20.45 |  |  | 30,000 |  |  |  | $ | 20.37 |  |
| Released (2) |  | (871,274 | ) |  | $ | 20.97 |  |  | (108,000 | ) |  |  | $ | 27.10 |  |
| Forfeited |  | (177,451 | ) |  | $ | 19.49 |  |  | — |  |  |  |  |
| Balance as of June 30, 2020 |  | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  |  |  | $ | 22.29 |  |

[0001375365-20-000064:notes:261]
| (1) | Reflects the number of PRSUs that have been earned based on the achievement of performance metrics. |

[0001375365-20-000064:notes:262]
| (2) | The number of shares released excludes 172,857 RSUs that were vested but not released in fiscal year 2019. The number of vested but not released RSUs for fiscal year 2020 was not material. The number of shares released also excludes 24,000 and 60,000 PRSUs that were vested but not released in fiscal years 2019 and 2018, respectively. These vested RSUs and PRSUs were primarily released in fiscal year 2020 and included in fiscal year 2020 number upon the effectiveness of the Company's registration statement on Form S-8. |

[0001375365-20-000064:notes:263]
The total pretax intrinsic value of RSUs and PRSUs vested was $18.9 million, $14.3 million and $16.8 million for the fiscal years ended June 30, 2020, 2019 and 2018, respectively. In fiscal years 2020, 2019 and 2018, the Company withheld 331,648, 175,044 and 199,715 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes from the vesting and release of 979,274, 549,886 and 572,789 RSUs and PRSUs, respectively, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to tax authorities were $8.2 million, $3.1 million and $4.5 million for the fiscal years ended June 30, 2020, 2019 and 2018, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-20-000064:notes:264]
The components of income before income tax provision for the fiscal years ended June 30, 2020, 2019 and 2018 are as follows (in thousands):

[0001375365-20-000064:notes:265]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 35,701 |  |  | $ | 45,126 |  |  | $ | 39,394 |  |
| Foreign | 49,127 |  |  | 44,397 |  |  | 48,821 |  |
| Income before income tax provision | $ | 84,828 |  |  | $ | 89,523 |  |  | $ | 88,215 |  |

[0001375365-20-000064:notes:266]
The income tax provision for the fiscal years ended June 30, 2020, 2019 and 2018, consists of the following (in thousands):

[0001375365-20-000064:notes:267]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| Federal | $ | 4,568 |  |  | $ | 12,308 |  |  | $ | 11,090 |  |
| State | 1,727 |  |  | 2,917 |  |  | 815 |  |
| Foreign | 10,399 |  |  | 16,531 |  |  | 12,984 |  |
|  | 16,694 |  |  | 31,756 |  |  | 24,889 |  |
| Deferred: |  |  |  |  |  |
| Federal | (10,108 | ) |  | (13,078 | ) |  | 14,304 |  |
| State | (1,621 | ) |  | (2,888 | ) |  | 265 |  |
| Foreign | (2,043 | ) |  | (906 | ) |  | (1,015 | ) |
|  | (13,772 | ) |  | (16,872 | ) |  | 13,554 |  |
| Income tax provision | $ | 2,922 |  |  | $ | 14,884 |  |  | $ | 38,443 |  |

[0001375365-20-000064:notes:268]
The Company’s net deferred tax assets as of June 30, 2020 and 2019 consist of the following (in thousands):

[0001375365-20-000064:notes:269]
|  | June 30, |
|  | 2020 |  | 2019 |
| Research and development credits | $ | 24,304 |  |  | $ | 20,858 |  |
| Deferred revenue | 20,354 |  |  | 18,963 |  |
| Inventory valuation | 13,946 |  |  | 11,856 |  |
| Capitalized research and development costs | 7,509 |  |  | — |  |
| Stock-based compensation | 4,075 |  |  | 6,080 |  |
| Lease obligations | 3,632 |  |  | — |  |
| Accrued vacation and bonus | 3,281 |  |  | 2,681 |  |
| Prepaid and accrued expenses | 2,560 |  |  | — |  |
| Warranty accrual | 2,051 |  |  | 1,948 |  |
| Bad debt and other reserves | 1,917 |  |  | 1,283 |  |
| Marketing fund accrual | 548 |  |  | 554 |  |
| Other | 3,652 |  |  | 3,276 |  |
| Total deferred income tax assets | 87,829 |  |  | 67,499 |  |
| Deferred tax liabilities-depreciation and other | (4,428 | ) |  | (5,406 | ) |
| Right of use asset | (3,612 | ) |  | — |  |
| Valuation allowance | (24,891 | ) |  | (20,967 | ) |
| Deferred income tax assets, net | $ | 54,898 |  |  | $ | 41,126 |  |

[0001375365-20-000064:notes:270]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2020, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception state research and development tax credits that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2020, the gross excess credits of $30.8 million, or net of federal tax benefit of $24.3 million, are subject to a full valuation allowance. At June 30, 2019, the gross excess credits of $26.4 million, or net of federal tax benefit of $20.9 million, are subject to a full valuation allowance. The change in valuation allowance is $3.9 million and $4.7 million for the fiscal years ended June 30, 2020 and 2019, respectively. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2020 and 2019 was $54.9 million and $41.1 million, respectively.

[0001375365-20-000064:notes:271]
In December 2017, the U.S. federal government enacted the 2017 Tax Reform Act. The 2017 Tax Reform Act reduced the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a one-time transition tax on foreign earnings of U.S. subsidiaries that were not previously subject to U.S. income tax. Under U.S. GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. As a result, the Company has completed its analysis and has recorded a one-time $12.9 million, net write down of its U.S. deferred tax assets and liabilities resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and a one-time transition tax of $2.8 million, in its income tax provision for the fiscal year ended June 30, 2018.

[0001375365-20-000064:notes:272]
The 2017 Tax Reform Act also creates a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) that must be included currently in the gross income of a CFC’s U.S. stockholder starting in the tax year that begins after 2017. GILTI does not have material impact on the Company's income tax provision.

[0001375365-20-000064:notes:273]
Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into a company’s measurement of its deferred taxes. The Company's selection of an accounting policy with respect to the GILTI tax rules is to treat GILTI tax as a current period expense under the period cost method.

[0001375365-20-000064:notes:274]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. The Company previously asserted that all of its foreign undistributed earnings

[0001375365-20-000064:notes:275]
were indefinitely reinvested. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for Netherlands. The Company may repatriate foreign earnings from Netherlands which are previously taxed income as a result of the 2017 Tax Reform Act. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-20-000064:notes:276]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. As a result of this restructuring, the Company estimated approximately $1.9 million additional tax benefit from foreign derived intangible income in fiscal year 2020 as compared to fiscal year 2019.

[0001375365-20-000064:notes:277]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted. The CARES Act provides temporary relief from certain aspects of the 2017 Tax Reform Act that imposed limitations on the utilization of certain losses, interest expense deductions and alternative minimum tax credits and made a technical correction to the 2017 Tax Reform Act related to the depreciable life of qualified improvement property. The CARES Act did not have a material impact on the Company.

[0001375365-20-000064:notes:278]
The following is a reconciliation for the fiscal years ended June 30, 2020, 2019 and 2018, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-20-000064:notes:279]
|  |  | Years Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Income tax provision at statutory rate |  | 21.0 | % |  | 21.0 | % |  | 28.1 | % |
| State income tax, net of federal tax benefit |  | — |  |  | 0.5 |  |  | (0.1 | ) |
| Foreign rate differential |  | — |  |  | 1.1 |  |  | (6.0 | ) |
| Research and development tax credit |  | (13.1 | ) |  | (9.5 | ) |  | (8.7 | ) |
| Uncertain tax positions, net of (settlement) with Tax Authorities |  | (2.3 | ) |  | 4.1 |  |  | 6.3 |  |
| Foreign derived intangible / Subpart F income inclusion |  | (3.8 | ) |  | (2.1 | ) |  | 0.7 |  |
| Stock-based compensation |  | (2.8 | ) |  | 2.1 |  |  | 1.8 |  |
| Non deductible penalty on SEC matter |  | 4.4 |  |  | — |  |  | — |  |
| Provision to return true-up |  | (1.1 | ) |  | (1.6 | ) |  | 1.5 |  |
| Tax reform related charge |  | — |  |  | — |  |  | 17.9 |  |
| Qualified production activity deduction |  | — |  |  | — |  |  | (1.3 | ) |
| Other, net |  | 1.1 |  |  | 1.0 |  |  | 3.4 |  |
| Effective tax rate |  | 3.4 | % |  | 16.6 | % |  | 43.6 | % |

[0001375365-20-000064:notes:280]
As of June 30, 2020, the Company had state research and development tax credit carryforwards of $40.1 million. The state research and development tax credits will carryforward indefinitely to offset future state income taxes.

[0001375365-20-000064:notes:281]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-20-000064:notes:282]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2017 | 19,217 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,864 |  |
| For prior years’ tax positions | — |  |
| Gross decreases: |  |
| Decreases due to a lapse of the statute of limitations | (964 | ) |
| Balance at June 30, 2018 | 25,117 |  |
| Gross increases: |  |
| For current year’s tax positions | 7,789 |  |
| For prior years’ tax positions | — |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (1,504 | ) |
| Decreases due to lapse of statute of limitations | (3,354 | ) |
| Balance at June 30, 2019 | 28,048 |  |
| Gross increases: |  |
| For current year’s tax positions | 8,769 |  |
| For prior years’ tax positions | 505 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (7,632 | ) |
| Decreases due to lapse of statute of limitations | (2,484 | ) |
| Balance at June 30, 2020 | $ | 27,206 |  |

[0001375365-20-000064:notes:283]
________________________

[0001375365-20-000064:notes:284]
*excludes interest, penalties, federal benefit of state reserves

[0001375365-20-000064:notes:285]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $13.4 million and $18.6 million as of June 30, 2020 and 2019, respectively.

[0001375365-20-000064:notes:286]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the income tax provision in the consolidated statements of operations. As of June 30, 2020 and 2019, the Company had accrued $2.1 million and $1.5 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively.

[0001375365-20-000064:notes:287]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in February 2020. In February 2020, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2019 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of these adjustments on the income statement was offset by the release of previously unrecognized tax benefits related to the fiscal years audited in the periods in which the proposed adjustments were accepted.

[0001375365-20-000064:notes:288]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-20-000064:notes:289]
The federal statute of limitations remains open in general for tax years ended June 30, 2017 through 2020. Various states statute of limitations remain open in general for tax years ended June 30, 2016 through 2020. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2016 through 2020. It is

[0001375365-20-000064:notes:290]
reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.2 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-20-000064:notes:291]
Commitments and Contingencies

[0001375365-20-000064:notes:292]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which is calendared for September 23, 2020.

[0001375365-20-000064:notes:293]
The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

[0001375365-20-000064:notes:294]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order.  The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company also agreed to pay a civil money penalty of $17.5 million. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer will pay the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. As of and for the year ended June 30, 2020, the Company recorded a liability of $17.5 million for its SEC settlement which is included in accrued liabilities and general and administrative expenses in the consolidated financial statements. The Company’s Chief Executive Officer’s payment of $2,122,000 to the Company is a contingent gain and will be recorded when it is realized.

[0001375365-20-000064:notes:295]
Other legal proceedings and indemnifications

[0001375365-20-000064:notes:296]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of June 30, 2020 and any prior periods.

[0001375365-20-000064:notes:297]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-20-000064:notes:298]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-20-000064:notes:299]
Purchase Commitments - The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2020, these remaining noncancelable commitments were $193.6 million, including $68.9 million for related parties.

[0001375365-20-000064:notes:300]
Standby Letter of Credit - In October 2019, Bank of America increased the value of a previously issued standby letter of credit to a beneficiary from $3.2 million to $6.4 million to facilitate ongoing operations of the Company. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.

[0001375365-20-000064:notes:301]
Lease Commitments - See Note 12, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-20-000064:notes:302]
Retirement Plans

[0001375365-20-000064:notes:303]
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2020, 2019 and 2018.

[0001375365-20-000064:notes:304]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. The Company is required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the fiscal years ended June 30, 2020, 2019 and 2018, the Company’s matching contribution was $0.6 million, $0.5 million, and $0.5 million, respectively.

[0001375365-20-000064:notes:305]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2020, 2019 and 2018, the Company’s contribution was $2.0 million, $1.6 million and $1.5 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-20-000064:notes:306]
Segment Reporting

[0001375365-20-000064:notes:307]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-20-000064:notes:308]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-20-000064:notes:309]
|  | June 30, |
|  | 2020 |  | 2019 |
| Long-lived assets: |  |  |  |
| United States | $ | 178,812 |  |  | $ | 162,835 |  |
| Asia | 51,605 |  |  | 41,915 |  |
| Europe | 3,368 |  |  | 2,587 |  |
|  | $ | 233,785 |  |  | $ | 207,337 |  |

[0001375365-20-000064:notes:310]
The Company’s revenue is presented on a disaggregated basis in Note 3, “Revenue” by type of product, by geographical market, and by products sold through its indirect sales channel or to its direct customers and OEMs.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001375365-20-000064:notes:311]
Selected Quarterly Financial Data (Unaudited)

[0001375365-20-000064:notes:312]
The following table presents the Company's unaudited consolidated quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company's quarterly results of operations for these periods are not necessarily indicative of future results of operations.

[0001375365-20-000064:notes:313]
|  | Three Months Ended |
|  | Jun. 302020 | Mar. 312020 | Dec. 312019 | Sep. 302019 | Jun. 302019 | Mar. 312019 | Dec. 312018 | Sep. 302018 |
|  | (In thousands, except per share data) |
| Net sales | $ | 896,126 |  | $ | 772,408 |  | $ | 870,943 |  | $ | 799,804 |  | $ | 854,234 |  | $ | 743,499 |  | $ | 931,509 |  | $ | 971,118 |  |
| Gross profit | 123,517 |  | 133,360 |  | 138,404 |  | 130,929 |  | 132,034 |  | 112,327 |  | 127,922 |  | 123,239 |  |
| Net income | 18,450 |  | 15,807 |  | 23,706 |  | 26,345 |  | 23,710 |  | 10,646 |  | 18,220 |  | 19,342 |  |
| Net income per common share: |  |  |  |  |  |  |  |  |
| Basic | 0.35 |  | 0.31 |  | 0.47 |  | 0.52 |  | 0.47 |  | 0.21 |  | 0.37 |  | 0.39 |  |
| Diluted | 0.34 |  | 0.29 |  | 0.46 |  | 0.51 |  | 0.46 |  | 0.21 |  | 0.36 |  | 0.37 |  |


## us-gaap:SubsequentEventsTextBlock

[0001375365-20-000064:notes:314]
Subsequent Events

[0001375365-20-000064:notes:315]
On August 9, 2020, the Company's Board of Directors approved a share repurchase program to repurchase shares of common stock for up to $30.0 million at prevailing prices in the open market. The share repurchase program is effective until December 31, 2020 or until the maximum amount of common stock is repurchased. 385,000 shares of common stock were repurchased through the date these consolidated financial statements were issued.
