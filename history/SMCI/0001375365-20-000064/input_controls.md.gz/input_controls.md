# SMCI 10-K controls and the auditor's report


## auditors_report

[0001375365-20-000064:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-20-000064:auditors_report:2]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-20-000064:auditors_report:3]
Opinion on the Financial Statements

[0001375365-20-000064:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Super Micro Computer, Inc. and subsidiaries (the "Company") as of June 30,2020 and 2019, the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended June 30, 2020, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2020, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-20-000064:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) and our report dated August 28, 2020, expressed an adverse opinion on the Company’s internal control over financial reporting because of a material weakness.

[0001375365-20-000064:auditors_report:6]
Basis for Opinion

[0001375365-20-000064:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-20-000064:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001375365-20-000064:auditors_report:9]
Critical Audit Matters

[0001375365-20-000064:auditors_report:10]
The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that were communicated or required to be communicated to the audit committee and that (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001375365-20-000064:auditors_report:11]
Variable Interest Entities and Related Party Transactions - Refer to Notes 1 and 13  to the financial statements

[0001375365-20-000064:auditors_report:12]
Critical Audit Matter Description

[0001375365-20-000064:auditors_report:13]
The Company has a variety of business relationships defined by various agreements with Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"). Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company.  Purchases from Ablecom and Compuware were $160.1 million and $131.8 million, respectively, for the fiscal year ended June 30, 2020. Net sales to Compuware as a distributor were $23.9 million for the fiscal year ended June 30, 2020.

[0001375365-20-000064:auditors_report:14]
The Company concluded that Ablecom and Compuware are variable interest entities (VIEs) and that it is not the primary beneficiary as it does not have the power to direct the activities that are most significant to Ablecom and Compuware. Therefore, the Company does not consolidate Ablecom and Compuware. The Company considered its explicit arrangements with Ablecom and Compuware, including its supplier arrangements, and as a result of the substantial related party relationships between the Company, Ablecom and Compuware, the Company also considered whether any implicit arrangements exist that

[0001375365-20-000064:auditors_report:15]
48

[0001375365-20-000064:auditors_report:16]
would cause the Company to protect those related parties’ interests from suffering losses. The Company determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-20-000064:auditors_report:17]
We identified management’s conclusion that it is not the primary beneficiary as a critical audit matter because of the judgments necessary for management to determine whether any explicit and implicit arrangements exist that would cause the Company to protect those related parties’ interest from absorbing losses. This required extensive audit effort due to the complexity and variety of related party relationships with Ablecom and Compuware and required a high degree of auditor judgment when performing audit procedures to audit the Company’s conclusion that it is not the primary beneficiary.

[0001375365-20-000064:auditors_report:18]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-20-000064:auditors_report:19]
Our audit procedures related to management’s conclusion that it is not the primary beneficiary included the following, among others:

[0001375365-20-000064:auditors_report:20]
| • | We evaluated and tested whether the arrangements are accurately considered and that such arrangements have been included in the consideration by comparing those related parties we had identified during our audit procedures for proper inclusion in the Company’s evaluation and performed inspection of source documents on a sample basis. |

[0001375365-20-000064:auditors_report:21]
| • | We tested management’s assertion that the Company does not direct the operations of, or is required to absorb and record losses incurred by Ablecom and Compuware by analyzing the gross margin for contract manufacturing transactions with Ablecom and Compuware in comparison to unrelated third parties to determine if there is an indication of off-market terms, assessing leasing arrangements by performing independent market data searches to assess if such leases are within the normal range of prices for Ablecom and Compuware and recalculating days sales outstanding as well as days purchases outstanding and compared to other contract manufacturers to assess comparability of payment terms. |

[0001375365-20-000064:auditors_report:22]
| • | We obtained confirmations directly from Ablecom and Compuware regarding the nature of their business relationships with the Company, the extent of power, if any, held by the Company over the most significant activities of Ablecom and Compuware’s businesses, and the existence of any implicit arrangements that may have a bearing on the Company’s ability to have power over Ablecom and Compuware. |

[0001375365-20-000064:auditors_report:23]
Inventories - Excess and Obsolescence Reserve - Refer to Notes 1 and 5 to the financial statements

[0001375365-20-000064:auditors_report:24]
Critical Audit Matter Description

[0001375365-20-000064:auditors_report:25]
The Company’s inventories are stated at lower of cost, using weighted average cost method, or net realizable value. The Company evaluates inventory for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors.  The provision for excess and obsolete inventory for the fiscal year ended June 30, 2020, was $22.6 million.

[0001375365-20-000064:auditors_report:26]
We identified the excess and obsolescence reserve as a critical audit matter because of judgments made by management in recording the manual adjustments that management may make to estimate the excess and obsolescence reserve.  This required a high degree of auditor judgment and an increased extent of effort when performing audit procedures to evaluate the methodology and the reasonableness of the excess and obsolescence reserve.

[0001375365-20-000064:auditors_report:27]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-20-000064:auditors_report:28]
Our audit procedures related to the Company’s excess and obsolescence reserve included the following procedures, among others:

[0001375365-20-000064:auditors_report:29]
| • | We gained an understanding and evaluated the Company’s methodology for determining inventory that is excess or obsolete and the key assumptions and judgments made as part of the process, including manual adjustments. |

[0001375365-20-000064:auditors_report:30]
| • | We evaluated management’s estimate by performing corroborative inquiry with the Company’s program managers, sales personnel, and/or buyers, and inspected correspondence and other communications between the Company’s operations team and customers. |

[0001375365-20-000064:auditors_report:31]
| • | As a result of the Company’s material weakness identified in IT general controls, we increased the extent of testing on reports derived from the Company’s systems and applications. |

[0001375365-20-000064:auditors_report:32]
49

[0001375365-20-000064:auditors_report:33]
/s/ Deloitte & Touche LLP

[0001375365-20-000064:auditors_report:34]
San Jose, California

[0001375365-20-000064:auditors_report:35]
August 28, 2020

[0001375365-20-000064:auditors_report:36]
We have served as the Company's auditor since fiscal 2003.

[0001375365-20-000064:auditors_report:37]
50

[0001375365-20-000064:auditors_report:38]
SUPER MICRO COMPUTER, INC.


## item_9a

[0001375365-20-000064:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-20-000064:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001375365-20-000064:item_9a:3]
Under the supervision, and with the participation, of our management, including our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of June 30, 2020. Based on this evaluation, our CEO and CFO have concluded that our disclosure controls and procedures were not effective as of June 30, 2020 because of a material weakness in our internal control over financial reporting, as further described below.

[0001375365-20-000064:item_9a:4]
Notwithstanding the material weakness, management believes that the consolidated financial statements and related financial information included in this Annual Report on Form 10-K present fairly, in all material respects, our financial condition, results of operations and cash flows as of and for the periods presented in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”).

[0001375365-20-000064:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001375365-20-000064:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f).

[0001375365-20-000064:item_9a:7]
Internal control over financial reporting is a process designed by, or under the supervision of, our CEO and CFO to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our consolidated financial statements for external purposes in accordance with U.S. GAAP. Management’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets, (ii) provide reasonable assurance that transactions are appropriately recorded to permit preparation of financial statements in accordance with U.S. GAAP and that our receipts and expenditures are made only in accordance with authorizations of management, acting under authority delegated to them by the Board, and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on our financial statements.

[0001375365-20-000064:item_9a:8]
Management, including our CEO and CFO, assessed our internal control over financial reporting as of June 30, 2020. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in its Internal Control - Integrated Framework (2013) (the “COSO Framework”). Based on this assessment, management has determined that we did not maintain effective internal control over financial reporting as of June 30, 2020 because of the material weakness described below.

[0001375365-20-000064:item_9a:9]
A material weakness in internal controls is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. Because of its inherent limitations, even appropriate internal control over financial reporting may not prevent or detect misstatements.

[0001375365-20-000064:item_9a:10]
Information Technology (“IT”) General Controls

[0001375365-20-000064:item_9a:11]
We identified deficiencies related to IT general controls that aggregated to a material weakness. The following were contributing factors to the material weakness in IT general controls:

[0001375365-20-000064:item_9a:12]
| • | We have authorized certain IT users with broad access to all parts of our primary accounting system without adequate monitoring or recording of how they used that access. In addition, access control deficiencies and change management deficiencies were noted on other systems relevant to financial reporting. Some of our internally-developed systems relevant to financial reporting lack system tracking capabilities to monitor access changes or application changes. In some cases, IT general controls were not designed effectively, and in others, were designed effectively but did not operate effectively or for a sufficient period of time. Business process controls that depend on the affected information systems, or that depend on data or financial reports generated from the affected information |

[0001375365-20-000064:item_9a:13]
systems to be accurate and complete, could be adversely affected, although we have identified no instances of any adverse effect due to these deficiencies.

[0001375365-20-000064:item_9a:14]
The effectiveness of our internal control over financial reporting as of June 30, 2020 has been audited by Deloitte & Touche LLP, our independent registered public accounting firm, as stated in its report that is included herein.

[0001375365-20-000064:item_9a:15]
Remediation Plan

[0001375365-20-000064:item_9a:16]
We have remediated the material weaknesses related to each of the five COSO components of internal control (Control Environment; Risk Assessment; Control Activities; Information & Communication; Monitoring of Controls) and revenue recognition accounting controls by completing our remediation plan, as previously disclosed in our Annual Report on Form 10-K for the year ended June 30, 2019.

[0001375365-20-000064:item_9a:17]
Our management is committed to remediating identified control deficiencies (including both those that rise to the level of a material weakness and those that do not), fostering continuous improvement in our internal controls and enhancing our overall internal controls environment. Our management believes that the actions below will remediate the material weakness we have identified and strengthen our internal control over financial reporting. As we continue to evaluate and work to improve our internal control over financial reporting, we may take additional or different measures to address control deficiencies with the overall objective to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our consolidated financial statements through an effective system of internal control over financial reporting.

[0001375365-20-000064:item_9a:18]
To date, we have taken the following actions related to the material weakness that, as of June 30, 2020, had not yet been fully implemented or had not been in place for a sufficient period of time to demonstrate that they were having their desired effect:

[0001375365-20-000064:item_9a:19]
| • | Re-designed the logical access roles associated with our primary ERP application and re-provisioned those roles to enforce segregation of duties and align user access commensurate with their business process role and job responsibilities; |

[0001375365-20-000064:item_9a:20]
| • | Implemented a third-party application to facilitate improved processes and controls related to provisioning privileged access roles and the monitoring of those roles; and |

[0001375365-20-000064:item_9a:21]
| • | For one of our boundary applications (fulfillment and warehouse management), implemented a new program change management control. |

[0001375365-20-000064:item_9a:22]
Our management believes that meaningful progress has been made on the remaining remediation efforts. Management regards successful completion of our remaining remediation actions as an important priority. The remaining remediation activities include:

[0001375365-20-000064:item_9a:23]
| • | Strengthening access controls related to boundary systems; |

[0001375365-20-000064:item_9a:24]
| • | Strengthening provisioning of privileged access roles; |

[0001375365-20-000064:item_9a:25]
| • | Monitoring instances in which individuals are granted broad access; and |

[0001375365-20-000064:item_9a:26]
| • | Implementing new change management controls related to boundary systems. |

[0001375365-20-000064:item_9a:27]
Changes in Internal Control over Financial Reporting

[0001375365-20-000064:item_9a:28]
Other than the remediation efforts described above, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the three months ended June 30, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-20-000064:item_9a:29]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-20-000064:item_9a:30]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-20-000064:item_9a:31]
Opinion on Internal Control over Financial Reporting

[0001375365-20-000064:item_9a:32]
We have audited the internal control over financial reporting of Super Micro Computer, Inc. and subsidiaries (the “Company”) as of June 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, because of the effect of the material weakness identified below on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of June 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0001375365-20-000064:item_9a:33]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended June 30, 2020, of the Company and our report dated August 28, 2020, expressed an unqualified opinion on those financial statements.

[0001375365-20-000064:item_9a:34]
Basis for Opinion

[0001375365-20-000064:item_9a:35]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-20-000064:item_9a:36]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-20-000064:item_9a:37]
Definition and Limitations of Internal Control over Financial Reporting

[0001375365-20-000064:item_9a:38]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-20-000064:item_9a:39]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-20-000064:item_9a:40]
Material Weakness

[0001375365-20-000064:item_9a:41]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company’s annual or interim financial statements will not be prevented or detected on a timely basis. The following material weakness has been identified and included in management's assessment:

[0001375365-20-000064:item_9a:42]
Information Technology (“IT”) General Controls

[0001375365-20-000064:item_9a:43]
The Company identified deficiencies related to IT general controls that aggregated to a material weakness. The following were contributing factors to the material weakness in IT general controls:

[0001375365-20-000064:item_9a:44]
| • | The Company authorized certain IT users with broad access to all parts of the primary accounting system without adequate monitoring or recording of how they used that access. In addition, access control deficiencies and change management deficiencies were noted on other systems relevant to financial reporting. Some of the Company’s |

[0001375365-20-000064:item_9a:45]
internally-developed systems relevant to financial reporting lack system tracking capabilities to monitor access changes or application changes. In some cases IT general controls were not designed effectively, and in others, were designed effectively but did not operate effectively or for a sufficient period of time. Business process controls that depend on the affected information systems, or that depend on data or financial reports generated from the affected information systems to be accurate and complete, could be adversely affected, although the Company has identified no instances of any adverse effect due to these deficiencies.

[0001375365-20-000064:item_9a:46]
This material weakness was considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements as of and for the year ended June 30, 2020, of the Company, and this report does not affect our report on such financial statements.

[0001375365-20-000064:item_9a:47]
/s/ Deloitte & Touche LLP

[0001375365-20-000064:item_9a:48]
San Jose, California

[0001375365-20-000064:item_9a:49]
August 28, 2020
