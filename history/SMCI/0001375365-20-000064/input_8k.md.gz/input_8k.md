# SMCI 8-K — 0001375365-20-000057 filed 2020-08-11

## item codes, every 8-K on or before 2020-08-31

- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2020-08-31

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-20-000057:8k_2_02:1]
EX-99.1
2
exhibit99120200811.htm
EXHIBIT 99.1

[0001375365-20-000057:8k_2_02:2]
Exhibit

[0001375365-20-000057:8k_2_02:3]
Exhibit 99.1

[0001375365-20-000057:8k_2_02:4]
Supermicro Announces Fourth Quarter and Full Year Fiscal Year 2020

[0001375365-20-000057:8k_2_02:5]
Financial Results and Stock Repurchase Authorization

[0001375365-20-000057:8k_2_02:6]
SAN JOSE, Calif. -- August 11, 2020 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced fourth quarter and full-year financial results for fiscal year 2020 ended June 30, 2020.

[0001375365-20-000057:8k_2_02:7]
Fourth Quarter of Fiscal Year 2020 Highlights

[0001375365-20-000057:8k_2_02:8]
| • | Net sales of $896 million versus $772 million in the third quarter of fiscal year 2020 and $854 million in the same quarter of last year. |

[0001375365-20-000057:8k_2_02:9]
| • | Gross margin of 13.8% versus 17.3% in the third quarter of fiscal year 2020 and 15.5% in the same quarter of last year. |

[0001375365-20-000057:8k_2_02:10]
| • | Net income of $18 million versus $16 million in the third quarter of fiscal year 2020 and $24 million in the same quarter of last year. |

[0001375365-20-000057:8k_2_02:11]
| • | Diluted net income per common share of $0.34 versus $0.29 in the third quarter of fiscal year 2020 and $0.46 in the same quarter of last year. |

[0001375365-20-000057:8k_2_02:12]
| • | Non-GAAP diluted net income per common share of $0.68 versus $0.84 in the third quarter of fiscal year 2020 and $0.69 in the same quarter of last year. |

[0001375365-20-000057:8k_2_02:13]
| • | Cash flow used in operations of $96 million and capital expenditures of $9 million. |

[0001375365-20-000057:8k_2_02:14]
Non-GAAP gross margin for the fourth quarter of fiscal year 2020 was 14.0%, which adds back stock-based compensation expense of $0.4 million, one-time employee performance bonuses of $1.2 million, and certain other expenses. Non-GAAP diluted net income per common share for the fourth quarter of fiscal year 2020 was $0.68, which adds back stock-based

[0001375365-20-000057:8k_2_02:15]
compensation expense of $5.4 million, one-time employee performance bonuses of $17.4 million, controls remediation costs of $1.0 million and other expenses of $0.7 million, less tax effects of $5.1 million.

[0001375365-20-000057:8k_2_02:16]
As of June 30, 2020, total cash, cash equivalents and restricted cash was $212 million and bank debt was $29 million.

[0001375365-20-000057:8k_2_02:17]
Fiscal Year 2020 Summary

[0001375365-20-000057:8k_2_02:18]
Net sales for the fiscal year ended June 30, 2020, were $3.34 billion versus $3.50 billion for the fiscal year ended June 30, 2019. Net income for fiscal year 2020 was $84 million, or $1.60 per diluted share, versus $72 million, or $1.39 per diluted share, for fiscal year 2019. Non-GAAP net income for the fiscal year 2020 was $150 million, or $2.77 per diluted share, versus $134 million, or $2.51 per diluted share, for fiscal year 2019. Non-GAAP net income for the fiscal year 2020 adds back stock-based compensation expense of $20.2 million, one-time employee performance bonuses of $27.7 million, legal settlement costs of $17.5 million, controls remediation costs of $13.9 million, and other expenses of $0.7 million, less tax effects of $14.0 million.

[0001375365-20-000057:8k_2_02:19]
Business Outlook and Management Commentary

[0001375365-20-000057:8k_2_02:20]
The Company expects net sales of $720 million to $800 million, GAAP net income per diluted share of $0.03 to $0.27 and non-GAAP net income per diluted share of $0.10 to $0.35 for the first quarter of fiscal year 2021 ending September 30, 2020. The company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 18% and a fully diluted share count of 56.3 million shares. The outlook for Q1 of fiscal year 2021 GAAP net income per diluted share includes approximately $5.0 million in expected stock-based compensation expense, one-time employee performance bonuses and controls remediation expenses, and other expense that are excluded from non-GAAP net income per diluted share.

[0001375365-20-000057:8k_2_02:21]
"Our 5% year-over-year Q4 revenue growth in a very dynamic business environment demonstrates our continuing market engagement in Edge applications and with internet data center customers, both of which grew double-digits year-on-year,” said Charles Liang, Chairman and Chief Executive Officer. “We also delivered Q4 non-GAAP EPS that was relatively stable year-on-year despite elevated costs resulting from the impact of COVID-19 on our operations. While our Q1 outlook reflects continued pressures from unprecedented market developments, we are very encouraged as we look to the future, as the digital world continues to progress, evolve, and grow. We are using this period of disruption as an opportunity to invest in long-term growth and optimize our workforce and strategy. A key strategic action we are taking is shifting a greater portion of our

[0001375365-20-000057:8k_2_02:22]
operations and R&D to our Taiwan campus, which will result in lower costs. We remain committed to re-accelerating our revenue growth and resuming our long history of market share gain.”

[0001375365-20-000057:8k_2_02:23]
Share Repurchase Authorization

[0001375365-20-000057:8k_2_02:24]
The Company also announced today that, its Board of Directors has authorized a stock repurchase program pursuant to which the Company may repurchase up to $30 million of its common stock.  The stock repurchase program is effective until December 31, 2020 or until the maximum amount of common stock is repurchased.

[0001375365-20-000057:8k_2_02:25]
“By implementing this stock repurchase program, we can utilize our cash on hand to increase stockholder value while maintaining sufficient cash resources to fund our operations.  The stock repurchase program reflects our ongoing commitment to improving the value of our common stock,” said Charles Liang, Chairman and CEO of the Company.

[0001375365-20-000057:8k_2_02:26]
Stock repurchases may be made from time to time at prevailing prices in the open market, including pursuant to a Rule 10b5-1 plan. There can be no assurance of how many shares will be repurchased, and the repurchase program may be suspended for periods or discontinued at any time. The timing and amount of any shares repurchased will be determined based on an evaluation of market conditions and other factors. Share repurchases will be funded with cash on hand.

[0001375365-20-000057:8k_2_02:27]
The Company had approximately 52,436,981 shares of common stock outstanding on August 10, 2020.

[0001375365-20-000057:8k_2_02:28]
Conference Call and Webcast Information

[0001375365-20-000057:8k_2_02:29]
The Company will hold a phone conference to answer questions from institutional investors and financial analysts beginning at 2:00 p.m. Pacific Time (PT) on August 11, 2020.

[0001375365-20-000057:8k_2_02:30]
The conference call can be accessed by registering online at:

[0001375365-20-000057:8k_2_02:31]
http://www.directeventreg.com/registration/event/1269132

[0001375365-20-000057:8k_2_02:32]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes. Registration is open up to the time of the live call, but to ensure connection for the entire call, it is recommended that participants register at least 10 minutes before the start of the call.

[0001375365-20-000057:8k_2_02:33]
The webcast can be accessed by registering online at:

[0001375365-20-000057:8k_2_02:34]
https://event.on24.com/wcc/r/2520942/CE280B9580467B7EEFD5180716B005EC

[0001375365-20-000057:8k_2_02:35]
A replay of the webcast will be available shortly after the call for one year at ir.supermicro.com.

[0001375365-20-000057:8k_2_02:36]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-20-000057:8k_2_02:37]
Use of Non-GAAP Financial Measures

[0001375365-20-000057:8k_2_02:38]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expense, one-time employee performance bonuses and other expenses. Non-GAAP operating expenses discussed in this press release adds back stock-based compensation expense, legal settlement costs, one-time employee performance bonuses, other expenses, and controls remediation. Non-GAAP income from operations discussed in this press release adds back stock-based compensation expense, legal settlement costs, one-time employee performance bonuses, other expenses and controls remediation. Non-GAAP diluted net income and non-GAAP net income per common share discussed in this press release adds back stock-based compensation expense, one-time employee performance bonuses, legal settlement costs, other expenses, controls remediation, impairment of investment, and less the related tax effects of the applicable items. Management presents non-GAAP financial measures

[0001375365-20-000057:8k_2_02:39]
because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-20-000057:8k_2_02:40]
Financial Statements are Preliminary

[0001375365-20-000057:8k_2_02:41]
As the Company has not yet finished its year-end annual close procedures, and the audit of its fiscal year 2020 consolidated financial statements is not complete, the anticipated financial information presented in this press release is preliminary, subject to final year-end closing adjustments, and may change materially. The information presented above has not been audited by the Company’s independent accountants, should not be considered a substitute for audited financial statements, and should not be regarded as a representation by the Company as to the actual financial results for the fourth quarter of the fiscal year 2020 or the fiscal year ended June 30, 2020.

[0001375365-20-000057:8k_2_02:42]
About Super Micro Computer, Inc.

[0001375365-20-000057:8k_2_02:43]
Supermicro (Nasdaq:SMCI), the leading innovator in high-performance, high-efficiency server and storage technology is a premier provider of advanced server Building Block Solutions® for Enterprise Data Center, Cloud Computing, Artificial Intelligence, and Edge Computing Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-20-000057:8k_2_02:44]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-20-000057:8k_2_02:45]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-20-000057:8k_2_02:46]
Investor Relations Contact:

[0001375365-20-000057:8k_2_02:47]
James Kisner

[0001375365-20-000057:8k_2_02:48]
Vice President, Investor Relations

[0001375365-20-000057:8k_2_02:49]
(669) 284-1259

[0001375365-20-000057:8k_2_02:50]
email: ir@supermicro.com

[0001375365-20-000057:8k_2_02:51]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000057:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-20-000057:8k_2_02:53]
(in thousands)

[0001375365-20-000057:8k_2_02:54]
(unaudited)

[0001375365-20-000057:8k_2_02:55]
|  | June 30, |  | June 30, |
|  | 2020 |  | 2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 210,533 |  |  | $ | 248,164 |  |
| Accounts receivable, net of allowances | 403,745 |  |  | 393,624 |  |
| Inventories | 851,498 |  |  | 670,188 |  |
| Prepaid expenses and other current assets | 126,985 |  |  | 109,795 |  |
| Total current assets | 1,592,761 |  |  | 1,421,771 |  |
| Investment in equity investee | 2,703 |  |  | 1,701 |  |
| Property, plant and equipment, net | 233,785 |  |  | 207,337 |  |
| Deferred income taxes, net | 54,898 |  |  | 41,126 |  |
| Other assets | 34,499 |  |  | 10,659 |  |
| Total assets | $ | 1,918,646 |  |  | $ | 1,682,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 417,673 |  |  | $ | 360,470 |  |
| Accrued liabilities | 155,401 |  |  | 114,678 |  |
| Income taxes payable | 4,700 |  |  | 13,021 |  |
| Short-term debt | 23,704 |  |  | 23,647 |  |
| Deferred revenue | 106,157 |  |  | 94,153 |  |
| Total current liabilities | 707,635 |  |  | 605,969 |  |
| Deferred revenue, non-current | 97,612 |  |  | 109,266 |  |
| Long-term debt | 5,697 |  |  | — |  |
| Other long-term liabilities | 41,995 |  |  | 26,183 |  |
| Total liabilities | 852,939 |  |  | 741,418 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and Additional Paid In Capital | 389,972 |  |  | 349,683 |  |
| Treasury stock | (20,491 | ) |  | (20,491 | ) |
| Accumulated other comprehensive loss | (152 | ) |  | (80 | ) |
| Retained earnings | 696,211 |  |  | 611,903 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,065,540 |  |  | 941,015 |  |
| Noncontrolling interest | 167 |  |  | 161 |  |
| Total stockholders’ equity | 1,065,707 |  |  | 941,176 |  |
| Total liabilities and stockholders’ equity | $ | 1,918,646 |  |  | $ | 1,682,594 |  |

[0001375365-20-000057:8k_2_02:56]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000057:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-20-000057:8k_2_02:58]
(in thousands, except share and per share amounts)

[0001375365-20-000057:8k_2_02:59]
(unaudited)

[0001375365-20-000057:8k_2_02:60]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | $ | 896,126 |  |  | $ | 854,234 |  |  | $ | 3,339,281 |  |  | $ | 3,500,360 |  |
| Cost of sales | 772,609 |  |  | 722,200 |  |  | 2,813,071 |  |  | 3,004,838 |  |
| Gross profit | 123,517 |  |  | 132,034 |  |  | 526,210 |  |  | 495,522 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 66,748 |  |  | 46,189 |  |  | 221,478 |  |  | 179,907 |  |
| Sales and marketing | 21,080 |  |  | 20,691 |  |  | 85,137 |  |  | 77,154 |  |
| General and administrative | 26,261 |  |  | 35,014 |  |  | 133,941 |  |  | 141,228 |  |
| Total operating expenses | 114,089 |  |  | 101,894 |  |  | 440,556 |  |  | 398,289 |  |
| Income from operations | 9,428 |  |  | 30,140 |  |  | 85,654 |  |  | 97,233 |  |
| Other income (expense), net | (700 | ) |  | (1,727 | ) |  | 1,410 |  |  | (1,020 | ) |
| Interest expense | (606 | ) |  | (1,210 | ) |  | (2,236 | ) |  | (6,690 | ) |
| Income before income tax | 8,122 |  |  | 27,203 |  |  | 84,828 |  |  | 89,523 |  |
| Income tax benefit (provision) | 6,860 |  |  | (4,344 | ) |  | (2,922 | ) |  | (14,884 | ) |
| Share of income (loss) from equity investee, net of taxes | 3,468 |  |  | 851 |  |  | 2,402 |  |  | (2,721 | ) |
| Net income | $ | 18,450 |  |  | $ | 23,710 |  |  | $ | 84,308 |  |  | $ | 71,918 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.47 |  |  | $ | 1.65 |  |  | $ | 1.44 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.46 |  |  | $ | 1.60 |  |  | $ | 1.39 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 52,240 |  |  | 50,137 |  |  | 50,987 |  |  | 49,917 |  |
| Diluted | 54,218 |  |  | 51,975 |  |  | 52,838 |  |  | 51,716 |  |

[0001375365-20-000057:8k_2_02:61]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-20-000057:8k_2_02:62]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of sales | $ | 355 |  |  | $ | 407 |  |  | $ | 1,504 |  |  | $ | 1,663 |  |
| Research and development | 2,903 |  |  | 3,165 |  |  | 12,202 |  |  | 12,981 |  |
| Sales and marketing | 404 |  |  | 446 |  |  | 1,680 |  |  | 1,805 |  |
| General and administrative | 1,704 |  |  | 1,085 |  |  | 4,803 |  |  | 4,735 |  |
| Stock-based compensation expense | $ | 5,366 |  |  | $ | 5,103 |  |  | $ | 20,189 |  |  | $ | 21,184 |  |

[0001375365-20-000057:8k_2_02:63]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000057:8k_2_02:64]
SELECTED CASH FLOW INFORMATION

[0001375365-20-000057:8k_2_02:65]
(in thousands)

[0001375365-20-000057:8k_2_02:66]
(unaudited)

[0001375365-20-000057:8k_2_02:67]
|  | Years Ended June 30, |
|  | 2020 |  | 2019 |  |
| Net cash provided (used in) by operating activities | $ | (30,334 | ) |  | $ | 262,554 |  |  |
| Net cash used in investing activities | (43,588 | ) |  | (24,849 | ) |  |
| Net cash provided (used in) financing activities | 23,796 |  |  | (95,828 | ) |  |
| Effect of exchange rate fluctuations on cash | 376 |  |  | (119 | ) |  |
| Net change in cash equivalents and restricted cash | (49,750 | ) |  | 141,758 |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 262,140 |  |  | 120,382 |  |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 212,390 |  |  | $ | 262,140 |  |  |

[0001375365-20-000057:8k_2_02:68]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000057:8k_2_02:69]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000057:8k_2_02:70]
(in thousands, except share and per share amounts)

[0001375365-20-000057:8k_2_02:71]
(unaudited)

[0001375365-20-000057:8k_2_02:72]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP GROSS PROFIT | $ | 123,517 |  |  | $ | 132,034 |  |  | $ | 526,210 |  |  | $ | 495,522 |  |
| Stock-based compensation | 355 |  |  | 407 |  |  | 1,504 |  |  | 1,663 |  |
| One-time employee performance bonuses | 1,201 |  |  | — |  |  | 4,072 |  |  | — |  |
| Other expenses | 39 |  |  | — |  |  | 39 |  |  | — |  |
| Non-GAAP GROSS PROFIT | $ | 125,112 |  |  | $ | 132,441 |  |  | $ | 531,825 |  |  | $ | 497,185 |  |
| GAAP GROSS MARGIN | 13.8 | % |  | 15.5 | % |  | 15.8 | % |  | 14.2 | % |
| Stock-based compensation | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| One-time employee performance bonuses | 0.2 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |
| Other expenses | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 14.0 | % |  | 15.5 | % |  | 15.9 | % |  | 14.2 | % |
| GAAP OPERATING EXPENSES | $ | 114,089 |  |  | $ | 101,894 |  |  | $ | 440,556 |  |  | $ | 398,289 |  |
| Stock-based compensation | (5,011 | ) |  | (4,696 | ) |  | (18,685 | ) |  | (19,521 | ) |
| Legal settlement costs | — |  |  | — |  |  | (17,500 | ) |  | — |  |
| One-time employee performance bonuses | (16,224 | ) |  | — |  |  | (23,682 | ) |  | — |  |
| Other expenses | (638 | ) |  | — |  |  | (638 | ) |  | — |  |
| Controls remediation | (1,004 | ) |  | (10,364 | ) |  | (13,863 | ) |  | (56,917 | ) |
| Non-GAAP OPERATING EXPENSES | $ | 91,212 |  |  | $ | 86,834 |  |  | $ | 366,188 |  |  | $ | 321,851 |  |
| GAAP INCOME FROM OPERATIONS | $ | 9,428 |  |  | $ | 30,140 |  |  | $ | 85,654 |  |  | $ | 97,233 |  |
| Stock-based compensation | 5,366 |  |  | 5,103 |  |  | 20,189 |  |  | 21,184 |  |
| Legal settlement costs | — |  |  | — |  |  | 17,500 |  |  | — |  |
| One-time employee performance bonuses | 17,425 |  |  | — |  |  | 27,754 |  |  | — |  |
| Other expenses | 677 |  |  | — |  |  | 677 |  |  | — |  |
| Controls remediation | 1,004 |  |  | 10,364 |  |  | 13,863 |  |  | 56,917 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 33,900 |  |  | $ | 45,607 |  |  | $ | 165,637 |  |  | $ | 175,334 |  |
| GAAP NET INCOME | $ | 18,450 |  |  | $ | 23,710 |  |  | 84,308 |  |  | $ | 71,918 |  |
| Stock-based compensation | 5,366 |  |  | 5,103 |  |  | 20,189 |  |  | 21,184 |  |
| Legal settlement costs | — |  |  | — |  |  | 17,500 |  |  | — |  |
| One-time employee performance bonuses | 17,425 |  |  | — |  |  | 27,754 |  |  | — |  |
| Other expenses | 677 |  |  | — |  |  | 677 |  |  | — |  |
| Controls remediation | 1,004 |  |  | 10,364 |  |  | 13,863 |  |  | 56,917 |  |
| Impairment of investment | — |  |  | 2,000 |  |  | — |  |  | 2,661 |  |
| Adjustments to tax provision | (5,101 | ) |  | (4,133 | ) |  | (13,969 | ) |  | (19,110 | ) |
| Non-GAAP NET INCOME | $ | 37,821 |  |  | $ | 37,044 |  |  | $ | 150,322 |  |  | $ | 133,570 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.35 |  |  | $ | 0.47 |  |  | $ | 1.65 |  |  | $ | 1.44 |  |
| Impact of Non-GAAP adjustments | 0.37 |  |  | 0.27 |  |  | 1.30 |  |  | 1.24 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.72 |  |  | $ | 0.74 |  |  | $ | 2.95 |  |  | $ | 2.68 |  |

[0001375365-20-000057:8k_2_02:73]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000057:8k_2_02:74]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000057:8k_2_02:75]
(in thousands, except share and per share amounts)

[0001375365-20-000057:8k_2_02:76]
(unaudited)

[0001375365-20-000057:8k_2_02:77]
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.34 |  |  | $ | 0.46 |  |  | $ | 1.60 |  |  | $ | 1.39 |  |
| Impact of Non-GAAP adjustments | 0.34 |  |  | 0.23 |  |  | 1.17 |  |  | 1.12 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.68 |  |  | $ | 0.69 |  |  | $ | 2.77 |  |  | $ | 2.51 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 52,240 |  |  | 50,137 |  |  | 50,987 |  |  | 49,917 |  |
| BASIC – Non-GAAP | 52,240 |  |  | 50,137 |  |  | 50,987 |  |  | 49,917 |  |
| DILUTED – GAAP | 54,218 |  |  | 51,975 |  |  | 52,838 |  |  | 51,716 |  |
| DILUTED – Non-GAAP | 55,595 |  |  | 53,431 |  |  | 54,317 |  |  | 53,127 |  |
