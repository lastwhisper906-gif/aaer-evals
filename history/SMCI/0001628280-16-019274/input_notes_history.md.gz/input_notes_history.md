# SMCI note change history — 0001628280-16-010768 → 0001628280-16-015755


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of March 31, 2016, these remaining non-cancellable commitments were $341,559,000 compared to $378,341,000 as of June 30, 2015.
  (was, 2016-02-04, similarity 0.972):
[0001628280-16-010768:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of December 31, 2015, these remaining non-cancellable commitments were $399,120,000 compared to $378,341,000 as of June 30, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.
  (was, 2016-02-04, similarity 0.9555):
[0001628280-16-010768:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.

- changed (2016-05-06):
[0001628280-16-015755:note_history:3]
Recent Accounting Pronouncements
  (was, 2016-02-04, similarity 0.7397):
[0001628280-16-010768:note_history:3]
Adoption of New Accounting Pronouncements

- added (2016-05-06):
[0001628280-16-015755:note_history:4]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. These guidances can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- added (2016-05-06):
[0001628280-16-015755:note_history:5]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- added (2016-05-06):
[0001628280-16-015755:note_history:6]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- removed (2016-05-06):
[0001628280-16-010768:note_history:7]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:8]
Short-term and long-term obligations as of March 31, 2016 and June 30, 2015 consisted of the following (in thousands):
  (was, 2016-02-04, similarity 0.9589):
[0001628280-16-010768:note_history:8]
Short-term and long-term obligations as of December 31, 2015 and June 30, 2015 consisted of the following (in thousands):

- changed (2016-05-06):
[0001628280-16-015755:note_history:9]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 1,633 |  |  | 3,733 |  |
| CTBC Bank | 20,263 |  |  | 21,280 |  |
| Total building term loans | 21,896 |  |  | 25,013 |  |
| Total debt | 93,795 |  |  | 94,412 |  |
| Current portion | (93,795 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |
  (was, 2016-02-04, similarity 0.9847):
[0001628280-16-010768:note_history:9]
|  | December 31, |  | June 30, |
|  | 2015 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 2,333 |  |  | 3,733 |  |
| CTBC Bank | 20,001 |  |  | 21,280 |  |
| Total building term loans | 22,334 |  |  | 25,013 |  |
| Total debt | 94,233 |  |  | 94,412 |  |
| Current portion | (94,233 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |

- changed (2016-05-06):
[0001628280-16-015755:note_history:10]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In April 2016, the Company extended the revolving line of credit to mature on May 31, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.
  (was, 2016-02-04, similarity 0.9836):
[0001628280-16-010768:note_history:10]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In November 2015, the Company extended the revolving line of credit to mature on February 15, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.

- changed (2016-05-06):
[0001628280-16-015755:note_history:11]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.44% at March 31, 2016. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.
  (was, 2016-02-04, similarity 0.9871):
[0001628280-16-010768:note_history:11]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.24% at December 31, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- changed (2016-05-06):
[0001628280-16-015755:note_history:12]
As of March 31, 2016 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $1,633,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit were $62,199,000 and $59,699,000 as of March 31, 2016 and June 30, 2015, respectively. The interest rates for these loans ranged from 1.00% to 1.94% per annum at March 31, 2016 and from 0.79% to 1.68% per annum at June 30, 2015, respectively. As of March 31, 2016, the unused revolving line of credit with Bank of America was $2,801,000.
  (was, 2016-02-04, similarity 0.9455):
[0001628280-16-010768:note_history:12]
As of December 31, 2015 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $2,333,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit were $62,199,000 and $59,699,000 as of December 31, 2015 and June 30, 2015, respectively. The interest rates for these loans ranged from 0.89% to 1.74% per annum at December 31, 2015 and from 0.79% to 1.68% per annum at June 30, 2015, respectively. As of December 31, 2015, the unused revolving line of credit with Bank of America was $2,801,000.

- changed (2016-05-06):
[0001628280-16-015755:note_history:13]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,340,000 U.S. dollar equivalent.
  (was, 2016-02-04, similarity 0.8427):
[0001628280-16-010768:note_history:13]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) to extend the maturity date to January 31, 2016. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,340,000 U.S. dollar equivalents. In January 2016, the Company further extended the revolving line of credit to mature on March 31, 2016, and the Company is currently negotiating with CTBC Bank to renew the credit agreement.

- changed (2016-05-06):
[0001628280-16-015755:note_history:14]
The total outstanding borrowings under the CTBC Bank term loan are denominated in Taiwanese dollars and were translated into U.S. dollars of $20,263,000 and $21,280,000 at March 31, 2016 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit were $9,700,000 in U.S. dollars at March 31, 2016 and June 30, 2015. The interest rate for this loan ranged from 0.92% and 1.06% at March 31, 2016 and 0.82% and 1.16% per annum at June 30, 2015.
  (was, 2016-02-04, similarity 0.7733):
[0001628280-16-010768:note_history:14]
The total outstanding borrowings under the CTBC Bank term loan are denominated in Taiwanese dollars and were translated into U.S. dollars of $20,001,000 and $21,280,000 at December 31, 2015 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit were $9,700,000 in U.S. dollars at December 31, 2015 and June 30, 2015. The interest rate for this loan ranged from 0.79% and 1.14% at December 31, 2015 and 0.82% and 1.16% per annum at June 30, 2015. At December 31, 2015, NT$21,025,000 or $639,000 U.S. dollar equivalents were available for future borrowing under this credit agreement. The Company is currently negotiating with CTBC Bank to renew the credit agreement.

- added (2016-05-06):
[0001628280-16-015755:note_history:15]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NT700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NT100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

- changed (2016-05-06):
[0001628280-16-015755:note_history:16]
As of March 31, 2016 and June 30, 2015, total assets of $1,137,023,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of March 31, 2016 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,181,000 and $17,354,000. As of March 31, 2016, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.
  (was, 2016-02-04, similarity 0.9643):
[0001628280-16-010768:note_history:16]
As of December 31, 2015 and June 30, 2015, total assets of $1,148,460,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of December 31, 2015 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,239,000 and $17,354,000. As of December 31, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

- changed (2016-05-06):
[0001628280-16-015755:note_history:17]
As of March 31, 2016 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $26,909,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2016.
  (was, 2016-02-04, similarity 0.9328):
[0001628280-16-010768:note_history:17]
As of December 31, 2015 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $26,939,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2015.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:18]
As of March 31, 2016 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at March 31, 2016 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.
  (was, 2016-02-04, similarity 0.9673):
[0001628280-16-010768:note_history:18]
As of December 31, 2015 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at December 31, 2015 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.

- changed (2016-05-06):
[0001628280-16-015755:note_history:19]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2016 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.
  (was, 2016-02-04, similarity 0.9867):
[0001628280-16-010768:note_history:19]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of December 31, 2015 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.

- changed (2016-05-06):
[0001628280-16-015755:note_history:20]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2016 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of March 31, 2016, the discount rate, the time period until redemption and the estimated rate of return were 1.81%, 3 years and 0.41%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.
  (was, 2016-02-04, similarity 0.9928):
[0001628280-16-010768:note_history:20]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of December 31, 2015 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of December 31, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.99%, 3 years and 0.50%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

- changed (2016-05-06):
[0001628280-16-015755:note_history:21]
Based on this assessment of fair value, the Company determined that there was no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2016 and 2015. There was a cumulative total decline of $117,000 as of March 31, 2016 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of March 31, 2016 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.
  (was, 2016-02-04, similarity 0.9498):
[0001628280-16-010768:note_history:21]
Based on this assessment of fair value, the Company determined that there was no changes in fair value of its auction rate securities during the three and six months ended December 31, 2015 and 2014. There was a cumulative total decline of $117,000 as of December 31, 2015 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of December 31, 2015 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

- changed (2016-05-06):
[0001628280-16-015755:note_history:22]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three and nine months ended March 31, 2016 and 2015, there were no auction rate securities redeemed or sold.
  (was, 2016-02-04, similarity 0.9532):
[0001628280-16-010768:note_history:22]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three and six months ended December 31, 2015 and 2014, there were no auction rate securities redeemed or sold.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:23]
Short-term and long-term obligations as of March 31, 2016 and June 30, 2015 consisted of the following (in thousands):
  (was, 2016-02-04, similarity 0.9589):
[0001628280-16-010768:note_history:23]
Short-term and long-term obligations as of December 31, 2015 and June 30, 2015 consisted of the following (in thousands):

- changed (2016-05-06):
[0001628280-16-015755:note_history:24]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 1,633 |  |  | 3,733 |  |
| CTBC Bank | 20,263 |  |  | 21,280 |  |
| Total building term loans | 21,896 |  |  | 25,013 |  |
| Total debt | 93,795 |  |  | 94,412 |  |
| Current portion | (93,795 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |
  (was, 2016-02-04, similarity 0.9847):
[0001628280-16-010768:note_history:24]
|  | December 31, |  | June 30, |
|  | 2015 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 2,333 |  |  | 3,733 |  |
| CTBC Bank | 20,001 |  |  | 21,280 |  |
| Total building term loans | 22,334 |  |  | 25,013 |  |
| Total debt | 94,233 |  |  | 94,412 |  |
| Current portion | (94,233 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001628280-16-015755:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.3% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at March 31, 2016.
  (was, 2016-02-04, similarity 0.9914):
[0001628280-16-010768:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at December 31, 2015.

- changed (2016-05-06):
[0001628280-16-015755:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $55,133,000 and $185,845,000, and sold products to Ablecom totaling $4,413,000 and $12,125,000 for the three and nine months ended March 31, 2016, respectively. The Company purchased products from Ablecom totaling $58,002,000 and $169,918,000, and sold products to Ablecom totaling $6,067,000 and $43,524,000 for the three and nine months ended March 31, 2015, respectively.
  (was, 2016-02-04, similarity 0.9016):
[0001628280-16-010768:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $71,451,000 and $130,712,000, and sold products to Ablecom totaling $2,492,000 and $7,712,000 for the three and six months ended December 31, 2015, respectively. The Company purchased products from Ablecom totaling $57,513,000 and $111,916,000, and sold products to Ablecom totaling $10,879,000 and $37,457,000 for the three and six months ended December 31, 2014, respectively.

- changed (2016-05-06):
[0001628280-16-015755:note_history:27]
Amounts owed to the Company by Ablecom as of March 31, 2016 and June 30, 2015 were $6,034,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2016 and June 30, 2015 were $45,357,000 and $59,015,000, respectively. For the three and nine months ended March 31, 2016, the Company paid Ablecom the majority of invoiced dollars between 34 and 88 days of invoice date. For the three and nine months ended March 31, 2016, the Company paid $3,003,000 and $5,901,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2015, the Company paid $231,000 and $4,728,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2016-02-04, similarity 0.864):
[0001628280-16-010768:note_history:27]
Amounts owed to the Company by Ablecom as of December 31, 2015 and June 30, 2015 were $6,484,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2015 and June 30, 2015 were $59,217,000 and $59,015,000, respectively. For the three and six months ended December 31, 2015, the Company paid Ablecom the majority of invoiced dollars between 46 and 89 days of invoice date. For the three and six months ended December 31, 2015, the Company paid $1,736,000 and $2,898,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2014, the Company paid $2,495,000 and $4,497,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2016-05-06):
[0001628280-16-015755:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $65,227,000 and $67,261,000 at March 31, 2016 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2016-02-04, similarity 0.9915):
[0001628280-16-010768:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $70,717,000 and $67,261,000 at December 31, 2015 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2016-05-06):
[0001628280-16-015755:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2016, $13,000 and $9,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2015, $4,000 and $(3,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2016-02-04, similarity 0.9488):
[0001628280-16-010768:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2015, $6,000 and $4,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2014, $10,000 and $7,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
