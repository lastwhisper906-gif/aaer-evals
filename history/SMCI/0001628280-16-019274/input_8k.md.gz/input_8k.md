# SMCI 8-K — 0001628280-16-018511 filed 2016-08-04

## item codes, every 8-K on or before 2016-08-26

- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2016-08-26

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-018511:8k_2_02:1]
EX-99.1
2
exhibit991q4-2016.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-16-018511:8k_2_02:2]
Exhibit

[0001628280-16-018511:8k_2_02:3]
Exhibit 99.1

[0001628280-16-018511:8k_2_02:4]
Super Micro Computer, Inc. Announces 4th Quarter 2016 Financial Results

[0001628280-16-018511:8k_2_02:5]
SAN JOSE, Calif., August 4, 2016 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced fourth quarter and full-year financial results for the fiscal year ended June 30, 2016. The final results are in line with the preliminary results announced by the Company on July 18, 2016.

[0001628280-16-018511:8k_2_02:6]
Fiscal 4th Quarter Highlights

[0001628280-16-018511:8k_2_02:7]
| • | Quarterly net sales of $524.3 million, down 1.6% from the third quarter of fiscal year 2016 and down 8.6% from the same quarter of last year. |

[0001628280-16-018511:8k_2_02:8]
| • | GAAP net income of $7.0 million, down 58.2% from the third quarter of fiscal year 2016 and down 73.9% from the same quarter of last year. |

[0001628280-16-018511:8k_2_02:9]
| • | GAAP gross margin was 14.1%, down from 14.9% in the third quarter of fiscal year 2016 and down from 15.6% in the same quarter of last year. |

[0001628280-16-018511:8k_2_02:10]
| • | Server solutions accounted for 65.5% of net sales compared with 69.9% in the third quarter of fiscal year 2016 and 61.7% in the same quarter of last year. |

[0001628280-16-018511:8k_2_02:11]
Net sales for the fourth quarter ended June 30, 2016 totaled $524.3 million, down 1.6% from $532.7 million in the third quarter of fiscal year 2016. No customer accounted for more than 10% of net sales during the quarter ended June 30, 2016.

[0001628280-16-018511:8k_2_02:12]
GAAP net income for the fourth quarter of fiscal year 2016 was $7.0 million or $0.13 per diluted share, a decrease of 73.9% from net income of $26.7 million, or $0.51 per diluted share in the same period a year ago. Included in net income for the quarter is $4.4 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the fourth quarter was $10.4 million, or $0.20 per diluted share, compared to non-GAAP net income of $30.0 million, or $0.57 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income decreased from the third quarter of fiscal year 2016 by $8.6 million or $0.16 per diluted share.

[0001628280-16-018511:8k_2_02:13]
GAAP gross margin for the fourth quarter was 14.1% compared to 15.6% in the same period a year ago. Non-GAAP gross margin for the fourth quarter was 14.1% compared to 15.7% in the same period a year ago. GAAP and Non-GAAP gross margin for the third quarter of fiscal year 2016 were both 14.9%.

[0001628280-16-018511:8k_2_02:14]
The GAAP income tax provision was $4.5 million or 39.0% of income before tax provision compared to $13.8 million or 34.1% in the same period a year ago and $7.4 million or 30.7% in the third quarter of fiscal year 2016. The effective tax rates for the fourth quarter of fiscal year 2016 was higher due to higher tax expenses associated with the implementation of the Company's new global corporate structure on May 1, 2016.

[0001628280-16-018511:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at June 30, 2016 were $183.7 million compared to $98.1 million at June 30, 2015. Free cash flow for the year ended June 30, 2016 was $73.4 million, primarily due to an increase in the Company's cash provided by operating activities and partially offset by the cash used in the development and construction of improvements on the Company's properties.

[0001628280-16-018511:8k_2_02:16]
Fiscal Year 2016 Summary

[0001628280-16-018511:8k_2_02:17]
Net sales for the fiscal year ended June 30, 2016 were $2,215.6 million, up 11.3% from $1,991.2 million for the fiscal year ended June 30, 2015. GAAP net income for fiscal year 2016 decreased to $72.0 million, or $1.39 per diluted share, a decrease of 29.3% from $101.9 million, or $2.03 per diluted share, for fiscal year 2015. Included in net income for the fiscal year ended June 30, 2016 is $16.1 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the fiscal year 2016 was $83.8 million or $1.59 per diluted share, a decrease of 24.9% compared to $111.6 million or $2.15 per diluted share for fiscal year 2015.

[0001628280-16-018511:8k_2_02:18]
Business Outlook & Management Commentary

[0001628280-16-018511:8k_2_02:19]
The Company expects net sales of $470 million to $550 million for the first quarter of fiscal year 2017 ending September 30, 2016. The Company expects non-GAAP earnings per diluted share of approximately $0.15 to $0.30 for the first quarter.

[0001628280-16-018511:8k_2_02:20]
“As previously announced, this quarter our results were below expectations due to reduced demand from large datacenter customers and issues related to a global SAP and tax reorganization implementation that impacted our execution and pricing flexibility,” said Charles Liang, Chairman and Chief Executive Officer. “Our core strategy will be to continue to grow our technology leadership by offering the broadest array of first to market innovations in server, storage, cloud and IoT, by delivering leading architectures that leverage our building block solutions and partner strategy to provide total solutions with software and service. At the same time, we will take actions to leverage our capacity and improve operational efficiency to become more flexible and competitive in winning new business. By offering the best value for innovation and emphasizing strategic customer relationships, we are confident that we can achieve stronger growth and improve financial performance.”

[0001628280-16-018511:8k_2_02:21]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-16-018511:8k_2_02:22]
Conference Call Information

[0001628280-16-018511:8k_2_02:23]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-455-2263 (International callers dial 1-719-325-2177) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, August 18, 2016, by dialing 1-877-870-5176 (International callers dial 1-858-384-5517) and entering replay PIN 1154709. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-16-018511:8k_2_02:24]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-16-018511:8k_2_02:25]
Use of Non-GAAP Financial Measures

[0001628280-16-018511:8k_2_02:26]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-16-018511:8k_2_02:27]
About Super Micro Computer, Inc.

[0001628280-16-018511:8k_2_02:28]
Supermicro®, a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, TwinPro, FatTwin™, Ultra Series, MicroCloud, MicroBlade, SuperBlade®, Simply Double, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-16-018511:8k_2_02:29]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-16-018511:8k_2_02:30]
Supermicro, FatTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001628280-16-018511:8k_2_02:31]
All other brands, names and trademarks are the property of their respective owners.

[0001628280-16-018511:8k_2_02:32]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | June 30, |  | June 30, |
|  |  |  |  | 2016 |  | 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 180,964 |  |  | $ | 95,442 |  |
|  | Accounts receivable, net | 288,941 |  |  | 322,594 |  |
|  | Inventory |  | 448,980 |  |  | 463,493 |  |
|  | Deferred income taxes – current | — |  |  | 17,863 |  |
|  | Prepaid income taxes | 5,682 |  |  | 7,507 |  |
|  | Prepaid expenses and other current assets | 13,435 |  |  | 7,516 |  |
|  |  | Total current assets | 938,002 |  |  | 914,415 |  |
| Long-term investments | 2,643 |  |  | 2,633 |  |
| Property, plant and equipment, net | 187,949 |  |  | 163,038 |  |
| Deferred income taxes – noncurrent |  | 28,460 |  |  | 4,497 |  |
| Other assets |  |  | 8,546 |  |  | 5,226 |  |
|  |  | Total assets | $ | 1,165,600 |  |  | $ | 1,089,809 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 249,239 |  |  | $ | 299,774 |  |
|  | Accrued liabilities |  | 55,618 |  |  | 46,743 |  |
|  | Income taxes payable |  | 5,172 |  |  | 14,111 |  |
|  | Short-term debt and current portion of long-term debt | 53,589 |  |  | 93,479 |  |
|  |  | Total current liabilities | 363,618 |  |  | 454,107 |  |
| Long term debt, net of current portion | 40,000 |  |  | 933 |  |
| Other long-term liabilities | 40,603 |  |  | 15,684 |  |
|  |  | Total liabilities | 444,221 |  |  | 470,724 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 277,339 |  |  | 247,081 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (85 | ) |  | (80 | ) |
|  | Retained earnings |  | 445,971 |  |  | 373,950 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 721,195 |  |  | 618,921 |  |
|  | Noncontrolling interest | 184 |  |  | 164 |  |
|  |  | Total stockholders' equity | 721,379 |  |  | 619,085 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,165,600 |  |  | $ | 1,089,809 |  |

[0001628280-16-018511:8k_2_02:33]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Fiscal Year Ended |
|  | June 30, |  | June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 524,270 |  |  | $ | 573,594 |  |  | $ | 2,215,573 |  |  | $ | 1,991,155 |  |
| Cost of sales | 450,474 |  |  | 483,828 |  |  | 1,884,048 |  |  | 1,670,924 |  |
| Gross profit | 73,796 |  |  | 89,766 |  |  | 331,525 |  |  | 320,231 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 34,148 |  |  | 27,741 |  |  | 123,994 |  |  | 100,257 |  |
| Sales and marketing | 17,664 |  |  | 14,195 |  |  | 62,841 |  |  | 48,851 |  |
| General and administrative | 10,145 |  |  | 7,043 |  |  | 37,840 |  |  | 24,377 |  |
| Total operating expenses | 61,957 |  |  | 48,979 |  |  | 224,675 |  |  | 173,485 |  |
| Income from operations | 11,839 |  |  | 40,787 |  |  | 106,850 |  |  | 146,746 |  |
| Interest and other income, net | 40 |  |  | 23 |  |  | 171 |  |  | 115 |  |
| Interest expense | (453 | ) |  | (309 | ) |  | (1,594 | ) |  | (965 | ) |
| Income before income tax provision | 11,426 |  |  | 40,501 |  |  | 105,427 |  |  | 145,896 |  |
| Income tax provision | 4,455 |  |  | 13,799 |  |  | 33,406 |  |  | 44,033 |  |
| Net income | $ | 6,971 |  |  | $ | 26,702 |  |  | $ | 72,021 |  |  | $ | 101,863 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.14 |  |  | $ | 0.56 |  |  | $ | 1.50 |  |  | $ | 2.19 |  |
| Diluted | $ | 0.13 |  |  | $ | 0.51 |  |  | $ | 1.39 |  |  | $ | 2.03 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 48,463 |  |  | 47,327 |  |  | 47,917 |  |  | 46,434 |  |
| Diluted | 52,274 |  |  | 51,990 |  |  | 51,836 |  |  | 50,094 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended |  | Fiscal Year Ended |
|  | June 30, |  | June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of sales | $ | 306 |  |  | $ | 250 |  |  | $ | 1,098 |  |  | $ | 901 |  |
| Research and development | 2,755 |  |  | 2,495 |  |  | 10,178 |  |  | 8,643 |  |
| Sales and marketing | 511 |  |  | 405 |  |  | 1,841 |  |  | 1,553 |  |
| General and administrative | 791 |  |  | 822 |  |  | 3,014 |  |  | 2,602 |  |
| Stock-based compensation expense before taxes | $ | 4,363 |  |  | $ | 3,972 |  |  | $ | 16,131 |  |  | $ | 13,699 |  |

[0001628280-16-018511:8k_2_02:34]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Fiscal Year Ended |
|  | June 30, |
|  | 2016 |  | 2015 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 72,021 |  |  | $ | 101,863 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 13,282 |  |  | 8,133 |  |
| Stock-based compensation expense | 16,131 |  |  | 13,699 |  |
| Excess tax benefits from stock-based compensation | (2,855 | ) |  | (8,089 | ) |
| Allowance for doubtful accounts | 1,278 |  |  | 326 |  |
| Provision for inventory | 9,313 |  |  | 5,928 |  |
| Exchange gain | (1,233 | ) |  | (675 | ) |
| Deferred income taxes, net | (6,133 | ) |  | 632 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 32,375 |  |  | (110,182 | ) |
| Inventory | 5,200 |  |  | (153,584 | ) |
| Prepaid expenses and other assets | (8,210 | ) |  | (2,741 | ) |
| Accounts payable | (54,301 | ) |  | 75,520 |  |
| Income taxes payable, net | (3,260 | ) |  | 11,951 |  |
| Accrued liabilities | 9,027 |  |  | 9,551 |  |
| Other long-term liabilities | 24,874 |  |  | 3,032 |  |
| Net cash provided by (used in) operating activities | 107,509 |  |  | (44,636 | ) |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (34,108 | ) |  | (35,100 | ) |
| Restricted cash | (1,020 | ) |  | (416 | ) |
| Investment in a privately held company | — |  |  | (661 | ) |
| Net cash used in investing activities | (35,128 | ) |  | (36,177 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 34,200 |  |  | 84,900 |  |
| Repayment of debt | (34,100 | ) |  | (36,000 | ) |
| Proceeds from exercise of stock options | 12,186 |  |  | 23,338 |  |
| Excess tax benefits from stock-based compensation | 2,855 |  |  | 8,089 |  |
| Payment of obligations under capital leases | (189 | ) |  | (134 | ) |
| Advances under receivable financing arrangements | (21 | ) |  | 33 |  |
| Minimum tax withholding paid on behalf of employees for restricted stock units | (1,786 | ) |  | (175 | ) |
| Net cash provided by financing activities | 13,145 |  |  | 80,051 |  |
| Effect of exchange rate fluctuations on cash | (4 | ) |  | (668 | ) |
| Net increase (decrease) in cash and cash equivalents | 85,522 |  |  | (1,430 | ) |
| Cash and cash equivalents at beginning of period | 95,442 |  |  | 96,872 |  |
| Cash and cash equivalents at end of period | 180,964 |  |  | 95,442 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 1,632 |  |  | 933 |  |
| Cash paid for taxes, net of refunds | 36,951 |  |  | 30,671 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 299 |  |  | 442 |  |
| Accrued costs for property, plant and equipment purchases | 10,888 |  |  | 6,826 |  |

[0001628280-16-018511:8k_2_02:35]
| SUPER MICRO COMPUTER, INC. |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  | Fiscal Year Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP GROSS PROFIT | $ | 73,796 |  |  | $ | 89,766 |  |  | $ | 331,525 |  |  | $ | 320,231 |  |
|  | Add back stock-based compensation (a) | 306 |  |  | 250 |  |  | 1,098 |  |  | 901 |  |
| Non-GAAP GROSS PROFIT | $ | 74,102 |  |  | $ | 90,016 |  |  | $ | 332,623 |  |  | $ | 321,132 |  |
| GAAP GROSS MARGIN | 14.1 | % |  | 15.6 | % |  | 15.0 | % |  | 16.1 | % |
|  | Add back stock-based compensation (a) | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 14.1 | % |  | 15.7 | % |  | 15.0 | % |  | 16.1 | % |
| GAAP INCOME FROM OPERATIONS | $ | 11,839 |  |  | $ | 40,787 |  |  | $ | 106,850 |  |  | $ | 146,746 |  |
|  | Add back stock-based compensation (a) | 4,363 |  |  | 3,972 |  |  | 16,131 |  |  | 13,699 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 16,202 |  |  | $ | 44,759 |  |  | $ | 122,981 |  |  | $ | 160,445 |  |
| GAAP NET INCOME | $ | 6,971 |  |  | $ | 26,702 |  |  | $ | 72,021 |  |  | $ | 101,863 |  |
|  | Add back stock-based compensation (a) | 4,363 |  |  | 3,972 |  |  | 16,131 |  |  | 13,699 |  |
|  | Add back adjustments to tax provision (b) | (971 | ) |  | (681 | ) |  | (4,312 | ) |  | (3,955 | ) |
| Non-GAAP NET INCOME | $ | 10,363 |  |  | $ | 29,993 |  |  | $ | 83,840 |  |  | $ | 111,607 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.14 |  |  | $ | 0.56 |  |  | $ | 1.50 |  |  | $ | 2.19 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.07 |  |  | 0.07 |  |  | 0.25 |  |  | 0.21 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.21 |  |  | $ | 0.63 |  |  | $ | 1.75 |  |  | $ | 2.40 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.13 |  |  | $ | 0.51 |  |  | $ | 1.39 |  |  | $ | 2.03 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.07 |  |  | 0.06 |  |  | 0.20 |  |  | 0.12 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.20 |  |  | $ | 0.57 |  |  | $ | 1.59 |  |  | $ | 2.15 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP | 48,463 |  |  | 47,327 |  |  | 47,917 |  |  | 46,434 |  |
|  | BASIC - Non-GAAP | 48,463 |  |  | 47,327 |  |  | 47,917 |  |  | 46,434 |  |
|  | DILUTED – GAAP | 52,274 |  |  | 51,990 |  |  | 51,836 |  |  | 50,094 |  |
|  | DILUTED - Non-GAAP | 52,955 |  |  | 52,609 |  |  | 52,666 |  |  | 51,930 |  |

[0001628280-16-018511:8k_2_02:36]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three months and fiscal years ended June 30, 2016 and 2015.

[0001628280-16-018511:8k_2_02:37]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 34.4% and 31.0% for the three months and fiscal year ended June 30, 2016, respectively, and 32.6% and 30.1% for the three months and fiscal year ended June 30, 2015, respectively.

[0001628280-16-018511:8k_2_02:38]
SOURCE: Super Micro Computer, Inc.

[0001628280-16-018511:8k_2_02:39]
Super Micro Computer, Inc.

[0001628280-16-018511:8k_2_02:40]
Howard Hideshima, 408-503-8000

[0001628280-16-018511:8k_2_02:41]
SVP, Chief Financial Officer

[0001628280-16-018511:8k_2_02:42]
ir@supermicro.com

[0001628280-16-018511:8k_2_02:43]
or

[0001628280-16-018511:8k_2_02:44]
Perry G. Hayes

[0001628280-16-018511:8k_2_02:45]
SVP, Investor Relations

[0001628280-16-018511:8k_2_02:46]
ir@supermicro.com

[0001628280-16-018511:8k_2_02:47]
SMCI-F
