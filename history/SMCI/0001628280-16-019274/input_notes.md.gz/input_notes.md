# SMCI notes — 0001628280-16-019274


## smci:CertainSignificantRisksandUncertaintiesPolicyPolicyTextBlock

[0001628280-16-019274:notes:1]
Certain Significant Risks and Uncertainties

[0001628280-16-019274:notes:2]
The Company operates in the high technology industry and is subject to a number of risks, some of which are beyond the Company’s control, that could have a material adverse effect on the Company’s business, operating results, and financial condition. These risks include variability and uncertainty of revenues and operating results; product obsolescence; geographic concentration; international operations; dependence on key personnel; competition; intellectual property claims and litigation; management of growth; and limited sources of supply.


## smci:ConcentrationofCreditRiskPolicyPolicyTextBlock

[0001628280-16-019274:notes:3]
Concentration of Credit Risk

[0001628280-16-019274:notes:4]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents and long-term investments and accounts receivable.


## smci:ConcentrationofSupplierRiskPolicyPolicyTextBlock

[0001628280-16-019274:notes:5]
Concentration of Supplier Risk

[0001628280-16-019274:notes:6]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry.


## smci:InvestmentsandOtherAssetsPolicyPolicyTextBlock

[0001628280-16-019274:notes:7]
Other Assets

[0001628280-16-019274:notes:8]
As of June 30, 2016, other assets consist primarily of a long-term deferred service costs of $3,498,000, restricted cash of $1,851,000, investments in privately held companies of $1,411,000, deposits of $910,000 and a long-term prepaid royalty license of $748,000. As of June 30, 2016, restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California, two deposits to an escrow account required by the Company's worker's compensation program, one deposit required for the Company's bonded warehouse set up in Taiwan, four deposits to bank guarantees for import duty required by the customs authority in Taiwan and bank guarantees in connection with office leases in the Netherlands.

[0001628280-16-019274:notes:9]
As of June 30, 2015, other assets consist primarily of a long-term deferred service costs of $1,490,000, investments in a privately held companies of $1,411,000, a long-term prepaid royalty license of $997,000 and restricted cash of $840,000.


## smci:PropertyPlantAndEquipmentUsefulLifeTableTextBlock

[0001628280-16-019274:notes:10]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001628280-16-019274:notes:11]
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Software | 3 to 5 years |
| Buildings | 39 years |
| Building improvements | 20 years |
| Land improvements | 15 years |
| Leasehold improvements | shorter of lease term or estimated useful life |


## smci:SummaryOfAllowanceForDoubtfulAccountsAndSalesReturnsTableTextBlock

[0001628280-16-019274:notes:12]
Accounts receivable allowances as of June 30, 2016, 2015 and 2014, consisted of the following (in thousands):

[0001628280-16-019274:notes:13]
|  | BeginningBalance |  | Charged toCost andExpenses |  | Deductions |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2016 | $ | 1,198 |  |  | $ | 1,278 |  |  | $ | (135 | ) |  | $ | 2,341 |  |
| Year ended June 30, 2015 | 1,474 |  |  | 326 |  |  | (602 | ) |  | 1,198 |  |
| Year ended June 30, 2014 | 1,562 |  |  | 1,476 |  |  | (1,564 | ) |  | 1,474 |  |
| Allowance for sales returns |  |  |  |  |  |  |  |
| Year ended June 30, 2016 | $ | 430 |  |  | $ | 10,877 |  |  | $ | (10,927 | ) |  | $ | 380 |  |
| Year ended June 30, 2015 | 448 |  |  | 9,383 |  |  | (9,401 | ) |  | 430 |  |
| Year ended June 30, 2014 | 404 |  |  | 8,985 |  |  | (8,941 | ) |  | 448 |  |


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001628280-16-019274:notes:14]
Prior Period Adjustment Recorded in Current Period

[0001628280-16-019274:notes:15]
In November 2015, the Company identified errors to revenue recognized in the consolidated financial statements for the fiscal years ended June 30, 2013, 2014 and 2015. The Company determined that certain contracts for extended warranties on products in multiple element arrangements were incorrectly recorded as revenue at the time of sale of the product instead of being deferred and amortized over the contractual warranty period. To quantify the amount of these errors, the Company determined a best estimated selling price for the extended warranty contracts based on amounts separately priced for these contracts on customer invoices. The cumulative impact of this prior period error as of June 30, 2015 was an overstatement of net sales and net income by $9,259,000 and $5,926,000, respectively for the three-year period then ended.

[0001628280-16-019274:notes:16]
The Company assessed the materiality of these errors on the consolidated financial statements for each of the fiscal years ended June 30, 2013, 2014 and 2015, and concluded not to correct those financial statements because the errors were not material to any of these periods. The Company also concluded that recording an out-of-period correction to the consolidated financial statements for the fiscal year ended June 30, 2016 would not be material. Consequently, the out-of-period correction of these errors was recorded in the first quarter ended September 30, 2015 by reducing net sales by $9,259,000 and net income by $5,926,000, respectively.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-16-019274:notes:17]
Accrued Liabilities

[0001628280-16-019274:notes:18]
Accrued liabilities as of June 30, 2016 and 2015 consisted of the following (in thousands):

[0001628280-16-019274:notes:19]
|  | June 30, |
|  | 2016 |  | 2015 |
| Accrued payroll and related expenses | $ | 16,015 |  |  | $ | 15,141 |  |
| Customer deposits | 6,265 |  |  | 6,314 |  |
| Accrued warranty costs | 5,816 |  |  | 7,700 |  |
| Accrued cooperative marketing expenses | 7,300 |  |  | 5,690 |  |
| Deferred revenue (1) | 13,418 |  |  | 4,989 |  |
| Others | 6,804 |  |  | 6,909 |  |
| Total accrued liabilities | $ | 55,618 |  |  | $ | 46,743 |  |

[0001628280-16-019274:notes:20]
(1) As of June 30, 2016 and 2015, deferred revenue consist primarily of a deferred extended warranty and on-site service revenue of $12,746,000 and $4,085,000, respectively.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001628280-16-019274:notes:21]
Advertising Costs

[0001628280-16-019274:notes:22]
Advertising costs are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001628280-16-019274:notes:23]
Cash and Cash Equivalents

[0001628280-16-019274:notes:24]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposits with maturities of less than three months.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-019274:notes:25]
Commitments and Contingencies

[0001628280-16-019274:notes:26]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-16-019274:notes:27]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of June 30, 2016, these remaining non-cancellable commitments were $334,010,000 compared to $378,341,000 as of June 30, 2015.

[0001628280-16-019274:notes:28]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $110,505,000, which will be paid through December 2016. The Company entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.

[0001628280-16-019274:notes:29]
Lease Commitments—The Company leases offices and equipment under noncancelable operating leases which expire at various dates through 2025. In addition, the Company leases certain of its equipment under capital leases. The future minimum lease commitments under all leases are as follows (in thousands):

[0001628280-16-019274:notes:30]
|  | Balance as of |
| Year ending: | CapitalLeases |  | OperatingLeases |
| June 30, 2017 | $ | 261 |  |  | $ | 4,271 |  |
| June 30, 2018 | 234 |  |  | 3,924 |  |
| June 30, 2019 | 195 |  |  | 3,698 |  |
| June 30, 2020 | 94 |  |  | 3,737 |  |
| June 30, 2021 | 38 |  |  | 1,662 |  |
| Thereafter | — |  |  | 2,631 |  |
| Total minimum lease payments | 822 |  |  | $ | 19,923 |  |
| Less: Amounts representing interest | 71 |  |  |  |
| Present value of minimum lease payments | 751 |  |  |  |
| Less: Long-term portion | 524 |  |  |  |
| Current portion | $ | 227 |  |  |  |

[0001628280-16-019274:notes:31]
Rent expense for the years ended June 30, 2016, 2015 and 2014, was $4,560,000, $3,729,000 and $3,477,000, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-16-019274:notes:32]
Basis of Presentation

[0001628280-16-019274:notes:33]
The consolidated financial statements reflect the consolidated balance sheets, results of operations and cash flows of Super Micro Computer, Inc. and its wholly-owned subsidiaries (collectively, the “Company”). All intercompany accounts and transactions have been eliminated in consolidation.

[0001628280-16-019274:notes:34]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the Consolidated Balance Sheets. Net income attributable to the noncontrolling interest is not presented separately in the Consolidated Statements of Operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:CostOfSalesPolicyTextBlock

[0001628280-16-019274:notes:35]
Cost of Sales

[0001628280-16-019274:notes:36]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or market and excess and obsolete inventory.


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-019274:notes:37]
Short-term and Long-term Obligations

[0001628280-16-019274:notes:38]
Short-term and long-term obligations as of June 30, 2016 and 2015 consisted of the following (in thousands):

[0001628280-16-019274:notes:39]
|  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 10,100 |  |  | 9,700 |  |
| Total lines of credit | 72,299 |  |  | 69,399 |  |
| Term loans: |  |  |  |
| Bank of America | 933 |  |  | 3,733 |  |
| CTBC Bank | 20,357 |  |  | 21,280 |  |
| Total term loans | 21,290 |  |  | 25,013 |  |
| Total debt | 93,589 |  |  | 94,412 |  |
| Current portion | (53,589 | ) |  | (93,479 | ) |
| Long-term portion | $ | 40,000 |  |  | $ | 933 |  |

[0001628280-16-019274:notes:40]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan as of June 30, 2016.

[0001628280-16-019274:notes:41]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-16-019274:notes:42]
Bank of America

[0001628280-16-019274:notes:43]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The Company extended the revolving line of credit to mature on June 30, 2016.

[0001628280-16-019274:notes:44]
In June 2016, the Company entered into a new credit agreement with Bank of America, which provided for (i) a $55,000,000 revolving line of credit facility including a $5,000,000 letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50,000,000 term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-16-019274:notes:45]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.46% at June 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, the Company received $50,000,000 term loan proceeds from Bank of America under the new credit agreement with an interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America.

[0001628280-16-019274:notes:46]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10.0 million for the Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of fund.

[0001628280-16-019274:notes:47]
As of June 30, 2016 and 2015, the total outstanding borrowings under the Bank of America term loan was $933,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $62,199,000 and $59,699,000 as of June 30, 2016 and 2015, respectively. The interest rates for these loans ranged from 1.02% to 1.96% per annum at June 30, 2016 and from 0.79% to 1.68% per annum at June 30, 2015, respectively. As of June 30, 2016, the unused revolving lines of credit and term loan amount with Bank of America under the new credit agreements were $2,801,000 and $50,000,000, respectively.

[0001628280-16-019274:notes:48]
CTBC Bank

[0001628280-16-019274:notes:49]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NTD$1,000,000,000 or $30,340,000 U.S. dollar equivalent. In January 2016, the Company extended the revolving line of credit to mature on March 31, 2016.

[0001628280-16-019274:notes:50]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

[0001628280-16-019274:notes:51]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20,357,000 and $21,280,000 at June 30, 2016 and 2015, respectively. At June 30, 2016 and 2015, the total outstanding borrowings under the CTBC Bank revolving line of credit was $10,100,000 and $9,700,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.90% and 1.25% at June 30, 2016 and 0.82% and 1.16% per annum at June 30, 2015. At June 30, 2016, available for future borrowing under this credit agreement was $9,543,000.

[0001628280-16-019274:notes:52]
Covenant Compliance

[0001628280-16-019274:notes:53]
The new credit agreement with Bank of America contain customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The new credit agreement contain certain financial covenants, including the following:

[0001628280-16-019274:notes:54]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001628280-16-019274:notes:55]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; |

[0001628280-16-019274:notes:56]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $30,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-16-019274:notes:57]
As of June 30, 2016, total assets of $934,625,000 collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of June 30, 2016, total assets collateralizing the term loan with Bank of America under the new credit agreement were $59,258,000. As of June 30, 2015, the total assets of $1,045,408,000 collateralized the line of credits with Bank of America which represents all the assets of the Company except for three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of June 30, 2015, total assets collateralizing the term loan with Bank of America was $17,354,000. As of June 30, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

[0001628280-16-019274:notes:58]
As of June 30, 2016 and 2015, the land and building located in Bade, Taiwan with a value of $26,804,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at June 30, 2016.

[0001628280-16-019274:notes:59]
Debt Maturities

[0001628280-16-019274:notes:60]
The following table as of June 30, 2016, summarizes future minimum principal payments on the Company’s debts excluding capital leases (in thousands):

[0001628280-16-019274:notes:61]
| Fiscal Years Ending June 30, |  |
| 2017 | $ | 53,589 |  |
| 2018 | 10,000 |  |
| 2019 | 10,000 |  |
| 2020 | 10,000 |  |
| 2021 | 10,000 |  |
| Thereafter | — |  |
| Total | $ | 93,589 |  |

[0001628280-16-019274:notes:62]
In July 2016, the Company received $50,000,000 term loan proceeds from Bank of America and paid down the outstanding amounts under the revolving line of credit with Bank of America. The above table presents the future minimum principal payments on the Company's debts based on the latest credit agreements with Bank of America and CTBC Bank as of June 30, 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-019274:notes:63]
Stock-based Compensation and Stockholders’ Equity

[0001628280-16-019274:notes:64]
Share Repurchase Program

[0001628280-16-019274:notes:65]
In July 2016, the Company’s Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of the Company’s common stock in the open market or in private transactions during the next twelve months at prevailing market prices. Repurchases will be made under the program using the Company’s own cash resources. This share repurchase program does not obligate the Company to acquire any particular amount of common stock, and it may be suspended at any time at the Company’s discretion. In July 2016, the Company purchased 513,194 shares of the Company's common stock in the open market at a weighted average price of $19.97 for $10,259,000.

[0001628280-16-019274:notes:66]
Equity Incentive Plan

[0001628280-16-019274:notes:67]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, restricted stock units and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of such date, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006" Plan). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan but that are forfeited in the future will become available for use under the 2016 Plan. In addition, 1,153,412 shares of common stock originally reserved for issuance under the 2006 Plan were cancelled upon the adoption of the 2016 Plan. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and restricted stock units generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of June 30, 2016, the Company had 4,294,003 authorized shares available for future issuance under the 2016 Plan.

[0001628280-16-019274:notes:68]
Determining Fair Value

[0001628280-16-019274:notes:69]
The Company's fair value of restricted stock units is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-16-019274:notes:70]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and the Company's historical experience.

[0001628280-16-019274:notes:71]
Expected Volatility—Expected volatility is based on a combination of the Company's implied and historical volatility.

[0001628280-16-019274:notes:72]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001628280-16-019274:notes:73]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001628280-16-019274:notes:74]
Estimated Forfeitures—The estimated forfeiture rate is based on the Company’s historical forfeiture rates and the estimate is revised in subsequent periods if actual forfeitures differ from the estimate.

[0001628280-16-019274:notes:75]
The fair value of stock option grants for the years ended June 30, 2016, 2015 and 2014 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-16-019274:notes:76]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Risk-free interest rate | 1.37% - 1.57% |  |  | 1.35% - 1.76% |  |  | 1.53% - 1.90% |  |
| Expected life | 5.31 - 5.33 years |  |  | 5.40 - 5.44 years |  |  | 5.49 - 5.58 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 46.65% - 50.89% |  |  | 46.93% - 49.31% |  |  | 43.48% - 50.07% |  |
| Weighted-average fair value | $ | 12.07 |  |  | $ | 12.72 |  |  | $ | 7.23 |  |

[0001628280-16-019274:notes:77]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the years ended June 30, 2016, 2015 and 2014 (in thousands):

[0001628280-16-019274:notes:78]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Cost of sales | $ | 1,098 |  |  | $ | 901 |  |  | $ | 941 |  |
| Research and development | 10,178 |  |  | 8,643 |  |  | 6,783 |  |
| Sales and marketing | 1,841 |  |  | 1,553 |  |  | 1,260 |  |
| General and administrative | 3,014 |  |  | 2,602 |  |  | 2,078 |  |
| Stock-based compensation expense before taxes | 16,131 |  |  | 13,699 |  |  | 11,062 |  |
| Income tax impact | (4,503 | ) |  | (3,791 | ) |  | (2,426 | ) |
| Stock-based compensation expense, net | $ | 11,628 |  |  | $ | 9,908 |  |  | $ | 8,636 |  |

[0001628280-16-019274:notes:79]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options and vesting of restricted stock units in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $3,727,000, $11,157,000 and $7,041,000 of excess tax benefits recorded in additional paid-in capital in the years ended June 30, 2016, 2015 and 2014, respectively. The Company had excess tax benefits classified as cash from financing activities of $2,855,000, $8,089,000 and $2,992,000 in the years ended June 30, 2016, 2015 and 2014, respectively, for options issued since July 1, 2006.

[0001628280-16-019274:notes:80]
As of June 30, 2016, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted to employees and non-employee directors was $37,533,000, which will be recognized over a weighted-average vesting period of approximately 2.29 years.

[0001628280-16-019274:notes:81]
Stock Option Activity

[0001628280-16-019274:notes:82]
The following table summarizes stock option activity during the years ended June 30, 2016, 2015 and 2014 under all plans:

[0001628280-16-019274:notes:83]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2013 (8,731,818 shares exercisable at weighted average exercise price of $9.66 per share) |  | 12,206,178 |  |  | $ | 10.83 |  |  |  |  |  |
| Granted (weighted average fair value of $7.23) |  | 1,808,006 |  |  | 15.87 |  |  |  |  |  |
| Exercised |  | (2,863,878 | ) |  | 8.36 |  |  |  |  |  |
| Forfeited |  | (244,704 | ) |  | 14.25 |  |  |  |  |  |
| Balance as of June 30, 2014 (7,558,631 shares exercisable at weighted average exercise price of $11.05 per share) |  | 10,905,602 |  |  | 12.24 |  |  |  |  |  |
| Granted (weighted average fair value of $12.72) |  | 1,093,920 |  |  | 28.28 |  |  |  |  |  |
| Exercised |  | (2,124,401 | ) |  | 10.99 |  |  |  |  |  |
| Forfeited |  | (172,278 | ) |  | 18.68 |  |  |  |  |  |
| Balance as of June 30, 2015 (7,208,475 shares exercisable at weighted average exercise price of $12.24 per share) |  | 9,702,843 |  |  | 14.21 |  |  |  |  |  |
| Granted (weighted average fair value of $12.07) |  | 316,580 |  |  | 26.86 |  |  |  |  |  |
| Exercised |  | (1,013,430 | ) |  | 12.03 |  |  |  |  |  |
| Forfeited |  | (45,126 | ) |  | 19.45 |  |  |  |  |  |
| Balance as of June 30, 2016 |  | 8,960,867 |  |  | $ | 14.88 |  |  | 5.20 |  | $ | 93,661 |  |
| Options vested and expected to vest at June 30, 2016 |  | 8,887,498 |  |  | $ | 14.79 |  |  | 5.18 |  | $ | 93,566 |  |
| Options vested and exercisable at June 30, 2016 |  | 7,495,131 |  |  | $ | 13.35 |  |  | 4.63 |  | $ | 87,796 |  |

[0001628280-16-019274:notes:84]
The total pretax intrinsic value of options exercised during the years ended June 30, 2016, 2015 and 2014 was $18,016,000, $48,077,000 and $30,165,000, respectively.

[0001628280-16-019274:notes:85]
Additional information regarding options outstanding as of June 30, 2016, is as follows:

[0001628280-16-019274:notes:86]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $4.63 - 7.91 |  | 933,694 |  |  | 2.41 |  | $ | 6.29 |  |  | 933,694 |  |  | $ | 6.29 |  |
| 7.94 - 9.24 |  | 924,705 |  |  | 3.29 |  | 8.61 |  |  | 908,080 |  |  | 8.60 |  |
| 9.72 - 10.66 |  | 1,309,468 |  |  | 3.69 |  | 10.39 |  |  | 1,245,451 |  |  | 10.41 |  |
| 10.68 - 12.50 |  | 907,879 |  |  | 5.36 |  | 11.78 |  |  | 846,813 |  |  | 11.79 |  |
| 12.68 - 14.23 |  | 1,307,560 |  |  | 5.20 |  | 13.76 |  |  | 1,138,326 |  |  | 13.69 |  |
| 15.22 - 17.29 |  | 923,677 |  |  | 5.51 |  | 16.32 |  |  | 923,677 |  |  | 16.32 |  |
| 17.69 - 18.93 |  | 1,134,968 |  |  | 6.36 |  | 18.56 |  |  | 829,328 |  |  | 18.57 |  |
| 20.70 - 26.75 |  | 1,125,706 |  |  | 8.01 |  | 24.83 |  |  | 562,044 |  |  | 24.04 |  |
| 27.28 - 37.06 |  | 357,710 |  |  | 8.99 |  | 32.80 |  |  | 84,593 |  |  | 35.09 |  |
| 39.19 |  | 35,500 |  |  | 8.62 |  | 39.19 |  |  | 23,125 |  |  | 39.19 |  |
| $4.63 - $39.19 |  | 8,960,867 |  |  | 5.20 |  | $ | 14.88 |  |  | 7,495,131 |  |  | $ | 13.35 |  |

[0001628280-16-019274:notes:87]
Restricted Stock Unit Activity

[0001628280-16-019274:notes:88]
In January 2015, the Company began to grant restricted stock units to employees. The Company grants restricted stock units to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. Restricted stock units are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting.

[0001628280-16-019274:notes:89]
The following table summarizes restricted stock unit activity during the years ended June 30, 2016 and 2015 under all plans:

[0001628280-16-019274:notes:90]
|  |  | Restricted Stock UnitsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 |  | — |  |  | $ | — |  |  |  |
| Granted |  | 374,720 |  |  | $ | 35.82 |  |  |  |
| Vested |  | (14,685 | ) |  | $ | 35.23 |  |  |  |
| Forfeited |  | (56,711 | ) |  | $ | 34.90 |  |  |  |
| Balance as of June 30, 2015 |  | 303,324 |  |  | $ | 36.02 |  |  |  |
| Granted |  | 845,870 |  |  | $ | 28.45 |  |  |  |
| Vested |  | (177,707 | ) |  | $ | 31.80 |  |  |  |
| Forfeited |  | (44,504 | ) |  | $ | 29.72 |  |  |  |
| Balance as of June 30, 2016 |  | 926,983 |  |  | $ | 30.23 |  |  | $ | 23,036 |  |

[0001628280-16-019274:notes:91]
The total pretax intrinsic value of restricted stock units vested was $4,872,743 and $486,000 for the years ended June 30, 2016 and 2015, respectively. In fiscal years 2016 and 2015, upon vesting, 177,707 and 14,685 shares of restricted stock units were partially net share-settled such that the Company withheld 65,164 and 5,278 shares, respectively, with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock units on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $1,786,000 and $175,000 for the years ended June 30, 2016 and 2015, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.

[0001628280-16-019274:notes:92]
Restricted Stock Awards

[0001628280-16-019274:notes:93]
Restricted stock awards are share awards that provide the rights to a set number of shares of the Company’s stock on the grant date. In August 2008, the Compensation Committee of the Board of Directors of the Company (the “Committee”) approved the terms of an agreement (the “Option Exercise Agreement”) with Charles Liang, a director and President and Chief Executive Officer of the Company, pursuant to which Mr. Liang exercised a fully vested option previously granted to him for the purchase of 925,000 shares. The option was exercised using a “net-exercise” procedure in which he was issued a number of shares representing the spread between the option exercise price and the then current market value of the shares subject to the option (898,205 shares based upon the market value as of the date of exercise). The shares issued upon exercise of the option are subject to vesting over five years. Vesting of the shares subject to the award may accelerate in certain circumstances pursuant to the terms of the Option Exercise Agreement. The Company determined that there is no incremental fair value of the option exchanged for the awards. The awards were fully vested as of June 30, 2014.

[0001628280-16-019274:notes:94]
Restricted Stock Award Activity

[0001628280-16-019274:notes:95]
The following table summarizes the Company’s restricted stock award activity for the year ended June 30, 2014:

[0001628280-16-019274:notes:96]
|  | Restricted Stock Awards |
|  | Numberof Shares |  | WeightedAverageGrant DateFair ValuePer Share |
| Nonvested stock at June 30, 2013 | 179,641 |  |  | $ | 10.66 |  |
| Granted | 3,500 |  |  | 14.23 |  |
| Vested | (183,141 | ) |  | 10.73 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2014 | — |  |  | — |  |

[0001628280-16-019274:notes:97]
The Company had no restricted stock award activity for the years ended June 30, 2016 and 2015. The total pretax intrinsic value of restricted stock awards vested was $1,965,000 for the year ended June 30, 2014. In fiscal year 2014, upon vesting, 183,141 shares of restricted stock awards were partially net share-settled such that the Company withheld 51,583 shares with value equivalent to the minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock awards on their vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities were $681,000 for the year ended June 30, 2014, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. There are no unvested restricted stock awards at June 30, 2016 and 2015.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-16-019274:notes:98]
Net Income Per Common Share

[0001628280-16-019274:notes:99]
In fiscal years 2016 and 2015, basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units.

[0001628280-16-019274:notes:100]
In fiscal year 2014, the Company had restricted share awards outstanding which were subject to repurchase and settled in shares of common stock upon vesting. Such awards had the nonforfeitable right to receive dividends on an equal basis with common stock and therefore were considered participating securities that must be included in the calculation of net income per share using the two-class method. Under the two-class method, basic and diluted net income per common share was determined by calculating net income per share for common stock and participating securities based on participation rights in undistributed earnings. Diluted net income per common share was calculated by adjusting outstanding shares, assuming any dilutive effects of stock incentive awards calculated using the treasury stock method.

[0001628280-16-019274:notes:101]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and restricted stock units. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-16-019274:notes:102]
The following table sets forth the Company’s cash equivalents and long-term investments as of June 30, 2016 and 2015 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-16-019274:notes:103]
| June 30, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 315 |  |  | $ | — |  |  | $ | — |  |  | $ | 315 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total assets measured at fair value | $ | 315 |  |  | $ | — |  |  | $ | 2,643 |  |  | $ | 2,958 |  |
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total assets measured at fair value | $ | 310 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,943 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-16-019274:notes:104]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for fiscal years 2016 and 2015 (in thousands):

[0001628280-16-019274:notes:105]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |
| Balance as of beginning of year | $ | 2,633 |  |  | $ | 2,647 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | 10 |  |  | (14 | ) |
| Sales and settlements at par | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |
| Balance as of end of year | $ | 2,643 |  |  | $ | 2,633 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-019274:notes:106]
Fair Value Disclosure

[0001628280-16-019274:notes:107]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy as the determination of their fair values is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy as the determination of their fair values was not based on observable inputs as of June 30, 2016 and 2015. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of June 30, 2016 and 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001628280-16-019274:notes:108]
The above table excludes $180,426,000 and $94,901,000 of cash and $2,133,000 and $1,130,000 of certificates of deposit held by the Company as of June 30, 2016 and 2015, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in fiscal year 2016 and 2015.

[0001628280-16-019274:notes:109]
The following is a summary of the Company’s long-term investments as of June 30, 2016 and 2015 (in thousands):

[0001628280-16-019274:notes:110]
|  | June 30, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |
|  | June 30, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |

[0001628280-16-019274:notes:111]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2016 and 2015, short-term and long-term debt of $93,589,000 and $94,412,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001628280-16-019274:notes:112]
Foreign Currency Translation

[0001628280-16-019274:notes:113]
The functional currency of the Company’s international subsidiaries is the U.S. dollar. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in the local currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the local currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the local currency are remeasured into U.S. dollars at the average exchange rates during the period. Accordingly, remeasurement of foreign currency accounts and foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001628280-16-019274:notes:114]
Long-Lived Assets

[0001628280-16-019274:notes:115]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-019274:notes:116]
Income Taxes

[0001628280-16-019274:notes:117]
The components of income before income tax provision for the years ended June 30, 2016, 2015 and 2014 are as follows (in thousands):

[0001628280-16-019274:notes:118]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| United States | $ | 94,335 |  |  | $ | 118,083 |  |  | $ | 66,152 |  |
| Foreign | 11,092 |  |  | 27,813 |  |  | 13,442 |  |
| Income before income tax provision | $ | 105,427 |  |  | $ | 145,896 |  |  | $ | 79,594 |  |

[0001628280-16-019274:notes:119]
The income tax provision for the years ended June 30, 2016, 2015 and 2014, consists of the following (in thousands):

[0001628280-16-019274:notes:120]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Current: |  |  |  |  |  |
| Federal | $ | 28,556 |  |  | $ | 33,496 |  |  | $ | 20,102 |  |
| State | 1,954 |  |  | 1,980 |  |  | 624 |  |
| Foreign | 10,843 |  |  | 10,960 |  |  | 5,252 |  |
|  | 41,353 |  |  | 46,436 |  |  | 25,978 |  |
| Deferred: |  |  |  |  |  |
| Federal | (6,890 | ) |  | (1,989 | ) |  | 122 |  |
| State | (1,080 | ) |  | 70 |  |  | (472 | ) |
| Foreign | 23 |  |  | (484 | ) |  | (191 | ) |
|  | (7,947 | ) |  | (2,403 | ) |  | (541 | ) |
| Income tax provision | $ | 33,406 |  |  | $ | 44,033 |  |  | $ | 25,437 |  |

[0001628280-16-019274:notes:121]
The Company’s net deferred tax assets as of June 30, 2016 and 2015 consist of the following (in thousands):

[0001628280-16-019274:notes:122]
|  | June 30, |
|  | 2016 |  | 2015 |
| Warranty accrual | $ | 2,213 |  |  | $ | 2,493 |  |
| Marketing fund accrual | 1,792 |  |  | 1,163 |  |
| Inventory valuation | 12,214 |  |  | 10,158 |  |
| Stock-based compensation | 5,186 |  |  | 4,800 |  |
| Accrued vacation and bonus | 2,544 |  |  | 1,230 |  |
| Payable to foreign subsidiaries | 1,824 |  |  | 1,716 |  |
| Deferred revenue | 3,221 |  |  | 425 |  |
| Other | 2,514 |  |  | 1,003 |  |
| Total deferred income tax assets | 31,508 |  |  | 22,988 |  |
| Deferred tax liabilities-depreciation and other | (3,048 | ) |  | (628 | ) |
| Deferred income tax assets-net | $ | 28,460 |  |  | $ | 22,360 |  |

[0001628280-16-019274:notes:123]
The cumulative undistributed earnings of our foreign subsidiaries of $42,515,000 at June 30, 2016 are considered to be indefinitely reinvested and accordingly, no provisions for federal and state income taxes have been provided thereon. The Company determined that the calculation of the amount of unrecognized deferred tax liability related to these cumulative unremitted earnings was not practicable. Upon distribution of those earnings in the form of dividends or otherwise, the Company would be subject to both United States income taxes (subject to an adjustment for foreign tax credits) and withholding taxes payable to various foreign countries.

[0001628280-16-019274:notes:124]
The following is a reconciliation for the years ended June 30, 2016, 2015 and 2014, of the statutory rate to the Company’s effective federal tax rate:

[0001628280-16-019274:notes:125]
|  |  | Years Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Tax at statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income tax, net of federal tax benefit |  | 3.3 |  |  | 3.0 |  |  | 3.3 |  |
| Foreign tax rate differences |  | 0.6 |  |  | (3.0 | ) |  | (2.5 | ) |
| Research and development tax credit |  | (7.2 | ) |  | (3.4 | ) |  | (4.0 | ) |
| Qualified production activity deduction |  | (2.8 | ) |  | (1.3 | ) |  | (1.8 | ) |
| Stock based compensation |  | 2.3 |  |  | 2.2 |  |  | 4.5 |  |
| Uncertain tax positions |  | (1.6 | ) |  | (0.7 | ) |  | (2.1 | ) |
| Subpart F income inclusion |  | (2.9 | ) |  | (2.9 | ) |  | (3.9 | ) |
| Foreign withholding tax |  | 3.3 |  |  | 3.0 |  |  | 4.1 |  |
| Federal tax return to provision adjustment |  | 0.4 |  |  | 0.2 |  |  | (0.7 | ) |
| Other |  | 1.3 |  |  | (1.9 | ) |  | 0.1 |  |
| Effective tax rate |  | 31.7 | % |  | 30.2 | % |  | 32.0 | % |

[0001628280-16-019274:notes:126]
As of June 30, 2016, the Company had state research and development tax credit carryforwards of $9,898,000. The state research and development tax credits will carryforward indefinitely to offset future state income taxes. $6,837,000 of the state research and development tax credit carryforwards were attributable to excess tax deductions from stock option exercises, and were not included in the deferred tax assets shown above. The benefit of these carryforwards will be credited to equity when realized.

[0001628280-16-019274:notes:127]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001628280-16-019274:notes:128]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2013 | $ | 8,089 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,120 |  |
| For prior years’ tax positions | 132 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (1,726 | ) |
| For prior year' tax positions | — |  |
| Balance at June 30, 2014 | 9,615 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,855 |  |
| For prior years’ tax positions | 793 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (971 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2015 | 13,292 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,167 |  |
| For prior years’ tax positions | 2,074 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (2,138 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2016 | $ | 19,395 |  |

[0001628280-16-019274:notes:129]
__________________________

[0001628280-16-019274:notes:130]
| * | excludes interest, penalties, federal benefit of state reserves |

[0001628280-16-019274:notes:131]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, is $16,723,000 and $10,971,000 as of June 30, 2016 and 2015, respectively.

[0001628280-16-019274:notes:132]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes in the consolidated statements of operations. As of June 30, 2016 and 2015, the Company had accrued $1,042,000 and $898,000 for the payment of interest and penalties relating to unrecognized tax benefits, respectively. During fiscal years 2016, 2015 and 2014, there was no material change in the total amount of the liability for accrued interest and penalties related to the unrecognized tax benefits.

[0001628280-16-019274:notes:133]
The Company is subject to United States federal income tax as well as income taxes in many state and foreign jurisdictions.  The 2012 and 2013 federal tax returns are currently under the IRS examination. The Company has responded to Information Document Requests ("IDRs"), issued by the Internal Revenue Service ("IRS"). No adjustment has been proposed by the IRS as of June 30, 2016. The Company is also currently under audit in Taiwan. The Taiwan Tax Authority issued income tax assessments for tax years 2013 and 2014 related to the local income tax exemption regime which the Company has participated in. The Company is currently in the process of appeals. While management believes that the Company has adequately provided reserves for all uncertain tax positions, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001628280-16-019274:notes:134]
The federal statute of limitations remain open in general for tax years 2012 through 2015. The state statute of limitations remain open in general for tax years 2011 through 2015. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2009 through 2015. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:IncomeTaxPolicyTextBlock

[0001628280-16-019274:notes:135]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying currently enacted tax laws. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001628280-16-019274:notes:136]
The Company recognizes the tax liability for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related change in its tax provision during the period in which the Company makes such determination.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-16-019274:notes:137]
Inventory

[0001628280-16-019274:notes:138]
Inventory as of June 30, 2016 and 2015 consisted of the following (in thousands):

[0001628280-16-019274:notes:139]
|  | June 30, |
|  | 2016 |  | 2015 |
| Finished goods | $ | 351,209 |  |  | $ | 384,647 |  |
| Work in process | 19,105 |  |  | 23,214 |  |
| Purchased parts and raw materials | 78,666 |  |  | 55,632 |  |
| Total inventory | $ | 448,980 |  |  | $ | 463,493 |  |


## us-gaap:InventoryPolicyTextBlock

[0001628280-16-019274:notes:140]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units based upon the usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-16-019274:notes:141]
Accounts Receivable Allowances

[0001628280-16-019274:notes:142]
The Company has established an allowance for doubtful accounts and an allowance for sales returns. The allowance for doubtful accounts is based upon the credit risk of specific customers, historical trends related to past losses and other relevant factors. The Company also provides its customers with product return rights. A provision for such returns is provided for in the same period that the related sales are recorded based upon contractual return rights and historical trends. Accounts receivable allowances as of June 30, 2016, 2015 and 2014, consisted of the following (in thousands):


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-019274:notes:143]
Recently Issued Accounting Pronouncements

[0001628280-16-019274:notes:144]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:notes:145]
In April 2015, the FASB issued an amendment to the accounting guidance related to presentation of debt issuance costs. The amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The amendment clarified that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The amendment is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:notes:146]
In July 2015, the FASB issued an amendment to the authoritative guidance related to inventory measurement. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:notes:147]
In November 2015, the FASB issued an amendment to the accounting guidance related to balance sheet classification of deferred taxes. The amendment requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. Early adoption is permitted as of the beginning of an interim or annual reporting period. The amendment is effective for the Company on July 1, 2017. The Company has adopted this guidance on a prospective basis for the fiscal year ended June 30, 2016. Adoption of this guidance resulted in a reclassification of our net current deferred tax asset of $17,869,000 to the net non-current deferred tax asset in our Consolidated Balance Sheet as of June 30, 2016. No prior periods were retrospectively adjusted.

[0001628280-16-019274:notes:148]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:notes:149]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-16-019274:notes:150]
Summary of Significant Accounting Policies

[0001628280-16-019274:notes:151]
Organization

[0001628280-16-019274:notes:152]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in San Jose, California, the Netherlands, Taiwan, China and Japan.

[0001628280-16-019274:notes:153]
Use of Estimates

[0001628280-16-019274:notes:154]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, product warranty accruals, stock-based compensation, impairment of long-term investments and income taxes. Actual results could differ from those estimates.

[0001628280-16-019274:notes:155]
Fair Value of Financial Instruments

[0001628280-16-019274:notes:156]
The Company accounts for certain assets and liabilities at fair value. Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents and long-term investments are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms. The hierarchy below lists three levels of fair value based on the extent to which inputs used in measuring fair value are observable in the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001628280-16-019274:notes:157]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001628280-16-019274:notes:158]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001628280-16-019274:notes:159]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001628280-16-019274:notes:160]
Long-term Investments

[0001628280-16-019274:notes:161]
The Company classifies its long-term investments in auction-rate securities ("auction rate securities") as long-term available-for-sale investments. Auction rate securities consist of municipal securities. The discounted cash flow model is used to estimate the fair value of the auction rate securities. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a component of accumulated other comprehensive income, net of tax.

[0001628280-16-019274:notes:162]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units based upon the usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected. During fiscal years 2016, 2015 and 2014, the Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $9,313,000, $5,928,000 and $2,254,000, respectively.

[0001628280-16-019274:notes:163]
Property, Plant and Equipment

[0001628280-16-019274:notes:164]
For assets acquired and financed under capital leases, the present value of the future minimum lease payments is recorded at the date of acquisition as property and equipment with the corresponding amount recorded as a capital lease obligation, and the amortization is computed on a straight-line basis over the shorter of lease term or estimated useful life.

[0001628280-16-019274:notes:165]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge has been recorded in any of the periods presented.

[0001628280-16-019274:notes:166]
Revenue Recognition

[0001628280-16-019274:notes:167]
The Company recognizes revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer if all other revenue recognition criteria have been met. The Company’s standard arrangement with its customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination if all other revenue recognition criteria have been met. The Company also has a few customers who have acceptance provisions for which revenue is recognized when customers provide the necessary acceptance. The Company generally does not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, the Company regularly reviews its history of actual returns for each major product line. The Company also communicates regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with distributors.

[0001628280-16-019274:notes:168]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. The Company also makes estimates of the uncollectibility of accounts receivable, analyzing accounts receivable and historical bad debts, customer concentrations, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, the Company evaluates aged items in the accounts receivable aging report and provides an allowance in an amount the Company deems adequate for doubtful accounts. Our provision for bad debt was $1,278,000, $326,000 and $1,476,000 in fiscal years 2016, 2015 and 2014, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than the Company's historical experience, or if other circumstances arise, the Company's estimates of the recoverability of amounts due to the Company could be overstated, and additional allowances could be required, which could have an adverse impact on its reported operating expenses. The Company provides for price protection to certain distributors. The Company assesses the market competition and product technology obsolescence, and makes price adjustments based on its judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on the distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time the Company reduces the product prices.

[0001628280-16-019274:notes:169]
Multiple-element arrangements. The Company’s multiple-element product offerings include server systems with embedded software and support, which are considered separate units of accounting.

[0001628280-16-019274:notes:170]
The Company allocates revenue to each element in a multiple-element arrangement based upon their relative selling price. When applying the relative selling price method, the Company determines the selling price for each deliverable using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, the Company uses its best estimate of selling price for that deliverable. Revenue allocated to each element is then recognized when all the revenue recognition criteria are met for each element.

[0001628280-16-019274:notes:171]
The Company determines VSOE based on its normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, the Company requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range.

[0001628280-16-019274:notes:172]
In most instances, the Company is not able to establish VSOE for all deliverables in an arrangement with multiple elements. This may be due to the Company infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history. When VSOE cannot be established, the Company attempts to establish the selling price for each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, the Company’s product solutions differ from that of its peers and contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, the Company is typically unable to determine TPE.

[0001628280-16-019274:notes:173]
When the Company is unable to establish selling price using VSOE or TPE, the Company uses estimated selling price (“ESP”) in its allocation of the arrangement consideration. The objective of ESP is to determine the price at which the Company would transact a sale if the product or service were sold on a stand-alone basis. ESP is generally used for offerings that are not typically sold on a stand-alone basis or for new or highly customized offerings.

[0001628280-16-019274:notes:174]
The Company determines ESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices. The determination of ESP is made through consultation with and approval by the Company’s management.

[0001628280-16-019274:notes:175]
The Company regularly reviews VSOE, TPE and ESP, as well as the establishment and updates of these estimates. There was no material impact on revenues during fiscal year 2016 nor does the Company expect a material impact in the near term from changes in VSOE, TPE or ESP.

[0001628280-16-019274:notes:176]
Services revenue. Services revenue mainly consists of extended warranty and on-site services. Extended warranty and on-site services are offered as part of multiple-element arrangements. Revenue related to extended warranty and on-site services is deferred and recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001628280-16-019274:notes:177]
Product Warranties

[0001628280-16-019274:notes:178]
The Company offers product warranties ranging from 15 to 39 months against any defective products. The Company accrues for estimated returns of defective products at the time revenue is recognized based on historical warranty experience and recent trends. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. If in future periods the Company experiences or anticipates an increase or decrease in warranty claims as a result of new product introductions or changes in unit volumes compared with its historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, the Company intends to adjust its estimates accordingly. The following table presents for the years ended June 30, 2016, 2015 and 2014, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities (in thousands):

[0001628280-16-019274:notes:179]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Balance, beginning of year | $ | 7,700 |  |  | $ | 7,083 |  |  | $ | 6,472 |  |
| Provision for warranty | 17,470 |  |  | 15,771 |  |  | 14,175 |  |
| Costs charged to accrual | (17,245 | ) |  | (14,950 | ) |  | (13,950 | ) |
| Change in estimated liability for pre-existing warranties | (2,109 | ) |  | (204 | ) |  | 386 |  |
| Balance, end of year | $ | 5,816 |  |  | $ | 7,700 |  |  | $ | 7,083 |  |

[0001628280-16-019274:notes:180]
Software Development Costs

[0001628280-16-019274:notes:181]
Software development costs are included in research and development and are expensed as incurred. Software development costs are capitalized beginning when technological feasibility has been established and ending when a product is available for general release to customers. To date, the period between achieving technological feasibility and the issuance of such software has been short and software development costs qualifying for capitalization have been insignificant.

[0001628280-16-019274:notes:182]
Research and Development

[0001628280-16-019274:notes:183]
Research and development costs are expensed as incurred and consist primarily of salaries, consulting services, other direct expenses and other engineering expenses. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $6,904,000, $6,318,000 and $3,132,000 for the years ended June 30, 2016, 2015 and 2014, respectively.

[0001628280-16-019274:notes:184]
Cooperative Marketing Arrangements

[0001628280-16-019274:notes:185]
The Company has arrangements with resellers of its products to reimburse the resellers for cooperative marketing costs meeting specified criteria. The Company accrues the cooperative marketing costs based on these arrangements and its estimate for resellers’ claims for marketing activities. The Company records marketing costs meeting such specified criteria within sales and marketing expenses in the consolidated statements of operations. For those marketing costs that do not meet the specified criteria, the amounts are recorded as a reduction to sales in the consolidated statements of operations.

[0001628280-16-019274:notes:186]
Total cooperative marketing costs charged to sales and marketing expenses for the years ended June 30, 2016, 2015 and 2014, were $2,506,000, $1,995,000 and $2,058,000, respectively. Total amounts recorded as reductions to sales for the years ended June 30, 2016, 2015 and 2014, were $3,879,000, $4,200,000 and $2,829,000, respectively.

[0001628280-16-019274:notes:187]
Advertising costs are expensed as incurred. Total advertising and promotional expenses, including cooperative marketing payments, were $10,477,000, $7,263,000 and $5,183,000 for the years ended June 30, 2016, 2015 and 2014, respectively.

[0001628280-16-019274:notes:188]
Stock-Based Compensation

[0001628280-16-019274:notes:189]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors, including employee stock options and restricted stock units. The Company is required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of our restricted stock units is based on the closing market price of the Company's common stock on the date of grant. The Company estimated the fair value of stock options granted using a Black-Scholes option pricing model and a single option award approach. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-16-019274:notes:190]
The expected term represents the period that the Company's stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and historical experience. The expected volatility is based on a combination of the Company's implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-16-019274:notes:191]
Shipping and Handling Fees

[0001628280-16-019274:notes:192]
The Company incurred shipping costs of $2,535,000, $2,090,000 and $1,605,000 for the years ended June 30, 2016, 2015 and 2014, respectively, which were included in sales and marketing expenses.

[0001628280-16-019274:notes:193]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001628280-16-019274:notes:194]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Basic net income per common share calculation |  |  |  |  |  |
| Net income | $ | 72,021 |  |  | $ | 101,863 |  |  | $ | 54,157 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | — |  |  | (36 | ) |
| Net income attributable to common shares—basic | $ | 72,021 |  |  | $ | 101,863 |  |  | $ | 54,121 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 47,917 |  |  | 46,434 |  |  | 43,599 |  |
| Basic net income per common share | $ | 1.50 |  |  | $ | 2.19 |  |  | $ | 1.24 |  |
| Diluted net income per common share calculation |  |  |  |  |  |
| Net income | $ | 72,021 |  |  | $ | 101,863 |  |  | $ | 54,157 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | — |  |  | (34 | ) |
| Net income attributable to common shares—diluted | $ | 72,021 |  |  | $ | 101,863 |  |  | $ | 54,123 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 47,917 |  |  | 46,434 |  |  | 43,599 |  |
| Dilutive effect of options and restricted stock units to purchase common stock | 3,919 |  |  | 3,660 |  |  | 2,913 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 51,836 |  |  | 50,094 |  |  | 46,512 |  |
| Diluted net income per common share | $ | 1.39 |  |  | $ | 2.03 |  |  | $ | 1.16 |  |

[0001628280-16-019274:notes:195]
For the years ended June 30, 2016, 2015 and 2014, the Company had stock options and restricted stock units outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,196,000, 3,805,000 and 3,465,000 for the years ended June 30, 2016, 2015 and 2014, respectively.

[0001628280-16-019274:notes:196]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 35.2%, 28.7%, and 23.4% of total purchases for the years ended June 30, 2016, 2015 and 2014, respectively. Ablecom, a related party of the Company as noted in Note 9, accounted for 11.5%, 12.6% and 16.1% of total purchases for the years ended June 30, 2016, 2015 and 2014, respectively.

[0001628280-16-019274:notes:197]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents and long-term investments and accounts receivable. In fiscal years 2016 and 2015, one customer accounted for 10.9% and 10.1%, respectively, of net sales. No single customer accounted for 10% or more of net sales in fiscal year 2014.  No customer accounted for 10% or more of accounts receivable as of June 30, 2016 and 2015.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001628280-16-019274:notes:198]
Other Long-term Liabilities

[0001628280-16-019274:notes:199]
Other long-term liabilities as of June 30, 2016 and 2015 consisted of the following (in thousands):

[0001628280-16-019274:notes:200]
|  | June 30, |
|  | 2016 |  | 2015 |
| Deferred revenue-net of current portion (1) | $ | 21,940 |  |  | $ | 4,276 |  |
| Accrued unrecognized tax benefits including related interests and penalties-net of current portion | 16,056 |  |  | 10,184 |  |
| Accrued warranty costs-net of current portion | 1,313 |  |  | — |  |
| Others | 1,294 |  |  | 1,224 |  |
| Total other long-term liabilities | $ | 40,603 |  |  | $ | 15,684 |  |

[0001628280-16-019274:notes:201]
(1) As of June 30, 2016 and 2015, deferred revenue-net of current portion consist primarily of a deferred extended warranty and on-site service revenue of $21,265,000 and $4,276,000, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-16-019274:notes:202]
Retirement Plans

[0001628280-16-019274:notes:203]
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the years ended June 30, 2016, 2015 and 2014.

[0001628280-16-019274:notes:204]
Beginning in March 2003, employees of Super Micro Computer, B.V. have the option to deduct a portion of their gross wages and invest the amount in a defined contribution plan. The Company has agreed to match 10% of the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the years ended June 30, 2016, 2015 and 2014, the Company’s matching contribution was $250,000, $200,000 and $198,000, respectively.

[0001628280-16-019274:notes:205]
The Company maintains a defined benefit pension plan for Super Micro Computer, Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. Plan assets of the funded defined benefit pension plan are deposited into a government-managed account in which the Company has no control over investment strategy. For the years ended June 30, 2016, 2015 and 2014, the Company’s contribution was $1,003,000, $862,000 and $740,000, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-16-019274:notes:206]
Property, Plant, and Equipment

[0001628280-16-019274:notes:207]
Property, plant and equipment as of June 30, 2016 and 2015 consisted of the following (in thousands):

[0001628280-16-019274:notes:208]
|  | June 30, |
|  | 2016 |  | 2015 |
| Land (1) | $ | 70,454 |  |  | $ | 63,962 |  |
| Buildings (1) | 71,665 |  |  | 51,959 |  |
| Building and leasehold improvements (1) | 10,941 |  |  | 8,323 |  |
| Buildings construction in progress (1) | 15,803 |  |  | 25,572 |  |
| Machinery and equipment | 53,282 |  |  | 40,689 |  |
| Furniture and fixtures | 10,364 |  |  | 7,421 |  |
| Purchased software (2) | 13,920 |  |  | 3,343 |  |
| Purchased software construction in progress (2) | 532 |  |  | 8,567 |  |
|  | 246,961 |  |  | 209,836 |  |
| Accumulated depreciation and amortization | (59,012 | ) |  | (46,798 | ) |
| Property, plant and equipment, net | $ | 187,949 |  |  | $ | 163,038 |  |

[0001628280-16-019274:notes:209]
(1) In connection with the purchase of property located in San Jose, California for the Company's Green Computing Park, the Company continues to engage several contractors for the development and construction of improvements on the property. The first manufacturing building at this location was completed in August 2015. In fiscal year 2016, the Company also engaged a contractor for the construction of improvements on leasehold property located in the Netherlands, which was completed in October 2015.

[0001628280-16-019274:notes:210]
(2) The Company completed its implementation of a new enterprise resource planning, or ERP, system for its United States headquarters on July 5, 2015 and for its subsidiaries in Taiwan and the Netherlands in January 2016. The Company has capitalized the costs of the new ERP software and certain expenses associated directly with the implementation of the ERP system and began to depreciate these costs in fiscal year 2016.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-16-019274:notes:211]
Quarterly Financial Data (Unaudited)

[0001628280-16-019274:notes:212]
The following table presents the Company’s unaudited consolidated quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company’s quarterly results of operations for these periods are not necessarily indicative of future results of operations.

[0001628280-16-019274:notes:213]
|  | Three Months Ended |
|  | Sep. 30, 2015 |  | Dec. 31, 2015 |  | Mar. 31, 2016 |  | Jun. 30, 2016 |
|  | (In thousands, except per share data) |
| Net sales | $ | 519,618 |  |  | $ | 638,964 |  |  | $ | 532,721 |  |  | $ | 524,270 |  |
| Gross profit | $ | 72,215 |  |  | $ | 106,362 |  |  | $ | 79,152 |  |  | $ | 73,796 |  |
| Net income | $ | 13,699 |  |  | $ | 34,689 |  |  | $ | 16,662 |  |  | $ | 6,971 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.73 |  |  | $ | 0.35 |  |  | $ | 0.14 |  |
| Diluted | $ | 0.27 |  |  | $ | 0.67 |  |  | $ | 0.32 |  |  | $ | 0.13 |  |

[0001628280-16-019274:notes:214]
|  | Three Months Ended |
|  | Sep. 30, 2014 |  | Dec. 31, 2014 |  | Mar. 31, 2015 |  | Jun. 30, 2015 |
|  | (In thousands, except per share data) |
| Net sales | $ | 443,322 |  |  | $ | 503,014 |  |  | $ | 471,225 |  |  | $ | 573,594 |  |
| Gross profit | $ | 69,193 |  |  | $ | 84,452 |  |  | $ | 76,820 |  |  | $ | 89,766 |  |
| Net income | $ | 20,863 |  |  | $ | 31,242 |  |  | $ | 23,056 |  |  | $ | 26,702 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.46 |  |  | $ | 0.68 |  |  | $ | 0.49 |  |  | $ | 0.56 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.61 |  |  | $ | 0.44 |  |  | $ | 0.51 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-019274:notes:215]
Related-party and Other Transactions

[0001628280-16-019274:notes:216]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.3% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at June 30, 2016.

[0001628280-16-019274:notes:217]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-16-019274:notes:218]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-16-019274:notes:219]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-16-019274:notes:220]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. For the years ended June 30, 2016, 2015 and 2014, the Company purchased products from Ablecom totaling $241,836,000, $227,562,000 and $201,848,000, respectively. For the years ended June 30, 2016, 2015 and 2014, the Company sold products to Ablecom totaling $19,453,000, $58,013,000 and $14,576,000, respectively.

[0001628280-16-019274:notes:221]
Amounts owed to the Company by Ablecom as of June 30, 2016 and 2015, were $4,678,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of June 30, 2016 and 2015, were $39,152,000 and $59,015,000, respectively. In fiscal year 2016, the Company paid Ablecom the majority of invoiced dollars between 48 and 90 days of invoice date. For the years ended June 30, 2016, 2015 and 2014, the Company paid $9,085,000, $5,851,000 and $6,906,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-16-019274:notes:222]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $62,782,000 and $67,261,000 at June 30, 2016 and 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-16-019274:notes:223]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. The Management Company had no business operations as of June 30, 2012. For the years ended June 30, 2016, 2015 and 2014, $20,000, $(11,000) and $(6,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the consolidated statements of operations.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-16-019274:notes:224]
The following is a summary of net sales by product type (in thousands):

[0001628280-16-019274:notes:225]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 1,525,570 |  |  | 68.9 | % |  | $ | 1,213,608 |  |  | 60.9 | % |  | $ | 740,789 |  |  | 50.5 | % |
| Subsystems and accessories | 690,003 |  |  | 31.1 | % |  | 777,547 |  |  | 39.1 | % |  | 726,413 |  |  | 49.5 | % |
| Total | $ | 2,215,573 |  |  | 100.0 | % |  | $ | 1,991,155 |  |  | 100.0 | % |  | $ | 1,467,202 |  |  | 100.0 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-019274:notes:226]
The following is a summary for the years ended June 30, 2016, 2015 and 2014, of net sales by geographic region (in thousands):

[0001628280-16-019274:notes:227]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Net sales: |  |  |  |  |  |
| United States | $ | 1,398,405 |  |  | $ | 1,160,651 |  |  | $ | 809,250 |  |
| Europe | 385,819 |  |  | 378,323 |  |  | 316,760 |  |
| Asia | 324,208 |  |  | 326,912 |  |  | 299,403 |  |
| Other | 107,141 |  |  | 125,269 |  |  | 41,789 |  |
|  | $ | 2,215,573 |  |  | $ | 1,991,155 |  |  | $ | 1,467,202 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-16-019274:notes:228]
The following is a summary of long-lived assets, excluding financial instruments, deferred tax assets, other assets, goodwill and intangible assets (in thousands):

[0001628280-16-019274:notes:229]
|  | June 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 142,764 |  |  | $ | 124,292 |  |  | $ | 94,119 |  |
| Asia | 42,052 |  |  | 37,695 |  |  | 36,123 |  |
| Europe | 3,133 |  |  | 1,051 |  |  | 347 |  |
|  | $ | 187,949 |  |  | $ | 163,038 |  |  | $ | 130,589 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-019274:notes:230]
Segment Reporting

[0001628280-16-019274:notes:231]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001628280-16-019274:notes:232]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the years ended June 30, 2016, 2015 and 2014, of net sales by geographic region (in thousands):

[0001628280-16-019274:notes:233]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories done by the Company. In fiscal year 2016 and 2015, one customer represented 10.9% and 10.1% of the Company's total net sales, respectively, and no customer represented greater than 10% of the Company’s total net sales for the year ended June 30, 2014. No country other than the United States represent greater than 10% of the Company’s total net sales for any of the years ended June 30, 2016, 2015 and 2014. No customer accounted for 10% or more of the Company's accounts receivable as of June 30, 2016, 2015 and 2014.
