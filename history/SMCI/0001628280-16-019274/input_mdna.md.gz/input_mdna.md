# SMCI MD&A — 0001628280-16-019274


## mdna

[0001628280-16-019274:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-16-019274:mdna:2]
Overview

[0001628280-16-019274:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, HPC and IoT/embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. For fiscal years 2016, 2015 and 2014, our net sales were $2,215.6 million, $1,991.2 million and $1,467.2 million, respectively. The increase in our net sales in fiscal year 2016 compared with fiscal year 2015 was primarily due to increased sales of our server systems optimized for OEM/direct customers and cloud/internet data center computing. For fiscal years 2016, 2015 and 2014, net sales of application optimized servers were $1,525.6 million, $1,213.6 million and $740.8 million, respectively, and net sales of subsystems and accessories were $690.0 million, $777.5 million and $726.4 million, respectively. In fiscal year 2016, we experienced strong growth in sales of our complete systems including ultra, data center optimized servers, Twin family of servers, storage and IoT/embedded servers. The percentage of our net sales represented by sales of complete server systems increased to 68.9% in fiscal year 2016 from 60.9% in fiscal year 2015.

[0001628280-16-019274:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2016, 2015 and 2014, our net income was $72.0 million, $101.9 million and $54.2 million, respectively. Our decrease in net income in fiscal year 2016 was primarily attributable to higher operating expenses from headcount increase to support our business growth and the recording of a $9.3 million out-of-period adjustment relating to extended warranty revenue in the three months ended September 30, 2015. The deferred revenue for the extended warranty will be recognized ratably through fiscal year 2019. The impact on net income from this out-of-period adjustment was $5.9 million pertaining to prior periods through June 30, 2015.

[0001628280-16-019274:mdna:5]
We sell our server systems and server subsystems and accessories through our direct sales force as well as through distributors and OEMs. For fiscal years 2016, 2015 and 2014, we derived 55.2%, 49.7%, 45.9%, respectively, of our net sales from products sold to OEMs/direct customers and 44.8%, 50.3% and 54.1%, respectively, of our net sales from products sold to distributors. Sales to Softlayer, a division of IBM Corporation, represented 10.9% and 10.1% of our net sales in fiscal years 2016 and 2015, respectively. None of our customers accounted for 10% or more of our net sales in fiscal year 2014. For fiscal years 2016, 2015 and 2014, we derived 63.1%, 58.3% and 55.2%, respectively, of our net sales from customers in the United States.

[0001628280-16-019274:mdna:6]
We perform the majority of our research and development efforts in-house. For fiscal years 2016, 2015 and 2014, research and development expenses represented 5.6%, 5.0% and 5.7% of our net sales, respectively.

[0001628280-16-019274:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2016, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For fiscal years 2016, 2015 and 2014, our purchases from Ablecom represented 12.8%, 13.6% and 16.3% of our cost of sales, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a large volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-16-019274:mdna:8]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding, or DSOs. In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures.

[0001628280-16-019274:mdna:9]
Other Financial Highlights

[0001628280-16-019274:mdna:10]
The following is a summary of other financial highlights of fiscal year 2016:

[0001628280-16-019274:mdna:11]
| • | Net cash provided by (used in) operating activities was $107.5 million, $(44.6) million and $6.5 million in fiscal year 2016, 2015 and 2014, respectively. Our cash and cash equivalents, together with our investments, were $183.7 million at the end of fiscal year 2016, compared with $98.1 million at the end of fiscal year 2015. The increase in our cash and cash equivalents, together with our investments at the end of fiscal year 2016 was primarily due to $107.5 million of cash provided by our operating activities and $12.2 million of proceeds from the exercise of stock options, partially offset by $34.1 million of purchases of property and equipment, of which $16.7 million was related to property and equipment of manufacturing buildings at our Green Computing Park in San Jose, California, and $3.4 million was related to the implementation of a new ERP system for the United States headquarters and our subsidiaries. |

[0001628280-16-019274:mdna:12]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of fiscal year 2016 was 50 days, compared with 48 days at the end of fiscal year 2015. |

[0001628280-16-019274:mdna:13]
| • | Our inventory balance was $449.0 million at the end of fiscal year 2016, compared with $463.5 million at the end of fiscal year 2015. Days sales of inventory (“DSI”) at the end of fiscal year 2016 was 87 days, compared with 84 days at the end of fiscal year 2015. |

[0001628280-16-019274:mdna:14]
| • | Our purchase commitments with contract manufacturers and suppliers were $334.0 million at the end of fiscal year 2016 and $378.3 million at the end of fiscal year 2015. Included in the non-cancellable commitments are hard disk drive purchase commitments totaling approximately $110.5 million, which have terms expiring through December 2016. See Note 12 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of purchase commitments. |

[0001628280-16-019274:mdna:15]
Fiscal Year

[0001628280-16-019274:mdna:16]
Our fiscal year ends on June 30. References to fiscal year 2016, for example, refer to the fiscal year ended June 30, 2016.

[0001628280-16-019274:mdna:17]
Revenues and Expenses

[0001628280-16-019274:mdna:18]
Net sales. Net sales consist of sales of our server solutions, including server systems, subsystems and accessories. The main factors which impact our net sales are unit volumes shipped and average selling prices. The prices for server systems range widely depending upon the configuration, and the prices for our subsystems and accessories vary based on the type. As with most electronics-based products, average selling prices typically are highest at the time of introduction of new products which utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products.

[0001628280-16-019274:mdna:19]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally lower

[0001628280-16-019274:mdna:20]
on server systems than on subsystems and accessories, but generally higher in the case of sales of server systems to internet data system customers. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001628280-16-019274:mdna:21]
Research and development expenses. Research and development expenses consist of the personnel and related expenses including stock based compensation of our research and development teams, and materials and supplies, consulting services, third party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering, or NRE, funding from certain suppliers and customers. Under these programs, we are reimbursed for certain research and development costs that we incur as part of the joint development of our products and those of our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001628280-16-019274:mdna:22]
Sales and marketing expenses. Sales and marketing expenses consist primarily of salaries, stock based compensation and incentive bonuses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these programs, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. Similarly, we from time to time offer our distributors cooperative marketing funding. To the extent the funding is not recorded as contra-revenue, it has the effect of increasing our expenses. The timing, magnitude and estimated usage of our programs and those of our suppliers can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, either by us or our suppliers, typically increases in connection with significant product releases by us or our suppliers.

[0001628280-16-019274:mdna:23]
General and administrative expenses. General and administrative expenses consist primarily of general corporate costs, including personnel expenses, financial reporting, corporate governance and compliance and outside legal, audit and tax fees.

[0001628280-16-019274:mdna:24]
Interest and other income, net. Interest and other income, net consist primarily of interest earned on our investment and cash balances.

[0001628280-16-019274:mdna:25]
Interest expense. Interest expense represents interest expense on our term loans and lines of credit.

[0001628280-16-019274:mdna:26]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits and the domestic production activities deduction which were partially offset by the impact of state taxes, stock option expenses and unrecognized tax benefits. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Note 11 of Notes to Consolidated Financial Statements.

[0001628280-16-019274:mdna:27]
Critical Accounting Policies

[0001628280-16-019274:mdna:28]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, inventory valuations, income taxes, warranty obligations, stock-based compensation and impairment of short-term and long-term investments. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates.

[0001628280-16-019274:mdna:29]
We believe the following are our most critical accounting policies as they require our more significant judgments in the preparation of our financial statements.

[0001628280-16-019274:mdna:30]
Revenue recognition. We recognize revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer if all other revenue recognition criteria have been met. Our standard

[0001628280-16-019274:mdna:31]
arrangement with our customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination if all other revenue recognition criteria have been met. We also have a few customers who have acceptance provisions for which revenue is recognized when customers provide the necessary acceptance. We generally do not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs customers are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, we regularly review our history of actual returns for each major product line. We also communicate regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with our distributors.

[0001628280-16-019274:mdna:32]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-16-019274:mdna:33]
Multiple-element arrangements. Our multiple-element product offerings include server systems with embedded software and support, which are considered separate units of accounting.

[0001628280-16-019274:mdna:34]
We allocate revenue to each element in a multiple-element arrangement based upon their relative selling price. When applying the relative selling price method, we determine the selling price for each deliverable using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price for that deliverable. Revenue allocated to each element is then recognized when all the revenue recognition criteria are met for each element.

[0001628280-16-019274:mdna:35]
We determine VSOE based on its normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range.

[0001628280-16-019274:mdna:36]
In most instances, we are not able to establish VSOE for all deliverables in an arrangement with multiple elements. This may be due to the infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history. When VSOE cannot be established, we attempt to establish the selling price for each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our product solutions differ from that of our peers and contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, we are typically unable to determine TPE.

[0001628280-16-019274:mdna:37]
When we are unable to establish selling price using VSOE or TPE, we use estimated selling price (“ESP”) in our allocation of the arrangement consideration. The objective of ESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. ESP is generally used for offerings that are not typically sold on a stand-alone basis or for new or highly customized offerings.

[0001628280-16-019274:mdna:38]
We determine ESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices. The determination of ESP is made through consultation with and approval by our management.

[0001628280-16-019274:mdna:39]
We regularly review VSOE, TPE and ESP, as well as the establishment and updates of these estimates. There was no material impact on revenues during fiscal year 2016 nor do we expect a material impact in the near term from changes in VSOE, TPE or ESP.

[0001628280-16-019274:mdna:40]
Services revenue. Services revenue mainly consists of extended warranty and on-site services. Extended warranty and on-site services are offered as part of multiple-element arrangements. Revenue related to extended warranty and on-site services is deferred and recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001628280-16-019274:mdna:41]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The liability for product warranties was $5.8 million as of June 30, 2016, compared with $7.7 million as of June 30, 2015. The provision for warranty reserve was $17.5 million, $15.8 million and $14.2 million in fiscal years 2016, 2015 and 2014, respectively. The change in estimated liability for pre-existing warranties was $(2.1) million, $(0.2) million and $0.4 million in fiscal years 2016, 2015 and 2014, respectively. As a result of our increase in cost of servicing warranty claims from our increase in net sales in fiscal year 2016 and 2015, the provision for warranty reserve increased $1.7 million and $1.6 million in fiscal years 2016 and 2015, respectively. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates accordingly.

[0001628280-16-019274:mdna:42]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $9.3 million, $5.9 million and $2.3 million in fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-019274:mdna:43]
Accounting for income taxes. We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying currently enacted tax laws. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001628280-16-019274:mdna:44]
We recognize the tax liability for uncertain income tax positions on the income tax return based on a two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon examination by the tax authority. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related change in our tax provision during the period in which we make such determination. See Note 11 of Notes to Consolidated Financial Statements for the impact on our consolidated financial statements.

[0001628280-16-019274:mdna:45]
Stock-based compensation. We measure and recognize compensation expense for all share-based awards made to employees and non-employee members of our Board of Directors including employee stock options and restricted stock units. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of our restricted stock units is based on the closing market price of our common stock on the date of grant. We estimated the fair value of stock options granted using a Black-Scholes option-pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option, the expected volatility of the price of our common

[0001628280-16-019274:mdna:46]
stock and the expected forfeiture rate. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-16-019274:mdna:47]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-16-019274:mdna:48]
Compensation expense for options and restricted stock units granted to employees was $16.1 million, $13.7 million and $11.1 million for fiscal years 2016, 2015 and 2014, respectively. As of June 30, 2016, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options and restricted stock units to employees and non-employee members of our Board of Directors, was $37.5 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.29 years. See Note 10 of Notes to our Consolidated Financial Statements for additional information.

[0001628280-16-019274:mdna:49]
Variable interest entities. We have concluded that Ablecom is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-16-019274:mdna:50]
We and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of June 30, 2016, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In fiscal years 2016, 2015 and 2014, $20,000, $(11,000) and $(6,000) of net income (loss) attributable to Ablecom's interest was included in our general and administrative expenses in the consolidated statements of operations, respectively.

[0001628280-16-019274:mdna:51]
Results of Operations

[0001628280-16-019274:mdna:52]
Net Sales

[0001628280-16-019274:mdna:53]
The following table presents net sales by product type for fiscal years 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-019274:mdna:54]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | $ |  | % |  | $ |  | % |
| Server systems | $ | 1,525.6 |  |  | $ | 1,213.6 |  |  | $ | 740.8 |  |  | $ | 312.0 |  |  | 25.7 | % |  | $ | 472.8 |  |  | 63.8 | % |
| Percentage of total net sales | 68.9 | % |  | 60.9 | % |  | 50.5 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 690.0 |  |  | 777.5 |  |  | 726.4 |  |  | (87.5 | ) |  | (11.3 | )% |  | 51.1 |  |  | 7.0 | % |
| Percentage of total net sales | 31.1 | % |  | 39.1 | % |  | 49.5 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 2,215.6 |  |  | $ | 1,991.2 |  |  | $ | 1,467.2 |  |  | $ | 224.4 |  |  | 11.3 | % |  | $ | 524.0 |  |  | 35.7 | % |

[0001628280-16-019274:mdna:55]
The following table presents unit sales and average selling price by product type for fiscal years 2016, 2015 and 2014 (units in thousands):

[0001628280-16-019274:mdna:56]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | % |  | % |
| Server systems: |  |  |  |  |  |  |  |  |  |
| Unit sales | 357 |  |  | 314 |  |  | 262 |  |  | 13.7 | % |  | 19.8 | % |
| Average selling price | $ | 4,273 |  |  | $ | 3,865 |  |  | $ | 2,827 |  |  | 10.6 | % |  | 36.7 | % |
| Subsystems and accessories: |  |  |  |  |  |  |  |  |  |
| Unit sales | 4,125 |  |  | 4,733 |  |  | 4,458 |  |  | (12.8 | )% |  | 6.2 | % |
| Average selling price | $ | 167 |  |  | $ | 164 |  |  | $ | 163 |  |  | 1.8 | % |  | 0.6 | % |

[0001628280-16-019274:mdna:57]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001628280-16-019274:mdna:58]
The increase in our net sales in fiscal year 2016 compared with fiscal year 2015 was primarily due to continued increased sales of our products optimized for OEM/direct customers and cloud/internet data center computing who increasingly are purchasing complete server systems from us offset in part by a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three prior fiscal year period ended June 30, 2015 and deferred in the three months ended September 30, 2015. The year-over-year growth in net sales of our server systems in fiscal year 2016 was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in the unit volumes of server systems. The average selling prices of our server systems increased primarily due to higher sales of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, data center optimized servers, Twin family of servers, storage and IoT/embedded servers.

[0001628280-16-019274:mdna:59]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in fiscal year 2016 was primarily due to a lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators as we are continuing to promote our sales of complete server systems to our OEM and direct customers.

[0001628280-16-019274:mdna:60]
Fiscal Year 2015 compared with Fiscal Year 2014

[0001628280-16-019274:mdna:61]
The increase in our net sales in fiscal year 2015 compared with fiscal year 2014 was primarily due to continued increased sales of our products optimized for OEM, internet data center cloud computing and enterprise verticals. The year-over-year growth in net sales of our server systems in fiscal year 2015 was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our storage servers and our Twin family of servers and to a lesser extent our GPU/Xeon Phi servers. Net sales also increased as a result of an increase in customers purchasing our software and service together with our complete systems as total solution packages.

[0001628280-16-019274:mdna:62]
The year-over-year growth in net sales and unit sales of our subsystems and accessories in fiscal year 2015 was primarily due to a higher sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who increasingly are purchasing additional accessories from us and completing the final assembly themselves.

[0001628280-16-019274:mdna:63]
The following table presents the percentages of net sales from products sold to distributors and OEMs and direct customers for fiscal years 2016, 2015 and 2014:

[0001628280-16-019274:mdna:64]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | % |  | % |
| Distributors | 44.8 | % |  | 50.3 | % |  | 54.1 | % |  | (5.5 | )% |  | (3.8 | )% |
| OEMs and direct customers | 55.2 | % |  | 49.7 | % |  | 45.9 | % |  | 5.5 | % |  | 3.8 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001628280-16-019274:mdna:65]
The following table presents percentages of net sales by geographic region for fiscal years 2016, 2015 and 2014:

[0001628280-16-019274:mdna:66]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | % |  | % |
| United States | 63.1 | % |  | 58.3 | % |  | 55.2 | % |  | 4.8 | % |  | 3.1 | % |
| Europe | 17.4 | % |  | 19.0 | % |  | 21.6 | % |  | (1.6 | )% |  | (2.6 | )% |
| Asia | 14.6 | % |  | 16.4 | % |  | 20.4 | % |  | (1.8 | )% |  | (4.0 | )% |
| Others | 4.9 | % |  | 6.3 | % |  | 2.8 | % |  | (1.4 | )% |  | 3.5 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |  |  |  |

[0001628280-16-019274:mdna:67]
Cost of Sales and Gross Margin

[0001628280-16-019274:mdna:68]
Cost of sales and gross margin for fiscal years 2016, 2015 and 2014, are as follows (dollars in millions):

[0001628280-16-019274:mdna:69]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | $ |  | % |  | $ |  | % |
| Total cost of sales | $ | 1,884.0 |  |  | $ | 1,670.9 |  |  | $ | 1,241.7 |  |  | $ | 213.1 |  |  | 12.8 | % |  | $ | 429.3 |  |  | 34.6 | % |
| Total gross profit | 331.5 |  |  | 320.2 |  |  | 225.5 |  |  | 11.3 |  |  | 3.5 | % |  | 94.7 |  |  | 42.0 | % |
| Total gross margin | 15.0 | % |  | 16.1 | % |  | 15.4 | % |  |  |  | (1.1 | )% |  |  |  | 0.7 | % |

[0001628280-16-019274:mdna:70]
Fiscal Year 2016 compared with Fiscal Year 2015

[0001628280-16-019274:mdna:71]
The year-over-year increase in absolute dollars of cost of sales in fiscal year 2016 compared to fiscal year 2015 was primarily attributable to the increase in net sales, an increase of $3.4 million in provision for inventory reserve and an increase of $1.7 million in provision for warranty reserve. In fiscal year 2016, we recorded a $9.3 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $5.9 million, or 0.3% of net sales, in fiscal year 2015. The increase in the inventory provision was primarily due to higher inventory reserves for specific products.

[0001628280-16-019274:mdna:72]
In fiscal year 2016, we recorded a $17.5 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to a $15.8 million expense, or 0.8% of net sales, in fiscal year 2015. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in fiscal year 2016. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-019274:mdna:73]
The year-over-year decrease in the gross margin percentage in fiscal year 2016 compared to fiscal year 2015 was primarily due to significant lower gross margins from sales of our subsystem and accessories, lower utilization of manufacturing capacity and the recording of a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three fiscal year period ended June 30, 2015, offset in part by higher sales of our complete server systems such as storage servers which have a higher gross margin. Gross margin percentage for fiscal year 2016 would have been 15.3% without this out-of-period adjustment.

[0001628280-16-019274:mdna:74]
Fiscal Year 2015 compared with Fiscal Year 2014

[0001628280-16-019274:mdna:75]
The year-over-year increase in  absolute dollars of cost of sales in fiscal year 2015 compared to fiscal year 2014 was primarily attributable to the increase in net sales, an increase of $3.7 million in provision for inventory reserve and an increase of $1.6 million in provision for warranty reserve. In fiscal year 2015, we recorded a $5.9 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $2.3 million, or 0.2% of net sales, in fiscal year 2014. The increase in the inventory provision was primarily due to higher inventory reserves for specific products.

[0001628280-16-019274:mdna:76]
In fiscal year 2015, we recorded a $15.8 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to a $14.2 million expense, or 1.0% of net sales, in fiscal year 2014. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in fiscal year 2015.

[0001628280-16-019274:mdna:77]
The year-over-year increase in the gross margin percentage in fiscal year 2015 compared to fiscal year 2014 was primarily due to lower costs resulting from an increase in the mix of complete server system sales with higher margin, the increased scale of our business and higher utilization of our manufacturing facilities in Taiwan, offset by higher sales to internet data center customers, which generally have a lower gross margin.

[0001628280-16-019274:mdna:78]
Operating Expenses

[0001628280-16-019274:mdna:79]
Operating expenses for fiscal years 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-019274:mdna:80]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 124.0 |  |  | $ | 100.3 |  |  | $ | 84.3 |  |  | $ | 23.7 |  |  | 23.7 | % |  | $ | 16.0 |  |  | 19.0 | % |
| Percentage of total net sales | 5.6 | % |  | 5.0 | % |  | 5.7 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 62.8 |  |  | 48.9 |  |  | 38.0 |  |  | 14.0 |  |  | 28.6 | % |  | 10.8 |  |  | 28.5 | % |
| Percentage of total net sales | 2.8 | % |  | 2.5 | % |  | 2.6 | % |  |  |  |  |  |  |  |  |
| General and administrative | 37.8 |  |  | 24.4 |  |  | 23.0 |  |  | 13.5 |  |  | 55.2 | % |  | 1.4 |  |  | 5.9 | % |
| Percentage of total net sales | 1.7 | % |  | 1.2 | % |  | 1.6 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | 224.7 |  |  | $ | 173.5 |  |  | $ | 145.3 |  |  | $ | 51.2 |  |  | 29.5 | % |  | $ | 28.2 |  |  | 19.4 | % |
| Percentage of total net sales | 10.1 | % |  | 8.7 | % |  | 9.9 | % |  |  |  |  |  |  |  |  |

[0001628280-16-019274:mdna:81]
Research and development expenses. Research and development expenses increased by $23.7 million, or 23.7% in fiscal year 2016 compared to fiscal year 2015. Research and development expenses were 5.6% and 5.0% of net sales for fiscal year 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $17.3 million in compensation and benefits including stock-based compensation expense, an increase of $4.4 million in development expenses for prototype materials and no value added tax refund of $2.8 million on research and development expenses which we received in fiscal year 2015.

[0001628280-16-019274:mdna:82]
Research and development expenses increased by $16.0 million, or 19.0% in fiscal year 2015 compared to fiscal year 2014. Research and development expenses were 5.0% and 5.7% of net sales for fiscal year 2015 and 2014, respectively. The increase in absolute dollars was driven primarily by an increase of $18.1 million in compensation and benefits including stock-based compensation expense, an increase of $1.7 million in development expenses for prototype materials, partially offset by $3.2 million in non-recurring engineering funding from certain suppliers and customers and a $2.8 million value added tax refund on research and development expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in fiscal year 2015.

[0001628280-16-019274:mdna:83]
Research and development expenses include stock-based compensation expense of $10.2 million, $8.6 million and $6.8 million for fiscal year 2016, 2015 and 2014, respectively.

[0001628280-16-019274:mdna:84]
Our compensation and benefit expense in research and development continues to increase resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. We continue to believe that focused investments in research and development are critical to our future growth and competitive position in the marketplace. Our investments in this area will directly relate to enhancement of our current product line, development of new products that achieve market acceptance, and our ability to meet an expanding range of customer requirements. As such, we expect to continue to spend on current and future product development efforts.

[0001628280-16-019274:mdna:85]
Sales and marketing expenses. Sales and marketing expenses increased by $14.0 million, or 28.6% in fiscal year 2016 compared to fiscal year 2015. Sales and marketing expenses were 2.8% and 2.5% of net sales for fiscal year 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $8.0 million in compensation and benefits including stock based compensation, resulting primarily from growth in sales and marketing personnel, an increase of $3.6 million in advertising, marketing promotional and trade show expenses, and a decrease of $1.1 million in marketing cooperative funding from certain suppliers.

[0001628280-16-019274:mdna:86]
Sales and marketing expenses increased by $10.8 million, or 28.5% in fiscal year 2015 compared to fiscal year 2014. Sales and marketing expenses were 2.5% and 2.6% of net sales for fiscal year 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $7.8 million in compensation and benefits resulting primarily from growth in sales and marketing personnel and an increase of $2.9 million in advertising, marketing promotional and trade show expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in fiscal year 2015.

[0001628280-16-019274:mdna:87]
Sales and marketing expenses include stock-based compensation expense of $1.8 million, $1.6 million and $1.3 million for fiscal year 2016, 2015 and 2014, respectively.

[0001628280-16-019274:mdna:88]
General and administrative expenses. General and administrative expenses increased by $13.5 million, or 55.2% in fiscal year 2016 compared to fiscal year 2015. General and administrative expenses were 1.7% and 1.2% of net sales for fiscal year 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $7.6 million in compensation and benefits including stock-based compensation expense, an increase of $4.1 million in legal, audit and accounting expenses and an increase of $1.0 million in bad debt expenses.

[0001628280-16-019274:mdna:89]
General and administrative expenses increased by $1.4 million, or 5.9% in fiscal year 2015 compared to fiscal year 2014. General and administrative expenses were 1.2% and 1.6% of net sales for fiscal year 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $2.3 million in compensation and benefits including stock-based compensation expense, a decrease of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor in the prior year offset in part by an increase of $1.1 million in foreign currency transaction gain and a decrease of $1.0 million in bad debt expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in fiscal year 2015.

[0001628280-16-019274:mdna:90]
General and administrative expenses include stock-based compensation expense of $3.0 million, $2.6 million and $2.1 million for fiscal year 2016, 2015 and 2014, respectively.

[0001628280-16-019274:mdna:91]
Interest and Other Expense, Net

[0001628280-16-019274:mdna:92]
Interest and other expense, net for fiscal year 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-019274:mdna:93]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | $ |  | % |  | $ |  | % |
| Interest and other income, net | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | 48.7 | % |  | $ | — |  |  | 25.0 | % |
| Interest expense | (1.6 | ) |  | (1.0 | ) |  | (0.8 | ) |  | (0.6 | ) |  | 65.2 | % |  | (0.2 | ) |  | 27.5 | % |
| Interest and other expense, net | $ | (1.4 | ) |  | $ | (0.9 | ) |  | $ | (0.7 | ) |  | $ | (0.6 | ) |  | 67.4 | % |  | $ | (0.2 | ) |  | 27.8 | % |

[0001628280-16-019274:mdna:94]
Interest and other expense, net. Interest and other expense, net increased by $0.6 million in fiscal year 2016 compared to fiscal year 2015 and increased by $0.2 million in fiscal year 2015 compared to fiscal year 2014. The increases were primarily due to higher interest expense on debt.

[0001628280-16-019274:mdna:95]
Provision for Income Taxes

[0001628280-16-019274:mdna:96]
Provision for income taxes and effective tax rates for fiscal years 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-019274:mdna:97]
|  | Years Ended June 30, |  | 2016 over 2015 Change |  | 2015 over 2014 Change |
|  | 2016 |  | 2015 |  | 2014 |  | $ |  | % |  | $ |  | % |
| Provision for Income Taxes | $ | 33.4 |  |  | $ | 44.0 |  |  | $ | 25.4 |  |  | $ | (10.6 | ) |  | (24.1 | )% |  | $ | 18.6 |  |  | 73.1 | % |
| Percentage of total net sales | 1.5 | % |  | 2.2 | % |  | 1.7 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 31.7 | % |  | 30.2 | % |  | 32.0 | % |  |  |  |  |  |  |  |  |

[0001628280-16-019274:mdna:98]
Provision for income taxes. Provision for income taxes decreased by $10.6 million, or 24.1% in fiscal year 2016 compared to fiscal year 2015. The effective tax rate was 31.7% and 30.2% for fiscal years 2016 and 2015, respectively. The lower income tax provision for fiscal year 2016 was primarily attributable to our lower operating income. The effective tax rate for fiscal year 2016 was higher primarily due to the lower foreign rate benefits and foreign unrecognized tax benefits offset in part by the increase in federal research and development credit as a result of the enactment of the Protecting Americans from Tax Hikes ("PATH") Act of 2015.

[0001628280-16-019274:mdna:99]
Provision for income taxes increased by $18.6 million, or 73.1% in fiscal year 2015 compared to fiscal year 2014. The effective tax rate was 30.2% and 32.0% for fiscal year 2015 and 2014, respectively. The higher income tax provision for fiscal year 2015 was primarily attributable to our higher operating income. The effective tax rate for fiscal year 2015 was lower primarily due to the release of unrecognized tax benefits due to the lapse of statute of limitations, reinstatement of the United

[0001628280-16-019274:mdna:100]
States federal research and development tax credits, higher income taxed by foreign jurisdictions with lower tax rates and lower add back for stock compensation expenses.

[0001628280-16-019274:mdna:101]
Liquidity and Capital Resources

[0001628280-16-019274:mdna:102]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $181.0 million and $95.5 million as of June 30, 2016 and 2015, respectively. Our cash in foreign locations was $46.5 million and $26.3 million at June 30, 2016 and 2015, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-16-019274:mdna:103]
Operating Activities. Net cash provided by (used in) operating activities was $107.5 million, $(44.6) million and $6.5 million for fiscal years 2016, 2015 and 2014, respectively.

[0001628280-16-019274:mdna:104]
Net cash provided by our operating activities for fiscal year 2016 was primarily due to our net income of $72.0 million, a decrease in accounts receivable of $32.4 million, an increase in other long term liabilities of $24.9 million, stock-based compensation expense of $16.1 million, depreciation expense of $13.3 million, provision for inventory of $9.3 million and an increase in accrued liabilities of $9.0 million, which were partially offset by a decrease in accounts payable of $54.3 million and an increase in prepaid expenses and other assets of $8.2 million.

[0001628280-16-019274:mdna:105]
Net cash used in our operating activities for fiscal year 2015 was primarily due to an increase in inventory of $153.6 million and an increase in accounts receivable of $110.2 million, which were partially offset by our net income of $101.9 million, an increase in accounts payable of $75.5 million, stock-based compensation expense of $13.7 million, an increase in net income taxes payable of $12.0 million, an increase in accrued liabilities of $9.6 million, depreciation expense of $8.1 million and provision for inventory of $5.9 million.

[0001628280-16-019274:mdna:106]
Net cash provided by our operating activities for fiscal year 2014 was primarily due to our net income of $54.2 million, an increase in accounts payable of $46.3 million, stock-based compensation expense of $11.1 million, an increase in net income taxes payable of $10.9 million, depreciation expense of $6.4 million and an increase in accrued liabilities of $3.3 million, provision for inventory of $2.3 million, which were partially offset by an increase in accounts receivable of $64.9 million, an increase in inventory of $63.9 million and the excess tax benefits from stock-based compensation of $3.0 million.

[0001628280-16-019274:mdna:107]
The decrease for fiscal year 2016 in accounts receivable was primarily due to lower sales volume in the fourth quarter of fiscal year 2016. The decrease for fiscal year 2016 in inventory and accounts payable was primarily due to anticipated lower sales volume in the first quarter of fiscal year 2017. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business in fiscal year 2016.

[0001628280-16-019274:mdna:108]
The increase for fiscal year 2014 and 2015 in accounts receivable was primarily due to an increase in our sales late in the fourth quarter. The increase for fiscal year 2014 and 2015 in inventory and accounts payable was primarily due to higher purchases to support the anticipated level of growth in our net sales in fiscal year 2015.

[0001628280-16-019274:mdna:109]
Investing activities. Net cash used in our investing activities was $35.1 million, $36.2 million and $40.2 million for fiscal years 2016, 2015 and 2014, respectively. In fiscal year 2016, of the net cash used in our investing activities, $34.1 million was related to the purchase of property, plant and equipment, of which $16.7 million was related to property and equipment of manufacturing buildings at our Green Computing Park in San Jose, California, and $3.4 million was related to the implementation of a new ERP system for the United States headquarters and our subsidiaries. We plan to continue the development and construction of improvements to our properties through fiscal year 2017. We anticipate investing approximately $17.0 million through April 2017 to complete the construction of a second manufacturing facility and the remodel of our office building. We plan to finance this development through our operating cash flows and additional borrowings from banks.

[0001628280-16-019274:mdna:110]
In fiscal year 2015, the $35.1 million included in net cash used in our investing activities was related to the purchase of property, plant and equipment including $21.8 million related to the development and construction of improvements to our first manufacturing building and warehouse at our Green Computing Park in San Jose, California, which was completed in August 2015 and $4.8 million related to the implementation of a new ERP system.

[0001628280-16-019274:mdna:111]
In fiscal year 2014, the $40.6 million included in net cash used in our investing activities was related to the purchase of property, plant and equipment including $30.2 million related to the real property purchased in San Jose, California in October 2013, offset in part by the termination of the certificates of deposits for $0.4 million, which were pledged as security for a value added tax examination required by tax authorities of Taiwan.

[0001628280-16-019274:mdna:112]
Financing activities. Net cash provided by our financing activities was $13.1 million, $80.1 million and $37.2 million for fiscal years 2016, 2015 and 2014, respectively. In fiscal year 2016, we borrowed an additional $34.2 million under our revolving lines of credit from Bank of America and CTBC Bank and repaid $34.1 million in loans. Further, we received $12.2 million related to the proceeds from the exercise of stock options in fiscal year 2016.

[0001628280-16-019274:mdna:113]
In fiscal year 2015, we borrowed an additional $84.9 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $36.0 million in loans. Further, we received $23.3 million related to the proceeds from the exercise of stock options in fiscal year 2015.

[0001628280-16-019274:mdna:114]
In fiscal year 2014, we received $23.9 million related to the proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding for restricted stock awards of $0.7 million in fiscal year 2014. Further, we borrowed an additional $6.8 million under the line of credit from Bank of America, borrowed $7.0 million from the CTBC Bank secured term loan, and borrowed $3.5 million of our CTBC Bank revolving line of credit and repaid $6.3 million in loans in fiscal year 2014.

[0001628280-16-019274:mdna:115]
In fiscal year 2016, 2015 and 2014, $2.9 million, $8.1 million and $3.0 million was related to the excess tax benefits from stock-based compensation, respectively. We expect the net cash provided by financing activities will increase throughout fiscal year 2017 as we intend to obtain additional financing from banks for our working capital requirements.

[0001628280-16-019274:mdna:116]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-16-019274:mdna:117]
Other factors affecting liquidity and capital resources

[0001628280-16-019274:mdna:118]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-16-019274:mdna:119]
Bank of America

[0001628280-16-019274:mdna:120]
In June 2015, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, we extended the revolving line of credit to mature on June 30, 2016.

[0001628280-16-019274:mdna:121]
In June 2016, we entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50.0 million term loan facility. This revolving line of credit facility replaces the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-16-019274:mdna:122]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.46% at June 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, we received $50.0 million term loan proceeds from Bank of America under the new credit agreement with interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America. As of June 30, 2016, we have reclassified $50.0 million of our line of credit to long-term loan.

[0001628280-16-019274:mdna:123]
In June 2016, we also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10.0 million for our Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of fund.

[0001628280-16-019274:mdna:124]
As of June 30, 2016 and 2015, the total outstanding borrowings under the Bank of America term loan was $0.9 million and $3.7 million, respectively. The total outstanding borrowings under the Bank of America lines of credit was $62.2 million and $59.7 million as of June 30, 2016 and 2015, respectively. The interest rates for these loans ranged from 1.02% to 1.96% per annum at June 30, 2016 and 0.79% to 1.68% per annum at June 30, 2015, respectively. As of June 30, 2016, the unused revolving lines of credit and term loan amount under Bank of America under the new credit agreements were $2.8 million and $50.0 million, respectively.

[0001628280-16-019274:mdna:125]
CTBC Bank

[0001628280-16-019274:mdna:126]
In November 2015, we entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700 million or $22.0 million U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1.0 billion or $30.3 million U.S. dollar equivalent. In January 2016, we extended the revolving line of credit to mature on March 31, 2016.

[0001628280-16-019274:mdna:127]
In April 2016, we entered into a new credit agreement with CTBC Bank that provides for (i) a 12-month NTD$700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100.0 million or $3.1 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40.0 million. The credit agreement matures on March 31, 2017.

[0001628280-16-019274:mdna:128]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20.4 million and $21.3 million as of June 30, 2016 and 2015, respectively. At June 30, 2016 and 2015, the total outstanding borrowings under the CTBC Bank revolving line of credit was $10.1 million and $9.7 million, respectively, in U.S. dollars. The interest rate for these loans were ranged from 0.90% and 1.25% at June 30, 2016 and 0.82% and 1.16% per annum at June 30, 2015. At June 30, 2016, available for future borrowing under this credit agreement was $9.5 million.

[0001628280-16-019274:mdna:129]
Covenant Compliance

[0001628280-16-019274:mdna:130]
The new credit agreement with Bank of America contain customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The new credit agreement contain certain financial covenants, including the following:

[0001628280-16-019274:mdna:131]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001628280-16-019274:mdna:132]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; |

[0001628280-16-019274:mdna:133]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $30,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-16-019274:mdna:134]
As of June 30, 2016, our total assets of $934.6 million collateralized the line of credit with Bank of America under the new credit agreement which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of June 30, 2016, total assets collateralizing the term loan with Bank of America were $59.3 million. As of June 30, 2016, we were in compliance with all financial covenants associated with the term loan and lines of credit with Bank of America under the new credit agreement.

[0001628280-16-019274:mdna:135]
As of June 30, 2016, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.8 million. There are no financial covenants associated with the term loan with CTBC Bank.

[0001628280-16-019274:mdna:136]
Contract Manufacturers

[0001628280-16-019274:mdna:137]
In fiscal year 2016, we paid our contract manufacturers within 40 to 74 days of invoice and Ablecom between 48 to 90 days of invoice. Ablecom is one of our major contract manufacturers and a related party. As of June 30, 2016 and 2015 amounts owed to Ablecom by us were approximately $39.2 million and $59.0 million, respectively.

[0001628280-16-019274:mdna:138]
Share Repurchase Program

[0001628280-16-019274:mdna:139]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of our common stock in the open market or in private transactions during the next twelve months at prevailing market prices. Repurchases will be made under the program using our own cash resources. This share repurchase program does not obligate us to acquire any particular amount of common stock, and it may be suspended at any time at our discretion. In July 2016, we purchased 513,194 shares of our common stock in the open market at a weighted average price of $19.97 per share for approximately $10.3 million.

[0001628280-16-019274:mdna:140]
Contractual Obligations

[0001628280-16-019274:mdna:141]
The following table describes our contractual obligations as of June 30, 2016:

[0001628280-16-019274:mdna:142]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,271 |  |  | $ | 7,622 |  |  | $ | 5,399 |  |  | $ | 2,631 |  |  | $ | 19,923 |  |
| Capital leases, including interest | 261 |  |  | 429 |  |  | 132 |  |  | — |  |  | 822 |  |
| Debt, including interest (1) | 54,370 |  |  | 21,041 |  |  | 20,358 |  |  | — |  |  | 95,769 |  |
| Purchase commitments (2) | 334,010 |  |  | — |  |  | — |  |  | — |  |  | 334,010 |  |
| Total (3) | $ | 392,912 |  |  | $ | 29,092 |  |  | $ | 25,889 |  |  | $ | 2,631 |  |  | $ | 450,524 |  |

[0001628280-16-019274:mdna:143]
__________________________

[0001628280-16-019274:mdna:144]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at June 30, 2016. |

[0001628280-16-019274:mdna:145]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $110.5 million of hard disk drive purchase commitments at June 30, 2016, which will be paid through December 2016. See Note 12 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of purchase commitments. |

[0001628280-16-019274:mdna:146]
| (3) | The table above excludes liabilities for deferred revenue of $35.4 million and unrecognized tax benefits and related interest and penalties accrual of $16.1 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 11 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of income taxes. |

[0001628280-16-019274:mdna:147]
We expect to fund our remaining contractual obligations from our ongoing operations and existing cash and cash equivalents on hand.

[0001628280-16-019274:mdna:148]
Recently Issued Accounting Pronouncements

[0001628280-16-019274:mdna:149]
In May 2014, the Financial Accounting Standards Board ("FASB") issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for us on July 1, 2018. We are currently evaluating the timing of our

[0001628280-16-019274:mdna:150]
adoption and the impact of adopting the new revenue guidance on our financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:mdna:151]
In April 2015, the FASB issued an amendment to the accounting guidance related to presentation of debt issuance costs. The amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The amendment clarified that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The amendment is effective for us on July 1, 2016. We are currently evaluating the effect the amendment to the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:mdna:152]
In July 2015, the FASB issued an amendment to the authoritative guidance related to inventory measurement. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for us on July 1, 2017. We are currently evaluating the effect the amendment to the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:mdna:153]
In November 2015, the FASB issued an amendment to the accounting guidance related to balance sheet classification of deferred taxes. The amendment requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. Early adoption is permitted as of the beginning of an interim or annual reporting period. The amendment is effective for us on July 1, 2017. We have adopted this guidance on a prospective basis for the fiscal year ended June 30, 2016. Adoption of this guidance resulted in a reclassification of our net current deferred tax asset of $17.9 million to the net non-current deferred tax asset in our Consolidated Balance Sheet as of June 30, 2016. No prior periods were retrospectively adjusted.

[0001628280-16-019274:mdna:154]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for us on July 1, 2018. Early adoption is permitted. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:mdna:155]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payments to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-019274:mdna:156]
Off-Balance Sheet Arrangements

[0001628280-16-019274:mdna:157]
We do not have any off-balance sheet arrangements.
