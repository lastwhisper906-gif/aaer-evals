# SMCI 8-K — 0001375365-22-000092 filed 2022-08-09

## item codes, every 8-K on or before 2022-08-29

- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2022-08-29

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-22-000092:8k_2_02:1]
EX-99.1
2
exhibit991_20220630.htm
EX-99.1

[0001375365-22-000092:8k_2_02:2]
Document

[0001375365-22-000092:8k_2_02:3]
Exhibit 99.1

[0001375365-22-000092:8k_2_02:4]
Supermicro Announces Fourth Quarter and Full Year Fiscal Year 2022

[0001375365-22-000092:8k_2_02:5]
Financial Results

[0001375365-22-000092:8k_2_02:6]
SAN JOSE, Calif. -- August 9, 2022 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced fourth quarter and full-year financial results for fiscal year 2022 ended June 30, 2022.

[0001375365-22-000092:8k_2_02:7]
Fourth Quarter of Fiscal Year 2022 Highlights

[0001375365-22-000092:8k_2_02:8]
•Net sales of $1.64 billion versus $1.36 billion in the third quarter of fiscal year 2022 and $1.07 billion in the same quarter of last year.

[0001375365-22-000092:8k_2_02:9]
•Gross margin of 17.6% versus 15.5% in the third quarter of fiscal year 2022 and 13.6% in the same quarter of last year.

[0001375365-22-000092:8k_2_02:10]
•Net income of $141 million versus $77 million in the third quarter of fiscal year 2022 and $39 million in the same quarter of last year.

[0001375365-22-000092:8k_2_02:11]
•Diluted net income per common share of $2.60 versus $1.43 in the third quarter of fiscal year 2022 and $0.74 in the same quarter of last year.

[0001375365-22-000092:8k_2_02:12]
•Non-GAAP diluted net income per common share of $2.62 versus $1.55 in the third quarter of fiscal year 2022 and $0.81 in the same quarter of last year.

[0001375365-22-000092:8k_2_02:13]
•Cash flow used in operations for the fourth quarter of fiscal year 2022 of $25 million and capital expenditures of $11 million.

[0001375365-22-000092:8k_2_02:14]
Non-GAAP gross margin for the fourth quarter of fiscal year 2022 was 17.6%, which adds back stock-based compensation expense of $0.5 million. Non-GAAP diluted net income per common share for the fourth quarter of fiscal year 2022 was $2.62, which adds back stock-based compensation expense of $8.9 million and other expenses of $0.2 million, net of the related tax effects.

[0001375365-22-000092:8k_2_02:15]
As of June 30, 2022, total cash and cash equivalents was $267.4 million and bank debt was $596.8 million.

[0001375365-22-000092:8k_2_02:16]
“The Supermicro team has attained yet another milestone by achieving $5.2 billion in annual revenue,” said Charles Liang, Chairman and CEO. “The ramp up of recent design wins and top tier customers adopting our plug and play ("PNP") rack-scale solutions have given us momentum going into fiscal year 2023. We are well on our way to becoming the leading global supplier of rack-scale Total IT Solutions, powering the world’s digital transformation across diverse applications in key market segments including AI, enterprise, cloud, edge/telco and others.”

[0001375365-22-000092:8k_2_02:17]
Fiscal Year 2022 Summary

[0001375365-22-000092:8k_2_02:18]
Net sales for the fiscal year ended June 30, 2022, were $5.20 billion versus $3.56 billion for the fiscal year ended June 30, 2021. Net income for fiscal year 2022 was $285 million, or $5.32 per diluted share, versus $112 million, or $2.09 per diluted share, for fiscal year 2021. Non-GAAP net income for the fiscal year 2022 was $311 million, or $5.65 per diluted share, versus $136 million, or $2.48 per diluted share, for fiscal year 2021. Non-GAAP net income for the fiscal year 2022 adds back stock-based compensation expense of $32.8 million, litigation expenses of $4.4 million, $2.0 million of litigation settlement costs, and $0.5 million of special performance bonuses, net of the related tax effects.

[0001375365-22-000092:8k_2_02:19]
Business Outlook and Management Commentary

[0001375365-22-000092:8k_2_02:20]
For the first quarter of fiscal year 2023 ending September 30, 2022, the Company expects net sales of $1.52 billion to $1.62 billion, GAAP net income per diluted share of $2.01 to $2.27 and non-GAAP net income per diluted share of $2.07 to $2.32. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 19.4% and 20.3%, respectively, and a fully diluted share count of 54.8 million shares for GAAP and fully diluted share count of 56.2 million shares for non-GAAP. The outlook for Q1 of fiscal year 2023 GAAP net income per diluted share includes approximately $8.6 million in expected stock-based compensation expense and $0.5 million in other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000092:8k_2_02:21]
For fiscal year 2023 ending June 30, 2023, the Company expects net sales of $6.2 billion to $7.0 billion, GAAP net income per diluted share of at least $7.27 and non-GAAP net income per diluted share of at least $7.50. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 20.3% and 21.1%, respectively, and a fully diluted share count of 55.6 million shares for GAAP and fully diluted share count of 57.0 million shares for non-GAAP. The outlook for fiscal year 2023 GAAP net income per diluted share includes approximately $35.4 million in expected stock-based compensation expense and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000092:8k_2_02:22]
Conference Call and Webcast Information

[0001375365-22-000092:8k_2_02:23]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its fourth quarter and full-year fiscal 2022 financial results. Those wishing to access the live webcast may use the following link:

[0001375365-22-000092:8k_2_02:24]
https://events.q4inc.com/attendee/361336377

[0001375365-22-000092:8k_2_02:25]
The conference call can be accessed by registering online at:

[0001375365-22-000092:8k_2_02:26]
https://conferencingportals.com/event/fIceWmPv

[0001375365-22-000092:8k_2_02:27]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-22-000092:8k_2_02:28]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-22-000092:8k_2_02:29]
Cautionary Statement Regarding Forward-Looking Statements

[0001375365-22-000092:8k_2_02:30]
Use of Non-GAAP Financial Measures

[0001375365-22-000092:8k_2_02:31]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, litigation and controls remediation expenses, litigation settlement costs and other expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-22-000092:8k_2_02:32]
About Super Micro Computer, Inc.

[0001375365-22-000092:8k_2_02:33]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-22-000092:8k_2_02:34]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-22-000092:8k_2_02:35]
Investor Relations Contact:

[0001375365-22-000092:8k_2_02:36]
Nicole Noutsios

[0001375365-22-000092:8k_2_02:37]
email: ir@supermicro.com

[0001375365-22-000092:8k_2_02:38]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000092:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-22-000092:8k_2_02:40]
(in thousands)

[0001375365-22-000092:8k_2_02:41]
(unaudited)

[0001375365-22-000092:8k_2_02:42]
|  | June 30, |  | June 30, |
|  | 2022 |  | 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 267,397 |  |  | $ | 232,266 |  |
| Accounts receivable, net of allowances | 834,513 |  |  | 463,834 |  |
| Inventories | 1,545,606 |  |  | 1,040,964 |  |
| Prepaid expenses and other current assets | 158,799 |  |  | 130,195 |  |
| Total current assets | 2,806,315 |  |  | 1,867,259 |  |
| Investment in equity investee | 5,329 |  |  | 4,578 |  |
| Property, plant and equipment, net | 285,972 |  |  | 274,713 |  |
| Deferred income taxes, net | 69,929 |  |  | 63,288 |  |
| Other assets | 37,532 |  |  | 32,126 |  |
| Total assets | $ | 3,205,077 |  |  | $ | 2,241,964 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 655,403 |  |  | $ | 612,336 |  |
| Accrued liabilities | 212,419 |  |  | 178,850 |  |
| Income taxes payable | 41,743 |  |  | 12,741 |  |
| Short-term debt | 449,146 |  |  | 63,490 |  |
| Deferred revenue | 111,313 |  |  | 101,479 |  |
| Total current liabilities | 1,470,024 |  |  | 968,896 |  |
| Deferred revenue, non-current | 122,548 |  |  | 100,838 |  |
| Long-term debt | 147,618 |  |  | 34,700 |  |
| Other long-term liabilities | 39,140 |  |  | 41,132 |  |
| Total liabilities | 1,779,330 |  |  | 1,145,566 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid in capital | 481,741 |  |  | 438,012 |  |
| Accumulated other comprehensive income | 911 |  |  | 453 |  |
| Retained earnings | 942,923 |  |  | 657,760 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,425,575 |  |  | 1,096,225 |  |
| Noncontrolling interest | 172 |  |  | 173 |  |
| Total stockholders’ equity | 1,425,747 |  |  | 1,096,398 |  |
| Total liabilities and stockholders’ equity | $ | 3,205,077 |  |  | $ | 2,241,964 |  |

[0001375365-22-000092:8k_2_02:43]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000092:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-22-000092:8k_2_02:45]
(in thousands, except share and per share amounts)

[0001375365-22-000092:8k_2_02:46]
(unaudited)

[0001375365-22-000092:8k_2_02:47]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,635,460 |  |  | $ | 1,068,985 |  |  | $ | 5,196,099 |  |  | $ | 3,557,422 |  |
| Cost of sales | 1,348,116 |  |  | 923,474 |  |  | 4,396,098 |  |  | 3,022,884 |  |
| Gross profit | 287,344 |  |  | 145,511 |  |  | 800,001 |  |  | 534,538 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 70,790 |  |  | 58,930 |  |  | 272,273 |  |  | 224,369 |  |
| Sales and marketing | 24,186 |  |  | 22,825 |  |  | 90,126 |  |  | 85,683 |  |
| General and administrative | 27,155 |  |  | 24,675 |  |  | 102,435 |  |  | 100,539 |  |
| Total operating expenses | 122,131 |  |  | 106,430 |  |  | 464,834 |  |  | 410,591 |  |
| Income from operations | 165,213 |  |  | 39,081 |  |  | 335,167 |  |  | 123,947 |  |
| Other income (expense), net | 3,973 |  |  | (1,471) |  |  | 8,079 |  |  | (2,834) |  |
| Interest expense | (2,928) |  |  | (635) |  |  | (6,413) |  |  | (2,485) |  |
| Income before income tax | 166,258 |  |  | 36,975 |  |  | 336,833 |  |  | 118,628 |  |
| Income tax (provision) benefit | (25,760) |  |  | 1,605 |  |  | (52,876) |  |  | (6,936) |  |
| Share of income from equity investee, net of taxes | 324 |  |  | 582 |  |  | 1,206 |  |  | 173 |  |
| Net income | $ | 140,822 |  |  | $ | 39,162 |  |  | $ | 285,163 |  |  | $ | 111,865 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 2.70 |  |  | $ | 0.78 |  |  | $ | 5.54 |  |  | $ | 2.19 |  |
| Diluted | $ | 2.60 |  |  | $ | 0.74 |  |  | $ | 5.32 |  |  | $ | 2.09 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 52,111 |  |  | 50,230 |  |  | 51,478 |  |  | 51,157 |  |
| Diluted | 54,260 |  |  | 52,782 |  |  | 53,615 |  |  | 53,507 |  |

[0001375365-22-000092:8k_2_02:48]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-22-000092:8k_2_02:49]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of sales | $ | 498 |  |  | $ | 450 |  |  | $ | 1,876 |  |  | $ | 1,762 |  |
| Research and development | 4,447 |  |  | 3,661 |  |  | 16,571 |  |  | 14,030 |  |
| Sales and marketing | 541 |  |  | 505 |  |  | 2,058 |  |  | 2,022 |  |
| General and administrative | 3,398 |  |  | 2,816 |  |  | 12,311 |  |  | 10,735 |  |
| Stock-based compensation expense | $ | 8,884 |  |  | $ | 7,432 |  |  | $ | 32,816 |  |  | $ | 28,549 |  |

[0001375365-22-000092:8k_2_02:50]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000092:8k_2_02:51]
SELECTED CASH FLOW INFORMATION

[0001375365-22-000092:8k_2_02:52]
(in thousands)

[0001375365-22-000092:8k_2_02:53]
(unaudited)

[0001375365-22-000092:8k_2_02:54]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |
| Net cash (used in) provided by operating activities | $ | (440,801) |  |  | $ | 122,955 |  |
| Net cash used in investing activities | (46,282) |  |  | (58,016) |  |
| Net cash provided by (used in) financing activities | 522,871 |  |  | (44,440) |  |
| Effect of exchange rate fluctuations on cash | (678) |  |  | 560 |  |
| Net change in cash, cash equivalents and restricted cash | 35,110 |  |  | 21,059 |  |
| Cash, cash equivalents and restricted cash at the beginning of the year | 233,449 |  |  | 212,390 |  |
| Cash, cash equivalents and restricted cash at the end of the year | $ | 268,559 |  |  | $ | 233,449 |  |

[0001375365-22-000092:8k_2_02:55]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000092:8k_2_02:56]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000092:8k_2_02:57]
(in thousands, except per share amounts)

[0001375365-22-000092:8k_2_02:58]
(unaudited)

[0001375365-22-000092:8k_2_02:59]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |  |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |
| GAAP GROSS PROFIT | $ | 287,344 |  |  | $ | 145,511 |  |  | $ | 800,001 |  |  | $ | 534,538 |  |  |
| Stock-based compensation | 498 |  |  | 450 |  |  | 1,876 |  |  | 1,762 |  |  |
| Other expenses | — |  |  | — |  |  | 295 |  |  | 20 |  |  |
| NON-GAAP GROSS PROFIT | $ | 287,842 |  |  | $ | 145,961 |  |  | $ | 802,172 |  |  | $ | 536,320 |  |  |
| GAAP GROSS MARGIN | 17.6 | % |  | 13.6 | % |  | 15.4 | % |  | 15.0 | % |  |
| Stock-based compensation | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  | 0.1 | % |  |
| Other expenses | — |  |  | — |  |  | 0.0 | % |  | 0.0 | % |  |
| NON-GAAP GROSS MARGIN | 17.6 | % |  | 13.7 | % |  | 15.4 | % |  | 15.1 | % |  |
| GAAP OPERATING EXPENSES | $ | 122,131 |  |  | $ | 106,430 |  |  | $ | 464,834 |  |  | $ | 410,591 |  |  |
| Stock-based compensation | (8,386) |  |  | (6,982) |  |  | (30,940) |  |  | (26,787) |  |  |
| Executive SEC settlement | — |  |  | — |  |  | — |  |  | 2,122 |  |  |
| Litigation settlement costs | — |  |  | — |  |  | (2,000) |  |  | — |  |  |
| Special performance bonuses | — |  |  | (672) |  |  | (158) |  |  | (5,801) |  |  |
| Other expenses | — |  |  | — |  |  | — |  |  | (221) |  |  |
| Litigation and controls remediation expense | (234) |  |  | 163 |  |  | (4,367) |  |  | (1,076) |  |  |
| NON-GAAP OPERATING EXPENSES | $ | 113,511 |  |  | $ | 98,939 |  |  | $ | 427,369 |  |  | $ | 378,828 |  |  |
| GAAP INCOME FROM OPERATIONS | $ | 165,213 |  |  | $ | 39,081 |  |  | $ | 335,167 |  |  | $ | 123,947 |  |  |
| Stock-based compensation | 8,884 |  |  | 7,432 |  |  | 32,816 |  |  | 28,549 |  |  |
| Executive SEC settlement | — |  |  | — |  |  | — |  |  | (2,122) |  |  |
| Litigation settlement costs | — |  |  | — |  |  | 2,000 |  |  | — |  |  |
| Special performance bonuses | — |  |  | 672 |  |  | 453 |  |  | 5,801 |  |  |
| Other expenses | — |  |  | — |  |  | — |  |  | 241 |  |  |
| Litigation and controls remediation expenses | 234 |  |  | (163) |  |  | 4,367 |  |  | 1,076 |  |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 174,331 |  |  | $ | 47,022 |  |  | $ | 374,803 |  |  | $ | 157,492 |  |  |
| GAAP OPERATING MARGIN | 10.1 | % |  | 3.7 | % |  | 6.5 | % |  | 3.5 | % |  |
| Stock-based compensation | 0.6 | % |  | 0.7 | % |  | 0.6 | % |  | 0.8 | % |  |
| Executive SEC settlement | — | % |  | — | % |  | — | % |  | (0.1) | % |  |
| Litigation settlement costs | — | % |  | — | % |  | 0.0 | % |  | — | % |  |
| Special performance bonuses | — | % |  | 0.0 | % |  | 0.0 | % |  | 0.2 | % |  |
| Other expenses | — | % |  | — | % |  | — | % |  | 0.0 | % |  |
| Litigation and controls remediation expenses | 0.0 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  |
| NON-GAAP OPERATING MARGIN | 10.7 | % |  | 4.4 | % |  | 7.2 | % |  | 4.4 | % |  |
| GAAP TAX EXPENSE (BENEFIT) | $ | 25,760 |  |  | $ | (1,605) |  |  | $ | 52,876 |  |  | $ | 6,936 |  |  |
| Adjustments to tax provision | 4,137 |  |  | 3,373 |  |  | 13,721 |  |  | 9,006 |  |  |
| NON-GAAP TAX EXPENSE | $ | 29,897 |  |  | $ | 1,768 |  |  | $ | 66,597 |  |  | $ | 15,942 |  |  |

[0001375365-22-000092:8k_2_02:60]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000092:8k_2_02:61]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000092:8k_2_02:62]
(in thousands, except per share amounts)

[0001375365-22-000092:8k_2_02:63]
(unaudited)

[0001375365-22-000092:8k_2_02:64]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |  |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |
| GAAP NET INCOME | $ | 140,822 |  |  | $ | 39,162 |  |  | $ | 285,163 |  |  | $ | 111,865 |  |  |
| Stock-based compensation | 8,884 |  |  | 7,432 |  |  | 32,816 |  |  | 28,549 |  |  |
| Executive SEC settlement | — |  |  | — |  |  | — |  |  | (2,122) |  |  |
| Special performance bonuses | — |  |  | 672 |  |  | 453 |  |  | 5,801 |  |  |
| Litigation settlement costs | — |  |  | — |  |  | 2,000 |  |  | — |  |  |
| Other expenses | — |  |  | — |  |  | — |  |  | 241 |  |  |
| Litigation and controls remediation expenses | 234 |  |  | (163) |  |  | 4,367 |  |  | 1,076 |  |  |
| Adjustments to tax provision | (4,137) |  |  | (3,373) |  |  | (13,721) |  |  | (9,006) |  |  |
| NON-GAAP NET INCOME | $ | 145,803 |  |  | $ | 43,730 |  |  | $ | 311,078 |  |  | $ | 136,404 |  |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 2.70 |  |  | $ | 0.78 |  |  | $ | 5.54 |  |  | $ | 2.19 |  |  |
| Impact of NON-GAAP adjustments | 0.10 |  |  | 0.09 |  |  | 0.50 |  |  | 0.48 |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 2.80 |  |  | $ | 0.87 |  |  | $ | 6.04 |  |  | $ | 2.67 |  |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 2.60 |  |  | $ | 0.74 |  |  | $ | 5.32 |  |  | $ | 2.09 |  |  |
| Impact of NON-GAAP adjustments | 0.02 |  |  | 0.07 |  |  | 0.33 |  |  | 0.39 |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 2.62 |  |  | $ | 0.81 |  |  | $ | 5.65 |  |  | $ | 2.48 |  |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 52,111 |  |  | 50,230 |  |  | 51,478 |  |  | 51,157 |  |  |
| BASIC – NON-GAAP | 52,111 |  |  | 50,230 |  |  | 51,478 |  |  | 51,157 |  |  |
| DILUTED – GAAP | 54,260 |  |  | 52,782 |  |  | 53,615 |  |  | 53,507 |  |  |
| DILUTED – NON-GAAP | 55,611 |  |  | 54,082 |  |  | 55,025 |  |  | 54,910 |  |  |
