# SMCI MD&A — 0001375365-22-000103


## mdna

[0001375365-22-000103:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-22-000103:mdna:2]
Overview

[0001375365-22-000103:mdna:3]
We are a Silicon Valley-based provider of accelerated compute platforms that are application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence, 5G and edge computing. Our Total IT Solutions include complete servers, storage systems, modular blade servers, blades, workstations, full rack scale solutions, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-22-000103:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2022, 2021 and 2020, our net income was $285.2 million, $111.9 million and $84.3 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-22-000103:mdna:5]
COVID-19 Pandemic Impact

[0001375365-22-000103:mdna:6]
COVID-19 and its variants have continued to create volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders that govern the operations of businesses. We are an essential critical infrastructure (information technology) business under the relevant federal, state and county regulations. Our first priority is the safety of our workforce and we have therefore implemented numerous health precautions and work practices to be in compliance with the law and to operate in a safe manner.

[0001375365-22-000103:mdna:7]
We have continued to see ongoing demand for our IT solutions and do not have significant direct exposure to industries which have been impacted the greatest. The COVID-19 pandemic has created additional demand for many server applications that support the global movement towards a digital economy. These applications include greater use of online transactions for everyday purchases by consumers of food, clothing, entertainment from gaming and video streaming, as well as tele-health, social networking, messaging, email, autonomous driving solutions and video conferencing companies.

[0001375365-22-000103:mdna:8]
We have actively managed our supply chain for potential shortage risk by building inventories of critical components required such as CPUs, memory, SSDs and GPUs to support our ability to fulfill customer orders. Our architecture, which is based on a “Building Block Solutions” design approach, has also assisted us during the COVID-19 pandemic, to qualify different components for compatibility with our systems to help us overcome some shortages.

[0001375365-22-000103:mdna:9]
Logistics has continued to be a challenge during the COVID-19 pandemic as the global transportation industry, and particularly ocean transportation, has been constrained by shortages of containers, labor, truckers and crowded ports. As a result, shipping by air, has been used more frequently despite that it is more expensive and there are fewer flights during the COVID-19 pandemic than there were previously. We have experienced increased costs in freight.  In addition, we also experienced increased direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect both of these trends to continue until the COVID-19 pandemic and other macroeconomic factors exacerbated by the COVID-19 pandemic end.

[0001375365-22-000103:mdna:10]
SMCI | 2022 Form 10-K | 37

[0001375365-22-000103:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In June 2021, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2026 and, in March 2022, further negotiated an increase in the size of our credit facility with Bank of America from $200 million to $350 million. In July 2021, we replaced our prior credit facility and term loan facility with CTBC Bank, with a new facility for omnibus credit lines. In September 2021, we replaced our prior credit facility with E.SUN Bank, with new credit facility and term facility. In September 2021 and April 2022, we entered into a term loan facility and credit line, respectively, with Mega Bank which will be used to support our manufacturing activities (including the purchase of materials and components) and provide medium-term working capital. In October 2021, we entered into a credit facility with Chang Hwa Bank and in January 2022 we entered into a loan agreement with HSBC Bank, each of which will be used to support the growth of our Taiwan business. In May 2022, we also entered into a line of credit with Cathay Bank to be used for general corporate purposes to support our growth. In August 2022, we entered into a new general credit agreement with E.Sun Bank which replaced the prior E.Sun Bank credit facility which will also support the growth of our Taiwan business. Refer to Part II, Item 8, Note 9, “Short-term and Long-term Debt” in our notes to consolidated financial statements in this Annual Report on Form 10-K for further information on our outstanding debt

[0001375365-22-000103:mdna:12]
Our management team is focused on guiding our company through the ongoing challenges presented by the COVID-19 pandemic, including the emergence of any new variants. There are positive signs with the expiration of various COVID-19 mandates, vaccine availability and the rollout of boosters; however, with the possibility of the emergence of other new virus strains and ongoing adverse impacts of the COVID-19 pandemic on economic recovery, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations.

[0001375365-22-000103:mdna:13]
Financial Highlights

[0001375365-22-000103:mdna:14]
The following is a summary of financial highlights of fiscal years 2022 and 2021:

[0001375365-22-000103:mdna:15]
•Net sales increased by 46.1% in fiscal year 2022 as compared to fiscal year 2021.

[0001375365-22-000103:mdna:16]
•Gross margin increased to 15.4% in fiscal year 2022 from 15.0% in fiscal year 2021, primarily due to product and customer mix and was offset by increased logistic costs.

[0001375365-22-000103:mdna:17]
•Operating expenses increased by 13.2% in fiscal year 2022 as compared to fiscal year 2021, primarily due to the increase in personnel expenses as a result of salary increases and a higher headcount.

[0001375365-22-000103:mdna:18]
•Net income increased to $285.2 million in fiscal year 2022 as compared to $111.9 million in fiscal year 2021, which was primarily due to the higher net sales and lower operating expenses as a percentage of revenues in fiscal year 2022 as compared to fiscal year 2021.

[0001375365-22-000103:mdna:19]
•Our cash and cash equivalents were $267.4 million and $232.3 million at the end of fiscal years 2022 and 2021, respectively. In fiscal year 2022, we generated net cash of $35.1 million and $522.9 million in cash provided by financing activities primarily due to the proceeds from borrowings and invested $45.2 million in purchases of property and equipment. We used $440.8 million in operating activities primarily related to the increase in inventories and accounts receivables.

[0001375365-22-000103:mdna:20]
SMCI | 2022 Form 10-K | 38

[0001375365-22-000103:mdna:21]
Critical Accounting Policies and Estimates

[0001375365-22-000103:mdna:22]
General

[0001375365-22-000103:mdna:23]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-22-000103:mdna:24]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-22-000103:mdna:25]
Revenue Recognition

[0001375365-22-000103:mdna:26]
The most critical accounting policy estimate and judgments required in applying ASC 606, Revenue Recognition of Contracts from Customers, and our revenue recognition policy relate to the determination of the transaction price, distinct performance obligations and the evaluation of the standalone selling price (the “SSP”) for each performance obligation.

[0001375365-22-000103:mdna:27]
We generate revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services. Many of our customer contracts include multiple performance obligations. Judgment is required in determining whether each performance obligation within a customer contract is distinct. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.

[0001375365-22-000103:mdna:28]
As part of determining the transaction price in contracts with customers, we may be required to estimate variable consideration when determining the amount of revenue to recognize. We estimate reserves for future sales returns based on a review of our history of actual returns. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. We also estimate the costs of customer and distributor programs and incentive offerings such as price protection, rebates, as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-22-000103:mdna:29]
We allocate the transaction price for each customer contract to each performance obligation based on the relative SSP for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the respective performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgement. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we apply judgment to estimate the SSP. For substantially all performance obligations, we are able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-22-000103:mdna:30]
These estimates and judgements have not fluctuated significantly for the fiscal year ended June 30, 2022 compared to prior fiscal years.

[0001375365-22-000103:mdna:31]
SMCI | 2022 Form 10-K | 39

[0001375365-22-000103:mdna:32]
Inventories

[0001375365-22-000103:mdna:33]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-22-000103:mdna:34]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold. We determine the volume-based rebates to be recognized in the cost of sales on a first-in, first-out basis.

[0001375365-22-000103:mdna:35]
Income Taxes

[0001375365-22-000103:mdna:36]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or when loss or credit carryforwards are utilized. In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001375365-22-000103:mdna:37]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and reflect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-22-000103:mdna:38]
Stock-Based Compensation

[0001375365-22-000103:mdna:39]
We measure and recognize compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. We base initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-22-000103:mdna:40]
SMCI | 2022 Form 10-K | 40

[0001375365-22-000103:mdna:41]
The fair value of RSUs and PRSUs is based on the closing market price of our common stock on the date of grant. We estimate the fair value of stock options granted using a Black-Scholes option pricing model. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the historical volatility of our common stock. The assumptions used to determine the fair value of the option awards represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. Our use of the Black-Scholes option-pricing model requires the input of highly subjective assumptions. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.

[0001375365-22-000103:mdna:42]
Variable Interest Entities

[0001375365-22-000103:mdna:43]
We determine at the inception of each arrangement whether an entity in which we hold an investment or in which we have other variable interests is considered a variable interest entity ("VIE"). We consolidate VIEs when we are the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, we assess whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether we are the primary beneficiary. If we are not the primary beneficiary in a VIE, we account for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-22-000103:mdna:44]
We have concluded that Ablecom and its affiliate, Compuware, are VIEs; however, we are not the primary beneficiary as we do not have the power to direct the activities that are most significant to the entities and therefore, we do not consolidate these entities. In performing this analysis, we considered our explicit arrangements with Ablecom and Compuware, including all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between us and these two companies, we considered whether any implicit arrangements exist that would cause us to protect these related parties’ interests from suffering losses. We determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-22-000103:mdna:45]
Our ability to assess correctly our influence or control over an entity at inception of our involvement or on a continuous basis when determining the primary beneficiary of a VIE affects the presentation of these entities in our consolidated financial statements. Subsequent evaluations of the primary beneficiary of a VIE may require the use of different assumptions that could lead to identification of a different primary beneficiary, resulting in a different consolidation conclusion than what was determined at inception of the arrangement.

[0001375365-22-000103:mdna:46]
SMCI | 2022 Form 10-K | 41

[0001375365-22-000103:mdna:47]
Results of Operations

[0001375365-22-000103:mdna:48]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of revenue.

[0001375365-22-000103:mdna:49]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.6 | % |  | 85.0 | % |  | 84.2 | % |
| Gross profit | 15.4 | % |  | 15.0 | % |  | 15.8 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 5.2 | % |  | 6.3 | % |  | 6.6 | % |
| Sales and marketing | 1.7 | % |  | 2.4 | % |  | 2.5 | % |
| General and administrative | 2.0 | % |  | 2.8 | % |  | 4.1 | % |
| Total operating expenses | 8.9 | % |  | 11.5 | % |  | 13.2 | % |
| Income from operations | 6.5 | % |  | 3.5 | % |  | 2.6 | % |
| Other (expense) income, net | 0.2 | % |  | (0.1) | % |  | — | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 6.6 | % |  | 3.3 | % |  | 2.5 | % |
| Income tax provision | (1.0) | % |  | (0.2) | % |  | (0.1) | % |
| Share of income from equity investee, net of taxes | — | % |  | — | % |  | 0.1 | % |
| Net income | 5.6 | % |  | 3.1 | % |  | 2.5 | % |

[0001375365-22-000103:mdna:50]
Net Sales

[0001375365-22-000103:mdna:51]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-22-000103:mdna:52]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPU/GPU, memory and storage.

[0001375365-22-000103:mdna:53]
The following table presents net sales by product type for fiscal years 2022, 2021 and 2020 (dollars in millions):

[0001375365-22-000103:mdna:54]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 4,463.8 |  |  | $ | 2,790.3 |  |  | $ | 2,620.8 |  |  | $ | 1,673.5 |  |  | 60.0 | % |  | $ | 169.5 |  |  | 6.5 | % |
| Percentage of total net sales | 85.9 | % |  | 78.4 | % |  | 78.5 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 732.3 |  |  | 767.1 |  |  | 718.5 |  |  | (34.8) |  |  | (4.5) | % |  | 48.6 |  |  | 6.8 | % |
| Percentage of total net sales | 14.1 | % |  | 21.6 | % |  | 21.5 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 5,196.1 |  |  | $ | 3,557.4 |  |  | $ | 3,339.3 |  |  | $ | 1,638.7 |  |  | 46.1 | % |  | $ | 218.1 |  |  | 6.5 | % |

[0001375365-22-000103:mdna:55]
SMCI | 2022 Form 10-K | 42

[0001375365-22-000103:mdna:56]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:57]
During fiscal year 2022 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to an increase of average selling prices per compute node by approximately 32% as well as an increase of approximately 23% in the number of units of compute nodes sold. The year-over-year decrease in net sales of subsystems and accessories was primarily due to our emphasis on selling full systems and servers. Our services and software revenue, included in server and storage systems revenue, increased by $2.5 million year-over-year.

[0001375365-22-000103:mdna:58]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:59]
During fiscal year 2021 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to an increase of average selling prices per compute node by approximately 17%, offset by a decrease of approximately 9% in the number of units of compute nodes sold. We typically adjust our selling prices as component costs rise and fall. The increase in average selling prices was primarily due to significant inventory component price increases resulting from component shortages during fiscal year 2021. The year-over-year increase in net sales of subsystems and accessories was primarily due to an increase of approximately 5% in the volume of subsystems and accessories sold, mainly due to increased demand and an approximately 2% increase in average selling prices due primarily to the increase in costs of the components. Our services and software revenue, included in server and storage systems revenue, increased by $0.2 million year-over-year.

[0001375365-22-000103:mdna:60]
The following table presents percentages of net sales by geographic region for fiscal years 2022, 2021 and 2020 (dollars in millions):

[0001375365-22-000103:mdna:61]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| United States | $ | 3,035.5 |  |  | $ | 2,107.9 |  |  | $ | 1,957.3 |  |  | $ | 927.6 |  |  | 44.0 | % |  | $ | 150.6 |  |  | 7.7 | % |
| Percentage of total net sales | 58.4 | % |  | 59.3 | % |  | 58.6 | % |  |  |  |  |  |  |  |  |
| Asia | 1,139.9 |  |  | 699.7 |  |  | 650.7 |  |  | 440.2 |  |  | 62.9 | % |  | 49.0 |  |  | 7.5 | % |
| Percentage of total net sales | 21.9 | % |  | 19.7 | % |  | 19.5 | % |  |  |  |  |  |  |  |  |
| Europe | 825.2 |  |  | 614.8 |  |  | 598.6 |  |  | 210.4 |  |  | 34.2 | % |  | 16.2 |  |  | 2.7 | % |
| Percentage of total net sales | 15.9 | % |  | 17.3 | % |  | 17.9 | % |  |  |  |  |  |  |  |  |
| Others | 195.5 |  |  | 135.0 |  |  | 132.7 |  |  | 60.5 |  |  | 44.8 | % |  | 2.3 |  |  | 1.7 | % |
| Percentage of total net sales | 3.7 | % |  | 3.7 | % |  | 4.0 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 5,196.1 |  |  | $ | 3,557.4 |  |  | $ | 3,339.3 |  |  | $ | 1,638.7 |  |  | 46.1 | % |  | $ | 218.1 |  |  | 6.5 | % |

[0001375365-22-000103:mdna:62]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:63]
The year over year increase in overall net sales is the result of increased selling prices and quantities of product shipments. Asia experienced the highest percentage growth among all regions. China, Japan and Korea exceeded the overall regional average of growth, which was the primary driver of the increases in net sales in Asia. Russia experienced a year over year decrease due to the conflict in that region, which decrease had an immaterial impact on our overall performance.

[0001375365-22-000103:mdna:64]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:65]
The year-over-year increase in net sales in the United States was primarily due to an increase in net sales of our server and storage systems. The year-over-year increase in net sales in Asia was primarily due to an increase in net sales of our server and storage systems in China, Singapore, India and Japan, partially offset by a decrease in the net sales in Taiwan. The year-over-year increase in net sales in Europe was primarily due to an increase in net sales of our server and storage systems in the Germany, UK and France, partially offset by a decrease in net sales in the Netherlands and Russia.

[0001375365-22-000103:mdna:66]
SMCI | 2022 Form 10-K | 43

[0001375365-22-000103:mdna:67]
Cost of Sales and Gross Margin

[0001375365-22-000103:mdna:68]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-22-000103:mdna:69]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware combined represented 8.3%, 7.8% and 10.1% of our cost of sales for fiscal years 2022, 2021 and 2020, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 12, “Related Party Transactions.”

[0001375365-22-000103:mdna:70]
Cost of sales and gross margin for fiscal years 2022, 2021 and 2020, are as follows (dollars in millions):

[0001375365-22-000103:mdna:71]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 4,396.1 |  |  | $ | 3,022.9 |  |  | $ | 2,813.1 |  |  | $ | 1,373.2 |  |  | 45.4 | % |  | $ | 209.8 |  |  | 7.5 | % |
| Gross profit | 800.0 |  |  | 534.5 |  |  | 526.2 |  |  | 265.5 |  |  | 49.7 | % |  | 8.3 |  |  | 1.6 | % |
| Gross margin | 15.4 | % |  | 15.0 | % |  | 15.8 | % |  |  |  | 0.4 | % |  |  |  | (0.8) | % |

[0001375365-22-000103:mdna:72]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:73]
The year-over-year increase in cost of sales was primarily attributed to an increase of $1,262.6 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $54.9 million increase in freight charges, a $23.6 million increase in overhead costs, a $18.9 million increase due to lower cost recovery of cost paid in prior periods, a $8.3 million increase in excess and obsolete inventory charges and a $4.9 million increase in other cost of sales.

[0001375365-22-000103:mdna:74]
The year-over-year increase in the gross margin percentage was primarily due to sales prices increases, product and customer mix and higher capitalization of manufacturing overhead due to higher inventory levels, offset by higher costs from freight, overhead, other cost of sales, excess and obsolete inventory charges, and lower recovery of costs from prior periods.  Since the start of the COVID-19 pandemic, we have experienced an increase in costs of sales, logistics costs as well as direct labor costs as we incentivize our employees. This increase in costs negatively impacts our gross margin, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-22-000103:mdna:75]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:76]
The year-over-year increase in cost of sales was primarily attributable to an increase of $244.1 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume and an increase of $8.9 million in the cost of freight. This was offset by a decrease of $29.5 million in overhead costs attributable primarily to a recovery of costs paid in prior periods, a decrease of $12.4 million in the provision of excess inventory and obsolescence and a decrease of $2.6 million in personnel expenses due to a decrease in special performance bonuses in the fiscal year 2021. Warranty and repairs costs also decreased by $3.4 million in the fiscal year 2021 as compared to the fiscal year 2020.

[0001375365-22-000103:mdna:77]
SMCI | 2022 Form 10-K | 44

[0001375365-22-000103:mdna:78]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of components and due to the decrease in services and software revenue which have higher margins than product sales. Since the start of the COVID-19 pandemic, we have experienced an increase in both logistics costs as well as direct labor costs as we incentivize our employees to continue to work and assist us in serving our customers.  This increase in costs negatively impacts our gross margins, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-22-000103:mdna:79]
Operating Expenses

[0001375365-22-000103:mdna:80]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-22-000103:mdna:81]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-22-000103:mdna:82]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-22-000103:mdna:83]
Operating expenses for fiscal years 2022, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000103:mdna:84]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 272.3 |  |  | $ | 224.4 |  |  | $ | 221.5 |  |  | $ | 47.9 |  |  | 21.3 | % |  | $ | 2.9 |  |  | 1.3 | % |
| Percentage of total net sales | 5.2 | % |  | 6.3 | % |  | 6.6 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 90.1 |  |  | 85.7 |  |  | 85.1 |  |  | 4.4 |  |  | 5.1 | % |  | 0.6 |  |  | 0.7 | % |
| Percentage of total net sales | 1.7 | % |  | 2.4 | % |  | 2.5 | % |  |  |  |  |  |  |  |  |
| General and administrative | 102.4 |  |  | 100.5 |  |  | 133.9 |  |  | 1.9 |  |  | 1.9 | % |  | (33.4) |  |  | (24.9) | % |
| Percentage of total net sales | 2.0 | % |  | 2.8 | % |  | 4.0 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 464.8 |  |  | $ | 410.6 |  |  | $ | 440.5 |  |  | 54.2 |  |  | 13.2 | % |  | (29.9) |  |  | (6.8) | % |

[0001375365-22-000103:mdna:85]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:86]
The year-over-year increase in research and development expenses was primarily due to a $40.8 million increase in personnel expenses due to salary increases and a higher headcount, $3.7 million lower research and development credits from certain suppliers and customers towards our development efforts and a $3.4 million increase in product development costs.

[0001375365-22-000103:mdna:87]
The year-over-year increase in sales and marketing expenses was primarily due to a $9.6 million increase in personnel expenses due to salary increases and a higher headcount, offset by a $5.7 million increase in marketing development funds received and a $0.5 million increase in advertising and other expenses.

[0001375365-22-000103:mdna:88]
SMCI | 2022 Form 10-K | 45

[0001375365-22-000103:mdna:89]
The year-over-year increase in general and administrative expenses was primarily due to a $4.1 million increase in legal and litigation settlement expenses and $6.6 million increase in personnel and other expenses due to salary increases and a higher headcount offset by decrease of $1.5 million in professional fees driven by lower expenses incurred to remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of our previously issued financial statements and a $7.3 million decrease in expense from special performance awards.

[0001375365-22-000103:mdna:90]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:91]
The year-over-year increase in research and development expenses was primarily due to an increase of $11.6 million in costs mainly related to materials, supplies and equipment used in product development. During fiscal year 2020, we recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred materials, supplies and equipment costs for one canceled joint product development agreement. Personnel expenses increased $1.7 million as a result of an increase in the number of research and development employees. These increases were partially offset by an increase of $8.8 million in research and development credits from certain suppliers and customers towards our development efforts and a $1.5 million decrease mainly due to decrease in travel expenses as a result of change in our operations in response to the COVID-19 pandemic.

[0001375365-22-000103:mdna:92]
The year-over-year increase in sales and marketing expenses was primarily due to an increase of $1.2 million in advertising expenses, a $1.0 million increase in other sales and marketing expenses, offset by a $1.7 million decrease in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic.

[0001375365-22-000103:mdna:93]
The year-over-year decrease in general and administrative expenses was due to a decrease of $41.8 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $3.4 million in other expenses related to the COVID-19 pandemic and a $1.1 million decrease in supplies costs. These decreases were partially offset by a $12.9 million increase in personnel expenses due to increased full time personnel and bonuses.

[0001375365-22-000103:mdna:94]
We anticipate the above expenses impacted by the COVID-19 pandemic to normalize if and when the COVID-19 pandemic is over.

[0001375365-22-000103:mdna:95]
Interest and Income (Expense), Net

[0001375365-22-000103:mdna:96]
Other income (expense), net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-22-000103:mdna:97]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-22-000103:mdna:98]
Interest and other income (expense), net for fiscal years 2022, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000103:mdna:99]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Other income (expense), net | $ | 8.1 |  |  | $ | (2.8) |  |  | $ | 1.4 |  |  | $ | 10.9 |  |  | (389.3) | % |  | $ | (4.2) |  |  | (300.0) | % |
| Interest expense | (6.4) |  |  | (2.5) |  |  | (2.2) |  |  | (3.9) |  |  | 156.0 | % |  | (0.3) |  |  | 13.6 | % |
| Interest and other income (expense), net | $ | 1.7 |  |  | $ | (5.3) |  |  | $ | (0.8) |  |  | $ | 7.0 |  |  | (132.1) | % |  | $ | (4.5) |  |  | 562.5 | % |

[0001375365-22-000103:mdna:100]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:101]
The change of $7.0 million in interest and other (expense) income, net was primarily attributable to a $10.9 million increase in foreign exchange gain due to favorable currency fluctuations primarily related to our borrowing facilities in Taiwan offset by a $3.9 million increase in interest expense due to increase in loan balances and interest rates.

[0001375365-22-000103:mdna:102]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:103]
The change of $4.5 million in interest expense and other (expense) income, net was attributable to a decrease of $2.4 million in interest income on our interest-bearing deposits due primarily to lower yields on investments and an increase of $1.8 million in foreign exchange loss due to unfavorable foreign currency fluctuations.

[0001375365-22-000103:mdna:104]
SMCI | 2022 Form 10-K | 46

[0001375365-22-000103:mdna:105]
Provision for Income Taxes

[0001375365-22-000103:mdna:106]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock-based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 14, “Income Taxes” to the consolidated financial statements in this Annual Report.

[0001375365-22-000103:mdna:107]
Provision for income taxes and effective tax rates for fiscal years 2022, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000103:mdna:108]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 52.9 |  |  | $ | 6.9 |  |  | $ | 2.9 |  |  | $ | 46.0 |  |  | 666.7 | % |  | $ | 4.0 |  |  | 137.9 | % |
| Percentage of total net sales | 1.0 | % |  | 0.2 | % |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 15.7 | % |  | 5.8 | % |  | 3.4 | % |  |  |  |  |  |  |  |  |

[0001375365-22-000103:mdna:109]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:110]
The year-over-year increase in the effective tax rate was primarily due to a significant increase in revenue and income before tax. Total effective tax rate increased by 9.5% from 5.8% for the fiscal year ended June 30, 2021 to 15.7% for the fiscal year ended June 30, 2022. This increase was driven by a 15.4% increase in the overall effective tax rate. R&D credit reduced the effective tax rate by 3.5% and foreign derived income reduced the effective tax rate by 1.4%.

[0001375365-22-000103:mdna:111]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:112]
The year-over-year increase in the effective tax rate was primarily due to a release of reserve from uncertain tax positions in the prior year.

[0001375365-22-000103:mdna:113]
Share of Income from Equity Investee, Net of Taxes

[0001375365-22-000103:mdna:114]
Share of income from equity investee, net of taxes represents our share of income from the Corporate Venture in which we have a 30% ownership.

[0001375365-22-000103:mdna:115]
Share of income from equity investee, net of taxes for fiscal years 2022, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000103:mdna:116]
|  | Years Ended June 30, |  | 2022 over 2021 Change |  | 2021 over 2020 Change |
|  | 2022 |  | 2021 |  | 2020 |  | $ |  | % |  | $ |  | % |
| Share of income from equity investee, net of taxes | $ | 1.2 |  |  | $ | 0.2 |  |  | $ | 2.4 |  |  | $ | 1.0 |  |  | 500.0 | % |  | $ | (2.2) |  |  | 91.7 | % |
| Percentage of total net sales | — | % |  | — | % |  | — | % |  |  |  |  |  |  |  |  |

[0001375365-22-000103:mdna:117]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-22-000103:mdna:118]
The period-over-period increase of $1.0 million in share of income from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-22-000103:mdna:119]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-22-000103:mdna:120]
The year-over-year decrease of $2.2 million in share of income from equity investee, net of taxes was primarily due to lower net income recognized by the Corporate Venture in the fiscal year 2021 as compared to 2020.

[0001375365-22-000103:mdna:121]
SMCI | 2022 Form 10-K | 47

[0001375365-22-000103:mdna:122]
Liquidity and Capital Resources

[0001375365-22-000103:mdna:123]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to an increase in the need for working capital due to longer supply chain manufacturing and delivery times as well as the financing of real property acquisitions and funds received from the exercise of employee stock options. Our cash and cash equivalents were $267.4 million and $232.3 million as of June 30, 2022 and 2021, respectively. Our cash in foreign locations was $169.5 million and $152.6 million as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:mdna:124]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-22-000103:mdna:125]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the twelve months following the issuance of these consolidated financial statements. In August 2022, we entered into a new general credit agreement with E.Sun Bank. This New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million in loans that will support the growth of our Taiwan business.

[0001375365-22-000103:mdna:126]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved the Prior Repurchase Program, which permitted us to repurchase up to an aggregate of $200.0 million of our common stock at market prices. The program was effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. We had $150.0 million of remaining availability under the Prior Repurchase Program as of June 30, 2022. Subsequently, on August 3, 2022, after the expiration of the Prior Repurchase Program, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first.

[0001375365-22-000103:mdna:127]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-22-000103:mdna:128]
|  | Years Ended June 30, |  | 2022 over 2021 |  | 2021 over 2020 |  |  |
|  | 2022 |  | 2021 |  | 2020 |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (440.8) |  |  | $ | 123.0 |  |  | $ | (30.3) |  |  | $ | (563.8) |  |  | $ | 153.3 |  |  |  |
| Net cash used in investing activities | $ | (46.3) |  |  | $ | (58.0) |  |  | $ | (43.6) |  |  | $ | 11.7 |  |  | $ | (14.4) |  |  |  |
| Net cash provided by (used in) financing activities | $ | 522.9 |  |  | $ | (44.4) |  |  | $ | 23.8 |  |  | $ | 567.3 |  |  | $ | (68.2) |  |  |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 35.1 |  |  | $ | 21.1 |  |  | $ | (49.8) |  |  | $ | 14.0 |  |  | $ | 70.9 |  |  |  |

[0001375365-22-000103:mdna:129]
Operating Activities

[0001375365-22-000103:mdna:130]
Net cash provided by operating activities decreased by $563.8 million for fiscal year 2022 as compared to fiscal year 2021. The decrease was primarily due to an increase in net cash required for net working capital of $739.6 million to meet customer demand, support expected business growth and mitigate supply chain risk as a result of the COVID-19 pandemic environment and a $16.2 million decrease in unrealized gain and loss. These decreases are partially offset by increases in provision for excess and obsolete inventories of $8.3 million, depreciation and amortization expense of $4.3 million, stock-based compensation expense of $4.3 million and net income of $173.3 million. Since the beginning of the COVID-19 pandemic and the accompanying supply chain disruptions our management decided to increase our holdings of all components of our inventory (finished goods, work in process and purchased parts and raw materials). This decision reflected our belief that we had opportunities to increase our net sales if we could mitigate the risk of being unable to satisfy customer demand because of these supply chain disruptions, including longer lead times. We expect disruption of the supply chain and longer lead times to continue for the foreseeable future and therefore expect to continue to carry larger amounts of inventory than we would if the supply chain were functioning more normally and predictably.

[0001375365-22-000103:mdna:131]
SMCI | 2022 Form 10-K | 48

[0001375365-22-000103:mdna:132]
Net cash provided by operating activities increased by $153.3 million for fiscal year 2021 as compared to fiscal year 2020. While net income increased by $27.6 million in fiscal year 2021 as compared to fiscal year 2020, the increase in cash flows from operating activities was due primarily to a decrease of cash used for net working capital requirements of $120.3 million. Non-cash charges related to stock-based compensation expense increased by $8.4 million, collection of bad debt previously reserved decreased by $2.3 million, income from equity investee decreased by $2.2 million and $5.4 million decrease in the non-cash charges related to the change in our deferred income tax assets. These increases in the cash flow from operating activities were partially offset by the decrease of $11.6 million in previously reserved excess and obsolete inventory.

[0001375365-22-000103:mdna:133]
Investing Activities

[0001375365-22-000103:mdna:134]
Net cash used in investing activities was $46.3 million, $58.0 million and $43.6 million for fiscal years 2022, 2021 and 2020, respectively, as we invested in our Green Computing Park in San Jose to expand our capacity and office space we purchased and expanded our Bade Facility in Taiwan and made purchases of property, plant and equipment.

[0001375365-22-000103:mdna:135]
Financing Activities

[0001375365-22-000103:mdna:136]
Net cash used in financing activities increased by $567.3 million for fiscal year 2022 as compared to fiscal year 2021 primarily due to an increase of $446.2 million in proceeds from borrowings net of repayment, offset by a $130.0 million decrease in stock repurchases. Net cash used in financing activities increased by $68.2 million for fiscal year 2021 as compared to fiscal year 2020 primarily due to an increase of $130.0 million in repurchase of our common stock, partially offset by an increase of $61.9 million in proceeds from borrowings net of repayment.

[0001375365-22-000103:mdna:137]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-22-000103:mdna:138]
Refer to Part II, Item 8, Note 9, “Short-term and Long-term Debt” in our notes to consolidated financial statements in this Annual Report on Form 10-K for further information on our outstanding debt.

[0001375365-22-000103:mdna:139]
Capital Expenditure Requirements

[0001375365-22-000103:mdna:140]
We anticipate our capital expenditures in fiscal year 2023 will be approximately $21.2 million, relating primarily to costs associated in our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-22-000103:mdna:141]
We intend to continue to focus our capital expenditures in fiscal year 2023 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-22-000103:mdna:142]
Contractual Obligations

[0001375365-22-000103:mdna:143]
Our estimated future obligations as of June 30, 2022, include both current and long term obligations. For our long-term debt as noted in Part II, Item 8, Note 9, “Short-term and Long-term Debt”, we have a current obligation of $449.1 million and a long-term obligation of $147.6 million. Under our operating leases as noted in Part II, Item 8, Note 11, "Leases", we have a current obligation of $7.7 million and a long-term obligation of $17.4 million. As noted in Part II, Item 8, Note 15, "Commitments and Contingencies", we have current obligations related to noncancelable purchase commitments of $562.9 million.

[0001375365-22-000103:mdna:144]
Recent Accounting Pronouncements

[0001375365-22-000103:mdna:145]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report.

[0001375365-22-000103:mdna:146]
SMCI | 2022 Form 10-K | 49
