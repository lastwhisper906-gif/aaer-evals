# SMCI notes — 0001375365-22-000103


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001375365-22-000103:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001375365-22-000103:notes:2]
None


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-22-000103:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001375365-22-000103:notes:4]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

[0001375365-22-000103:notes:5]
Basis of Presentation

[0001375365-22-000103:notes:6]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

[0001375365-22-000103:notes:7]
Use of Estimates

[0001375365-22-000103:notes:8]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to revenue recognition, allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the COVID-19 pandemic pressures, global economic recession, inflation and increased interest rates on its critical and significant accounting estimates, including an assessment of the collectability of each customer contract as part of the revenue recognition process, assessment of the valuation of accounts receivable, assessment of provision for excess and obsolete inventory and an impairment of long-lived assets.

[0001375365-22-000103:notes:9]
Fair Value of Financial Instruments

[0001375365-22-000103:notes:10]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-22-000103:notes:11]
•Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001375365-22-000103:notes:12]
•Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and

[0001375365-22-000103:notes:13]
•Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable.

[0001375365-22-000103:notes:14]
Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposit and the investment in an auction rate security are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms.

[0001375365-22-000103:notes:15]
Cash and Cash Equivalents

[0001375365-22-000103:notes:16]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months.

[0001375365-22-000103:notes:17]
Restricted Cash and Cash Equivalents

[0001375365-22-000103:notes:18]
Restricted cash is comprised of amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to the Company’s workers’ compensation program. These restricted cash balances have been excluded from the Company's cash and cash equivalents balance.

[0001375365-22-000103:notes:19]
Inventories

[0001375365-22-000103:notes:20]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based upon the Company's inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-22-000103:notes:21]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-22-000103:notes:22]
Property, Plant and Equipment

[0001375365-22-000103:notes:23]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-22-000103:notes:24]
| Software | 3 to 5 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |

[0001375365-22-000103:notes:25]
Long-Lived Assets

[0001375365-22-000103:notes:26]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge for long-lived assets has been recorded in any of the periods presented.

[0001375365-22-000103:notes:27]
Revenue Recognition

[0001375365-22-000103:notes:28]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-22-000103:notes:29]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customers from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-22-000103:notes:30]
The Company applies judgment in determining the transaction price as the Company may be required to estimate variable consideration when determining the amount of revenue to recognize. As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-22-000103:notes:31]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-22-000103:notes:32]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-22-000103:notes:33]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, the Company allocates the transaction price for each customer contract to each performance obligation based on the relative standalone selling price (SSP) for each performance obligation within each contract. The Company recognizes the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgement. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company applies judgment to estimate the SSP. For substantially all performance obligations, the Company is able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. The Company typically establishes an SSP range for its products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for the Company’s products and services can evolve over time due to changes in its pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for the Company’s products and services, economic and other factors.

[0001375365-22-000103:notes:34]
These estimates and judgements have not fluctuated significantly for the fiscal year ended June 30, 2022, compared to prior fiscal years.

[0001375365-22-000103:notes:35]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-22-000103:notes:36]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.

[0001375365-22-000103:notes:37]
Allowances for Doubtful Accounts

[0001375365-22-000103:notes:38]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability and intent to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer concentrations, customer-credit-worthiness, and current economic trends to evaluate the adequacy of the allowance for doubtful accounts. The Company's recovery of allowance for bad debt was $(0.8) million, $(0.8) million, and $(3.1) million in fiscal years 2022, 2021 and 2020, respectively.

[0001375365-22-000103:notes:39]
Cost of Sales

[0001375365-22-000103:notes:40]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or net realizable value and excess and obsolete inventory.

[0001375365-22-000103:notes:41]
Product Warranties

[0001375365-22-000103:notes:42]
The Company offers product warranties typically ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are recorded to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2022, 2021 and 2020, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-22-000103:notes:43]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Balance, beginning of the year | $ | 12,863 |  |  | $ | 12,379 |  |  | $ | 11,034 |  |
| Provision for warranty | 28,150 |  |  | 29,638 |  |  | 35,962 |  |
| Costs utilized | (29,872) |  |  | (30,575) |  |  | (34,502) |  |
| Change in estimated liability for pre-existing warranties | 996 |  |  | 1,421 |  |  | (115) |  |
| Balance, end of the year | $ | 12,137 |  |  | $ | 12,863 |  |  | $ | 12,379 |  |
| Current portion | 9,073 |  |  | 10,185 |  |  | 9,984 |  |
| Non-current portion | $ | 3,064 |  |  | $ | 2,678 |  |  | $ | 2,395 |  |

[0001375365-22-000103:notes:44]
Research and Development

[0001375365-22-000103:notes:45]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for the Company's research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to the Company's research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $8.2 million, $10.9 million, and $2.1 million for the fiscal years ended June 30, 2022, 2021 and 2020, respectively. During the fiscal year ended June 30, 2020, the Company also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-22-000103:notes:46]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-22-000103:notes:47]
Advertising Costs

[0001375365-22-000103:notes:48]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred. Total advertising and promotional expenses were $0.1 million, $4.1 million and $3.0 million for the fiscal years ended June 30, 2022, 2021 and 2020, respectively, net of credits from marketing development funds.

[0001375365-22-000103:notes:49]
Stock-Based Compensation

[0001375365-22-000103:notes:50]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-22-000103:notes:51]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-22-000103:notes:52]
Leases

[0001375365-22-000103:notes:53]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. The Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-22-000103:notes:54]
Operating Leases

[0001375365-22-000103:notes:55]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-22-000103:notes:56]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

[0001375365-22-000103:notes:57]
Finance Leases

[0001375365-22-000103:notes:58]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-22-000103:notes:59]
Income Taxes

[0001375365-22-000103:notes:60]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-22-000103:notes:61]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

[0001375365-22-000103:notes:62]
Variable Interest Entities

[0001375365-22-000103:notes:63]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-22-000103:notes:64]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect these related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-22-000103:notes:65]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each party contributed $0.2 million for a 50% ownership interest of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2022, 2021 and 2020, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's consolidated statements of operations.

[0001375365-22-000103:notes:66]
Foreign Currency Transactions

[0001375365-22-000103:notes:67]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, with the exception of Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in foreign currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the foreign currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the foreign currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, are reflected in the consolidated statements of operations in other income (expense), net.

[0001375365-22-000103:notes:68]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-22-000103:notes:69]
The Company has an investment in a privately-held company that is accounted for under the equity method (the "Corporate Venture").  The functional currency of the Corporate Venture is the Chinese Yuan. Adjustments for the Company's share of the effects of foreign currency translation from local currency to U.S. dollars are recorded as increases or decreases to the carrying value of the investment and included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-22-000103:notes:70]
Net Income Per Common Share

[0001375365-22-000103:notes:71]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested RSUs and PRSUs. Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-22-000103:notes:72]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs and PRSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.

[0001375365-22-000103:notes:73]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-22-000103:notes:74]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 285,163 |  |  | $ | 111,865 |  |  | $ | 84,308 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 51,478 |  |  | 51,157 |  |  | 50,987 |  |
| Effect of dilutive securities | 2,137 |  |  | 2,350 |  |  | 1,851 |  |
| Weighted-average diluted shares | 53,615 |  |  | 53,507 |  |  | 52,838 |  |
| Basic net income per common share | $ | 5.54 |  |  | $ | 2.19 |  |  | $ | 1.65 |  |
| Diluted net income per common share | $ | 5.32 |  |  | $ | 2.09 |  |  | $ | 1.60 |  |

[0001375365-22-000103:notes:75]
For the fiscal years ended June 30, 2022, 2021 and 2020, the Company had stock options, RSUs and PRSUs outstanding that could potentially dilute basic earnings per share in the future but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 475,529, 670,179, and 2,208,000 for the fiscal years ended June 30, 2022, 2021 and 2020, respectively.

[0001375365-22-000103:notes:76]
Concentration of Supplier Risk

[0001375365-22-000103:notes:77]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 18.1% and 11.4% of total purchases for the fiscal year ended June 30, 2022. Two suppliers accounted for 20.3% and 11.8% of total purchases for the fiscal years ended June 30, 2021. One supplier accounted for 26.8% of total purchases for the fiscal years ended June 30, 2020. Purchases from Ablecom and Compuware, related parties of the Company as noted in Part II, Item 8, Note 12, "Related Party Transactions," accounted for a combined 8.3%, 7.8%, and 10.1% of total cost of sales for the fiscal years ended June 30, 2022, 2021 and 2020, respectively.

[0001375365-22-000103:notes:78]
Concentration of Credit Risk

[0001375365-22-000103:notes:79]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales in any of fiscal years 2022, 2021 and 2020. One customer accounted for 21.7% and 13.5% of accounts receivable, net as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:80]
Treasury Stock

[0001375365-22-000103:notes:81]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-22-000103:notes:82]
Accounting Pronouncements Recently Adopted

[0001375365-22-000103:notes:83]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021. The adoption of the guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

[0001375365-22-000103:notes:84]
Accounting Pronouncements Not Yet Adopted

[0001375365-22-000103:notes:85]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In April 2022, FASB issued a proposed accounting standard update for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The proposed amendment defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of adoption of the guidance on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-22-000103:notes:86]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.
Disaggregation of RevenueThe Company disaggregates revenue by type of product and geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue and are aggregated within the respective categories.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001375365-22-000103:notes:87]
Research and DevelopmentResearch and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for the Company's research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to the Company's research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-22-000103:notes:88]
Fair Value Disclosure
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-22-000103:notes:89]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of June 30, 2022 and June 30, 2021. See Part II, Item 8, Note 1, "Organization and Summary of Significant Accounting Policies," for a discussion of the Company’s policies regarding the fair value hierarchy. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of June 30, 2022.

[0001375365-22-000103:notes:90]
Financial Assets and Liabilities Measured on a Recurring Basis

[0001375365-22-000103:notes:91]
The following table sets forth the Company’s financial instruments as of June 30, 2022 and 2021, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-22-000103:notes:92]
| June 30, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 20,220 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,220 |  |
| Certificates of deposit(2) | — |  |  | 832 |  |  | — |  |  | 832 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,220 |  |  | $ | 832 |  |  | $ | 1,590 |  |  | $ | 22,642 |  |
| June 30, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | 151 |  |
| Certificates of deposit(2) | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Auction rate security | — |  |  | — |  |  | 1,556 |  |  | 1,556 |  |
| Total assets measured at fair value | $ | 151 |  |  | $ | 863 |  |  | $ | 1,556 |  |  | $ | 2,570 |  |

[0001375365-22-000103:notes:93]
(1) $20.0 million and $0.0 million in money market funds are included in cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:94]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.3 million and $0.4 million in certificates of deposit are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:95]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the fiscal year ended June 30, 2022, the credit losses related to the Company’s investments were not significant.

[0001375365-22-000103:notes:96]
There was an immaterial movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for fiscal years 2022 and 2021.

[0001375365-22-000103:notes:97]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in fiscal years 2022 and 2021.

[0001375365-22-000103:notes:98]
The following is a summary of the Company’s investment in an auction rate security as of June 30, 2022 and 2021 (in thousands):

[0001375365-22-000103:notes:99]
|  | June 30, 2022 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (160) |  |  | $ | 1,590 |  |

[0001375365-22-000103:notes:100]
|  | June 30, 2021 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (194) |  |  | $ | 1,556 |  |

[0001375365-22-000103:notes:101]
For the fiscal year ended June 30, 2022, the Company recognized $0.03 million of unrealized gain for the auction rate security in other comprehensive income based on the current valuation. For the fiscal year ended June 30, 2021, the Company's loss recognized in other comprehensive income for the auction rate security was immaterial. No gain or loss was recognized in other comprehensive income for the auction rate security for the fiscal year ended June 30, 2020.

[0001375365-22-000103:notes:102]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2022 and 2021, total debt of $596.8 million and $98.2 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-22-000103:notes:103]
Other Financial Assets - Investments into Non-Marketable Equity Securities
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $1.2 million as of each of June 30, 2022, and 2021. The Company accounts for these investments at cost minus impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the years ended June 30, 2022 and 2021, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during fiscal year 2022, 2021 and 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-22-000103:notes:104]
Revenue
    Disaggregation of Revenue

[0001375365-22-000103:notes:105]
The Company disaggregates revenue by type of product and geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue and are aggregated within the respective categories.

[0001375365-22-000103:notes:106]
The following is a summary of net sales by product type (in thousands):

[0001375365-22-000103:notes:107]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Server and storage systems | $ | 4,463,833 |  |  | $ | 2,790,305 |  |  | $ | 2,620,754 |  |
| Subsystems and accessories | 732,266 |  |  | 767,117 |  |  | 718,527 |  |
| Total | $ | 5,196,099 |  |  | $ | 3,557,422 |  |  | $ | 3,339,281 |  |

[0001375365-22-000103:notes:108]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-22-000103:notes:109]
International net sales are based on the country and geographical region to which the products were shipped. The following is a summary of net sales by geographic region (in thousands):

[0001375365-22-000103:notes:110]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| United States | $ | 3,035,523 |  |  | $ | 2,107,910 |  |  | $ | 1,957,329 |  |
| Asia | 1,139,898 |  |  | 699,653 |  |  | 650,652 |  |
| Europe | 825,200 |  |  | 614,826 |  |  | 598,558 |  |
| Other | 195,478 |  |  | 135,033 |  |  | 132,742 |  |
| Total | $ | 5,196,099 |  |  | $ | 3,557,422 |  |  | $ | 3,339,281 |  |

[0001375365-22-000103:notes:111]
Starting July 1, 2020, the Company does not separately disclose revenue by products sold to indirect sales channel partners or direct customers and original equipment manufacturers because management does not make business operational decisions based on this set of disaggregation, so the disclosure is no longer material to investors.

[0001375365-22-000103:notes:112]
Contract Balances

[0001375365-22-000103:notes:113]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s unconditional right to consideration for performance obligations either partially or fully completed.

[0001375365-22-000103:notes:114]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s consolidated financial statements.

[0001375365-22-000103:notes:115]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during fiscal year ended June 30, 2022, which was included in the opening deferred revenue balance as of June 30, 2021, of $202.3 million, was $100.2 million.

[0001375365-22-000103:notes:116]
Deferred revenue increased $31.5 million during the fiscal year ended June 30, 2022, as compared to the fiscal year ended June 30, 2021 mainly because the deferral on invoiced amounts for service contracts during the period exceeded the recognition of revenue from contracts entered into in prior periods.

[0001375365-22-000103:notes:117]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-22-000103:notes:118]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of June 30, 2022, was approximately $233.8 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-22-000103:notes:119]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-22-000103:notes:120]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

[0001375365-22-000103:notes:121]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-22-000103:notes:122]
The following is a summary of net sales by geographic region (in thousands):


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-22-000103:notes:123]
Accounts Receivable Allowances
    The Company has established an allowance for doubtful accounts. The allowance for doubtful accounts is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2022, 2021 and 2020 consisted of the following (in thousands):

[0001375365-22-000103:notes:124]
|  | BeginningBalance |  | Charged toCost andExpenses (Recovered), net |  | Write-offs |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2022 | $2,591 |  | $(840) |  | $2 |  | $1,753 |
| Year ended June 30, 2021 | $4,586 |  | $(820) |  | $(1,175) |  | $2,591 |
| Year ended June 30, 2020 | $8,906 |  | $(3,081) |  | $(1,239) |  | $4,586 |


## us-gaap:InventoryDisclosureTextBlock

[0001375365-22-000103:notes:125]
Inventories 
Inventories as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:126]
|  | June 30, |
|  | 2022 |  | 2021 |
| Finished goods | $ | 1,025,555 |  |  | $ | 761,694 |  |
| Work in process | 209,576 |  |  | 80,472 |  |
| Purchased parts and raw materials | 310,475 |  |  | 198,798 |  |
| Total inventories | $ | 1,545,606 |  |  | $ | 1,040,964 |  |

[0001375365-22-000103:notes:127]
During fiscal years 2022, 2021 and 2020, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $15.1 million, $6.8 million and $18.4 million, respectively. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-22-000103:notes:128]
Property, Plant, and Equipment
    Property, plant and equipment as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:129]
|  | June 30, |
|  | 2022 |  | 2021 |
| Buildings | $ | 143,509 |  |  | $ | 86,930 |  |
| Land | 84,616 |  |  | 76,421 |  |
| Machinery and equipment | 113,665 |  |  | 97,671 |  |
| Buildings construction in progress(1) | 303 |  |  | 87,438 |  |
| Building and leasehold improvements | 45,169 |  |  | 26,640 |  |
| Software | 23,186 |  |  | 22,592 |  |
| Furniture and fixtures | 43,282 |  |  | 22,843 |  |
|  | 453,730 |  |  | 420,535 |  |
| Accumulated depreciation and amortization | (167,758) |  |  | (145,822) |  |
| Property, plant and equipment, net | $ | 285,972 |  |  | $ | 274,713 |  |

[0001375365-22-000103:notes:130]
(1)Construction in progress balance as of June 30, 2021, primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California and the new building in Taiwan.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001375365-22-000103:notes:131]
Prepaid Expenses and Other Assets
Prepaid expenses and other current assets as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:132]
|  | June 30, |
|  | 2022 |  | 2021 |
| Other receivables(1) | $ | 138,054 |  |  | $ | 99,921 |  |
| Prepaid expenses | 5,632 |  |  | 6,719 |  |
| Deferred service costs | 5,562 |  |  | 4,900 |  |
| Prepaid income tax | 2,352 |  |  | 12,288 |  |
| Restricted cash | 251 |  |  | 251 |  |
| Others | 6,948 |  |  | 6,116 |  |
| Total prepaid expenses and other current assets | $ | 158,799 |  |  | $ | 130,195 |  |

[0001375365-22-000103:notes:133]
(1)Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $98.9 million and $76.2 million as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:134]
Other assets as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:135]
|  | June 30, |
|  | 2022 |  | 2021 |
| Operating lease right-of-use asset | $ | 23,679 |  |  | $ | 20,047 |  |
| Deferred service costs, non-current | 6,316 |  |  | 5,421 |  |
| Prepaid expense, non-current | 2,011 |  |  | 1,973 |  |
| Investment in auction rate security | 1,590 |  |  | 1,556 |  |
| Deposits | 1,069 |  |  | 1,669 |  |
| Restricted cash, non-current | 911 |  |  | 932 |  |
| Others | 1,956 |  |  | 528 |  |
| Total other assets | $ | 37,532 |  |  | $ | 32,126 |  |

[0001375365-22-000103:notes:136]
Cash, cash equivalents and restricted cash as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:137]
|  | June 30, |
|  | 2022 |  | 2021 |
| Cash and cash equivalents | $ | 267,397 |  |  | $ | 232,266 |  |
| Restricted cash included in prepaid expenses and other current assets | 251 |  |  | 251 |  |
| Restricted cash included in other assets | 911 |  |  | 932 |  |
| Total cash, cash equivalents and restricted cash | $ | 268,559 |  |  | $ | 233,449 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001375365-22-000103:notes:138]
Accrued Liabilities
Accrued liabilities as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:139]
|  | June 30, |
|  | 2022 |  | 2021 |
| Accrued payroll and related expenses | $ | 57,736 |  |  | $ | 45,770 |  |
| Contract manufacturers liabilities | 41,125 |  |  | 45,319 |  |
| Customer deposits | 30,421 |  |  | 32,419 |  |
| Accrued legal liabilities (Note 15) | 18,250 |  |  | — |  |
| Accrued warranty costs | 9,073 |  |  | 10,185 |  |
| Accrued cooperative marketing expenses | 8,757 |  |  | 5,652 |  |
| Operating lease liability | 7,139 |  |  | 6,322 |  |
| Accrued professional fees | 4,281 |  |  | 2,737 |  |
| Others | 35,637 |  |  | 30,446 |  |
| Total accrued liabilities | $ | 212,419 |  |  | $ | 178,850 |  |

[0001375365-22-000103:notes:140]
Performance Awards Liability

[0001375365-22-000103:notes:141]
In March 2020, the Board of Directors (the “Board”) approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments will be earned when specified market and performance conditions are achieved.

[0001375365-22-000103:notes:142]
The Chief Executive Officer’s total cash bonus opportunity was $8.1 million, divided into two equal tranches. Each tranche would be earned if the average closing price for the Company’s common stock reached specified targets. The Board retained the flexibility to reduce the amount payable under the first tranche (but not the second tranche) based on performance goals. Both price targets were reached during the fiscal year ended June 30, 2021, and the second tranche totaled $4.0 million was paid in full. As of June 30, 2021, the Company also expected it would likely pay the first tranche in full, and therefore recorded an expense of $3.6 million since March 2020 relating to the first tranche.
In September 2021, after the Company had closed its books for the year ended June 30, 2021, the Board decided to exercise its discretion to reduce the amount to be paid to the Chief Executive for the first tranche to $2.0 million, which was paid in the quarter ended December 31, 2021. As a result of the Board’s decision to reduce the amount to be paid under the first tranche, the Company adjusted the $3.6 million expense previously recorded for the first tranche to the new amount of $2.0 million, which resulted in the Company recognizing a $1.6 million benefit from this adjustment during the quarter ended September 30, 2021. For the fiscal years ended June 30, 2022 and June 30, 2021, $1.6 million of benefit and $5.8 million of expense was recognized, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001375365-22-000103:notes:143]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:144]
|  | June 30, |
|  | 2022 |  | 2021 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 268,245 |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 9,500 |  | — |  |
| Cathay Bank Line of Credit | 30,000 |  | — |  |
| 2021 CTBC Credit Lines | 84,800 |  | 18,000 |  |
| HSBC Bank Credit Facility | 30,000 |  | — |  |
| 2021 E.SUN Bank Credit Facility | 7,800 |  | 20,400 |
| Mega Bank Credit Facility | 3,500 |  | — |  |
| Total line of credit | 433,845 |  |  | 38,400 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 33,643 |  | — |  |
| CTBC Bank term loan, due August 31, 2022 | — |  |  | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 40,372 |  | 34,700 |  |
| 2021 CTBC Credit Lines, due December 27, 2027 | 5,468 |  | — |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 43,064 |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 40,372 |  | — |  |
| Total term loans | 162,919 |  |  | 59,790 |  |
| Total debt | 596,764 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 449,146 |  |  | 63,490 |  |
| Debt, non-current | $ | 147,618 |  |  | $ | 34,700 |  |

[0001375365-22-000103:notes:145]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-22-000103:notes:146]
Bank of America

[0001375365-22-000103:notes:147]
2018 Bank of America Credit Facility

[0001375365-22-000103:notes:148]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and change provisions relating to payments and LIBOR replacement mechanics to SOFR. The obligations bear a base interest rate plus 0.5% to 1.5% based on the SOFR availability. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Prior to that, on June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, and increase the maximum amount that the Company can request the facility be increased from $100 million to $150 million. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-22-000103:notes:149]
As of June 30, 2022, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $268.2 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rate under the 2018 Bank of America Credit Facility as of June 30, 2022 and 2021 was 2.53% and 1.50%, respectively. The balance of debt issuance costs outstanding as of June 30, 2022 and June 30, 2021 was $1.0 million and $0.5 million, respectively. The Company is in compliance with all covenants under the 2018 Bank of America Credit Facility, and as of June 30, 2022, the Company's available borrowing capacity was $81.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-22-000103:notes:150]
2022 Bank of America Credit Facility

[0001375365-22-000103:notes:151]
On March 23, 2022, the Company through its Taiwan subsidiary entered into an Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch (the “2022 Bank of America Credit Facility”), for an amount not to exceed in aggregate $20.0 million. The interest rate will be quoted by Bank of America - Taipei Branch for each drawdown. As of June 30, 2022, the total outstanding borrowings were $9.5 million with an interest rate of 1.85% per annum under the 2022 Bank of America Credit Facility.

[0001375365-22-000103:notes:152]
CTBC Bank

[0001375365-22-000103:notes:153]
2021 CTBC Credit Lines

[0001375365-22-000103:notes:154]
The Company through its Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

[0001375365-22-000103:notes:155]
On July 20, 2021 (the “Effective Date”), the Company through its Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

[0001375365-22-000103:notes:156]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-22-000103:notes:157]
As of June 30, 2022 and 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $40.4 million and $34.7 million, respectively. The interest rates for these loans were 0.825% per annum as of June 30, 2022 and 0.45% as of June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $5.5 million on June 30, 2022. The interest rate for this loan was 1.025% per annum as of June 30, 2022. As of June 30, 2021 there were no outstanding borrowings under the 2021 CTBC Machine Loan.

[0001375365-22-000103:notes:158]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $0.0 million and $25.1 million at June 30, 2022 and 2021, respectively. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. The interest rate for the 2021 CTBC Credit Facility term loan was 0.75% per annum as of June 30, 2021. As of June 30, 2022 and 2021, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were $84.8 million and $18.0 million, respectively. The interest rates for these loans ranged from 1.80% to 2.52% per annum as of June 30, 2022 and were 0.98% per annum as of June 30, 2021. As of June 30, 2022, the amount available for future borrowing under the 2021 CTBC Credit Facility was $20.2 million. As of June 30, 2022, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.3 million. The Company was in compliance with all financial covenants under 2021 CTBC Credit Lines as of June 30, 2022.

[0001375365-22-000103:notes:159]
E.SUN Bank Credit Facility

[0001375365-22-000103:notes:160]
2021 E.SUN Bank Credit Facility

[0001375365-22-000103:notes:161]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US $30.0 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility expired on September 18, 2021.

[0001375365-22-000103:notes:162]
On September 13, 2021 (the “Old E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permitted borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility were substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility were based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility had customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. There were various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements to be reviewed on a yearly basis at fiscal year end.

[0001375365-22-000103:notes:163]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, were to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the Old E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of June 30, 2022, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $43.1 million and the interest rates for the Term Loan was 1.37% per annum. As of June 30, 2022 and June 30, 2021, the amounts outstanding under the Import Loan were $7.8 million and $20.4 million, respectively. The interest rate for the fiscal year ended June 30, 2022 was 1.81% per annum. The interest rate for the fiscal year ended June 30, 2021 ranged from 1.00% to 1.29% per annum. As of June 30, 2022 the amount available for future borrowing under the Import Loan was $22.2 million. The Company was in compliance with all financial covenants under 2021 E.SUN Bank Credit Facility as of June 30, 2022.

[0001375365-22-000103:notes:164]
2022 E.SUN Bank Credit Facility

[0001375365-22-000103:notes:165]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

[0001375365-22-000103:notes:166]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of 5 years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured.

[0001375365-22-000103:notes:167]
Mega Bank

[0001375365-22-000103:notes:168]
Mega Bank Credit Facilities

[0001375365-22-000103:notes:169]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. The first drawdown date was on October 4, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of June 30, 2022, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $40.4 million and the interest rates ranged from 1.02% to 1.22% per annum.

[0001375365-22-000103:notes:170]
Credit Agreement with Mega Bank

[0001375365-22-000103:notes:171]
On April 25, 2022, the Company through its Taiwan subsidiary, entered into a $20.0 million (or foreign currency equivalent) (the “Credit Limit”) Omnibus Credit Authorization Agreement (the “Omnibus Credit Authorization Agreement”) with Mega Bank. The Omnibus Credit Authorization Agreement permits individual credit authorizations subject to specified drawdown conditions up to the Credit Limit (on a revolving basis) to be used as loans for the purchase of materials or supplies.

[0001375365-22-000103:notes:172]
Pursuant to the Omnibus Credit Authorization Agreement, the Taiwan subsidiary also entered into both a Credit Authorization Agreement (the “Credit Authorization Agreement”) and Credit Authorization Approval Notice (the “Credit Authorization Approval Notice”) with Mega Bank and an associated branch of Mega Bank, respectively. Pursuant to such Agreement and Notice, Mega Bank permits the Taiwan subsidiary to make drawdowns up to the Credit Limit for short-term loans for material purchases with a tenor not to exceed 120 days on a revolving basis. Drawdowns may be made through March 2023. The interest rate for each individual credit authorization is adjusted according to the Mega Bank’s USD basic loan interest rate at the time of signing the agreement which was 0.90% per annum. Interest on such drawdowns is based upon TAIFX OFFER for six months plus 0.23% then divided by 0.946, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to the bank’s right of set off. The interest rate shall be adjusted once every month but shall not be lower than the USD basic loan interest rate plus 0.1%. If the loan involves the acceptance of a bill of exchange, the Company would be required to pay a handling fee at the annual rate of 0.75% calculated based on the number of actual acceptance days. The fee is paid in full upon acceptance and a minimum handling fee of NTD 400 is charged for each transaction. Amounts borrowed are otherwise unsecured, and the Credit Authorization Agreement has customary default provisions permitting Mega Bank to reduce the extension of credit, shorten the term for loan repayment or declare all of the amounts immediately due and payable. The Company is not a guarantor under the Credit Authorization Agreement or Credit Authorization Approval Notice.

[0001375365-22-000103:notes:173]
As of June 30, 2022 the amount outstanding under the Credit Authorization Agreement was $3.5 million. The interest rate for the fiscal year ended June 30, 2022, was 1.85% per annum. As of June 30, 2022, the amount available for future borrowing under the Credit Limit was $16.5 million.

[0001375365-22-000103:notes:174]
Chang Hwa Bank

[0001375365-22-000103:notes:175]
Chang Hwa Bank Credit Facility

[0001375365-22-000103:notes:176]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”). The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed.

[0001375365-22-000103:notes:177]
On May 13, 2022, Chang Hwa Bank notified that they increased the borrowing capacity limit by $20.0 million.

[0001375365-22-000103:notes:178]
As of June 30, 2022, the total outstanding borrowings under the Chang Hwa Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $33.6 million and the interest rate was 1.175% per annum.

[0001375365-22-000103:notes:179]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants. The Company is not a guarantor under Chang Hwa Bank Credit Facility.

[0001375365-22-000103:notes:180]
HSBC Bank

[0001375365-22-000103:notes:181]
HSBC Bank Credit Facility

[0001375365-22-000103:notes:182]
On January 7, 2022 (the “HSBC Bank Effective Date”), the Company, through its Taiwan subsidiary, entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with a Taiwan affiliate of HSBC Bank (“HSBC Bank”). The Loan Agreement provides for borrowings in the form of loans, export/import financings, overdrafts, commercial paper guaranties, and other types of drawdown instruments. The Loan Agreement has customary default provisions permitting HSBC Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Company’s Taiwan subsidiary fails to make payment of sums under another agreement which permits acceleration of maturity of such indebtedness. The Company is not a guarantor of the Loan Agreement.

[0001375365-22-000103:notes:183]
Terms for specific drawdown instruments issued under the Loan Agreement, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, may be set forth in facility letters (each, a “Facility Letter”) negotiated with HSBC Bank. Under a Facility Letter entered into on the HSBC Bank Effective Date, the Company’s Taiwan subsidiary and HSBC Bank agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date.

[0001375365-22-000103:notes:184]
As of June 30, 2022, the outstanding borrowings under the 2022 HSBC Bank Credit Facility revolving line of credit were $30.0 million. The interest rates for these loans ranged from 1.95% to 2.20% per annum as of June 30, 2022. As of June 30, 2022, there was no amount available for future borrowing under the 2022 HSBC Bank Credit Facility.

[0001375365-22-000103:notes:185]
Cathay Bank

[0001375365-22-000103:notes:186]
Cathay Bank Line of Credit

[0001375365-22-000103:notes:187]
On May 19, 2022 (the “Cathay Bank Effective Date”), the Company entered into a Loan Agreement (the “Cathay Bank Loan Agreement”) with Cathay Bank (“Cathay Bank”) pursuant to which Cathay Bank has agreed to provide a revolving line of credit of up to $132 million (the “Commitment”) for the five-year period following the Cathay Bank Effective Date. On the fifth anniversary of the Cathay Bank Effective Date, the total outstanding borrowings under the Cathay Bank Loan Agreement will automatically be converted into a five-year term loan. The interest rate under the Cathay Bank Loan Agreement is based upon either the SOFR index or prime rate index, at the Company’s quarterly election, plus a tiered spread that is based upon the average amounts deposited by the Company at Cathay Bank as a percentage of the Commitment. The spread is either 1.65% or 2.0% if the index is SOFR index, or 1.25% or 1.00% if the spread is the prime rate index with the higher spread applying in each case if an amount less than 25% of the Commitment is on deposit with Cathay Bank. Interest is payable monthly during the five-year period following the Cathay Bank Effective Date. After conversion to a term loan on the fifth anniversary of the Cathay Bank Effective Rate, interest is payable monthly based on a 20-year amortization schedule with the unpaid balance due at maturity. The Cathay Bank Loan Agreement has customary default provisions and is cross defaulted with other indebtedness to the extent such default causes a material adverse effect with respect to the Commitment. The Company is required to comply with certain covenants, including maintaining a fixed charge coverage ratio of at least 1.15:1.00. The Company is required to pay Cathay Bank an unused facility fee in the amount of 0.15% per annum of the undrawn Commitment payable quarterly in arrears.

[0001375365-22-000103:notes:188]
Borrowings under the Loan Agreement are secured against certain of the Company’s properties located in San Jose, California (the “Collateral”). The Company has agreed to indemnify the Bank with respect to certain environmental matters with respect to the Collateral. The Collateral is subject to re-appraisal every two years at the election of the Bank, and the Bank reserves the right to reduce the Commitment in accordance with such appraised values. As of June 30, 2022, the outstanding borrowings under the Cathay Bank line of credit were $30.0 million.

[0001375365-22-000103:notes:189]
Principal payments on short-term and long-term debt obligations are due as follows (in thousands):

[0001375365-22-000103:notes:190]
| Fiscal Year: | Principal Payments |
| 2023 | $ | 449,146 |  |
| 2024 | 36,404 |  |
| 2025 | 39,769 |  |
| 2026 | 39,769 |  |
| 2027 | 14,855 |  |
| 2028 and thereafter | 16,821 |  |
| Total short-term and long-term debt | $ | 596,764 |  |


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001375365-22-000103:notes:191]
Other Long-term Liabilities
Other long-term liabilities as of June 30, 2022 and 2021 consisted of the following (in thousands):

[0001375365-22-000103:notes:192]
|  | June 30, |
|  | 2022 |  | 2021 |
| Accrued unrecognized tax benefits including related interest and penalties, non-current | $ | 18,866 |  |  | $ | 17,841 |  |
| Operating lease liability, non-current | 16,661 |  |  | 14,539 |  |
| Accrued warranty costs, non-current | 3,064 |  |  | 2,678 |  |
| Other | 549 |  |  | 6,074 |  |
| Total other long-term liabilities | $ | 39,140 |  |  | $ | 41,132 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-22-000103:notes:193]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized, and supplemental cash flow information related to operating leases for the years ended June 30, 2022 and 2021 were as follows (in thousands):

[0001375365-22-000103:notes:194]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |
| Operating lease expense (including expense for lease agreements with related parties of $711 and $1,319 for the years ended June 30, 2022 and 2021, respectively) | $ | 8,265 |  |  | $ | 7,827 |  |
| Cash payments for operating leases (including payments to related parties of $766 and $1,351 for the years ended June 30, 2022 and 2021, respectively) | 8,007 |  |  | 7,966 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | 11,151 |  |  | 3,538 |  |

[0001375365-22-000103:notes:195]
During the years ended June 30, 2022 and 2021, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the years ended June 30, 2022, 2021 and 2020 were $1.1 million, $1.8 million and $1.3 million, respectively.

[0001375365-22-000103:notes:196]
As of June 30, 2022, the weighted average remaining lease term for operating leases was 3.8 years and the weighted average discount rate was 3.0%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of June 30, 2022, were as follows (in thousands):

[0001375365-22-000103:notes:197]
| Fiscal Year: |  | Maturities of operating leases |
| 2023 |  | $ | 7,721 |  |
| 2024 |  | 6,525 |  |
| 2025 |  | 6,136 |  |
| 2026 |  | 2,602 |  |
| 2027 |  | 1,550 |
| 2028 and beyond |  | 533 |  |
| Total future lease payments |  | $ | 25,067 |  |
| Less: Imputed interest |  | (1,267) |  |
| Present value of operating lease liabilities |  | $ | 23,800 |  |

[0001375365-22-000103:notes:198]
As of June 30, 2022, commitments under short-term lease arrangements and operating and financing leases that have not yet commenced were immaterial.

[0001375365-22-000103:notes:199]
The Company has entered into lease agreements with related parties. See Part II, Item 8, Note 12, "Related Party Transactions" for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-22-000103:notes:200]
Related Party Transactions
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of June 30, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang or Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware's capital stock.

[0001375365-22-000103:notes:201]
Dealings with Ablecom

[0001375365-22-000103:notes:202]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-22-000103:notes:203]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.2%, 91.8% and 95.5% of the chassis included in the products sold by the Company during fiscal years 2022, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-22-000103:notes:204]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-22-000103:notes:205]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2021 were $44.9 million and $40.2 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-22-000103:notes:206]
Dealings with Compuware

[0001375365-22-000103:notes:207]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-22-000103:notes:208]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-22-000103:notes:209]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-22-000103:notes:210]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-22-000103:notes:211]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2021 were $123.3 million and $71.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-22-000103:notes:212]
Dealings with Investment in a Corporate Venture

[0001375365-22-000103:notes:213]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately held company located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-22-000103:notes:214]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of June 30, 2022 and 2021, the Company had unamortized deferred gain balance of $0.0 million and $1.0 million, respectively, in accrued liabilities and none in other long-term liabilities in the Company’s consolidated balance sheets.

[0001375365-22-000103:notes:215]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of June 30, 2022. No impairment charge was recorded for the fiscal years ended June 30, 2022 and 2021.

[0001375365-22-000103:notes:216]
The Company sold products worth $121.0 million, $51.2 million, $61.9 million to the Corporate Venture in the fiscal years 2022, 2021 and 2020, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of June 30, 2022 and June 30, 2021 have been eliminated and have reduced the carrying value of the Company's investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $8.0 million and $8.5 million due from the Corporate Venture in accounts receivable, net as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:217]
Dealings with Monolithic Power Systems, Inc.

[0001375365-22-000103:notes:218]
The Company procures certain semiconductor products from Monolithic Power Systems, Inc. (“MPS”), a fabless manufacturer of high-performance analog and mixed-signal semiconductors, through its contract manufacturers for use in its products. A member of the Board of Directors, who served during fiscal year 2022 until May 18, 2022, also serves as an officer of MPS.

[0001375365-22-000103:notes:219]
The Company had the following balances related to transactions with its related parties as of the fiscal years ended June 30, 2022, 2021 and 2020 (in thousands):

[0001375365-22-000103:notes:220]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | MPS |  | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |
|  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | (27) |  |  | $ | 404 |  | $ | 198 |  | $ | 938 |  |  | $ | 7,992 |  | $ | 8,478 |  | $ | 7,801 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 8,398 |  | $ | 8,678 |  | $ | 8,712 |  |
| Other receivable (1) | $ | 4,816 |  | $ | 5,575 |  | $ | 6,406 |  |  | $ | 19,596 |  | $ | 18,173 |  | $ | 13,385 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | 89 |  | $ | — |  |  | $ | 24,412 |  | $ | 23,837 |  | $ | 19,791 |  |
| Accounts payable | $ | 42,463 |  | $ | 38,152 |  | $ | 36,955 |  |  | $ | 44,892 |  | $ | 31,944 |  | $ | 35,413 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 87,355 |  | $ | 70,096 |  | $ | 72,368 |  |
| Accrued liabilities (2) | $ | 3,531 |  | $ | 3,042 |  | $ | 3,101 |  |  | $ | 15,145 |  | $ | 14,486 |  | $ | 11,105 |  |  | $ | — |  | $ | 1,000 |  | $ | 2,000 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 18,676 |  | $ | 18,528 |  | $ | 16,206 |  |

[0001375365-22-000103:notes:221]
(1)Other receivables include receivables from vendors included in prepaid and other current assets.

[0001375365-22-000103:notes:222]
(2)Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-22-000103:notes:223]
The Company's results from transactions with its related parties for each of the fiscal years ended June 30, 2022, 2021 and 2020, are as follows (in thousands):

[0001375365-22-000103:notes:224]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | MPS |  | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |
|  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |
| Net sales | $ | 15 |  | $ | (23) |  | $ | (7) |  |  | $ | 26,085 |  | $ | 27,865 |  | $ | 23,867 |  |  | $ | 120,991 |  | $ | 51,176 |  | $ | 61,899 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 147,091 |  | $ | 79,018 |  | $ | 85,759 |  |
| Purchases - inventory | $ | 192,441 |  | $ | 122,243 |  | $ | 152,464 |  |  | $ | 170,300 |  | $ | 113,400 |  | $ | 130,592 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 8,335 |  | $ | 3,915 |  | $ | 5,215 |  |  | $ | 371,076 |  | $ | 239,558 |  | $ | 288,271 |  |
| Purchases - other miscellaneous items | $ | 8,265 |  | $ | 8,609 |  | $ | 7,620 |  |  | $ | 1,455 |  | $ | 1,813 |  | $ | 1,171 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 9,720 |  | $ | 10,422 |  | $ | 8,791 |  |

[0001375365-22-000103:notes:225]
The Company’s cash flow impact from transactions with its related parties for the fiscal years ended June 30, 2022, 2021 and 2020, are as follows (in thousands):

[0001375365-22-000103:notes:226]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | MPS |  | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |
|  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |  | 2022 | 2021 | 2020 |
| Changes in accounts receivable | $ | — |  | $ | (29) |  | $ | 42 |  |  | $ | (206) |  | $ | 740 |  | $ | (623) |  |  | $ | 486 |  | $ | (677) |  | $ | 5,308 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 280 |  | $ | 34 |  | $ | 4,727 |  |
| Changes in other receivable | $ | 759 |  | $ | 832 |  | $ | 816 |  |  | $ | (1,423) |  | $ | (4,788) |  | $ | 695 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 89 |  | $ | (13) |  | $ | — |  |  | $ | (575) |  | $ | (3,969) |  | $ | 1,511 |  |
| Changes in accounts payable | $ | 4,311 |  | $ | 1,198 |  | $ | 5,709 |  |  | $ | 12,948 |  | $ | (3,470) |  | $ | 6,850 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 17,259 |  | $ | (2,272) |  | $ | 12,559 |  |
| Changes in accrued liabilities | $ | 489 |  | $ | (59) |  | $ | 419 |  |  | $ | 659 |  | $ | 3,381 |  | $ | 5,251 |  |  | $ | (1,000) |  | $ | (1,000) |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 148 |  | $ | 2,322 |  | $ | 5,670 |  |
| Changes in other long-term liabilities | $ | — |  | $ | (513) |  | $ | 513 |  |  | $ | 499 |  | $ | (186) |  | $ | 186 |  |  | $ | — |  | $ | (1,000) |  | $ | (2,000) |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 499 |  | $ | (1,699) |  | $ | (1,301) |  |
| Purchases of property, plant and equipment | $ | 4,678 |  | $ | 7,110 |  | $ | 4,384 |  |  | $ | 140 |  | $ | 237 |  | $ | 2 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 4,818 |  | $ | 7,347 |  | $ | 4,386 |  |
| Unpaid property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 2,158 |  |  | $ | 106 |  | $ | 62 |  | $ | 65 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 689 |  | $ | 400 |  | $ | 2,223 |  |

[0001375365-22-000103:notes:227]
Tripartite Agreement

[0001375365-22-000103:notes:228]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. 
Pursuant to the Agreement, the Subsidiary will participate in purchasing 33.33% of the 137,225.97 square meters (approximately 34 acres) of land Ablecom has agreed to acquire from third-party landowners in proximity to the Company’s campus in Bade, Taiwan. Compuware will acquire 17.21% of such land and Ablecom will retain the remaining 49.46% of the land. Under the Agreement, fees and costs related to such land purchase would be borne by the parties according to their proportionate share of the land purchased. The Company intends to fund its proportionate share of the land purchased under the Agreement which is estimated to be approximately NTD 789.0 million (or approximately US $28.3 million) from either available cash and/or borrowings under loan agreements to which the Subsidiary is a party in Taiwan. Amounts payable related to the purchase of the land are due in three installments based upon the achievement of specified milestones. The transaction is subject to various customary conditions precedent, including the receipt of government approvals, the discharge of mortgages and leases on the land, and the completion of due diligence. As of June 30, 2022, due diligence and discussions with government officials are continuing, and no installment payments have been made with respect to the transaction. If the transaction does not close within 12 months, Ablecom may offer the land to other parties.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-22-000103:notes:229]
Stock-based Compensation and Stockholders’ Equity
Equity Incentive Plan

[0001375365-22-000103:notes:230]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "Original 2020 Plan"). The maximum number of shares available under the Original 2020 Plan was 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan (as amended and restated, the “2020 Plan”) which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-22-000103:notes:231]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-22-000103:notes:232]
As of June 30, 2022, the Company had 3,604,025 authorized shares available for future issuance under the 2020 Plan.

[0001375365-22-000103:notes:233]
Common Stock Repurchase and Retirement

[0001375365-22-000103:notes:234]
On January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program was effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased (the "Prior Repurchase Program"). 1,391,171 shares of common stock were repurchased and retired for an aggregate $50.0 million as of June 30, 2021. The Company had $150.0 million of remaining availability under the Prior Repurchase Program as of June 30, 2022. There were no shares repurchased under the Prior Repurchase Program during fiscal year 2022.

[0001375365-22-000103:notes:235]
During the fiscal year ended June 30, 2021, the Company repurchased and retired 4,209,211 shares of common stock for an aggregated $130.0 million. Additionally, the Company retired 1,333,125 shares of common stock repurchased in prior years.

[0001375365-22-000103:notes:236]
On August 3, 2022, after the expiration of the Prior Repurchase Program, a duly authorized subcommittee of the Company's Board approved a new share repurchase program to repurchase shares of common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first.

[0001375365-22-000103:notes:237]
Determining Fair Value

[0001375365-22-000103:notes:238]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-22-000103:notes:239]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience.

[0001375365-22-000103:notes:240]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-22-000103:notes:241]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-22-000103:notes:242]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-22-000103:notes:243]
The fair value of stock option grants for the fiscal years ended June 30, 2022, 2021 and 2020 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-22-000103:notes:244]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Risk-free interest rate | 0.81% - 3.02% |  | 0.27% - 1.09% |  | 0.47% - 1.72% |
| Expected term | 6.09 years |  | 5.98 years |  | 6.27 years |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 49.69% - 50.13% |  | 50.03% - 50.43% |  | 49.61% - 50.46% |
| Weighted-average fair value | $ | 20.25 |  |  | $ | 14.92 |  |  | $ | 9.59 |  |

[0001375365-22-000103:notes:245]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2022, 2021 and 2020 (in thousands):

[0001375365-22-000103:notes:246]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Cost of sales | $ | 1,876 |  |  | $ | 1,762 |  |  | $ | 1,504 |  |
| Research and development | 16,571 |  |  | 14,030 |  |  | 12,202 |  |
| Sales and marketing | 2,058 |  |  | 2,022 |  |  | 1,680 |  |
| General and administrative | 12,311 |  |  | 10,735 |  |  | 4,803 |  |
| Stock-based compensation expense before taxes | 32,816 |  |  | 28,549 |  |  | 20,189 |  |
| Income tax impact | (12,220) |  |  | (8,574) |  |  | (6,814) |  |
| Stock-based compensation expense, net | $ | 20,596 |  |  | $ | 19,975 |  |  | $ | 13,375 |  |

[0001375365-22-000103:notes:247]
As of June 30, 2022, $12.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.41 years and $56.5 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.78 years. Additionally, as described below, $5.6 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 3.0 years.

[0001375365-22-000103:notes:248]
Stock Option Activity

[0001375365-22-000103:notes:249]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 1,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). The 2021 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2021 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $120.00 per share thereafter (based on a 60 trading day average stock price), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to March 2, 2024, the Company’s CEO must hold shares that he acquires until March 2, 2024, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-22-000103:notes:250]
The achievement status of the operational and stock price milestones as of June 30, 2022, was as follows:

[0001375365-22-000103:notes:251]
| Annualized Revenue Milestone |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |
| (in billions) |  |  |  |  |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved(1) |
| $4.8 |  | Achieved(2) |  | $60 |  | Not yet achieved |
| $5.8 |  | Probable |  | $75 |  | Not yet achieved |
| $6.8 |  | Probable |  | $95 |  | Not yet achieved |
| $8.0 |  | Probable |  | $120 |  | Not yet achieved |

[0001375365-22-000103:notes:252]
(1)The Company’s Compensation Committee had certified achievement of the $4 billion annualized revenue milestone on March 26, 2022. The $45 stock price milestone was achieved based upon the 60-trading day average stock price from March 15, 2022 through June 8, 2022. The achievement of such stock price milestone and the vesting of the first tranche of 200,000 option shares under the 2021 CEO Performance Stock Option, representing one-fifth of such award were certified by the Company's Compensation Committee subsequent to June 30, 2022.

[0001375365-22-000103:notes:253]
(2)To be certified by the Company's Compensation Committee after Annual Report on Form 10-K for the year ended June 30, 2022, as filed with the SEC.

[0001375365-22-000103:notes:254]
On the grant date, a Monte Carlo simulation was used to determine for each tranche (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-22-000103:notes:255]
During the fiscal year ended June 30, 2022, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $7.1 million. As of June 30, 2022, $5.6 million in unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 3.0 years.

[0001375365-22-000103:notes:256]
The following table summarizes stock option activity during the fiscal years ended June 30, 2022, 2021 and 2020 under all plans:

[0001375365-22-000103:notes:257]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |  |  |
| Granted |  | 273,260 |  |  | $ | 19.61 |  |  |  |  |  |
| Exercised |  | (1,812,000) |  |  | $ | 15.74 |  |  |  |  |  |
| Forfeited/Cancelled |  | (456,127) |  |  | $ | 11.97 |  |  |  |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  |  |  |  |
| Granted |  | 1,517,110 |  |  | $ | 40.49 |  |  |  |  |  |
| Exercised |  | (1,645,800) |  |  | $ | 17.25 |  |  |  |  |  |
| Forfeited/Cancelled |  | (75,524) |  |  | $ | 24.43 |  |  |  |  |  |
| Balance as of June 30, 2021 |  | 5,175,554 |  |  | $ | 26.17 |  |  |  |  |  |
| Granted |  | 489,940 |  |  | $ | 40.23 |  |  |  |  |  |
| Exercised |  | (1,197,756) |  |  | $ | 17.82 |  |  |  |  |  |
| Forfeited/Cancelled |  | (156,322) |  |  | $ | 30.47 |  |  |  |  |  |
| Balance as of June 30, 2022 |  | 4,311,416 |  |  | $ | 29.99 |  |  | 5.60 |  | $ | 50,010 |  |
| Options vested and exercisable at June 30, 2022 |  | 2,497,977 |  |  | $ | 22.24 |  |  | 3.31 |  | $ | 45,232 |  |

[0001375365-22-000103:notes:258]
The total pretax intrinsic value of options exercised during the fiscal year ended June 30, 2022, 2021 and 2020 was $29.6 million, $24.3 million and $19.3 million, respectively. Additional information regarding options outstanding as of June 30, 2022, is as follows:

[0001375365-22-000103:notes:259]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $9.24 - $14.23 |  | 479,265 |  |  | 1.72 |  | $ | 12.22 |  |  | 469,819 |  |  | $ | 12.20 |  |
| $14.95 - $20.37 |  | 459,117 |  |  | 4.13 |  | $ | 18.34 |  |  | 417,757 |  |  | $ | 18.42 |  |
| $20.54 - $22.10 |  | 491,131 |  |  | 3.08 |  | $ | 21.19 |  |  | 475,696 |  |  | $ | 21.20 |  |
| $22.15 - $25.44 |  | 486,997 |  |  | 4.48 |  | $ | 24.28 |  |  | 404,847 |  |  | $ | 24.48 |  |
| $26.60 - $30.33 |  | 559,007 |  |  | 4.91 |  | $ | 27.91 |  |  | 478,856 |  |  | $ | 27.50 |  |
| $33.36 - $37.88 |  | 432,552 |  |  | 5.95 |  | $ | 35.81 |  |  | 214,674 |  |  | $ | 35.20 |  |
| $38.50 - $41.25 |  | 351,827 |  |  | 9.28 |  | $ | 39.99 |  |  | 34,231 |  |  | $ | 38.67 |  |
| $42.35 - $42.35 |  | 8,390 |  |  | 3.82 |  | $ | 42.35 |  |  | 2,097 |  |  | $ | 42.35 |  |
| $45.00 - $45.00 |  | 1,000,000 |  |  | 8.67 |  | $ | 45.00 |  |  | — |  |  | $ | — |  |
| $53.04 - $53.04 |  | 43,130 |  |  | 9.85 |  | $ | 53.04 |  |  | — |  |  | $ | — |  |
| $9.24 - $53.04 |  | 4,311,416 |  |  | 5.60 |  | $ | 29.99 |  |  | 2,497,977 |  |  | $ | 22.24 |  |

[0001375365-22-000103:notes:260]
RSU and PRSU Activity

[0001375365-22-000103:notes:261]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units have vested in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019. An additional 2,939 units were earned for fiscal year 2021 that vested on November 10, 2021.

[0001375365-22-000103:notes:262]
The following table summarizes RSUs and PRSUs activity during the fiscal years ended June 30, 2022, and 2021 under all plans:

[0001375365-22-000103:notes:263]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUs Outstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2019 |  | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  |  |  | $ | 27.10 |  |
| Granted |  | 943,650 |  |  | $ | 20.45 |  |  | 30,000 |  |  |  | $ | 20.37 |  |
| Released(1) |  | (871,274) |  |  | $ | 20.97 |  |  | (108,000) |  |  |  | $ | 27.10 |  |
| Forfeited |  | (177,451) |  |  | $ | 19.49 |  |  | — |  |  |  |  |
| Balance as of June 30, 2020 |  | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  |  |  | $ | 22.29 |  |
| Granted |  | 1,334,418 |  |  | $ | 31.54 |  |  | 30,000 |  |  |  | $ | 34.27 |  |
| Released(1) |  | (984,406) |  |  | $ | 21.63 |  |  | (27,000) |  |  |  | $ | 23.36 |  |
| Forfeited |  | (263,083) |  |  | $ | 25.01 |  |  | (30,000) |  |  |  | $ | 20.37 |  |
| Balance as of June 30, 2021 |  | 1,854,956 |  |  | $ | 26.79 |  |  | 15,000 |  |  |  | $ | 34.27 |  |
| Granted |  | 1,121,451 |  |  | $ | 38.99 |  |  | 2,939 |  |  |  | $ | 34.27 |  |
| Released(1) |  | (745,702) |  |  | $ | 25.16 |  |  | (17,939) |  |  |  | $ | 34.27 |  |
| Forfeited |  | (351,632) |  |  | $ | 30.19 |  |  | — |  |  |  | $ | — |  |
| Balance as of June 30, 2022 |  | 1,879,073 |  |  | $ | 33.72 |  |  | — |  |  |  | $ | — |  |

[0001375365-22-000103:notes:264]
(1)    The number of shares released excludes 172,857 RSUs that were vested but not released in fiscal year 2019. The number of vested but not released RSUs for fiscal years 2021 and 2020 was not material. The number of shares released also excludes 24,000 PRSUs that were vested but not released in fiscal year 2019. These vested RSUs and PRSUs were primarily released in fiscal year 2020 and included in fiscal year 2020 upon the effectiveness of the Company's registration statement on Form S-8.

[0001375365-22-000103:notes:265]
The total pretax intrinsic value of RSUs and PRSUs vested was $33.1 million, $32.6 million and $18.9 million for the fiscal years ended June 30, 2022, 2021 and 2020, respectively. In fiscal years 2022, 2021 and 2020, the Company withheld 232,461, 274,620 and 331,648 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes from the vesting and release of 763,641, 1,011,406 and 979,274 RSUs and PRSUs, respectively, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to tax authorities were $10.1 million, $8.7 million and $8.2 million for the fiscal years ended June 30, 2022, 2021 and 2020, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2020 and 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2020 and 2016 Plan, respectively, and are available for future grants under the 2020 Plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-22-000103:notes:266]
Income Taxes
The components of income before income tax provision for the fiscal years ended June 30, 2022, 2021 and 2020 are as follows (in thousands):

[0001375365-22-000103:notes:267]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| United States | $ | 250,513 |  |  | $ | 80,922 |  |  | $ | 35,701 |  |
| Foreign | 86,320 |  |  | 37,706 |  |  | 49,127 |  |
| Income before income tax provision | $ | 336,833 |  |  | $ | 118,628 |  |  | $ | 84,828 |  |

[0001375365-22-000103:notes:268]
The income tax provision for the fiscal years ended June 30, 2022, 2021 and 2020, consists of the following (in thousands):

[0001375365-22-000103:notes:269]
|  | Years Ended June 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| Federal | $ | 34,711 |  |  | $ | 3,406 |  |  | $ | 4,568 |  |
| State | 4,327 |  |  | 1,077 |  |  | 1,727 |  |
| Foreign | 20,495 |  |  | 10,843 |  |  | 10,399 |  |
|  | 59,533 |  |  | 15,326 |  |  | 16,694 |  |
| Deferred: |  |  |  |  |  |
| Federal | (4,030) |  |  | (5,489) |  |  | (10,108) |  |
| State | (257) |  |  | (409) |  |  | (1,621) |  |
| Foreign | (2,370) |  |  | (2,492) |  |  | (2,043) |  |
|  | (6,657) |  |  | (8,390) |  |  | (13,772) |  |
| Income tax provision | $ | 52,876 |  |  | $ | 6,936 |  |  | $ | 2,922 |  |

[0001375365-22-000103:notes:270]
The Company’s net deferred tax assets as of June 30, 2022 and 2021 consist of the following (in thousands):

[0001375365-22-000103:notes:271]
|  | June 30, |
|  | 2022 |  | 2021 |
| Research and development credits | $ | 33,080 |  |  | $ | 30,540 |  |
| Deferred revenue | 24,370 |  |  | 18,584 |  |
| Inventory valuation | 16,792 |  |  | 13,831 |  |
| Capitalized research and development costs | 14,589 |  |  | 15,206 |  |
| Stock-based compensation | 3,762 |  |  | 3,868 |  |
| Lease obligations | 4,035 |  |  | 2,861 |  |
| Accrued vacation and bonus | 6,052 |  |  | 5,098 |  |
| Prepaid and accrued expenses | 1,298 |  |  | 1,179 |  |
| Warranty accrual | 2,134 |  |  | 2,154 |  |
| Bad debt and other reserves | 1,183 |  |  | 1,668 |  |
| Marketing fund accrual | 1,308 |  |  | 720 |  |
| Other | 5,169 |  |  | 4,460 |  |
| Total deferred income tax assets | 113,772 |  |  | 100,169 |  |
| Deferred tax liabilities-depreciation and other | (6,259) |  |  | (4,137) |  |
| Right of use asset | (3,919) |  |  | (2,831) |  |
| Valuation allowance | (33,665) |  |  | (29,913) |  |
| Deferred income tax assets, net | $ | 69,929 |  |  | $ | 63,288 |  |

[0001375365-22-000103:notes:272]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2022, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of state research and development tax credits that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2022, the gross excess credits of $42.0 million, or net of federal tax benefit of $33.2 million, were subject to a full valuation allowance. At June 30, 2021, the gross excess credits of $37.1 million, or net of federal tax benefit of $29.3 million, were subject to a full valuation allowance. The change in valuation allowance is $3.8 million and $5.0 million for the fiscal years ended June 30, 2022 and 2021, respectively. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2022 and 2021 was $69.9 million and $63.3 million, respectively.

[0001375365-22-000103:notes:273]
The 2017 Tax Reform Act also creates a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) that must be included currently in the gross income of a CFC’s U.S. stockholder starting in the tax year that begins after 2017. GILTI does not have material impact on the Company's income tax provision.

[0001375365-22-000103:notes:274]
Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into a company’s measurement of its deferred taxes. The Company's selection of an accounting policy with respect to the GILTI tax rules is to treat GILTI tax as a current period expense under the period cost method.

[0001375365-22-000103:notes:275]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for undistributed earnings related to the Company’s operations in the Netherlands. The Company may repatriate foreign earnings from the Netherlands that have been previously taxed in the U.S.  The tax impact of such repatriation is estimated to be immaterial.

[0001375365-22-000103:notes:276]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. As a result of this restructuring, the Company realized $4.6 million and $3.0 million additional tax benefit from foreign derived intangible income in fiscal years 2022 and 2021 respectively, as compared to fiscal year 2020.

[0001375365-22-000103:notes:277]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted. The CARES Act provides temporary relief from certain aspects of the 2017 Tax Reform Act that imposed limitations on the utilization of certain losses, interest expense deductions, alternative minimum tax credits and made a technical correction to the 2017 Tax Reform Act related to the depreciable life of qualified improvement property. The CARES Act did not have a material impact on the Company.

[0001375365-22-000103:notes:278]
The following is a reconciliation for the fiscal years ended June 30, 2022, 2021 and 2020, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-22-000103:notes:279]
|  |  | Years Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Income tax provision at statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax, net of federal tax benefit |  | 0.9 |  |  | 0.3 |  |  | — |  |
| Foreign rate differential |  | (0.3) |  |  | (0.5) |  |  | — |  |
| Research and development tax credit |  | (3.9) |  |  | (10.5) |  |  | (13.1) |  |
| Uncertain tax positions, net of (settlement) with Tax Authorities |  | 0.3 |  |  | 2.0 |  |  | (2.3) |  |
| Foreign derived intangible / Subpart F income inclusion |  | (1.4) |  |  | (2.5) |  |  | (3.8) |  |
| Stock-based compensation |  | (1.5) |  |  | (3.3) |  |  | (2.8) |  |
| Non deductible penalty on SEC matter |  | — |  |  | — |  |  | 4.4 |  |
| Provision to return true-up |  | 0.1 |  |  | (1.9) |  |  | (1.1) |  |
| Other, net |  | 0.5 |  |  | 1.2 |  |  | 1.1 |  |
| Effective tax rate |  | 15.7 | % |  | 5.8 | % |  | 3.4 | % |

[0001375365-22-000103:notes:280]
As of June 30, 2022, the Company had state research and development tax credit carryforwards of $55.6 million. The state research and development tax credits will carryforward indefinitely to offset future state income taxes.

[0001375365-22-000103:notes:281]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-22-000103:notes:282]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2019 | $ | 28,048 |  |
| Gross increases: |  |
| For current year’s tax positions | 8,769 |  |
| For prior years’ tax positions | 505 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (7,632) |  |
| Decreases due to lapse of statute of limitations | (2,484) |  |
| Balance at June 30, 2020 | 27,206 |  |
| Gross increases: |  |
| For current year’s tax positions | 13,333 |  |
| For prior years’ tax positions | 1,439 |  |
| Gross decreases: |  |
| Decreases due to lapse of statute of limitations | (1,243) |  |
| Balance at June 30, 2021 | 40,735 |  |
| Gross increases: |  |
| For current year’s tax positions | 2,392 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (4,090) |  |
| Decreases due to lapse of statute of limitations | (1,036) |  |
| Balance at June 30, 2022 | $ | 38,001 |  |

[0001375365-22-000103:notes:283]
*excludes interest, penalties, federal benefit of state reserves

[0001375365-22-000103:notes:284]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $23.5 million and $27.1 million as of June 30, 2022 and 2021, respectively.

[0001375365-22-000103:notes:285]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the income tax provision in the consolidated statements of operations. As of June 30, 2022 and 2021, the Company had accrued $3.1 million and $2.5 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively.

[0001375365-22-000103:notes:286]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in February 2020. In February 2020, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2019 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of these adjustments on the income statement was offset by the release of previously unrecognized tax benefits related to the fiscal years audited in the periods in which the proposed adjustments were accepted.

[0001375365-22-000103:notes:287]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved. 
The federal statute of limitations remains open in general for tax years ended June 30, 2019 through 2022. Various states statute of limitations remains open in general for tax years ended June 30, 2018 through 2022. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2016 through 2022. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.4 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-22-000103:notes:288]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement,  pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. Consequently, the parties expect the Court will grant preliminary approval and calendar a future hearing for final approval. This settlement, if finally approved by the Court, will fully resolve the action.

[0001375365-22-000103:notes:289]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021, motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021. Following a March 23, 2022, hearing, on March 25, 2022, the Court granted defendants’ demurrers on the grounds that plaintiffs had failed to allege demand futility and the Court dismissed the amended complaint, but with leave to amend by May 20, 2022. On May 13, 2022, plaintiff’s counsel reported to the Court that plaintiff would not file an amended complaint and the May 20 deadline lapsed without further amendment. On June 8, 2022, the court entered judgment in defendants’ favor and with prejudice against plaintiff. This matter has now been dismissed.

[0001375365-22-000103:notes:290]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice. On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval. On December 16, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval. The Company provided notice as required by the Court on December 21, 2021. No shareholder sought to intervene during the 45-day notice period ending on February 4, 2022, and on March 24, 2022, the Court issued an order dismissing the lawsuit with prejudice as to the named plaintiff.

[0001375365-22-000103:notes:291]
SEC Matter — The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations in the first quarter of fiscal 2021. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense in the first quarter of fiscal 2021.

[0001375365-22-000103:notes:292]
Other legal proceedings and indemnifications

[0001375365-22-000103:notes:293]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of June 30, 2022, and any prior periods.

[0001375365-22-000103:notes:294]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-22-000103:notes:295]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers' liability insurance coverage to reduce its exposure to such obligations.

[0001375365-22-000103:notes:296]
Purchase Commitments - The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2022, these remaining noncancelable commitments were $562.9 million, including $80.2 million for related parties.
 Lease Commitments - See Part II, Item 8, Note 11, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-22-000103:notes:297]
Retirement Plans
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2022, 2021 and 2020.

[0001375365-22-000103:notes:298]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. The Company is required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the fiscal years ended June 30, 2022, 2021 and 2020, the Company’s matching contribution was $0.8 million, $0.7 million, and $0.6 million, respectively.

[0001375365-22-000103:notes:299]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2022, 2021 and 2020, the Company’s contribution was $3.4 million, $2.5 million and $1.9 million, respectively.

[0001375365-22-000103:notes:300]
The Company has a defined benefit pension plan under the R.O.C. Labor Standards Law for certain employees of Super Micro Computer, Inc. Taiwan that provides benefits based on an employee’s length of service and average monthly salary for the six-month period prior to retirement. The Company contributes an amount equal to 2% of salaries paid each month to the pension fund (the “Fund”), which is administered by the Labor Pension Fund Supervisory Committee (the “Committee”) and deposited in the Committee’s name in the Bank of Taiwan. Before the end of each year, the Company assesses the balance in the Fund. If the amount of the balance in the Fund is inadequate to pay retirement benefits for eligible employees in the next year, the Company is required to fund the difference in one appropriation that should be made before the end of March 31 of the next year. The Fund is operated and managed by the government’s designated authorities. As such, the Company does not have any right to intervene in the investments of the Fund. For the fiscal years ended June 30, 2022 and 2021, the Company recorded a pension expense of $0.4 million and $1.0 million, respectively. For the fiscal year ended June 30, 2020, the Company’s pension expense was immaterial.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-22-000103:notes:301]
Segment Reporting
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-22-000103:notes:302]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-22-000103:notes:303]
|  | June 30, |  |  |
|  | 2022 |  | 2021 |  |  |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 180,846 |  |  | $ | 180,143 |  |  |  |
| Asia | 102,241 |  |  | 91,640 |  |  |  |
| Europe | 2,885 |  |  | 2,930 |  |  |  |
|  | $ | 285,972 |  |  | $ | 274,713 |  |  |  |

[0001375365-22-000103:notes:304]
The Company’s revenue is presented on a disaggregated basis in Note 3, “Revenue” by type of product and by geographical market.
