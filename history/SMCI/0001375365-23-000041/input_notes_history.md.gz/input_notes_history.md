# SMCI note change history — 0001375365-23-000028 → 0001375365-23-000041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:1]
Commitments and Contingencies
Legal proceedings and indemnifications
  (was, 2023-05-05, similarity 0.75):
[0001375365-23-000028:note_history:1]
Other legal proceedings and indemnifications

- changed (2023-11-03):
[0001375365-23-000041:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2023 and any prior periods.
  (was, 2023-05-05, similarity 0.9785):
[0001375365-23-000028:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2023 and any prior periods.

- changed (2023-11-03):
[0001375365-23-000041:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2023, these remaining noncancelable commitments were $1.4 billion, including $66.4 million for related parties.
  (was, 2023-05-05, similarity 0.6604):
[0001375365-23-000028:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2023, these remaining noncancelable commitments were $932.8 million, including $83.3 million for related parties.
Lease Commitments - See Part I, Item 1, Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.

- removed (2023-11-03):
[0001375365-23-000028:note_history:4]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 5, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. All settlement funds have been transferred into an account controlled by the settlement’s escrow agent. No settlement funds will be distributed until the Court grants final approval. On November 8, 2022, the Court granted preliminary approval and calendared a hearing on March 2, 2023 for final approval, which the Court continued to May 4, 2023. At the May 4, 2023 hearing, the Court indicated that it planned to grant final approval in a subsequent order, which will fully resolve the action.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.
  (was, 2023-05-05, similarity 0.7174):
[0001375365-23-000028:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.

- added (2023-11-03):
[0001375365-23-000041:note_history:6]
Certain prior year amounts within cash from operating activities in the condensed consolidated statements of cash flows have been reclassified to conform to current year presentation. These changes in presentation do not affect previously reported results.

- changed (2023-11-03):
[0001375365-23-000041:note_history:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 55.1% and 10.3% of total purchases for the three months ended September 30, 2023, and the same two suppliers accounted for 25.7% and 16.1% of total purchases for the three months ended September 30, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 55.1% of total purchases for the three months ended September 30, 2023 is as a result of the purchase of GPUs to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% of total cost of sales for both the three months ended September 30, 2023 and 2022.
  (was, 2023-05-05, similarity 0.6111):
[0001375365-23-000028:note_history:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 16.9% and 26.9% of total purchases for the three months ended March 31, 2023, and the same two suppliers accounted for 13.0% and 19.4% of total purchases for the three months ended March 31, 2022. Two suppliers accounted for 15.8% and 23.6% of total purchases for the nine months ended March 31, 2023, and the same two suppliers accounted for 18.0% and 11.4% of total purchases for the nine months ended March 31, 2022. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 8.3% and 8.2% of total cost of sales for the three months ended March 31, 2023 and 2022, respectively, and a combined 7.0% and 9.0% of total cost of sales for the nine months ended March 31, 2023 and 2022, respectively.

- changed (2023-11-03):
[0001375365-23-000041:note_history:8]
Concentration of Credit and Customer Risk
  (was, 2023-05-05, similarity 0.8116):
[0001375365-23-000028:note_history:8]
Concentration of Credit Risk

- added (2023-11-03):
[0001375365-23-000041:note_history:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash and accounts receivable.

- added (2023-11-03):
[0001375365-23-000041:note_history:10]
Three customers accounted for 15.7%, 14.5% and 10.3% of accounts receivable, net as of September 30, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.
One customer accounted for 25.0% of the net sales for the three months ended September 30, 2023. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:11]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 10.7% of the net sales for the three months ended March 31, 2023, and one customer accounted for 11.8% of the net sales for the nine months ended March 31, 2023. One customer accounted for 10.2% of the net sales for the three months ended March 31, 2022 and no single customer accounted for 10% or more of the net sales for the nine months ended March 31, 2022. One customer accounted for 21.0% of the Company's accounts receivable, net as of March 31, 2023. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:12]
Treasury Stock

- removed (2023-11-03):
[0001375365-23-000028:note_history:13]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

- removed (2023-11-03):
[0001375365-23-000028:note_history:14]
Accounting Pronouncements Recently Adopted

- removed (2023-11-03):
[0001375365-23-000028:note_history:15]
There were no new pronouncements recently adopted.

- removed (2023-11-03):
[0001375365-23-000028:note_history:16]
Accounting Pronouncements Not Yet Adopted

- removed (2023-11-03):
[0001375365-23-000028:note_history:17]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendment was effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In December 2022, FASB issued an Accounting Standards Update (ASU) for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The ASU defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, ESUN and Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have a material impact on its consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:18]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands):
  (was, 2023-05-05, similarity 0.9655):
[0001375365-23-000028:note_history:18]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:19]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2021 CTBC Credit Lines | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | — |  |  | — |  |
| Total line of credit | — |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 23,892 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,424 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 4,183 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 29,756 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,782 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,195 |  |  | 38,668 |  |
| Total term loans | 146,232 |  |  | 158,719 |  |
| Total debt | 146,232 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 40,843 |  |  | 170,123 |  |
| Debt, non-current | $ | 105,389 |  |  | $ | 120,179 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:20]
Available borrowings and interest rates as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2023-05-05, similarity 0.9632):
[0001375365-23-000028:note_history:20]
Available borrowings and interest rates as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands except for percentages):

- changed (2023-11-03):
[0001375365-23-000041:note_history:21]
|  | September 30, 2023 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.80% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.50% |  | $ | 417 |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  | — |  | $ | 105,000 |  | 3.33% |
| 2023 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.51% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | 50,000 |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 20,000 |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | — |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.75% |  | $ | 7,734 |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.40% - 1.60% |
  (was, 2023-05-05, similarity 0.7401):
[0001375365-23-000028:note_history:21]
|  | March 31, 2023 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 330,000 |  | 6.04% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 6.87% |  | $ | 102,000 |  | 4.00% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.23% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.18% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 0.83% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | 6,308 |  | 1.03% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 5,250 |  | 1.75% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.02% - 1.22% |

- changed (2023-11-03):
[0001375365-23-000041:note_history:22]
The Company entered into a new General Credit Agreement with CTBC Bank during the three months ended  September 30, 2023 with the following terms:
  (was, 2023-05-05, similarity 0.7951):
[0001375365-23-000028:note_history:22]
The Company entered into new agreements during the nine months ended March 31, 2023 with the following terms:

- changed (2023-11-03):
[0001375365-23-000041:note_history:23]
2023 CTBC Bank Credit Lines
  (was, 2023-05-05, similarity 0.8571):
[0001375365-23-000028:note_history:23]
2022 CTBC Credit Line

- added (2023-11-03):
[0001375365-23-000041:note_history:24]
On September 28, 2023 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank, which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

- added (2023-11-03):
[0001375365-23-000041:note_history:25]
Interest rates under each of the individual New CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line are secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor for each of the individual New CTBC Credit Lines is one year. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of its Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the New CTBC Credit Lines. The New CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable upon the occurrence of an event of default.

- added (2023-11-03):
[0001375365-23-000041:note_history:26]
The Company's Taiwan subsidiary intends to use borrowings under the New CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices) and to finance additional improvements to the Company’s Bade Manufacturing Facility located in Taiwan.

- removed (2023-11-03):
[0001375365-23-000028:note_history:27]
|  | March 31, |  | June 30, |
|  | 2023 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 20,000 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 20,000 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 29,405 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,390 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,189 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 36,764 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 17,069 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 39,390 |  |  | 40,372 |  |
| Total term loans | 167,207 |  |  | 162,919 |  |
| Total debt | 187,207 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 53,972 |  |  | 449,146 |  |
| Debt, non-current | $ | 133,235 |  |  | $ | 147,618 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:28]
E.SUN Bank

- removed (2023-11-03):
[0001375365-23-000028:note_history:29]
2022 E.SUN Bank Credit Facility

- removed (2023-11-03):
[0001375365-23-000028:note_history:30]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through Super Micro Computer Inc., Taiwan, a Taiwan corporation and wholly-owned subsidiary of the Company (the “Taiwan Subsidiary”), entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US $30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan Subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

- removed (2023-11-03):
[0001375365-23-000028:note_history:31]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Taiwan Subsidiary and E.SUN Bank have agreed to both a Medium Term Credit Loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the New E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan Subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Taiwan Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and the principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of March 31, 2023, the amount outstanding under the Medium Term Loan was denominated in NTD and remeasured into US dollars of $53.8 million. The interest rate as of March 31, 2023 was 1.75% per annum. As of March 31, 2023 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $0.0 million and $7.8 million, respectively. The interest rate as of March 31, 2023 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of March 31, 2023, the amount available for future borrowing under the Import O/A Loan was $30.0 million.

- removed (2023-11-03):
[0001375365-23-000028:note_history:32]
Pursuant to banking practices in Taiwan to confirm loan agreements annually, on October 3, 2022, the Company through the Taiwan Subsidiary entered into an Agreement for Individually Negotiated Terms and Conditions with CTBC Bank Co., Ltd. (“CTBC Bank”) (such credit line, the “2022 CTBC Credit Line”) related to the prior 2021 CTBC credit lines (the “2021 CTBC Credit Lines”). The terms of the 2022 CTBC Credit Line remain substantially similar to the 2021 CTBC Credit Line, except the 2022 CTBC Credit Line made certain minor amendments to the monthly interest payment date. The total borrowing cap under the whole arrangement is $105.0 million and NTD 1,550.0 million ($55.4 million U.S. dollar equivalent).

- removed (2023-11-03):
[0001375365-23-000028:note_history:33]
The Company, through the Taiwan Subsidiary, was party to that certain credit agreement, dated May 6, 2020, with CTBC Bank, which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent). As of March 31, 2023 and June 30, 2022, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.4 million and $40.4 million, respectively. The interest rates for these loans were 1.20% per annum as of March 31, 2023 and 0.83% as of June 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:34]
The 2021 Credit Lines permitted borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the previously-existing ten-year, non-revolving term loan facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”). As of March 31, 2023 and June 30, 2022, under the 2021 CTBC Machine Loan, the amounts outstanding were $5.2 million and $5.5 million, respectively. The interest rates for these loans were 1.40% per annum as of March 31, 2023 and 1.03% as of June 30, 2022. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. As of March 31, 2023 and June 30, 2022, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were none and $84.8 million, respectively. The interest rates for these loans was 3.33% per annum as of March 31, 2023 and ranged from 1.80% to 2.52% as of June 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:35]
As of March 31, 2023, the amount available for future borrowing under the 2022 CTBC Credit Line was $105 million. As of March 31, 2023, the net book value of land and building located in Bade, Taiwan, collateralizing the 2022 CTBC Credit Line was $75.4 million. The Company was in compliance with all financial covenants under 2022 CTBC Credit Line as of March 31, 2023.

- removed (2023-11-03):
[0001375365-23-000028:note_history:36]
HSBC Bank

- removed (2023-11-03):
[0001375365-23-000028:note_history:37]
HSBC Bank Credit Facility

- removed (2023-11-03):
[0001375365-23-000028:note_history:38]
On February 7, 2023, the Company through the Taiwan subsidiary, entered into a new facility letter (the “New Facility Letter”) with the Taiwan affiliate of HSBC Bank which expanded the prior $30 million facility letter entered into with HSBC Bank on January 7, 2022. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date. Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash cover. As of March 31, 2023 and June 30, 2022, the outstanding borrowings under the HSBC Credit Facility were $0.0 million and $30.0 million, respectively. The interest rates for these loans were 4.50% per annum as of March 31, 2023 and ranged from 1.95% to 2.20% as of June 30, 2022.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:39]
Short-term and long-term debt obligations as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands):
  (was, 2023-05-05, similarity 0.9565):
[0001375365-23-000028:note_history:39]
Short-term and long-term debt obligations as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:40]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2021 CTBC Credit Lines | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | — |  |  | — |  |
| Total line of credit | — |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 23,892 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,424 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 4,183 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 29,756 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,782 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,195 |  |  | 38,668 |  |
| Total term loans | 146,232 |  |  | 158,719 |  |
| Total debt | 146,232 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 40,843 |  |  | 170,123 |  |
| Debt, non-current | $ | 105,389 |  |  | $ | 120,179 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:41]
Available borrowings and interest rates as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2023-05-05, similarity 0.9632):
[0001375365-23-000028:note_history:41]
Available borrowings and interest rates as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands except for percentages):

- changed (2023-11-03):
[0001375365-23-000041:note_history:42]
|  | September 30, 2023 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.80% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.50% |  | $ | 417 |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  | — |  | $ | 105,000 |  | 3.33% |
| 2023 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.51% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | 50,000 |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 20,000 |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | — |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.75% |  | $ | 7,734 |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.40% - 1.60% |
  (was, 2023-05-05, similarity 0.7401):
[0001375365-23-000028:note_history:42]
|  | March 31, 2023 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 330,000 |  | 6.04% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 6.87% |  | $ | 102,000 |  | 4.00% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.23% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.18% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 0.83% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | 6,308 |  | 1.03% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 5,250 |  | 1.75% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.02% - 1.22% |

- removed (2023-11-03):
[0001375365-23-000028:note_history:43]
|  | March 31, |  | June 30, |
|  | 2023 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 20,000 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 20,000 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 29,405 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,390 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,189 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 36,764 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 17,069 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 39,390 |  |  | 40,372 |  |
| Total term loans | 167,207 |  |  | 162,919 |  |
| Total debt | 187,207 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 53,972 |  |  | 449,146 |  |
| Debt, non-current | $ | 133,235 |  |  | $ | 147,618 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:44]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2023-05-05, similarity 0.9944):
[0001375365-23-000028:note_history:44]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- changed (2023-11-03):
[0001375365-23-000041:note_history:45]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 85.5% and 88.4% of the chassis included in the products sold by the Company during the three months ended September 30, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2023-05-05, similarity 0.9188):
[0001375365-23-000028:note_history:45]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.3% and 88.8% of the chassis included in the products sold by the Company during the three months ended March 31, 2023 and 2022, respectively, and 93.0% and 82.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2023-11-03):
[0001375365-23-000041:note_history:46]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2023 were $49.5 million and $27.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2023-05-05, similarity 0.9941):
[0001375365-23-000028:note_history:46]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on March 31, 2023 were $23.4 million and $23.6 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2023-11-03):
[0001375365-23-000041:note_history:47]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company’s products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company’s standard price for its purchases.
  (was, 2023-05-05, similarity 0.9954):
[0001375365-23-000028:note_history:47]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

- changed (2023-11-03):
[0001375365-23-000041:note_history:48]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2023 were $138.2 million and $38.8 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2023-05-05, similarity 0.9915):
[0001375365-23-000028:note_history:48]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on March 31, 2023 were $154.3 million and $59.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2023-11-03):
[0001375365-23-000041:note_history:49]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.
  (was, 2023-05-05, similarity 0.9944):
[0001375365-23-000028:note_history:49]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- added (2023-11-03):
[0001375365-23-000041:note_history:50]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of September 30, 2023 and June 30, 2023.

- changed (2023-11-03):
[0001375365-23-000041:note_history:51]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2023. No impairment charge was recorded for the three months ended September 30, 2023 or 2022.
  (was, 2023-05-05, similarity 0.9588):
[0001375365-23-000028:note_history:51]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of March 31, 2023. No impairment charge was recorded for the three and nine months ended March 31, 2023 or 2022.

- added (2023-11-03):
[0001375365-23-000041:note_history:52]
The Company sold products worth $0.8 million and $11.3 million to the Corporate Venture during the three months ended September 30, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.2 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of September 30, 2023 and June 30, 2023, respectively.

- changed (2023-11-03):
[0001375365-23-000041:note_history:53]
The Company had the following balances related to transactions with its related parties as of September 30, 2023 and June 30, 2023 (in thousands):
  (was, 2023-05-05, similarity 0.9627):
[0001375365-23-000028:note_history:53]
The Company had the following balances related to transactions with its related parties as of March 31, 2023 and June 30, 2022 (in thousands):

- changed (2023-11-03):
[0001375365-23-000041:note_history:54]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 |  |  | September 30, 2023 | June 30, 2023 |
| Accounts receivable | $ | 4 |  | $ | 2 |  | $ | 1,092 |  | $ | 3,528 |  | $ | 239 |  | $ | 1,943 |  |  |  | $ | 1,335 |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,283 |  | $ | 2,841 |  | $ | 22,622 |  | $ | 24,891 |  | $ | — |  | $ | — |  |  |  | $ | 24,905 |  | $ | 27,732 |  |
| Accounts payable | $ | 44,476 |  | $ | 35,711 |  | $ | 47,639 |  | $ | 53,423 |  | $ | — |  | $ | — |  |  |  | $ | 92,115 |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 485 |  | $ | 1,230 |  | $ | 16,019 |  | $ | 12,787 |  | $ | — |  | $ | — |  |  |  | $ | 16,504 |  | $ | 14,017 |  |
  (was, 2023-05-05, similarity 0.9598):
[0001375365-23-000028:note_history:54]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 |  |  | March 31, 2023 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 111 |  | $ | 404 |  | $ | 1,918 |  | $ | 7,992 |  |  |  | $ | 2,031 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 4,189 |  | $ | 4,816 |  | $ | 28,796 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 32,985 |  | $ | 24,412 |  |
| Accounts payable | $ | 28,369 |  | $ | 42,463 |  | $ | 47,744 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 76,113 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,797 |  | $ | 3,531 |  | $ | 16,555 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 18,352 |  | $ | 18,676 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:55]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):
  (was, 2023-05-05, similarity 0.9595):
[0001375365-23-000028:note_history:55]
The Company's results from transactions with its related parties for each of the three months ended March 31, 2023 and 2022, are as follows (in thousands):

- changed (2023-11-03):
[0001375365-23-000041:note_history:56]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 16,606 |  | $ | 13,760 |  | $ | 788 |  | $ | 11,293 |  |  |  | $ | 17,396 |  | $ | 25,055 |  |
| Purchases - inventory | $ | 46,614 |  | $ | 47,847 |  | $ | 66,493 |  | $ | 48,689 |  | $ | — |  | $ | — |  |  |  | 113,107 |  | 96,536 |  |
| Purchases - other miscellaneous items | $ | 4,759 |  | $ | 4,763 |  | $ | 417 |  | $ | 258 |  | $ | — |  | $ | — |  |  |  | $ | 5,176 |  | $ | 5,021 |  |
  (was, 2023-05-05, similarity 0.6433):
[0001375365-23-000028:note_history:56]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 2,826 |  | $ | 3,928 |  | $ | 6,360 |  | $ | 43,739 |  | $ | — |  | $ | — |  | $ | 9,188 |  | $ | 47,669 |  |
| Purchases - inventory | $ | 33,637 |  | $ | 49,472 |  | $ | 54,095 |  | $ | 43,989 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,018 |  | $ | 87,732 |  | $ | 95,479 |  |
| Purchases - other miscellaneous items | $ | 2,329 |  | $ | 1,687 |  | $ | 541 |  | $ | 404 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,870 |  | $ | 2,091 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:57]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):
  (was, 2023-05-05, similarity 0.9457):
[0001375365-23-000028:note_history:57]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:58]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Changes in accounts receivable | $ | (2) |  | $ | — |  | $ | 2,436 |  | $ | (478) |  | $ | 1,704 |  | $ | (1,373) |  |  |  | $ | 4,138 |  | $ | (1,851) |  |
| Changes in other receivable | $ | 558 |  | $ | 1,276 |  | $ | 2,269 |  | $ | (11,415) |  | $ | — |  | $ | — |  |  |  | $ | 2,827 |  | $ | (10,139) |  |
| Changes in accounts payable | $ | 8,765 |  | $ | 664 |  | $ | (5,784) |  | $ | 6,010 |  | $ | — |  | $ | — |  |  |  | $ | 2,981 |  | $ | 6,674 |  |
| Changes in accrued liabilities | $ | (745) |  | $ | (1,532) |  | $ | 3,232 |  | $ | 11,117 |  | $ | — |  | $ | — |  |  |  | $ | 2,487 |  | $ | 9,585 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (80) |  | $ | (105) |  | $ | — |  | $ | — |  |  |  | $ | (80) |  | $ | (105) |  |
| Purchases of property, plant and equipment | $ | 782 |  | $ | 583 |  | $ | 44 |  | $ | 146 |  | $ | — |  | $ | — |  |  |  | $ | 826 |  | $ | 729 |  |
| Unpaid property, plant and equipment | $ | 3,672 |  | $ | 3,782 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 3,672 |  | $ | 3,782 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:59]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of March 31, 2023 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- removed (2023-11-03):
[0001375365-23-000028:note_history:60]
The Company sold products worth $6.4 million and $43.7 million to the Corporate Venture during the three months ended March 31, 2023 and 2022, respectively, and sold products worth $23.6 million and $97.3 million to the Corporate Venture during the nine months ended March 31, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2023 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $1.9 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of March 31, 2023 and June 30, 2022, respectively.

- removed (2023-11-03):
[0001375365-23-000028:note_history:61]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:62]
The Company's results from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

- removed (2023-11-03):
[0001375365-23-000028:note_history:63]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 6 |  | $ | 12 |  | $ | 30,699 |  | $ | 22,932 |  | $ | 23,611 |  | $ | 97,262 |  | $ | — |  | $ | — |  | $ | 54,316 |  | $ | 120,206 |  |
| Purchases - inventory | $ | 128,198 |  | $ | 147,780 |  | $ | 154,812 |  | $ | 126,039 |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,074 |  | $ | 283,010 |  | $ | 279,893 |  |
| Purchases - other miscellaneous items | $ | 9,855 |  | $ | 6,671 |  | $ | 1,078 |  | $ | 1,090 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 10,933 |  | $ | 7,761 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:64]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:65]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 293 |  | $ | (182) |  | $ | 6,074 |  | $ | (25,224) |  | $ | — |  | $ | — |  | $ | 6,367 |  | $ | (25,405) |  |
| Changes in other receivable | $ | 627 |  | $ | 3,159 |  | $ | (9,200) |  | $ | (8,933) |  | $ | — |  | $ | — |  | $ | — |  | $ | 48 |  | $ | (8,573) |  | $ | (5,726) |  |
| Changes in accounts payable | $ | (14,094) |  | $ | 814 |  | $ | 2,852 |  | $ | 16,356 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (11,242) |  | $ | 17,170 |  |
| Changes in accrued liabilities | $ | (1,734) |  | $ | (2,060) |  | $ | 1,410 |  | $ | (153) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | (324) |  | $ | (3,213) |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  |
| Purchases of property, plant and equipment | $ | 6,129 |  | $ | 2,365 |  | $ | 196 |  | $ | 140 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,325 |  | $ | 2,505 |  |
| Unpaid property, plant and equipment | $ | 1,369 |  | $ | 681 |  | $ | 22 |  | $ | 48 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,391 |  | $ | 729 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:66]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:67]
Tripartite Agreement

- removed (2023-11-03):
[0001375365-23-000028:note_history:68]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated, and during the quarter ended December 31, 2022, the Agreement was terminated.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:69]
The Company had the following balances related to transactions with its related parties as of September 30, 2023 and June 30, 2023 (in thousands):
  (was, 2023-05-05, similarity 0.9627):
[0001375365-23-000028:note_history:69]
The Company had the following balances related to transactions with its related parties as of March 31, 2023 and June 30, 2022 (in thousands):

- changed (2023-11-03):
[0001375365-23-000041:note_history:70]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 |  |  | September 30, 2023 | June 30, 2023 |
| Accounts receivable | $ | 4 |  | $ | 2 |  | $ | 1,092 |  | $ | 3,528 |  | $ | 239 |  | $ | 1,943 |  |  |  | $ | 1,335 |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,283 |  | $ | 2,841 |  | $ | 22,622 |  | $ | 24,891 |  | $ | — |  | $ | — |  |  |  | $ | 24,905 |  | $ | 27,732 |  |
| Accounts payable | $ | 44,476 |  | $ | 35,711 |  | $ | 47,639 |  | $ | 53,423 |  | $ | — |  | $ | — |  |  |  | $ | 92,115 |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 485 |  | $ | 1,230 |  | $ | 16,019 |  | $ | 12,787 |  | $ | — |  | $ | — |  |  |  | $ | 16,504 |  | $ | 14,017 |  |
  (was, 2023-05-05, similarity 0.9598):
[0001375365-23-000028:note_history:70]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 |  |  | March 31, 2023 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 111 |  | $ | 404 |  | $ | 1,918 |  | $ | 7,992 |  |  |  | $ | 2,031 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 4,189 |  | $ | 4,816 |  | $ | 28,796 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 32,985 |  | $ | 24,412 |  |
| Accounts payable | $ | 28,369 |  | $ | 42,463 |  | $ | 47,744 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 76,113 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,797 |  | $ | 3,531 |  | $ | 16,555 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 18,352 |  | $ | 18,676 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:71]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):
  (was, 2023-05-05, similarity 0.9595):
[0001375365-23-000028:note_history:71]
The Company's results from transactions with its related parties for each of the three months ended March 31, 2023 and 2022, are as follows (in thousands):

- changed (2023-11-03):
[0001375365-23-000041:note_history:72]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 16,606 |  | $ | 13,760 |  | $ | 788 |  | $ | 11,293 |  |  |  | $ | 17,396 |  | $ | 25,055 |  |
| Purchases - inventory | $ | 46,614 |  | $ | 47,847 |  | $ | 66,493 |  | $ | 48,689 |  | $ | — |  | $ | — |  |  |  | 113,107 |  | 96,536 |  |
| Purchases - other miscellaneous items | $ | 4,759 |  | $ | 4,763 |  | $ | 417 |  | $ | 258 |  | $ | — |  | $ | — |  |  |  | $ | 5,176 |  | $ | 5,021 |  |
  (was, 2023-05-05, similarity 0.6433):
[0001375365-23-000028:note_history:72]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 2,826 |  | $ | 3,928 |  | $ | 6,360 |  | $ | 43,739 |  | $ | — |  | $ | — |  | $ | 9,188 |  | $ | 47,669 |  |
| Purchases - inventory | $ | 33,637 |  | $ | 49,472 |  | $ | 54,095 |  | $ | 43,989 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,018 |  | $ | 87,732 |  | $ | 95,479 |  |
| Purchases - other miscellaneous items | $ | 2,329 |  | $ | 1,687 |  | $ | 541 |  | $ | 404 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,870 |  | $ | 2,091 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:73]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):
  (was, 2023-05-05, similarity 0.9457):
[0001375365-23-000028:note_history:73]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:74]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Changes in accounts receivable | $ | (2) |  | $ | — |  | $ | 2,436 |  | $ | (478) |  | $ | 1,704 |  | $ | (1,373) |  |  |  | $ | 4,138 |  | $ | (1,851) |  |
| Changes in other receivable | $ | 558 |  | $ | 1,276 |  | $ | 2,269 |  | $ | (11,415) |  | $ | — |  | $ | — |  |  |  | $ | 2,827 |  | $ | (10,139) |  |
| Changes in accounts payable | $ | 8,765 |  | $ | 664 |  | $ | (5,784) |  | $ | 6,010 |  | $ | — |  | $ | — |  |  |  | $ | 2,981 |  | $ | 6,674 |  |
| Changes in accrued liabilities | $ | (745) |  | $ | (1,532) |  | $ | 3,232 |  | $ | 11,117 |  | $ | — |  | $ | — |  |  |  | $ | 2,487 |  | $ | 9,585 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (80) |  | $ | (105) |  | $ | — |  | $ | — |  |  |  | $ | (80) |  | $ | (105) |  |
| Purchases of property, plant and equipment | $ | 782 |  | $ | 583 |  | $ | 44 |  | $ | 146 |  | $ | — |  | $ | — |  |  |  | $ | 826 |  | $ | 729 |  |
| Unpaid property, plant and equipment | $ | 3,672 |  | $ | 3,782 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 3,672 |  | $ | 3,782 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:75]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:76]
The Company's results from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

- removed (2023-11-03):
[0001375365-23-000028:note_history:77]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 6 |  | $ | 12 |  | $ | 30,699 |  | $ | 22,932 |  | $ | 23,611 |  | $ | 97,262 |  | $ | — |  | $ | — |  | $ | 54,316 |  | $ | 120,206 |  |
| Purchases - inventory | $ | 128,198 |  | $ | 147,780 |  | $ | 154,812 |  | $ | 126,039 |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,074 |  | $ | 283,010 |  | $ | 279,893 |  |
| Purchases - other miscellaneous items | $ | 9,855 |  | $ | 6,671 |  | $ | 1,078 |  | $ | 1,090 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 10,933 |  | $ | 7,761 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:78]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2023-11-03):
[0001375365-23-000028:note_history:79]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 293 |  | $ | (182) |  | $ | 6,074 |  | $ | (25,224) |  | $ | — |  | $ | — |  | $ | 6,367 |  | $ | (25,405) |  |
| Changes in other receivable | $ | 627 |  | $ | 3,159 |  | $ | (9,200) |  | $ | (8,933) |  | $ | — |  | $ | — |  | $ | — |  | $ | 48 |  | $ | (8,573) |  | $ | (5,726) |  |
| Changes in accounts payable | $ | (14,094) |  | $ | 814 |  | $ | 2,852 |  | $ | 16,356 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (11,242) |  | $ | 17,170 |  |
| Changes in accrued liabilities | $ | (1,734) |  | $ | (2,060) |  | $ | 1,410 |  | $ | (153) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | (324) |  | $ | (3,213) |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  |
| Purchases of property, plant and equipment | $ | 6,129 |  | $ | 2,365 |  | $ | 196 |  | $ | 140 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,325 |  | $ | 2,505 |  |
| Unpaid property, plant and equipment | $ | 1,369 |  | $ | 681 |  | $ | 22 |  | $ | 48 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,391 |  | $ | 729 |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:80]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:81]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Server and storage systems | $ | 1,966,608 |  |  | $ | 1,713,056 |  |  |  |  |  |
| Subsystems and accessories | 153,064 |  |  | 139,074 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |
  (was, 2023-05-05, similarity 0.6908):
[0001375365-23-000028:note_history:81]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 1,163,723 |  |  | $ | 1,145,869 |  |  | $ | 4,537,710 |  |  | $ | 2,981,777 |  |
| Subsystems and accessories | 119,573 |  |  | 209,621 |  |  | 400,911 |  |  | 578,862 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:82]
The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):
  (was, 2023-05-05, similarity 0.9243):
[0001375365-23-000028:note_history:82]
The following is a summary for the three and nine months ended March 31, 2023 and 2022, of net sales by geographic region (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:83]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 1,619,514 |  |  | $ | 1,295,504 |  |  |  |  |  |
| Asia | 225,468 |  |  | 270,024 |  |  |  |  |  |
| Europe | 190,848 |  |  | 235,074 |  |  |  |  |  |
| Other | 83,842 |  |  | 51,528 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

- removed (2023-11-03):
[0001375365-23-000028:note_history:84]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 785,548 |  |  | $ | 762,418 |  |  | $ | 3,172,444 |  |  | $ | 1,961,573 |  |
| Asia | 214,363 |  |  | 309,972 |  |  | 815,098 |  |  | 857,165 |  |
| Europe | 228,531 |  |  | 205,444 |  |  | 776,138 |  |  | 600,589 |  |
| Other | 54,854 |  |  | 77,656 |  |  | 174,941 |  |  | 141,312 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0001375365-23-000041:note_history:85]
The Company disaggregates revenue by type of product and by the geographical market. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.
  (was, 2023-05-05, similarity 0.8577):
[0001375365-23-000028:note_history:85]
The Company disaggregates revenue by type of product and by the geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

- changed (2023-11-03):
[0001375365-23-000041:note_history:86]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Server and storage systems | $ | 1,966,608 |  |  | $ | 1,713,056 |  |  |  |  |  |
| Subsystems and accessories | 153,064 |  |  | 139,074 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |
  (was, 2023-05-05, similarity 0.6908):
[0001375365-23-000028:note_history:86]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 1,163,723 |  |  | $ | 1,145,869 |  |  | $ | 4,537,710 |  |  | $ | 2,981,777 |  |
| Subsystems and accessories | 119,573 |  |  | 209,621 |  |  | 400,911 |  |  | 578,862 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:87]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):
  (was, 2023-05-05, similarity 0.8946):
[0001375365-23-000028:note_history:87]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2023 and 2022, of net sales by geographic region (in thousands):

- added (2023-11-03):
[0001375365-23-000041:note_history:88]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 1,619,514 |  |  | $ | 1,295,504 |  |  |  |  |  |
| Asia | 225,468 |  |  | 270,024 |  |  |  |  |  |
| Europe | 190,848 |  |  | 235,074 |  |  |  |  |  |
| Other | 83,842 |  |  | 51,528 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

- changed (2023-11-03):
[0001375365-23-000041:note_history:89]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $43.7 million.
  (was, 2023-05-05, similarity 0.9462):
[0001375365-23-000028:note_history:89]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2023, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $25.2 million and $86.2 million, respectively.

- changed (2023-11-03):
[0001375365-23-000041:note_history:90]
Deferred revenue increased $36.1 million as of September 30, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $21.1 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.
  (was, 2023-05-05, similarity 0.6606):
[0001375365-23-000028:note_history:90]
Deferred revenue increased $76.1 million as of March 31, 2023 as compared to the fiscal year ended June 30, 2022 was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $2.4 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

- changed (2023-11-03):
[0001375365-23-000041:note_history:91]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2023 was approximately $340.5 million. The Company expects to recognize approximately 49% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2023-05-05, similarity 0.9851):
[0001375365-23-000028:note_history:91]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2023 was $309.9 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2023-11-03):
[0001375365-23-000028:note_history:92]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 785,548 |  |  | $ | 762,418 |  |  | $ | 3,172,444 |  |  | $ | 1,961,573 |  |
| Asia | 214,363 |  |  | 309,972 |  |  | 815,098 |  |  | 857,165 |  |
| Europe | 228,531 |  |  | 205,444 |  |  | 776,138 |  |  | 600,589 |  |
| Other | 54,854 |  |  | 77,656 |  |  | 174,941 |  |  | 141,312 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |
