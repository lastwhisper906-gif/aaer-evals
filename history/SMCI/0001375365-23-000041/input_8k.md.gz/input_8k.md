# SMCI 8-K — 0001375365-23-000040 filed 2023-11-01

## item codes, every 8-K on or before 2023-11-03

- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2023-11-03

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-23-000040:8k_2_02:1]
EX-99.1
2
exhibit991_20230930.htm
EX-99.1

[0001375365-23-000040:8k_2_02:2]
Document

[0001375365-23-000040:8k_2_02:3]
Exhibit 99.1

[0001375365-23-000040:8k_2_02:4]
Supermicro Announces First Quarter Fiscal Year 2024 Financial Results

[0001375365-23-000040:8k_2_02:5]
SAN JOSE, Calif. -- November 1, 2023 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a Total IT Solution Manufacturer for AI, Cloud, Storage and 5G/Edge, today announced financial results for its first quarter of fiscal year 2024 ended September 30, 2023.

[0001375365-23-000040:8k_2_02:6]
First Quarter Fiscal Year 2024 Highlights

[0001375365-23-000040:8k_2_02:7]
•Net sales of $2.12 billion versus $2.18 billion in the fourth quarter of fiscal year 2023 and $1.85 billion in the same quarter of last year.

[0001375365-23-000040:8k_2_02:8]
•Gross margin of 16.7% versus 17.0% in the fourth quarter of fiscal year 2023 and 18.8% in the same quarter of last year.

[0001375365-23-000040:8k_2_02:9]
•Net income of $157 million versus $194 million in the fourth quarter of fiscal year 2023 and $184 million in the same quarter of last year.

[0001375365-23-000040:8k_2_02:10]
•Diluted net income per common share of $2.75 versus $3.43 in the fourth quarter of fiscal year 2023 and $3.35 in the same quarter of last year.

[0001375365-23-000040:8k_2_02:11]
•Non-GAAP diluted net income per common share of $3.43 versus $3.51 in the fourth quarter of fiscal year 2023 and $3.42 in the same quarter of last year.

[0001375365-23-000040:8k_2_02:12]
•Cash flow provided by operations for the first quarter of fiscal year 2024 of $271 million and capital expenditures of $3 million.

[0001375365-23-000040:8k_2_02:13]
Non-GAAP gross margin for the first quarter of fiscal year 2024 was 17.0% which adds back stock-based compensation expenses of $6 million. Non-GAAP diluted net income per common share for the first quarter of fiscal year 2024 was $3.43, with adjustments for stock-based compensation expenses of $41 million, net of the related tax effects of $16 million.

[0001375365-23-000040:8k_2_02:14]
As of September 30, 2023, total cash and cash equivalents was $543 million and total bank debt was $146 million.

[0001375365-23-000040:8k_2_02:15]
“I am pleased to announce that we are off to a good start to fiscal 2024, achieving first quarter revenue of $2.12B,” said Charles Liang, President and CEO of Supermicro. “Our teams executed with passion and precision despite the ongoing GPU supply constraints. We are working diligently to meet these challenges and given my confidence in my team and the strong demand we are seeing for AI infrastructure and compelling new and upcoming compute and storage products we are now raising our fiscal year 2024 outlook to $10B - $11B in revenue.”

[0001375365-23-000040:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-23-000040:8k_2_02:17]
For the second quarter of fiscal year 2024 ending December 31, 2023, the Company expects net sales of $2.7 billion to $2.9 billion, GAAP net income per diluted share of $3.75 to $4.24 and non-GAAP net income per diluted share of $4.40 to $4.88. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 15.7% and 17.1%, respectively, and a fully diluted share count of 57.6 million shares for GAAP and fully diluted share count of 58.3 million shares for non-GAAP. The outlook for second quarter of fiscal year 2024 GAAP net income per diluted share includes approximately $40 million in expected stock-based compensation, net of related tax effects of $13 million that are excluded from non-GAAP net income per diluted share.

[0001375365-23-000040:8k_2_02:18]
For fiscal year 2024 ending June 30, 2024, the Company maintains its guidance for net sales from a range of $10 billion to $11 billion.

[0001375365-23-000040:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-23-000040:8k_2_02:20]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its first quarter of fiscal year 2024.

[0001375365-23-000040:8k_2_02:21]
Those wishing to access the live webcast may use the following link:

[0001375365-23-000040:8k_2_02:22]
https://events.q4inc.com/attendee/484918945

[0001375365-23-000040:8k_2_02:23]
The conference call can be accessed by registering online at:

[0001375365-23-000040:8k_2_02:24]
https://conferencingportals.com/event/dteAMPMM

[0001375365-23-000040:8k_2_02:25]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-23-000040:8k_2_02:26]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-23-000040:8k_2_02:27]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-23-000040:8k_2_02:28]
Use of Non-GAAP Financial Measures

[0001375365-23-000040:8k_2_02:29]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of GAAP gross margin to non-GAAP gross margin and from GAAP diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-23-000040:8k_2_02:30]
About Super Micro Computer, Inc.

[0001375365-23-000040:8k_2_02:31]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI, and 5G/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro’s motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-23-000040:8k_2_02:32]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-23-000040:8k_2_02:33]
Investor Relations Contact

[0001375365-23-000040:8k_2_02:34]
Nicole Noutsios

[0001375365-23-000040:8k_2_02:35]
email: ir@supermicro.com

[0001375365-23-000040:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000040:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-23-000040:8k_2_02:38]
(in thousands)

[0001375365-23-000040:8k_2_02:39]
(unaudited)

[0001375365-23-000040:8k_2_02:40]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 543,156 |  |  | $ | 440,459 |  |
| Accounts receivable, net of allowance for credit losses | 845,729 |  |  | 1,148,259 |  |
| Inventories | 2,052,805 |  |  | 1,445,564 |  |
| Prepaid expenses and other current assets | 129,144 |  |  | 145,144 |  |
| Total current assets | 3,570,834 |  |  | 3,179,426 |  |
| Property, plant and equipment, net | 291,669 |  |  | 290,240 |  |
| Deferred income taxes, net | 185,675 |  |  | 162,654 |  |
| Other assets | 47,786 |  |  | 42,409 |  |
| Total assets | $ | 4,095,964 |  |  | $ | 3,674,729 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,084,058 |  |  | $ | 776,831 |  |
| Accrued liabilities | 152,500 |  |  | 163,865 |  |
| Income taxes payable | 161,395 |  |  | 129,166 |  |
| Short-term debt | 40,843 |  |  | 170,123 |  |
| Deferred revenue | 166,025 |  |  | 134,667 |  |
| Total current liabilities | 1,604,821 |  |  | 1,374,652 |  |
| Deferred revenue, non-current | 174,478 |  |  | 169,781 |  |
| Long-term debt | 105,389 |  |  | 120,179 |  |
| Other long-term liabilities | 45,737 |  |  | 37,947 |  |
| Total liabilities | 1,930,425 |  |  | 1,702,559 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 574,718 |  |  | 538,352 |  |
| Accumulated other comprehensive income | 651 |  |  | 639 |  |
| Retained earnings | 1,590,009 |  |  | 1,433,014 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 2,165,378 |  |  | 1,972,005 |  |
| Noncontrolling interest | 161 |  |  | 165 |  |
| Total stockholders’ equity | 2,165,539 |  |  | 1,972,170 |  |
| Total liabilities and stockholders’ equity | $ | 4,095,964 |  |  | $ | 3,674,729 |  |

[0001375365-23-000040:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000040:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-23-000040:8k_2_02:43]
(in thousands, except per share amounts)

[0001375365-23-000040:8k_2_02:44]
(unaudited)

[0001375365-23-000040:8k_2_02:45]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net sales | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |
| Cost of sales | 1,765,981 |  |  | 1,504,595 |  |  |  |  |  |
| Gross profit | 353,691 |  |  | 347,535 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 111,027 |  |  | 74,243 |  |  |  |  |  |
| Sales and marketing | 37,230 |  |  | 29,363 |  |  |  |  |  |
| General and administrative | 32,924 |  |  | 23,806 |  |  |  |  |  |
| Total operating expenses | 181,181 |  |  | 127,412 |  |  |  |  |  |
| Income from operations | 172,510 |  |  | 220,123 |  |  |  |  |  |
| Other income, net | 6,613 |  |  | 8,054 |  |  |  |  |  |
| Interest expense | (1,863) |  |  | (3,938) |  |  |  |  |  |
| Income before income tax provision | 177,260 |  |  | 224,239 |  |  |  |  |  |
| Income tax provision | (20,215) |  |  | (38,934) |  |  |  |  |  |
| Share of loss from equity investee, net of taxes | (50) |  |  | (889) |  |  |  |  |  |
| Net income | $ | 156,995 |  |  | $ | 184,416 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 2.96 |  |  | $ | 3.51 |  |  |  |  |  |
| Diluted | $ | 2.75 |  |  | $ | 3.35 |  |  |  |  |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 53,093 |  |  | 52,598 |  |  |  |  |  |
| Diluted | 57,185 |  |  | 55,017 |  |  |  |  |  |

[0001375365-23-000040:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-23-000040:8k_2_02:47]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Cost of sales | $ | 5,904 |  |  | $ | 884 |  |  |  |  |  |
| Research and development | 35,710 |  |  | 6,118 |  |  |  |  |  |
| Sales and marketing | 5,665 |  |  | 809 |  |  |  |  |  |
| General and administrative | 10,100 |  |  | 3,203 |  |  |  |  |  |
| Stock-based compensation expense | $ | 57,379 |  |  | $ | 11,014 |  |  |  |  |  |

[0001375365-23-000040:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000040:8k_2_02:49]
SELECTED CASH FLOW INFORMATION

[0001375365-23-000040:8k_2_02:50]
(in thousands)

[0001375365-23-000040:8k_2_02:51]
(unaudited)

[0001375365-23-000040:8k_2_02:52]
|  | Three Months EndedSeptember 30, |
|  | 2023 |  | 2022 |
| Net cash provided by operating activities | $ | 270,465 |  |  | $ | 313,587 |  |
| Net cash used in investing activities | (7,631) |  |  | (10,746) |  |
| Net cash used in financing activities | (159,941) |  |  | (331,183) |  |
| Effect of exchange rate fluctuations on cash | (203) |  |  | (1,472) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 102,690 |  |  | (29,813) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 440,960 |  |  | 268,559 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 543,650 |  |  | $ | 238,746 |  |

[0001375365-23-000040:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000040:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000040:8k_2_02:55]
(in thousands, except per share amounts)

[0001375365-23-000040:8k_2_02:56]
(unaudited)

[0001375365-23-000040:8k_2_02:57]
|  | Three Months Ended |
|  | September 30, 2023 |  | June 30, 2023 |  | September 30, 2022 |
| GAAP GROSS PROFIT | $ | 353,691 |  |  | $ | 371,696 |  |  | $ | 347,535 |  |
| Stock-based compensation | 5,904 |  |  | 989 |  |  | 884 |  |
| NON-GAAP GROSS PROFIT | $ | 359,595 |  |  | $ | 372,685 |  |  | $ | 348,419 |  |
| GAAP GROSS MARGIN | 16.7 | % |  | 17.0 | % |  | 18.8 | % |
| Stock-based compensation | 0.3 | % |  | 0.1 | % |  | 0.0 | % |
| NON-GAAP GROSS MARGIN | 17.0 | % |  | 17.1 | % |  | 18.8 | % |
| GAAP OPERATING EXPENSE | $ | 181,181 |  |  | $ | 144,941 |  |  | $ | 127,412 |  |
| Stock-based compensation | (51,475) |  |  | (11,797) |  |  | (10,130) |  |
| NON-GAAP OPERATING EXPENSE | $ | 129,706 |  |  | $ | 133,144 |  |  | $ | 117,282 |  |
| GAAP INCOME FROM OPERATIONS | $ | 172,510 |  |  | $ | 226,755 |  |  | $ | 220,123 |  |
| Stock-based compensation | 57,379 |  |  | 12,786 |  |  | 11,014 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 229,889 |  |  | $ | 239,541 |  |  | $ | 231,137 |  |
| GAAP OPERATING MARGIN | 8.1 | % |  | 10.4 | % |  | 11.9 | % |
| Stock-based compensation | 2.7 | % |  | 0.6 | % |  | 0.6 | % |
| NON-GAAP OPERATING MARGIN | 10.8 | % |  | 11.0 | % |  | 12.5 | % |
| GAAP TAX EXPENSE | $ | 20,215 |  |  | $ | 31,302 |  |  | $ | 38,934 |  |
| Adjustments to tax provision | 16,049 |  |  | 5,304 |  |  | 3,230 |  |
| NON-GAAP TAX EXPENSE | $ | 36,264 |  |  | $ | 36,606 |  |  | $ | 42,164 |  |
| GAAP NET INCOME | $ | 156,995 |  |  | $ | 193,569 |  |  | $ | 184,416 |  |
| Stock-based compensation | 57,379 |  |  | 12,786 |  |  | 11,014 |  |
| Adjustments to tax provision | (16,049) |  |  | (5,304) |  |  | (3,230) |  |
| NON-GAAP NET INCOME | $ | 198,325 |  |  | $ | 201,051 |  |  | $ | 192,200 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 2.96 |  |  | $ | 3.67 |  |  | $ | 3.51 |  |
| Impact of Non-GAAP adjustments | 0.78 |  |  | 0.15 |  |  | 0.14 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.74 |  |  | $ | 3.82 |  |  | $ | 3.65 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 2.75 |  |  | $ | 3.43 |  |  | $ | 3.35 |  |
| Impact of Non-GAAP adjustments | 0.68 |  |  | 0.08 |  |  | 0.07 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.43 |  |  | $ | 3.51 |  |  | $ | 3.42 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |
| BASIC – GAAP | 53,093 |  |  | 52,679 |  |  | 52,598 |  |
| BASIC – NON-GAAP | 53,093 |  |  | 52,679 |  |  | 52,598 |  |

[0001375365-23-000040:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000040:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000040:8k_2_02:60]
(in thousands, except per share amounts)

[0001375365-23-000040:8k_2_02:61]
(unaudited)

[0001375365-23-000040:8k_2_02:62]
|  | Three Months Ended |
|  | September 30, 2023 |  | June 30, 2023 |  | September 30, 2022 |
| DILUTED – GAAP | 57,185 |  |  | 56,505 |  |  | 55,017 |  |
| DILUTED – NON-GAAP | 57,846 |  |  | 57,222 |  |  | 56,271 |  |
