# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001375365-23-000041:item_4_controls:1]
Item 4.    Controls and Procedures

[0001375365-23-000041:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001375365-23-000041:item_4_controls:3]
Under the supervision, and with the participation, of our management, including our Chief Executive Officer ("CEO") and Chief Financial Officer ("CFO"), we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of September 30, 2023. Based on this evaluation, our CEO and CFO have concluded that our disclosure controls and procedures were effective at a reasonable assurance level as of September 30, 2023.

[0001375365-23-000041:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001375365-23-000041:item_4_controls:5]
Under applicable SEC rules (Exchange Act Rules 13a-15(d) and 15d-15(d)), management is required to evaluate, with the participation of our CEO and CFO, any changes in internal control over financial reporting that occurred during each fiscal quarter that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. There were no changes in our internal control over financial reporting during the quarter ended September 30, 2023, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-23-000041:item_4_controls:6]
Inherent Limitations on Effectiveness of Controls

[0001375365-23-000041:item_4_controls:7]
The effectiveness of any system of internal control over financial reporting is subject to inherent limitations, including the exercise of judgment in designing, implementing, operating, and evaluating the controls and procedures, and the inability to eliminate misconduct completely. Accordingly, any system of internal control over financial reporting can only provide reasonable, not absolute, assurances that its objectives will be met. In addition, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. We intend to continue to monitor and upgrade our internal controls as necessary or appropriate for our business, but we cannot assure that such improvements will be sufficient to provide us with effective internal control over financial reporting.

[0001375365-23-000041:item_4_controls:8]
SMCI | Q1 2024 Form 10-Q | 36
