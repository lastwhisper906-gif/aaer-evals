# SMCI notes — 0001375365-23-000041


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-23-000041:notes:1]
[same as prior period, unchanged from 0001375365-23-000028:notes:1]

[0001375365-23-000041:notes:2]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Part II, Item 8, Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 28, 2023, for the year ended June 30, 2023. Management's estimates take into consideration, as applicable, general macroeconomic conditions, inflation, changes in interest rates and geopolitical events.

[0001375365-23-000041:notes:3]
[same as prior period, unchanged from 0001375365-23-000028:notes:3]

[0001375365-23-000041:notes:4]
[same as prior period, unchanged from 0001375365-23-000028:notes:4]

[0001375365-23-000041:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.

[0001375365-23-000041:notes:6]
Certain prior year amounts within cash from operating activities in the condensed consolidated statements of cash flows have been reclassified to conform to current year presentation. These changes in presentation do not affect previously reported results.

[0001375365-23-000041:notes:7]
[same as prior period, unchanged from 0001375365-23-000028:notes:6]

[0001375365-23-000041:notes:8]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 55.1% and 10.3% of total purchases for the three months ended September 30, 2023, and the same two suppliers accounted for 25.7% and 16.1% of total purchases for the three months ended September 30, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 55.1% of total purchases for the three months ended September 30, 2023 is as a result of the purchase of GPUs to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% of total cost of sales for both the three months ended September 30, 2023 and 2022.

[0001375365-23-000041:notes:9]
Concentration of Credit and Customer Risk

[0001375365-23-000041:notes:10]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash and accounts receivable.

[0001375365-23-000041:notes:11]
Three customers accounted for 15.7%, 14.5% and 10.3% of accounts receivable, net as of September 30, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.
One customer accounted for 25.0% of the net sales for the three months ended September 30, 2023. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-23-000041:notes:12]
[same as prior period, unchanged from 0001375365-23-000028:notes:16]

[0001375365-23-000041:notes:13]
The Company disaggregates revenue by type of product and by the geographical market. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

[0001375365-23-000041:notes:14]
[same as prior period, unchanged from 0001375365-23-000028:notes:18]

[0001375365-23-000041:notes:15]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Server and storage systems | $ | 1,966,608 |  |  | $ | 1,713,056 |  |  |  |  |  |
| Subsystems and accessories | 153,064 |  |  | 139,074 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

[0001375365-23-000041:notes:16]
[same as prior period, unchanged from 0001375365-23-000028:notes:20]

[0001375365-23-000041:notes:17]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):

[0001375365-23-000041:notes:18]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 1,619,514 |  |  | $ | 1,295,504 |  |  |  |  |  |
| Asia | 225,468 |  |  | 270,024 |  |  |  |  |  |
| Europe | 190,848 |  |  | 235,074 |  |  |  |  |  |
| Other | 83,842 |  |  | 51,528 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

[0001375365-23-000041:notes:19]
[same as prior period, unchanged from 0001375365-23-000028:notes:23]

[0001375365-23-000041:notes:20]
[same as prior period, unchanged from 0001375365-23-000028:notes:24]

[0001375365-23-000041:notes:21]
[same as prior period, unchanged from 0001375365-23-000028:notes:25]

[0001375365-23-000041:notes:22]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $43.7 million.

[0001375365-23-000041:notes:23]
Deferred revenue increased $36.1 million as of September 30, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $21.1 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-23-000041:notes:24]
[same as prior period, unchanged from 0001375365-23-000028:notes:28]

[0001375365-23-000041:notes:25]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2023 was approximately $340.5 million. The Company expects to recognize approximately 49% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-23-000041:notes:26]
[same as prior period, unchanged from 0001375365-23-000028:notes:30]

[0001375365-23-000041:notes:27]
[same as prior period, unchanged from 0001375365-23-000028:notes:31]

[0001375365-23-000041:notes:28]
[same as prior period, unchanged from 0001375365-23-000028:notes:32]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-23-000041:notes:29]
The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-23-000041:notes:30]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2023 and 2022 (in thousands, except per share amounts):

[0001375365-23-000041:notes:31]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 156,995 |  |  | $ | 184,416 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 53,093 |  |  | 52,598 |  |  |  |  |  |
| Effect of dilutive securities | 4,092 |  |  | 2,419 |  |  |  |  |  |
| Weighted-average diluted shares | 57,185 |  |  | 55,017 |  |  |  |  |  |
| Basic net income per common share | $ | 2.96 |  |  | $ | 3.51 |  |  |  |  |  |
| Diluted net income per common share | $ | 2.75 |  |  | $ | 3.35 |  |  |  |  |  |

[0001375365-23-000041:notes:32]
For the three months ended September 30, 2023 and 2022, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 337,730 and 307,395 for the three months ended September 30, 2023 and 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-23-000041:notes:33]
[same as prior period, unchanged from 0001375365-23-000028:notes:37]

[0001375365-23-000041:notes:34]
[same as prior period, unchanged from 0001375365-23-000028:notes:44]

[0001375365-23-000041:notes:35]
|  | September 30, 2023 |  | June 30, 2023 |
| Cash and cash equivalents | $ | 543,156 |  |  | $ | 440,459 |  |
| Restricted cash included in other assets | 494 |  |  | 501 |  |
| Total cash, cash equivalents and restricted cash | $ | 543,650 |  |  | $ | 440,960 |  |

[0001375365-23-000041:notes:36]
[same as prior period, unchanged from 0001375365-23-000028:notes:38]

[0001375365-23-000041:notes:37]
|  | September 30, 2023 |  | June 30, 2023 |
| Finished goods | $ | 1,364,995 |  |  | $ | 1,045,177 |  |
| Work in process | 333,689 |  |  | 71,874 |  |
| Purchased parts and raw materials | 354,121 |  |  | 328,513 |  |
| Total inventories | $ | 2,052,805 |  |  | $ | 1,445,564 |  |

[0001375365-23-000041:notes:38]
[same as prior period, unchanged from 0001375365-23-000028:notes:46]

[0001375365-23-000041:notes:39]
|  | September 30, 2023 |  | June 30, 2023 |
| Buildings | $ | 143,496 |  |  | $ | 143,496 |  |
| Machinery and equipment | 133,600 |  |  | 130,151 |  |
| Land | 87,217 |  |  | 86,642 |  |
| Building and leasehold improvements | 59,984 |  |  | 59,634 |  |
| Furniture and fixtures | 38,345 |  |  | 36,303 |  |
| Software | 23,680 |  |  | 23,098 |  |
| Building construction in progress | 303 |  |  | 303 |  |
|  | 486,625 |  |  | 479,627 |  |
| Accumulated depreciation and amortization | (194,956) |  |  | (189,387) |  |
| Property, plant and equipment, net | $ | 291,669 |  |  | $ | 290,240 |  |

[0001375365-23-000041:notes:40]
[same as prior period, unchanged from 0001375365-23-000028:notes:50]

[0001375365-23-000041:notes:41]
|  | September 30, 2023 |  | June 30, 2023 |
| Accrued payroll and related expenses | $ | 38,658 |  |  | $ | 53,439 |  |
| Contract manufacturers liabilities | 23,741 |  |  | 23,634 |  |
| Customer deposits | 19,722 |  |  | 16,577 |  |
| Accrued cooperative marketing expenses | 10,764 |  |  | 9,744 |  |
| Accrued warranty costs | 9,107 |  |  | 9,079 |  |
| Operating lease liability | 8,473 |  |  | 7,292 |  |
| Accrued professional fees | 813 |  |  | 2,363 |  |
| Other | 41,222 |  |  | 41,737 |  |
| Total accrued liabilities | $ | 152,500 |  |  | $ | 163,865 |  |

[0001375365-23-000041:notes:42]
[same as prior period, unchanged from 0001375365-23-000028:notes:58]

[0001375365-23-000041:notes:43]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Balance, beginning of the period | $ | 14,859 |  |  | $ | 12,136 |  |  |  |  |  |
| Provision for warranty | 12,529 |  |  | 8,617 |  |  |  |  |  |
| Costs utilized | (11,804) |  |  | (8,473) |  |  |  |  |  |
| Change in estimated liability for pre-existing warranties | 45 |  |  | 423 |  |  |  |  |  |
| Balance, end of the period | 15,629 |  |  | 12,703 |  |  |  |  |  |
| Current portion | 9,107 |  |  | 8,540 |  |  |  |  |  |
| Non-current portion | $ | 6,522 |  |  | $ | 4,163 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-23-000041:notes:44]
Fair Value DisclosureThe financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2023 and June 30, 2023. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-23-000041:notes:45]
[same as prior period, unchanged from 0001375365-23-000028:notes:61]

[0001375365-23-000041:notes:46]
The following table sets forth the Company’s financial instruments as of September 30, 2023 and June 30, 2023, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-23-000041:notes:47]
| September 30, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 21,075 |  |  | $ | — |  |  | $ | — |  |  | $ | 21,075 |  |
| Certificates of deposit (2) | — |  |  | 126,951 |  |  | — |  |  | 126,951 |  |
| Investment in marketable securities | 3,866 |  |  | — |  |  | — |  |  | 3,866 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 24,941 |  |  | $ | 126,951 |  |  | $ | 1,843 |  |  | $ | 153,735 |  |
| June 30, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,823 |  |
| Certificates of deposit (2) | — |  |  | 462 |  |  | — |  |  | 462 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 20,823 |  |  | $ | 462 |  |  | $ | 1,843 |  |  | $ | 23,128 |  |

[0001375365-23-000041:notes:48]
(1) $20.9 million and $20.6 million in money market funds are included cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2023 and June 30, 2023, respectively.

[0001375365-23-000041:notes:49]
(2) $126.7 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.1 million and $0.1 million in certificates of deposit are included in prepaid expenses and other assets, and $0.2 million and $0.2 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2023 and June 30, 2023, respectively.

[0001375365-23-000041:notes:50]
The carrying amounts reported in the condensed consolidated balance sheets for cash and cash equivalents, accounts receivable, other assets, accounts payable and accrued liabilities approximate their fair values. The investment in marketable securities is carried at fair value using values available on a public exchange and is based on a Level 1 input. The investment is accounted for as an equity security, with unrealized gains and losses included in earnings. Unrealized loss of $1.1 million has been recorded in Other income, net in the condensed consolidated statement of operations for the three months ended September 30, 2023.

[0001375365-23-000041:notes:51]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For  the three  months ended September 30, 2023,  the credit losses related to the Company’s investments were not material.

[0001375365-23-000041:notes:52]
There was immaterial movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three months ended September 30, 2023 and 2022.

[0001375365-23-000041:notes:53]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three months ended September 30, 2023 and 2022.

[0001375365-23-000041:notes:54]
The following is a summary of the Company’s investment in an auction rate security as of September 30, 2023 and June 30, 2023 (in thousands):

[0001375365-23-000041:notes:55]
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | 287 |  |  | $ | (194) |  |  | $ | 1,843 |  |

[0001375365-23-000041:notes:56]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three months ended September 30, 2023 and 2022.

[0001375365-23-000041:notes:57]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2023 and June 30, 2023, total debt of $146.2 million and $290.3 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-23-000041:notes:58]
[same as prior period, unchanged from 0001375365-23-000028:notes:73]

[0001375365-23-000041:notes:59]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $0.1 million and $1.7 million as of September 30, 2023 and June 30, 2023, respectively. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three months ended September 30, 2023, the Company performed a qualitative assessment and identified impairment indicators. The Company recorded a $1.6 million impairment during the three months ended September 30, 2023 in Other income, net on the condensed consolidated statement of operations. The Company did not have any impairment to the carrying values of the non-marketable equity securities during the three months ended September 30, 2022.


## us-gaap:DebtDisclosureTextBlock

[0001375365-23-000041:notes:60]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands):

[0001375365-23-000041:notes:61]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2021 CTBC Credit Lines | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | — |  |  | — |  |
| Total line of credit | — |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 23,892 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,424 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 4,183 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 29,756 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,782 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,195 |  |  | 38,668 |  |
| Total term loans | 146,232 |  |  | 158,719 |  |
| Total debt | 146,232 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 40,843 |  |  | 170,123 |  |
| Debt, non-current | $ | 105,389 |  |  | $ | 120,179 |  |

[0001375365-23-000041:notes:62]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-23-000041:notes:63]
Available borrowings and interest rates as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

[0001375365-23-000041:notes:64]
|  | September 30, 2023 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.80% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.50% |  | $ | 417 |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  | — |  | $ | 105,000 |  | 3.33% |
| 2023 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.51% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | 50,000 |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 20,000 |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | — |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.75% |  | $ | 7,734 |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.40% - 1.60% |

[0001375365-23-000041:notes:65]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 7. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023 for a more complete description of the Company's credit facilities.

[0001375365-23-000041:notes:66]
The Company entered into a new General Credit Agreement with CTBC Bank during the three months ended  September 30, 2023 with the following terms:

[0001375365-23-000041:notes:67]
CTBC Bank

[0001375365-23-000041:notes:68]
2023 CTBC Bank Credit Lines

[0001375365-23-000041:notes:69]
On September 28, 2023 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank, which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

[0001375365-23-000041:notes:70]
Interest rates under each of the individual New CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line are secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor for each of the individual New CTBC Credit Lines is one year. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of its Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the New CTBC Credit Lines. The New CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable upon the occurrence of an event of default.

[0001375365-23-000041:notes:71]
The Company's Taiwan subsidiary intends to use borrowings under the New CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices) and to finance additional improvements to the Company’s Bade Manufacturing Facility located in Taiwan.

[0001375365-23-000041:notes:72]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-23-000041:notes:73]
Fiscal Year                                                                                                                                                                                              Principal Payments

[0001375365-23-000041:notes:74]
| Remainder of 2024 |  | $ | 30,632 |  |
| 2025 |  | 40,843 |  |
| 2026 |  | 40,843 |  |
| 2027 |  | 17,744 |  |
| 2028 |  | 5,985 |  |
| 2029 and thereafter |  | 10,185 |  |
| Total short-term and long-term debt |  | $ | 146,232 |  |

[0001375365-23-000041:notes:75]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-23-000041:notes:76]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2023 and 2022 were as follows (in thousands):

[0001375365-23-000041:notes:77]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Operating lease expense (including expense for lease agreements with related parties of $139 and $143 for the three months ended September 30, 2023 and 2022, respectively) | $ | 2,184 |  |  | $ | 2,110 |  |  |  |  |  |
| Cash payments for operating leases (including payments to related parties of $128 and $130 for the three months ended September 30, 2023 and 2022, respectively) | $ | 2,083 |  |  | $ | 2,038 |  |  |  |  |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 9,177 |  |  | $ | 750 |  |  |  |  |  |

[0001375365-23-000041:notes:78]
During the three months ended September 30, 2023 and 2022, the Company’s costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three months ended September 30, 2023 and 2022 were immaterial.

[0001375365-23-000041:notes:79]
As of September 30, 2023, the weighted average remaining lease term for operating leases was 3.5 years and the weighted average discount rate was 4.1%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of September 30, 2023 were as follows (in thousands):

[0001375365-23-000041:notes:80]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2024 |  | $ | 6,942 |  |
| 2025 |  | 9,248 |  |
| 2026 |  | 5,226 |  |
| 2027 |  | 3,737 |  |
| 2028 |  | 2,735 |  |
| 2029 and beyond |  | 364 |  |
| Total future lease payments |  | 28,252 |  |
| Less: Imputed interest |  | (2,183) |  |
| Present value of operating lease liabilities |  | $ | 26,069 |  |

[0001375365-23-000041:notes:81]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 8, “Related Party Transactions,” for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-23-000041:notes:82]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-23-000041:notes:83]
Dealings with Ablecom

[0001375365-23-000041:notes:84]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-23-000041:notes:85]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 85.5% and 88.4% of the chassis included in the products sold by the Company during the three months ended September 30, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-23-000041:notes:86]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-23-000041:notes:87]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2023 were $49.5 million and $27.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-23-000041:notes:88]
Dealings with Compuware

[0001375365-23-000041:notes:89]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company’s products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company’s standard price for its purchases.

[0001375365-23-000041:notes:90]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-23-000041:notes:91]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-23-000041:notes:92]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-23-000041:notes:93]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2023 were $138.2 million and $38.8 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-23-000041:notes:94]
Dealings with Investment in a Corporate Venture

[0001375365-23-000041:notes:95]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-23-000041:notes:96]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of September 30, 2023 and June 30, 2023.

[0001375365-23-000041:notes:97]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2023. No impairment charge was recorded for the three months ended September 30, 2023 or 2022.

[0001375365-23-000041:notes:98]
The Company sold products worth $0.8 million and $11.3 million to the Corporate Venture during the three months ended September 30, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.2 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of September 30, 2023 and June 30, 2023, respectively.

[0001375365-23-000041:notes:99]
The Company had the following balances related to transactions with its related parties as of September 30, 2023 and June 30, 2023 (in thousands):

[0001375365-23-000041:notes:100]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 |  |  | September 30, 2023 | June 30, 2023 |
| Accounts receivable | $ | 4 |  | $ | 2 |  | $ | 1,092 |  | $ | 3,528 |  | $ | 239 |  | $ | 1,943 |  |  |  | $ | 1,335 |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,283 |  | $ | 2,841 |  | $ | 22,622 |  | $ | 24,891 |  | $ | — |  | $ | — |  |  |  | $ | 24,905 |  | $ | 27,732 |  |
| Accounts payable | $ | 44,476 |  | $ | 35,711 |  | $ | 47,639 |  | $ | 53,423 |  | $ | — |  | $ | — |  |  |  | $ | 92,115 |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 485 |  | $ | 1,230 |  | $ | 16,019 |  | $ | 12,787 |  | $ | — |  | $ | — |  |  |  | $ | 16,504 |  | $ | 14,017 |  |

[0001375365-23-000041:notes:101]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-23-000041:notes:102]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

[0001375365-23-000041:notes:103]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 16,606 |  | $ | 13,760 |  | $ | 788 |  | $ | 11,293 |  |  |  | $ | 17,396 |  | $ | 25,055 |  |
| Purchases - inventory | $ | 46,614 |  | $ | 47,847 |  | $ | 66,493 |  | $ | 48,689 |  | $ | — |  | $ | — |  |  |  | 113,107 |  | 96,536 |  |
| Purchases - other miscellaneous items | $ | 4,759 |  | $ | 4,763 |  | $ | 417 |  | $ | 258 |  | $ | — |  | $ | — |  |  |  | $ | 5,176 |  | $ | 5,021 |  |

[0001375365-23-000041:notes:104]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

[0001375365-23-000041:notes:105]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Changes in accounts receivable | $ | (2) |  | $ | — |  | $ | 2,436 |  | $ | (478) |  | $ | 1,704 |  | $ | (1,373) |  |  |  | $ | 4,138 |  | $ | (1,851) |  |
| Changes in other receivable | $ | 558 |  | $ | 1,276 |  | $ | 2,269 |  | $ | (11,415) |  | $ | — |  | $ | — |  |  |  | $ | 2,827 |  | $ | (10,139) |  |
| Changes in accounts payable | $ | 8,765 |  | $ | 664 |  | $ | (5,784) |  | $ | 6,010 |  | $ | — |  | $ | — |  |  |  | $ | 2,981 |  | $ | 6,674 |  |
| Changes in accrued liabilities | $ | (745) |  | $ | (1,532) |  | $ | 3,232 |  | $ | 11,117 |  | $ | — |  | $ | — |  |  |  | $ | 2,487 |  | $ | 9,585 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (80) |  | $ | (105) |  | $ | — |  | $ | — |  |  |  | $ | (80) |  | $ | (105) |  |
| Purchases of property, plant and equipment | $ | 782 |  | $ | 583 |  | $ | 44 |  | $ | 146 |  | $ | — |  | $ | — |  |  |  | $ | 826 |  | $ | 729 |  |
| Unpaid property, plant and equipment | $ | 3,672 |  | $ | 3,782 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 3,672 |  | $ | 3,782 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-23-000041:notes:106]
Stock-based Compensation and Stockholders’ Equity
Equity Incentive Plan

[0001375365-23-000041:notes:107]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan (as amended and restated, the “2020 Plan”) which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-23-000041:notes:108]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company’s outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-23-000041:notes:109]
As of September 30, 2023, the Company had 1,324,299 authorized shares available for future issuance under the 2020 Plan.

[0001375365-23-000041:notes:110]
[same as prior period, unchanged from 0001375365-23-000028:notes:139]

[0001375365-23-000041:notes:111]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company’s Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. Under the common stock repurchase program, shares may be purchased from time to time in open market transactions, block trades, through plans established under the Securities Exchange Act Rule 10b5-1, or otherwise. The number of shares purchased and the timing of such purchases are based on working capital requirements, market and general business conditions, and other factors, including alternative investment opportunities.

[0001375365-23-000041:notes:112]
No shares were repurchased under the share repurchase program during the three months ended September 30, 2023. As of September 30, 2023, $50.0 million was available for additional repurchases of common stock.

[0001375365-23-000041:notes:113]
[same as prior period, unchanged from 0001375365-23-000028:notes:142]

[0001375365-23-000041:notes:114]
The Company’s fair value of RSUs and PRSUs is based on the closing market price of the Company’s common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-23-000041:notes:115]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company’s historical experience.

[0001375365-23-000041:notes:116]
Expected Volatility—Expected volatility is based on the Company’s implied and historical volatility.

[0001375365-23-000041:notes:117]
[same as prior period, unchanged from 0001375365-23-000028:notes:146]

[0001375365-23-000041:notes:118]
[same as prior period, unchanged from 0001375365-23-000028:notes:147]

[0001375365-23-000041:notes:119]
The fair value of stock option grants for the three months ended September 30, 2023 and 2022 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-23-000041:notes:120]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Risk-free interest rate | 4.15% - 4.32% |  | 2.81% - 4.06% |  |  |  |  |
| Expected term | 3.00 years - 5.99 years |  | 6.07 years |  |  |  |  |
| Dividend yield | —% |  | —% |  |  |  |  |
| Volatility | 56.87% - 58.27% |  | 50.62% - 51.30% |  |  |  |  |
| Weighted-average fair value | $188.29 |  | $28.67 |  |  |  |  |

[0001375365-23-000041:notes:121]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2023 and 2022 (in thousands):

[0001375365-23-000041:notes:122]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Cost of sales | $ | 5,904 |  |  | $ | 884 |  |  |  |  |  |
| Research and development | 35,710 |  |  | 6,118 |  |  |  |  |  |
| Sales and marketing | 5,665 |  |  | 809 |  |  |  |  |  |
| General and administrative | 10,100 |  |  | 3,203 |  |  |  |  |  |
| Stock-based compensation expense before taxes | 57,379 |  |  | 11,014 |  |  |  |  |  |
| Income tax impact | (16,049) |  |  | (1,339) |  |  |  |  |  |
| Stock-based compensation expense, net | $ | 41,330 |  |  | $ | 9,675 |  |  |  |  |  |

[0001375365-23-000041:notes:123]
As of September 30, 2023, $65.4 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.65 years and $203.1 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.67 years. Additionally, as described below, $0.5 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 0.5 years.

[0001375365-23-000041:notes:124]
[same as prior period, unchanged from 0001375365-23-000028:notes:153]

[0001375365-23-000041:notes:125]
[same as prior period, unchanged from 0001375365-23-000028:notes:154]

[0001375365-23-000041:notes:126]
The achievement status of the operational and stock price milestones as of September 30, 2023 was as follows:

[0001375365-23-000041:notes:127]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Achieved |  | $75 |  | Achieved (3) |  |  |
| $6.8 |  | Achieved |  | $95 |  | Achieved (4) |  |  |
| $8.0 |  | Probable |  | $120 |  | Achieved (5) |  |  |

[0001375365-23-000041:notes:128]
(1)The vesting of the first tranche of 200,000 option shares under the 2021 CEO Performance Stock Option, representing one-fifth of such award, was certified by the Company’s Compensation Committee in August 2022.

[0001375365-23-000041:notes:129]
(2)The vesting of the second tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in October 2022.

[0001375365-23-000041:notes:130]
(3)The vesting of the third tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in January 2023.

[0001375365-23-000041:notes:131]
(4)The vesting of the fourth tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in September 2023.

[0001375365-23-000041:notes:132]
(5)On June 19, 2023, the Compensation Committee certified achievement of the $120 stock price milestone based upon the 60 trading day average stock price from March 6, 2023 through May 30, 2023.

[0001375365-23-000041:notes:133]
[same as prior period, unchanged from 0001375365-23-000028:notes:161]

[0001375365-23-000041:notes:134]
During the three months ended September 30, 2023 and 2022, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.2 million and $1.3 million, respectively. As of September 30, 2023 and June 30, 2023, the Company had $0.5 million and $0.7 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of September 30, 2023 is expected to be recognized over a period of 0.5 years.

[0001375365-23-000041:notes:135]
The following table summarizes stock option activity during the three months ended September 30, 2023 under all plans:

[0001375365-23-000041:notes:136]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2023 |  | 3,302,533 |  |  | $ | 40.47 |  |  |  |  |  |
| Granted |  | 246,612 |  |  | $ | 330.42 |  |  |  |  |  |
| Exercised |  | (188,957) |  |  | $ | 23.87 |  |  |  |  |  |
| Forfeited/Cancelled |  | (4,041) |  |  | $ | 50.83 |  |  |  |  |  |
| Balance as of September 30, 2023 |  | 3,356,147 |  |  | $ | 62.71 |  |  | 6.66 |  |  |
| Options vested and exercisable at September 30, 2023 |  | 2,092,330 |  |  | $ | 34.42 |  |  | 5.47 |  |  |

[0001375365-23-000041:notes:137]
[same as prior period, unchanged from 0001375365-23-000028:notes:165]

[0001375365-23-000041:notes:138]
The following table summarizes RSU and PRSU activity during the three months ended September 30, 2023 under all plans:

[0001375365-23-000041:notes:139]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2023 | 2,042,986 |  |  | $ | 55.94 |  |  |  |  |  |  |
| Granted | 464,468 |  |  | $ | 334.93 |  |  |  |  |  |  |
| Released | (297,656) |  |  | $ | 262.41 |  |  |  |  |  |  |
| Forfeited | (31,724) |  |  | $ | 91.38 |  |  |  |  |  |  |
| Balance as of September 30, 2023 | 2,178,074 |  |  | $ | 104.49 |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-23-000041:notes:140]
Income Taxes
The Company recorded a provision for income taxes of $20.2 million and $38.9 million for the three months ended September 30, 2023 and 2022, respectively. The effective tax rate was 11.4% and 17.4% for the three months ended September 30, 2023 and 2022, respectively. The effective tax rate for the three months ended September 30, 2023 is lower than that for the three months ended September 30, 2022, primarily due to an increase in the tax deduction for stock compensation in the three months ended September 30, 2023.

[0001375365-23-000041:notes:141]
The Tax Cuts and Jobs Act of 2017 eliminated the option to deduct research and development (“R&D”) expenses in the year incurred and instead requires taxpayers to capitalize R&D expenses, including software development cost, and subsequently amortize such expenses over five years for R&D activities conducted in the United States and over fifteen years for R&D activities conducted outside of the United States beginning in the Company's fiscal year 2023. Although Congress has considered legislation that would defer, modify, and repeal the capitalization and amortization requirement, there is no assurance the provision will be deferred, repealed, or otherwise modified.

[0001375365-23-000041:notes:142]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-23-000041:notes:143]
In general, the federal statute of limitations remains open for tax years ended June 30, 2020 through 2023. Various states’ statutes of limitations remain open in general for tax years ended June 30, 2019 through 2023. Certain statutes of limitations in major foreign jurisdictions remain open for the tax years ended June 30, 2018 through 2023. It is reasonably possible that the Company’s gross unrecognized tax benefits will decrease by approximately $3.2 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact the Company’s effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-23-000041:notes:144]
Commitments and Contingencies
Legal proceedings and indemnifications

[0001375365-23-000041:notes:145]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2023 and any prior periods.

[0001375365-23-000041:notes:146]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-23-000041:notes:147]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-23-000041:notes:148]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2023, these remaining noncancelable commitments were $1.4 billion, including $66.4 million for related parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-23-000041:notes:149]
Segment ReportingThe Company operates in one operating segment that develops and provides high-performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-23-000041:notes:150]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Long-lived assets: |  |  |  |
| United States | $ | 183,685 |  |  | $ | 183,485 |  |
| Asia | 105,405 |  |  | 104,094 |  |
| Europe | 2,579 |  |  | 2,661 |  |
|  | $ | 291,669 |  |  | $ | 290,240 |  |

[0001375365-23-000041:notes:151]
[same as prior period, unchanged from 0001375365-23-000028:notes:182]


## ecd:MtrlTermsOfTrdArrTextBlock

[0001375365-23-000041:notes:152]
Certain of the Company’s directors have entered into trading plans pursuant to Rule 10b5-1(c) of the Securities Exchange Act of 1934, as amended. The following table summarizes the adoption of trading plans intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) during the three months ended September 30, 2023:

[0001375365-23-000041:notes:153]
| Name and Title | Adoption Date | End Date | Aggregate Number of Shares of the Company’s Common Stock to be Sold |
| Daniel Fairfax, non-employee director | August 30, 2023 | June 28, 2024 | 2,100 |
