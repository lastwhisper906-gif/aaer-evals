# SMCI MD&A — 0001375365-23-000041


## mdna

[0001375365-23-000041:mdna:1]
[same as prior period, unchanged from 0001375365-23-000028:mdna:1]

[0001375365-23-000041:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023 (the “2023 10-K”), which includes our condensed consolidated financial statements for the fiscal years ended June 30, 2023 and 2022.

[0001375365-23-000041:mdna:3]
[same as prior period, unchanged from 0001375365-23-000028:mdna:3]

[0001375365-23-000041:mdna:4]
We are a Silicon Valley-based provider of accelerated compute platforms that are comprised of application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence (“AI”), 5G and edge computing. Our Total IT Solutions include complete servers, storage systems, modular blade servers, blades, workstations, full rack scale solutions, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-23-000041:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. In order to increase our sales and profits, we believe that we must continue to develop customized and application optimized server and storage solutions and be among the first to market with new features and products. We continue to expand our software, customer service and support offerings, as we increasingly focus on larger enterprise customers. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor, GPU and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors, accelerators and storage technologies, and as a result, we monitor the product introduction cycles of Intel Corporation, NVIDIA Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-23-000041:mdna:6]
[same as prior period, unchanged from 0001375365-23-000028:mdna:7]

[0001375365-23-000041:mdna:7]
The following is a summary of our financial highlights of the first quarter of fiscal year 2024:

[0001375365-23-000041:mdna:8]
•Net sales increased by 14.4% in the three months ended September 30, 2023 as compared to the three months ended September 30, 2022.

[0001375365-23-000041:mdna:9]
•Gross margin decreased to 16.7% in the three months ended September 30, 2023 from 18.8% in the three months ended September 30, 2022.

[0001375365-23-000041:mdna:10]
•Operating expenses increased by 42.2% as compared to the three months ended September 30, 2022 and were equal to 8.5% and 6.9% of net sales in the three months ended September 30, 2023 and 2022, respectively.

[0001375365-23-000041:mdna:11]
•Effective tax rate decreased to 11.4% in the three months ended September 30, 2023 from 17.4% in the three months ended September 30, 2022.

[0001375365-23-000041:mdna:12]
SMCI | Q1 2024 Form 10-Q | 27

[0001375365-23-000041:mdna:13]
[same as prior period, unchanged from 0001375365-23-000028:mdna:13]

[0001375365-23-000041:mdna:14]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses.  We evaluate our estimates on an on-going basis based on a) historical experience, and b) assumptions we believe to be reasonable under the circumstances and are not readily apparent from other sources, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Because these estimates can vary depending on the situation, actual results may differ from these estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-23-000041:mdna:15]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2023 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Summary of Significant Accounting Policies" in our notes to condensed consolidated financial statements in this Quarterly Report.

[0001375365-23-000041:mdna:16]
[same as prior period, unchanged from 0001375365-23-000028:mdna:17]

[0001375365-23-000041:mdna:17]
[same as prior period, unchanged from 0001375365-23-000028:mdna:18]

[0001375365-23-000041:mdna:18]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 83.3 | % |  | 81.2 | % |  |  |  |  |
| Gross profit | 16.7 | % |  | 18.8 | % |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.2 | % |  | 4.0 | % |  |  |  |  |
| Sales and marketing | 1.7 | % |  | 1.6 | % |  |  |  |  |
| General and administrative | 1.6 | % |  | 1.3 | % |  |  |  |  |
| Total operating expenses | 8.5 | % |  | 6.9 | % |  |  |  |  |
| Income from operations | 8.2 | % |  | 11.9 | % |  |  |  |  |
| Other income, net | 0.3 | % |  | 0.4 | % |  |  |  |  |
| Interest expense | (0.1) | % |  | (0.2) | % |  |  |  |  |
| Income before income tax provision | 8.4 | % |  | 12.1 | % |  |  |  |  |
| Income tax provision | (1.0) | % |  | (2.1) | % |  |  |  |  |
| Share of loss from equity investee, net of taxes | — | % |  | — | % |  |  |  |  |
| Net income | 7.4 | % |  | 10.0 | % |  |  |  |  |

[0001375365-23-000041:mdna:19]
[same as prior period, unchanged from 0001375365-23-000028:mdna:20]

[0001375365-23-000041:mdna:20]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The prices for our server and storage systems range widely depending upon the configuration, as well as the level of integration of key components such as CPUs, GPUs, SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-23-000041:mdna:21]
As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPUs, GPUs, SSDs and memory.

[0001375365-23-000041:mdna:22]
SMCI | Q1 2024 Form 10-Q | 28

[0001375365-23-000041:mdna:23]
The following table presents net sales by product type for the three months ended September 30, 2023 and 2022 (dollars in millions):

[0001375365-23-000041:mdna:24]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,966.6 |  |  | $ | 1,713.1 |  |  | $ | 253.5 |  |  | 14.8 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 92.8 | % |  | 92.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | $ | 153.1 |  |  | $ | 139.0 |  |  | $ | 14.1 |  |  | 10.1 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 7.2 | % |  | 7.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 2,119.7 |  |  | $ | 1,852.1 |  |  | $ | 267.6 |  |  | 14.4 | % |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:25]
[same as prior period, unchanged from 0001375365-23-000028:mdna:26]

[0001375365-23-000041:mdna:26]
The period-over-period increase in net sales of our server and storage systems was primarily due to the strong demand from customers for GPU, high performance computing (“HPC"), and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling price ("ASP").

[0001375365-23-000041:mdna:27]
The period-over-period increase in net sales for our subsystems and accessories of 10.1% is primarily due to increased demand of accessories sold to data center customers as more accessories and spares were purchased in conjunction with the strong sales of full systems and servers.

[0001375365-23-000041:mdna:28]
The following table presents net sales by geographic region for the three months ended September 30, 2023 and 2022 (dollars in millions):

[0001375365-23-000041:mdna:29]
|  | Three Months Ended September 30, |  | Change |  | Change |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| United States | $ | 1,619.5 |  |  | $ | 1,295.5 |  |  | $ | 324.0 |  |  | 25.0 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 76.4 | % |  | 69.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 225.5 |  |  | $ | 270.0 |  |  | $ | (44.5) |  |  | (16.5) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 10.6 | % |  | 14.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe | $ | 190.9 |  |  | $ | 235.1 |  |  | $ | (44.2) |  |  | (18.8) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 9.0 | % |  | 12.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | $ | 83.8 |  |  | $ | 51.5 |  |  | $ | 32.3 |  |  | 62.7 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 4.0 | % |  | 2.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 2,119.7 |  |  | $ | 1,852.1 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:30]
The period-over-period increase in overall net sales is the result of higher ASP's, especially to large enterprise and data center customers. United States sales experienced significant growth due to increased demand from data center customers for GPU, HPC, and rack-scale solutions. The period-over-period decrease in Asia and Europe is mainly due to macro economic concerns and slower adoption of new product introductions, which has persisted in the three months ended September 30, 2023.

[0001375365-23-000041:mdna:31]
One customer accounted for 25.0% of the net sales for the three months ended September 30, 2023. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022. We had no customers with net sales over 10% for the year ended June 30, 2023, however, we expect to continue to have customers exceed 10% of net sales in future quarters.

[0001375365-23-000041:mdna:32]
SMCI | Q1 2024 Form 10-Q | 29

[0001375365-23-000041:mdna:33]
[same as prior period, unchanged from 0001375365-23-000028:mdna:40]

[0001375365-23-000041:mdna:34]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges. The primary factors that impact our cost of sales are the mix of products sold, changes in the cost of components, changes in logistic costs, changes in salary and benefits and overhead costs related to production as well as economies of scale gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in our costs are not matched by corresponding changes in our ASP's. Our cost of sales as a percentage of net sales is also impacted by the timing and extent to which we add to, and are able to efficiently utilize, our manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions.

[0001375365-23-000041:mdna:35]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing generally performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of certain components, particularly power supplies.

[0001375365-23-000041:mdna:36]
Cost of sales and gross margin for the three months ended September 30, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000041:mdna:37]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Cost of sales | $ | 1,766.0 |  |  | $ | 1,504.6 |  |  | $ | 261.4 |  |  | 17.4 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 353.7 |  |  | $ | 347.5 |  |  | $ | 6.2 |  |  | 1.8 | % |  |  |  |  |  |  |  |  |
| Gross margin | 16.7 | % |  | 18.8 | % |  |  |  | (2.1) | % |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:38]
The period-over-period increase in cost of sales was primarily attributed to an increase of $279.4 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, partially offset by a $11.0 million decrease in freight costs due to an improved supply chain, a $5.3 million decrease in inventory reserve charges and a $1.7 million decrease in overhead costs due to greater absorption of overhead in the ending inventory.

[0001375365-23-000041:mdna:39]
Certain materials used by us in the manufacturing of our products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. The increase in concentration of total purchases from one of our suppliers to 55.1% of total purchases for the three months ended September 30, 2023 is as a result of the increase in the number of purchases of GPUs from such supplier to build our solutions for our customers. We expect that this concentration in total purchases from this supplier will continue in the future.

[0001375365-23-000041:mdna:40]
The period-over-period decrease in the gross margin percentage was primarily due to product and customer mix, partially offset by an increase in capitalization of manufacturing overhead resulting from higher inventory level and mix, lower costs related to freight due to an improved supply chain, and inventory reserve charges.

[0001375365-23-000041:mdna:41]
[same as prior period, unchanged from 0001375365-23-000028:mdna:52]

[0001375365-23-000041:mdna:42]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These reimbursed costs offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-23-000041:mdna:43]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses for our sales and marketing personnel, cost for trade shows, independent sales

[0001375365-23-000041:mdna:44]
SMCI | Q1 2024 Form 10-Q | 30

[0001375365-23-000041:mdna:45]
representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These reimbursed costs offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-23-000041:mdna:46]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-23-000041:mdna:47]
Operating expenses for the three months ended September 30, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000041:mdna:48]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Research and development | $ | 111.0 |  |  | $ | 74.2 |  |  | $ | 36.8 |  |  | 49.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 5.2 | % |  | 4.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 37.2 |  |  | $ | 29.4 |  |  | $ | 7.8 |  |  | 26.5 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.7 | % |  | 1.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 32.9 |  |  | $ | 23.8 |  |  | $ | 9.1 |  |  | 38.2 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.6 | % |  | 1.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 181.1 |  |  | $ | 127.4 |  |  | $ | 53.7 |  |  | 42.2 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 8.5 | % |  | 6.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:49]
Research and development expenses. The period-over-period increase in research and development expenses was primarily driven by a $39.1 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards as we expanded our workforce and invested in key talent, and a $0.9 million increase in product development costs to support the development of next generation products and technologies, offset by a $3.2 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-23-000041:mdna:50]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily driven by a $9.1 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards offset by a $1.3 million decrease primarily due to an increase in marketing development funds to drive new sales opportunities for our products and customer support. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-23-000041:mdna:51]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to a $8.5 million increase in compensation expenses associated with higher headcount and the cost of equity awards and a $0.6 million increase in professional and service fees. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-23-000041:mdna:52]
Interest Expense and Other Income, Net

[0001375365-23-000041:mdna:53]
Other income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-23-000041:mdna:54]
[same as prior period, unchanged from 0001375365-23-000028:mdna:69]

[0001375365-23-000041:mdna:55]
SMCI | Q1 2024 Form 10-Q | 31

[0001375365-23-000041:mdna:56]
Interest expense and other income, net for the three months ended September 30, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000041:mdna:57]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income, net | $ | 6.6 |  |  | $ | 8.1 |  |  | $ | (1.5) |  |  | (18.5) | % |  |  |  |  |  |  |  |  |
| Interest expense | (1.9) |  |  | (3.9) |  |  | 2.0 |  |  | (51.3) | % |  |  |  |  |  |  |  |  |
| Interest expense and other income, net | $ | 4.7 |  |  | $ | 4.2 |  |  | $ | 0.5 |  |  | 11.9 | % |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:58]
The change of $0.5 million in interest expense and other income, net was primarily attributable to a $1.5 million decrease in other income driven by $2.7 million investment impairment and unrealized losses, offset by $1.2 million interest income and favorable foreign exchange gain. The decrease in interest expense of $2.0 million was due to a decrease in outstanding loan balances.

[0001375365-23-000041:mdna:59]
[same as prior period, unchanged from 0001375365-23-000028:mdna:77]

[0001375365-23-000041:mdna:60]
[same as prior period, unchanged from 0001375365-23-000028:mdna:78]

[0001375365-23-000041:mdna:61]
Provision for income taxes and effective tax rates for the three months ended September 30, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000041:mdna:62]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income tax provision | $ | 20.2 |  |  | $ | 38.9 |  |  | $ | (18.7) |  |  | (48.1) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.0 | % |  | 2.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective tax rate | 11.4 | % |  | 17.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:63]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended September 30, 2023, is lower than that for the three months ended September 30, 2022, primarily due to a significant increase in tax-deductible stock compensation expense in the three months ended September 30, 2023.

[0001375365-23-000041:mdna:64]
Share of Loss from Equity Investee, Net of Taxes

[0001375365-23-000041:mdna:65]
Share of loss from equity investee, net of taxes represents our share of loss from the Corporate Venture in which we have 30% ownership.

[0001375365-23-000041:mdna:66]
Share of loss from equity investee, net of taxes for the three months ended September 30, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000041:mdna:67]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Share of loss from equity investee, net of taxes | $ | — |  |  | $ | (0.9) |  |  | $ | 0.9 |  |  | n/m (1) |  |  |  |  |  |  |  |  |
| Percentage of total net sales | — | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-23-000041:mdna:68]
[same as prior period, unchanged from 0001375365-23-000028:mdna:90]

[0001375365-23-000041:mdna:69]
SMCI | Q1 2024 Form 10-Q | 32

[0001375365-23-000041:mdna:70]
The period-over-period decrease of $0.9 million in share of loss from equity investee, net of taxes was primarily due to a smaller net loss recognized by the Corporate Venture.

[0001375365-23-000041:mdna:71]
[same as prior period, unchanged from 0001375365-23-000028:mdna:95]

[0001375365-23-000041:mdna:72]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities. Our recent drivers of liquidity changes have included an increase in the need for working capital due to higher levels of inventory required by growing revenues and to a lesser extent, longer supply chain lead times on certain key components. Our cash and cash equivalents were $543.2 million and $440.5 million as of September 30, 2023 and June 30, 2023, respectively. Our cash and cash equivalents in foreign locations was $263.2 million and $192.3 million as of September 30, 2023 and June 30, 2023, respectively.

[0001375365-23-000041:mdna:73]
[same as prior period, unchanged from 0001375365-23-000028:mdna:97]

[0001375365-23-000041:mdna:74]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the filing of this Quarterly Report on Form 10-Q. On September 28, 2023, our company through our Taiwan subsidiary, entered into a new agreement pursuant to which our Taiwan subsidiary and CTBC Bank agreed to aggregate borrowings under all the New CTBC Credit Lines of up to $105.0 million. We continue to evaluate financing options that may be required to support the growth of our business, if it occurs more rapidly than anticipated.

[0001375365-23-000041:mdna:75]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first.  We repurchased 1,553,350 shares of common stock for $150 million during the fiscal year ended June 30, 2023 under this program and have $50.0 million of remaining availability as of September 30, 2023.

[0001375365-23-000041:mdna:76]
[same as prior period, unchanged from 0001375365-23-000028:mdna:101]

[0001375365-23-000041:mdna:77]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net cash provided by operating activities | $ | 270.5 |  |  | $ | 313.6 |  |  | $ | (43.1) |  |  |  |  |
| Net cash used in investing activities | $ | (7.6) |  |  | $ | (10.7) |  |  | $ | 3.1 |  |  |  |  |
| Net cash used in financing activities | $ | (159.9) |  |  | $ | (331.2) |  |  | $ | 171.3 |  |  |  |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 102.7 |  |  | $ | (29.8) |  |  | $ | 132.5 |  |  |  |  |

[0001375365-23-000041:mdna:78]
[same as prior period, unchanged from 0001375365-23-000028:mdna:103]

[0001375365-23-000041:mdna:79]
Net cash provided by operating activities decreased by $43.1 million for the three months ended September 30, 2023 as compared to the three months ended September 30, 2022. The decrease was primarily due to higher cash used to purchase inventory by $416.8 million, a decrease in net income of $27.4 million, offset by an increase of $207.4 million from the collection of accounts receivables, an increase of $145.4 million from other working capital items, an increase of $46.4 million in stock based compensation expense and an increase of $1.9 million in various other non-cash items.

[0001375365-23-000041:mdna:80]
[same as prior period, unchanged from 0001375365-23-000028:mdna:105]

[0001375365-23-000041:mdna:81]
Net cash used in investing activities decreased by $3.1 million for the three months ended September 30, 2023 as compared to the three months ended September 30, 2022 primarily due to a decrease of $8.1 million in purchases of property, plant and equipment offset by an investment of $5.0 million made in the three months ended September 30, 2023.

[0001375365-23-000041:mdna:82]
SMCI | Q1 2024 Form 10-Q | 33

[0001375365-23-000041:mdna:83]
[same as prior period, unchanged from 0001375365-23-000028:mdna:107]

[0001375365-23-000041:mdna:84]
Net cash used in financing activities was $171.3 million lower in the three months ended September 30, 2023 as compared to the three months ended September 30, 2022 primarily due to a lower repayment of borrowings of $196.7 million, offset by a higher withholding tax payment for equity compensation related activities of $25.4 million in the three months ended September 30, 2023.

[0001375365-23-000041:mdna:85]
[same as prior period, unchanged from 0001375365-23-000028:mdna:109]

[0001375365-23-000041:mdna:86]
[same as prior period, unchanged from 0001375365-23-000028:mdna:110]

[0001375365-23-000041:mdna:87]
[same as prior period, unchanged from 0001375365-23-000028:mdna:111]

[0001375365-23-000041:mdna:88]
We anticipate our capital expenditures for the remainder of fiscal year 2024 will be in range of $102.0 million to $112.0 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. During the second quarter of fiscal year 2023, we entered into a letter of understanding to acquire land in Malaysia to expand our manufacturing operations. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. We are obtaining early access to such land prior to the acquisition, and we anticipate additional capital expenditures for the remainder of fiscal year 2024 of $31.0 million (included in the above range) for such initiative. In addition, we will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-23-000041:mdna:89]
We intend to continue to focus our capital expenditures in fiscal year 2024 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our office facilities and our IT system infrastructure.

[0001375365-23-000041:mdna:90]
[same as prior period, unchanged from 0001375365-23-000028:mdna:115]

[0001375365-23-000041:mdna:91]
[same as prior period, unchanged from 0001375365-23-000028:mdna:116]

[0001375365-23-000041:mdna:92]
SMCI | Q1 2024 Form 10-Q | 34
