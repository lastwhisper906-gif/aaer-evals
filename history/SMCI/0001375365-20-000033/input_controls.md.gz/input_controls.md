# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001375365-20-000033:item_4_controls:1]
Item 4.    Controls and Procedures

[0001375365-20-000033:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001375365-20-000033:item_4_controls:3]
Under the supervision, and with the participation, of our current management, including our Chief Executive Officer ("CEO") and Chief Financial Officer ("CFO"), we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of March 31, 2020. Based on this evaluation of our disclosure controls and procedures, our CEO and CFO have concluded that our disclosure controls and procedures were not effective as of March 31, 2020 because of certain material weaknesses in our internal control over financial reporting, as further described below.

[0001375365-20-000033:item_4_controls:4]
Notwithstanding the conclusion by our CEO and CFO that our disclosure controls and procedures as of March 31, 2020 were not effective, and notwithstanding the material weaknesses in our internal control over financial reporting described below, management believes that the condensed consolidated financial statements and related financial information included in this Quarterly Report fairly present in all material respects our financial condition, results of operations and cash flows as of the dates presented, and for the periods ended on such dates, in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”).

[0001375365-20-000033:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0001375365-20-000033:item_4_controls:6]
Under applicable SEC rules (Exchange Act Rules 13a-15(d) and 15d-15(d)), management is required to evaluate, with the participation of our Chief Executive Officer and Chief Financial Officer, any changes in internal control over financial reporting that occurred during each fiscal quarter that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. Other than the remediation actions disclosed in Part II, Item 9A, "Controls and Procedures," of our 2019 Comprehensive 10-K, there were no changes in our internal control over financial reporting during the quarter ended March 31, 2020, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. As discussed in Part II, Item 9A, "Controls and Procedures," of our 2019 Comprehensive 10-K, we have undertaken a broad range of remedial procedures to address the material weaknesses in our internal control over financial reporting.

[0001375365-20-000033:item_4_controls:7]
Inherent Limitations on Effectiveness of Controls

[0001375365-20-000033:item_4_controls:8]
The effectiveness of any system of internal control over financial reporting is subject to inherent limitations, including the exercise of judgment in designing, implementing, operating, and evaluating the controls and procedures, and the inability to eliminate misconduct completely. Accordingly, any system of internal control over financial reporting can only provide reasonable, not absolute, assurances that its objectives will be met. In addition, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. We intend to continue to monitor and upgrade our internal controls as necessary or appropriate for our business, but we cannot assure that such improvements will be sufficient to provide us with effective internal control over financial reporting.

[0001375365-20-000033:item_4_controls:9]
46
