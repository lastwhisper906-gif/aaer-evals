# SMCI note change history — 0001375365-20-000011 → 0001375365-20-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:1]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.
  (was, 2020-02-07, similarity 0.8391):
[0001375365-20-000011:note_history:1]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant.  On July 26, 2019, the Company filed a motion to dismiss the complaint, which motion remains pending with the court.  The Company believes the allegations filed are without merit, and intends to vigorously defend against the lawsuit.

- added (2020-05-11):
[0001375365-20-000033:note_history:2]
SEC Matter— The Company has cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by the Company’s management, which irregularities were disclosed on August 31, 2015. In addition, the Company received subpoenas from the SEC in connection with the matters underlying its inability to timely file the Company's Form 10-K for the fiscal year ended June 30, 2017. The Company also received a subpoena from the SEC following the publication of a false and widely discredited news article in October 2018 concerning its products. The Company has cooperated fully to comply with these government requests. The Company has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Company will pay a penalty of $17.5 million. In addition, the Company’s Chief Executive Officer has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Chief Executive Officer will pay the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. As of March 31, 2020, the Company recorded a liability of $17.5 million for the Company’s potential SEC settlement included in general and administrative expenses and accrued liabilities in the condensed consolidated financial statements. The Chief Executive Officer’s potential payment of $2,122,000 to the Company is a contingent gain and will be recorded if and when it is realized. The Company and the Chief Executive Officer have not reached final resolutions of these matters with the SEC and the Company cannot predict when settlements, if finally agreed, would become final, nor whether any of the proposed terms may change in connection with final resolutions.

- added (2020-05-11):
[0001375365-20-000033:note_history:3]
Other legal proceedings and indemnifications

- changed (2020-05-11):
[0001375365-20-000033:note_history:4]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2020 and any prior periods.
  (was, 2020-02-07, similarity 0.7661):
[0001375365-20-000011:note_history:4]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

- changed (2020-05-11):
[0001375365-20-000033:note_history:5]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2020, these remaining noncancelable commitments were $381.1 million, including $122.2 million for related parties.
  (was, 2020-02-07, similarity 0.8497):
[0001375365-20-000011:note_history:5]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2019, these remaining noncancelable commitments were $579.2 million, including $134.0 million for related parties.

- added (2020-05-11):
[0001375365-20-000033:note_history:6]
Standby Letter of Credit— In October 2019, Bank of America increased the value of a previously issued standby letter of credit from $3.2 million to $6.4 million to facilitate ongoing operations of the Company. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.

- removed (2020-05-11):
[0001375365-20-000011:note_history:7]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:8]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations.
  (was, 2020-02-07, similarity 0.9081):
[0001375365-20-000011:note_history:8]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”) and include the accounts of Super Micro Computer and its consolidated subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations.

- changed (2020-05-11):
[0001375365-20-000033:note_history:9]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.
  (was, 2020-02-07, similarity 0.9546):
[0001375365-20-000011:note_history:9]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

- changed (2020-05-11):
[0001375365-20-000033:note_history:10]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, valuation and recognition of performance awards liability, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the coronavirus ("COVID-19") pandemic on our critical and significant accounting estimates, including assessment of collectibility of customer contracts, valuation of accounts receivable, provision for excess and obsolete inventory and impairment of long-lived assets. Collectibility of customer contracts assessment resulted in delaying revenue recognition of $3.4 million for certain orders shipped during the three months ended March 31, 2020.
  (was, 2020-02-07, similarity 0.7272):
[0001375365-20-000011:note_history:10]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates.

- changed (2020-05-11):
[0001375365-20-000033:note_history:11]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.
  (was, 2020-02-07, similarity 0.8067):
[0001375365-20-000011:note_history:11]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the

- added (2020-05-11):
[0001375365-20-000033:note_history:12]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns, with a corresponding decrease in revenue, and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs, with a corresponding decrease in cost of sales. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- added (2020-05-11):
[0001375365-20-000033:note_history:13]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product

- changed (2020-05-11):
[0001375365-20-000033:note_history:14]
will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.
  (was, 2020-02-07, similarity 0.7691):
[0001375365-20-000011:note_history:14]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,

- added (2020-05-11):
[0001375365-20-000033:note_history:15]
Research and Development

- added (2020-05-11):
[0001375365-20-000033:note_history:16]
Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $0.8 million and $2.0 million for the nine months ended March 31, 2020 and 2019, respectively. Such amounts recorded as a reduction of research and development expenses were not significant for the three months ended March 31, 2020 and 2019. During the three and nine months ended March 31, 2020, the Company also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

- added (2020-05-11):
[0001375365-20-000033:note_history:17]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of inventories based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

- added (2020-05-11):
[0001375365-20-000033:note_history:18]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock options and RSUs awards are recognized to expense on a straight-line basis over the requisite service period. PRSUs awards are recognized to expense using an accelerated method only when it is probable that any performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized as compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

- changed (2020-05-11):
[0001375365-20-000033:note_history:19]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.
  (was, 2020-02-07, similarity 0.9204):
[0001375365-20-000011:note_history:19]
The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

- changed (2020-05-11):
[0001375365-20-000033:note_history:20]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.
  (was, 2020-02-07, similarity 0.9784):
[0001375365-20-000011:note_history:20]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

- changed (2020-05-11):
[0001375365-20-000033:note_history:21]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.
  (was, 2020-02-07, similarity 0.8418):
[0001375365-20-000011:note_history:21]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

- changed (2020-05-11):
[0001375365-20-000033:note_history:22]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.
  (was, 2020-02-07, similarity 0.9955):
[0001375365-20-000011:note_history:22]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.

- changed (2020-05-11):
[0001375365-20-000033:note_history:23]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.
  (was, 2020-02-07, similarity 0.949):
[0001375365-20-000011:note_history:23]
Assets under finance leases are included in property, plant and equipment, net and current, and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

- changed (2020-05-11):
[0001375365-20-000033:note_history:24]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2020 and 2019, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.
  (was, 2020-02-07, similarity 0.6032):
[0001375365-20-000011:note_history:24]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and six months ended December 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- changed (2020-05-11):
[0001375365-20-000033:note_history:25]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by a third party in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2020 and June 30, 2019, the Company's equity investment in the Corporate Venture was $0 and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheets. The Company's share of losses, net of taxes, of the Corporate Venture were $1.1 million and $0.4 million for the three months ended March 31, 2020 and 2019, respectively, and $1.1 million and $3.6 million for the nine months ended March 31, 2020 and 2019, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations. The Company does not have an obligation or commitment to share in losses of the Corporate Venture above its investment amounts and will discontinue equity method accounting if the investment carrying value is below zero.
  (was, 2020-02-07, similarity 0.6411):
[0001375365-20-000011:note_history:25]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of December 31, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $1.1 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $1.0 million and $1.8 million for the three months ended December 31, 2019 and 2018, respectively, and $0.0 million and $3.2 million for the six months ended December 31, 2019 and 2018, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations.

- changed (2020-05-11):
[0001375365-20-000033:note_history:26]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of March 31, 2020 and June 30, 2019, the Company had unamortized deferred gain balance of $2.5 million and $2.0 million, respectively, in accrued liabilities and $1.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2020-02-07, similarity 0.9906):
[0001375365-20-000011:note_history:26]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of December 31, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.0 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2020-05-11):
[0001375365-20-000033:note_history:27]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2020 and 2019, respectively.
  (was, 2020-02-07, similarity 0.9268):
[0001375365-20-000011:note_history:27]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and six months ended December 31, 2019 and 2018, respectively.

- added (2020-05-11):
[0001375365-20-000033:note_history:28]
In addition, the Company sells products to the Corporate Venture. The Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of each period end is eliminated and recorded as a reduction of the Company's investment balance in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company sold products worth $14.0 million and $13.7 million to the Corporate Venture in the three months ended March 31, 2020 and 2019, respectively, and $51.5 million and $35.2 million in the nine months ended March 31, 2020 and 2019, respectively. As of March 31, 2020, the Company recorded $0.5 million related to unrealized intra-entity profits in accrued liabilities in the Company’s condensed consolidated balance sheet. The Company had $10.4 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2020 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- changed (2020-05-11):
[0001375365-20-000033:note_history:29]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. The COVID-19 pandemic has already and may further disrupt our supply chain. One supplier accounted for 26.1% and 20.1% of total purchases for the three months ended March 31, 2020 and 2019, respectively, and 27.9% and 21.2% for the nine months ended March 31, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 9.4% and 9.9% of total cost of sales for the three months ended March 31, 2020 and 2019, respectively, and 9.8% and 9.4% for the nine months ended March 31, 2020 and 2019, respectively.
  (was, 2020-02-07, similarity 0.7056):
[0001375365-20-000011:note_history:29]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.5% and 23.4% of total purchases for the three months ended December 31, 2019 and 2018, respectively, and 28.6% and 21.5% for the six months ended December 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 10.3% and 9.3% of total cost of sales for the three months ended December 31, 2019 and 2018, respectively, and 10.0% and 9.2% for the six months ended December 31, 2019 and 2018, respectively.

- changed (2020-05-11):
[0001375365-20-000033:note_history:30]
Financial instruments that potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2020 and 2019. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2020, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.
  (was, 2020-02-07, similarity 0.9118):
[0001375365-20-000011:note_history:30]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

- added (2020-05-11):
[0001375365-20-000033:note_history:31]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company has started its accounting assessment of the adoption of the new standard, the process of establishing new accounting policies and evaluation of changes to systems and internal controls necessary to support the requirements of the new standard. The Company will continue to update its assessment as more information becomes available. The Company cannot reasonably estimate quantitative information related to the impact of the new guidance on its consolidated financial statements at this time.

- changed (2020-05-11):
[0001375365-20-000033:note_history:32]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The adoption of the new guidance will simplify the disclosure of the fair value measurements for the Company's financial assets and liabilities.
  (was, 2020-02-07, similarity 0.7644):
[0001375365-20-000011:note_history:32]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

- changed (2020-05-11):
[0001375365-20-000033:note_history:33]
In August 2018, the FASB issued authoritative guidance , Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company will adopt the new guidance on a prospective basis for any new hosting arrangement entered into after July 1, 2020.
  (was, 2020-02-07, similarity 0.7901):
[0001375365-20-000011:note_history:33]
In August 2018, the FASB issued amended guidance to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- added (2020-05-11):
[0001375365-20-000033:note_history:34]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. The LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility terminates on June 30, 2020 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statement disclosures, results of operations and financial position.

- removed (2020-05-11):
[0001375365-20-000011:note_history:35]
distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2020-05-11):
[0001375365-20-000011:note_history:36]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-05-11):
[0001375365-20-000011:note_history:37]
changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

- removed (2020-05-11):
[0001375365-20-000011:note_history:38]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

- removed (2020-05-11):
[0001375365-20-000011:note_history:39]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options and restricted stock units ("RSUs"). The share-based awards granted to non-employees have not been material to date. The Company is required to estimate the fair value of share-based awards on the date of grant. The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. The fair value of RSUs with service conditions or performance conditions is based on the closing market price of the Company's common stock on the date of grant. The fair value for RSUs with service conditions, or time-based RSUs, is amortized on a straight-line basis over the requisite service period. The fair value for RSUs with performance conditions ("PRSUs") is recognized on a ratable basis over the requisite service period when it is probable the performance conditions of the awards will be met. The Company reassesses the probability of vesting at each reporting period and adjusts the total compensation expense of the award based on this probability assessment.

- removed (2020-05-11):
[0001375365-20-000011:note_history:40]
Additionally, the Company sold products worth $15.4 million and $12.1 million to the Corporate Venture in the three months ended December 31, 2019 and 2018, respectively, and $37.5 million and $21.5 million in the six months ended December 31, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.2 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- removed (2020-05-11):
[0001375365-20-000011:note_history:41]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:42]
Short-term debt obligations as of March 31, 2020 and June 30, 2019 consisted of the following (in thousands):
  (was, 2020-02-07, similarity 0.9552):
[0001375365-20-000011:note_history:42]
Short-term debt obligations as of December 31, 2019 and June 30, 2019 consisted of the following (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:43]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank | 10,000 |  |  | — |  |
| Total line of credit | 10,000 |  |  | 1,116 |  |
| CTBC Bank term loan | 23,158 |  |  | 22,531 |  |
| Total short-term debt | $ | 33,158 |  |  | $ | 23,647 |  |
  (was, 2020-02-07, similarity 0.763):
[0001375365-20-000011:note_history:43]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 23,250 |  |  | 22,531 |  |
| Total short-term debt | $ | 23,250 |  |  | $ | 23,647 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:44]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020. The Company is in the process of negotiating an extension of its credit facility with Bank of America and expects this process will be completed by the end of May, 2020.
  (was, 2020-02-07, similarity 0.8047):
[0001375365-20-000011:note_history:44]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

- changed (2020-05-11):
[0001375365-20-000033:note_history:45]
As of March 31, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2020 and June 30, 2019 were 3.63% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of March 31, 2020 and June 30, 2019. As of March 31, 2020, the Company's
  (was, 2020-02-07, similarity 0.8499):
[0001375365-20-000011:note_history:45]
As of December 31, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2019 and June 30, 2019 were 3.75% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of December 31, 2019 and June 30, 2019. As of December 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- added (2020-05-11):
[0001375365-20-000033:note_history:46]
available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2020-05-11):
[0001375365-20-000033:note_history:47]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (iii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.
  (was, 2020-02-07, similarity 0.9984):
[0001375365-20-000011:note_history:47]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

- added (2020-05-11):
[0001375365-20-000033:note_history:48]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.2 million and $22.5 million at March 31, 2020 and June 30, 2019, respectively. As of March 31, 2020, the total outstanding borrowings under the 2019 CTBC Credit Facility revolving line of credit were $10.0 million in U.S. dollars. At June 30, 2019, the Company did not have any outstanding balance under the 2019 CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.91% per annum as of March 31, 2020 and 0.93% per annum as of June 30, 2019. At March 31, 2020, the amount available for future borrowing under the 2019 CTBC Credit Facility was $16.8 million. As of March 31, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.5 million.

- added (2020-05-11):
[0001375365-20-000033:note_history:49]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended

- changed (2020-05-11):
[0001375365-20-000033:note_history:50]
June 30, 2017. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.
  (was, 2020-02-07, similarity 0.746):
[0001375365-20-000011:note_history:50]
2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

- removed (2020-05-11):
[0001375365-20-000011:note_history:51]
Activities under Revolving Lines of Credit and Term Loans

- removed (2020-05-11):
[0001375365-20-000011:note_history:52]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the then-existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

- removed (2020-05-11):
[0001375365-20-000011:note_history:53]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.3 million and $22.5 million at December 31, 2019 and June 30, 2019, respectively. The interest rate for these loans were 0.91% per annum as of December 31, 2019 and 0.93% per annum as of June 30, 2019. At December 31, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $26.7 million. As of December 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.6 million.

- removed (2020-05-11):
[0001375365-20-000011:note_history:54]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31,


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:55]
Short-term debt obligations as of March 31, 2020 and June 30, 2019 consisted of the following (in thousands):
  (was, 2020-02-07, similarity 0.9552):
[0001375365-20-000011:note_history:55]
Short-term debt obligations as of December 31, 2019 and June 30, 2019 consisted of the following (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:56]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank | 10,000 |  |  | — |  |
| Total line of credit | 10,000 |  |  | 1,116 |  |
| CTBC Bank term loan | 23,158 |  |  | 22,531 |  |
| Total short-term debt | $ | 33,158 |  |  | $ | 23,647 |  |
  (was, 2020-02-07, similarity 0.763):
[0001375365-20-000011:note_history:56]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 23,250 |  |  | 22,531 |  |
| Total short-term debt | $ | 23,250 |  |  | $ | 23,647 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:57]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2020, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.
  (was, 2020-02-07, similarity 0.9846):
[0001375365-20-000011:note_history:57]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of December 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of December 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

- changed (2020-05-11):
[0001375365-20-000033:note_history:58]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.1% and 96.0% of the chassis included in the products sold by the Company during the three months ended March 31, 2020 and 2019, respectively; and approximately 95.3% and 95.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2020-02-07, similarity 0.9687):
[0001375365-20-000011:note_history:58]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 97.5% and 94.8% of the chassis included in the products sold by the Company during the three months ended December 31, 2019 and 2018, respectively; and approximately 95.4% and 95.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2020-05-11):
[0001375365-20-000033:note_history:59]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the
  (was, 2020-02-07, similarity 0.8878):
[0001375365-20-000011:note_history:59]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the

- added (2020-05-11):
[0001375365-20-000033:note_history:60]
Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- changed (2020-05-11):
[0001375365-20-000033:note_history:61]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $60.0 million and $31.0 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2020-02-07, similarity 0.9936):
[0001375365-20-000011:note_history:61]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $49.4 million and $31.0 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2020-05-11):
[0001375365-20-000033:note_history:62]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $111.2 million and $70.6 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2020-02-07, similarity 0.9899):
[0001375365-20-000011:note_history:62]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $84.6 million and $70.6 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2020-05-11):
[0001375365-20-000033:note_history:63]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2020 and 2019, are as follows (in thousands):
  (was, 2020-02-07, similarity 0.9557):
[0001375365-20-000011:note_history:63]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2019 and 2018, are as follows (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:64]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 37,607 |  |  | $ | 29,372 |  |  | $ | 115,295 |  |  | $ | 110,290 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 7,503 |  |  | $ | 3,846 |  |  | $ | 19,456 |  |  | $ | 13,628 |  |
| Purchases (1) | 24,908 |  |  | 34,140 |  |  | 91,662 |  |  | 111,629 |  |
  (was, 2020-02-07, similarity 0.9289):
[0001375365-20-000011:note_history:64]
|  | Three months ended December 31, |  | Six months ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 44,568 |  |  | $ | 36,282 |  |  | $ | 77,688 |  |  | $ | 80,918 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 6,406 |  |  | $ | 4,640 |  |  | $ | 11,953 |  |  | $ | 9,782 |  |
| Purchases (1) | 33,438 |  |  | 40,277 |  |  | 66,754 |  |  | 77,489 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:65]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2020 and 2019.
  (was, 2020-02-07, similarity 0.9333):
[0001375365-20-000011:note_history:65]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2019 and 2018.

- changed (2020-05-11):
[0001375365-20-000033:note_history:66]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2020 and June 30, 2019 (in thousands):
  (was, 2020-02-07, similarity 0.9668):
[0001375365-20-000011:note_history:66]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2019 and June 30, 2019 (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:67]
|  | March 31, 2020 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 4,749 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 28,928 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 1,036 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 18,046 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 43,935 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 335 |  |  | — |  |
  (was, 2020-02-07, similarity 0.8189):
[0001375365-20-000011:note_history:67]
|  | December 31, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 10,747 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 44,913 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,105 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 16,747 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 44,788 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 325 |  |  | — |  |

- added (2020-05-11):
[0001375365-20-000033:note_history:68]
(1) Other receivables include receivables from vendors.

- added (2020-05-11):
[0001375365-20-000033:note_history:69]
See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.

- removed (2020-05-11):
[0001375365-20-000011:note_history:70]
components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- removed (2020-05-11):
[0001375365-20-000011:note_history:71]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and six months ended December 31, 2019 and 2018.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:72]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2020 and 2019, are as follows (in thousands):
  (was, 2020-02-07, similarity 0.9557):
[0001375365-20-000011:note_history:72]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2019 and 2018, are as follows (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:73]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 37,607 |  |  | $ | 29,372 |  |  | $ | 115,295 |  |  | $ | 110,290 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 7,503 |  |  | $ | 3,846 |  |  | $ | 19,456 |  |  | $ | 13,628 |  |
| Purchases (1) | 24,908 |  |  | 34,140 |  |  | 91,662 |  |  | 111,629 |  |
  (was, 2020-02-07, similarity 0.9289):
[0001375365-20-000011:note_history:73]
|  | Three months ended December 31, |  | Six months ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 44,568 |  |  | $ | 36,282 |  |  | $ | 77,688 |  |  | $ | 80,918 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 6,406 |  |  | $ | 4,640 |  |  | $ | 11,953 |  |  | $ | 9,782 |  |
| Purchases (1) | 33,438 |  |  | 40,277 |  |  | 66,754 |  |  | 77,489 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:74]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2020 and 2019.
  (was, 2020-02-07, similarity 0.9333):
[0001375365-20-000011:note_history:74]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2019 and 2018.

- changed (2020-05-11):
[0001375365-20-000033:note_history:75]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2020 and June 30, 2019 (in thousands):
  (was, 2020-02-07, similarity 0.9668):
[0001375365-20-000011:note_history:75]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2019 and June 30, 2019 (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:76]
|  | March 31, 2020 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 4,749 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 28,928 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 1,036 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 18,046 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 43,935 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 335 |  |  | — |  |
  (was, 2020-02-07, similarity 0.8189):
[0001375365-20-000011:note_history:76]
|  | December 31, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 10,747 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 44,913 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,105 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 16,747 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 44,788 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 325 |  |  | — |  |

- added (2020-05-11):
[0001375365-20-000033:note_history:77]
(1) Other receivables include receivables from vendors.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-05-11):
[0001375365-20-000033:note_history:78]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 571,291 |  |  | $ | 592,783 |  |  | $ | 1,880,043 |  |  | $ | 2,161,321 |  |
| Subsystems and accessories | 201,117 |  |  | 150,716 |  |  | 563,112 |  |  | 484,805 |  |
| Total | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:79]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.
  (was, 2020-02-07, similarity 0.7398):
[0001375365-20-000011:note_history:79]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

- changed (2020-05-11):
[0001375365-20-000033:note_history:80]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-02-07, similarity 0.8933):
[0001375365-20-000011:note_history:80]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2019 and 2018, of net sales by geographic region (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:81]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 422,872 |  |  | $ | 436,734 |  |  | $ | 1,419,117 |  |  | $ | 1,516,262 |  |
| Europe | 158,144 |  |  | 128,789 |  |  | 433,767 |  |  | 472,325 |  |
| Asia | 160,472 |  |  | 146,120 |  |  | 487,827 |  |  | 549,296 |  |
| Others | 30,920 |  |  | 31,856 |  |  | 102,444 |  |  | 108,243 |  |
|  | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |
  (was, 2020-02-07, similarity 0.937):
[0001375365-20-000011:note_history:81]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| United States | $ | 527,404 |  |  | $ | 511,913 |  |  | $ | 996,245 |  |  | $ | 1,079,528 |  |
| Europe | 147,564 |  |  | 180,976 |  |  | 275,623 |  |  | 343,536 |  |
| Asia | 165,716 |  |  | 196,308 |  |  | 327,355 |  |  | 403,176 |  |
| Others | 30,259 |  |  | 42,312 |  |  | 71,524 |  |  | 76,387 |  |
|  | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:82]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2020 and 2019 (in thousands):
  (was, 2020-02-07, similarity 0.816):
[0001375365-20-000011:note_history:82]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2019 and 2018:

- added (2020-05-11):
[0001375365-20-000033:note_history:83]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Indirect sales channel | $ | 445,980 |  |  | $ | 284,204 |  |  | $ | 1,292,472 |  |  | $ | 997,983 |  |
| Direct customers and OEMs | 326,428 |  |  | 459,295 |  |  | 1,150,683 |  |  | 1,648,143 |  |
| Total net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- removed (2020-05-11):
[0001375365-20-000011:note_history:84]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 672,727 |  |  | 77.2 | % |  | $ | 762,622 |  |  | 81.9 | % |  | $ | 1,308,753 |  |  | 78.3 | % |  | $ | 1,568,538 |  |  | 82.4 | % |
| Subsystems and accessories | 198,216 |  |  | 22.8 | % |  | 168,887 |  |  | 18.1 | % |  | 361,994 |  |  | 21.7 | % |  | 334,089 |  |  | 17.6 | % |
| Total | $ | 870,943 |  |  | 100.0 | % |  | $ | 931,509 |  |  | 100.0 | % |  | $ | 1,670,747 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |

- removed (2020-05-11):
[0001375365-20-000011:note_history:85]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

- removed (2020-05-11):
[0001375365-20-000011:note_history:86]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001375365-20-000033:note_history:87]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.
  (was, 2020-02-07, similarity 0.8067):
[0001375365-20-000011:note_history:87]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the

- added (2020-05-11):
[0001375365-20-000033:note_history:88]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns, with a corresponding decrease in revenue, and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs, with a corresponding decrease in cost of sales. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-05-11):
[0001375365-20-000011:note_history:89]
distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2020-05-11):
[0001375365-20-000011:note_history:90]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-05-11):
[0001375365-20-000033:note_history:91]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 571,291 |  |  | $ | 592,783 |  |  | $ | 1,880,043 |  |  | $ | 2,161,321 |  |
| Subsystems and accessories | 201,117 |  |  | 150,716 |  |  | 563,112 |  |  | 484,805 |  |
| Total | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:92]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.
  (was, 2020-02-07, similarity 0.7398):
[0001375365-20-000011:note_history:92]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

- changed (2020-05-11):
[0001375365-20-000033:note_history:93]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-02-07, similarity 0.8933):
[0001375365-20-000011:note_history:93]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2019 and 2018, of net sales by geographic region (in thousands):

- changed (2020-05-11):
[0001375365-20-000033:note_history:94]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 422,872 |  |  | $ | 436,734 |  |  | $ | 1,419,117 |  |  | $ | 1,516,262 |  |
| Europe | 158,144 |  |  | 128,789 |  |  | 433,767 |  |  | 472,325 |  |
| Asia | 160,472 |  |  | 146,120 |  |  | 487,827 |  |  | 549,296 |  |
| Others | 30,920 |  |  | 31,856 |  |  | 102,444 |  |  | 108,243 |  |
|  | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |
  (was, 2020-02-07, similarity 0.937):
[0001375365-20-000011:note_history:94]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| United States | $ | 527,404 |  |  | $ | 511,913 |  |  | $ | 996,245 |  |  | $ | 1,079,528 |  |
| Europe | 147,564 |  |  | 180,976 |  |  | 275,623 |  |  | 343,536 |  |
| Asia | 165,716 |  |  | 196,308 |  |  | 327,355 |  |  | 403,176 |  |
| Others | 30,259 |  |  | 42,312 |  |  | 71,524 |  |  | 76,387 |  |
|  | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |

- changed (2020-05-11):
[0001375365-20-000033:note_history:95]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2020 and 2019 (in thousands):
  (was, 2020-02-07, similarity 0.816):
[0001375365-20-000011:note_history:95]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2019 and 2018:

- added (2020-05-11):
[0001375365-20-000033:note_history:96]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Indirect sales channel | $ | 445,980 |  |  | $ | 284,204 |  |  | $ | 1,292,472 |  |  | $ | 997,983 |  |
| Direct customers and OEMs | 326,428 |  |  | 459,295 |  |  | 1,150,683 |  |  | 1,648,143 |  |
| Total net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

- added (2020-05-11):
[0001375365-20-000033:note_history:97]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Accounts receivable relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

- changed (2020-05-11):
[0001375365-20-000033:note_history:98]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and nine months ended March 31, 2020, which was included in the opening deferred revenue balance as of June 30, 2019, was $22.9 million and $71.6 million, respectively.
  (was, 2020-02-07, similarity 0.9602):
[0001375365-20-000011:note_history:98]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and six months ended December 31, 2019, which was included in the opening deferred revenue balance as of June 30, 2019, was $23.2 million and $48.7 million, respectively.

- added (2020-05-11):
[0001375365-20-000033:note_history:99]
Deferred revenue increased during the nine months ended March 31, 2020 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

- changed (2020-05-11):
[0001375365-20-000033:note_history:100]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2020 was approximately $205.5 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2020-02-07, similarity 0.7758):
[0001375365-20-000011:note_history:100]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2019 was approximately $215.6 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2020-05-11):
[0001375365-20-000011:note_history:101]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 672,727 |  |  | 77.2 | % |  | $ | 762,622 |  |  | 81.9 | % |  | $ | 1,308,753 |  |  | 78.3 | % |  | $ | 1,568,538 |  |  | 82.4 | % |
| Subsystems and accessories | 198,216 |  |  | 22.8 | % |  | 168,887 |  |  | 18.1 | % |  | 361,994 |  |  | 21.7 | % |  | 334,089 |  |  | 17.6 | % |
| Total | $ | 870,943 |  |  | 100.0 | % |  | $ | 931,509 |  |  | 100.0 | % |  | $ | 1,670,747 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |

- removed (2020-05-11):
[0001375365-20-000011:note_history:102]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

- removed (2020-05-11):
[0001375365-20-000011:note_history:103]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- removed (2020-05-11):
[0001375365-20-000011:note_history:104]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

- removed (2020-05-11):
[0001375365-20-000011:note_history:105]
Deferred revenue decreased during the six months ended December 31, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.
