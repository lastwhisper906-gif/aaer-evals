# SMCI notes — 0001375365-20-000033


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-20-000033:notes:1]
[same as prior period, unchanged from 0001375365-20-000011:notes:1]

[0001375365-20-000033:notes:2]
[same as prior period, unchanged from 0001375365-20-000011:notes:2]

[0001375365-20-000033:notes:3]
[same as prior period, unchanged from 0001375365-20-000011:notes:3]

[0001375365-20-000033:notes:4]
[same as prior period, unchanged from 0001375365-20-000011:notes:4]

[0001375365-20-000033:notes:5]
[same as prior period, unchanged from 0001375365-20-000011:notes:5]

[0001375365-20-000033:notes:6]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations.

[0001375365-20-000033:notes:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

[0001375365-20-000033:notes:8]
[same as prior period, unchanged from 0001375365-20-000011:notes:8]

[0001375365-20-000033:notes:9]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, valuation and recognition of performance awards liability, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the coronavirus ("COVID-19") pandemic on our critical and significant accounting estimates, including assessment of collectibility of customer contracts, valuation of accounts receivable, provision for excess and obsolete inventory and impairment of long-lived assets. Collectibility of customer contracts assessment resulted in delaying revenue recognition of $3.4 million for certain orders shipped during the three months ended March 31, 2020.

[0001375365-20-000033:notes:10]
[same as prior period, unchanged from 0001375365-20-000011:notes:10]

[0001375365-20-000033:notes:11]
[same as prior period, unchanged from 0001375365-20-000011:notes:11]

[0001375365-20-000033:notes:12]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

[0001375365-20-000033:notes:13]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns, with a corresponding decrease in revenue, and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs, with a corresponding decrease in cost of sales. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-20-000033:notes:14]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-20-000033:notes:15]
Contracts with multiple promised goods and services. Certain of the Company’s contracts contain multiple promised goods and services. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-20-000033:notes:16]
[same as prior period, unchanged from 0001375365-20-000011:notes:17]

[0001375365-20-000033:notes:17]
[same as prior period, unchanged from 0001375365-20-000011:notes:18]

[0001375365-20-000033:notes:18]
[same as prior period, unchanged from 0001375365-20-000011:notes:19]

[0001375365-20-000033:notes:19]
[same as prior period, unchanged from 0001375365-20-000011:notes:20]

[0001375365-20-000033:notes:20]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product

[0001375365-20-000033:notes:21]
will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

[0001375365-20-000033:notes:22]
Research and Development

[0001375365-20-000033:notes:23]
Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $0.8 million and $2.0 million for the nine months ended March 31, 2020 and 2019, respectively. Such amounts recorded as a reduction of research and development expenses were not significant for the three months ended March 31, 2020 and 2019. During the three and nine months ended March 31, 2020, the Company also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-20-000033:notes:24]
[same as prior period, unchanged from 0001375365-20-000011:notes:23]

[0001375365-20-000033:notes:25]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of inventories based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-20-000033:notes:26]
[same as prior period, unchanged from 0001375365-20-000011:notes:25]

[0001375365-20-000033:notes:27]
[same as prior period, unchanged from 0001375365-20-000011:notes:26]

[0001375365-20-000033:notes:28]
[same as prior period, unchanged from 0001375365-20-000011:notes:27]

[0001375365-20-000033:notes:29]
[same as prior period, unchanged from 0001375365-20-000011:notes:28]

[0001375365-20-000033:notes:30]
[same as prior period, unchanged from 0001375365-20-000011:notes:29]

[0001375365-20-000033:notes:31]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock options and RSUs awards are recognized to expense on a straight-line basis over the requisite service period. PRSUs awards are recognized to expense using an accelerated method only when it is probable that any performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized as compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-20-000033:notes:32]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-20-000033:notes:33]
[same as prior period, unchanged from 0001375365-20-000011:notes:32]

[0001375365-20-000033:notes:34]
[same as prior period, unchanged from 0001375365-20-000011:notes:33]

[0001375365-20-000033:notes:35]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-20-000033:notes:36]
[same as prior period, unchanged from 0001375365-20-000011:notes:35]

[0001375365-20-000033:notes:37]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-20-000033:notes:38]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

[0001375365-20-000033:notes:39]
[same as prior period, unchanged from 0001375365-20-000011:notes:38]

[0001375365-20-000033:notes:40]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-20-000033:notes:41]
[same as prior period, unchanged from 0001375365-20-000011:notes:40]

[0001375365-20-000033:notes:42]
[same as prior period, unchanged from 0001375365-20-000011:notes:41]

[0001375365-20-000033:notes:43]
[same as prior period, unchanged from 0001375365-20-000011:notes:42]

[0001375365-20-000033:notes:44]
[same as prior period, unchanged from 0001375365-20-000011:notes:43]

[0001375365-20-000033:notes:45]
[same as prior period, unchanged from 0001375365-20-000011:notes:44]

[0001375365-20-000033:notes:46]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary with respect to either Ablecom or Compuware as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-20-000033:notes:47]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2020 and 2019, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

[0001375365-20-000033:notes:48]
[same as prior period, unchanged from 0001375365-20-000011:notes:47]

[0001375365-20-000033:notes:49]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by a third party in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2020 and June 30, 2019, the Company's equity investment in the Corporate Venture was $0 and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheets. The Company's share of losses, net of taxes, of the Corporate Venture were $1.1 million and $0.4 million for the three months ended March 31, 2020 and 2019, respectively, and $1.1 million and $3.6 million for the nine months ended March 31, 2020 and 2019, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations. The Company does not have an obligation or commitment to share in losses of the Corporate Venture above its investment amounts and will discontinue equity method accounting if the investment carrying value is below zero.

[0001375365-20-000033:notes:50]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of March 31, 2020 and June 30, 2019, the Company had unamortized deferred gain balance of $2.5 million and $2.0 million, respectively, in accrued liabilities and $1.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-20-000033:notes:51]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2020 and 2019, respectively.

[0001375365-20-000033:notes:52]
In addition, the Company sells products to the Corporate Venture. The Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of each period end is eliminated and recorded as a reduction of the Company's investment balance in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company sold products worth $14.0 million and $13.7 million to the Corporate Venture in the three months ended March 31, 2020 and 2019, respectively, and $51.5 million and $35.2 million in the nine months ended March 31, 2020 and 2019, respectively. As of March 31, 2020, the Company recorded $0.5 million related to unrealized intra-entity profits in accrued liabilities in the Company’s condensed consolidated balance sheet. The Company had $10.4 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2020 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

[0001375365-20-000033:notes:53]
[same as prior period, unchanged from 0001375365-20-000011:notes:52]

[0001375365-20-000033:notes:54]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. The COVID-19 pandemic has already and may further disrupt our supply chain. One supplier accounted for 26.1% and 20.1% of total purchases for the three months ended March 31, 2020 and 2019, respectively, and 27.9% and 21.2% for the nine months ended March 31, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 9.4% and 9.9% of total cost of sales for the three months ended March 31, 2020 and 2019, respectively, and 9.8% and 9.4% for the nine months ended March 31, 2020 and 2019, respectively.

[0001375365-20-000033:notes:55]
[same as prior period, unchanged from 0001375365-20-000011:notes:54]

[0001375365-20-000033:notes:56]
Financial instruments that potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2020 and 2019. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2020, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

[0001375365-20-000033:notes:57]
[same as prior period, unchanged from 0001375365-20-000011:notes:56]

[0001375365-20-000033:notes:58]
[same as prior period, unchanged from 0001375365-20-000011:notes:57]

[0001375365-20-000033:notes:59]
[same as prior period, unchanged from 0001375365-20-000011:notes:58]

[0001375365-20-000033:notes:60]
[same as prior period, unchanged from 0001375365-20-000011:notes:59]

[0001375365-20-000033:notes:61]
[same as prior period, unchanged from 0001375365-20-000011:notes:60]

[0001375365-20-000033:notes:62]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company has started its accounting assessment of the adoption of the new standard, the process of establishing new accounting policies and evaluation of changes to systems and internal controls necessary to support the requirements of the new standard. The Company will continue to update its assessment as more information becomes available. The Company cannot reasonably estimate quantitative information related to the impact of the new guidance on its consolidated financial statements at this time.

[0001375365-20-000033:notes:63]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The adoption of the new guidance will simplify the disclosure of the fair value measurements for the Company's financial assets and liabilities.

[0001375365-20-000033:notes:64]
In August 2018, the FASB issued authoritative guidance , Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company will adopt the new guidance on a prospective basis for any new hosting arrangement entered into after July 1, 2020.

[0001375365-20-000033:notes:65]
[same as prior period, unchanged from 0001375365-20-000011:notes:64]

[0001375365-20-000033:notes:66]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. The LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility terminates on June 30, 2020 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-20-000033:notes:67]
[same as prior period, unchanged from 0001375365-20-000011:notes:65]

[0001375365-20-000033:notes:68]
[same as prior period, unchanged from 0001375365-20-000011:notes:66]

[0001375365-20-000033:notes:69]
[same as prior period, unchanged from 0001375365-20-000011:notes:67]

[0001375365-20-000033:notes:70]
[same as prior period, unchanged from 0001375365-20-000011:notes:68]

[0001375365-20-000033:notes:71]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 571,291 |  |  | $ | 592,783 |  |  | $ | 1,880,043 |  |  | $ | 2,161,321 |  |
| Subsystems and accessories | 201,117 |  |  | 150,716 |  |  | 563,112 |  |  | 484,805 |  |
| Total | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

[0001375365-20-000033:notes:72]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-20-000033:notes:73]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2020 and 2019, of net sales by geographic region (in thousands):

[0001375365-20-000033:notes:74]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 422,872 |  |  | $ | 436,734 |  |  | $ | 1,419,117 |  |  | $ | 1,516,262 |  |
| Europe | 158,144 |  |  | 128,789 |  |  | 433,767 |  |  | 472,325 |  |
| Asia | 160,472 |  |  | 146,120 |  |  | 487,827 |  |  | 549,296 |  |
| Others | 30,920 |  |  | 31,856 |  |  | 102,444 |  |  | 108,243 |  |
|  | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

[0001375365-20-000033:notes:75]
The following table presents the net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2020 and 2019 (in thousands):

[0001375365-20-000033:notes:76]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Indirect sales channel | $ | 445,980 |  |  | $ | 284,204 |  |  | $ | 1,292,472 |  |  | $ | 997,983 |  |
| Direct customers and OEMs | 326,428 |  |  | 459,295 |  |  | 1,150,683 |  |  | 1,648,143 |  |
| Total net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |

[0001375365-20-000033:notes:77]
[same as prior period, unchanged from 0001375365-20-000011:notes:76]

[0001375365-20-000033:notes:78]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Accounts receivable relate to the Company’s right to consideration for performance obligations completed (or partially completed) for which the Company has an unconditional right to consideration.

[0001375365-20-000033:notes:79]
[same as prior period, unchanged from 0001375365-20-000011:notes:78]

[0001375365-20-000033:notes:80]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and nine months ended March 31, 2020, which was included in the opening deferred revenue balance as of June 30, 2019, was $22.9 million and $71.6 million, respectively.

[0001375365-20-000033:notes:81]
Deferred revenue increased during the nine months ended March 31, 2020 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

[0001375365-20-000033:notes:82]
[same as prior period, unchanged from 0001375365-20-000011:notes:81]

[0001375365-20-000033:notes:83]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2020 was approximately $205.5 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-20-000033:notes:84]
[same as prior period, unchanged from 0001375365-20-000011:notes:83]

[0001375365-20-000033:notes:85]
[same as prior period, unchanged from 0001375365-20-000011:notes:84]

[0001375365-20-000033:notes:86]
Commencing March 8, 2016, the Company began granting stock options, RSUs, PRSUs and other equity-based awards under the 2016 Equity Incentive Plan (the "2016 Plan"). The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one

[0001375365-20-000033:notes:87]
sixteenth per quarter thereafter. As of March 31, 2020, the Company had 231,312 authorized shares available for future issuance under the 2016 Plan.

[0001375365-20-000033:notes:88]
[same as prior period, unchanged from 0001375365-20-000011:notes:86]

[0001375365-20-000033:notes:89]
[same as prior period, unchanged from 0001375365-20-000011:notes:87]

[0001375365-20-000033:notes:90]
[same as prior period, unchanged from 0001375365-20-000011:notes:88]

[0001375365-20-000033:notes:91]
[same as prior period, unchanged from 0001375365-20-000011:notes:89]

[0001375365-20-000033:notes:92]
[same as prior period, unchanged from 0001375365-20-000011:notes:90]

[0001375365-20-000033:notes:93]
[same as prior period, unchanged from 0001375365-20-000011:notes:91]

[0001375365-20-000033:notes:94]
The fair value of stock option grants for the three and nine months ended March 31, 2020 and 2019 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-20-000033:notes:95]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Risk-free interest rate | 0.53% - 1.49% |  |  | 2.56 | % |  | 0.53% - 1.72% |  |  | 2.56% - 2.97% |  |
| Expected term | 6.27 years |  |  | 6.05 years |  |  | 6.27 years |  |  | 6.05 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 49.61% - 50.46% |  |  | 50.25 | % |  | 49.61% - 50.46% |  |  | 47.34% - 50.25% |  |
| Weighted-average fair value | $ | 10.15 |  |  | $ | 7.55 |  |  | $ | 9.50 |  |  | $ | 8.56 |  |

[0001375365-20-000033:notes:96]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2020 and 2019 (in thousands):

[0001375365-20-000033:notes:97]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of sales | $ | 370 |  |  | $ | 390 |  |  | $ | 1,149 |  |  | $ | 1,256 |  |
| Research and development | 3,043 |  |  | 3,107 |  |  | 9,299 |  |  | 9,816 |  |
| Sales and marketing | 417 |  |  | 418 |  |  | 1,276 |  |  | 1,359 |  |
| General and administrative | 975 |  |  | 1,045 |  |  | 3,099 |  |  | 3,650 |  |
| Stock-based compensation expense before taxes | 4,805 |  |  | 4,960 |  |  | 14,823 |  |  | 16,081 |  |
| Income tax impact | (2,978 | ) |  | (1,016 | ) |  | (5,142 | ) |  | (3,339 | ) |
| Stock-based compensation expense, net | $ | 1,827 |  |  | $ | 3,944 |  |  | $ | 9,681 |  |  | $ | 12,742 |  |

[0001375365-20-000033:notes:98]
As of March 31, 2020, $6.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.32 years, $34.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.63 years and $0.7 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 1.04 years.

[0001375365-20-000033:notes:99]
[same as prior period, unchanged from 0001375365-20-000011:notes:97]

[0001375365-20-000033:notes:100]
The following table summarizes stock option activity during the nine months ended March 31, 2020 under all plans:

[0001375365-20-000033:notes:101]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |
| Granted |  | 251,930 |  |  | $ | 19.39 |  |  |  |
| Exercised |  | (1,454,507 | ) |  | $ | 15.98 |  |  |  |
| Forfeited/Cancelled |  | (440,807 | ) |  | $ | 11.62 |  |  |  |
| Balance as of March 31, 2020 |  | 5,731,251 |  |  | $ | 19.09 |  |  | 4.11 |
| Options vested and exercisable at March 31, 2020 |  | 4,988,991 |  |  | $ | 18.88 |  |  | 3.54 |

[0001375365-20-000033:notes:102]
[same as prior period, unchanged from 0001375365-20-000011:notes:100]

[0001375365-20-000033:notes:103]
[same as prior period, unchanged from 0001375365-20-000011:notes:101]

[0001375365-20-000033:notes:104]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. The first award was a one-year PRSU and the second award was a two-year PRSU. The one-year PRSUs would be earned based on the Company’s performance as it relates to a revenue growth metric and a minimum non-GAAP operating margin metric during the fiscal year ended June 30, 2018 with eligibility up to 200% of the targeted 30,000 units based on revenue growth if the minimum non-GAAP operating margin is achieved. If the performance metrics were met, 50% of the PRSUs would vest at June 30, 2018 while the remainder would vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors (the "Board") determined that the Company achieved the revenue and non-GAAP operating margin metrics for the fiscal year ended June 30, 2018 at a level that entitled the Chief Executive Officer to 200% of the originally targeted number of shares subject to the one-year PRSU. 50% of the PRSUs so earned were vested as of June 30, 2018, and an additional 35% of the PRSUs vested during the seven quarters ended March 31, 2020, in accordance with the terms of the grant.

[0001375365-20-000033:notes:105]
The two-year PRSUs would be earned based on the Company’s performance for the average non-GAAP operating margin metric for the two fiscal years ended June 30, 2019 with eligibility up to 100% of the targeted number of units. If the performance metrics were met, 50% of the PRSUs would have vested at June 30, 2019 while the remainder would have vested in equal amounts over the following ten quarters if the Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Board determined that the Company did not achieve the required performance metrics for the two-year PRSUs and none of the two-year PRSUs vested.

[0001375365-20-000033:notes:106]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units would vest in November 2021.

[0001375365-20-000033:notes:107]
The following table summarizes RSU and PRSU activity during the nine months ended March 31, 2020 under all plans:

[0001375365-20-000033:notes:108]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2019 | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Granted | 841,880 |  |  | $ | 20.24 |  |  | 30,000 |  |  |  | $ | 20.37 |  |
| Released | (669,721 | ) |  | $ | 20.79 |  |  | (102,000 | ) |  |  | $ | 27.10 |  |
| Forfeited | (126,039 | ) |  | $ | 18.88 |  |  | — |  |  |  |  |
| Balance as of March 31, 2020 | 1,919,222 |  |  | $ | 20.14 |  |  | 48,000 |  |  |  | $ | 22.89 |  |

[0001375365-20-000033:notes:109]
[same as prior period, unchanged from 0001375365-20-000011:notes:107]

[0001375365-20-000033:notes:110]
(1)

[0001375365-20-000033:notes:111]
Reflects the number of PRSUs that have been earned based on the achievement of performance metrics.


## us-gaap:EarningsPerShareTextBlock

[0001375365-20-000033:notes:112]
[same as prior period, unchanged from 0001375365-20-000011:notes:111]

[0001375365-20-000033:notes:113]
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2020 and 2019 (in thousands, except per share amounts):

[0001375365-20-000033:notes:114]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 15,807 |  |  | $ | 10,646 |  |  | $ | 65,858 |  |  | $ | 48,208 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 51,526 |  |  | 49,988 |  |  | 50,591 |  |  | 49,845 |  |
| Effect of dilutive securities | 2,167 |  |  | 1,570 |  |  | 1,808 |  |  | 1,712 |  |
| Weighted-average diluted shares | 53,693 |  |  | 51,558 |  |  | 52,399 |  |  | 51,557 |  |
| Basic net income per common share | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 1.30 |  |  | $ | 0.97 |  |
| Diluted net income per common share | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 1.26 |  |  | $ | 0.94 |  |

[0001375365-20-000033:notes:115]
For the three and nine months ended March 31, 2020 and 2019, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,882,238 and 2,305,538 for three and nine months ended March 31, 2020, respectively, and 4,443,127 and 4,194,283 for the three and nine months ended March 31, 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-20-000033:notes:116]
[same as prior period, unchanged from 0001375365-20-000011:notes:115]

[0001375365-20-000033:notes:117]
[same as prior period, unchanged from 0001375365-20-000011:notes:116]

[0001375365-20-000033:notes:118]
[same as prior period, unchanged from 0001375365-20-000011:notes:117]

[0001375365-20-000033:notes:119]
|  | March 31, 2020 |  | June 30, 2019 |
| Finished goods | $ | 623,868 |  |  | $ | 492,387 |  |
| Work in process | 82,108 |  |  | 43,598 |  |
| Purchased parts and raw materials | 160,250 |  |  | 134,203 |  |
| Total inventories | $ | 866,226 |  |  | $ | 670,188 |  |

[0001375365-20-000033:notes:120]
The Company recorded a provision for excess and obsolete inventory to cost of sales totaling $4.7 million and $21.6 million in the three and nine months ended March 31, 2020, respectively, and $4.7 million and $17.3 million in the three and nine months ended March 31, 2019, respectively. These amounts exclude a (recovery) provision for adjusting the cost of certain inventories to net realizable value of $(0.8) million and $(3.5) million for the three and nine months ended March 31, 2020, respectively, and $5.7 million and $7.3 million for the three and nine months ended March 31, 2019, respectively.

[0001375365-20-000033:notes:121]
[same as prior period, unchanged from 0001375365-20-000011:notes:120]

[0001375365-20-000033:notes:122]
|  | March 31, 2020 |  | June 30, 2019 |
| Receivables from vendors (1) | $ | 90,006 |  |  | $ | 83,050 |  |
| Prepaid income tax | 15,483 |  |  | 607 |  |
| Restricted cash | 16,804 |  |  | 11,673 |  |
| Prepaid expenses | 9,704 |  |  | 7,269 |  |
| Deferred service costs | 3,790 |  |  | 3,374 |  |
| Others (2) | 12,315 |  |  | 3,822 |  |
| Total prepaid expenses and other current assets | $ | 148,102 |  |  | $ | 109,795 |  |

[0001375365-20-000033:notes:123]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $87.1 million and $82.0 million as of March 31, 2020 and June 30, 2019, respectively.

[0001375365-20-000033:notes:124]
(2) Includes input value added tax (“VAT”) paid for inventories purchased in Taiwan of $8.4 million and $0 as of March 31, 2020 and June 30, 2019, respectively.

[0001375365-20-000033:notes:125]
[same as prior period, unchanged from 0001375365-20-000011:notes:123]

[0001375365-20-000033:notes:126]
|  | March 31, 2020 |  | June 30, 2019 |
| Cash and cash equivalents | $ | 300,859 |  |  | $ | 248,164 |  |
| Restricted cash included in prepaid expenses and other current assets | 16,804 |  |  | 11,673 |  |
| Restricted cash included in other assets | 1,601 |  |  | 2,303 |  |
| Total cash, cash equivalents and restricted cash | $ | 319,264 |  |  | $ | 262,140 |  |

[0001375365-20-000033:notes:127]
[same as prior period, unchanged from 0001375365-20-000011:notes:125]

[0001375365-20-000033:notes:128]
|  | March 31, 2020 |  | June 30, 2019 |
| Buildings | $ | 86,930 |  |  | $ | 86,136 |  |
| Machinery and equipment | 84,711 |  |  | 79,946 |  |
| Land | 75,240 |  |  | 74,926 |  |
| Buildings construction in progress (1) | 41,637 |  |  | 14,189 |  |
| Building and leasehold improvements | 24,390 |  |  | 22,307 |  |
| Furniture and fixtures | 21,038 |  |  | 20,193 |  |
| Software | 20,619 |  |  | 18,415 |  |
|  | 354,565 |  |  | 316,112 |  |
| Accumulated depreciation and amortization | (124,088 | ) |  | (108,775 | ) |
| Property, plant and equipment, net | $ | 230,477 |  |  | $ | 207,337 |  |

[0001375365-20-000033:notes:129]
[same as prior period, unchanged from 0001375365-20-000011:notes:127]

[0001375365-20-000033:notes:130]
[same as prior period, unchanged from 0001375365-20-000011:notes:128]

[0001375365-20-000033:notes:131]
|  | March 31, 2020 |  | June 30, 2019 |
| Operating lease right-of-use asset | $ | 25,304 |  |  | $ | — |  |
| Deferred service costs, non-current | 4,413 |  |  | 3,572 |  |
| Prepaid expense, non-current | 1,615 |  |  | 1,649 |  |
| Restricted cash, non-current | 1,601 |  |  | 2,303 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 1,206 |  |  | 686 |  |
| Non-marketable equity securities | 128 |  |  | 878 |  |
| Total other assets | $ | 35,838 |  |  | $ | 10,659 |  |

[0001375365-20-000033:notes:132]
[same as prior period, unchanged from 0001375365-20-000011:notes:130]

[0001375365-20-000033:notes:133]
|  | March 31, 2020 |  | June 30, 2019 |
| Contract manufacturing liabilities | 48,835 |  |  | 25,308 |  |
| Accrued payroll and related expenses | 28,716 |  |  | 25,552 |  |
| Accrued legal liabilities (Note 11) | 17,500 |  |  | — |  |
| Customer deposits | 15,958 |  |  | 11,133 |  |
| Performance awards liability, current | 10,257 |  |  | — |  |
| Accrued warranty costs | 9,386 |  |  | 8,661 |  |
| Accrued cooperative marketing expenses | 6,649 |  |  | 5,830 |  |
| Operating lease liability | 6,103 |  |  | — |  |
| Accrued professional fees | 2,804 |  |  | 11,756 |  |
| Others (accrued liabilities) | 30,940 |  |  | 26,438 |  |
| Total accrued liabilities | 177,148 |  |  | 114,678 |  |

[0001375365-20-000033:notes:134]
Performance Awards Liability

[0001375365-20-000033:notes:135]
In March 2020, the Board approved $25.3 million one-time performance bonuses to employees, which include $8.0 million payable in cash during the fourth quarter of fiscal year 2020 and $17.3 million payable in cash if the average closing price for the Company’s common stock equals or exceeds $21.39 for any period of 10 consecutive trading days following March 26, 2020. The target price criteria were achieved in April 2020. Therefore, the Company expects to pay the entire amount of the one-time performance bonuses to employees in the fourth fiscal quarter 2020.

[0001375365-20-000033:notes:136]
The Board also approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments will be earned when specified market and performance conditions are achieved.

[0001375365-20-000033:notes:137]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved and the date that the payment is made. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved and the date that the payment is made.

[0001375365-20-000033:notes:138]
Performance bonuses for a senior executive and two members of the Board are earned based on achieving a specified target average closing price for the Company’s common stock over the specified period as determined by the Board at the grant dates and continuous services through the payment dates. A senior executive can earn an aggregate cash payment up to $0.1 million and the two members of the Board can earn aggregate cash payments of $0.3 million. The target average closing price ranges from $25.80 to $32.99 per share. These awards expire in two equal amounts at September 30, 2021 and June 30, 2022 for the two Board members' awards, and in September 30, 2022 for the senior executive’s award.

[0001375365-20-000033:notes:139]
Except for cash bonuses of $8.0 million to employees, the Company accounts for these performance bonuses as liabilities and estimates fair value of payable amounts using a Monte-Carlo simulation model. The awards are re-measured at each period end with changes in fair value recorded in the Company’s condensed consolidated statement of operations in cost of sales and operating expenses. The cumulative recorded expense at each period end is trued-up to the expected payable amount vested through the period end. The requisite service periods over which expenses are recognized are derived from the Monte-Carlo model for all performance awards, except for the first 50% of the Chief Executive Officer’s award that includes a performance condition. The Company estimates if it is probable that the performance condition will be met through the expiration date of this award. If at the measurement date it is determined to be probable, the Company estimates the requisite period as the longer of the service period derived by the Monte-Carlo model and the implicit service period when the Company expects to make adequate progress in remediating its material weaknesses in its internal control over financial reporting, as reported by the Company's Audit Committee. If it is determined to not be probable, then the Company will reverse any previously recognized expense for this award in the period when it is no longer probable that the performance condition will be achieved.

[0001375365-20-000033:notes:140]
As of March 31, 2020, the Company recorded a $10.3 million compensation expense related to performance bonuses, which amount includes the $8.0 million in cash payable in the fourth quarter of fiscal year 2020. An unrecognized compensation expense of $15.6 million will be recorded over the remaining service periods from one month for employees’ awards to 1.43 years for the first 50% of the Chief Executive Officer’s award. The unrecognized expense and remaining service periods will be remeasured each reporting period. As of March 31, 2020, the Company recorded $10.3 million in accrued liabilities and $0.1 million in other long-term liabilities in its condensed consolidated balance sheet.

[0001375365-20-000033:notes:141]
[same as prior period, unchanged from 0001375365-20-000011:notes:132]

[0001375365-20-000033:notes:142]
|  | March 31, 2020 |  | June 30, 2019 |
| Operating lease liability, non-current | $ | 19,488 |  |  | $ | — |  |
| Accrued unrecognized tax benefits including related interest and penalties | 17,804 |  |  | 20,102 |  |
| Accrued warranty costs, non-current | 2,348 |  |  | 2,373 |  |
| Others | 1,626 |  |  | 3,708 |  |
| Total other long-term liabilities | $ | 41,266 |  |  | $ | 26,183 |  |

[0001375365-20-000033:notes:143]
[same as prior period, unchanged from 0001375365-20-000011:notes:134]

[0001375365-20-000033:notes:144]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance, beginning of the period | $ | 11,441 |  |  | $ | 10,434 |  |  | $ | 11,034 |  |  | $ | 9,884 |  |
| Provision for warranty | 8,521 |  |  | 5,510 |  |  | 25,627 |  |  | 17,163 |  |
| Costs utilized | (8,130 | ) |  | (6,346 | ) |  | (24,907 | ) |  | (18,083 | ) |
| Change in estimated liability for pre-existing warranties | (98 | ) |  | 918 |  |  | (20 | ) |  | 1,552 |  |
| Balance, end of the period | 11,734 |  |  | 10,516 |  |  | 11,734 |  |  | 10,516 |  |
| Current portion | 9,386 |  |  | 8,200 |  |  | 9,386 |  |  | 8,200 |  |
| Non-current portion | $ | 2,348 |  |  | $ | 2,316 |  |  | $ | 2,348 |  |  | $ | 2,316 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-20-000033:notes:145]
[same as prior period, unchanged from 0001375365-20-000011:notes:136]

[0001375365-20-000033:notes:146]
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2020 and June 30, 2019. The Company used discounted cash flows to estimate the fair value of the auction rate security as of March 31, 2020 and June 30, 2019. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-20-000033:notes:147]
[same as prior period, unchanged from 0001375365-20-000011:notes:138]

[0001375365-20-000033:notes:148]
The following table sets forth the Company’s cash equivalents, certificates of deposit, investment in an auction rate security and performance awards liability as of March 31, 2020 and June 30, 2019, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-20-000033:notes:149]
| March 31, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,164 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,164 |  |
| Certificates of deposit (2) | — |  |  | 577 |  |  | — |  |  | 577 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,164 |  |  | $ | 577 |  |  | $ | 1,571 |  |  | $ | 3,312 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,344 |  |  | $ | — |  |  | $ | 2,344 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,344 |  |  | $ | — |  |  | $ | 2,344 |  |
| June 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,162 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,162 |  |
| Certificates of deposit (2) | — |  |  | 1,285 |  |  | — |  |  | 1,285 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,162 |  |  | $ | 1,285 |  |  | $ | 1,571 |  |  | $ | 4,018 |  |

[0001375365-20-000033:notes:150]
(1) $0.4 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2020 and June 30, 2019, respectively.

[0001375365-20-000033:notes:151]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents and $0.4 million and $1.1 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2020 and June 30, 2019, respectively.

[0001375365-20-000033:notes:152]
(3) As of March 31, 2020, the current portion of the performance awards liability of $2.2 million is included in accrued liabilities and the noncurrent portion of $0.1 million is included in other long-term liabilities in the condensed consolidated balance sheets. There was no such liability outstanding as of June 30, 2019.

[0001375365-20-000033:notes:153]
The performance awards liability consists of one-time employee performance bonuses for the Company's Chief Executive Officer, a senior executive, two members of the Board, and other employees that are payable when specified market and performance conditions are achieved. The Company estimated the fair value of these performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of March 31, 2020 are as follows:

[0001375365-20-000033:notes:154]
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $21.28 |  | 1.5 - 2.5 years |  | 0.26% |  | 53.8% |  | —% |

[0001375365-20-000033:notes:155]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and nine months ended March 31, 2020 and 2019.

[0001375365-20-000033:notes:156]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2020 and 2019.

[0001375365-20-000033:notes:157]
The following is a summary of the Company’s investment in an auction rate security as of March 31, 2020 and June 30, 2019 (in thousands):

[0001375365-20-000033:notes:158]
|  | March 31, 2020 and June 30, 2019 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-20-000033:notes:159]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2020 and June 30, 2019, total debt of $33.2 million and $23.6 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-20-000033:notes:160]
Other Financial Assets - Investments into Non-Marketable Equity Securities

[0001375365-20-000033:notes:161]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values. The Company accounts for these investments at cost minus impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three and nine months ended March 31, 2020 and 2019, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three and nine months ended March 31, 2020. During the three and nine months ended March 31, 2019, the Company recorded impairment charges of $0.7 million for its non-marketable equity securities which had an initial cost basis of $0.7 million as it was determined the carrying value of the investments were not recoverable.


## us-gaap:DebtDisclosureTextBlock

[0001375365-20-000033:notes:162]
Short-term Debt

[0001375365-20-000033:notes:163]
Short-term debt obligations as of March 31, 2020 and June 30, 2019 consisted of the following (in thousands):

[0001375365-20-000033:notes:164]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank | 10,000 |  |  | — |  |
| Total line of credit | 10,000 |  |  | 1,116 |  |
| CTBC Bank term loan | 23,158 |  |  | 22,531 |  |
| Total short-term debt | $ | 33,158 |  |  | $ | 23,647 |  |

[0001375365-20-000033:notes:165]
Bank of America

[0001375365-20-000033:notes:166]
2018 Bank of America Credit Facility

[0001375365-20-000033:notes:167]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and was extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

[0001375365-20-000033:notes:168]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020. The Company is in the process of negotiating an extension of its credit facility with Bank of America and expects this process will be completed by the end of May, 2020.

[0001375365-20-000033:notes:169]
As of March 31, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2020 and June 30, 2019 were 3.63% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of March 31, 2020 and June 30, 2019. As of March 31, 2020, the Company's

[0001375365-20-000033:notes:170]
available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-20-000033:notes:171]
CTBC Bank

[0001375365-20-000033:notes:172]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-20-000033:notes:173]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (iii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-20-000033:notes:174]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.2 million and $22.5 million at March 31, 2020 and June 30, 2019, respectively. As of March 31, 2020, the total outstanding borrowings under the 2019 CTBC Credit Facility revolving line of credit were $10.0 million in U.S. dollars. At June 30, 2019, the Company did not have any outstanding balance under the 2019 CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.91% per annum as of March 31, 2020 and 0.93% per annum as of June 30, 2019. At March 31, 2020, the amount available for future borrowing under the 2019 CTBC Credit Facility was $16.8 million. As of March 31, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.5 million.

[0001375365-20-000033:notes:175]
Covenant Compliance

[0001375365-20-000033:notes:176]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-20-000033:notes:177]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended

[0001375365-20-000033:notes:178]
June 30, 2017. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

[0001375365-20-000033:notes:179]
On December 19, 2019, the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such, the Company complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

[0001375365-20-000033:notes:180]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-20-000033:notes:181]
[same as prior period, unchanged from 0001375365-20-000011:notes:171]

[0001375365-20-000033:notes:182]
Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2020 were as follows (in thousands):

[0001375365-20-000033:notes:183]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2020 |  | March 31, 2020 |
| Operating lease expense (including expense for lease agreements with related parties of $359 and $1,086 for the three and nine months ended March 31, 2019, respectively) |  | $ | 1,605 |  |  | $ | 4,909 |  |
| Cash payments for operating leases (including payments to related parties of $369 and $1,106 for the three and nine months ended March 31, 2019, respectively) |  | $ | 1,667 |  |  | $ | 5,082 |  |
| New operating lease assets obtained in exchange for operating lease liabilities |  | $ | 14,221 |  |  | $ | 14,889 |  |

[0001375365-20-000033:notes:184]
During the three and nine months ended March 31, 2020, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable payments expensed in the three and nine months ended March 31, 2020 were $0.2 million and $0.9 million, respectively.

[0001375365-20-000033:notes:185]
As of March 31, 2020, the weighted average remaining lease term for operating leases was 4.7 years and the weighted average discount rate was 3.6%. Future minimum lease payments under noncancelable operating lease arrangements as of March 31, 2020 were as follows (in thousands):

[0001375365-20-000033:notes:186]
| Fiscal Year: |  | Minimum lease payments |
| 2020 (remainder) |  | $ | 2,208 |  |
| 2021 |  | 6,974 |  |
| 2022 |  | 5,613 |  |
| 2023 |  | 4,219 |  |
| 2024 |  | 4,204 |  |
| 2025 and beyond |  | 5,232 |  |
| Total future lease payments |  | $ | 28,450 |  |
| Less: Imputed interest |  | (2,859 | ) |
| Present value of operating lease liabilities |  | $ | 25,591 |  |

[0001375365-20-000033:notes:187]
As of March 31, 2020, commitments under short-term lease arrangements were immaterial. As of March 31, 2020, operating and financing leases that have not yet commenced were immaterial.

[0001375365-20-000033:notes:188]
The Company has entered into lease agreements with related parties.  See Note 9, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-20-000033:notes:189]
Related Party Transactions

[0001375365-20-000033:notes:190]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2020, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-20-000033:notes:191]
Dealings with Ablecom

[0001375365-20-000033:notes:192]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-20-000033:notes:193]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.1% and 96.0% of the chassis included in the products sold by the Company during the three months ended March 31, 2020 and 2019, respectively; and approximately 95.3% and 95.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-20-000033:notes:194]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the

[0001375365-20-000033:notes:195]
Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-20-000033:notes:196]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $60.0 million and $31.0 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-20-000033:notes:197]
Dealings with Compuware

[0001375365-20-000033:notes:198]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-20-000033:notes:199]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-20-000033:notes:200]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-20-000033:notes:201]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-20-000033:notes:202]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $111.2 million and $70.6 million at March 31, 2020 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-20-000033:notes:203]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2020 and 2019, are as follows (in thousands):

[0001375365-20-000033:notes:204]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 37,607 |  |  | $ | 29,372 |  |  | $ | 115,295 |  |  | $ | 110,290 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 7,503 |  |  | $ | 3,846 |  |  | $ | 19,456 |  |  | $ | 13,628 |  |
| Purchases (1) | 24,908 |  |  | 34,140 |  |  | 91,662 |  |  | 111,629 |  |

[0001375365-20-000033:notes:205]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-20-000033:notes:206]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2020 and 2019.

[0001375365-20-000033:notes:207]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2020 and June 30, 2019 (in thousands):

[0001375365-20-000033:notes:208]
|  | March 31, 2020 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 4,749 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (2) | 28,928 |  |  | 33,928 |  |
| Other long-term liabilities (3) | 1,036 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 18,046 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (2) | 43,935 |  |  | 34,417 |  |
| Other long-term liabilities (3) | 335 |  |  | — |  |

[0001375365-20-000033:notes:209]
____________________________

[0001375365-20-000033:notes:210]
(1) Other receivables include receivables from vendors.

[0001375365-20-000033:notes:211]
(2) Includes current portion of operating lease liabilities.

[0001375365-20-000033:notes:212]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-20-000033:notes:213]
See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-20-000033:notes:214]
The Company recorded a benefit for income taxes of $0.9 million for the three months ended March 31, 2020, and a provision for income taxes of $9.8 million for the nine months ended March 31, 2020.  The Company recorded provisions for income taxes of $0.5 million and $10.5 million for the three and nine months ended March 31, 2019, respectively. The effective tax rate was (5.6)% and 12.8% for the three and nine months ended March 31, 2020, respectively, and 4.3% and 16.9% for the three and nine months ended March 31, 2019, respectively. The effective tax rate for the three and nine months ended March 31, 2020 is lower than that for the three and nine months ended March 31, 2019, primarily due to the tax benefit from employees’ exercises of stock options.

[0001375365-20-000033:notes:215]
[same as prior period, unchanged from 0001375365-20-000011:notes:204]

[0001375365-20-000033:notes:216]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted. The CARES Act provides temporary relief from certain aspects of the 2017 Tax Reform Act that imposed limitations on the utilization of certain losses, interest expense deductions and alternative minimum tax credits and made a technical correction to the 2017 Tax Reform Act related to the depreciable life of qualified improvement property. The CARES Act is not expected to have a material impact on the Company.

[0001375365-20-000033:notes:217]
As of March 31, 2020, the Company had a liability for gross unrecognized tax benefits of $25.8 million, substantially all of which, if recognized, would affect the Company's effective tax rate. During the nine months ended March 31, 2020, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2020, the Company had accrued $2.0 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-20-000033:notes:218]
[same as prior period, unchanged from 0001375365-20-000011:notes:206]

[0001375365-20-000033:notes:219]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in accordance with the tax assessment notice issued in February 2020. The impact of this adjustment on the income statement has been offset by the recognition of previously unrecognized tax benefits for the three months ended March 31, 2020.

[0001375365-20-000033:notes:220]
In February 2020, the Taiwan tax authority proposed an adjustment to the Company’s fiscal year 2019 transfer pricing which resulted in additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of this adjustment on the income statement has been offset by the recognition of previously unrecognized tax benefits for the three months ended March 31, 2020.

[0001375365-20-000033:notes:221]
[same as prior period, unchanged from 0001375365-20-000011:notes:208]

[0001375365-20-000033:notes:222]
The federal statute of limitations remains open in general for tax years ended June 30, 2017 through 2019. Various states statute of limitations remain open in general for tax years ended June 30, 2016 through 2019. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2014 through 2019. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months, except for the reductions arising from the lapse of the statute of limitations. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $5.5 million in the next 12 months, primarily due to the lapse of the statute of limitations and

[0001375365-20-000033:notes:223]
settlement with the Tax Authorities. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-20-000033:notes:224]
Commitments and Contingencies

[0001375365-20-000033:notes:225]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

[0001375365-20-000033:notes:226]
SEC Matter— The Company has cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by the Company’s management, which irregularities were disclosed on August 31, 2015. In addition, the Company received subpoenas from the SEC in connection with the matters underlying its inability to timely file the Company's Form 10-K for the fiscal year ended June 30, 2017. The Company also received a subpoena from the SEC following the publication of a false and widely discredited news article in October 2018 concerning its products. The Company has cooperated fully to comply with these government requests. The Company has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Company will pay a penalty of $17.5 million. In addition, the Company’s Chief Executive Officer has reached an agreement in principle regarding a proposed settlement of these matters with the staff of the SEC, subject to final approval by the Commissioners of the SEC. Under the terms of the proposed resolution, the Chief Executive Officer will pay the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. As of March 31, 2020, the Company recorded a liability of $17.5 million for the Company’s potential SEC settlement included in general and administrative expenses and accrued liabilities in the condensed consolidated financial statements. The Chief Executive Officer’s potential payment of $2,122,000 to the Company is a contingent gain and will be recorded if and when it is realized. The Company and the Chief Executive Officer have not reached final resolutions of these matters with the SEC and the Company cannot predict when settlements, if finally agreed, would become final, nor whether any of the proposed terms may change in connection with final resolutions.

[0001375365-20-000033:notes:227]
Other legal proceedings and indemnifications

[0001375365-20-000033:notes:228]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2020 and any prior periods.

[0001375365-20-000033:notes:229]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-20-000033:notes:230]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2020, these remaining noncancelable commitments were $381.1 million, including $122.2 million for related parties.

[0001375365-20-000033:notes:231]
Standby Letter of Credit— In October 2019, Bank of America increased the value of a previously issued standby letter of credit from $3.2 million to $6.4 million to facilitate ongoing operations of the Company. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-20-000033:notes:232]
[same as prior period, unchanged from 0001375365-20-000011:notes:216]

[0001375365-20-000033:notes:233]
[same as prior period, unchanged from 0001375365-20-000011:notes:217]

[0001375365-20-000033:notes:234]
[same as prior period, unchanged from 0001375365-20-000011:notes:218]

[0001375365-20-000033:notes:235]
|  | March 31, |  | June 30, |
| Long-lived assets: | 2020 |  | 2019 |
| United States | $ | 179,154 |  |  | $ | 162,835 |  |
| Asia | 47,717 |  |  | 41,915 |  |
| Europe | 3,606 |  |  | 2,587 |  |
|  | $ | 230,477 |  |  | $ | 207,337 |  |

[0001375365-20-000033:notes:236]
[same as prior period, unchanged from 0001375365-20-000011:notes:220]
