# SMCI MD&A — 0001375365-20-000033


## mdna

[0001375365-20-000033:mdna:1]
[same as prior period, unchanged from 0001375365-20-000011:mdna:1]

[0001375365-20-000033:mdna:2]
[same as prior period, unchanged from 0001375365-20-000011:mdna:2]

[0001375365-20-000033:mdna:3]
[same as prior period, unchanged from 0001375365-20-000011:mdna:3]

[0001375365-20-000033:mdna:4]
[same as prior period, unchanged from 0001375365-20-000011:mdna:4]

[0001375365-20-000033:mdna:5]
[same as prior period, unchanged from 0001375365-20-000011:mdna:5]

[0001375365-20-000033:mdna:6]
We are a global leader and innovator of high-performance, high-efficiency server and storage technology. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise, big data, artificial intelligence ("AI"), High-Performance Computing ("HPC"), edge computing and Internet of Things/embedded (“IoT”) markets. Our solutions range from complete server, storage, modular blade servers, blades and workstations to full racks, networking devices, server management software, server sub-systems and global support and services.

[0001375365-20-000033:mdna:7]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales for the three months ended March 31, 2020 increased to $772.4 million from $743.5 million for the corresponding period in the prior year, and our net income for the three months ended March 31, 2020 increased to $15.8 million from $10.6 million for the corresponding period in the prior year. We seek to increase our sales and profits every quarter. We believe that to do so, we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and our customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors incorporating new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the product introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others carefully. This also impacts our research and development expenditures as we continue to invest significantly in our current and future product development efforts.

[0001375365-20-000033:mdna:8]
Coronavirus (COVID-19) Pandemic Impact

[0001375365-20-000033:mdna:9]
The global spread of the coronavirus (COVID-19) and the various attempts to contain it have created significant volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders to close all businesses not deemed “essential,” shelter in place, and practice social distancing when engaging in essential activities. We are an essential business under the relevant regulations. In late March, we responded to the directives from Santa Clara County and the State of California regarding “shelter in place” instructions to combat the spread of COVID-19. Our first priority is the safety of our workforce and we immediately began to implement numerous health precautions and work practices to operate in a safe manner.

[0001375365-20-000033:mdna:10]
We quickly transitioned most of our indirect labor forces to work from home and continued to operate our local assembly in Taiwan and, to a lesser extent, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continue to see ongoing demand as we enter the fourth quarter of fiscal year 2020 and do not have significant direct exposure to industries such as retail and oil and gas, which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-20-000033:mdna:11]
We have actively managed our supply chain for potential shortage risk by first building inventories of critical components required for our motherboards and other system printed circuit boards in response to the early outbreak of COVID-19 in China. Since that time, we have continued to add to our inventories of key components such as CPUs, memory, SSDs and to a lesser extent GPUs such that customer orders can be fulfilled as they are received.

[0001375365-20-000033:mdna:12]
We are monitoring the changes in liquidity and payment patterns of our customer base to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we are actively managing our liquidity needs and working to expand our access to credit facilities. We are in the process of negotiating an extension of our credit facility with Bank of America and expect this process will be completed by the end of May, 2020.

[0001375365-20-000033:mdna:13]
Looking forward, logistics has emerged as a new challenge as the transportation industry restricts the frequency of departures and increases logistics costs. We expect increased costs in freight as well as direct labor costs as we incentivize our employees to continue to work and assist us in serving our customers, many of whom are in critical industries.

[0001375365-20-000033:mdna:14]
Our management team is focused on guiding our company through the unfolding and emerging challenges presented by COVID-19. Currently, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-20-000033:mdna:15]
[same as prior period, unchanged from 0001375365-20-000011:mdna:11]

[0001375365-20-000033:mdna:16]
The following is a summary of our financial highlights of the third quarter of fiscal year 2020:

[0001375365-20-000033:mdna:17]
| • | Net sales increased by 3.9% as compared to the three months ended March 31, 2019. The increase was mainly due to an increase in the sales of subsystems and accessories and an increase in the volume of server and storage systems sold, partially offset by lower average selling prices per system. |

[0001375365-20-000033:mdna:18]
| • | Gross margin increased to 17.3% in the three months ended March 31, 2020 from 15.1% for the three months ended March 31, 2019, primarily due to a favorable geographic, customer and product mix. |

[0001375365-20-000033:mdna:19]
| • | Operating expenses increased by 18.4% as compared to the three months ended March 31, 2019, and were equal to 15.3% and 13.4% of net sales in the three months ended March 31, 2020 and 2019, respectively. |

[0001375365-20-000033:mdna:20]
| • | Effective tax rate decreased from 4.3% in the three months ended March 31, 2019 to (5.6)% in the three months ended March 31, 2020. |

[0001375365-20-000033:mdna:21]
[same as prior period, unchanged from 0001375365-20-000011:mdna:17]

[0001375365-20-000033:mdna:22]
Net sales. Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact our net sales are the number of compute nodes sold, the average selling prices per node for our server and storage system sales and units shipped and the average selling price per unit and units shipped for our subsystem and accessories. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs, and memory, and the prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories. A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, and due to price transparency of certain higher cost components, we must

[0001375365-20-000033:mdna:23]
actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs, and actively adjust our procurement practices in anticipation of near term fluctuations in market prices for key components.

[0001375365-20-000033:mdna:24]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from a number of factors, including component shortages.

[0001375365-20-000033:mdna:25]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. Beginning in fiscal year 2019, we expanded manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We continue to enhance our Taiwan manufacturing operations to increase the diversification of our manufacturing capabilities in order to strengthen our business continuity and better position the Company to respond to challenges, such as those arising from COVID-19. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of subsystems, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 9.4% and 9.9% of total cost of sales for the three months ended March 31, 2020 and 2019, respectively, and 9.8% and 9.4% for the nine months ended March 31, 2020 and 2019, respectively. For further details on our dealings with related parties, see Part I, Item 1, Note 9, “Related Party Transactions.”

[0001375365-20-000033:mdna:26]
[same as prior period, unchanged from 0001375365-20-000011:mdna:21]

[0001375365-20-000033:mdna:27]
[same as prior period, unchanged from 0001375365-20-000011:mdna:22]

[0001375365-20-000033:mdna:28]
[same as prior period, unchanged from 0001375365-20-000011:mdna:23]

[0001375365-20-000033:mdna:29]
[same as prior period, unchanged from 0001375365-20-000011:mdna:24]

[0001375365-20-000033:mdna:30]
[same as prior period, unchanged from 0001375365-20-000011:mdna:25]

[0001375365-20-000033:mdna:31]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan and the Netherlands. Our effective tax rate differs from the statutory rate

[0001375365-20-000033:mdna:32]
primarily due to the benefit of research and development tax credits and the domestic production activities deduction which were partially offset by state taxes and unrecognized tax benefits related to permanent establishment exposures.

[0001375365-20-000033:mdna:33]
[same as prior period, unchanged from 0001375365-20-000011:mdna:27]

[0001375365-20-000033:mdna:34]
[same as prior period, unchanged from 0001375365-20-000011:mdna:28]

[0001375365-20-000033:mdna:35]
Except for the changes to our accounting policy as a result of the adoption of the new lease accounting guidance on July 1, 2019, there have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2019 Comprehensive 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Organization and Summary of Significant Accounting Policies" in our notes to the condensed consolidated financial statements in this Quarterly Report.

[0001375365-20-000033:mdna:36]
[same as prior period, unchanged from 0001375365-20-000011:mdna:30]

[0001375365-20-000033:mdna:37]
The following table presents certain items of our condensed consolidated statements of operations expressed as a percentage of revenue.

[0001375365-20-000033:mdna:38]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 82.7 | % |  | 84.9 | % |  | 83.5 | % |  | 86.3 | % |
| Gross profit | 17.3 | % |  | 15.1 | % |  | 16.5 | % |  | 13.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6.4 | % |  | 6.0 | % |  | 6.3 | % |  | 5.1 | % |
| Sales and marketing | 2.8 | % |  | 2.5 | % |  | 2.6 | % |  | 2.1 | % |
| General and administrative | 6.0 | % |  | 4.9 | % |  | 4.4 | % |  | 4.0 | % |
| Total operating expenses | 15.3 | % |  | 13.4 | % |  | 13.4 | % |  | 11.2 | % |
| Income from operations | 2.0 | % |  | 1.7 | % |  | 3.1 | % |  | 2.5 | % |
| Other (expense) income, net | 0.1 | % |  | — | % |  | 0.1 | % |  | — | % |
| Interest expense | (0.1 | )% |  | (0.2 | )% |  | (0.1 | )% |  | (0.2 | )% |
| Income before income tax provision | 2.1 | % |  | 1.5 | % |  | 3.1 | % |  | 2.4 | % |
| Income tax provision | 0.1 | % |  | (0.1 | )% |  | (0.4 | )% |  | (0.4 | )% |
| Share of loss from equity investee, net of taxes | (0.1 | )% |  | — | % |  | — | % |  | (0.1 | )% |
| Net income | 2.0 | % |  | 1.4 | % |  | 2.7 | % |  | 1.8 | % |

[0001375365-20-000033:mdna:39]
[same as prior period, unchanged from 0001375365-20-000011:mdna:31]

[0001375365-20-000033:mdna:40]
The following table presents net sales by product type for the three and nine months ended March 31, 2020 and 2019 (dollars in millions):

[0001375365-20-000033:mdna:41]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Server and storage systems | $ | 571.3 |  |  | $ | 592.8 |  |  | $ | (21.5 | ) |  | (3.6 | )% |  | $ | 1,880.0 |  |  | $ | 2,161.3 |  |  | $ | (281.3 | ) |  | (13.0 | )% |
| Percentage of total net sales | 74.0 | % |  | 79.7 | % |  |  |  |  |  | 77.0 | % |  | 81.7 | % |  |  |  |  |
| Subsystems and accessories | $ | 201.1 |  |  | $ | 150.7 |  |  | $ | 50.4 |  |  | 33.4 | % |  | $ | 563.1 |  |  | $ | 484.8 |  |  | $ | 78.3 |  |  | 16.2 | % |
| Percentage of total net sales | 26.0 | % |  | 20.3 | % |  |  |  |  |  | 23.0 | % |  | 18.3 | % |  |  |  |  |
| Total net sales | $ | 772.4 |  |  | $ | 743.5 |  |  | $ | 28.9 |  |  | 3.9 | % |  | $ | 2,443.1 |  |  | $ | 2,646.1 |  |  | $ | (203.0 | ) |  | (7.7 | )% |

[0001375365-20-000033:mdna:42]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-20-000033:mdna:43]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:44]
The period-over-period decrease in net sales of our server and storage systems was due to a slight decrease in the number of units of compute nodes shipped and a 3% decline in the average selling prices per node. The decline in the number of units of compute nodes shipped was due to fewer shipments of multimode systems, such as blades and twin systems, compared to the same period last year.

[0001375365-20-000033:mdna:45]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the volume of subsystems and accessories units sold by approximately 38% mainly due to increased demand from our indirect sales channel, which was offset by an approximately 5% decrease in the average selling price.

[0001375365-20-000033:mdna:46]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:47]
The period-over-period decrease in net sales of our server and storage systems was primarily due to a decrease in average selling prices per compute node by approximately 13% as well as a slight decrease in the number of units of compute nodes shipped. The decline in average selling prices was primarily due to substantially lower costs for key components in the first two quarters of the fiscal year.

[0001375365-20-000033:mdna:48]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the volume of subsystems and accessories sold by approximately 35%, partially offset by a decrease in the average selling prices per unit by approximately 12%.

[0001375365-20-000033:mdna:49]
The following table presents net sales from products sold through our indirect sales channel and to our direct customers and OEMs customers for the three and nine months ended March 31, 2020 and 2019 (dollars in millions):

[0001375365-20-000033:mdna:50]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Indirect sales channel | $ | 446.0 |  |  | $ | 284.2 |  |  | $ | 161.8 |  |  | 56.9 | % |  | $ | 1,292.5 |  |  | $ | 998.0 |  |  | $ | 294.5 |  |  | 29.5 | % |
| Percentage of total net sales | 57.7 | % |  | 38.2 | % |  |  |  |  |  | 52.9 | % |  | 37.7 | % |  |  |  |  |
| Direct customers and OEMs | 326.4 |  |  | 459.3 |  |  | (132.9 | ) |  | (28.9 | )% |  | 1,150.7 |  |  | 1,648.1 |  |  | (497.4 | ) |  | (30.2 | )% |
| Percentage of total net sales | 42.3 | % |  | 61.8 | % |  |  |  |  |  | 47.1 | % |  | 62.3 | % |  |  |  |  |
| Total net sales | $ | 772.4 |  |  | $ | 743.5 |  |  | $ | 28.9 |  |  | 3.9 | % |  | $ | 2,443.2 |  |  | $ | 2,646.1 |  |  | $ | (202.9 | ) |  | (7.7 | )% |

[0001375365-20-000033:mdna:51]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:52]
The period-over-period increase in net sales through our indirect sales channel was primarily due to increased demand from indirect sales channel partners supporting large end users and the lower average selling prices for our server and storage systems, caused by fewer multimode systems shipped and slightly lower component pricing.  The period-over-period decrease in net sales to our direct customers and OEMs was primarily due to a decline in demand from our internet datacenter and cloud customers and our enterprise datacenter customers.

[0001375365-20-000033:mdna:53]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:54]
The period-over-period increase in net sales through our indirect sales channel was primarily due to increased demand from the channel supporting large end users and the lower average selling prices for our server and storage systems, caused by lower component pricing. The period-over-period decrease in net sales to our direct customers and OEMs was primarily due to a decline in demand from our internet datacenter and cloud customers and our enterprise datacenter customers.

[0001375365-20-000033:mdna:55]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2020 and 2019 (dollars in millions):

[0001375365-20-000033:mdna:56]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| United States | $ | 422.9 |  |  | $ | 436.7 |  |  | $ | (13.8 | ) |  | (3.2 | )% |  | $ | 1,419.1 |  |  | $ | 1,516.3 |  |  | $ | (97.2 | ) |  | (6.4 | )% |
| Percentage of total net sales | 54.8 | % |  | 58.7 | % |  |  |  |  |  | 58.1 | % |  | 57.3 | % |  |  |  |  |
| Europe | 158.1 |  |  | 128.8 |  |  | 29.3 |  |  | 22.7 | % |  | 433.8 |  |  | 472.3 |  |  | (38.5 | ) |  | (8.2 | )% |
| Percentage of total net sales | 20.5 | % |  | 17.3 | % |  |  |  |  |  | 17.8 | % |  | 17.8 | % |  |  |  |  |
| Asia | 160.5 |  |  | 146.1 |  |  | 14.4 |  |  | 9.9 | % |  | 487.8 |  |  | 549.3 |  |  | (61.5 | ) |  | (11.2 | )% |
| Percentage of total net sales | 20.8 | % |  | 19.7 | % |  |  |  |  |  | 20.0 | % |  | 20.8 | % |  |  |  |  |
| Others | 30.9 |  |  | 31.9 |  |  | (1.0 | ) |  | (3.1 | )% |  | 102.5 |  |  | 108.2 |  |  | (5.7 | ) |  | (5.3 | )% |
| Percentage of total net sales | 4.0 | % |  | 4.3 | % |  |  |  |  |  | 4.2 | % |  | 4.1 | % |  |  |  |  |
| Total net sales | $ | 772.4 |  |  | $ | 743.5 |  |  |  |  |  |  | $ | 2,443.2 |  |  | $ | 2,646.1 |  |  |  |  |  |

[0001375365-20-000033:mdna:57]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:58]
The period-over-period decrease in net sales in the United States for the three months ended March 31, 2020 and 2019 was primarily due to lower sales of our server and storage systems to our direct customers and OEMs. The period-over-period increase in net sales in Asia was due primarily to increased sales in Singapore, Taiwan and Korea, partially offset by decreased sales in Japan and China. The increase of net sales in Europe was primarily due to higher sales in the United Kingdom, Germany, Hungary and the Netherlands, partially offset by decreased sales in France and Turkey.

[0001375365-20-000033:mdna:59]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:60]
The period-over-period decrease in net sales in the United States for the three months ended March 31, 2020 and 2019 was primarily due to lower sales of our server and storage systems to our direct customers and OEMs and decreased sales through our indirect sales channel. The period-over-period decrease in net sales in Asia was due primarily to decreased sales in China, Indonesia and Japan, partially offset by increased sales in Taiwan, Korea and Vietnam. The decrease in net sales in Europe was primarily due to lower sales in the Netherlands, United Kingdom and France, partially offset by increased sales in Russia, Germany and Hungary. The period-over-period decrease in net sales in other countries was due to decreased sales in Australia and Israel, partially offset by increased sales in Mexico and Saudi Arabia.

[0001375365-20-000033:mdna:61]
We determined that COVID-19 has impacted certain of our customers’ ability to pay on a timely basis. Our collectibility assessment resulted in delaying revenue recognition of $3.4 million for certain orders shipped during the three months ended March 31, 2020. The impact of COVID-19 on future revenue may be more significant.

[0001375365-20-000033:mdna:62]
[same as prior period, unchanged from 0001375365-20-000011:mdna:52]

[0001375365-20-000033:mdna:63]
Cost of sales and gross margin for the three and nine months ended March 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000033:mdna:64]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Cost of sales | $ | 639.0 |  |  | $ | 631.2 |  |  | $ | 7.8 |  |  | 1.2 | % |  | $ | 2,040.5 |  |  | $ | 2,282.6 |  |  | $ | (242.1 | ) |  | (10.6 | )% |
| Gross profit | $ | 133.4 |  |  | $ | 112.3 |  |  | $ | 21.1 |  |  | 18.8 | % |  | $ | 402.7 |  |  | $ | 363.5 |  |  | $ | 39.2 |  |  | 10.8 | % |
| Gross margin | 17.3 | % |  | 15.1 | % |  |  |  | 2.2 | % |  | 16.5 | % |  | 13.7 | % |  |  |  | 2.8 | % |

[0001375365-20-000033:mdna:65]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:66]
The period-over-period increase in cost of sales was primarily attributable to an increase of $6.4 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales, an increase of $4.8 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $2.9 million, an

[0001375365-20-000033:mdna:67]
increase of $1.0 million in product service costs and an increase of $2.0 million in manufacturing and other costs, offset by a decrease of $6.6 million in inventory obsolescence costs.

[0001375365-20-000033:mdna:68]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components we purchased. We expect that an increase in logistics costs and additional inducements for employees to continue production will negatively impact our gross margins due to the COVID-19 pandemic.

[0001375365-20-000033:mdna:69]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:70]
The period-over-period decrease in cost of sales was primarily attributable to a decrease of $259.5 million in costs of materials and contract manufacturing expenses primarily related to the decrease in net sales and the decrease in the cost of key components primarily associated with server and storage systems and a decrease of $6.5 million in inventory obsolescence costs, offset by an increase of $7.2 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $2.9 million, an increase in overhead costs of $10.2 million primarily attributable to increased tariffs, an increase of $1.8 million in product service costs, an increase of $1.4 million in warranty expense and an increase of $3.8 million in manufacturing and other costs.

[0001375365-20-000033:mdna:71]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components we purchased. We expect that an increase in logistics costs and additional inducements for employees to continue production will negatively impact our gross margins due to the COVID-19 pandemic.

[0001375365-20-000033:mdna:72]
[same as prior period, unchanged from 0001375365-20-000011:mdna:62]

[0001375365-20-000033:mdna:73]
Operating expenses for the three and nine months ended March 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000033:mdna:74]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Research and development | $ | 49.6 |  |  | $ | 44.8 |  |  | $ | 4.8 |  |  | 10.7 | % |  | $ | 154.7 |  |  | $ | 133.7 |  |  | $ | 21.0 |  |  | 15.7 | % |
| Percentage of total net sales | 6.4 | % |  | 6.0 | % |  |  |  |  |  | 6.3 | % |  | 5.1 | % |  |  |  |  |
| Sales and marketing | $ | 21.9 |  |  | $ | 18.5 |  |  | $ | 3.4 |  |  | 18.4 | % |  | $ | 64.1 |  |  | $ | 56.5 |  |  | $ | 7.6 |  |  | 13.5 | % |
| Percentage of total net sales | 2.8 | % |  | 2.5 | % |  |  |  |  |  | 2.6 | % |  | 2.1 | % |  |  |  |  |
| General and administrative | $ | 46.3 |  |  | $ | 36.2 |  |  | $ | 10.1 |  |  | 27.9 | % |  | $ | 107.7 |  |  | $ | 106.2 |  |  | $ | 1.5 |  |  | 1.4 | % |
| Percentage of total net sales | 6.0 | % |  | 4.9 | % |  |  |  |  |  | 4.4 | % |  | 4.0 | % |  |  |  |  |
| Total operating expenses | $ | 117.8 |  |  | $ | 99.5 |  |  | $ | 18.3 |  |  | 18.4 | % |  | $ | 326.5 |  |  | $ | 296.4 |  |  | $ | 30.1 |  |  | 10.2 | % |
| Percentage of total net sales | 15.3 | % |  | 13.4 | % |  |  |  |  |  | 13.4 | % |  | 11.2 | % |  |  |  |  |

[0001375365-20-000033:mdna:75]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:76]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $13.0 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $5.3 million, a decrease of $0.5 million in reimbursements received for certain research and development costs that we incur as part of the joint product development and an increase of $0.8 million in facilities and other expenses. During the three months ended March 31, 2020, we also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement. We expect that research and development costs will increase as a result of additional inducements for employees who must work on-site to further our new product development for the duration of the “shelter in place” directives issued by the local authorities during the COVID-19 pandemic.

[0001375365-20-000033:mdna:77]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to an increase of $3.0 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $1.0 million.

[0001375365-20-000033:mdna:78]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to the expense accrual in the quarter ended March 31, 2020 for a potential SEC settlement of $17.5 million, an increase of $4.5 million in personnel expenses, including an increase in the number of personnel and a one-time performance bonus of $1.1 million, an increase of $1.0 million in insurance expense and an increase of $0.7 million in other general and

[0001375365-20-000033:mdna:79]
administrative expenses, offset by a decrease of $13.8 million in professional fees primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements.

[0001375365-20-000033:mdna:80]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:81]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $23.7 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $5.3 million, a decrease of $1.2 million in reimbursements received for certain research and development costs that we incur as part of joint product development, an increase of $2.8 million in costs mainly related to materials and supplies used in product development, and an increase of $1.9 million in facilities and other expenses. During the three months ended March 31, 2020, we also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement. We expect that research and development costs will increase as a result of additional inducements for employees who must work on-site to further our new product development for the duration of the “shelter in place” directives issued by the local authorities during the COVID-19 pandemic.

[0001375365-20-000033:mdna:82]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to an increase of $5.7 million in personnel expenses as a result of an increase in the number of personnel and a one-time performance bonus of $1.0 million, an increase of $0.8 million related to participation in trade shows and an increase of $1.1 million in expenses related to advertising and promotion activities.

[0001375365-20-000033:mdna:83]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to the expense accrual in the quarter ended March 31, 2020 for a potential SEC settlement fee of $17.5 million, an increase of $7.7 million in personnel expenses, including an increase in the number of personnel and a one-time performance bonus of $1.1 million and an increase of $2.5 million in insurance expense, offset by a decrease of $26.4 million in professional fees primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements.

[0001375365-20-000033:mdna:84]
[same as prior period, unchanged from 0001375365-20-000011:mdna:73]

[0001375365-20-000033:mdna:85]
[same as prior period, unchanged from 0001375365-20-000011:mdna:74]

[0001375365-20-000033:mdna:86]
[same as prior period, unchanged from 0001375365-20-000011:mdna:75]

[0001375365-20-000033:mdna:87]
Interest and other income (expense), net for the three and nine months ended March 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000033:mdna:88]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Other income (expense), net | $ | 0.9 |  |  | $ | (0.1 | ) |  | $ | 1.0 |  |  | (1,000.0 | )% |  | $ | 2.1 |  |  | $ | 0.7 |  |  | $ | 1.4 |  |  | 200.0 | % |
| Interest expense | (0.5 | ) |  | (1.3 | ) |  | 0.8 |  |  | (61.5 | )% |  | (1.6 | ) |  | (5.5 | ) |  | 3.9 |  |  | (70.9 | )% |
| Interest and other income (expense), net | $ | 0.4 |  |  | $ | (1.4 | ) |  | $ | 1.8 |  |  | (128.6 | )% |  | $ | 0.5 |  |  | $ | (4.8 | ) |  | $ | 5.3 |  |  | (110.4 | )% |

[0001375365-20-000033:mdna:89]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:90]
The period-over-period change in interest expense was due to a decrease of $0.8 million in interest expense primarily as a result of lower interest rates in the three months ended March 31, 2020 as compared to the three months ended March 31, 2019. The change of $1.0 million in other income (expense), net was attributable to an increase of $0.3 million in interest income on our interest bearing deposits and a decrease of $0.6 million in other expenses.

[0001375365-20-000033:mdna:91]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:92]
The period-over-period change in interest expense was due to a decrease of $3.9 million in interest expense primarily as a result of lower interest rates in the nine months ended March 31, 2020 as compared to the nine months ended March 31, 2019. The change of $1.4 million in other income (expense), net was attributable to an increase of $1.6 million in interest

[0001375365-20-000033:mdna:93]
income on our interest bearing deposits and a decrease of $0.6 million in other expenses, offset by change of $(0.9) million related to foreign exchange losses due to unfavorable foreign currency fluctuations.

[0001375365-20-000033:mdna:94]
Provision (Benefit) for Income Taxes

[0001375365-20-000033:mdna:95]
Provision (benefit) for income taxes and effective tax rates for the three and nine months ended March 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-20-000033:mdna:96]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Income tax (benefit) provision | $ | (0.9 | ) |  | $ | 0.5 |  |  | $ | (1.4 | ) |  | (280.0 | )% |  | $ | 9.8 |  |  | $ | 10.5 |  |  | $ | (0.7 | ) |  | (6.7 | )% |
| Percentage of total net sales | (0.1 | )% |  | 0.1 | % |  |  |  |  |  | 0.4 | % |  | 0.4 | % |  |  |  |  |
| Effective tax rate | (5.6 | )% |  | 4.3 | % |  |  |  |  |  | 12.8 | % |  | 16.9 | % |  |  |  |  |

[0001375365-20-000033:mdna:97]
Comparison of Three Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:98]
The income tax benefit and effective tax rate change was primarily due to a tax benefit from the disqualified disposition of incentive stock options for the three months ended March 31, 2020.

[0001375365-20-000033:mdna:99]
Comparison of Nine Months Ended March 31, 2020 and 2019

[0001375365-20-000033:mdna:100]
The period-over-period decrease in effective tax rate was primarily due to a tax benefit from the disqualified disposition of incentive stock options for the nine months ended March 31, 2020.

[0001375365-20-000033:mdna:101]
[same as prior period, unchanged from 0001375365-20-000011:mdna:89]

[0001375365-20-000033:mdna:102]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $300.9 million and $248.2 million as of March 31, 2020 and June 30, 2019, respectively. Our cash in foreign locations was $90.2 million and $124.6 million as of March 31, 2020 and June 30, 2019, respectively.

[0001375365-20-000033:mdna:103]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-20-000033:mdna:104]
We believe that our current cash, cash equivalents, credit lines and internally generated cash flows will be generally sufficient to support our operating businesses, remediation efforts, maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements. We are in the process of negotiating an extension of our credit facility with Bank of America and expect this process will be completed by the end of May, 2020. Expected uses of our cash over the short term include our continued development of our innovative and resource saving products, manufacturing expansion in the United States and Taiwan and ongoing remediation of our material weaknesses in internal controls over financial reporting. We expect to pay one-time performance bonuses of approximately $25.3 million to employees in the fourth quarter of fiscal year 2020 and $8.5 million to other executives and members of the Board of Directors within the next two years when and if specified market and performance conditions will be met. In addition, we expect to make a one-time settlement payment of $17.5 million to the SEC in connection with the conclusion of the ongoing investigations.

[0001375365-20-000033:mdna:105]
[same as prior period, unchanged from 0001375365-20-000011:mdna:93]

[0001375365-20-000033:mdna:106]
|  | Nine Months Ended March 31, |  | Change |
|  | 2020 |  | 2019 |  |
| Net cash provided by operating activities | $ | 65.7 |  |  | $ | 180.7 |  |  | $ | (115.0 | ) |
| Net cash used in investing activities | $ | (34.1 | ) |  | $ | (15.8 | ) |  | $ | (18.3 | ) |
| Net cash provided by (used in) financing activities | $ | 25.4 |  |  | $ | (95.9 | ) |  | $ | 121.3 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 57.1 |  |  | $ | 68.9 |  |  | $ | (11.8 | ) |

[0001375365-20-000033:mdna:107]
[same as prior period, unchanged from 0001375365-20-000011:mdna:95]

[0001375365-20-000033:mdna:108]
Net cash provided by operating activities decreased by $115.0 million for the nine months ended March 31, 2020 as compared to the nine months ended March 31, 2019. The decrease was due primarily to an increase in net working capital of $129.7 million driven by increased inventories and prepaid expenses and other current assets, offset by an increase in net income for the current period of $17.7 million.

[0001375365-20-000033:mdna:109]
[same as prior period, unchanged from 0001375365-20-000011:mdna:98]

[0001375365-20-000033:mdna:110]
Net cash used in investing activities was $34.1 million and $15.8 million for the nine months ended March 31, 2020 and 2019, respectively, as we continued to invest in expanding our capacity and office space, including the expansion of our Green Computing Park in San Jose and offices in Taiwan. During the nine months ended March 31, 2020, we received $0.8 million from the sale of our investment in a privately held company.

[0001375365-20-000033:mdna:111]
[same as prior period, unchanged from 0001375365-20-000011:mdna:100]

[0001375365-20-000033:mdna:112]
Net cash provided by financing activities for the nine months ended March 31, 2020 was $25.4 million while net cash used in financing activities for the nine months ended March 31, 2019 was $95.9 million. The change in cash flows from financing activities was primarily due to decreased debt repayments of $101.9 million and cash received for exercise of stock options of $23.1 million.

[0001375365-20-000033:mdna:113]
[same as prior period, unchanged from 0001375365-20-000011:mdna:102]

[0001375365-20-000033:mdna:114]
2018 Bank of America Credit Facility

[0001375365-20-000033:mdna:115]
We have a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility”) for up to $250.0 million, which expires in June 30, 2020. Prior to its maturity, if certain conditions are satisfied, we may convert it into a five-year revolving credit facility for up to $400.0 million. As of March 31, 2020, we had no outstanding borrowings and we had a $6.4 million letter of credit outstanding under this facility. Our available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets and we are not permitted to repurchase our shares or pay any dividends. We were in compliance with all covenants as of March 31, 2020. We are in the process of negotiating an extension of our credit facility with Bank of America and expect this process will be completed by the end of May, 2020.

[0001375365-20-000033:mdna:116]
2019 CTBC Credit Facility

[0001375365-20-000033:mdna:117]
In June 2019, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans denominated in NTD of up to $50.0 million and expires in June 2020. During the three months ended March 31, 2020, we borrowed $10.0 million under the revolving line of credit. The total outstanding borrowings under the 2019 CTBC Credit Facility were $33.2 million with maturity on June 30, 2020. The amount available for future borrowing was $16.8 million as of March 31, 2020. The interest rate for these outstanding term loans was 0.91% per annum as of March 31, 2020. Term loans are secured by various Company’s assets, including certain property, plant, and equipment. There are no financial covenants under the 2019 CTBC Credit Facility.

[0001375365-20-000033:mdna:118]
Refer to Part I, Item 1, Note 7, “Short-term Debt,” in our notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding debt.

[0001375365-20-000033:mdna:119]
[same as prior period, unchanged from 0001375365-20-000011:mdna:122]

[0001375365-20-000033:mdna:120]
[same as prior period, unchanged from 0001375365-20-000011:mdna:123]

[0001375365-20-000033:mdna:121]
[same as prior period, unchanged from 0001375365-20-000011:mdna:124]

[0001375365-20-000033:mdna:122]
[same as prior period, unchanged from 0001375365-20-000011:mdna:125]

[0001375365-20-000033:mdna:123]
44
