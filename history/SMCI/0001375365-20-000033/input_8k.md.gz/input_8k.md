# SMCI 8-K — 0001375365-20-000030 filed 2020-05-07

## item codes, every 8-K on or before 2020-05-11

- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2020-05-11

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-20-000030:8k_2_02:1]
EX-99.1
2
exhibit99120200507.htm
EXHIBIT 99.1

[0001375365-20-000030:8k_2_02:2]
Exhibit

[0001375365-20-000030:8k_2_02:3]
Exhibit 99.1

[0001375365-20-000030:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2020

[0001375365-20-000030:8k_2_02:5]
Financial Results

[0001375365-20-000030:8k_2_02:6]
SAN JOSE, Calif. -- May 7, 2020 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced financial results for its third quarter of fiscal year 2020 ended March 31, 2020.

[0001375365-20-000030:8k_2_02:7]
Third Quarter Fiscal Year 2020 Highlights

[0001375365-20-000030:8k_2_02:8]
| • | Net sales of $772 million versus $871 million in the second quarter of fiscal year 2020 and $744 million in the same quarter of last year. |

[0001375365-20-000030:8k_2_02:9]
| • | Gross margin of 17.3% versus 15.9% in the second quarter of fiscal year 2020 and 15.1% in the same quarter of last year. |

[0001375365-20-000030:8k_2_02:10]
| • | Net income of $16 million versus $24 million in the second quarter of fiscal year 2020 and $11 million in the same quarter of last year. |

[0001375365-20-000030:8k_2_02:11]
| • | Diluted net income per common share of $0.29 versus $0.46 in the second quarter of fiscal year 2020 and $0.21 in the same quarter of last year. |

[0001375365-20-000030:8k_2_02:12]
| • | Non-GAAP diluted net income per common share of $0.84 versus $0.57 in the second quarter of fiscal year 2020 and $0.49 in the same quarter of last year. |

[0001375365-20-000030:8k_2_02:13]
| • | Cash flow used in operations of $21 million and capital expenditures of $11 million. |

[0001375365-20-000030:8k_2_02:14]
Income from operations in the third quarter of fiscal year 2020 benefited by a $10.1 million settlement fee related to a joint

[0001375365-20-000030:8k_2_02:15]
product development agreement.  After the related tax effect, GAAP and non-GAAP net income per common share on a

[0001375365-20-000030:8k_2_02:16]
diluted basis benefited by $0.14.

[0001375365-20-000030:8k_2_02:17]
Non-GAAP gross margin for the third quarter of fiscal year 2020 was 17.7%, which adds back stock-based compensation expenses of $0.4 million and one-time employee performance bonuses of $2.9 million. Non-GAAP diluted net income per common share for the third quarter of fiscal year 2020 was $0.84, which adds back stock-based compensation expenses of $4.8 million, one-time employee performance bonuses of $10.3 million, legal settlement costs of $17.5 million, and other non-recurring expenses of $1.4 million less the related tax effects.

[0001375365-20-000030:8k_2_02:18]
As of March 31, 2020, total cash, cash equivalents and restricted cash was $319 million and bank debt was $33 million.

[0001375365-20-000030:8k_2_02:19]
“We were pleased to deliver Q3 revenue that grew 4% year-over-year despite the disruptions to our operations from the impact of COVID-19," said Charles Liang, Chairman and CEO. "Our highest priority remains the health and security of our employees, customers and partners, and I want to personally thank them all for their perseverance during this challenging time. While the business environment remains dynamic, we remain focused on our longer-term priorities and helping our customers capitalize on rapidly growing applications such as Artificial Intelligence, 5G / Edge, and Cloud, the adoption of all which is accelerating as a result of the global pandemic. Our pipeline of innovation is more vibrant than ever with new server products leveraging the latest generation of Xeon processors from Intel and EPYC processors from AMD, Outdoor Edge systems for 5G, and high-volume, cost-effective systems for large Data Center operators. Supermicro remains ready and eager to help its customers meet their evolving strategic priorities, whatever challenges may come."

[0001375365-20-000030:8k_2_02:20]
Fourth Quarter Fiscal Year 2020 Guidance

[0001375365-20-000030:8k_2_02:21]
Given the uncertainties related to COVID-19, Supermicro will not provide guidance for the fourth quarter of fiscal year 2020.

[0001375365-20-000030:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-20-000030:8k_2_02:23]
discussed under the caption "Risk Factors" in such filings, particularly in our Annual Report on Form 10-K for our fiscal year ended June 30, 2019 and our Quarterly Report on Form 10-Q for our quarterly period ended December 31, 2019.

[0001375365-20-000030:8k_2_02:24]
Use of Non-GAAP Financial Measures

[0001375365-20-000030:8k_2_02:25]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and one-time employee performance bonuses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, one-time employee performance bonuses, legal settlement costs, other non-recurring expenses, and the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-20-000030:8k_2_02:26]
About Super Micro Computer, Inc.

[0001375365-20-000030:8k_2_02:27]
Supermicro (Nasdaq: SMCI), the leading innovator in high-performance, high-efficiency server technology is a premier provider of advanced Server Building Block Solutions® for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-20-000030:8k_2_02:28]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-20-000030:8k_2_02:29]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-20-000030:8k_2_02:30]
Investor Relations Contact

[0001375365-20-000030:8k_2_02:31]
James Kisner, Investor Relations

[0001375365-20-000030:8k_2_02:32]
(669) 284-1259

[0001375365-20-000030:8k_2_02:33]
email: ir@supermicro.com

[0001375365-20-000030:8k_2_02:34]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000030:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-20-000030:8k_2_02:36]
(in thousands)

[0001375365-20-000030:8k_2_02:37]
(unaudited)

[0001375365-20-000030:8k_2_02:38]
|  | March 31, |  | June 30, |
|  | 2020 |  | 2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 300,859 |  |  | $ | 248,164 |  |
| Accounts receivable, net of allowances | 333,172 |  |  | 393,624 |  |
| Inventories | 866,226 |  |  | 670,188 |  |
| Prepaid expenses and other current assets | 148,102 |  |  | 109,795 |  |
| Total current assets | 1,648,359 |  |  | 1,421,771 |  |
| Investment in equity investee | — |  |  | 1,701 |  |
| Property, plant and equipment, net | 230,477 |  |  | 207,337 |  |
| Deferred income taxes, net | 45,562 |  |  | 41,126 |  |
| Other assets | 35,838 |  |  | 10,659 |  |
| Total assets | $ | 1,960,236 |  |  | $ | 1,682,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 462,808 |  |  | $ | 360,470 |  |
| Accrued liabilities | 177,148 |  |  | 114,678 |  |
| Income taxes payable | 1,979 |  |  | 13,021 |  |
| Short-term debt | 33,158 |  |  | 23,647 |  |
| Deferred revenue | 109,730 |  |  | 94,153 |  |
| Total current liabilities | 784,823 |  |  | 605,969 |  |
| Deferred revenue, non-current | 95,752 |  |  | 109,266 |  |
| Other long-term liabilities | 41,266 |  |  | 26,183 |  |
| Total liabilities | 921,841 |  |  | 741,418 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.001 par value |  |  |  |
| Authorized shares: 100,000,000; Outstanding shares: 51,915,646 and 49,956,288 at March 31, 2020 and June 30, 2019, respectively |  |  |  |
| Issued shares: 53,248,771 and 51,289,413 at March 31, 2020 and June 30, 2019, respectively | 381,125 |  |  | 349,683 |  |
| Treasury stock (at cost), 1,333,125 shares at March 31, 2020 and June 30, 2019 | (20,491 | ) |  | (20,491 | ) |
| Accumulated other comprehensive loss | (166 | ) |  | (80 | ) |
| Retained earnings | 677,761 |  |  | 611,903 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,038,229 |  |  | 941,015 |  |
| Noncontrolling interest | 166 |  |  | 161 |  |
| Total stockholders’ equity | 1,038,395 |  |  | 941,176 |  |
| Total liabilities and stockholders’ equity | $ | 1,960,236 |  |  | $ | 1,682,594 |  |

[0001375365-20-000030:8k_2_02:39]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000030:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-20-000030:8k_2_02:41]
(in thousands, except share and per share amounts)

[0001375365-20-000030:8k_2_02:42]
(unaudited)

[0001375365-20-000030:8k_2_02:43]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | $ | 772,408 |  |  | $ | 743,499 |  |  | $ | 2,443,155 |  |  | $ | 2,646,126 |  |
| Cost of sales | 639,048 |  |  | 631,172 |  |  | 2,040,462 |  |  | 2,282,638 |  |
| Gross profit | 133,360 |  |  | 112,327 |  |  | 402,693 |  |  | 363,488 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 49,586 |  |  | 44,800 |  |  | 154,730 |  |  | 133,718 |  |
| Sales and marketing | 21,886 |  |  | 18,494 |  |  | 64,057 |  |  | 56,463 |  |
| General and administrative | 46,342 |  |  | 36,174 |  |  | 107,680 |  |  | 106,214 |  |
| Total operating expenses | 117,814 |  |  | 99,468 |  |  | 326,467 |  |  | 296,395 |  |
| Income from operations | 15,546 |  |  | 12,859 |  |  | 76,226 |  |  | 67,093 |  |
| Other income (expense), net | 937 |  |  | (86 | ) |  | 2,110 |  |  | 707 |  |
| Interest expense | (518 | ) |  | (1,271 | ) |  | (1,630 | ) |  | (5,480 | ) |
| Income before income tax provision | 15,965 |  |  | 11,502 |  |  | 76,706 |  |  | 62,320 |  |
| Income tax provision | 899 |  |  | (497 | ) |  | (9,782 | ) |  | (10,540 | ) |
| Share of loss from equity investee, net of taxes | (1,057 | ) |  | (359 | ) |  | (1,066 | ) |  | (3,572 | ) |
| Net income | $ | 15,807 |  |  | $ | 10,646 |  |  | $ | 65,858 |  |  | $ | 48,208 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 1.30 |  |  | $ | 0.97 |  |
| Diluted | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 1.26 |  |  | $ | 0.94 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 51,526 |  |  | 49,988 |  |  | 50,591 |  |  | 49,845 |  |
| Diluted | 53,693 |  |  | 51,558 |  |  | 52,399 |  |  | 51,557 |  |

[0001375365-20-000030:8k_2_02:44]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-20-000030:8k_2_02:45]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of sales | $ | 370 |  |  | $ | 390 |  |  | $ | 1,149 |  |  | $ | 1,256 |  |
| Research and development | 3,043 |  |  | 3,107 |  |  | 9,299 |  |  | 9,816 |  |
| Sales and marketing | 417 |  |  | 418 |  |  | 1,276 |  |  | 1,359 |  |
| General and administrative | 975 |  |  | 1,045 |  |  | 3,099 |  |  | 3,650 |  |
| Stock-based compensation expense | $ | 4,805 |  |  | $ | 4,960 |  |  | $ | 14,823 |  |  | $ | 16,081 |  |

[0001375365-20-000030:8k_2_02:46]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000030:8k_2_02:47]
SELECTED CASH FLOW INFORMATION

[0001375365-20-000030:8k_2_02:48]
(in thousands)

[0001375365-20-000030:8k_2_02:49]
(unaudited)

[0001375365-20-000030:8k_2_02:50]
|  | Nine Months EndedMarch 31, |
|  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 65,716 |  |  | $ | 180,700 |  |
| Net cash used in investing activities | (34,136 | ) |  | (15,781 | ) |
| Net cash provided (used in) financing activities | 25,381 |  |  | (95,943 | ) |
| Effect of exchange rate fluctuations on cash | 163 |  |  | (88 | ) |
| Net increase in cash, cash equivalents and restricted cash | 57,124 |  |  | 68,888 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 262,140 |  |  | 120,382 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 319,264 |  |  | $ | 189,270 |  |

[0001375365-20-000030:8k_2_02:51]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000030:8k_2_02:52]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000030:8k_2_02:53]
(in thousands, except share and per share amounts)

[0001375365-20-000030:8k_2_02:54]
(unaudited)

[0001375365-20-000030:8k_2_02:55]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP GROSS PROFIT | $ | 133,360 |  |  | $ | 112,327 |  |  | $ | 402,693 |  |  | $ | 363,488 |  |
| Add back stock-based compensation expenses | 370 |  |  | 390 |  |  | 1,149 |  |  | 1,256 |  |
| Add back one-time employee performance bonuses | 2,871 |  |  | — |  |  | 2,871 |  |  | — |  |
| Non-GAAP GROSS PROFIT | $ | 136,601 |  |  | $ | 112,717 |  |  | $ | 406,713 |  |  | $ | 364,744 |  |
| GAAP GROSS MARGIN | 17.3 | % |  | 15.1 | % |  | 16.5 | % |  | 13.7 | % |
| Add back stock-based compensation expenses | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  | 0.1 | % |
| Add back one-time employee performance bonuses | 0.4 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 17.7 | % |  | 15.2 | % |  | 16.6 | % |  | 13.8 | % |
| GAAP INCOME FROM OPERATIONS | $ | 15,546 |  |  | $ | 12,859 |  |  | $ | 76,226 |  |  | $ | 67,093 |  |
| Add back stock-based compensation expenses | 4,805 |  |  | 4,960 |  |  | 14,823 |  |  | 16,081 |  |
| Add back legal settlement costs | 17,500 |  |  | — |  |  | 17,500 |  |  | — |  |
| Add back one-time employee performance bonuses | 10,329 |  |  | — |  |  | 10,329 |  |  | — |  |
| Add back controls remediation | 1,440 |  |  | 14,142 |  |  | 12,859 |  |  | 46,553 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 49,620 |  |  | $ | 31,961 |  |  | $ | 131,737 |  |  | $ | 129,727 |  |
| GAAP NET INCOME | $ | 15,807 |  |  | $ | 10,646 |  |  | 65,858 |  |  | $ | 48,208 |  |
| Add back stock-based compensation expenses | 4,805 |  |  | 4,960 |  |  | 14,823 |  |  | 16,081 |  |
| Add back legal settlement costs | 17,500 |  |  | — |  |  | 17,500 |  |  | — |  |
| Add back one-time employee performance bonuses | 10,329 |  |  | — |  |  | 10,329 |  |  | — |  |
| Add back controls remediation | 1,440 |  |  | 14,142 |  |  | 12,859 |  |  | 46,553 |  |
| Add back impairment of an investment | — |  |  | 661 |  |  | — |  |  | 661 |  |
| Less adjustments to tax provision | (3,812 | ) |  | (4,678 | ) |  | (8,868 | ) |  | (14,977 | ) |
| Non-GAAP NET INCOME | $ | 46,069 |  |  | $ | 25,731 |  |  | $ | 112,501 |  |  | $ | 96,526 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 1.30 |  |  | $ | 0.97 |  |
| Add back stock-based compensation expenses, legal settlement costs, one-time employee performance bonuses, controls remediation, impairment of an investment, less adjustments to tax provision | 0.58 |  |  | 0.30 |  |  | 0.92 |  |  | 0.97 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.89 |  |  | $ | 0.51 |  |  | $ | 2.22 |  |  | $ | 1.94 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 1.26 |  |  | $ | 0.94 |  |
| Add back stock-based compensation expenses, legal settlement costs, one-time employee performance bonuses, controls remediation, impairment of an investment, less adjustments to tax provision | 0.55 |  |  | 0.28 |  |  | 0.83 |  |  | 0.88 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.84 |  |  | $ | 0.49 |  |  | $ | 2.09 |  |  | $ | 1.82 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 51,526 |  |  | 49,988 |  |  | 50,591 |  |  | 49,845 |  |

[0001375365-20-000030:8k_2_02:56]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000030:8k_2_02:57]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000030:8k_2_02:58]
(in thousands, except share and per share amounts)

[0001375365-20-000030:8k_2_02:59]
(unaudited)

[0001375365-20-000030:8k_2_02:60]
| BASIC - Non-GAAP | 51,526 |  |  | 49,988 |  |  | 50,591 |  |  | 49,845 |  |
| DILUTED – GAAP | 53,693 |  |  | 51,558 |  |  | 52,399 |  |  | 51,557 |  |
| DILUTED - Non-GAAP | 55,050 |  |  | 53,048 |  |  | 53,913 |  |  | 53,017 |  |
