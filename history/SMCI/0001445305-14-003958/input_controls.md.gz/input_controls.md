# SMCI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001445305-14-003958:item_9a:1]
Item 9A.    Controls and Procedures

[0001445305-14-003958:item_9a:2]
Evaluation of Effectiveness of Disclosure Controls and Procedures

[0001445305-14-003958:item_9a:3]
We are committed to maintaining disclosure controls and procedures designed to ensure that information required to be disclosed in our periodic reports filed under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure.

[0001445305-14-003958:item_9a:4]
Under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, we evaluated the effectiveness of our disclosure controls and procedures, as such term is defined in Rule 13a-15(e) and 15d-15(e) promulgated under the Exchange Act. The evaluation considered the procedures designed to ensure that information required to be disclosed by us in the reports filed or submitted by us under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were effective at a reasonable assurance level as of June 30, 2014.

[0001445305-14-003958:item_9a:5]
Changes in Internal Control over Financial Reporting

[0001445305-14-003958:item_9a:6]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) identified in connection with the evaluation described in this Item 9A that occurred during the fourth quarter of fiscal year 2014 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001445305-14-003958:item_9a:7]
Inherent Limitations on Internal Control

[0001445305-14-003958:item_9a:8]
A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of management override or improper acts, if any, have been detected. These inherent limitations include the realities that judgments in decision making can be faulty, and that breakdowns can occur because of simple errors or mistakes. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The design of any system of controls is also based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Because of the inherent limitations in a cost-effective control system, misstatements due to management override, error or improper acts may occur and not be detected. Any resulting misstatement or loss may have an adverse and material effect on our business, financial condition and results of operations.

[0001445305-14-003958:item_9a:9]
Management’s Report on Internal Control over Financial Reporting

[0001445305-14-003958:item_9a:10]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the criteria set forth in Internal Control – Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (1992 framework). Based on our evaluation, our management has concluded that our internal control over financial reporting was effective as of June 30, 2014 to provide reasonable assurance regarding the reliability of financial reporting and preparation of consolidated financial statements for external reporting purposes in accordance with U.S. generally accepted accounting principles. The effectiveness of our internal control over financial reporting as of June 30, 2014 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, and their opinion is stated in their report which is included in this Annual Report on Form 10-K.

[0001445305-14-003958:item_9a:11]
70

[0001445305-14-003958:item_9a:12]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001445305-14-003958:item_9a:13]
To the Board of Directors and Stockholders of

[0001445305-14-003958:item_9a:14]
Super Micro Computer, Inc.

[0001445305-14-003958:item_9a:15]
San Jose, California

[0001445305-14-003958:item_9a:16]
We have audited the internal control over financial reporting of Super Micro Computer, Inc. and subsidiaries (the “Company”) as of June 30, 2014, based on the criteria established in Internal Control—Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission. The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit.

[0001445305-14-003958:item_9a:17]
We conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001445305-14-003958:item_9a:18]
A company’s internal control over financial reporting is a process designed by, or under the supervision of, the company’s principal executive and principal financial officers, or persons performing similar functions, and effected by the company’s board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001445305-14-003958:item_9a:19]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001445305-14-003958:item_9a:20]
In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2014, based on the criteria established in Internal Control—Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001445305-14-003958:item_9a:21]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements as of and for the year ended June 30, 2014 of the Company and our report dated September 15, 2014 expressed an unqualified opinion on those financial statements and included an explanatory paragraph relating to significant related party transactions.

[0001445305-14-003958:item_9a:22]
/s/ Deloitte & Touche LLP

[0001445305-14-003958:item_9a:23]
San Jose, California

[0001445305-14-003958:item_9a:24]
September 15, 2014

[0001445305-14-003958:item_9a:25]
WEST\249206192.2                                           71
