# SMCI MD&A — 0001445305-14-003958


## mdna

[0001445305-14-003958:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001445305-14-003958:mdna:2]
Overview

[0001445305-14-003958:mdna:3]
We are a global leader in high-performance, high-efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the Data Center, Cloud Computing, Enterprise IT, Big Data, HPC and Embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. For fiscal years 2014, 2013 and 2012, net sales of optimized servers were $740.8 million, $501.9 million and $447.0 million, respectively, and net sales of subsystems and accessories were $726.4 million, $660.7 million and $566.9 million, respectively. The increase in fiscal year 2014 compared with fiscal year 2013 was primarily due to increased sales of our products optimized for the storage, HPC, Cloud Computing, Data Center and OEM verticals. In addition, the percentage of our net sales represented by sales of complete server systems increased to 50.5% in fiscal year 2014 from 43.2% in fiscal year 2013. We also benefited from the technology transition from Intel's Sandybridge to Ivybridge processor in fiscal year 2014.

[0001445305-14-003958:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2014, 2013 and 2012, our net sales were $1,467.2 million, $1,162.6 million and $1,013.9 million, respectively, and our net income was $54.2 million, $21.3 million and $29.9 million, respectively. Our increase in net income in fiscal year 2014 was primarily attributable to an increase in our gross profit resulting primarily from higher sales of server systems and higher utilization of our manufacturing facilities in Taiwan, partially offset by higher research and development expenses.

[0001445305-14-003958:mdna:5]
We sell our server systems and subsystems and accessories primarily through distributors and to a lesser extent to OEMs as well as through our direct sales force. For fiscal years 2014, 2013 and 2012, we derived 54.1%, 56.3% and 54.4%, respectively, of our net sales from products sold to distributors, and derived 45.9%, 43.7% and 45.6% from sales to OEMs and to end customers, respectively. None of our customers accounted for 10% or more of our net sales in fiscal years 2014, 2013 and 2012. For fiscal years 2014, 2013 and 2012, we derived 55.2%, 54.2% and 58.2%, respectively, of our net sales from customers in the United States.

[0001445305-14-003958:mdna:6]
We perform the majority of our research and development efforts in-house. For fiscal years 2014, 2013 and 2012, research and development expenses represented 5.7%, 6.5% and 6.3% of our net sales, respectively.

[0001445305-14-003958:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2014, we continued to increase manufacturing and service operations in Taiwan and the Netherlands to support our Asian and European customers and we have increased our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For fiscal years 2014, 2013 and 2012, our purchases from Ablecom represented 16.3%, 17.9% and 19.9% of our cost of sales, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001445305-14-003958:mdna:8]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding, or DSOs. In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with

[0001445305-14-003958:mdna:9]
WEST\249206192.2                                           25

[0001445305-14-003958:mdna:10]
microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures. For example, in fiscal year 2012 and in prior years, our results have been adversely impacted by customer order delays in anticipation of the introduction of the new lines of microprocessors and research and development expenditures necessary for us to prepare for the introduction.

[0001445305-14-003958:mdna:11]
Other Financial Highlights

[0001445305-14-003958:mdna:12]
The following is a summary of other financial highlights of fiscal year 2014:

[0001445305-14-003958:mdna:13]
| • | Net cash provided by operating activities was $6.5 million, $13.6 million and $16.5 million in fiscal year 2014, 2013 and 2012, respectively. Our cash and cash equivalents, together with our investments, were $99.6 million at the end of fiscal year 2014, compared with $95.7 million at the end of fiscal year 2013. The increase in our cash and cash equivalents, together with our investments at the end of fiscal year 2014 was primarily due to $6.5 million of cash generated from our operating activities, $23.9 million of proceeds from the exercise of stock options and $11.0 million of borrowings, net of repayments, offset in part by $40.6 million of purchases of property and equipment. |

[0001445305-14-003958:mdna:14]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of fiscal year 2014 was 44 days, compared with 39 days at the end of fiscal year 2013. The increase in our DSO was primarily due to an increase in sales late in the quarter. |

[0001445305-14-003958:mdna:15]
| • | Our inventory balance was $315.8 million at the end of fiscal year 2014, compared with $254.2 million at the end of fiscal year 2013. Days sales of inventory (“DSI”) at the end of fiscal year 2014 was 83 days, compared with 95 days at the end of fiscal year 2013. The increase in our inventory was to support our anticipated level of growth in net sales in fiscal year 2015. |

[0001445305-14-003958:mdna:16]
| • | Our purchase commitments with contract manufacturers and suppliers were $211.1 million at the end of fiscal year 2014 and $249.0 million at the end of fiscal year 2013. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $45.2 million, which have terms expiring through December 2014. See Note 12 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of purchase commitments. |

[0001445305-14-003958:mdna:17]
| • | On October 31, 2013, we completed the purchase of real property in San Jose, California for $30.2 million. The property consists of approximately 324,000 square feet of building space on 36 acres of land. In connection with the purchase, we also engaged several contractors for the development and construction of improvements on the property that will serve as our Green Computing Park. We plan to develop five manufacturing buildings and remodel one existing warehouse on the land in which two of the buildings and the improvement of the warehouse will be constructed through fiscal year 2016. |

[0001445305-14-003958:mdna:18]
Fiscal Year

[0001445305-14-003958:mdna:19]
Our fiscal year ends on June 30. References to fiscal year 2014, for example, refer to the fiscal year ended June 30, 2014.

[0001445305-14-003958:mdna:20]
WEST\249206192.2                                           26

[0001445305-14-003958:mdna:21]
Revenues and Expenses

[0001445305-14-003958:mdna:22]
Net sales. Net sales consist of sales of our server solutions, including server systems, subsystems and accessories. The main factors which impact our net sales are unit volumes shipped and average selling prices. The prices for server systems range widely depending upon the configuration, and the prices for our subsystems and accessories vary based on the type. As with most electronics-based products, average selling prices typically are highest at the time of introduction of new products which utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products.

[0001445305-14-003958:mdna:23]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally lower on server systems than on subsystems and accessories, but generally higher in the case of sales of server systems to internet data system customers. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001445305-14-003958:mdna:24]
Research and development expenses. Research and development expenses consist of the personnel and related expenses of our research and development teams, and materials and supplies, consulting services, third party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering, or NRE, funding from certain suppliers and customers. Under these programs, we are reimbursed for certain research and development costs that we incur as part of the joint development of our products and those of our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001445305-14-003958:mdna:25]
Sales and marketing expenses. Sales and marketing expenses consist primarily of salaries and incentive bonuses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these programs, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. Similarly, we from time to time offer our distributors cooperative marketing funding which has the effect of increasing our expenses. The timing, magnitude and estimated usage of our programs and those of our suppliers can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, either by us or our suppliers, typically increases in connection with significant product releases by us or our suppliers.

[0001445305-14-003958:mdna:26]
General and administrative expenses. General and administrative expenses consist primarily of general corporate costs, including personnel expenses, financial reporting, corporate governance and compliance and outside legal, audit and tax fees.

[0001445305-14-003958:mdna:27]
Interest and other expense, net. Interest and other expense, net represents interest expense on our term loans and line of credit, offset by interest earned on our investment and cash balances.

[0001445305-14-003958:mdna:28]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, currently primarily the United States, Taiwan, the Netherlands, and to a lesser extent, China and Japan. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, the domestic production activities deduction and lower taxes in foreign jurisdictions which were partially offset by the impact of state taxes and stock option expenses. In recent years, our effective tax rate from period to period has been significantly impacted by delays in the approval of extensions of the U.S. research and development tax credit. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Note 11 of Notes to Consolidated Financial Statements.

[0001445305-14-003958:mdna:29]
WEST\249206192.2                                           27

[0001445305-14-003958:mdna:30]
Critical Accounting Policies

[0001445305-14-003958:mdna:31]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, cooperative marketing accruals, investment valuations, inventory valuations, income taxes, warranty obligations and stock-based compensation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates.

[0001445305-14-003958:mdna:32]
We believe the following are our most critical accounting policies as they require our more significant judgments in the preparation of our financial statements.

[0001445305-14-003958:mdna:33]
Revenue recognition. We recognize revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. Our standard arrangement with our customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination. We generally do not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, we regularly review our history of actual returns for each major product line. We also communicate regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with our distributors.

[0001445305-14-003958:mdna:34]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At June 30, 2014 and 2013, we had deferred revenue of $7.7 million and $1.0 million and related deferred product costs of $6.7 million and $0.7 million, respectively, related to shipments to customers pending acceptances.

[0001445305-14-003958:mdna:35]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision for bad debt was $1.5 million, $0.9 million and $0.2 million in fiscal years 2014, 2013 and 2012, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001445305-14-003958:mdna:36]
We  have an immaterial amount of service revenue relating to on-site service and non-warranty repairs. Revenue for on-site service is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001445305-14-003958:mdna:37]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are

[0001445305-14-003958:mdna:38]
WEST\249206192.2                                           28

[0001445305-14-003958:mdna:39]
charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.1 million as of June 30, 2014, compared with $6.5 million as of June 30, 2013. The provision for warranty reserve was $14.2 million, $13.4 million and $12.2 million in fiscal years 2014, 2013 and 2012, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was $0.4 million, ($1,000) and $0.7 million in fiscal years 2014, 2013 and 2012, respectively. As a result of our increase in cost of servicing warranty claims from our increase in net sales in fiscal year 2014 and 2013, the provision for warranty reserve increased $0.7 million and $1.2 million in fiscal year 2014 and 2013, respectively. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001445305-14-003958:mdna:40]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $2.3 million, $9.7 million and $8.6 million in fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-003958:mdna:41]
Accounting for income taxes. We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying currently enacted tax laws. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001445305-14-003958:mdna:42]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related change in our tax provision during the period in which we make such determination. See Note 11 of Notes to Consolidated Financial Statements for the impact on our consolidated financial statements.

[0001445305-14-003958:mdna:43]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors including employee stock options and restricted stock awards based on estimated fair values. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. Compensation expense for options and restricted stock awards granted to employees was $11.1 million, $11.4 million and $10.3 million for the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:mdna:44]
As of June 30, 2014, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options granted since July 1, 2006 to employees and non-employee members of the Board of Directors, was $19.2 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.40 years. See Note 10 of Notes to our Consolidated Financial Statements for additional information.

[0001445305-14-003958:mdna:45]
We estimated the fair value of stock options granted using a Black-Scholes option-pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option, the expected volatility of the price of our common stock and the expected forfeiture rate. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001445305-14-003958:mdna:46]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and exercise behavior for the stock

[0001445305-14-003958:mdna:47]
WEST\249206192.2                                           29

[0001445305-14-003958:mdna:48]
options granted prior to June 30, 2011. For stock options and restricted stock awards granted after June 30, 2011, expected term is based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001445305-14-003958:mdna:49]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001445305-14-003958:mdna:50]
In May 2012, we and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of June 30, 2014, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In fiscal year 2014 and 2013, ($6,000) and $13,000 of net income (loss) attributable to Ablecom's interest was included in our general and administrative expenses in the consolidated statements of operations, respectively.

[0001445305-14-003958:mdna:51]
Results of Operations

[0001445305-14-003958:mdna:52]
The following table sets forth our financial results, as a percentage of net sales for the periods indicated:

[0001445305-14-003958:mdna:53]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.6 |  |  | 86.2 |  |  | 83.7 |  |
| Gross profit | 15.4 |  |  | 13.8 |  |  | 16.3 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 5.7 |  |  | 6.5 |  |  | 6.3 |  |
| Sales and marketing | 2.6 |  |  | 2.9 |  |  | 3.3 |  |
| General and administrative | 1.6 |  |  | 2.1 |  |  | 2.2 |  |
| Total operating expenses | 9.9 |  |  | 11.5 |  |  | 11.8 |  |
| Income from operations | 5.5 |  |  | 2.3 |  |  | 4.5 |  |
| Interest and other income, net | — |  |  | — |  |  | — |  |
| Interest expense | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Income before income tax provision | 5.4 |  |  | 2.2 |  |  | 4.5 |  |
| Income tax provision | 1.7 |  |  | 0.4 |  |  | 1.6 |  |
| Net income | 3.7 | % |  | 1.8 | % |  | 2.9 | % |

[0001445305-14-003958:mdna:54]
Comparison of Fiscal Years Ended June 30, 2014 and 2013

[0001445305-14-003958:mdna:55]
Net sales. Net sales increased by $304.6 million, or 26.2%, to $1,467.2 million from $1,162.6 million, for fiscal year 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001445305-14-003958:mdna:56]
For fiscal year 2014, the number of server system units sold increased 12.9% to 262,000 compared to 232,000 for fiscal year 2013. The average selling price of server system units increased 27.3% to $2,800 in fiscal year 2014 compared to

[0001445305-14-003958:mdna:57]
WEST\249206192.2                                           30

[0001445305-14-003958:mdna:58]
$2,200 in fiscal year 2013. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete integrated-high-end servers solutions to OEM and end customers, the Twin family of servers, storage and GPU/Xeon Phi servers which offered higher density computing and more memory and hard disk drive capacity.  Sales of server systems increased by $238.9 million or 47.6% from fiscal year 2013 to fiscal year 2014, primarily due to the increased sales of the products described above. In addition, our new server products based on Intel's Ivy Bridge processor, which was launched in September 2013, also contributed to our growth in server system sales in fiscal year 2014. Sales of server systems represented 50.5% of our net sales for fiscal year 2014 compared to 43.2% of our net sales for fiscal year 2013.

[0001445305-14-003958:mdna:59]
For fiscal year 2014, the number of subsystems and accessories units sold decreased 1.0% to 4.5 million compared to fiscal year 2013. Sales of subsystems and accessories increased by $65.7 million or 9.9% from fiscal year 2013 to fiscal year 2014, primarily related to higher sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who increasingly are purchasing additional accessories from us and completing the final assembly themselves. Sales of subsystems and accessories represented 49.5% of our net sales for fiscal year 2014 as compared to 56.8% of our net sales for fiscal year 2013.

[0001445305-14-003958:mdna:60]
For fiscal year 2014 and 2013, we derived 54.1% and 56.3%, respectively, of our net sales from products sold to distributors and we derived 45.9% and 43.7%, respectively, from sales to OEMs and to end customers. For fiscal year 2014, customers in the United States, Europe and Asia accounted for 55.2%, 21.6% and 20.4%, of our net sales, respectively, as compared to 54.2%, 22.7% and 20.5% of our net sales, respectively, for fiscal year 2013.

[0001445305-14-003958:mdna:61]
Cost of sales. Cost of sales increased by $239.1 million, or 23.9%, to $1,241.7 million from $1,002.5 million, for fiscal year 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 84.6% and 86.2% for fiscal year 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales partially offset by a decrease of $7.5 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to a lower provision for inventory reserve, an increase in purchasing power, an increase in the mix of server system sales and higher utilization of our manufacturing facilities in Taiwan, offset by higher sales to internet data center customers, which generally have a lower gross margin. In fiscal year 2014, we recorded a $2.3 million expense, net of recovery, or 0.2% of net sales, related to the inventory provision as compared to $9.7 million, or 0.8% of net sales, in fiscal year 2013. The decrease in the inventory provision was primarily due to lower inventory reserves for special items and higher sales of previously reserved inventory of $9.3 million as we have improved our processes and reduced our excess and slow moving inventory.

[0001445305-14-003958:mdna:62]
In fiscal year 2014, we recorded a $14.2 million expense, or 1.0% of net sales, related to the provision for warranty reserve as compared to $13.4 million, or 1.2% of net sales, in fiscal year 2013. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in fiscal year 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001445305-14-003958:mdna:63]
Research and development expenses. Research and development expenses increased by $9.0 million, or 12.0%, to $84.3 million from $75.2 million, for fiscal year 2014 and 2013, respectively. Research and development expenses were 5.7% and 6.5% of net sales for fiscal year 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $7.8 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan and an increase of $2.7 million in development expenses for prototype materials and testing associated with new product introductions, particularly related to the introduction of new products including servers based on Intel's Ivy Bridge processor, TwinPro, EX DP and MicroBlade series of servers and the development of new products associated to the new processor technology, Grantley, from Intel. This increase was partially offset by an increase of $1.0 million in non-recurring engineering funding from certain suppliers and customers. The decrease as a percentage of net sales was primarily due to the significant increase in net sales in fiscal year 2014.

[0001445305-14-003958:mdna:64]
Research and development expenses include stock-based compensation expense of $6.8 million and $6.5 million for fiscal year 2014 and 2013, respectively.

[0001445305-14-003958:mdna:65]
Sales and marketing expenses. Sales and marketing expenses increased by $4.2 million, or 12.5%, to $38.0 million from $33.8 million, for fiscal year 2014 and 2013, respectively. Sales and marketing expenses were 2.6% and 2.9% of net sales for fiscal year 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $2.3 million in compensation and benefits resulting from growth in sales and marketing personnel and an increase of $1.1 million in

[0001445305-14-003958:mdna:66]
WEST\249206192.2                                           31

[0001445305-14-003958:mdna:67]
advertising and marketing promotional expenses including cooperating marketing expenses. The decrease as a percentage of net sales was primarily due to the significant increase in net sales in fiscal year 2014.

[0001445305-14-003958:mdna:68]
Sales and marketing expenses include stock-based compensation expense of $1.3 million and $1.5 million for fiscal year 2014 and 2013, respectively.

[0001445305-14-003958:mdna:69]
General and administrative expenses. General and administrative expenses decreased by $0.9 million, or 3.7%, to $23.0 million from $23.9 million, for fiscal year 2014 and 2013, respectively. General and administrative expenses were 1.6% and 2.1% of net sales for fiscal year 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to an increase of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor and a decrease of $0.6 million resulting from payroll tax audit assessment in fiscal year 2013, offset in part by an increase of $0.4 million in bad debt expenses. The decrease as a percentage of net sales was primarily due to the significant increase in net sales in fiscal year 2014.

[0001445305-14-003958:mdna:70]
General and administrative expenses include stock-based compensation expense of $2.1 million and $2.3 million for fiscal year 2014 and 2013, respectively.

[0001445305-14-003958:mdna:71]
Interest and other expense, net. Interest and other expense changed by $0.1 million, to $0.7 million of expense from $0.6 million of expense, for fiscal year 2014 and 2013, respectively, which included $0.8 million and $0.6 million of interest expense for fiscal year 2014 and 2013, respectively.

[0001445305-14-003958:mdna:72]
Provision for income taxes. Provision for income taxes increased by $20.1 million, or 378.4%, to $25.4 million from $5.3 million, for fiscal year 2014 and 2013, respectively. The effective tax rate was 32.0% and 20.0% for fiscal year 2014 and 2013, respectively. The higher income tax provision and effective tax rate for the fiscal year 2014 were primarily attributable to our higher operating income and the expiration of the U.S. federal research and development credit on December 31, 2013.

[0001445305-14-003958:mdna:73]
Comparison of Fiscal Years Ended June 30, 2013 and 2012

[0001445305-14-003958:mdna:74]
Net sales. Net sales increased by $148.7 million, or 14.7%, to $1,162.6 million from $1,013.9 million, for fiscal year 2013 and 2012, respectively. This increase was due primarily to an increase in unit volumes of our subsystems and accessories and to a lesser extent an increase in the average selling price of our server systems offset by a decrease in unit volumes of server systems as we sold more higher density server systems in fiscal year 2013 compared to fiscal year 2012.

[0001445305-14-003958:mdna:75]
For fiscal year 2013, the number of server system units sold decreased 2.9% to 232,000 compared to 239,000 for fiscal year 2012. The average selling price of server system units increased 15.8% to $2,200 in fiscal year 2013 compared to $1,900 in fiscal year 2012. The average selling prices of our server systems increased primarily due to higher average selling prices of MicroCloud, FatTwin servers, storage and SuperBlades servers with Intel's Sandy Bridge processors which offered higher density computing and more memory and hard disk drive capacity. Sales of server systems increased by $54.9 million or 12.3% from fiscal year 2012 to fiscal year 2013, primarily due to higher sales of Twin, storage, MicroCloud, GPU/Xeon Phi and SuperBlade servers solutions and complete integrated-high-end servers solutions to OEM and end customers partially offset by lower sales of rack solutions. Sales of server systems represented 43.2% of our net sales for fiscal year 2013 compared to 44.1% of our net sales for fiscal year 2012.

[0001445305-14-003958:mdna:76]
For fiscal year 2013, the number of subsystems and accessories units sold increased 3.6% to 4.5 million compared to 4.3 million for fiscal year 2012. Sales of subsystems and accessories increased by $93.8 million or 16.6% from fiscal year 2012 to fiscal year 2013, primarily related to higher sales of hard disk drives, chassis, memory and serverboards to our distributors and system integrators who purchased additional accessories from us and completed the final assembly themselves. Sales of subsystems and accessories represented 56.8% of our net sales for fiscal year 2013 as compared to 55.9% of our net sales for fiscal year 2012.

[0001445305-14-003958:mdna:77]
For fiscal year 2013 and 2012, we derived 56.3% and 54.4%, respectively, of our net sales from products sold to distributors and we derived 43.7% and 45.6%, respectively, from sales to OEMs and to end customers. For fiscal year 2013, customers in the United States, Europe and Asia accounted for 54.2%, 22.7% and 20.5%, of our net sales, respectively, as compared to 58.2%, 21.8% and 17.4% of our net sales, respectively, for fiscal year 2012.

[0001445305-14-003958:mdna:78]
Cost of sales. Cost of sales increased by $154.1 million, or 18.2%, to $1,002.5 million from $848.5 million, for fiscal year 2013 and 2012, respectively. Cost of sales as a percentage of net sales was 86.2% and 83.7% for fiscal year 2013 and 2012, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales, an increase of $1.2 million in provision for warranty reserve and an increase of $1.1 million in provision for inventory reserve.

[0001445305-14-003958:mdna:79]
WEST\249206192.2                                           32

[0001445305-14-003958:mdna:80]
The higher cost of sales as a percentage of net sales was primarily due to higher costs of hard disk drives as a result of our HDD supply agreement and memory bundled with our server solutions and higher mix of subsystem and accessories sales. In general, we have higher margins in server systems than in subsystems and accessories. In fiscal year 2013, we recorded a $13.4 million expense, or 1.2% of net sales, related to the provision for warranty reserve as compared to $12.2 million, or 1.2% of net sales, in fiscal year 2012. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in fiscal year 2013. In fiscal year 2013, we recorded a $9.7 million expense, net of recovery, or 0.8% of net sales, related to the inventory provision as compared to $8.6 million, or 0.8% of net sales, in fiscal year 2012. The increase in the inventory provision was primarily for older products as a result of product transitions.

[0001445305-14-003958:mdna:81]
Research and development expenses. Research and development expenses increased by $11.0 million, or 17.1%, to $75.2 million from $64.2 million, for fiscal year 2013 and 2012, respectively. Research and development expenses were 6.5% and 6.3% of net sales for fiscal year 2013 and 2012, respectively. The increase in absolute dollars was primarily due to an increase of $9.2 million in compensation and benefits including higher stock-based compensation expense, resulting from growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan, a decrease of $0.8 million in non-recurring engineering funding from certain suppliers and customers and an increase of $0.6 million in VAT expenses related to research and development service fees paid to our subsidiary in Taiwan. The increase as a percentage of sales was due to increased headcount and prototype material expenses relating to new product introductions, particularly related to the introduction of new products for technology launches such as Intel's Sandy Bridge and Haswell processor as well as our FatTwin solutions and product development expenses for Ivy Bridge processor.

[0001445305-14-003958:mdna:82]
Research and development expenses include stock-based compensation expense of $6.5 million and $5.5 million for fiscal year 2013 and 2012, respectively.

[0001445305-14-003958:mdna:83]
Sales and marketing expenses. Sales and marketing expenses increased by $0.5 million, or 1.4%, to $33.8 million from $33.3 million, for fiscal year 2013 and 2012, respectively. Sales and marketing expenses were 2.9% and 3.3% of net sales for fiscal year 2013 and 2012, respectively. The increase in absolute dollars was primarily due to an increase of $2.4 million in compensation and benefits resulting from growth in sales and marketing personnel, including higher stock-based compensation expense and an increase of $0.5 million in advertising, promotional and trade show expenses offset in part by an increase of $1.3 million in cooperative marketing funding received from vendors to promote the new product launches and a decrease of $1.0 million in cooperative marketing funding to our customers.

[0001445305-14-003958:mdna:84]
Sales and marketing expenses include stock-based compensation expense of $1.5 million  for both fiscal year 2013 and 2012.

[0001445305-14-003958:mdna:85]
General and administrative expenses. General and administrative expenses increased by $2.0 million, or 9.3%, to $23.9 million from $21.9 million, for fiscal year 2013 and 2012, respectively. General and administrative expenses were 2.1% and 2.2% of net sales for fiscal year 2013 and 2012, respectively. The increase in absolute dollars was primarily due to an increase of $1.1 million in compensation and benefits, including higher stock-based compensation expense, in part to support the expansion of our operations at our headquarters and operations in Taiwan, an increase of $0.7 million in bad debt expense, an increase of $0.6 million in payroll tax audit reserve, a decrease of $0.2 million in rental income, an increase of $0.3 million in miscellaneous expense relating to the settlement payment of one patent claim offset in part by a decrease of $0.4 million in foreign currency transaction loss, a decrease of $0.4 million in moving expenses and a decrease of $0.4 million in legal fees.

[0001445305-14-003958:mdna:86]
General and administrative expenses include stock-based compensation expense of $2.3 million and $2.5 million for fiscal year 2013 and 2012, respectively.

[0001445305-14-003958:mdna:87]
Interest and other expense, net. Interest and other expense changed by $(0.1) million, to $0.6 million of expense from $0.7 million of expense, for fiscal year 2013 and 2012, respectively, which included $0.6 million and $0.7 million of interest expense for fiscal year 2013 and 2012, respectively.

[0001445305-14-003958:mdna:88]
Provision for income taxes. Provision for income taxes decreased by $10.2 million, or 65.7%, to $5.3 million from $15.5 million, for fiscal year 2013 and 2012, respectively. The effective tax rate was 20.0% and 34.2% for fiscal year 2013 and 2012, respectively. The lower provision for income taxes and effective tax rate for fiscal year 2013 were primarily attributable to our lower net income, a tax benefit of $3.7 million related to the U.S. federal R&D tax credit, of which $1.5 million related to fiscal year 2012, and the recognition of a $2.0 million benefit related to our resolution of IRS audits for all outstanding items covering fiscal year 2008 through 2010, offset in part by an increase of $0.8 million in stock option expense.

[0001445305-14-003958:mdna:89]
WEST\249206192.2                                           33

[0001445305-14-003958:mdna:90]
Liquidity and Capital Resources

[0001445305-14-003958:mdna:91]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $96.9 million and $93.1 million as of June 30, 2014 and 2013, respectively. Our cash in foreign locations was $28.3 million and $16.6 million at June 30, 2014 and 2013, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001445305-14-003958:mdna:92]
Operating Activities. Net cash provided by operating activities was $6.5 million, $13.6 million and $16.5 million for fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-003958:mdna:93]
Net cash provided by our operating activities for fiscal year 2014 was primarily due to our net income of $54.2 million, an increase in accounts payable of $46.3 million, stock-based compensation expense of $11.1 million, an increase in net income taxes payable of $10.9 million, depreciation expense of $6.4 million and an increase in accrued liabilities of $3.3 million, provision for inventory of $2.3 million, which were partially offset by an increase in accounts receivable of $64.9 million, an increase in inventory of $63.9 million and the excess tax benefits from stock-based compensation of $3.0 million.

[0001445305-14-003958:mdna:94]
Net cash provided by our operating activities for fiscal year 2013 was primarily due to our net income of $21.3 million, a decrease in inventory of $12.7 million, stock-based compensation expense of $11.4 million, provision for inventory of $9.7 million, depreciation expense of $7.8 million, an increase in net income taxes payable of $4.5 million and an increase in accrued liabilities of $4.4 million, which were partially offset by an increase in accounts receivable of $48.3 million, deferred income taxes of $7.0 million and a decrease in accounts payable of $2.2 million.

[0001445305-14-003958:mdna:95]
Net cash provided by our operating activities for fiscal year 2012 was primarily due to our net income of $29.9 million, an increase in accounts payable of $61.3 million, stock-based compensation expense of $10.3 million, an increase in net income taxes payable of $9.0 million, provision for inventory of $8.6 million, depreciation expense of $7.1 million, and an increase in accrued liabilities of $5.0 million, which were partially offset by an increase in inventory of $92.5 million and an increase in accounts receivable of $17.2 million.

[0001445305-14-003958:mdna:96]
The increase for fiscal year 2014 in accounts receivable was primarily due to an increase in our sales late in the fourth quarter. The increase for fiscal year 2014 in inventory and accounts payable was mainly due to higher purchases to support the anticipated level of growth in our net sales in fiscal year 2015. The increase for fiscal year 2014 in accrued liabilities was also due to support our growth in net sales. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001445305-14-003958:mdna:97]
The increase for fiscal year 2013 in accounts receivable was primarily due to an increase in sales to customers with net payment terms and a decrease in sales to customers with electronic payment terms. The decrease for fiscal year 2013 in inventory and accounts payable was mainly due to lower hard disk drive and memory inventory. The increase for fiscal year 2013 in accrued liabilities was in part due to timing of payments to our vendors and in part due to support our growth and our increasing manufacturing activities in Taiwan. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001445305-14-003958:mdna:98]
The increase for fiscal year 2012 in accounts receivable was primarily due to higher net sales in the fourth quarter of fiscal year 2012 to customers with net payment terms. The increase for fiscal year 2012 in inventory was in part due to support the anticipated level of growth in net sales in fiscal year 2012, to increase inventory relating to the Sandy Bridge processors launched by Intel in the third quarter of fiscal year 2012 and to address the disruption in the hard disk drive supply chain as a result of the flooding in Thailand in 2011. The increase for fiscal year 2012 in accounts payable and accrued liabilities was in part due to timing of payments to our suppliers and in part due to support our growth and our increasing manufacturing activities in Taiwan. We anticipate that accounts receivable, inventory and accounts payable will continue to increase to the extent we continue to grow our product lines and our business.

[0001445305-14-003958:mdna:99]
Investing activities. Net cash used in our investing activities was $40.2 million, $5.1 million and $19.7 million for fiscal years 2014, 2013 and 2012, respectively. In fiscal year 2014, $40.6 million was related to the purchase of property, plant and equipment including $30.2 million related to the real property purchased in San Jose, California in October 2013, offset in part by the termination of the certificates of deposits for $0.4 million, which were pledged as security for a value added tax examination required by tax authority of Taiwan.

[0001445305-14-003958:mdna:100]
WEST\249206192.2                                           34

[0001445305-14-003958:mdna:101]
In fiscal year 2013, $5.0 million was related to the purchase of property, plant and equipment and $0.4 million was related to the additional certificate of deposit pledged as security for value added tax examination required by tax authority of Taiwan. This was offset by the redemption at par of investments in auction rate securities of $0.3 million.

[0001445305-14-003958:mdna:102]
In fiscal year 2012, $22.0 million was related to the purchase of property, plant and equipment net of land deposit refund primarily related to the construction of facilities in Taiwan and the headquarters office expansion in San Jose, California. The purchase of the land in Taiwan, consisting of approximately 2.2 acres, was finalized and closed in December 2011. We also completed the construction of facilities in Taiwan and the headquarters expansion in San Jose, California in December 2011. This was offset by the redemption at par of investments in auction rate securities of $2.5 million.

[0001445305-14-003958:mdna:103]
In connection with the purchase of the real property in San Jose, California, we also engaged several contractors for the development and construction of improvements on the property that will serve as our Green Computing Park. We plan to develop five manufacturing buildings on the land and remodel one existing warehouse in which two of the manufacturing facilities and the improvement on warehouse will be constructed through fiscal year 2016. We anticipate the costs of approximately $22.1 million during fiscal year 2015 to build the first manufacturing facility and remodel the warehouse. We plan to finance this development through our operating cash flows and additional borrowings from banks.

[0001445305-14-003958:mdna:104]
Financing activities. Net cash provided by our financing activities was $37.2 million, $3.8 million and $13.8 million for fiscal years 2014, 2013 and 2012, respectively. In fiscal year 2014, we received $23.9 million related to the proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding mainly on behalf of one executive officer for his restricted stock awards of $0.7 million in fiscal year 2014. Further, we borrowed an additional $6.8 million under the line of credit from Bank of America, borrowed $7.0 million from the CTBC Bank secured term loan, and borrowed $3.5 million of our CTBC Bank revolving line of credit and repaid $6.3 million in loans in fiscal year 2014.

[0001445305-14-003958:mdna:105]
In fiscal year 2013, we received $1.8 million related to the proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding mainly on behalf of one executive officer for his restricted stock awards of $1.0 million in fiscal year 2013. Further, we obtained a new term loan of $15.0 million from China Trust Bank, borrowed $5.6 million of our revolving line of credit from Bank of America, N.A., and repaid $18.1 million in loans in fiscal year 2013.

[0001445305-14-003958:mdna:106]
In fiscal year 2012, we received $8.5 million related to the proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding on behalf of one executive officer for his restricted stock awards of $1.1 million in fiscal year 2012. Further, we obtained a new term loan of $14.0 million from Bank of America, N.A., borrowed $19.7 million of our revolving line of credit and repaid $28.9 million in loans in fiscal year 2012.

[0001445305-14-003958:mdna:107]
In fiscal year 2014, 2013 and 2012, $3.0 million, $0.9 million and $2.0 million was related to the excess tax benefits from stock-based compensation, respectively. We expect the net cash provided by financing activities will increase throughout fiscal year 2015 as we intend to obtain additional financing from banks to construct our manufacturing buildings at our Green Computing Park in San Jose, California.

[0001445305-14-003958:mdna:108]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001445305-14-003958:mdna:109]
Other factors affecting liquidity and capital resources

[0001445305-14-003958:mdna:110]
Activities under Revolving Lines of Credit and Term Loans

[0001445305-14-003958:mdna:111]
Bank of America

[0001445305-14-003958:mdna:112]
In October 2011, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $40.0 million revolving line of credit facility through June 15, 2013 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are

[0001445305-14-003958:mdna:113]
WEST\249206192.2                                           35

[0001445305-14-003958:mdna:114]
payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit to November 15, 2014. We are currently negotiating with Bank of America to renew the revolving line of credit.

[0001445305-14-003958:mdna:115]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at June 30, 2014. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001445305-14-003958:mdna:116]
As of June 30, 2014 and 2013, the total outstanding borrowings under the Bank of America term loan was $6.5 million and $9.3 million, respectively. The total outstanding borrowings under the Bank of America line of credit was $17.7 million and $10.9 million as of June 30, 2014 and 2013, respectively. The interest rates for these loans ranged from 1.19% to 1.65% per annum at June 30, 2014 and 1.23% to 1.69% per annum at June 30, 2013, respectively. As of June 30, 2014, the unused revolving line of credit under Bank of America was $22.3 million.

[0001445305-14-003958:mdna:117]
CTBC Bank

[0001445305-14-003958:mdna:118]
In October 2011, we obtained an unsecured revolving line of credit from CTBC Bank totaling NT$300.0 million or $9.9 million U.S. dollars equivalents. In July 2012, we increased the credit line to NT$450.0 million or $14.9 million U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate at the lender's established interest rate plus 0.3% which is adjusted monthly.

[0001445305-14-003958:mdna:119]
In November 2013, we entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700.0 million or $23.8 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100.0 million or $3.4 million U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500.0 million or $17.0 million U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $34.0 million U.S. dollar equivalents.

[0001445305-14-003958:mdna:120]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $22.1 million and $14.9 million as of June 30, 2014 and 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at June 30, 2014 and 2013. The interest rate for the loan was at 1.15% and 1.2% per annum at June 30, 2014 and 2013, respectively. At June 30, 2014, NT$340.0 million or $11.4 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001445305-14-003958:mdna:121]
Covenant Compliance

[0001445305-14-003958:mdna:122]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001445305-14-003958:mdna:123]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001445305-14-003958:mdna:124]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001445305-14-003958:mdna:125]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001445305-14-003958:mdna:126]
As of June 30, 2014, our total assets of $751.4 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of June 30, 2014, total assets collateralizing the term loan with Bank of America were $17.6 million. As of June 30, 2014, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001445305-14-003958:mdna:127]
WEST\249206192.2                                           36

[0001445305-14-003958:mdna:128]
As of June 30, 2014, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.3 million. There are no financial covenants associated with the term loan with CTBC Bank at June 30, 2014.

[0001445305-14-003958:mdna:129]
Contract Manufacturers

[0001445305-14-003958:mdna:130]
In fiscal year 2014, we paid our contract manufacturers within 61 to 72 days of invoice and Ablecom between 63 to 98 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of June 30, 2014 and 2013 amounts owed to Ablecom by us were approximately $49.0 million and $50.4 million, respectively.

[0001445305-14-003958:mdna:131]
Auction Rate Securities Valuation

[0001445305-14-003958:mdna:132]
As of June 30, 2014, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AAA or AA2 at June 30, 2014. These auction rate preferred shares have no stated maturity date.

[0001445305-14-003958:mdna:133]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of June 30, 2014, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at June 30, 2014, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In fiscal year 2014, there was no auction rate securities redeemed or sold. In fiscal year 2013 and 2012, $0.3 million and $2.5 million of auction rate securities were redeemed at par, respectively.

[0001445305-14-003958:mdna:134]
Contractual Obligations

[0001445305-14-003958:mdna:135]
The following table describes our contractual obligations as of June 30, 2014:

[0001445305-14-003958:mdna:136]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 3,265 |  |  | $ | 1,259 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,526 |  |
| Capital leases, including interest | 103 |  |  | 189 |  |  | 96 |  |  | — |  |  | 388 |  |
| Long-term debt, including interest (1) | 42,648 |  |  | 3,781 |  |  | — |  |  | — |  |  | 46,429 |  |
| Purchase commitments (2) | 211,064 |  |  | 26 |  |  | — |  |  | — |  |  | 211,090 |  |
| Total (3) | $ | 257,080 |  |  | $ | 5,255 |  |  | $ | 98 |  |  | $ | — |  |  | $ | 262,433 |  |

[0001445305-14-003958:mdna:137]
__________________________

[0001445305-14-003958:mdna:138]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at June 30, 2014. |

[0001445305-14-003958:mdna:139]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $45.2 million of hard disk drive purchase commitments at June 30, 2014, which will be paid through December 2014. See Note 12 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of purchase commitments. |

[0001445305-14-003958:mdna:140]
| (3) | The table above excludes liabilities for deferred revenue for warranty and on-site services of $6.0 million and unrecognized tax benefits and related interest and penalties accrual of $9.5 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 11 of Notes to our Consolidated Financial Statements in Item 8 of this Form 10-K for a discussion of income taxes. |

[0001445305-14-003958:mdna:141]
We expect to fund our remaining contractual obligations from our ongoing operations and existing cash and cash equivalents on hand.

[0001445305-14-003958:mdna:142]
WEST\249206192.2                                           37

[0001445305-14-003958:mdna:143]
Adoption of New Accounting Pronouncements

[0001445305-14-003958:mdna:144]
In February 2013, the FASB issued authoritative guidance associated with reporting of amounts reclassified out of accumulated other comprehensive income, which requires companies to present significant reclassifications out of accumulated other comprehensive income in their entirety in the statement of operations or in a separate footnote to the financial statements. For amounts that are not required to be reclassified in their entirety to net income, the standard requires companies to cross-reference to related footnoted disclosures. The adoption of this guidance did not have a material impact on our results of operations or financial position.

[0001445305-14-003958:mdna:145]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. We are currently reviewing the provisions but do not expect it to have a material impact on our financial statement disclosures, results of operations or financial position.

[0001445305-14-003958:mdna:146]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. We adopted the new disclosure requirement on July 1, 2014. We do not believe the adoption of this guidance will have a material impact on our financial statement disclosure, results of operations or financial position.

[0001445305-14-003958:mdna:147]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for us on July 1, 2017. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations or financial position.

[0001445305-14-003958:mdna:148]
Off-Balance Sheet Arrangements

[0001445305-14-003958:mdna:149]
We do not have any off-balance sheet arrangements.
