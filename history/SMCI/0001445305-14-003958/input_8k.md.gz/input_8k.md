# SMCI 8-K — 0001445305-14-003415 filed 2014-08-05

## item codes, every 8-K on or before 2014-09-15

- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2014-09-15

- none on or before 2014-09-15

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-003415:8k_2_02:1]
EX-99.1
2
exhibit991q42014.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001445305-14-003415:8k_2_02:2]
Exhibit 991 Q42014

[0001445305-14-003415:8k_2_02:3]
Exhibit 99.1

[0001445305-14-003415:8k_2_02:4]
Super Micro Computer, Inc. Announces 4th Quarter 2014 Financial Results

[0001445305-14-003415:8k_2_02:5]
SAN JOSE, Calif., August 5, 2014 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a leader in application optimized, high performance server solutions, today announced fourth quarter and full-year financial results for the fiscal year ended June 30, 2014.

[0001445305-14-003415:8k_2_02:6]
Fiscal 4th Quarter Highlights

[0001445305-14-003415:8k_2_02:7]
| • | Quarterly net sales of $428.1 million, up 14.5% from the third quarter of fiscal year 2014 and up 32.8% from the same quarter of last year. |

[0001445305-14-003415:8k_2_02:8]
| • | GAAP net income before income tax provision of $26.3 million, up 23.5% from the third quarter of fiscal year 2014 and up 114.3% from the same quarter of last year. |

[0001445305-14-003415:8k_2_02:9]
| • | GAAP net income of $16.5 million, down 0.2% from the third quarter of fiscal year 2014 and up 96.4% from the same quarter of last year. |

[0001445305-14-003415:8k_2_02:10]
| • | GAAP gross margin of 15.5%, up from 15.3% in the third quarter of fiscal year 2014 and up from 14.3% in the same quarter of last year. |

[0001445305-14-003415:8k_2_02:11]
| • | Server solutions accounted for 55.2% of net sales compared with 50.1% in the third quarter of fiscal year 2014 and 47.4% in the same quarter of last year. |

[0001445305-14-003415:8k_2_02:12]
Net sales for the fourth quarter ended June 30, 2014 totaled $428.1 million, up 14.5% from $373.8 million in the third quarter of fiscal year 2014. No customer accounted for more than 10% of net sales during the quarter ended June 30, 2014.

[0001445305-14-003415:8k_2_02:13]
GAAP net income for the fourth quarter of fiscal year 2014 was $16.5 million or $0.34 per diluted share, an increase of 96.4% from the net income of $8.4 million, or $0.19 per diluted share in the same period a year ago. Included in net income for the quarter is $2.9 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the fourth quarter was $19.4 million, or $0.40 per diluted share, compared to non-GAAP net income of $11.3 million, or $0.26 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the third quarter of fiscal year 2014 by $1.6 million or $0.03 per diluted share.

[0001445305-14-003415:8k_2_02:14]
GAAP gross margin for the fourth quarter was 15.5% compared to 14.3% in the same period a year ago. Non-GAAP gross margin for the fourth quarter was 15.6% compared to 14.4% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the third quarter of fiscal year 2014 were 15.3% and 15.4%, respectively.

[0001445305-14-003415:8k_2_02:15]
The GAAP income tax provision was $9.8 million or 37.2% of income before tax provision compared to $3.9 million or 31.4% in the same period a year ago and $4.8 million or 22.3% in the third quarter of fiscal year 2014. The increase from prior year was due to the reinstatement of the R&D tax credit in that quarter. The increase from prior quarter was due to a lower deduction for stock-based compensation expense and an increase in taxable income in the current quarter.

[0001445305-14-003415:8k_2_02:16]
The Company's cash and cash equivalents and short and long term investments at June 30, 2014 were $99.6 million compared to $95.7 million at June 30, 2013. Free cash flow for the year ended June 30, 2014 was $(34.0) million primarily due to the purchase of real property in San Jose, California for $30.1 million.

[0001445305-14-003415:8k_2_02:17]
Fiscal Year 2014 Summary

[0001445305-14-003415:8k_2_02:18]
Net sales for the fiscal year ended June 30, 2014 were $1,467.2 million, up 26.2% from $1,162.6 million for the fiscal year ended June 30, 2013. GAAP net income for fiscal year 2014 increased to $54.2 million, or $1.16 per diluted share, an increase of 154.5% from $21.3 million, or $0.48 per diluted share, for fiscal year 2013. Excluding $11.1 million of stock based-compensation expense and related tax effect, non-GAAP net income for the fiscal year 2014 was $62.9 million or $1.34 per diluted share, an increase of 95.4% compared to $32.2 million or $0.73 per diluted share for fiscal year 2013.

[0001445305-14-003415:8k_2_02:19]
Business Outlook & Management Commentary

[0001445305-14-003415:8k_2_02:20]
The Company expects net sales of $395 million to $435 million for the first quarter of fiscal year 2015 ending September 30, 2014. The Company expects non-GAAP earnings per diluted share of approximately $0.36 to $0.42 for the first quarter.

[0001445305-14-003415:8k_2_02:21]
“In the fourth quarter, we achieved $428.1 million revenue or 32.8% growth over last year which marked the third straight quarter of record revenues and keeps us on a path to reach our goal of achieving $2 billion annual run rate in the coming fiscal year 2015. Revenue growth was driven by higher sales into virtualization and cloud applications to internet data centers totaling 17.8% of fourth quarter revenue or 150% higher than last year which helped us to achieve record revenue for system sales of 55.2% of revenue. With this strong revenue growth combined with operating expense leverage, we achieved record profits,” said Charles Liang, Chairman and CEO. “We are looking forward to the new fiscal year and we have been preparing to be a strong market leader in the upcoming technology refresh cycle related to the Intel Grantley (Haswell new processor) launch. We have created new X10 based

[0001445305-14-003415:8k_2_02:22]
product lines optimized for Grantley which includes our new Ultra server architecture, our new Data Center Optimized line, and our TwinPro line to just name a few of the many products that will lead the industry in innovation and time to market.”

[0001445305-14-003415:8k_2_02:23]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001445305-14-003415:8k_2_02:24]
Conference Call Information

[0001445305-14-003415:8k_2_02:25]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate the conference, please call 1-888-329-8877 (international callers dial 1-719-457-2661) 10 minutes prior. A recording of the conference will be available until 11:59 pm ET on Tuesday, August 19, 2014 by dialing 1-877-870-5176 (international callers dial 1-858-384-5517) and entering replay PIN 6112672. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001445305-14-003415:8k_2_02:26]
Cautionary Statement Regarding Forward Looking Statements

[0001445305-14-003415:8k_2_02:27]
Use of Non-GAAP Financial Measures

[0001445305-14-003415:8k_2_02:28]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001445305-14-003415:8k_2_02:29]
About Super Micro Computer, Inc.

[0001445305-14-003415:8k_2_02:30]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001445305-14-003415:8k_2_02:31]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001445305-14-003415:8k_2_02:32]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001445305-14-003415:8k_2_02:33]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | June 30, |  | June 30, |
|  |  |  |  | 2014 |  | 2013 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 96,872 |  |  | $ | 93,038 |  |
|  | Accounts receivable, net | 212,738 |  |  | 149,340 |  |
|  | Inventory |  | 315,837 |  |  | 254,170 |  |
|  | Deferred income taxes – current | 16,842 |  |  | 15,786 |  |
|  | Prepaid income taxes | 5,555 |  |  | 4,039 |  |
|  | Prepaid expenses and other current assets | 6,237 |  |  | 6,819 |  |
|  |  | Total current assets | 654,081 |  |  | 523,192 |  |
| Long-term investments | 2,647 |  |  | 2,637 |  |
| Property, plant and equipment, net | 130,589 |  |  | 95,912 |  |
| Deferred income taxes – noncurrent |  | 6,154 |  |  | 7,275 |  |
| Other assets |  |  | 2,854 |  |  | 3,241 |  |
|  |  | Total assets | $ | 796,325 |  |  | $ | 632,257 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 219,354 |  |  | $ | 172,855 |  |
|  | Accrued liabilities |  | 37,564 |  |  | 34,122 |  |
|  | Income taxes payable |  | 11,414 |  |  | 6,049 |  |
|  | Short-term debt and current portion of long-term debt | 42,554 |  |  | 28,638 |  |
|  |  | Total current liabilities | 310,886 |  |  | 241,664 |  |
| Long term debt-net of current portion | 3,733 |  |  | 6,533 |  |
| Other long-term liabilities | 12,475 |  |  | 10,336 |  |
|  |  | Total liabilities | 327,094 |  |  | 258,533 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital |  | 199,062 |  |  | 157,712 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (63 | ) |  | (69 | ) |
|  | Retained earnings |  | 272,087 |  |  | 217,930 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 469,056 |  |  | 373,543 |  |
|  | Noncontrolling interest | 175 |  |  | 181 |  |
|  |  | Total liabilities and stockholders' equity | $ | 796,325 |  |  | $ | 632,257 |  |

[0001445305-14-003415:8k_2_02:34]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except share and per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Fiscal Year Ended |
|  | June 30, |  | June 30, |  | June 30, |  | June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 428,069 |  |  | $ | 322,333 |  |  | $ | 1,467,202 |  |  | $ | 1,162,561 |  |
| Cost of sales | 361,672 |  |  | 276,310 |  |  | 1,241,657 |  |  | 1,002,508 |  |
| Gross profit | 66,397 |  |  | 46,023 |  |  | 225,545 |  |  | 160,053 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 23,023 |  |  | 19,557 |  |  | 84,257 |  |  | 75,208 |  |
| Sales and marketing | 10,755 |  |  | 8,361 |  |  | 38,012 |  |  | 33,785 |  |
| General and administrative | 6,079 |  |  | 5,677 |  |  | 23,017 |  |  | 23,902 |  |
| Total operating expenses | 39,857 |  |  | 33,595 |  |  | 145,286 |  |  | 132,895 |  |
| Income from operations | 26,540 |  |  | 12,428 |  |  | 80,259 |  |  | 27,158 |  |
| Interest and other income, net | 19 |  |  | 24 |  |  | 92 |  |  | 48 |  |
| Interest expense | (222 | ) |  | (161 | ) |  | (757 | ) |  | (610 | ) |
| Income before income tax provision | 26,337 |  |  | 12,291 |  |  | 79,594 |  |  | 26,596 |  |
| Income tax provision | 9,788 |  |  | 3,865 |  |  | 25,437 |  |  | 5,317 |  |
| Net income | $ | 16,549 |  |  | $ | 8,426 |  |  | $ | 54,157 |  |  | $ | 21,279 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.20 |  |  | $ | 1.24 |  |  | $ | 0.50 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.19 |  |  | $ | 1.16 |  |  | $ | 0.48 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 45,017 |  |  | 42,267 |  |  | 43,599 |  |  | 41,992 |  |
| Diluted (b) | 48,317 |  |  | 43,918 |  |  | 46,512 |  |  | 43,907 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended |  | Fiscal Year Ended |
|  | June 30, |  | June 30, |  | June 30, |  | June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 215 |  |  | $ | 257 |  |  | $ | 941 |  |  | $ | 953 |  |
| Research and development | 1,790 |  |  | 1,599 |  |  | 6,783 |  |  | 6,527 |  |
| Sales and marketing | 335 |  |  | 359 |  |  | 1,260 |  |  | 1,541 |  |
| General and administrative | 539 |  |  | 484 |  |  | 2,078 |  |  | 2,340 |  |

[0001445305-14-003415:8k_2_02:35]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Fiscal Year Ended June 30, |
|  | 2014 |  | 2013 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 54,157 |  |  | $ | 21,279 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 6,364 |  |  | 7,835 |  |
| Stock-based compensation expense | 11,062 |  |  | 11,361 |  |
| Excess tax benefits from stock-based compensation | (2,992 | ) |  | (865 | ) |
| Allowance for doubtful accounts | 1,476 |  |  | 929 |  |
| Provision for inventory | 2,254 |  |  | 9,725 |  |
| Exchange gain | (96 | ) |  | (153 | ) |
| Deferred income taxes, net | 63 |  |  | (7,010 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (64,874 | ) |  | (48,255 | ) |
| Inventory | (63,921 | ) |  | 12,704 |  |
| Prepaid expenses and other assets | 618 |  |  | (67 | ) |
| Accounts payable | 46,298 |  |  | (2,208 | ) |
| Income taxes payable, net | 10,882 |  |  | 4,490 |  |
| Accrued liabilities | 3,293 |  |  | 4,384 |  |
| Other long-term liabilities | 1,954 |  |  | (566 | ) |
| Net cash provided by operating activities | 6,538 |  |  | 13,583 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Proceeds from investments | — |  |  | 300 |  |
| Purchases of property, plant and equipment | (40,567 | ) |  | (5,001 | ) |
| Restricted cash | 406 |  |  | (412 | ) |
| Net cash used in investing activities | (40,161 | ) |  | (5,113 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 17,354 |  |  | 20,641 |  |
| Repayment of debt | (6,320 | ) |  | (18,073 | ) |
| Proceeds from exercise of stock options | 23,928 |  |  | 1,845 |  |
| Excess tax benefits from stock-based compensation | 2,992 |  |  | 865 |  |
| Payment of obligations under capital leases | (47 | ) |  | (40 | ) |
| Payments under receivable financing arrangements | (4 | ) |  | (610 | ) |
| Contribution from noncontrolling interests | — |  |  | 168 |  |
| Minimum tax withholding paid on behalf of employees for restricted stock awards | (681 | ) |  | (1,034 | ) |
| Net cash provided by financing activities | 37,222 |  |  | 3,762 |  |
| Effect of exchange rate fluctuations on cash | 235 |  |  | (20 | ) |
| Net increase in cash and cash equivalents | 3,834 |  |  | 12,212 |  |
| Cash and cash equivalents at beginning of year | 93,038 |  |  | 80,826 |  |
| Cash and cash equivalents at end of year | $ | 96,872 |  |  | $ | 93,038 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | $ | 757 |  |  | $ | 718 |  |
| Cash paid for taxes, net of refunds | $ | 13,096 |  |  | $ | 8,074 |  |
| Non-cash investing and financing activities: |  |  |  |
| Accrued costs for property, plant and equipment purchases | $ | 2,021 |  |  | $ | 1,871 |  |
| Equipment purchased under capital leases | $ | 283 |  |  | $ | 85 |  |

[0001445305-14-003415:8k_2_02:36]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except share and per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  | Fiscal Year Ended |
|  |  | June 30, |  | June 30, |  | June 30, |  | June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP GROSS PROFIT | $ | 66,397 |  |  | $ | 46,023 |  |  | $ | 225,545 |  |  | $ | 160,053 |  |
|  | Add back stock-based compensation (c) | 215 |  |  | 257 |  |  | 941 |  |  | 953 |  |
| Non-GAAP GROSS PROFIT | $ | 66,612 |  |  | $ | 46,280 |  |  | $ | 226,486 |  |  | $ | 161,006 |  |
| GAAP GROSS MARGIN | 15.5 | % |  | 14.3 | % |  | 15.4 | % |  | 13.8 | % |
|  | Add back stock-based compensation (c) | 0.1 | % |  | 0.1 | % |  | 0.0 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 15.6 | % |  | 14.4 | % |  | 15.4 | % |  | 13.8 | % |
| GAAP INCOME FROM OPERATIONS | $ | 26,540 |  |  | $ | 12,428 |  |  | $ | 80,259 |  |  | $ | 27,158 |  |
|  | Add back stock-based compensation (c) | 2,879 |  |  | 2,699 |  |  | 11,062 |  |  | 11,361 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 29,419 |  |  | $ | 15,127 |  |  | $ | 91,321 |  |  | $ | 38,519 |  |
| GAAP NET INCOME | $ | 16,549 |  |  | $ | 8,426 |  |  | $ | 54,157 |  |  | $ | 21,279 |  |
|  | Add back stock-based compensation (c) | 2,879 |  |  | 2,699 |  |  | 11,062 |  |  | 11,361 |  |
|  | Add back adjustments to tax benefit (provision) (d) | (31 | ) |  | 167 |  |  | (2,303 | ) |  | (440 | ) |
| Non-GAAP NET INCOME | $ | 19,397 |  |  | $ | 11,292 |  |  | $ | 62,916 |  |  | $ | 32,200 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.37 |  |  | $ | 0.20 |  |  | $ | 1.24 |  |  | $ | 0.50 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.06 |  |  | 0.07 |  |  | 0.20 |  |  | 0.26 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.43 |  |  | $ | 0.27 |  |  | $ | 1.44 |  |  | $ | 0.76 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.34 |  |  | $ | 0.19 |  |  | $ | 1.16 |  |  | $ | 0.48 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.06 |  |  | 0.07 |  |  | 0.18 |  |  | 0.25 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.40 |  |  | $ | 0.26 |  |  | $ | 1.34 |  |  | $ | 0.73 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP (g) | 45,017 |  |  | 42,267 |  |  | 43,599 |  |  | 41,992 |  |
|  | BASIC - Non-GAAP (h) | 45,018 |  |  | 42,447 |  |  | 43,628 |  |  | 42,202 |  |
|  | DILUTED – GAAP (g) | 48,317 |  |  | 43,918 |  |  | 46,512 |  |  | 43,907 |  |
|  | DILUTED - Non-GAAP (h) | 48,977 |  |  | 44,171 |  |  | 47,075 |  |  | 44,256 |  |

[0001445305-14-003415:8k_2_02:37]
(a) Approximately $311 and $36,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three months and fiscal year ended June 30, 2014, respectively, and approximately $36,000 and $106,000 for the three months and fiscal year ended June, 2013, respectively.

[0001445305-14-003415:8k_2_02:38]
(b) Approximately $290 and $34,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively, and approximately $34,000 and $101,000 for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:39]
(c) Amortization of ASC Topic 718 stock-based compensation for the three months and fiscal year ended June 30, 2014 and 2013.

[0001445305-14-003415:8k_2_02:40]
(d) The benefit from (provision of) income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 33.6% and 30.6% for the three months and fiscal year ended June 30, 2014, respectively, and 24.7% and 15.2% for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:41]
(e) Approximately $365 and $42,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three months and fiscal year ended June 30, 2014, respectively, and approximately $48,000 and $160,000 for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:42]
(f) Approximately $335 and $39,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively, and approximately $46,000 and $153,000 for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:43]
(g) 846 and 29,326 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively. 180,487 and 210,041 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:44]
(h) 846 and 29,326 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2014, respectively. 180,487 and 210,041 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three months and fiscal year ended June 30, 2013, respectively.

[0001445305-14-003415:8k_2_02:45]
SOURCE: Super Micro Computer, Inc.

[0001445305-14-003415:8k_2_02:46]
Super Micro Computer, Inc.

[0001445305-14-003415:8k_2_02:47]
Howard Hideshima, 408-503-8000

[0001445305-14-003415:8k_2_02:48]
SVP, Chief Financial Officer

[0001445305-14-003415:8k_2_02:49]
ir@supermicro.com

[0001445305-14-003415:8k_2_02:50]
or

[0001445305-14-003415:8k_2_02:51]
Perry G. Hayes

[0001445305-14-003415:8k_2_02:52]
SVP, Investor Relations

[0001445305-14-003415:8k_2_02:53]
ir@supermicro.com

[0001445305-14-003415:8k_2_02:54]
SMCI-F
