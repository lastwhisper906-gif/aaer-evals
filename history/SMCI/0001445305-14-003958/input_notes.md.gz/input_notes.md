# SMCI notes — 0001445305-14-003958


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001445305-14-003958:notes:1]
Accrued Liabilities

[0001445305-14-003958:notes:2]
Accrued liabilities as of June 30, 2014 and 2013 consisted of the following (in thousands):

[0001445305-14-003958:notes:3]
|  | June 30, |
|  | 2014 |  | 2013 |
| Accrued payroll and related expenses | $ | 11,624 |  |  | $ | 12,084 |  |
| Customer deposits | 4,185 |  |  | 4,134 |  |
| Accrued warranty costs | 7,083 |  |  | 6,472 |  |
| Accrued cooperative marketing expenses | 4,387 |  |  | 4,016 |  |
| Others | 10,285 |  |  | 7,416 |  |
| Total accrued liabilities | $ | 37,564 |  |  | $ | 34,122 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001445305-14-003958:notes:4]
Advertising Costs

[0001445305-14-003958:notes:5]
Advertising costs are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001445305-14-003958:notes:6]
Cash and Cash Equivalents

[0001445305-14-003958:notes:7]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposits with maturities of less than three months.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-14-003958:notes:8]
Commitments and Contingencies

[0001445305-14-003958:notes:9]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001445305-14-003958:notes:10]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of June 30, 2014, these remaining non-cancellable commitments were $211,090,000 compared to $249,005,000 as of June 30, 2013.

[0001445305-14-003958:notes:11]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $45,210,000, which will be paid through December 2014. The Company entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.

[0001445305-14-003958:notes:12]
Lease Commitments—The Company leases offices and equipment under noncancelable operating leases which expire at various dates through 2019. In addition, the Company leases certain of its equipment under capital leases. The future minimum lease commitments under all leases are as follows (in thousands):

[0001445305-14-003958:notes:13]
|  | Balance as of |
|  | CapitalLeases |  | OperatingLeases |
| Year ending June 30, 2015 | $ | 103 |  |  | $ | 3,265 |  |
| Year ending June 30, 2016 | 99 |  |  | 1,129 |  |
| Year ending June 30, 2017 | 90 |  |  | 130 |  |
| Year ending June 30, 2018 | 66 |  |  | 1 |  |
| Year ending June 30, 2019 | 30 |  |  | 1 |  |
| Thereafter | — |  |  | — |  |
| Total minimum lease payments | 388 |  |  | $ | 4,526 |  |
| Less: Amounts representing interest | 49 |  |  |  |
| Present value of minimum lease payments | 339 |  |  |  |
| Less: Long-term portion | 259 |  |  |  |
| Current portion | $ | 80 |  |  |  |

[0001445305-14-003958:notes:14]
Rent expense for the years ended June 30, 2014, 2013 and 2012, was $3,477,000, $3,345,000 and $3,444,000, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001445305-14-003958:notes:15]
Basis of Presentation

[0001445305-14-003958:notes:16]
The consolidated financial statements reflect the consolidated balance sheets, results of operations and cash flows of Super Micro Computer, Inc. and its wholly-owned subsidiaries (collectively, the “Company”). All intercompany accounts and transactions have been eliminated in consolidation.

[0001445305-14-003958:notes:17]
The Company consolidates its investment in Super Micro Business Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the Consolidated Balance Sheets. Net income attributable to the noncontrolling interest is not presented separately in the Consolidated Statements of Operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:CostOfSalesPolicyTextBlock

[0001445305-14-003958:notes:18]
Cost of Sales

[0001445305-14-003958:notes:19]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses, equipment and facility expenses, warranty costs and provision for lower of cost or market and excess and obsolete inventory.


## us-gaap:DebtDisclosureTextBlock

[0001445305-14-003958:notes:20]
Short-term and Long-term Obligations

[0001445305-14-003958:notes:21]
Short-term and long-term obligations as of June 30, 2014 and 2013 consisted of the following (in thousands):

[0001445305-14-003958:notes:22]
|  | June 30, |
|  | 2014 |  | 2013 |
| Line of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Total line of credit | 17,699 |  |  | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 6,533 |  |  | 9,333 |  |
| CTBC Bank | 22,055 |  |  | 14,939 |  |
| Total building term loans | 28,588 |  |  | 24,272 |  |
| Total debt | 46,287 |  |  | 35,171 |  |
| Current portion | (42,554 | ) |  | (28,638 | ) |
| Long-term portion | $ | 3,733 |  |  | $ | 6,533 |  |

[0001445305-14-003958:notes:23]
Activities under Revolving Lines of Credit and Term Loans

[0001445305-14-003958:notes:24]
Bank of America

[0001445305-14-003958:notes:25]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2014. The Company is currently negotiating with Bank of America to renew the revolving line of credit.

[0001445305-14-003958:notes:26]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at June 30, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001445305-14-003958:notes:27]
As of June 30, 2014 and 2013, the total outstanding borrowings under the Bank of America term loan was $6,533,000 and $9,333,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $17,699,000 and $10,899,000 as of June 30, 2014 and 2013, respectively. The interest rates for these loans ranged from 1.19% to 1.65% per annum at June 30, 2014 and from 1.23%  to 1.69% per annum at June 30, 2013, respectively. As of June 30, 2014, the unused revolving line of credit with Bank of America was $22,301,000.

[0001445305-14-003958:notes:28]
CTBC Bank

[0001445305-14-003958:notes:29]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollars or $9,898,000 U.S. dollars equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollars or $14,912,000 U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

[0001445305-14-003958:notes:30]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

[0001445305-14-003958:notes:31]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $22,055,000 and $14,939,000 at June 30, 2014 and 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at June 30, 2014 and 2013, respectively. The interest rate for the loan was at 1.15% and 1.20% per annum at June 30, 2014 and 2013, respectively. At June 30, 2014, NT$340,000,000 or $11,361,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001445305-14-003958:notes:32]
Covenant Compliance

[0001445305-14-003958:notes:33]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001445305-14-003958:notes:34]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001445305-14-003958:notes:35]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001445305-14-003958:notes:36]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001445305-14-003958:notes:37]
As of June 30, 2014 and 2013, the total assets of $751,396,000 and $586,742,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan, As of June 30, 2014 and 2013, total assets collateralizing the term loan with Bank of America were $17,584,000 and $17,813,000. As of June 30, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001445305-14-003958:notes:38]
As of June 30, 2014 and 2013, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,345,000 and $27,702,000, respectively. There are no financial covenants associated with the term loan with China Trust Bank at June 30, 2014.

[0001445305-14-003958:notes:39]
Debt Maturities

[0001445305-14-003958:notes:40]
The following table as of June 30, 2014, summarizes future minimum principal payments on the Company’s debts excluding capital leases (in thousands):

[0001445305-14-003958:notes:41]
| Fiscal Years Ending June 30, |  |
| 2015 | $ | 42,554 |  |
| 2016 | 2,800 |  |
| 2017 | 933 |  |
| 2018 | — |  |
| 2019 | — |  |
| Thereafter | — |  |
| Total | $ | 46,287 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-14-003958:notes:42]
Stock-based Compensation and Stockholders’ Equity

[0001445305-14-003958:notes:43]
Equity Incentive Plan

[0001445305-14-003958:notes:44]
In January 2011, the Board of Directors approved an amendment to the 2006 Equity Incentive Plan (the “2006 Plan”) that increased by 2,000,000 the aggregate maximum number of shares that may be issued under the 2006 Plan. The amendment to the 2006 Plan was approved by the Company’s stockholders in February 2011. The authorized number of shares that may be issued under the 2006 Plan automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant and options vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. The 2006 Plan is the successor equity incentive plan to the Company's 1998 Stock Option Plan. As of June 30, 2014, the Company had 341,617 authorized shares available for future issuance under the 2006 plan.

[0001445305-14-003958:notes:45]
Restricted Stock Awards

[0001445305-14-003958:notes:46]
Restricted stock awards are share awards that provide the rights to a set number of shares of the Company’s stock on the grant date. In August 2008, the Compensation Committee of the Board of Directors of the Company (the “Committee”) approved the terms of an agreement (the “Option Exercise Agreement”) with Charles Liang, a director and President and Chief Executive Officer of the Company, pursuant to which Mr. Liang exercised a fully vested option previously granted to him for the purchase of 925,000 shares. The option was exercised using a “net-exercise” procedure in which he was issued a number of shares representing the spread between the option exercise price and the then current market value of the shares subject to the option (898,205 shares based upon the market value as of the date of exercise). The shares issued upon exercise of the option are subject to vesting over five years. Vesting of the shares subject to the award may accelerate in certain circumstances pursuant to the terms of the Option Exercise Agreement. The Company determined that there is no incremental fair value of the option exchanged for the award. 898,205 and 718,564 shares were vested as of June 30, 2014 and 2013, respectively.

[0001445305-14-003958:notes:47]
In November 2008, the Committee approved the terms of an Option Exercise Agreement with Chiu-Chu Liang, a director and Vice President of Operations & Treasurer of the Company and Shiow-Meei Liaw, Senior Warehouse Manager of the Company, pursuant to which they exercised fully vested options previously granted to them for the purchase of 185,263 and 92,631 shares, respectively. They exercised the options using a “net-exercise” procedure in which they were issued a number of shares representing the spread between the option exercise price and the then current market value of the shares subject to the option (182,611 and 91,305 shares, respectively, based upon the market value as of the date of exercise). The shares issued upon exercise of the options are subject to vesting over two years. Vesting of the shares subject to the awards may accelerate in certain circumstances pursuant to the terms of the applicable Option Exercise Agreement. The Company determined that there is no incremental fair value of the option exchanged for the awards. The awards were fully vested as of June 30, 2012.

[0001445305-14-003958:notes:48]
Determining Fair Value

[0001445305-14-003958:notes:49]
Valuation and amortization method—The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001445305-14-003958:notes:50]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and the exercise factors for the stock options granted prior to June 30, 2011. For stock options granted after June 30, 2011, the expected term is based on a combination of the Company's peer group and the Company's historical experience.

[0001445305-14-003958:notes:51]
Expected Volatility—Expected volatility is based on a combination of the Company's implied and historical volatility.

[0001445305-14-003958:notes:52]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001445305-14-003958:notes:53]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the U.S. Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001445305-14-003958:notes:54]
Estimated Forfeitures—The estimated forfeiture rate is based on the Company’s historical forfeiture rates and the estimate is revised in subsequent periods if actual forfeitures differ from the estimate.

[0001445305-14-003958:notes:55]
The fair value of stock option grants for the years ended June 30, 2014, 2013 and 2012 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001445305-14-003958:notes:56]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Risk-free interest rate | 1.53% - 1.90% |  |  | 0.65% - 0.90% |  |  | 0.83% - 1.32% |  |
| Expected life | 5.49 - 5.58 years |  |  | 5.03 - 5.15 years |  |  | 5.01 - 5.04 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 43.48% - 50.07% |  |  | 51.27% - 51.76% |  |  | 45.62% - 53.72% |  |
| Weighted-average fair value | $ | 7.23 |  |  | $ | 4.53 |  |  | $ | 7.15 |  |

[0001445305-14-003958:notes:57]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the years ended June 30, 2014, 2013 and 2012 (in thousands):

[0001445305-14-003958:notes:58]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Cost of sales | $ | 941 |  |  | $ | 953 |  |  | $ | 783 |  |
| Research and development | 6,783 |  |  | 6,527 |  |  | 5,542 |  |
| Sales and marketing | 1,260 |  |  | 1,541 |  |  | 1,469 |  |
| General and administrative | 2,078 |  |  | 2,340 |  |  | 2,458 |  |
| Stock-based compensation expense before taxes | 11,062 |  |  | 11,361 |  |  | 10,252 |  |
| Income tax impact | (2,426 | ) |  | (548 | ) |  | (1,582 | ) |
| Stock-based compensation expense, net | $ | 8,636 |  |  | $ | 10,813 |  |  | $ | 8,670 |  |

[0001445305-14-003958:notes:59]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $7,041,000, $1,734,000 and $3,421,000 of excess tax benefits accounted in the Company’s additional paid-in capital in the year ended June 30, 2014, 2013 and 2012, respectively. The Company had excess tax benefits that are classified as cash from financing activities of $2,992,000, $865,000 and $2,047,000 in the year ended June 30, 2014, 2013 and 2012, respectively, for options issued since July 1, 2006. Excess tax benefits for stock options issued prior to July 1, 2006 continue to be classified as cash from operating activities.

[0001445305-14-003958:notes:60]
Stock Option Activity

[0001445305-14-003958:notes:61]
The following table summarizes stock option activity during the years ended June 30, 2014, 2013 and 2012 under all stock option plans:

[0001445305-14-003958:notes:62]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2011 (6,617,414 shares exercisable at weighted average exercise price of $7.18 per share) |  | 10,480,785 |  |  | $ | 8.86 |  |  |  |  |  |
| Granted (weighted average fair value of $7.15) |  | 2,381,700 |  |  | 15.89 |  |  |  |  |  |
| Exercised |  | (1,211,070 | ) |  | 7.06 |  |  |  |  |  |
| Forfeited |  | (349,187 | ) |  | 14.60 |  |  |  |  |  |
| Balance as of June 30, 2012 (7,410,152 shares exercisable at weighted average exercise price of $8.25 per share) |  | 11,302,228 |  |  | 10.36 |  |  |  |  |  |
| Granted (weighted average fair value of $4.53) |  | 1,952,270 |  |  | 11.83 |  |  |  |  |  |
| Exercised |  | (612,034 | ) |  | 3.01 |  |  |  |  |  |
| Forfeited |  | (436,286 | ) |  | 14.01 |  |  |  |  |  |
| Balance as of June 30, 2013 (8,731,818 shares exercisable at weighted average exercise price of $9.66 per share) |  | 12,206,178 |  |  | 10.83 |  |  |  |  |  |
| Granted (weighted average fair value of $7.23) |  | 1,808,006 |  |  | 15.87 |  |  |  |  |  |
| Exercised |  | (2,863,878 | ) |  | 8.36 |  |  |  |  |  |
| Forfeited |  | (244,704 | ) |  | 14.25 |  |  |  |  |  |
| Balance as of June 30, 2014 |  | 10,905,602 |  |  | $ | 12.24 |  |  | 6.28 |  | $ | 142,053 |  |
| Options vested and expected to vest at June 30, 2014 |  | 10,633,458 |  |  | $ | 12.16 |  |  | 6.20 |  | $ | 139,430 |  |
| Options vested and exercisable at June 30, 2014 |  | 7,558,631 |  |  | $ | 11.05 |  |  | 5.21 |  | $ | 107,481 |  |

[0001445305-14-003958:notes:63]
The total pretax intrinsic value of options exercised during the years ended June 30, 2014, 2013 and 2012 was $30,165,000, $4,614,000 and $11,589,000, respectively. As of June 30, 2014, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted since July 1, 2006 to employees and non-employee directors was $19,236,000, which will be recognized over a weighted-average vesting period of approximately 2.4 years.

[0001445305-14-003958:notes:64]
Additional information regarding options outstanding as of June 30, 2014, is as follows:

[0001445305-14-003958:notes:65]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $2.60 - 6.14 |  | 1,373,230 |  |  | 3.37 |  | $ | 4.87 |  |  | 1,373,230 |  |  | $ | 4.87 |  |
| 6.21 - 8.36 |  | 1,149,959 |  |  | 4.08 |  | 7.97 |  |  | 1,149,959 |  |  | 7.97 |  |
| 8.47 - 10.35 |  | 1,355,173 |  |  | 6.76 |  | 9.62 |  |  | 761,809 |  |  | 9.55 |  |
| 10.66 - 11.76 |  | 1,259,691 |  |  | 6.02 |  | 10.92 |  |  | 1,025,009 |  |  | 10.74 |  |
| 11.81 - 13.61 |  | 1,313,886 |  |  | 6.73 |  | 12.70 |  |  | 1,037,201 |  |  | 12.72 |  |
| 13.67 - 14.23 |  | 1,333,831 |  |  | 6.53 |  | 13.98 |  |  | 677,016 |  |  | 13.81 |  |
| 15.22 - 17.29 |  | 1,369,860 |  |  | 7.54 |  | 16.41 |  |  | 839,991 |  |  | 16.31 |  |
| 17.69 - 18.93 |  | 1,496,712 |  |  | 8.24 |  | 18.58 |  |  | 607,694 |  |  | 18.67 |  |
| 20.70 |  | 231,260 |  |  | 8.56 |  | 20.70 |  |  | 86,722 |  |  | 20.70 |  |
| 21.86 |  | 22,000 |  |  | 9.62 |  | 21.86 |  |  | — |  |  | — |  |
| $2.60 - $21.86 |  | 10,905,602 |  |  | 6.28 |  | $ | 12.24 |  |  | 7,558,631 |  |  | $ | 11.05 |  |

[0001445305-14-003958:notes:66]
Restricted Stock Award Activity

[0001445305-14-003958:notes:67]
The following table summarizes the Company’s restricted stock award activity for the year ended June 30, 2014, 2013 and 2012:

[0001445305-14-003958:notes:68]
|  | Restricted Stock Awards |
|  | Numberof Shares |  | WeightedAverageGrant DateFair ValuePer Share |
| Nonvested stock at June 30, 2011 | 538,923 |  |  | $ | 10.66 |  |
| Granted | 3,500 |  |  | 17.29 |  |
| Vested | (179,641 | ) |  | 10.66 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2012 | 362,782 |  |  | 10.72 |  |
| Granted | — |  |  | — |  |
| Vested | (183,141 | ) |  | 10.79 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2013 | 179,641 |  |  | 10.66 |  |
| Granted | 3,500 |  |  | 14.23 |  |
| Vested | (183,141 | ) |  | 10.73 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at June 30, 2014 | — |  |  | $ | — |  |

[0001445305-14-003958:notes:69]
The total pretax intrinsic value of restricted stock awards vested was $1,965,000, $2,225,000 and $2,375,000 for the years ended June 30, 2014, 2013 and 2012, respectively. In fiscal year 2014, 2013 and 2012, upon vesting, 183,141, 183,141 and 179,641 shares of restricted stock awards were partially net share-settled such that the Company withheld 51,583, 85,091 and 83,857 shares, respectively, with value equivalent to an officer's minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock awards on their vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities were $681,000, $1,034,000 and $1,109,000 in fiscal year 2014, 2013 and 2012, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. There is no unvested restricted stock awards at June 30, 2014.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-14-003958:notes:70]
Net Income Per Common Share

[0001445305-14-003958:notes:71]
The Company’s restricted share awards subject to repurchase and settled in shares of common stock upon vesting have the nonforfeitable right to receive dividends on an equal basis with common stock and therefore are considered participating securities that must be included in the calculation of net income per share using the two-class method. Under the two-class method, basic and diluted net income per common share is determined by calculating net income per share for common stock and participating securities based on participation rights in undistributed earnings. Diluted net income per common share also considers the dilutive effect of in-the-money stock options, calculated using the treasury stock method. Under the treasury stock method, the amount of assumed proceeds from unexercised stock options includes the amount of compensation cost attributable to future services not yet recognized, assumed proceeds from the exercise of the options, and the incremental income tax benefit or liability as if the options were exercised during the period.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001445305-14-003958:notes:72]
These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001445305-14-003958:notes:73]
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |
| June 30, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,637 |  |  | 2,637 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,637 |  |  | $ | 2,947 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001445305-14-003958:notes:74]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for fiscal year 2014 and 2013 (in thousands):

[0001445305-14-003958:notes:75]
|  | June 30, |
|  | 2014 |  | 2013 |
| Balance as of beginning of year | $ | 2,637 |  |  | $ | 2,923 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | 10 |  |  | 14 |  |
| Sales and settlements at par | — |  |  | (300 | ) |
| Transfers in and/or out of Level 3 | — |  |  | — |  |
| Balance as of end of year | $ | 2,647 |  |  | $ | 2,637 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-003958:notes:76]
Fair Value Disclosure

[0001445305-14-003958:notes:77]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of June 30, 2014 and 2013. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001445305-14-003958:notes:78]
The following table sets forth the Company’s cash equivalents and long-term investments as of June 30, 2014 and 2013 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001445305-14-003958:notes:79]
The above table excludes $96,324,000 and $92,495,000 of cash and $746,000 and $1,139,000 of certificates of deposit held by the Company as of June 30, 2014 and 2013, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in fiscal year 2014 and 2013.

[0001445305-14-003958:notes:80]
The following is a summary of the Company’s long-term investments as of June 30, 2014 and 2013 (in thousands):

[0001445305-14-003958:notes:81]
|  | June 30, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |
|  | June 30, 2013 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (113 | ) |  | $ | 2,637 |  |

[0001445305-14-003958:notes:82]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2014 and 2013, short-term and long-term debt of $46,287,000 and $35,171,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as they are not actively traded and are valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001445305-14-003958:notes:83]
Foreign Currency Translation

[0001445305-14-003958:notes:84]
The functional currency of the Company’s international subsidiaries is the U.S. dollar. Assets and liabilities of the Company's international subsidiaries that are denominated in the local currency are remeasured into U.S. dollars at period-end exchange rates and revenue and expenses that are denominated in the local currency are remeasured into U.S. dollars at the average exchange rates during the period. Accordingly, remeasurement of foreign currency accounts and foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001445305-14-003958:notes:85]
Long-Lived Assets

[0001445305-14-003958:notes:86]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-003958:notes:87]
Income Taxes

[0001445305-14-003958:notes:88]
The components of income before income tax provision for the years ended June 30, 2014, 2013 and 2012 are as follows (in thousands):

[0001445305-14-003958:notes:89]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| United States | $ | 66,152 |  |  | $ | 14,102 |  |  | $ | 41,540 |  |
| Foreign | 13,442 |  |  | 12,494 |  |  | 3,811 |  |
| Income before income tax provision | $ | 79,594 |  |  | $ | 26,596 |  |  | $ | 45,351 |  |

[0001445305-14-003958:notes:90]
The income tax provision for the years ended June 30, 2014, 2013 and 2012, consists of the following (in thousands):

[0001445305-14-003958:notes:91]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Current: |  |  |  |  |  |
| Federal | $ | 20,102 |  |  | $ | 7,904 |  |  | $ | 17,210 |  |
| State | 624 |  |  | 684 |  |  | 817 |  |
| Foreign | 5,252 |  |  | 3,806 |  |  | 1,206 |  |
|  | 25,978 |  |  | 12,394 |  |  | 19,233 |  |
| Deferred: |  |  |  |  |  |
| Federal | 122 |  |  | (5,984 | ) |  | (2,862 | ) |
| State | (472 | ) |  | (1,093 | ) |  | (873 | ) |
| Foreign | (191 | ) |  | — |  |  | — |  |
|  | (541 | ) |  | (7,077 | ) |  | (3,735 | ) |
| Income tax provision | $ | 25,437 |  |  | $ | 5,317 |  |  | $ | 15,498 |  |

[0001445305-14-003958:notes:92]
The Company’s net deferred tax assets as of June 30, 2014 and 2013, consist of the following (in thousands):

[0001445305-14-003958:notes:93]
|  | June 30, |
|  | 2014 |  | 2013 |
| Warranty accrual | $ | 2,459 |  |  | $ | 2,204 |  |
| Marketing fund accrual | 938 |  |  | 795 |  |
| Inventory valuation | 9,472 |  |  | 10,313 |  |
| Stock-based compensation | 4,114 |  |  | 3,889 |  |
| Research and development credit | 1,938 |  |  | 1,906 |  |
| Other | 4,719 |  |  | 4,216 |  |
| Total deferred income tax assets | 23,640 |  |  | 23,323 |  |
| Deferred tax liabilities-depreciation and other | (644 | ) |  | (262 | ) |
| Deferred income tax assets-net | $ | 22,996 |  |  | $ | 23,061 |  |

[0001445305-14-003958:notes:94]
The cumulative undistributed earnings of our foreign subsidiaries of $22,737,000 at June 30, 2014 are considered to be indefinitely reinvested and accordingly, no provisions for federal and state income taxes have been provided thereon. The Company determined that the calculation of the amount of unrecognized deferred tax liability related to these cumulative unremitted earnings was not practicable. Upon distribution of those earnings in the form of dividends or otherwise, the Company would be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes payable to various foreign countries.

[0001445305-14-003958:notes:95]
Income tax benefits resulting from stock option transactions of $7,041,000, $1,734,000 and $3,421,000 were credited to stockholders’ equity in the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:notes:96]
The following is a reconciliation for the years ended June 30, 2014, 2013 and 2012, of the statutory rate to the Company’s effective federal tax rate:

[0001445305-14-003958:notes:97]
|  |  | Years Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Tax at statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income tax, net of federal tax benefit |  | 3.3 |  |  | 3.8 |  |  | 2.5 |  |
| Foreign tax rate differences |  | (2.5 | ) |  | (6.7 | ) |  | (1.0 | ) |
| Research and development tax credit |  | (4.0 | ) |  | (14.4 | ) |  | (5.7 | ) |
| Qualified production activity deduction |  | (1.8 | ) |  | (2.9 | ) |  | (2.4 | ) |
| Stock based compensation |  | 4.5 |  |  | 13.5 |  |  | 6.2 |  |
| Uncertain tax positions |  | (2.1 | ) |  | (11.0 | ) |  | (0.5 | ) |
| Subpart F income inclusion |  | (3.9 | ) |  | (3.8 | ) |  | (0.6 | ) |
| Foreign withholding tax |  | 4.1 |  |  | 5.5 |  |  | 2.0 |  |
| Federal tax return to provision adjustment |  | (0.7 | ) |  | (3.9 | ) |  | (0.2 | ) |
| Other |  | 0.1 |  |  | 4.9 |  |  | (1.1 | ) |
| Effective tax rate |  | 32.0 | % |  | 20.0 | % |  | 34.2 | % |

[0001445305-14-003958:notes:98]
As of June 30, 2014, the Company had state research and development tax credit carryforwards of $7,738,000. The state research and development tax credits will carryforward to offset future state income taxes. $4,755,000 of the state research and development tax credit carryforwards were attributable to excess tax deductions from stock options exercises, and were not included in the deferred tax assets shown above. The benefit of these carryforwards will be credited to equity when realized.

[0001445305-14-003958:notes:99]
In January 2013, the American Taxpayer Relief Act of 2012 reinstated the U.S. federal R&D tax credit for two years to December 31, 2013, retroactive to January 1, 2012. As a result, during fiscal year 2013, the Company recognized a total tax benefit of $3,708,000, of which $1,455,000 related to fiscal year 2012.

[0001445305-14-003958:notes:100]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001445305-14-003958:notes:101]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2011 | $ | 6,549 |  |
| Gross increases: |  |
| For current year’s tax positions | 1,302 |  |
| For prior years’ tax positions | 501 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (225 | ) |
| For prior year' tax positions | (102 | ) |
| Balance at June 30, 2012 | 8,025 |  |
| Gross increases: |  |
| For current year’s tax positions | 2,044 |  |
| For prior years’ tax positions | 490 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (2,470 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2013 | 8,089 |  |
| Gross increases: |  |
| For current year’s tax positions | 3,120 |  |
| For prior years’ tax positions | 132 |  |
| Gross decreases: |  |
| Settlements and releases due to the lapse of statutes of limitations | (1,726 | ) |
| For prior years’ tax positions | — |  |
| Balance at June 30, 2014 | $ | 9,615 |  |

[0001445305-14-003958:notes:102]
__________________________

[0001445305-14-003958:notes:103]
| * | excludes interest, penalties, federal benefit of state reserves |

[0001445305-14-003958:notes:104]
In March 2014, the California Franchise Tax Board and the Company agreed to all outstanding items related to the audit of the Company's California income tax returns for the fiscal years ended June 30, 2008 through June 30, 2010. As a result of the resolution, the Company recognized a net benefit to the provision for income taxes of $1,089,000, which included a reduction in interest expense of $46,000.

[0001445305-14-003958:notes:105]
In March 2013, the Internal Revenue Service and the Company agreed to all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended June 30, 2008 through June 30, 2010. As a result of the resolution, the Company recognized a net benefit to the provision for income taxes of $2,017,000, which included a reduction in interest expense of $266,000.

[0001445305-14-003958:notes:106]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, is $8,168,000 and $6,499,000 as of June 30, 2014 and 2013, respectively. In fiscal year 2014, the liability for gross unrecognized tax benefit was reduced by $1,726,000 primarily due to the audit settlement with California Franchise Tax Board and foreign tax authority.

[0001445305-14-003958:notes:107]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the consolidated statements of operations. As of June 30, 2014 and 2013, the Company had accrued $818,000 and $797,000 for the payment of interest and penalties relating to unrecognized tax benefits, respectively. During fiscal year 2014, 2013 and 2012, there was no material change in the total amount of the liability for accrued interest and penalties related to the unrecognized tax benefits.

[0001445305-14-003958:notes:108]
The Company is subject to U.S. federal income tax as well as income taxes in many state and foreign jurisdictions.   The federal statute of limitations remain open in general for tax years 2011 through 2014. The state statute of limitations remain open in general for tax years 2009 through 2014. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2007 through 2014. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:IncomeTaxPolicyTextBlock

[0001445305-14-003958:notes:109]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and for income tax reporting purposes, net operating loss carryforwards and other tax credits measured by applying currently enacted tax laws. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001445305-14-003958:notes:110]
The Company recognizes a tax liability for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related change in its tax provision during the period in which the Company makes such determination.


## us-gaap:InventoryDisclosureTextBlock

[0001445305-14-003958:notes:111]
Inventory

[0001445305-14-003958:notes:112]
Inventory as of June 30, 2014 and 2013 consisted of the following (in thousands):

[0001445305-14-003958:notes:113]
|  | June 30, |
|  | 2014 |  | 2013 |
| Finished goods | $ | 246,803 |  |  | $ | 185,459 |  |
| Work in process | 18,794 |  |  | 10,440 |  |
| Purchased parts and raw materials | 50,240 |  |  | 58,271 |  |
| Total inventory | $ | 315,837 |  |  | $ | 254,170 |  |


## us-gaap:InventoryPolicyTextBlock

[0001445305-14-003958:notes:114]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units to lower of cost or market or for excess and obsolescence based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001445305-14-003958:notes:115]
Long-term Investments

[0001445305-14-003958:notes:116]
As of June 30, 2014 and 2013, the Company held $2,647,000 and $2,637,000, respectively, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at June 30, 2014 and June 30, 2013. These auction rate preferred shares have no stated maturity date.

[0001445305-14-003958:notes:117]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of June 30, 2014 and 2013, $2,647,000 and $2,637,000 of these auction rate securities have been classified as long-term available-for-sale investments, respectively.

[0001445305-14-003958:notes:118]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of June 30, 2014 and 2013. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of June 30, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.56%, 3 years and 0.28%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001445305-14-003958:notes:119]
Based on this assessment of fair value, the Company determined there was a recovery in fair value of its auction rate securities of $10,000 and $14,000 during the year ended June 30, 2014 and 2013, respectively. There was a cumulative total decline of $103,000 and $113,000 as of June 30, 2014 and 2013, respectively. That amount has been recorded as a component of other comprehensive income. As of June 30, 2014 and 2013, the Company has recorded an accumulated unrealized loss of $62,000 and $68,000, respectively, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001445305-14-003958:notes:120]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In fiscal year 2014, there was no auction rate securities redeemed or sold. In fiscal year 2013 and 2012, $300,000 and $2,475,000 of auction rate securities were redeemed at par, respectively.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001445305-14-003958:notes:121]
Accounts Receivable Allowances

[0001445305-14-003958:notes:122]
The Company has established an allowance for doubtful accounts and an allowance for sales returns. The allowance for doubtful accounts is based upon the credit risk of specific customers, historical trends related to past losses and other relevant factors. The Company also provides its customers with product return rights. A provision for such returns is provided for in the same period that the related sales are recorded based upon contractual return rights and historical trends. Accounts receivable allowances as of June 30, 2014, 2013 and 2012, consisted of the following (in thousands):

[0001445305-14-003958:notes:123]
|  | BeginningBalance |  | Charged toCost andExpenses |  | Deductions |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2014 | $ | 1,562 |  |  | $ | 1,476 |  |  | $ | (1,564 | ) |  | $ | 1,474 |  |
| Year ended June 30, 2013 | 777 |  |  | 929 |  |  | (144 | ) |  | 1,562 |  |
| Year ended June 30, 2012 | 738 |  |  | 217 |  |  | (178 | ) |  | 777 |  |
| Allowance for sales returns |  |  |  |  |  |  |  |
| Year ended June 30, 2014 | $ | 404 |  |  | $ | 8,985 |  |  | $ | (8,941 | ) |  | $ | 448 |  |
| Year ended June 30, 2013 | 329 |  |  | 7,463 |  |  | (7,388 | ) |  | 404 |  |
| Year ended June 30, 2012 | 324 |  |  | 6,997 |  |  | (6,992 | ) |  | 329 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-003958:notes:124]
Adoption of New Accounting Pronouncements

[0001445305-14-003958:notes:125]
In February 2013, the FASB issued authoritative guidance associated with reporting of amounts reclassified out of accumulated other comprehensive income, which requires companies to present significant reclassifications out of accumulated other comprehensive income in their entirety in the statement of operations or in a separate footnote to the financial statements. For amounts that are not required to be reclassified in their entirety to net income, the standard requires companies to cross-reference to related footnoted disclosures. The adoption of this guidance did not have a material impact on the Company's financial statement disclosure, results of operations or financial position.

[0001445305-14-003958:notes:126]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. The Company is currently reviewing the provisions but does not expect it to have a material impact on the Company’s financial statement disclosures, results of operations or financial position.

[0001445305-14-003958:notes:127]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company currently plans to adopt the new disclosure effective on July 1, 2014. The Company does not believe the adoption of this guidance will have a material impact on the Company's financial statement disclosures, results of operations or financial position.

[0001445305-14-003958:notes:128]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations or financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001445305-14-003958:notes:129]
Summary of Significant Accounting Policies

[0001445305-14-003958:notes:130]
Organization

[0001445305-14-003958:notes:131]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in San Jose, California, the Netherlands, Taiwan, China and Japan.

[0001445305-14-003958:notes:132]
Use of Estimates

[0001445305-14-003958:notes:133]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (“U.S. GAAP”) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to: allowances for doubtful accounts and sales returns, cooperative marketing accruals, inventory valuation, product warranty accruals, stock-based compensation, impairment of short-term and long-term investments and income taxes. Actual results could differ from those estimates.

[0001445305-14-003958:notes:134]
Fair Value of Financial Instruments

[0001445305-14-003958:notes:135]
The Company accounts for certain assets and liabilities at fair value. Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents and long-term investments are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms. The hierarchy below lists three levels of fair value based on the extent to which inputs used in measuring fair value are observable in the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001445305-14-003958:notes:136]
| • | Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities; |

[0001445305-14-003958:notes:137]
| • | Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and |

[0001445305-14-003958:notes:138]
| • | Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable. |

[0001445305-14-003958:notes:139]
The Company classifies its long-term investments in auction-rate securities ("auction rate securities") as long-term available-for-sale investments. Auction rate securities consist of municipal securities. The discounted cash flow model is used to estimate the fair value of the auction rate securities. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a component of accumulated other comprehensive income, net of tax.

[0001445305-14-003958:notes:140]
Inventory is valued at the lower of cost or market. Inventory consists of raw materials (principally components), work in process (principally products being assembled) and finished goods. Market value represents net realizable value for finished goods and work in process and replacement value of raw materials and parts. The Company evaluates inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, writes down the valuation of units to lower of cost or market or for excess and obsolescence based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for the Company's products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. The Company monitors the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjusts its estimate for determining future write downs. If in future periods, the Company experiences or anticipates a change in recovery rate compared with its historical experience, its gross margin would be affected. During fiscal years 2014, 2013 and 2012, the Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $2,254,000, $9,725,000 and $8,579,000, respectively.

[0001445305-14-003958:notes:141]
Property, Plant and Equipment

[0001445305-14-003958:notes:142]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001445305-14-003958:notes:143]
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Software | 3 to 5 years |
| Buildings | 39 years |
| Building improvements | 20 years |
| Land improvements | 15 years |
| Leasehold improvements | shorter of lease term or estimated useful life |

[0001445305-14-003958:notes:144]
For assets acquired and financed under capital leases, the present value of the future minimum lease payments is recorded at the date of acquisition as property and equipment with the corresponding amount recorded as a capital lease obligation, and the amortization is computed on a straight-line basis over the shorter of lease term or estimated useful life.

[0001445305-14-003958:notes:145]
Other Assets

[0001445305-14-003958:notes:146]
As of June 30, 2014, other assets consist primarily of a long-term prepaid royalty license of $1,246,000, an investment in a privately held company of $750,000 and restricted cash of $450,000. As of June 30, 2013, other assets consist primarily of a long-term prepaid royalty license of $1,496,000, an investment in a privately held company of $750,000 and restricted cash of $847,000. Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California and bank guarantees in connection with office leases in the Netherlands.

[0001445305-14-003958:notes:147]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge has been recorded in any of the periods presented.

[0001445305-14-003958:notes:148]
Revenue Recognition

[0001445305-14-003958:notes:149]
The Company recognizes revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. The Company’s standard arrangement with its customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination. The Company generally does not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, the Company regularly reviews its history of actual returns for each major product line. The Company also communicates regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with distributors

[0001445305-14-003958:notes:150]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At June 30, 2014 and 2013, the Company had deferred revenue of $7,665,000 and $1,019,000 and related deferred product costs of $6,674,000 and $711,000, respectively, related to shipments to customers pending acceptance.

[0001445305-14-003958:notes:151]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. The Company also makes estimates of the uncollectibility of accounts receivable, analyzing accounts receivable and historical bad debts, customer concentrations, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, the Company evaluates aged items in the accounts receivable aging report and provides an allowance in an amount the Company deems adequate for doubtful accounts. Our provision for bad debt was $1,476,000, $929,000 and $217,000 in fiscal years 2014, 2013 and 2012, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than the Company's historical experience, or if other circumstances arise, the Company's estimates of the recoverability of amounts due to the Company could be overstated, and additional allowances could be required, which could have an adverse impact on its reported operating expenses. The Company provides for price protection to certain distributors. The Company assesses the market competition and product technology obsolescence, and makes price adjustments based on its judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on the distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time the Company reduces the product prices.

[0001445305-14-003958:notes:152]
The Company has an immaterial amount of service revenue relating to on-site service and non-warranty repairs. Revenue for on-site service is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001445305-14-003958:notes:153]
Product Warranties

[0001445305-14-003958:notes:154]
The Company offers product warranties ranging from 15 to 39 months against any defective products. The Company accrues for estimated returns of defective products at the time revenue is recognized based on historical warranty experience and recent trends. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The Company’s estimates and assumptions used have been historically close to actual. If in future periods the Company experiences or anticipates an increase or decrease in warranty claims as a result of new product introductions or changes in unit volumes compared with its historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, the Company intends to adjust its estimates appropriately. The following table presents for the years ended June 30, 2014, 2013 and 2012, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities (in thousands):

[0001445305-14-003958:notes:155]
|  | June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Balance, beginning of year | $ | 6,472 |  |  | $ | 5,522 |  |  | $ | 4,710 |  |
| Provision for warranty | 14,175 |  |  | 13,438 |  |  | 12,226 |  |
| Costs charged to accrual | (13,950 | ) |  | (12,487 | ) |  | (12,127 | ) |
| Change in estimated liability for pre-existing warranties | 386 |  |  | (1 | ) |  | 713 |  |
| Balance, end of year | $ | 7,083 |  |  | $ | 6,472 |  |  | $ | 5,522 |  |

[0001445305-14-003958:notes:156]
Software Development Costs

[0001445305-14-003958:notes:157]
Software development costs are included in research and development and are expensed as incurred. Software development costs are capitalized beginning when technological feasibility has been established and ending when a product is available for general release to customers. To date, the period between achieving technological feasibility and the issuance of such software has been short and software development costs qualifying for capitalization have been insignificant.

[0001445305-14-003958:notes:158]
Research and Development

[0001445305-14-003958:notes:159]
Research and development costs are expensed as incurred and consist primarily of salaries, consulting services, other direct expenses and other engineering expenses. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $3,132,000, $2,112,000 and $2,866,000 for the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:notes:160]
Cooperative Marketing Arrangements

[0001445305-14-003958:notes:161]
The Company has arrangements with resellers of its products to reimburse the resellers for cooperative marketing costs meeting specified criteria. The Company accrues the cooperative marketing costs based on these arrangements and its estimate for resellers’ claims for marketing activities. The Company records marketing costs meeting such specified criteria within sales and marketing expenses in the consolidated statements of operations. For those marketing costs that do not meet the specified criteria, the amounts are recorded as a reduction to sales in the consolidated statements of operations.

[0001445305-14-003958:notes:162]
Total cooperative marketing costs charged to sales and marketing expenses for the years ended June 30, 2014, 2013 and 2012, were $2,058,000, $1,550,000 and $2,529,000, respectively. Total amounts recorded as reductions to sales for the years ended June 30, 2014, 2013 and 2012, were $2,829,000, $2,610,000 and $2,416,000, respectively.

[0001445305-14-003958:notes:163]
Advertising costs are expensed as incurred. Total advertising and promotional expenses, including cooperative marketing payments, were $5,183,000, $4,085,000 and $4,382,000 for the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:notes:164]
Stock-Based Compensation

[0001445305-14-003958:notes:165]
The Company measures and recognizes the compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors, including employee stock options and restricted stock awards, based on estimated fair values. The Company is required to estimate the fair value of share-based awards on the date of grant. The Company has estimated the fair value of stock options and restricted stock awards as of the date of grant using the Black-Scholes option pricing model. The Black-Scholes model considers, among other factors, the expected life of the award, the expected volatility of the Company's stock price and the expected dividend yield. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. Because share-based compensation expense is based on awards ultimately expected to vest, it has been reduced for forfeitures.

[0001445305-14-003958:notes:166]
Shipping and Handling Fees

[0001445305-14-003958:notes:167]
The Company incurred shipping costs of $1,605,000, $1,475,000 and $1,776,000 for the years ended June 30, 2014, 2013 and 2012, respectively, that were included in sales and marketing expenses.

[0001445305-14-003958:notes:168]
The computation of basic and diluted net income per common share using the two-class method is as follows (in thousands, except per share amounts):

[0001445305-14-003958:notes:169]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Basic net income per common share calculation |  |  |  |  |  |
| Net income | $ | 54,157 |  |  | $ | 21,279 |  |  | $ | 29,853 |  |
| Less: Undistributed earnings allocated to participating securities | (36 | ) |  | (106 | ) |  | (280 | ) |
| Net income attributable to common shares—basic | $ | 54,121 |  |  | $ | 21,173 |  |  | $ | 29,573 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 43,599 |  |  | 41,992 |  |  | 40,890 |  |
| Basic net income per common share | $ | 1.24 |  |  | $ | 0.50 |  |  | $ | 0.72 |  |
| Diluted net income per common share calculation |  |  |  |  |  |
| Net income | $ | 54,157 |  |  | $ | 21,279 |  |  | $ | 29,853 |  |
| Less: Undistributed earnings allocated to participating securities | (34 | ) |  | (101 | ) |  | (260 | ) |
| Net income attributable to common shares—diluted | $ | 54,123 |  |  | $ | 21,178 |  |  | $ | 29,593 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 43,599 |  |  | 41,992 |  |  | 40,890 |  |
| Dilutive effect of options to purchase common stock | 2,913 |  |  | 1,915 |  |  | 3,262 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 46,512 |  |  | 43,907 |  |  | 44,152 |  |
| Diluted net income per common share | $ | 1.16 |  |  | $ | 0.48 |  |  | $ | 0.67 |  |

[0001445305-14-003958:notes:170]
For the years ended June 30, 2014, 2013 and 2012, the Company had stock options outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The shares of common stock issuable upon exercise of such anti-dilutive outstanding stock options were 3,465,000, 6,241,000 and 3,252,000 for the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:notes:171]
Certain Significant Risks and Uncertainties

[0001445305-14-003958:notes:172]
The Company operates in the high technology industry and is subject to a number of risks, some of which are beyond the Company’s control, that could have a material adverse effect on the Company’s business, operating results, and financial condition. These risks include variability and uncertainty of revenues and operating results; product obsolescence; geographic concentration; international operations; dependence on key personnel; competition; intellectual property claims and litigation; management of growth; and limited sources of supply.

[0001445305-14-003958:notes:173]
Concentration of Supplier Risk

[0001445305-14-003958:notes:174]
Certain raw materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 23.4%, 21.9%, and 21.7% of total purchases for the years ended June 30, 2014, 2013 and 2012, respectively. Ablecom Technology, Inc., a related party of the Company as noted in Note 9, accounted for 16.1%, 18.9% and 19.5% of total purchases for the years ended June 30, 2014, 2013 and 2012, respectively.

[0001445305-14-003958:notes:175]
Concentration of Credit Risk

[0001445305-14-003958:notes:176]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents and long-term investments and accounts receivable. No single customer accounted for 10% or more of net sales in fiscal years 2014, 2013 and 2012.  No customer accounted for 10% or more of accounts receivable as of June 30, 2014. One customer accounted for 14.4% of accounts receivable as of June 30, 2013.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001445305-14-003958:notes:177]
Retirement Plan

[0001445305-14-003958:notes:178]
The Company sponsors a 401(k) savings plan for eligible U.S. employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the years ended June 30, 2014, 2013 and 2012.

[0001445305-14-003958:notes:179]
Beginning in March 2003, employees of Super Micro Computer, B.V. have the option to deduct a portion of their gross wages and invest the amount in a defined contribution plan. The Company has agreed to match 10% of the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the years ended June 30, 2014, 2013 and 2012, the Company’s matching contribution was $198,000, $133,000 and $115,000, respectively.

[0001445305-14-003958:notes:180]
The Company maintains a defined benefit pension plan of Super Micro Computer, Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. Plan assets of the funded defined benefit pension plan are deposited into a government-managed account in which the Company has no control over investment strategy. For the years ended June 30, 2014, 2013 and 2012, the Company’s contribution was $740,000, $660,000 and $509,000, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001445305-14-003958:notes:181]
Property, Plant, and Equipment

[0001445305-14-003958:notes:182]
Property, plant and equipment as of June 30, 2014 and 2013 consisted of the following (in thousands):

[0001445305-14-003958:notes:183]
|  | June 30, |
|  | 2014 |  | 2013 |
| Land | $ | 63,962 |  |  | $ | 41,774 |  |
| Buildings | 51,959 |  |  | 43,979 |  |
| Building and leasehold improvements | 7,683 |  |  | 7,483 |  |
| Buildings construction in progress (1) | 587 |  |  | — |  |
| Machinery and equipment | 34,342 |  |  | 26,941 |  |
| Furniture and fixtures | 5,892 |  |  | 4,731 |  |
| Purchased software | 3,606 |  |  | 5,380 |  |
| Purchased software construction in progress (2) | 2,548 |  |  | — |  |
|  | 170,579 |  |  | 130,288 |  |
| Accumulated depreciation and amortization | (39,990 | ) |  | (34,376 | ) |
| Property, plant and equipment, net | $ | 130,589 |  |  | $ | 95,912 |  |

[0001445305-14-003958:notes:184]
(1) On October 31, 2013, the Company completed the purchase of real property for $30,158,000. The property consists of approximately 324,000 square feet of building space on 36 acres of land. The purchase values allocated to the land and building were $22,178,000 and $7,980,000 respectively. In connection with the purchase of the property located in San Jose, California, the Company also engaged several contractors for the development and construction of improvements on the property, which is still in progress.

[0001445305-14-003958:notes:185]
(2) In May 2014, the Company began its implementation of a new enterprise resource planning, or ERP, system and capitalized the costs of the new ERP software and certain expenses associated directly with the development of the ERP system, which is still in progress.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001445305-14-003958:notes:186]
Quarterly Financial Data (Unaudited)

[0001445305-14-003958:notes:187]
The following table presents the Company’s unaudited quarterly financial data. This information has been prepared on a basis consistent with that of the audited consolidated financial statements. The Company believes that all necessary adjustments, consisting of normal recurring accruals and adjustments, have been included to present fairly the quarterly financial data. The Company’s quarterly results of operations for these periods are not necessarily indicative of future results of operations.

[0001445305-14-003958:notes:188]
|  | Three Months Ended |
|  | Sep. 30, 2013 |  | Dec. 31, 2013 |  | Mar. 31, 2014 |  | Jun. 30, 2014 |
|  | (In thousands, except per share data) |
| Net sales | $ | 309,016 |  |  | $ | 356,362 |  |  | $ | 373,755 |  |  | $ | 428,069 |  |
| Gross profit | $ | 46,792 |  |  | $ | 55,092 |  |  | $ | 57,264 |  |  | $ | 66,397 |  |
| Net income | $ | 7,699 |  |  | $ | 13,335 |  |  | $ | 16,574 |  |  | $ | 16,549 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.18 |  |  | $ | 0.31 |  |  | $ | 0.38 |  |  | $ | 0.37 |  |
| Diluted | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.35 |  |  | $ | 0.34 |  |

[0001445305-14-003958:notes:189]
|  | Three Months Ended |
|  | Sep. 30, 2012 |  | Dec. 31, 2012 |  | Mar. 31, 2013 |  | Jun. 30, 2013 |
|  | (In thousands, except per share data) |
| Net sales | $ | 270,707 |  |  | $ | 291,487 |  |  | $ | 278,034 |  |  | $ | 322,333 |  |
| Gross profit | $ | 35,015 |  |  | $ | 40,122 |  |  | $ | 38,893 |  |  | $ | 46,023 |  |
| Net income | $ | 899 |  |  | $ | 4,914 |  |  | $ | 7,040 |  |  | $ | 8,426 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.20 |  |
| Diluted | $ | 0.02 |  |  | $ | 0.11 |  |  | $ | 0.16 |  |  | $ | 0.19 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001445305-14-003958:notes:190]
Related-party and Other Transactions

[0001445305-14-003958:notes:191]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at June 30, 2014.

[0001445305-14-003958:notes:192]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001445305-14-003958:notes:193]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001445305-14-003958:notes:194]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001445305-14-003958:notes:195]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. For fiscal year 2014, 2013 and 2012, the Company purchased products from Ablecom totaling $201,848,000, $179,735,000 and $168,744,000, respectively. For fiscal year 2014, 2013 and 2012, the Company sold products to Ablecom totaling $14,576,000, $13,805,000 and $12,229,000, respectively.

[0001445305-14-003958:notes:196]
Amounts owed to the Company by Ablecom as of June 30, 2014 and 2013, were $621,000 and $974,000, respectively. Amounts owed to Ablecom by the Company as of June 30, 2014 and 2013, were $48,969,000 and $50,448,000, respectively. In fiscal year 2014, the Company paid Ablecom the majority of invoiced dollars between 63 and 98 days of invoice date. For the years ended June 30, 2014, 2013 and 2012, the Company paid $6,906,000, $5,076,000 and $5,042,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001445305-14-003958:notes:197]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $64,464,000 and $53,684,000 at June 30, 2014 and 2013, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001445305-14-003958:notes:198]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. The Management Company had no business operations as of June 30, 2012. In fiscal year 2014 and 2013, $(6,000) and $13,000 of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the consolidated statements of operations.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001445305-14-003958:notes:199]
The following is a summary of net sales by product type (in thousands):

[0001445305-14-003958:notes:200]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 740,789 |  |  | 50.5 | % |  | $ | 501,868 |  |  | 43.2 | % |  | $ | 447,000 |  |  | 44.1 | % |
| Subsystems and accessories | 726,413 |  |  | 49.5 | % |  | 660,693 |  |  | 56.8 | % |  | 566,874 |  |  | 55.9 | % |
| Total | $ | 1,467,202 |  |  | 100.0 | % |  | $ | 1,162,561 |  |  | 100.0 | % |  | $ | 1,013,874 |  |  | 100.0 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001445305-14-003958:notes:201]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the years ended June 30, 2014, 2013 and 2012, of net sales by geographic region (in thousands):

[0001445305-14-003958:notes:202]
|  | Years Ended June 30, |
|  | 2014 |  | 2013 |  | 2012 |
| Net sales: |  |  |  |  |  |
| United States | $ | 809,250 |  |  | $ | 629,869 |  |  | $ | 589,709 |  |
| Europe | 316,760 |  |  | 265,635 |  |  | 221,373 |  |
| Asia | 299,403 |  |  | 237,798 |  |  | 175,980 |  |
| Other | 41,789 |  |  | 29,259 |  |  | 26,812 |  |
|  | $ | 1,467,202 |  |  | $ | 1,162,561 |  |  | $ | 1,013,874 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001445305-14-003958:notes:203]
The following is a summary of long-lived assets, excluding financial instruments, deferred tax assets, other assets, goodwill and intangible assets (in thousands):

[0001445305-14-003958:notes:204]
|  | June 30, |
|  | 2014 |  | 2013 |
| Long-lived assets: |  |  |  |
| United States | $ | 94,119 |  |  | $ | 61,976 |  |
| Asia | 36,123 |  |  | 33,500 |  |
| Europe | 347 |  |  | 436 |  |
|  | $ | 130,589 |  |  | $ | 95,912 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-14-003958:notes:205]
Segment Reporting

[0001445305-14-003958:notes:206]
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001445305-14-003958:notes:207]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories done by the Company. No customer represented greater than 10% of the Company’s total net sales nor did net sales in any country other than the United States represent greater than 10% of the Company’s total net sales for any of the years ended June 30, 2014, 2013 and 2012. No customer accounted for 10% or more of the Company's accounts receivable as of June 30, 2014. One customer accounted for 14.4% of the Company's accounts receivable as of June 30, 2013.
