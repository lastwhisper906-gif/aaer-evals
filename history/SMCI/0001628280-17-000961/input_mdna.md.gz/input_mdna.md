# SMCI MD&A — 0001628280-17-000961


## mdna

[0001628280-17-000961:mdna:1]
[same as prior period, unchanged from 0001628280-16-020941:mdna:1]

[0001628280-17-000961:mdna:2]
[same as prior period, unchanged from 0001628280-16-020941:mdna:2]

[0001628280-17-000961:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, high performance computing (“HPC”), and Internet of Things (“IoT”)/embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Our net sales were $652.0 million and $1,180.9 million for the three and six months ended December 31, 2016, respectively, and $639.0 million and $1,158.6 million for the three and six months ended December 31, 2015, respectively. The increase in our net sales in the three and six months ended December 31, 2016 compared with the three and six months ended December 31, 2015 was primarily due to increased sales of our subsystems and accessories to our distributors. Net sales of optimized servers were $444.0 million and $801.5 million for the three and six months ended December 31, 2016, respectively, and $453.7 million and $810.0 million for the three and six months ended December 31, 2015, respectively, and net sales of subsystems and accessories were $208.0 million and $379.4 million for the three and six months ended December 31, 2016, respectively, and $185.2 million and $348.6 million for the three and six months ended December 31, 2015, respectively. In the three and six months ended December 31, 2016, we experienced a decrease in sales of our complete server systems primarily due to a decrease in ultra and data center optimized servers offset in part by growth in sales of high density Twin family of servers, storage, accelerated GPU computing servers or HPC and MicroBlade and strong growth from enterprise cloud and Asia Pacific, particularly China. The percentage of our net sales represented by sales of server systems decreased to 68.1% and 67.9% in the three and six months ended December 31, 2016 from 71.0% and 69.9% in the three and six months ended December 31, 2015, respectively.

[0001628280-17-000961:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $22.0 million and $35.5 million for the three and six months ended December 31, 2016, respectively, and $34.7 million and $48.4 million for the three and six months ended December 31, 2015, respectively. Our decrease in net income in the three and six months ended December 31, 2016 was primarily attributable to lower gross margins from sales of our complete server systems due to higher costs related to shortages of memory and solid state drives ("SSD") and higher operating expenses from headcount and annual salary increases to support our business growth.

[0001628280-17-000961:mdna:5]
We sell our server systems and subsystems and accessories through our direct sales force as well as through distributors and OEMs. We derived 53.8% and 52.1% of our net sales from products sold to direct customers and OEMs for the three and six months ended December 31, 2016, respectively. We derived 58.1% and 56.4% of our net sales from products sold to direct customers and OEMs for the three and six months ended December 31, 2015, respectively. None of our customers accounted for 10% or more of our net sales in the three and six months ended December 31, 2016. Sales to SoftLayer, a division of IBM Corporation, represented 15.0% and 12.8% of our net sales in the three and six months ended December 31, 2015. We derived 55.0% and 55.4% of our net sales from customers in the United States for the three and six months ended December 31, 2016, respectively, and 63.7% and 64.4% for the three and six months ended December 31, 2015, respectively.

[0001628280-17-000961:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.2% and 5.7% of our net sales for the three and six months ended December 31, 2016, respectively, and 4.7% and 5.1% of our net sales for the three and six months ended December 31, 2015, respectively.

[0001628280-17-000961:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2017, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers, and we have continued to improve our utilization of our overseas manufacturing

[0001628280-17-000961:mdna:8]
capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and six months ended December 31, 2016, our purchases from Ablecom represented 11.6% and 11.4% of our cost of sales, respectively, compared to 13.4% and 13.3% of our cost of sales for the three and six months ended December 31, 2015, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in an effort to reduce our cost of sales. In addition to providing contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-17-000961:mdna:9]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding (“DSOs”). In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001628280-17-000961:mdna:10]
[same as prior period, unchanged from 0001628280-16-020941:mdna:10]

[0001628280-17-000961:mdna:11]
The following is a summary of other financial highlights of the second quarter of fiscal 2017:

[0001628280-17-000961:mdna:12]
| • | Net cash provided by (used in) operating activities was $(54.9) million and $86.9 million during the six months ended December 31, 2016 and 2015, respectively. Our cash and cash equivalents, together with our investments, were $131.5 million at the end of the second quarter of fiscal year 2017, compared with $183.7 million at the end of fiscal year 2016. The decrease in our cash and cash equivalents, together with our investments at the end of the second quarter of fiscal year 2017 was primarily due to $54.9 million of cash used in our operating activities, $18.5 million used to purchase outstanding common stock and $17.4 million used to purchase property and equipment, of which $8.2 million was related to property and equipment for use at our Green Computing Park in San Jose, California, partially offset by $33.6 million of borrowings, net of repayments. |

[0001628280-17-000961:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the second quarter of fiscal year 2017 was 49 days, compared with 50 days at the end of fiscal year 2016. |

[0001628280-17-000961:mdna:14]
| • | Our inventory balance was $599.3 million at the end of the second quarter of fiscal year 2017, compared with $449.0 million at the end of fiscal year 2016. Days sales of inventory at the end of the second quarter of fiscal year 2017 was 91 days, compared with 87 days at the end of fiscal year 2016. |

[0001628280-17-000961:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $402.2 million at the end of the second quarter of fiscal year 2017 and $334.0 million at the end of fiscal year 2016. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-17-000961:mdna:16]
[same as prior period, unchanged from 0001628280-16-020941:mdna:16]

[0001628280-17-000961:mdna:17]
[same as prior period, unchanged from 0001628280-16-020941:mdna:17]

[0001628280-17-000961:mdna:18]
[same as prior period, unchanged from 0001628280-16-020941:mdna:18]

[0001628280-17-000961:mdna:19]
[same as prior period, unchanged from 0001628280-16-020941:mdna:19]

[0001628280-17-000961:mdna:20]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions. As a result, our cost of sales as a percentage of sales in any period can be negatively impacted by significant component price increases resulting from component shortages.

[0001628280-17-000961:mdna:21]
[same as prior period, unchanged from 0001628280-16-020941:mdna:21]

[0001628280-17-000961:mdna:22]
[same as prior period, unchanged from 0001628280-16-020941:mdna:22]

[0001628280-17-000961:mdna:23]
[same as prior period, unchanged from 0001628280-16-020941:mdna:23]

[0001628280-17-000961:mdna:24]
[same as prior period, unchanged from 0001628280-16-020941:mdna:24]

[0001628280-17-000961:mdna:25]
[same as prior period, unchanged from 0001628280-16-020941:mdna:25]

[0001628280-17-000961:mdna:26]
[same as prior period, unchanged from 0001628280-16-020941:mdna:26]

[0001628280-17-000961:mdna:27]
[same as prior period, unchanged from 0001628280-16-020941:mdna:27]

[0001628280-17-000961:mdna:28]
There have been no material changes in the matters for which we make critical accounting policies and estimates in the preparation of our Condensed Consolidated Financial Statements during the three and six months ended December 31, 2016, as compared to those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2016.

[0001628280-17-000961:mdna:29]
[same as prior period, unchanged from 0001628280-16-020941:mdna:29]

[0001628280-17-000961:mdna:30]
[same as prior period, unchanged from 0001628280-16-020941:mdna:30]

[0001628280-17-000961:mdna:31]
The following table presents net sales by product type for the three and six months ended December 31, 2016 and 2015 (dollars in millions):

[0001628280-17-000961:mdna:32]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Server systems | $ | 444.0 |  |  | $ | 453.7 |  |  | $ | (9.7 | ) |  | (2.1 | )% |  | $ | 801.5 |  |  | $ | 810.0 |  |  | $ | (8.5 | ) |  | (1.0 | )% |
| Percentage of total net sales | 68.1 | % |  | 71.0 | % |  |  |  |  |  | 67.9 | % |  | 69.9 | % |  |  |  |  |
| Subsystems and accessories | 208.0 |  |  | 185.2 |  |  | 22.7 |  |  | 12.3 | % |  | 379.4 |  |  | 348.6 |  |  | 30.8 |  |  | 8.8 | % |
| Percentage of total net sales | 31.9 | % |  | 29.0 | % |  |  |  |  |  | 32.1 | % |  | 30.1 | % |  |  |  |  |
| Total net sales | $ | 652.0 |  |  | $ | 639.0 |  |  | $ | 13.0 |  |  | 2.0 | % |  | $ | 1,180.9 |  |  | $ | 1,158.6 |  |  | $ | 22.3 |  |  | 1.9 | % |

[0001628280-17-000961:mdna:33]
The following table presents the number of compute node sales and average selling price per node of our server systems for the three and six months ended December 31, 2016 and 2015 (nodes in thousands):

[0001628280-17-000961:mdna:34]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| Server systems: |  |  |  |  |  |  |  |  |  |  |  |
| Number of compute node sales (1) | 145 |  |  | 133 |  |  | 9.0 | % |  | 267 |  |  | 249 |  |  | 7.2 | % |
| Average selling price per node | $ | 3,064 |  |  | $ | 3,400 |  |  | (9.9 | )% |  | $ | 3,001 |  |  | $ | 3,249 |  |  | (7.6 | )% |

[0001628280-17-000961:mdna:35]
[same as prior period, unchanged from 0001628280-16-020941:mdna:35]

[0001628280-17-000961:mdna:36]
The following table presents unit sales and average selling price of our subsystems and accessories for the three and six months ended December 31, 2016 and 2015 (units in thousands):

[0001628280-17-000961:mdna:37]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| Subsystems and accessories: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 1,214 |  |  | 1,092 |  |  | 11.2 | % |  | 2,358 |  |  | 2,008 |  |  | 17.4 | % |
| Average selling price per unit | $ | 171 |  |  | $ | 169 |  |  | 1.2 | % |  | $ | 161 |  |  | $ | 173 |  |  | (6.9 | )% |

[0001628280-17-000961:mdna:38]
Comparison of Three Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:39]
The increase in our net sales in the three months ended December 31, 2016 compared with the three months ended December 31, 2015 was primarily due to an increase in sales of our subsystems and accessories to our distributors as well as growth in our Twin family product line of servers including our FatTwin, storage, accelerated GPU computing servers or HPC and MicroBlade. The year-over-year decrease in net sales of our server systems in the three months ended December 31, 2016 was due primarily to a decrease in the average selling price per node of our server systems as we experienced a decrease in sales of complete server systems for ultra and data center optimized servers which offset an increase in the number of compute node sales as we sold higher nodes per systems for our Twin family product line of servers.

[0001628280-17-000961:mdna:40]
The year-over-year increase in net sales and unit sales of our subsystems and accessories in the three months ended December 31, 2016 was primarily due to higher sales of server accessories and serverboards to our distributors.

[0001628280-17-000961:mdna:41]
Comparison of Six Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:42]
The increase in our net sales in the six months ended December 31, 2016 compared with the six months ended December 31, 2015 was primarily due to an increase in sales of our subsystems and accessories to our distributors as well as growth in our Twin family product line of servers including our FatTwin, storage, accelerated GPU computing servers or HPC and MicroBlade. The year-over-year decrease in net sales of our server systems in the six months ended December 31, 2016 was primarily due to a decrease in the average selling price per node of our server systems as we experienced a decrease in sales of complete server systems for ultra and data center optimized servers which offset an increase in the number of compute node sales as we sold higher nodes per systems for our Twin family product line of servers.

[0001628280-17-000961:mdna:43]
The year-over-year increase in net sales and unit sales of our subsystems and accessories in the six months ended December 31, 2016 was primarily due to higher sales of serverboards and server accessories to our distributors.

[0001628280-17-000961:mdna:44]
The following table presents the percentages of net sales from products sold to distributors and direct/OEM customers for the three and six months ended December 31, 2016 and 2015:

[0001628280-17-000961:mdna:45]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| Distributors | 46.2 | % |  | 41.9 | % |  | 4.3 | % |  | 47.9 | % |  | 43.6 | % |  | 4.3 | % |
| Direct/OEM customers | 53.8 | % |  | 58.1 | % |  | (4.3 | )% |  | 52.1 | % |  | 56.4 | % |  | (4.3 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-17-000961:mdna:46]
The year-over-year increase in net sales to distributors in the three and six months ended December 31, 2016 as a percentage of total net sales was primarily due to the higher demand for our subsystem and accessories which are typically sold through distributors. The year-over-year decrease in net sales to direct/OEM customers in the three and six months ended December 31, 2016 as a percentage of total net sales was primarily due to the lower demand for our complete server systems from cloud/internet data center computing partially offset by an increase demand for our server systems from storage, enterprise, HPC and IoT/embedded customers.

[0001628280-17-000961:mdna:47]
The following table presents percentages of net sales by geographic region for the three and six months ended December 31, 2016 and 2015:

[0001628280-17-000961:mdna:48]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| United States | 55.0 | % |  | 63.7 | % |  | (8.7 | )% |  | 55.4 | % |  | 64.4 | % |  | (9.0 | )% |
| Europe | 19.9 | % |  | 17.9 | % |  | 2.0 | % |  | 20.6 | % |  | 17.4 | % |  | 3.2 | % |
| Asia | 21.1 | % |  | 13.8 | % |  | 7.3 | % |  | 19.8 | % |  | 14.0 | % |  | 5.8 | % |
| Others | 4.0 | % |  | 4.6 | % |  | (0.6 | )% |  | 4.2 | % |  | 4.2 | % |  | — | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-17-000961:mdna:49]
The year-over-year decrease in net sales in the United States in the three and six months ended December 31, 2016 as a percentage of total net sales was primarily due to the lower demand for our server systems from cloud/internet data center computing which represents a higher portion of sales in the United States than in other regions. The year-over-year increase in net sales in Asia and Europe in the three and six months ended December 31, 2016 as a percentage of total net sales was primarily due to the higher demand for our server systems in China, the Netherlands and Russian Federation.

[0001628280-17-000961:mdna:50]
[same as prior period, unchanged from 0001628280-16-020941:mdna:47]

[0001628280-17-000961:mdna:51]
Cost of sales and gross margin for the three and six months ended December 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-17-000961:mdna:52]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Total cost of sales | $ | 558.6 |  |  | $ | 532.6 |  |  | $ | 26.0 |  |  | 4.9 | % |  | $ | 1,007.5 |  |  | $ | 980.0 |  |  | $ | 27.5 |  |  | 2.8 | % |
| Total gross profit | 93.4 |  |  | 106.4 |  |  | (13.0 | ) |  | (12.2 | )% |  | 173.4 |  |  | 178.6 |  |  | (5.1 | ) |  | (2.9 | )% |
| Total gross margin | 14.3 | % |  | 16.6 | % |  |  |  | (2.3 | )% |  | 14.7 | % |  | 15.4 | % |  |  |  | (0.7 | )% |

[0001628280-17-000961:mdna:53]
Comparison of Three Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:54]
The year-over-year increase in absolute dollars of cost of sales in the three months ended December 31, 2016 compared to the three months ended December 31, 2015 was primarily attributable to the increase in net sales. In the three months ended December 31, 2016, we recorded a $2.5 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $2.1 million, or 0.3% of net sales, in the three months ended December 31, 2015.

[0001628280-17-000961:mdna:55]
In the three months ended December 31, 2016, we recorded a $4.8 million expense, or 0.7% of net sales, related to the provision for warranty reserve which was comparable to a $4.7 million expense, or 0.7% of net sales, in the three months ended December 31, 2015. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-17-000961:mdna:56]
Gross margin percentage was 14.3% and 16.6% for the three months ended December 31, 2016 and 2015, respectively. The decrease was primarily due to higher costs related to shortages of memory and SSD as well as many of our server systems being based on mature, late life cycle processors and GPUs at lower prices. Geographically, we had higher sales in Asia where pricing is typically more competitive.

[0001628280-17-000961:mdna:57]
Comparison of Six Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:58]
The year-over-year increase in absolute dollars of cost of sales in the six months ended December 31, 2016 compared to the six months ended December 31, 2015 was primarily attributable to the increase in net sales. In the six months ended December 31, 2016, we recorded a $6.4 million expense, net of recovery, or 0.5% of net sales, related to the inventory provision as compared to $3.8 million, or 0.3% of net sales, in the six months ended December 31, 2015.

[0001628280-17-000961:mdna:59]
In the six months ended December 31, 2016, we recorded a $9.7 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to a $8.5 million expense, or 0.7% of net sales, in the six months ended December 31, 2015. The increase in the provision for warranty reserve was primarily due to an increase in warranty claims and cost of servicing warranty claims in the six months ended December 31, 2016.

[0001628280-17-000961:mdna:60]
Gross margin percentage was 14.7% and 15.4% for the six months ended December 31, 2016 and 2015, respectively. The decrease was primarily due to higher costs related to shortages of memory and SSD as well as many of our server systems being based on mature, late life cycle processors and GPUs at lower prices. Geographically, we had higher sales in Asia where pricing is typically more competitive.

[0001628280-17-000961:mdna:61]
[same as prior period, unchanged from 0001628280-16-020941:mdna:55]

[0001628280-17-000961:mdna:62]
Operating expenses for the three and six months ended December 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-17-000961:mdna:63]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Research and development | $ | 34.0 |  |  | $ | 30.3 |  |  | $ | 3.8 |  |  | 12.5 | % |  | $ | 67.2 |  |  | $ | 58.6 |  |  | $ | 8.6 |  |  | 14.7 | % |
| Percentage of total net sales | 5.2 | % |  | 4.7 | % |  |  |  |  |  | 5.7 | % |  | 5.1 | % |  |  |  |  |
| Sales and marketing | 18.2 |  |  | 16.5 |  |  | 1.7 |  |  | 10.3 | % |  | 34.1 |  |  | 30.7 |  |  | 3.4 |  |  | 10.9 | % |
| Percentage of total net sales | 2.8 | % |  | 2.6 | % |  |  |  |  |  | 2.9 | % |  | 2.7 | % |  |  |  |  |
| General and administrative | 9.4 |  |  | 10.5 |  |  | (1.1 | ) |  | (10.3 | )% |  | 20.2 |  |  | 18.7 |  |  | 1.5 |  |  | 7.9 | % |
| Percentage of total net sales | 1.5 | % |  | 1.6 | % |  |  |  |  |  | 1.7 | % |  | 1.5 | % |  |  |  |  |
| Total operating expenses | $ | 61.6 |  |  | $ | 57.2 |  |  | $ | 4.4 |  |  | 7.7 | % |  | $ | 121.5 |  |  | $ | 108.0 |  |  | $ | 13.5 |  |  | 12.5 | % |
| Percentage of total net sales | 9.5 | % |  | 8.9 | % |  |  |  |  |  | 10.3 | % |  | 9.3 | % |  |  |  |  |

[0001628280-17-000961:mdna:64]
Comparison of Three Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:65]
Research and development expenses. Research and development expenses increased by $3.8 million, or 12.5% in the three months ended December 31, 2016 compared to the three months ended December 31, 2015. Research and development expenses were 5.2% and 4.7% of net sales for the three months ended December 31, 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $4.4 million in compensation and benefits including stock-based compensation expense, partially offset by an increase of $1.1 million in non-recurring engineering funding from certain suppliers and customers.

[0001628280-17-000961:mdna:66]
Research and development expenses include stock-based compensation expense of $3.0 million and $2.5 million for the three months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:67]
[same as prior period, unchanged from 0001628280-16-020941:mdna:61]

[0001628280-17-000961:mdna:68]
Sales and marketing expenses. Sales and marketing expenses increased by $1.7 million, or 10.3% in the three months ended December 31, 2016 compared to the three months ended December 31, 2015. Sales and marketing expenses were 2.8% and 2.6% of net sales for the three months ended December 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $0.7 million in compensation and benefits including stock-based compensation expense, resulting primarily from growth in sales and marketing personnel and an increase of $0.6 million in advertising, marketing promotional and trade show expenses.

[0001628280-17-000961:mdna:69]
Sales and marketing expenses include stock-based compensation expense of $0.5 million and $0.4 million for the three months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:70]
General and administrative expenses. General and administrative expenses decreased by $1.1 million, or 10.3% in the three months ended December 31, 2016 compared to the three months ended December 31, 2015. General and administrative expenses were 1.5% and 1.6% of net sales for the three months ended December 31, 2016 and 2015, respectively. The decrease in absolute dollars was primarily due to a $0.6 million foreign currency transaction gain in the three months ended December 31, 2016 as compared to a $0.5 million foreign currency transaction loss in the three months ended December 31, 2015, a decrease of $0.7 million in legal expenses, a decrease of $0.4 million in bad debt expenses, partially offset by an increase of $1.3 million in compensation and benefits including stock-based compensation expense.

[0001628280-17-000961:mdna:71]
General and administrative expenses include stock-based compensation expense of $0.9 million and $0.8 million for the three months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:72]
Comparison of Six Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:73]
Research and development expenses. Research and development expenses increased by $8.6 million, or 14.7% in the six months ended December 31, 2016 compared to the six months ended December 31, 2015. Research and development expenses were 5.7% and 5.1% of net sales for the six months ended December 31, 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $9.1 million in compensation and benefits including stock-based compensation expense, partially offset by an increase of $1.6 million in non-recurring engineering funding from certain suppliers and customers.

[0001628280-17-000961:mdna:74]
Research and development expenses include stock-based compensation expense of $5.9 million and $4.9 million for the six months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:75]
Our compensation and benefit expense in research and development increased from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. We continue to believe that investments in research and development are critical to our future growth and competitive position in the marketplace. As such, we expect to continue to spend on current and future product development efforts.

[0001628280-17-000961:mdna:76]
Sales and marketing expenses. Sales and marketing expenses increased by $3.4 million, or 10.9% in the six months ended December 31, 2016 compared to the six months ended December 31, 2015. Sales and marketing expenses were 2.9% and 2.7% of net sales for the six months ended December 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $2.1 million in compensation and benefits including stock-based compensation expense, resulting primarily from growth in sales and marketing personnel.

[0001628280-17-000961:mdna:77]
Sales and marketing expenses include stock-based compensation expense of $1.0 million and $0.8 million for the six months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:78]
General and administrative expenses. General and administrative expenses increased by $1.5 million, or 7.9% in the six months ended December 31, 2016 compared to the six months ended December 31, 2015. General and administrative expenses were 1.7% and 1.5% of net sales for the six months ended December 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $2.3 million in compensation and benefits including stock-based compensation expense, a $1.4 million foreign currency transaction gain in the six months ended December 31, 2015 as compared to a $0.1 million foreign currency transaction gain in the six months ended December 31, 2016, partially offset by a decrease of $1.8 million in legal expenses.

[0001628280-17-000961:mdna:79]
General and administrative expenses include stock-based compensation expense of $1.7 million and $1.7 million for the six months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:80]
[same as prior period, unchanged from 0001628280-16-020941:mdna:66]

[0001628280-17-000961:mdna:81]
Interest and other expense, net for the three and six months ended December 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-17-000961:mdna:82]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Interest and other income, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | N/M* |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | (0.1 | ) |  | N/M* |  |
| Interest expense | (0.5 | ) |  | (0.4 | ) |  | (0.1 | ) |  | 24.3 | % |  | (0.8 | ) |  | (0.7 | ) |  | (0.1 | ) |  | 14.2 | % |
| Interest and other expense, net | $ | (0.5 | ) |  | $ | (0.4 | ) |  | $ | (0.1 | ) |  | 20.2 | % |  | $ | (0.8 | ) |  | $ | (0.6 | ) |  | $ | (0.2 | ) |  | 22.8 | % |

[0001628280-17-000961:mdna:83]
*Not meaningful

[0001628280-17-000961:mdna:84]
Comparison of Three Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:85]
Interest and other expense, net. Interest and other expense, net increased by $0.1 million in the three months ended December 31, 2016 compared to the three months ended December 31, 2015. The increases were primarily due to an increase in interest expense.

[0001628280-17-000961:mdna:86]
Comparison of Six Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:87]
Interest and other expense, net. Interest and other expense, net increased by $0.2 million in the six months ended December 31, 2016 compared to the six months ended December 31, 2015. The increases were primarily due to an increase in interest expense.

[0001628280-17-000961:mdna:88]
[same as prior period, unchanged from 0001628280-16-020941:mdna:71]

[0001628280-17-000961:mdna:89]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-17-000961:mdna:90]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Provision for income taxes | $ | 9.3 |  |  | $ | 14.1 |  |  | $ | (4.7 | ) |  | (33.8 | )% |  | $ | 15.7 |  |  | $ | 21.6 |  |  | $ | (5.9 | ) |  | (27.3 | )% |
| Percentage of total net sales | 1.4 | % |  | 2.2 | % |  |  |  |  |  | 1.3 | % |  | 1.8 | % |  |  |  |  |
| Effective tax rate | 29.7 | % |  | 28.8 | % |  |  |  |  |  | 30.6 | % |  | 30.8 | % |  |  |  |  |

[0001628280-17-000961:mdna:91]
Comparison of Three Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:92]
Provision for income taxes. Provision for income taxes decreased by $4.7 million, or 33.8% in the three months ended December 31, 2016 compared to the three months ended December 31, 2015. The effective tax rate was 29.7% and 28.8% for the three months ended December 31, 2016 and 2015, respectively. The lower income tax provision for the three months ended December 31, 2016 was primarily attributable to our lower operating income. The effective tax rate for the three months ended December 31, 2016 was higher primarily due to the lower benefits from U.S. federal research and development ("R&D") tax credit and foreign rate differentials. For the third quarter of fiscal year 2017, we expect a decrease of approximately $1.9 million of unrecognized tax benefits related to foreign uncertain tax positions resulting from the completion of the income tax audit in Taiwan.

[0001628280-17-000961:mdna:93]
Comparison of Six Months Ended December 31, 2016 and 2015

[0001628280-17-000961:mdna:94]
Provision for income taxes. Provision for income taxes decreased by $5.9 million, or 27.3% in the six months ended December 31, 2016 compared to the six months ended December 31, 2015. The effective tax rate was 30.6% and 30.8% for the six months ended December 31, 2016 and 2015, respectively. The lower income tax provision for the six months ended December 31, 2016 was primarily attributable to our lower operating income. The effective tax rate for the six months ended December 31, 2016 was lower primarily due to the benefits from domestic production activities deductions.

[0001628280-17-000961:mdna:95]
[same as prior period, unchanged from 0001628280-16-020941:mdna:76]

[0001628280-17-000961:mdna:96]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $128.8 million and $181.0 million as of December 31, 2016 and June 30, 2016, respectively. Our cash in foreign locations was $54.1 million and $46.5 million at December 31, 2016 and June 30, 2016, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-17-000961:mdna:97]
Operating Activities. Net cash provided by (used in) operating activities was $(54.9) million and $86.9 million for the six months ended December 31, 2016 and 2015, respectively.

[0001628280-17-000961:mdna:98]
Net cash used in our operating activities for the six months ended December 31, 2016 was primarily due to an increase in inventory of $156.7 million and an increase in accounts receivable of $78.3 million, which were partially offset by an increase in accounts payable of $96.8 million, our net income of $35.5 million, an increase in accrued liabilities of $18.2 million, an increase in other long-term liabilities of $12.4 million, stock-based compensation expense of $9.2 million, and depreciation and amortization expense of $7.7 million.

[0001628280-17-000961:mdna:99]
Net cash provided by our operating activities for the six months ended December 31, 2015 was primarily due to our net income of $48.4 million, an increase in accounts payable of $20.7 million, an increase in other long-term liabilities of $18.7 million, an increase in accrued liabilities of $9.7 million, stock-based compensation expense of $7.9 million, a decrease in accounts receivable of $7.6 million, depreciation and amortization expense of $6.0 million, and provision for inventory of $3.8 million, which were partially offset by an increase in inventory of $26.8 million, an increase in deferred income taxes assets of $4.4 million, and an increase in prepaid expenses and other assets of $4.3 million.

[0001628280-17-000961:mdna:100]
The increase for the six months ended December 31, 2016 in accounts receivable was primarily due to higher sales in the last month of the second quarter of fiscal year 2017 as compared to the last month of the fourth quarter of fiscal year 2016. The increase for the six months ended December 31, 2016 in inventory and accounts payable was due to higher purchases to support memory and SSD component shortages as well as the lunar new year holiday shutdown in Asia at the end of January 2017. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-17-000961:mdna:101]
The decrease for the six months ended December 31, 2015 in accounts receivable was primarily due to lower sales in the last month of the second quarter of fiscal year 2016 as compared to the last month of the fourth quarter of fiscal year 2015. The increase for the six months ended December 31, 2015 in inventory and accounts payable was primarily due to higher purchases to support the lunar new year holiday shutdown in Asia in the beginning of February 2016 and higher sales in the six months ended December 31, 2015.

[0001628280-17-000961:mdna:102]
Investing activities. Net cash used in our investing activities was $17.7 million and $15.6 million for the six months ended December 31, 2016 and 2015, respectively. In the six months ended December 31, 2016, of the net cash used in our investing activities, $17.4 million was related to the purchase of property, plant and equipment, of which $8.2 million was related to the property and equipment for the manufacturing buildings at our Green Computing Park in San Jose, California. We anticipate investing approximately $7.0 million through April 2017 to complete the construction of a second manufacturing facility in the Green Computing Park. We plan to finance this development through our operating cash flows and additional borrowings from banks. In the six months ended December 31, 2015, $15.2 million was related to the purchase of property, plant and equipment.

[0001628280-17-000961:mdna:103]
Financing activities. Net cash provided by our financing activities was $20.8 million and $3.3 million for the six months ended December 31, 2016 and 2015, respectively. In the six months ended December 31, 2016, we borrowed an additional $130.1 million under our term loan and revolving lines of credit from Bank of America and CTBC Bank and repaid $96.6 million in loans. We received $5.9 million related to the proceeds from the exercise of stock options in the six months ended December 31, 2016. Further, we used $18.5 million to repurchase our outstanding common stock.

[0001628280-17-000961:mdna:104]
In the six months ended December 31, 2015, we borrowed an additional $14.4 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $13.3 million in loans. Further, we received $2.4 million related to the proceeds from the exercise of stock options in the six months ended December 31, 2015.

[0001628280-17-000961:mdna:105]
[same as prior period, unchanged from 0001628280-16-020941:mdna:87]

[0001628280-17-000961:mdna:106]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-17-000961:mdna:107]
[same as prior period, unchanged from 0001628280-16-020941:mdna:90]

[0001628280-17-000961:mdna:108]
[same as prior period, unchanged from 0001628280-16-020941:mdna:91]

[0001628280-17-000961:mdna:109]
[same as prior period, unchanged from 0001628280-16-020941:mdna:92]

[0001628280-17-000961:mdna:110]
In June 2015, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, we extended the revolving line of credit to mature on June 30, 2016.

[0001628280-17-000961:mdna:111]
In June 2016, we entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50.0 million term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-17-000961:mdna:112]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.61% at December 31, 2016. The letter of credit is charged at 1.25% per annum.

[0001628280-17-000961:mdna:113]
[same as prior period, unchanged from 0001628280-16-020941:mdna:96]

[0001628280-17-000961:mdna:114]
In December 2016, we entered into an amendment to the credit agreement with Bank of America to reduce the $55.0 million revolving line of credit facility to $45.0 million and increase the revolving line of credit for the Taiwan and the Netherlands subsidiaries from $10.0 million to $20.0 million.

[0001628280-17-000961:mdna:115]
As of December 31, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $45.0 million and $0.9 million, respectively. The total outstanding borrowings under the Bank of America lines of credit was $43.2 million and $62.2 million as of December 31, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.19% to 2.14% per annum at December 31, 2016 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of December 31, 2016, the unused revolving lines of credit amount with Bank of America under the credit agreements were $21.8 million.

[0001628280-17-000961:mdna:116]
In February 2017, we drew an additional $10.0 million from Bank of America revolving line of credit with interest rate at 1.29% per annum to support the Company's growth and expansion of its business in the Netherlands.

[0001628280-17-000961:mdna:117]
[same as prior period, unchanged from 0001628280-16-020941:mdna:99]

[0001628280-17-000961:mdna:118]
[same as prior period, unchanged from 0001628280-16-020941:mdna:100]

[0001628280-17-000961:mdna:119]
[same as prior period, unchanged from 0001628280-16-020941:mdna:101]

[0001628280-17-000961:mdna:120]
[same as prior period, unchanged from 0001628280-16-020941:mdna:102]

[0001628280-17-000961:mdna:121]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $18.5 million and $20.4 million at December 31, 2016 and June 30, 2016, respectively. At December 31, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20.8 million and $10.1 million, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.95% and 2.15% at December 31, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At December 31, 2016, available for future borrowing under this credit agreement was $0.6 million.

[0001628280-17-000961:mdna:122]
In January 2017, we drew an additional $8.0 million from CTBC Bank revolving line of credit with the interest rate at 1.55% per annum to support the Company's growth and expansion of its business in the Netherlands.

[0001628280-17-000961:mdna:123]
Covenant Compliance

[0001628280-17-000961:mdna:124]
The credit agreement with Bank of America contain customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-17-000961:mdna:125]
[same as prior period, unchanged from 0001628280-16-020941:mdna:106]

[0001628280-17-000961:mdna:126]
[same as prior period, unchanged from 0001628280-16-020941:mdna:107]

[0001628280-17-000961:mdna:127]
[same as prior period, unchanged from 0001628280-16-020941:mdna:108]

[0001628280-17-000961:mdna:128]
As of December 31, 2016, our total assets of $998.3 million collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarters company except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of December 31, 2016, total assets collateralizing the term loan with Bank of America were $101.1 million. As of December 31, 2016, we were in compliance with all financial covenants associated with the term loan and lines of credit with Bank of America under the credit agreement.

[0001628280-17-000961:mdna:129]
As of December 31, 2016, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.6 million. There are no financial covenants associated with the term loan with CTBC Bank.

[0001628280-17-000961:mdna:130]
[same as prior period, unchanged from 0001628280-16-020941:mdna:111]

[0001628280-17-000961:mdna:131]
In the three and six months ended December 31, 2016, we paid our contract manufacturers within 34 to 76 days of invoice and Ablecom between 48 to 83 days of invoice. Ablecom is one of our major contract manufacturers and a related party. As of December 31, 2016 and June 30, 2016 amounts owed to Ablecom by us were approximately $54.3 million and $39.2 million, respectively.

[0001628280-17-000961:mdna:132]
[same as prior period, unchanged from 0001628280-16-020941:mdna:113]

[0001628280-17-000961:mdna:133]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of our common stock in the open market or in private transactions during the following twelve months at prevailing market prices. Repurchases will be made under the program using our own cash resources. This share repurchase program does not obligate us to acquire any particular amount of common stock, and it may be suspended at any time at our discretion. During the three months ended December 31, 2016, we did not purchase any shares of our common stock in the open market. During the six months ended December 31, 2016, we purchased 888,097 shares of our common stock in the open market at a weighted average price of $20.79 per share for approximately $18.5 million.

[0001628280-17-000961:mdna:134]
[same as prior period, unchanged from 0001628280-16-020941:mdna:115]

[0001628280-17-000961:mdna:135]
The following table describes our contractual obligations as of December 31, 2016:

[0001628280-17-000961:mdna:136]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,468 |  |  | $ | 7,665 |  |  | $ | 4,084 |  |  | $ | 1,921 |  |  | $ | 18,138 |  |
| Capital leases, including interest | 271 |  |  | 417 |  |  | 99 |  |  | — |  |  | 787 |  |
| Debt, including interest (1) | 93,347 |  |  | 20,956 |  |  | 15,223 |  |  | — |  |  | 129,526 |  |
| Purchase commitments (2) | 402,229 |  |  | — |  |  | — |  |  | — |  |  | 402,229 |  |
| Total (3) | $ | 500,315 |  |  | $ | 29,038 |  |  | $ | 19,406 |  |  | $ | 1,921 |  |  | $ | 550,680 |  |

[0001628280-17-000961:mdna:137]
[same as prior period, unchanged from 0001628280-16-020941:mdna:118]

[0001628280-17-000961:mdna:138]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at December 31, 2016. |

[0001628280-17-000961:mdna:139]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-17-000961:mdna:140]
| (3) | The table above excludes liabilities for deferred revenue of $52.0 million and unrecognized tax benefits and related interest and penalties accrual of $18.8 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 8 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes. |

[0001628280-17-000961:mdna:141]
[same as prior period, unchanged from 0001628280-16-020941:mdna:122]

[0001628280-17-000961:mdna:142]
[same as prior period, unchanged from 0001628280-16-020941:mdna:123]

[0001628280-17-000961:mdna:143]
[same as prior period, unchanged from 0001628280-16-020941:mdna:124]

[0001628280-17-000961:mdna:144]
[same as prior period, unchanged from 0001628280-16-020941:mdna:125]

[0001628280-17-000961:mdna:145]
[same as prior period, unchanged from 0001628280-16-020941:mdna:126]
