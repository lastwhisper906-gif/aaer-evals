# SMCI 8-K — 0001628280-17-000437 filed 2017-01-26

## item codes, every 8-K on or before 2017-02-07

- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2017-02-07

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-17-000437:8k_2_02:1]
EX-99.1
2
exhibit991q2-2017.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-17-000437:8k_2_02:2]
Exhibit

[0001628280-17-000437:8k_2_02:3]
Exhibit 99.1

[0001628280-17-000437:8k_2_02:4]
Super Micro Computer, Inc. Announces 2nd Quarter 2017 Financial Results

[0001628280-17-000437:8k_2_02:5]
SAN JOSE, Calif., January 26, 2017 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced second quarter fiscal 2017 financial results for the quarter ended December 31, 2016.

[0001628280-17-000437:8k_2_02:6]
Fiscal 2nd Quarter Highlights

[0001628280-17-000437:8k_2_02:7]
| • | Quarterly net sales of $652.0 million, up 23.3% from the first quarter of fiscal year 2017 and up 2.0% from the same quarter of last year. |

[0001628280-17-000437:8k_2_02:8]
| • | GAAP net income of $22.0 million, up 62.5% from the first quarter of fiscal year 2017 and down 36.6% from the same quarter of last year. |

[0001628280-17-000437:8k_2_02:9]
| • | GAAP gross margin was 14.3%, down from 15.1% in the first quarter of fiscal year 2017 and down from 16.6% in the same quarter of last year. |

[0001628280-17-000437:8k_2_02:10]
| • | Server solutions accounted for 68.1% of net sales compared with 67.6% in the first quarter of fiscal year 2017 and 71.0% in the same quarter of last year. |

[0001628280-17-000437:8k_2_02:11]
Net sales for the second quarter ended December 31, 2016 totaled $652.0 million, up 23.3% from $529.0 million in the first quarter of fiscal year 2017. No customer accounted for more than 10% of net sales during the quarter ended December 31, 2016.

[0001628280-17-000437:8k_2_02:12]
GAAP net income for the second quarter of fiscal year 2017 was $22.0 million or $0.43 per diluted share, a decrease of 36.6% from net income of $34.7 million, or $0.67 per diluted share in the same period a year ago. Included in net income for the quarter is $4.7 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the second quarter was $25.0 million, or $0.48 per diluted share, compared to non-GAAP net income of $38.0 million, or $0.73 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the first quarter of fiscal year 2017 by $8.4 million or $0.16 per diluted share.

[0001628280-17-000437:8k_2_02:13]
GAAP gross margin for the second quarter of fiscal year 2017 was 14.3% compared to 16.6% in the same period a year ago. Non-GAAP gross margin for the second quarter was 14.4% compared to 16.7% in the same period a year ago. GAAP gross margin for the first quarter of fiscal year 2017 was 15.1% and Non-GAAP gross margin for the first quarter of fiscal year 2017 was 15.2%.

[0001628280-17-000437:8k_2_02:14]
The GAAP income tax provision for the second quarter of fiscal year 2017 was $9.3 million or 29.7% of income before tax provision compared to $14.1 million or 28.8% in the same period a year ago and $6.4 million or 32.0% in the first quarter of fiscal year 2017. The effective tax rate for the second quarter of fiscal year 2017 was lower than the first quarter primarily due to an increase in the domestic production activities deduction and U.S. federal research and development ("R&D") tax credits.

[0001628280-17-000437:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at December 31, 2016 were $131.5 million compared to $183.7 million at June 30, 2016. Free cash flow for the six months ended December 31, 2016 was $(72.2) million, primarily due to an increase in the Company's cash used in operating activities and used in the development and construction of improvements on the Company's properties.

[0001628280-17-000437:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-17-000437:8k_2_02:17]
The Company expects net sales of $570 million to $630 million for the third quarter of fiscal year 2017 ending March 31, 2017. The Company expects non-GAAP earnings per diluted share of approximately $0.34 to $0.42 for the third quarter.

[0001628280-17-000437:8k_2_02:18]
“We are pleased to report record second quarter revenues of $652.0 million that exceeded our guidance and outpaced a strong compare with last year. Contributing to this strong growth was our Twin family product line including our FatTwin, Storage, HPC, MicroBlade, and strong growth from enterprise cloud and Asia Pacific, particularly China. Component shortages and pricing, product and geographic mix adversely impacted gross margins while improved leverage allowed us to deliver stronger operating margins from last quarter,” said Charles Liang, Chairman and Chief Executive Officer. “We expect to continue the growth of last quarter and be reflected in the year-over-year revenue growth in the March quarter based on an increasing number of sizable customer engagements demanding the performance and advantages of our leading product lines. In addition, we are well positioned to benefit from technology transitions in 2017 and have upgraded our product lines to optimize these new technologies.”

[0001628280-17-000437:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-17-000437:8k_2_02:20]
Conference Call Information

[0001628280-17-000437:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-211-0193 (International callers dial 1-913-312-0947) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, February 9, 2017, by dialing 1-844-512-2921 (International callers dial 1-412-317-6671) and entering replay PIN 7473642. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-17-000437:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-17-000437:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-17-000437:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-17-000437:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-17-000437:8k_2_02:26]
Supermicro®, a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, TwinPro, FatTwin™, Ultra Series, MicroCloud, MicroBlade, SuperBlade®, Simply Double, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-17-000437:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-17-000437:8k_2_02:28]
Supermicro, FatTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001628280-17-000437:8k_2_02:29]
All other brands, names and trademarks are the property of their respective owners.

[0001628280-17-000437:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | December 31, |  | June 30, |
|  |  |  |  | 2016 |  | 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 128,752 |  |  | $ | 180,964 |  |
|  | Accounts receivable, net | 366,885 |  |  | 288,941 |  |
|  | Inventory |  | 599,269 |  |  | 448,980 |  |
|  | Prepaid income taxes | 5,164 |  |  | 5,682 |  |
|  | Prepaid expenses and other current assets | 13,738 |  |  | 13,435 |  |
|  |  | Total current assets | 1,113,808 |  |  | 938,002 |  |
| Long-term investments | 2,643 |  |  | 2,643 |  |
| Property, plant and equipment, net | 193,670 |  |  | 187,949 |  |
| Deferred income taxes – noncurrent |  | 32,255 |  |  | 28,460 |  |
| Other assets |  |  | 7,480 |  |  | 8,546 |  |
|  |  | Total assets | $ | 1,349,856 |  |  | $ | 1,165,600 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 341,940 |  |  | $ | 249,239 |  |
|  | Accrued liabilities |  | 74,331 |  |  | 55,618 |  |
|  | Income taxes payable |  | 1,048 |  |  | 5,172 |  |
|  | Short-term debt and current portion of long-term debt, net of debt issuance costs | 92,443 |  |  | 53,589 |  |
|  |  | Total current liabilities | 509,762 |  |  | 363,618 |  |
| Long term debt, net of current portion and debt issuance costs | 34,732 |  |  | 40,000 |  |
| Other long-term liabilities | 53,001 |  |  | 40,603 |  |
|  |  | Total liabilities | 597,495 |  |  | 444,221 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 291,275 |  |  | 277,339 |  |
|  | Treasury stock (at cost) | (20,491 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (83 | ) |  | (85 | ) |
|  | Retained earnings |  | 481,499 |  |  | 445,971 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 752,200 |  |  | 721,195 |  |
|  | Noncontrolling interest | 161 |  |  | 184 |  |
|  |  | Total stockholders' equity | 752,361 |  |  | 721,379 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,349,856 |  |  | $ | 1,165,600 |  |

[0001628280-17-000437:8k_2_02:31]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, |  | December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 651,954 |  |  | $ | 638,964 |  |  | $ | 1,180,922 |  |  | $ | 1,158,582 |  |
| Cost of sales | 558,576 |  |  | 532,602 |  |  | 1,007,480 |  |  | 980,005 |  |
| Gross profit | 93,378 |  |  | 106,362 |  |  | 173,442 |  |  | 178,577 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 34,033 |  |  | 30,264 |  |  | 67,224 |  |  | 58,590 |  |
| Sales and marketing | 18,153 |  |  | 16,461 |  |  | 34,069 |  |  | 30,710 |  |
| General and administrative | 9,429 |  |  | 10,511 |  |  | 20,184 |  |  | 18,711 |  |
| Total operating expenses | 61,615 |  |  | 57,236 |  |  | 121,477 |  |  | 108,011 |  |
| Income from operations | 31,763 |  |  | 49,126 |  |  | 51,965 |  |  | 70,566 |  |
| Interest and other income, net | 45 |  |  | 24 |  |  | 74 |  |  | 111 |  |
| Interest expense | (497 | ) |  | (400 | ) |  | (827 | ) |  | (724 | ) |
| Income before income tax provision | 31,311 |  |  | 48,750 |  |  | 51,212 |  |  | 69,953 |  |
| Income tax provision | 9,315 |  |  | 14,061 |  |  | 15,684 |  |  | 21,565 |  |
| Net income | $ | 21,996 |  |  | $ | 34,689 |  |  | $ | 35,528 |  |  | $ | 48,388 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.46 |  |  | $ | 0.73 |  |  | $ | 0.74 |  |  | $ | 1.02 |  |
| Diluted | $ | 0.43 |  |  | $ | 0.67 |  |  | $ | 0.69 |  |  | $ | 0.94 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 48,124 |  |  | 47,651 |  |  | 48,144 |  |  | 47,584 |  |
| Diluted | 51,521 |  |  | 51,489 |  |  | 51,352 |  |  | 51,405 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, |  | December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of sales | $ | 325 |  |  | $ | 258 |  |  | $ | 634 |  |  | $ | 498 |  |
| Research and development | 3,012 |  |  | 2,472 |  |  | 5,920 |  |  | 4,874 |  |
| Sales and marketing | 520 |  |  | 435 |  |  | 998 |  |  | 839 |  |
| General and administrative | 852 |  |  | 841 |  |  | 1,661 |  |  | 1,671 |  |
| Stock-based compensation expense before taxes | $ | 4,709 |  |  | $ | 4,006 |  |  | $ | 9,213 |  |  | $ | 7,882 |  |

[0001628280-17-000437:8k_2_02:32]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Six Months Ended |
|  | December 31, |
|  | 2016 |  | 2015 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 35,528 |  |  | $ | 48,388 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 7,711 |  |  | 5,953 |  |
| Stock-based compensation expense | 9,213 |  |  | 7,882 |  |
| Excess tax benefits from stock-based compensation | (745 | ) |  | (355 | ) |
| Allowance for doubtful accounts | 356 |  |  | 805 |  |
| Provision for inventory | 6,391 |  |  | 3,780 |  |
| Exchange loss (gain) | 232 |  |  | (1,539 | ) |
| Deferred income taxes, net | (3,791 | ) |  | (4,380 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (78,300 | ) |  | 7,613 |  |
| Inventory | (156,680 | ) |  | (26,818 | ) |
| Prepaid expenses and other assets | 941 |  |  | (4,259 | ) |
| Accounts payable | 96,774 |  |  | 20,738 |  |
| Income taxes payable, net | (3,176 | ) |  | 650 |  |
| Accrued liabilities | 18,234 |  |  | 9,715 |  |
| Other long-term liabilities | 12,442 |  |  | 18,749 |  |
| Net cash provided by (used in) operating activities | (54,870 | ) |  | 86,922 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (17,372 | ) |  | (15,235 | ) |
| Restricted cash | (287 | ) |  | (404 | ) |
| Net cash used in investing activities | (17,659 | ) |  | (15,639 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt, net of debt issuance costs | 130,116 |  |  | 14,400 |  |
| Repayment of debt | (96,552 | ) |  | (13,300 | ) |
| Payment to acquire treasury stock | (18,461 | ) |  | — |  |
| Proceeds from exercise of stock options | 5,873 |  |  | 2,439 |  |
| Excess tax benefits from stock-based compensation | 745 |  |  | 355 |  |
| Payment of obligations under capital leases | (118 | ) |  | (86 | ) |
| Advances (payments) under receivable financing arrangements | 787 |  |  | (18 | ) |
| Minimum tax withholding paid on behalf of employees for restricted stock units | (1,542 | ) |  | (504 | ) |
| Net cash provided by financing activities | 20,848 |  |  | 3,286 |  |
| Effect of exchange rate fluctuations on cash | (531 | ) |  | (119 | ) |
| Net increase (decrease) in cash and cash equivalents | (52,212 | ) |  | 74,450 |  |
| Cash and cash equivalents at beginning of period | 180,964 |  |  | 95,442 |  |
| Cash and cash equivalents at end of period | $ | 128,752 |  |  | $ | 169,892 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | $ | 749 |  |  | $ | 693 |  |
| Cash paid for taxes, net of refunds | 20,004 |  |  | 19,636 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 86 |  |  | 127 |  |
| Accrued costs for property, plant and equipment purchases | 5,325 |  |  | 5,366 |  |

[0001628280-17-000437:8k_2_02:33]
| SUPER MICRO COMPUTER, INC. |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP GROSS PROFIT | $ | 93,378 |  |  | $ | 106,362 |  |  | $ | 173,442 |  |  | $ | 178,577 |  |
|  | Add back stock-based compensation (a) | 325 |  |  | 258 |  |  | 634 |  |  | 498 |  |
| Non-GAAP GROSS PROFIT | $ | 93,703 |  |  | $ | 106,620 |  |  | $ | 174,076 |  |  | $ | 179,075 |  |
| GAAP GROSS MARGIN | 14.3 | % |  | 16.6 | % |  | 14.7 | % |  | 15.4 | % |
|  | Add back stock-based compensation (a) | 0.1 | % |  | 0.1 | % |  | 0.0 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 14.4 | % |  | 16.7 | % |  | 14.7 | % |  | 15.5 | % |
| GAAP INCOME FROM OPERATIONS | $ | 31,763 |  |  | $ | 49,126 |  |  | $ | 51,965 |  |  | $ | 70,566 |  |
|  | Add back stock-based compensation (a) | 4,709 |  |  | 4,006 |  |  | 9,213 |  |  | 7,882 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 36,472 |  |  | $ | 53,132 |  |  | $ | 61,178 |  |  | $ | 78,448 |  |
| GAAP NET INCOME | $ | 21,996 |  |  | $ | 34,689 |  |  | $ | 35,528 |  |  | $ | 48,388 |  |
|  | Add back stock-based compensation (a) | 4,709 |  |  | 4,006 |  |  | 9,213 |  |  | 7,882 |  |
|  | Add back adjustments to tax provision (b) | (1,673 | ) |  | (704 | ) |  | (3,035 | ) |  | (1,787 | ) |
| Non-GAAP NET INCOME | $ | 25,032 |  |  | $ | 37,991 |  |  | $ | 41,706 |  |  | $ | 54,483 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.46 |  |  | $ | 0.73 |  |  | $ | 0.74 |  |  | $ | 1.02 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.06 |  |  | 0.07 |  |  | 0.13 |  |  | 0.12 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.52 |  |  | $ | 0.80 |  |  | $ | 0.87 |  |  | $ | 1.14 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.43 |  |  | $ | 0.67 |  |  | $ | 0.69 |  |  | $ | 0.94 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.05 |  |  | 0.06 |  |  | 0.11 |  |  | 0.10 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.48 |  |  | $ | 0.73 |  |  | $ | 0.80 |  |  | $ | 1.04 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP | 48,124 |  |  | 47,651 |  |  | 48,144 |  |  | 47,584 |  |
|  | BASIC - Non-GAAP | 48,124 |  |  | 47,651 |  |  | 48,144 |  |  | 47,584 |  |
|  | DILUTED – GAAP | 51,521 |  |  | 51,489 |  |  | 51,352 |  |  | 51,405 |  |
|  | DILUTED - Non-GAAP | 52,555 |  |  | 52,113 |  |  | 52,391 |  |  | 52,166 |  |

[0001628280-17-000437:8k_2_02:34]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three and six months ended December 31, 2016 and 2015.

[0001628280-17-000437:8k_2_02:35]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 30.5% and 31.0% for the three and six months ended December 31, 2016, respectively, and 28.0% and 30.0% for the three and six months ended December 31, 2015, respectively.

[0001628280-17-000437:8k_2_02:36]
SOURCE: Super Micro Computer, Inc.

[0001628280-17-000437:8k_2_02:37]
Super Micro Computer, Inc.

[0001628280-17-000437:8k_2_02:38]
Howard Hideshima, 408-503-8000

[0001628280-17-000437:8k_2_02:39]
SVP, Chief Financial Officer

[0001628280-17-000437:8k_2_02:40]
ir@supermicro.com

[0001628280-17-000437:8k_2_02:41]
or

[0001628280-17-000437:8k_2_02:42]
Perry G. Hayes

[0001628280-17-000437:8k_2_02:43]
SVP, Investor Relations

[0001628280-17-000437:8k_2_02:44]
ir@supermicro.com

[0001628280-17-000437:8k_2_02:45]
SMCI-F
