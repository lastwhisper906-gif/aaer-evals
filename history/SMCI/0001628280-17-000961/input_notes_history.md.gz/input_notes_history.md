# SMCI note change history — 0001628280-16-020941 → 0001628280-17-000961


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001628280-17-000961:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of December 31, 2016, these remaining non-cancellable commitments were $402,229,000 compared to $334,010,000 as of June 30, 2016.
  (was, 2016-11-07, similarity 0.678):
[0001628280-16-020941:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of September 30, 2016, these remaining non-cancellable commitments were $354,796,000 compared to $334,010,000 as of June 30, 2016.

- removed (2017-02-07):
[0001628280-16-020941:note_history:2]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $42,200,000, which will be paid through December 2016. The Company has entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001628280-17-000961:note_history:3]
The unaudited condensed consolidated financial statements reflect the condensed consolidated balance sheets, results of operations, comprehensive income and cash flows of Super Micro Computer, Inc. and its wholly-owned subsidiaries (collectively, the “Company”). All intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2016-11-07, similarity 0.9853):
[0001628280-16-020941:note_history:3]
The condensed consolidated financial statements reflect the condensed consolidated balance sheets, results of operations, comprehensive income and cash flows of Super Micro Computer, Inc. and its wholly-owned subsidiaries (collectively, the “Company”). All intercompany accounts and transactions have been eliminated in consolidation.

- changed (2017-02-07):
[0001628280-17-000961:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.
  (was, 2016-11-07, similarity 0.7195):
[0001628280-16-020941:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.

- changed (2017-02-07):
[0001628280-17-000961:note_history:5]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectibility and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position. The Company has not yet selected a transition method nor has it determined the effect of the guidance on its ongoing financial reporting.
  (was, 2016-11-07, similarity 0.9644):
[0001628280-16-020941:note_history:5]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectibility and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- changed (2017-02-07):
[0001628280-17-000961:note_history:6]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.
  (was, 2016-11-07, similarity 0.9847):
[0001628280-16-020941:note_history:6]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the amendment to the guidance will have on its financial statement disclosures, results of operations and financial position.

- added (2017-02-07):
[0001628280-17-000961:note_history:7]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. This amendment is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosure, results of operations and financial position.

- added (2017-02-07):
[0001628280-17-000961:note_history:8]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This amendment is effective for the Company on July 1, 2018. Early adoption is permitted. The Company does not expect the impact of adopting this guidance to be significant.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001628280-17-000961:note_history:9]
Short-term and long-term obligations as of December 31, 2016 and June 30, 2016 consisted of the following (in thousands):
  (was, 2016-11-07, similarity 0.9776):
[0001628280-16-020941:note_history:9]
Short-term and long-term obligations as of September 30, 2016 and June 30, 2016 consisted of the following (in thousands):

- changed (2017-02-07):
[0001628280-17-000961:note_history:10]
|  | December 31, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 43,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,800 |  |  | 10,100 |  |
| Total line of credit | 63,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 45,000 |  |  | 933 |  |
| CTBC Bank | 18,521 |  |  | 20,357 |  |
| Total term loans | 63,521 |  |  | 21,290 |  |
| Total debt | 127,520 |  |  | 93,589 |  |
| Less: debt issuance costs | (345 | ) |  | — |  |
| Total debt, net of debt issuance costs | 127,175 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (92,443 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 34,732 |  |  | $ | 40,000 |  |
  (was, 2016-11-07, similarity 0.9869):
[0001628280-16-020941:note_history:10]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 11,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 18,800 |  |  | 10,100 |  |
| Total line of credit | 29,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America (1) | 47,500 |  |  | 933 |  |
| CTBC Bank | 21,061 |  |  | 20,357 |  |
| Total term loans | 68,561 |  |  | 21,290 |  |
| Total debt | 98,560 |  |  | 93,589 |  |
| Less: debt issuance costs | (365 | ) |  | — |  |
| Total debt, net of debt issuance costs | 98,195 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (60,983 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 37,212 |  |  | $ | 40,000 |  |

- changed (2017-02-07):
[0001628280-17-000961:note_history:11]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.61% at December 31, 2016. The letter of credit is charged at 1.25% per annum.
  (was, 2016-11-07, similarity 0.6515):
[0001628280-16-020941:note_history:11]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.52% at September 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, the Company received $50,000,000 term loan proceeds from Bank of America under the new credit agreement with an interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America.

- changed (2017-02-07):
[0001628280-17-000961:note_history:12]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10,000,000 for the Taiwan and the Netherlands subsidiaries that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds.
  (was, 2016-11-07, similarity 0.963):
[0001628280-16-020941:note_history:12]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10,000,000 for the Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds.

- added (2017-02-07):
[0001628280-17-000961:note_history:13]
In December 2016, the Company entered into an amendment to the credit agreement with Bank of America to reduce the $55,000,000 revolving line of credit facility to $45,000,000 and increase the revolving line of credit for the Taiwan and the Netherlands subsidiaries from $10,000,000 to $20,000,000.

- changed (2017-02-07):
[0001628280-17-000961:note_history:14]
As of December 31, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $45,000,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $43,199,000 and $62,199,000 as of December 31, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.19% to 2.14% per annum at December 31, 2016 and from 1.02% to 1.96% per annum at June 30, 2016. As of December 31, 2016, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $21,801,000.
  (was, 2016-11-07, similarity 0.8697):
[0001628280-16-020941:note_history:14]
As of September 30, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $47,500,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $11,199,000 and $62,199,000 as of September 30, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.08% to 1.77% per annum at September 30, 2016 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of September 30, 2016, the amount of the unused revolving lines of credit with Bank of America under the new credit agreements was $53,801,000.

- changed (2017-02-07):
[0001628280-17-000961:note_history:15]
In February 2017, the Company drew an additional $10,000,000 from Bank of America revolving line of credit with interest rate at 1.29% per annum to support the Company's growth and expansion of its business in the Netherlands.
  (was, 2016-11-07, similarity 0.8578):
[0001628280-16-020941:note_history:15]
In October 2016, the Company drew an additional $30,000,000 from Bank of America revolving line of credit with interest rates ranging from 2.14% to 3.75% per annum to support the Company's growth and expansion of its business in the Netherlands.

- changed (2017-02-07):
[0001628280-17-000961:note_history:16]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $18,521,000 and $20,357,000 at December 31, 2016 and June 30, 2016, respectively. At December 31, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20,800,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.95% and 2.15% at December 31, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At December 31, 2016, available for future borrowing under this credit agreement was $612,000.
  (was, 2016-11-07, similarity 0.9739):
[0001628280-16-020941:note_history:16]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,061,000 and $20,357,000 at September 30, 2016 and June 30, 2016, respectively. At September 30, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $18,800,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.89% and 1.40% at September 30, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At September 30, 2016, available for future borrowing under this credit agreement was $139,000.

- added (2017-02-07):
[0001628280-17-000961:note_history:17]
In January 2017, the Company drew an additional $8,000,000 from CTBC Bank revolving line of credit with the interest rate at 1.55% per annum to support the Company's growth and expansion of its business in the Netherlands.

- changed (2017-02-07):
[0001628280-17-000961:note_history:18]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:
  (was, 2016-11-07, similarity 0.9855):
[0001628280-16-020941:note_history:18]
The new credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The new credit agreement contains certain financial covenants, including the following:

- changed (2017-02-07):
[0001628280-17-000961:note_history:19]
As of December 31, 2016 and June 30, 2016, total assets of $998,259,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of December 31, 2016 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the credit agreement were $101,074,000 and $59,258,000, respectively. As of December 31, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.
  (was, 2016-11-07, similarity 0.9777):
[0001628280-16-020941:note_history:19]
As of September 30, 2016 and June 30, 2016, total assets of $959,924,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of September 30, 2016 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the new credit agreement were $82,006,000 and $59,258,000, respectively. As of September 30, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

- changed (2017-02-07):
[0001628280-17-000961:note_history:20]
As of December 31, 2016 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,623,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2016.
  (was, 2016-11-07, similarity 0.9377):
[0001628280-16-020941:note_history:20]
As of September 30, 2016 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,691,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2016.

- removed (2017-02-07):
[0001628280-16-020941:note_history:21]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan at September 30, 2016 and June 30, 2016.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001628280-17-000961:note_history:22]
Short-term and long-term obligations as of December 31, 2016 and June 30, 2016 consisted of the following (in thousands):
  (was, 2016-11-07, similarity 0.9776):
[0001628280-16-020941:note_history:22]
Short-term and long-term obligations as of September 30, 2016 and June 30, 2016 consisted of the following (in thousands):

- changed (2017-02-07):
[0001628280-17-000961:note_history:23]
|  | December 31, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 43,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,800 |  |  | 10,100 |  |
| Total line of credit | 63,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 45,000 |  |  | 933 |  |
| CTBC Bank | 18,521 |  |  | 20,357 |  |
| Total term loans | 63,521 |  |  | 21,290 |  |
| Total debt | 127,520 |  |  | 93,589 |  |
| Less: debt issuance costs | (345 | ) |  | — |  |
| Total debt, net of debt issuance costs | 127,175 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (92,443 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 34,732 |  |  | $ | 40,000 |  |
  (was, 2016-11-07, similarity 0.9869):
[0001628280-16-020941:note_history:23]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 11,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 18,800 |  |  | 10,100 |  |
| Total line of credit | 29,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America (1) | 47,500 |  |  | 933 |  |
| CTBC Bank | 21,061 |  |  | 20,357 |  |
| Total term loans | 68,561 |  |  | 21,290 |  |
| Total debt | 98,560 |  |  | 93,589 |  |
| Less: debt issuance costs | (365 | ) |  | — |  |
| Total debt, net of debt issuance costs | 98,195 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (60,983 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 37,212 |  |  | $ | 40,000 |  |

- removed (2017-02-07):
[0001628280-16-020941:note_history:24]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan at September 30, 2016 and June 30, 2016.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001628280-17-000961:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.4% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at December 31, 2016.
  (was, 2016-11-07, similarity 0.9954):
[0001628280-16-020941:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at September 30, 2016.

- changed (2017-02-07):
[0001628280-17-000961:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $64,930,000 and $115,135,000, and sold products to Ablecom totaling $7,003,000 and $10,345,000 for the three and six months ended December 31, 2016, respectively. The Company purchased products from Ablecom totaling $71,451,000 and $130,712,000, and sold products to Ablecom totaling $2,492,000 and $7,712,000 for the three and six months ended December 31, 2015, respectively.
  (was, 2016-11-07, similarity 0.7097):
[0001628280-16-020941:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $50,205,000 and $59,261,000, and sold products to Ablecom totaling $3,342,000 and $5,220,000 for the three months ended September 30, 2016 and 2015, respectively.

- changed (2017-02-07):
[0001628280-17-000961:note_history:27]
Amounts owed to the Company by Ablecom as of December 31, 2016 and June 30, 2016 were $12,378,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2016 and June 30, 2016 were $54,278,000 and $39,152,000, respectively. For the three and six months ended December 31, 2016, the Company paid Ablecom the majority of invoiced dollars between 48 and 83 days of invoice date. For the three and six months ended December 31, 2016, the Company paid $1,191,000 and $2,936,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2015, the Company paid $1,736,000 and $2,898,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2016-11-07, similarity 0.7662):
[0001628280-16-020941:note_history:27]
Amounts owed to the Company by Ablecom as of September 30, 2016 and June 30, 2016 were $7,251,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2016 and June 30, 2016 were $38,290,000 and $39,152,000, respectively. For the three months ended September 30, 2016, the Company paid Ablecom the majority of invoiced dollars between 47 and 77 days of invoice date. For the three months ended September 30, 2016 and 2015, the Company paid $1,745,000 and $1,162,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2017-02-07):
[0001628280-17-000961:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $104,569,000 and $62,782,000 at December 31, 2016 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2016-11-07, similarity 0.9954):
[0001628280-16-020941:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $77,369,000 and $62,782,000 at September 30, 2016 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2017-02-07):
[0001628280-17-000961:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2016, $29,000 and $24,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively. In the three and six months ended December 31, 2015, $6,000 and $4,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively.
  (was, 2016-11-07, similarity 0.878):
[0001628280-16-020941:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2016 and 2015, $5,000 and $2,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
