# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001628280-17-000961:item_4_controls:1]
Item 4.    Controls and Procedures

[0001628280-17-000961:item_4_controls:2]
Evaluation of Effectiveness of Disclosure Controls and Procedures

[0001628280-17-000961:item_4_controls:3]
We are committed to maintaining disclosure controls and procedures designed to ensure that information required to be disclosed in our periodic reports filed under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure.

[0001628280-17-000961:item_4_controls:4]
Under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, we evaluated the effectiveness of our disclosure controls and procedures, as such term is defined in Rule 13a-15(e) and 15d-15(e) promulgated under the Exchange Act. The evaluation considered the procedures designed to ensure that information required to be disclosed by us in the reports filed or submitted by us under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were effective at a reasonable assurance level as of December 31, 2016.

[0001628280-17-000961:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0001628280-17-000961:item_4_controls:6]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) identified in connection with the evaluation described in this Item 9A that occurred during the quarter ended December 31, 2016 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-17-000961:item_4_controls:7]
32
