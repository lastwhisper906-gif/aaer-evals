# SMCI notes — 0001375365-21-000083


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-21-000083:notes:1]
[same as prior period, unchanged from 0001375365-21-000034:notes:1]

[0001375365-21-000083:notes:2]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 27, 2021, for the year ended June 30, 2021. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.

[0001375365-21-000083:notes:3]
[same as prior period, unchanged from 0001375365-21-000034:notes:3]

[0001375365-21-000083:notes:4]
[same as prior period, unchanged from 0001375365-21-000034:notes:4]

[0001375365-21-000083:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2022.

[0001375365-21-000083:notes:6]
[same as prior period, unchanged from 0001375365-21-000034:notes:13]

[0001375365-21-000083:notes:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 22.0% of total purchases for the three months ended September 30, 2021 and 2020, respectively. Purchases from Ablecom, and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 9.6% and 9.2% of total cost of sales for the three months ended September 30, 2021 and 2020, respectively.

[0001375365-21-000083:notes:8]
[same as prior period, unchanged from 0001375365-21-000034:notes:15]

[0001375365-21-000083:notes:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021 and 2020. One customer accounted for 11.7% and 13.5% of accounts receivable, net as of September 30, 2021 and June 30, 2021, respectively.

[0001375365-21-000083:notes:10]
[same as prior period, unchanged from 0001375365-21-000034:notes:19]

[0001375365-21-000083:notes:11]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021. The adoption of the guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

[0001375365-21-000083:notes:12]
[same as prior period, unchanged from 0001375365-21-000034:notes:25]

[0001375365-21-000083:notes:13]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 which provided for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. As the amendment had changes not related to LIBOR replacement, optional expedients under this guidance cannot be elected. The E.SUN Credit Facility will terminate on July 29, 2022 before the phase out of LIBOR. Therefore, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-21-000083:notes:14]
Revenue
Disaggregation of Revenue

[0001375365-21-000083:notes:15]
[same as prior period, unchanged from 0001375365-21-000034:notes:29]

[0001375365-21-000083:notes:16]
[same as prior period, unchanged from 0001375365-21-000034:notes:30]

[0001375365-21-000083:notes:17]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849,856 |  |  |  |  | $ | 617,788 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 182,874 |  |  |  |  | 144,462 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,032,730 |  |  |  |  | $ | 762,250 |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-21-000083:notes:18]
[same as prior period, unchanged from 0001375365-21-000034:notes:32]

[0001375365-21-000083:notes:19]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):

[0001375365-21-000083:notes:20]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 560,948 |  |  | $ | 496,086 |  |  |  |  |  |
| Asia | 263,086 |  |  | 126,707 |  |  |  |  |  |
| Europe | 179,694 |  |  | 112,089 |  |  |  |  |  |
| Other | 29,002 |  |  | 27,368 |  |  |  |  |  |
|  | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |

[0001375365-21-000083:notes:21]
[same as prior period, unchanged from 0001375365-21-000034:notes:36]

[0001375365-21-000083:notes:22]
[same as prior period, unchanged from 0001375365-21-000034:notes:37]

[0001375365-21-000083:notes:23]
[same as prior period, unchanged from 0001375365-21-000034:notes:38]

[0001375365-21-000083:notes:24]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2021, which was included in the opening deferred revenue balance as of June 30, 2021 of $202.3 million, was $30.0 million.

[0001375365-21-000083:notes:25]
Deferred revenue increased $13.1 million during the three months ended September 30, 2021 as compared to the fiscal year ended June 30, 2021 mainly due to the increase in non-cancellable non-refundable advance considerations received from customers which precede the Company's satisfaction of the associated performance obligations.

[0001375365-21-000083:notes:26]
[same as prior period, unchanged from 0001375365-21-000034:notes:41]

[0001375365-21-000083:notes:27]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2021 was $215.4 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-21-000083:notes:28]
[same as prior period, unchanged from 0001375365-21-000034:notes:43]

[0001375365-21-000083:notes:29]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

[0001375365-21-000083:notes:30]
[same as prior period, unchanged from 0001375365-21-000034:notes:46]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-21-000083:notes:31]
The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-21-000083:notes:32]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2021 and 2020 (in thousands, except per share amounts):

[0001375365-21-000083:notes:33]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 25,437 |  |  | $ | 26,601 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 50,796 |  |  | 52,329 |  |  |  |  |  |
| Effect of dilutive securities | 2,120 |  |  | 2,097 |  |  |  |  |  |
| Weighted-average diluted shares | 52,916 |  |  | 54,426 |  |  |  |  |  |
| Basic net income per common share | $ | 0.50 |  |  | $ | 0.51 |  |  |  |  |  |
| Diluted net income per common share | $ | 0.48 |  |  | $ | 0.49 |  |  |  |  |  |

[0001375365-21-000083:notes:34]
For the three months ended September 30, 2021 and 2020, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 694,211 and 1,177,694 for the three months ended September 30, 2021 and 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-21-000083:notes:35]
Balance Sheet Components
The following tables provide details of the selected balance sheet items (in thousands):

[0001375365-21-000083:notes:36]
[same as prior period, unchanged from 0001375365-21-000034:notes:52]

[0001375365-21-000083:notes:37]
|  | September 30, 2021 |  | June 30, 2021 |
| Finished goods | $ | 781,992 |  |  | $ | 761,694 |  |
| Work in process | 172,593 |  |  | 80,472 |  |
| Purchased parts and raw materials | 229,988 |  |  | 198,798 |  |
| Total inventories | $ | 1,184,573 |  |  | $ | 1,040,964 |  |

[0001375365-21-000083:notes:38]
During the three months ended September 30, 2021 and 2020, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $3.5 million and $0.9 million, respectively. The Company classifies subsystems and

[0001375365-21-000083:notes:39]
accessories that may be sold separately or incorporated into systems as finished goods.

[0001375365-21-000083:notes:40]
[same as prior period, unchanged from 0001375365-21-000034:notes:56]

[0001375365-21-000083:notes:41]
|  | September 30, 2021 |  | June 30, 2021 |
| Other receivables (1) | $ | 87,269 |  |  | $ | 99,921 |  |
| Prepaid income tax | 13,797 |  |  | 12,288 |  |
| Prepaid expenses | 9,210 |  |  | 6,719 |  |
| Deferred service costs | 4,680 |  |  | 4,900 |  |
| Restricted cash | 251 |  |  | 251 |  |
| Others | 9,052 |  |  | 6,116 |  |
| Total prepaid expenses and other current assets | $ | 124,259 |  |  | $ | 130,195 |  |

[0001375365-21-000083:notes:42]
[same as prior period, unchanged from 0001375365-21-000034:notes:58]

[0001375365-21-000083:notes:43]
(1) Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $75.2 million and $76.2 million as of September 30, 2021 and June 30, 2021, respectively.

[0001375365-21-000083:notes:44]
[same as prior period, unchanged from 0001375365-21-000034:notes:60]

[0001375365-21-000083:notes:45]
|  | September 30, 2021 |  | June 30, 2021 |
| Cash and cash equivalents | $ | 270,047 |  |  | $ | 232,266 |  |
| Restricted cash included in prepaid expenses and other current assets | 251 |  |  | 251 |  |
| Restricted cash included in other assets | 929 |  |  | 932 |  |
| Total cash, cash equivalents and restricted cash | $ | 271,227 |  |  | $ | 233,449 |  |

[0001375365-21-000083:notes:46]
[same as prior period, unchanged from 0001375365-21-000034:notes:62]

[0001375365-21-000083:notes:47]
|  | September 30, 2021 |  | June 30, 2021 |
| Buildings | $ | 143,512 |  | $ | 86,930 |  |
| Land | 84,602 |  | 76,421 |  |
| Machinery and equipment | 102,522 |  | 97,671 |  |
| Building construction in progress (1) | 5,919 |  | 87,438 |  |
| Building and leasehold improvements | 43,422 |  | 26,640 |  |
| Software | 23,093 |  | 22,592 |  |
| Furniture and fixtures | 31,782 |  | 22,843 |  |
|  | 434,852 |  | 420,535 |  |
| Accumulated depreciation and amortization | (150,704) |  | (145,822) |  |
| Property, plant and equipment, net | $ | 284,148 |  | $ | 274,713 |  |

[0001375365-21-000083:notes:48]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California, and a new building in Taiwan.

[0001375365-21-000083:notes:49]
[same as prior period, unchanged from 0001375365-21-000034:notes:65]

[0001375365-21-000083:notes:50]
|  | September 30, 2021 |  | June 30, 2021 |
| Operating lease right-of-use asset | $ | 24,156 |  |  | $ | 20,047 |  |
| Deferred service costs, non-current | 5,576 |  |  | 5,421 |  |
| Prepaid expense, non-current | 1,890 |  |  | 1,973 |  |
| Investment in auction rate security | 1,556 |  |  | 1,556 |  |
| Deposits | 1,449 |  |  | 1,669 |  |
| Restricted cash, non-current | 929 |  |  | 932 |  |
| Other | 1,604 |  |  | 528 |  |
| Total other assets | $ | 37,160 |  |  | $ | 32,126 |  |

[0001375365-21-000083:notes:51]
[same as prior period, unchanged from 0001375365-21-000034:notes:67]

[0001375365-21-000083:notes:52]
|  | September 30, 2021 |  | June 30, 2021 |
| Accrued payroll and related expenses | $ | 43,912 |  |  | $ | 45,770 |  |
| Contract manufacturing liabilities | 39,206 |  |  | 45,319 |  |
| Customer deposits | 30,773 |  |  | 32,419 |  |
| Accrued warranty costs | 9,532 |  |  | 10,185 |  |
| Accrued cooperative marketing expenses | 7,811 |  | 5,652 |  |
| Operating lease liability | 6,400 |  |  | 6,322 |  |
| Accrued professional fees | 2,343 |  |  | 2,737 |  |
| Other | 35,245 |  |  | 30,446 |  |
| Total accrued liabilities | $ | 175,221 |  |  | $ | 178,850 |  |

[0001375365-21-000083:notes:53]
[same as prior period, unchanged from 0001375365-21-000034:notes:69]

[0001375365-21-000083:notes:54]
[same as prior period, unchanged from 0001375365-21-000034:notes:70]

[0001375365-21-000083:notes:55]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved.

[0001375365-21-000083:notes:56]
During the fiscal year ended June 30, 2021, the target average closing prices for both tranches were met and the cash payment under the second tranche was made. On September 21, 2021, the Audit Committee of the Board determined and advised the Board as to its view that the Company had made adequate progress in remediating the material weaknesses in its internal control over financial reporting. On September 30, 2021, the Board considered and agreed with this assessment, but also considered the impact of accomplishments of Company employees other than Mr. Liang in achieving this adequate progress. The Board exercised its discretion under the terms of the performance bonuses to reduce the payout for the first tranche from 50% to approximately 25% of $8.1 million, for an aggregate of $2.0 million. The payout of $2.0 million was made subsequent to September 30, 2021.

[0001375365-21-000083:notes:57]
The Company previously expected that the full amount of the first tranche would be paid to its Chief Executive Officer and, accordingly, recorded a liability of $3.6 million related to this tranche on its balance sheet as of June 30, 2021.  In light of the Board’s action in September 2021 to reduce the amount of the first tranche payout to $2.0 million, the Company adjusted the amount of this liability on its balance sheet as of September 30, 2021 to $2.0 million and recognized a benefit of $1.6 million in its consolidated statement of operations during the quarter ended September 30, 2021. The (benefit) or expense recognized during the three months ended September 30, 2021 and 2020 was $(1.6) million and $0.1 million, respectively.

[0001375365-21-000083:notes:58]
[same as prior period, unchanged from 0001375365-21-000034:notes:77]

[0001375365-21-000083:notes:59]
|  | September 30, 2021 |  | June 30, 2021 |
| Operating lease liability, non-current | $ | 18,366 |  |  | $ | 14,539 |  |
| Accrued unrecognized tax benefits including related interest and penalties | 18,392 |  |  | 17,841 |  |
| Accrued warranty costs, non-current | 2,701 |  |  | 2,678 |  |
| Other | 6,074 |  |  | 6,074 |  |
| Total other long-term liabilities | $ | 45,533 |  |  | $ | 41,132 |  |

[0001375365-21-000083:notes:60]
[same as prior period, unchanged from 0001375365-21-000034:notes:79]

[0001375365-21-000083:notes:61]
|  | Three Months EndedSeptember 30, |  |
|  | 2021 |  | 2020 |  |  |  |
| Balance, beginning of the period | $ | 12,863 |  |  | $ | 12,379 |  |  |  |  |
| Provision for warranty | 6,386 |  |  | 8,347 |  |  |  |  |
| Costs utilized | (7,199) |  |  | (7,607) |  |  |  |  |
| Change in estimated liability for pre-existing warranties | 183 |  |  | 608 |  |  |  |  |
| Balance, end of the period | 12,233 |  |  | 13,727 |  |  |  |  |
| Current portion | 9,532 |  |  | 11,057 |  |  |  |  |
| Non-current portion | $ | 2,701 |  |  | $ | 2,670 |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-21-000083:notes:62]
Fair Value Disclosure
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-21-000083:notes:63]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2021 and June 30, 2021. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of September 30, 2021.

[0001375365-21-000083:notes:64]
[same as prior period, unchanged from 0001375365-21-000034:notes:83]

[0001375365-21-000083:notes:65]
The following table sets forth the Company’s financial instruments as of September 30, 2021 and June 30, 2021, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-21-000083:notes:66]
| September 30, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | 151 |  |
| Certificates of deposit (2) | — |  |  | 862 |  |  | — |  |  | 862 |  |
| Auction rate security | — |  |  | — |  |  | 1,556 |  |  | 1,556 |  |
| Total assets measured at fair value | $ | 151 |  |  | $ | 862 |  |  | $ | 1,556 |  |  | $ | 2,569 |  |
| June 30, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | 151 |  |
| Certificates of deposit (2) | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Auction rate security | — |  |  | — |  |  | 1,556 |  |  | 1,556 |  |
| Total assets measured at fair value | $ | 151 |  |  | $ | 863 |  |  | $ | 1,556 |  |  | $ | 2,570 |  |

[0001375365-21-000083:notes:67]
(1) $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2021 and June 30, 2021, respectively.

[0001375365-21-000083:notes:68]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.4 million and $0.4 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2021 and June 30, 2021, respectively.

[0001375365-21-000083:notes:69]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three months ended September 30, 2021, the credit losses related to the Company’s investments was not significant.

[0001375365-21-000083:notes:70]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three months ended September 30, 2021 and 2020.

[0001375365-21-000083:notes:71]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three months ended September 30, 2021 and 2020.

[0001375365-21-000083:notes:72]
The following is a summary of the Company’s investment in an auction rate security as of September 30, 2021 and June 30, 2021 (in thousands):

[0001375365-21-000083:notes:73]
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (194) |  |  | $ | 1,556 |  |

[0001375365-21-000083:notes:74]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three months ended September 30, 2021 and 2020.

[0001375365-21-000083:notes:75]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2021 and June 30, 2021, total debt of $278.8 million and $98.2 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-21-000083:notes:76]
Other Financial Assets - Investments into Non-Marketable Equity Securities

[0001375365-21-000083:notes:77]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $1.2 million and $0.1 million as of September 30, 2021 and June 30, 2021, respectively. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three months ended September 30, 2021 and 2020, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three months ended September 30, 2021 and 2020.


## us-gaap:DebtDisclosureTextBlock

[0001375365-21-000083:notes:78]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2021 and June 30, 2021 consisted of the following (in thousands):

[0001375365-21-000083:notes:79]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 110,193 |  |  | $ | — |  |
| CTBC Bank | 68,100 |  |  | 18,000 |  |
| E.SUN Bank | 30,000 |  |  | 20,400 |  |
| Total line of credit | 208,293 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | 25,195 |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,018 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 1,434 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 4,868 |  |  | — |  |
| Total term loans | 70,515 |  |  | 59,790 |  |
| Total debt | 278,808 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 233,674 |  |  | 63,490 |  |
| Debt, Non-current | $ | 45,134 |  |  | $ | 34,700 |  |

[0001375365-21-000083:notes:80]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-21-000083:notes:81]
Bank of America

[0001375365-21-000083:notes:82]
2018 Bank of America Credit Facility

[0001375365-21-000083:notes:83]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million, increase the maximum amount that the Company can request the facility be increased from $100.0 million to $150.0 million, and update provisions relating to erroneous payments and LIBOR replacement mechanics. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-21-000083:notes:84]
As of September 30, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $110.2 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2021 and June 30, 2021 were 1.50%. The balance of debt issuance costs outstanding as of September 30, 2021 and June 30, 2021 were $0.5 million. The

[0001375365-21-000083:notes:85]
Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2021, the Company's available borrowing capacity was $89.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-21-000083:notes:86]
CTBC Bank

[0001375365-21-000083:notes:87]
2021 CTBC Credit Lines

[0001375365-21-000083:notes:88]
The Company through its Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

[0001375365-21-000083:notes:89]
On July 20, 2021 (the “Effective Date”), the Company through its Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million  U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million  U.S. dollar equivalents) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

[0001375365-21-000083:notes:90]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-21-000083:notes:91]
As of September 30, 2021 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.0 million and $34.7 million, respectively. The interest rates for these loans were 0.45% per annum as of September 30, 2021 and June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $1.4 million at September 30, 2021. The interest rates for these loans were 0.65% per annum as of September 30, 2021. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

[0001375365-21-000083:notes:92]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.2 million and $25.1 million at September 30, 2021 and June 30, 2021, respectively. The interest rate for these loans were 0.74% and 0.75% per annum as of September 30, 2021 and June 30, 2021, respectively.  As of September 30, 2021, and June 30, 2021, the outstanding borrowings of 2021 CTBC Credit Facility revolving line of credit were $68.1 million and $18.0 million, respectively. The interest rates for these loans ranged from approximately 0.94% to 0.95% per annum as of September 30, 2021. The interest rate was 0.98% per annum as of June 30, 2021. As of September 30, 2021, the amount available for future borrowing under the 2021 CTBC Credit Facility was $11.7 million. As of September 30, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million. As of September 30, 2021, all financial covenants under the 2021 CTBC Credit Lines were satisfied.

[0001375365-21-000083:notes:93]
E.SUN Bank

[0001375365-21-000083:notes:94]
2021 E.SUN Bank Credit Facility

[0001375365-21-000083:notes:95]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility was until September 18, 2021.

[0001375365-21-000083:notes:96]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements.

[0001375365-21-000083:notes:97]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and  development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of September 30, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $4.9 million and the interest rates for these loans were 0.995% per annum. As of September 30, 2021 and June 30, 2021, the amounts outstanding under the Import Loan were $30.0 and $20.4 million, respectively. The interest rates for these loans ranged approximately from 0.96% to 1.23% and 1.00% to 1.29% per annum as of September 30, 2021 and June 30, 2021, respectively. At September 30, 2021, the amount available for future borrowing under the Import Loan was $0.0 million and all financial covenants under the 2021 E.SUN Bank Credit Facility were satisfied.

[0001375365-21-000083:notes:98]
Mega Bank

[0001375365-21-000083:notes:99]
Mega Bank Credit Facilities

[0001375365-21-000083:notes:100]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of September 30, 2021, there were no outstanding borrowings under the Mega Bank Credit Facility.

[0001375365-21-000083:notes:101]
Chang Hwa Bank

[0001375365-21-000083:notes:102]
Chang Hwa Bank Credit Facility

[0001375365-21-000083:notes:103]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments.  The Chang Hwa Bank Credit Facility has customary default provisions permitting the Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed.

[0001375365-21-000083:notes:104]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants.

[0001375365-21-000083:notes:105]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-21-000083:notes:106]
Fiscal Year:                                                                                                               Principal Payments

[0001375365-21-000083:notes:107]
| 2022 | $ | 233,594 |  |
| 2023 | 1,696 |  |
| 2024 | 7,110 |  |
| 2025 | 7,110 |  |
| 2026 | 7,110 |  |
| 2027 and thereafter | 22,188 |  |
| Total short-term and long-term debt | $ | 278,808 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-21-000083:notes:108]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2021 and 2020 were as follows (in thousands):

[0001375365-21-000083:notes:109]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2021 |  | 2020 |  |  |  |
| Operating lease expense (including expense for lease agreements with related parties of $246 and $347 for the three months ended September 30, 2021 and 2020, respectively) |  | $ | 2,182 |  |  | $ | 2,000 |  |  |  |  |
| Cash payments for operating leases (including payments to related parties of $279 and $347 for the three months ended September 30, 2021 and 2020, respectively) |  | $ | 2,205 |  |  | $ | 1,966 |  |  |  |  |
| New operating lease assets obtained in exchange for operating lease liabilities |  | $ | 6,119 |  |  | $ | 2,059 |  |  |  |  |

[0001375365-21-000083:notes:110]
During the three months ended September 30, 2021 and 2020, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three months ended September 30, 2021 and 2020 were immaterial.

[0001375365-21-000083:notes:111]
As of September 30, 2021, the weighted average remaining lease term for operating leases was 4.3 years and the weighted average discount rate was 3.2%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of September 30, 2021 were as follows (in thousands):

[0001375365-21-000083:notes:112]
| Fiscal Year: |  | Minimum lease payments |
| 2022 |  | $ | 5,682 |  |
| 2023 |  | 6,605 |  |
| 2024 |  | 5,498 |  |
| 2025 |  | 5,349 |  |
| 2026 |  | 2,015 |  |
| 2027 and beyond |  | 1,584 |  |
| Total future lease payments |  | 26,733 |  |
| Less: Imputed interest |  | (1,967) |  |
| Present value of operating lease liabilities |  | $ | 24,766 |  |

[0001375365-21-000083:notes:113]
As of September 30, 2021, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-21-000083:notes:114]
The Company has entered into lease agreements with related parties. See Note 8, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-21-000083:notes:115]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-21-000083:notes:116]
Dealings with Ablecom

[0001375365-21-000083:notes:117]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-21-000083:notes:118]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.5% and 93.6% of the chassis included in the products sold by the Company during the three months ended September 30, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-21-000083:notes:119]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-21-000083:notes:120]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $36.7 million and $40.2 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-21-000083:notes:121]
Dealings with Compuware

[0001375365-21-000083:notes:122]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-21-000083:notes:123]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-21-000083:notes:124]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-21-000083:notes:125]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-21-000083:notes:126]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $87.8 million and $71.0 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-21-000083:notes:127]
Dealings with Investment in a Corporate Venture

[0001375365-21-000083:notes:128]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-21-000083:notes:129]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2021 and June 30, 2021, the Company had unamortized deferred gain balance of $0.5 million and $1.0 million, respectively, in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-21-000083:notes:130]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of the third party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2021. No impairment charge was recorded for the three months ended September 30, 2021 and 2020, respectively.

[0001375365-21-000083:notes:131]
The Company sold products to the Corporate Venture and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities.

[0001375365-21-000083:notes:132]
Dealings with Monolithic Power Systems, Inc.

[0001375365-21-000083:notes:133]
The Company procures certain semiconductor products from Monolithic Power Systems, Inc. (“MPS”), a fabless manufacturer of high-performance analog and mixed-signal semiconductors, for use in its products. A member on the Board of Directors, also serves as an officer of MPS.

[0001375365-21-000083:notes:134]
The Company had the following balances related to transactions with its related parties as of September 30, 2021 and June 30, 2021 (in thousands):

[0001375365-21-000083:notes:135]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 1,332 |  | $ | 198 |  | $ | 12,659 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 13,993 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,428 |  | $ | 5,575 |  | $ | 21,690 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 165 |  | $ | 89 |  | $ | 26,283 |  | $ | 23,837 |  |
| Accounts payable | $ | 40,730 |  | $ | 38,152 |  | $ | 37,024 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 77,754 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 1,813 |  | $ | 3,042 |  | $ | 17,790 |  | $ | 14,486 |  | $ | 500 |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,103 |  | $ | 18,528 |  |

[0001375365-21-000083:notes:136]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-21-000083:notes:137]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

[0001375365-21-000083:notes:138]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 7 |  | $ | 5 |  | $ | 15,702 |  | $ | 13,299 |  | $ | 15,213 |  | $ | 6,412 |  | — |  | — |  | $ | 30,922 |  | $ | 19,716 |  |
| Purchases - inventory | $ | 50,788 |  | $ | 23,871 |  | $ | 35,229 |  | $ | 34,197 |  | — |  | — |  | $ | 1,670 |  | $ | 791 |  | $ | 87,687 |  | $ | 58,859 |  |
| Purchases - other miscellaneous items | $ | 2,116 |  | $ | 2,718 |  | $ | 339 |  | $ | 333 |  | — |  | — |  | — |  | — |  | $ | 2,455 |  | $ | 3,051 |  |

[0001375365-21-000083:notes:139]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

[0001375365-21-000083:notes:140]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | — |  | $ | (27) |  | $ | (1,134) |  | $ | 353 |  | $ | (4,181) |  | $ | 7,184 |  | — |  | — |  | $ | (5,315) |  | $ | 7,510 |  |
| Changes in other receivable | $ | 1,147 |  | $ | 4,243 |  | $ | (3,517) |  | $ | 7,840 |  | — |  | — |  | $ | (76) |  | $ | 75 |  | $ | (2,446) |  | $ | 12,158 |  |
| Changes in accounts payable | $ | 2,578 |  | $ | (14,952) |  | $ | 5,080 |  | $ | (9,724) |  | — |  | — |  | — |  | — |  | $ | 7,658 |  | $ | (24,676) |  |
| Changes in accrued liabilities | $ | (1,229) |  | $ | (203) |  | $ | 3,304 |  | $ | (3,374) |  | $ | (500) |  | — |  | — |  | — |  | $ | 1,575 |  | $ | (3,577) |  |
| Changes in other long-term liabilities | — |  | $ | 47 |  | — |  | $ | (77) |  | — |  | $ | (500) |  | — |  | — |  | — |  | $ | (530) |  |
| Purchases of property, plant and equipment | $ | 338 |  | $ | 2,140 |  | $ | 62 |  | $ | 90 |  | — |  | — |  | — |  | — |  | $ | 400 |  | $ | 2,230 |  |
| Unpaid property, plant and equipment | $ | 1,360 |  | $ | 1,664 |  | — |  | — |  | — |  | — |  | — |  | — |  | $ | 1,360 |  | $ | 1,664 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-21-000083:notes:141]
[same as prior period, unchanged from 0001375365-21-000034:notes:148]

[0001375365-21-000083:notes:142]
[same as prior period, unchanged from 0001375365-21-000034:notes:149]

[0001375365-21-000083:notes:143]
As of September 30, 2021, the Company had 2,385,365 authorized shares available for future issuance under the 2020 Plan.

[0001375365-21-000083:notes:144]
Common Stock Repurchase

[0001375365-21-000083:notes:145]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. The Company had $150.0 million of remaining availability under the share repurchase program as of September 30, 2021.  There were no shares repurchased under the share repurchase program during the three months ended September 30, 2021.

[0001375365-21-000083:notes:146]
[same as prior period, unchanged from 0001375365-21-000034:notes:157]

[0001375365-21-000083:notes:147]
[same as prior period, unchanged from 0001375365-21-000034:notes:158]

[0001375365-21-000083:notes:148]
[same as prior period, unchanged from 0001375365-21-000034:notes:159]

[0001375365-21-000083:notes:149]
[same as prior period, unchanged from 0001375365-21-000034:notes:160]

[0001375365-21-000083:notes:150]
[same as prior period, unchanged from 0001375365-21-000034:notes:161]

[0001375365-21-000083:notes:151]
[same as prior period, unchanged from 0001375365-21-000034:notes:162]

[0001375365-21-000083:notes:152]
The fair value of stock option grants for the three months ended September 30, 2021 and 2020 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-21-000083:notes:153]
|  | Three Months Ended September 30, |  |
|  | 2021 |  | 2020 |  |  |  |
| Risk-free interest rate | 0.81 | % |  | 0.27% |  |  |  |
| Expected term | 6.09 years |  | 5.98 years |  |  |  |
| Dividend yield | — | % |  | — | % |  |  |  |
| Volatility | 49.71 | % |  | 50.43% |  |  |  |
| Weighted-average fair value | $ | 17.94 |  |  | $ | 14.16 |  |  |  |  |

[0001375365-21-000083:notes:154]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2021 and 2020 (in thousands):

[0001375365-21-000083:notes:155]
|  | Three Months Ended September 30, |  |
|  | 2021 |  | 2020 |  |  |  |
| Cost of sales | $ | 447 |  |  | $ | 503 |  |  |  |  |
| Research and development | 3,880 |  |  | 3,702 |  |  |  |  |
| Sales and marketing | 517 |  |  | 517 |  |  |  |  |
| General and administrative | 2,171 |  |  | 2,448 |  |  |  |  |
| Stock-based compensation expense before taxes | 7,015 |  |  | 7,170 |  |  |  |  |
| Income tax impact | (1,888) |  |  | (1,955) |  |  |  |  |
| Stock-based compensation expense, net | $ | 5,127 |  |  | $ | 5,215 |  |  |  |  |

[0001375365-21-000083:notes:156]
As of September 30, 2021, $9.4 million of unrecognized compensation expense related to stock options is expected to be recognized over a weighted-average period of 3.85 years, $51.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.77 years and less than $0.1 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.11 years. Additionally, as described below, $9.6 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 5.0 years.

[0001375365-21-000083:notes:157]
[same as prior period, unchanged from 0001375365-21-000034:notes:168]

[0001375365-21-000083:notes:158]
[same as prior period, unchanged from 0001375365-21-000034:notes:169]

[0001375365-21-000083:notes:159]
The achievement status of the operational and stock price milestones as of September 30, 2021 was as follows:

[0001375365-21-000083:notes:160]
[same as prior period, unchanged from 0001375365-21-000034:notes:171]

[0001375365-21-000083:notes:161]
On the grant date, a Monte Carlo simulation was used to determine for each tranche (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-21-000083:notes:162]
During the three months ended September 30, 2021, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.9 million. No compensation expense related to the 2021 CEO Performance Stock Option was recognized during the three months ended September 30, 2020. As of September 30, 2021 and June 30, 2021, the Company had $9.6 million and $10.5 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of September 30, 2021 is expected to be recognized over a period of five years.

[0001375365-21-000083:notes:163]
The following table summarizes stock option activity during the three months ended September 30, 2021 under all plans:

[0001375365-21-000083:notes:164]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2021 |  | 5,175,554 |  |  | $ | 26.17 |  |  |  |  |  |
| Granted |  | 114,860 |  |  | $ | 37.88 |  |  |  |  |  |
| Exercised |  | (389,942) |  |  | $ | 17.25 |  |  |  |  |  |
| Forfeited/Cancelled |  | (41,459) |  |  | $ | 30.47 |  |  |  |  |  |
| Balance as of September 30, 2021 |  | 4,859,013 |  |  | $ | 27.13 |  |  | 5.52 |  |  |
| Options vested and exercisable at September 30, 2021 |  | 3,099,511 |  |  | $ | 20.82 |  |  | 3.47 |  |  |

[0001375365-21-000083:notes:165]
[same as prior period, unchanged from 0001375365-21-000034:notes:177]

[0001375365-21-000083:notes:166]
[same as prior period, unchanged from 0001375365-21-000034:notes:178]

[0001375365-21-000083:notes:167]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units would vest in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019. An additional 2,939 units were earned for fiscal year 2021 that would vest on November 10, 2021.

[0001375365-21-000083:notes:168]
The following table summarizes RSU and PRSU activity during the three months ended September 30, 2021 under all plans:

[0001375365-21-000083:notes:169]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2021 | 1,854,956 |  |  | $ | 26.79 |  |  | 15,000 |  |  |  | $ | 34.27 |  |
| Granted | 359,405 |  |  | $ | 37.88 |  |  | — |  |  |  | $ | — |  |
| Released | (173,771) |  |  | $ | 22.92 |  |  | — |  |  |  | $ | — |  |
| Forfeited | (87,894) |  |  | $ | 27.54 |  |  | — |  |  |  | $ | — |  |
| Balance as of September 30, 2021 | 1,952,696 |  |  | $ | 29.15 |  |  | 15,000 |  |  |  | $ | 34.27 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-21-000083:notes:170]
Income Taxes
The Company recorded a provision for income taxes of $3.3 million and $3.7 million for the three months ended September 30, 2021 and 2020, respectively. The effective tax rate was 11.7% and 12.7% for the three months ended September 30, 2021 and 2020, respectively. The effective tax rate for the three months ended September 30, 2021 is lower than that for the three months ended September 30, 2020, primarily due to a decrease in certain non-deductible expenses and a decrease in foreign tax liability.

[0001375365-21-000083:notes:171]
As of September 30, 2021, the Company had gross unrecognized tax benefits of $45.1 million, of which, $28.3 million, if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2021, there was a $4.3 million increase in gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2021, the Company had accrued $2.7 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-21-000083:notes:172]
[same as prior period, unchanged from 0001375365-21-000034:notes:186]

[0001375365-21-000083:notes:173]
The Company has determined that its foreign undistributed earnings are indefinitely reinvested except for undistributed earnings related to the Company's operations in the Netherlands. The Company may repatriate certain foreign earnings from the Netherlands that have been previously taxed in the U.S. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-21-000083:notes:174]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.
The federal statute of limitations remains open in general for tax years ended June 30, 2018 through 2021. Various states statutes of limitations remain open in general for tax years ended June 30, 2017 through 2021. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2016 through 2021. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.0 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-21-000083:notes:175]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss.  Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes.  Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales.  The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO.  Discovery has commenced, and the Court has calendared a hearing on class certification for January 22, 2022. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000083:notes:176]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021, and the Court has calendared the hearing for January 26, 2022. The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000083:notes:177]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice.  On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval.  On October 27, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval.  The Court noted that, if no shareholder seeks to intervene during the notice period, plaintiff may file an administrative motion requesting that the Court dismiss the lawsuit with prejudice

[0001375365-21-000083:notes:178]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

[0001375365-21-000083:notes:179]
Other legal proceedings and indemnifications

[0001375365-21-000083:notes:180]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2021 and any prior periods.

[0001375365-21-000083:notes:181]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-21-000083:notes:182]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-21-000083:notes:183]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2021, these remaining noncancelable commitments were $508.2 million, including $124.4 million for related parties.

[0001375365-21-000083:notes:184]
Lease Commitments - See Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-21-000083:notes:185]
Segment ReportingThe Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-21-000083:notes:186]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Long-lived assets: |  |  |  |
| United States | $ | 181,189 |  |  | $ | 180,143 |  |
| Asia | 100,046 |  |  | 91,640 |  |
| Europe | 2,913 |  |  | 2,930 |  |
|  | $ | 284,148 |  |  | $ | 274,713 |  |

[0001375365-21-000083:notes:187]
[same as prior period, unchanged from 0001375365-21-000034:notes:205]
