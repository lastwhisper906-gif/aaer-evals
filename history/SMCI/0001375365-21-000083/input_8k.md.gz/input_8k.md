# SMCI 8-K — 0001375365-21-000078 filed 2021-11-02

## item codes, every 8-K on or before 2021-11-05

- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2021-11-05

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-21-000078:8k_2_02:1]
EX-99.1
2
exhibit991_20210930.htm
EX-99.1

[0001375365-21-000078:8k_2_02:2]
Document

[0001375365-21-000078:8k_2_02:3]
Exhibit 99.1

[0001375365-21-000078:8k_2_02:4]
Supermicro Announces First Quarter Fiscal Year 2022 Financial Results

[0001375365-21-000078:8k_2_02:5]
SAN JOSE, Calif. -- November 2, 2021 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced financial results for its first quarter of fiscal year 2022 ended September 30, 2021.

[0001375365-21-000078:8k_2_02:6]
First Quarter Fiscal Year 2022 Highlights

[0001375365-21-000078:8k_2_02:7]
•Net sales of $1.03 billion versus $1.07 billion in the fourth quarter of fiscal year 2021 and $762 million in the same quarter of last year.

[0001375365-21-000078:8k_2_02:8]
•Gross margin of 13.4% versus 13.6% in the fourth quarter of fiscal year 2021 and 17.0% in the same quarter of last year.

[0001375365-21-000078:8k_2_02:9]
•Net income of $25 million versus $39 million in the fourth quarter of fiscal year 2021 and $27 million in the same quarter of last year.

[0001375365-21-000078:8k_2_02:10]
•Diluted net income per common share of $0.48 versus $0.74 in the fourth quarter of fiscal year 2021 and $0.49 in the same quarter of last year.

[0001375365-21-000078:8k_2_02:11]
•Non-GAAP diluted net income per common share of $0.58 versus $0.81 in the fourth quarter of fiscal year 2021 and $0.55 in the same quarter of last year.

[0001375365-21-000078:8k_2_02:12]
•Cash flow used in operations of $135 million and capital expenditures of $12 million.

[0001375365-21-000078:8k_2_02:13]
Non-GAAP gross margin for the first quarter of fiscal year 2022 was 13.4%, which adds back stock-based compensation expenses of $0.4 million and special performance bonuses and other expenses of $0.3 million. Non-GAAP diluted net income per common share for the first quarter of fiscal year 2022 was $0.58, which adds back stock-based compensation expenses of $7.0 million, special performance bonuses of $0.5 million and controls remediation and litigation expenses of $1.3 million, net of the related tax effects.

[0001375365-21-000078:8k_2_02:14]
As of September 30, 2021, total cash and cash equivalents was $270 million and total bank debt was $279 million.

[0001375365-21-000078:8k_2_02:15]
“For Q1, we are pleased to announce that our quarterly revenue exceeded $1 billion again with revenue growth of 35% year over year, and significantly exceeded industry growth. We continue to gain market share and are executing well against our

[0001375365-21-000078:8k_2_02:16]
plan to achieve $10 billion in annual revenue,” said Charles Liang, Chairman and CEO. "Supermicro is transforming from a server hardware company into a Total IT Solutions company. Our Q1 revenue growth was driven by strong design win momentum and shipment growth to our key global customers in the large enterprise, cloud, AI, and Telco markets. This initiative is helping Supermicro mitigate the impact of the global supply chain disruptions by precise forecasting, building inventories in scale and prioritizing with our strategic partners. Our new 5S business program, APAC production expansion in Taiwan, database-driven intelligent auto-configurator, and B2B/B2C automation platform are key drivers to accelerate our strong growth.”

[0001375365-21-000078:8k_2_02:17]
Business Outlook and Management Commentary

[0001375365-21-000078:8k_2_02:18]
For the second quarter of fiscal year 2022 ending December 31, 2021, the Company expects net sales of $1.1 billion to $1.2 billion, GAAP net income per diluted share of $0.60 to $0.80 and non-GAAP net income per diluted share of $0.70 to $0.90. The Company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 16% and a fully diluted share count of 53.5 million shares for GAAP and fully diluted share count of 55.0 million shares for non-GAAP. The outlook for Q2 of fiscal year 2022 GAAP net income per diluted share includes approximately $8 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-21-000078:8k_2_02:19]
For fiscal year 2022 ending June 30, 2022, the Company expects net sales of $4.2 billion to $4.6 billion, GAAP net income per diluted share of at least $2.77 and non-GAAP net income per diluted share of at least $3.20. The Company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 16% and a fully diluted share count of 54.1 million shares for GAAP and fully diluted share count of 55.6 million shares for non-GAAP. The outlook for fiscal year 2022 GAAP net income per diluted share includes approximately $33 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-21-000078:8k_2_02:20]
Conference Call and Webcast Information

[0001375365-21-000078:8k_2_02:21]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its first quarter of fiscal year 2022. Those wishing to access the live webcast may use the following link:

[0001375365-21-000078:8k_2_02:22]
https://event.on24.com/wcc/r/3409023/D99246BE30B960E5574A262A14152527 [event.on24.com]

[0001375365-21-000078:8k_2_02:23]
The conference call can be accessed by registering online at:

[0001375365-21-000078:8k_2_02:24]
https://conferencingportals.com/event/fIceWmPv [conferencingportals.com]

[0001375365-21-000078:8k_2_02:25]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-21-000078:8k_2_02:26]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-21-000078:8k_2_02:27]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-21-000078:8k_2_02:28]
Use of Non-GAAP Financial Measures

[0001375365-21-000078:8k_2_02:29]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses, special performance bonuses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, controls remediation and litigation expenses and other non-recurring expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-21-000078:8k_2_02:30]
About Super Micro Computer, Inc.

[0001375365-21-000078:8k_2_02:31]
Supermicro (Nasdaq:SMCI), the leading innovator in high-performance, high-efficiency server and storage technology, is a premier provider of advanced server Building Block Solutions® for Enterprise Data Center, Cloud Computing, Artificial Intelligence, and Edge Computing Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-21-000078:8k_2_02:32]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-21-000078:8k_2_02:33]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-21-000078:8k_2_02:34]
Investor Relations Contact

[0001375365-21-000078:8k_2_02:35]
Nicole Noutsios

[0001375365-21-000078:8k_2_02:36]
email: ir@supermicro.com

[0001375365-21-000078:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000078:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-21-000078:8k_2_02:39]
(in thousands)

[0001375365-21-000078:8k_2_02:40]
(unaudited)

[0001375365-21-000078:8k_2_02:41]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 270,047 |  |  | $ | 232,266 |  |
| Accounts receivable, net of allowances | 458,076 |  |  | 463,834 |  |
| Inventories | 1,184,573 |  |  | 1,040,964 |  |
| Prepaid expenses and other current assets | 124,259 |  |  | 130,195 |  |
| Total current assets | 2,036,955 |  |  | 1,867,259 |  |
| Investment in equity investee | 5,161 |  |  | 4,578 |  |
| Property, plant and equipment, net | 284,148 |  |  | 274,713 |  |
| Deferred income taxes, net | 63,269 |  |  | 63,288 |  |
| Other assets | 37,160 |  |  | 32,126 |  |
| Total assets | $ | 2,426,693 |  |  | $ | 2,241,964 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 564,628 |  |  | $ | 612,336 |  |
| Accrued liabilities | 175,221 |  |  | 178,850 |  |
| Income taxes payable | 14,273 |  |  | 12,741 |  |
| Short-term debt | 233,674 |  |  | 63,490 |  |
| Deferred revenue | 113,683 |  |  | 101,479 |  |
| Total current liabilities | 1,101,479 |  |  | 968,896 |  |
| Deferred revenue, non-current | 101,749 |  |  | 100,838 |  |
| Long-term debt, net of debt issuance costs | 45,134 |  |  | 34,700 |  |
| Other long-term liabilities | 45,533 |  |  | 41,132 |  |
| Total liabilities | 1,293,895 |  |  | 1,145,566 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 448,976 |  |  | 438,012 |  |
| Accumulated other comprehensive income | 449 |  |  | 453 |  |
| Retained earnings | 683,197 |  |  | 657,760 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,132,622 |  |  | 1,096,225 |  |
| Noncontrolling interest | 176 |  |  | 173 |  |
| Total stockholders’ equity | 1,132,798 |  |  | 1,096,398 |  |
| Total liabilities and stockholders’ equity | $ | 2,426,693 |  |  | $ | 2,241,964 |  |

[0001375365-21-000078:8k_2_02:42]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000078:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-21-000078:8k_2_02:44]
(in thousands except per share amounts)

[0001375365-21-000078:8k_2_02:45]
(unaudited)

[0001375365-21-000078:8k_2_02:46]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net sales | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |
| Cost of sales | 894,591 |  |  | 632,335 |  |  |  |  |  |
| Gross profit | 138,139 |  |  | 129,915 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 65,143 |  |  | 54,798 |  |  |  |  |  |
| Sales and marketing | 21,624 |  |  | 20,292 |  |  |  |  |  |
| General and administrative | 22,244 |  |  | 24,379 |  |  |  |  |  |
| Total operating expenses | 109,011 |  |  | 99,469 |  |  |  |  |  |
| Income from operations | 29,128 |  |  | 30,446 |  |  |  |  |  |
| Other income (expense), net | 50 |  |  | (841) |  |  |  |  |  |
| Interest expense | (804) |  |  | (674) |  |  |  |  |  |
| Income before income tax provision | 28,374 |  |  | 28,931 |  |  |  |  |  |
| Income tax provision | (3,325) |  |  | (3,660) |  |  |  |  |  |
| Share of income from equity investee, net of taxes | 388 |  |  | 1,330 |  |  |  |  |  |
| Net income | $ | 25,437 |  |  | $ | 26,601 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.50 |  |  | $ | 0.51 |  |  |  |  |  |
| Diluted | $ | 0.48 |  |  | $ | 0.49 |  |  |  |  |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 50,796 |  |  | 52,329 |  |  |  |  |  |
| Diluted | 52,916 |  |  | 54,426 |  |  |  |  |  |

[0001375365-21-000078:8k_2_02:47]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-21-000078:8k_2_02:48]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Cost of sales | $ | 447 |  |  | $ | 503 |  |  |  |  |  |
| Research and development | 3,880 |  |  | 3,702 |  |  |  |  |  |
| Sales and marketing | 517 |  |  | 517 |  |  |  |  |  |
| General and administrative | 2,171 |  |  | 2,448 |  |  |  |  |  |
| Stock-based compensation expense | $ | 7,015 |  |  | $ | 7,170 |  |  |  |  |  |

[0001375365-21-000078:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000078:8k_2_02:50]
SELECTED CASH FLOW INFORMATION

[0001375365-21-000078:8k_2_02:51]
(in thousands)

[0001375365-21-000078:8k_2_02:52]
(unaudited)

[0001375365-21-000078:8k_2_02:53]
|  | Three Months EndedSeptember 30, |
|  | 2021 |  | 2020 |
| Net cash (used in) provided by operating activities | $ | (134,571) |  |  | $ | 120,555 |  |
| Net cash used in investing activities | (11,902) |  |  | (11,851) |  |
| Net cash provided by (used in) financing activities | 184,262 |  |  | (19,327) |  |
| Effect of exchange rate fluctuations on cash | (11) |  |  | 185 |  |
| Net increase in cash, cash equivalents and restricted cash | 37,778 |  |  | 89,562 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 233,449 |  |  | 212,390 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 271,227 |  |  | $ | 301,952 |  |

[0001375365-21-000078:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000078:8k_2_02:55]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000078:8k_2_02:56]
(in thousands except per share amounts)

[0001375365-21-000078:8k_2_02:57]
(unaudited)

[0001375365-21-000078:8k_2_02:58]
|  | Three Months Ended |  |
|  | September 30, 2021 |  | June 30, 2021 |  | September 30, 2020 |  |  |  |
| GAAP GROSS PROFIT | $ | 138,139 |  |  | $ | 145,511 |  |  | $ | 129,915 |  |  |  |  |
| Stock-based compensation | 447 |  |  | 450 |  |  | 503 |  |  |  |  |
| Special performance bonuses and other expenses | 295 |  |  | — |  |  | 20 |  |  |  |  |
| NON-GAAP GROSS PROFIT | $ | 138,881 |  |  | $ | 145,961 |  |  | $ | 130,438 |  |  |  |  |
| GAAP GROSS MARGIN | 13.4 | % |  | 13.6 | % |  | 17.0 | % |  |  |  |
| Stock-based compensation expenses | — |  |  | 0.1 | % |  | 0.1 | % |  |  |  |
| Special performance bonuses and other expenses | — |  |  | — |  |  | — |  |  |  |  |
| NON-GAAP GROSS MARGIN | 13.4 | % |  | 13.7 | % |  | 17.1 | % |  |  |  |
| GAAP OPERATING EXPENSE | $ | 109,011 |  |  | $ | 106,430 |  |  | $ | 99,469 |  |  |  |  |
| Stock-based compensation | (6,568) |  |  | (6,982) |  |  | (6,667) |  |  |  |  |
| Executive SEC settlement | — |  |  | — |  |  | 2,122 |  |  |  |  |
| Special performance bonuses | (158) |  |  | (672) |  |  | (90) |  |  |  |  |
| Other expenses | — |  |  | — |  |  | (221) |  |  |  |  |
| Controls remediation and litigation expenses | (1,326) |  |  | 163 |  |  | — |  |  |  |  |
| NON-GAAP OPERATING EXPENSE | $ | 100,959 |  |  | $ | 98,939 |  |  | $ | 94,613 |  |  |  |  |
| GAAP INCOME FROM OPERATIONS | $ | 29,128 |  |  | $ | 39,081 |  |  | $ | 30,446 |  |  |  |  |
| Stock-based compensation | 7,015 |  |  | 7,432 |  |  | 7,170 |  |  |  |  |
| Executive SEC settlement | — |  |  | — |  |  | (2,122) |  |  |  |  |
| Special performance bonuses | 453 |  |  | 672 |  |  | 90 |  |  |  |  |
| Other expenses | — |  |  | — |  |  | 241 |  |  |  |  |
| Controls remediation and litigation expenses | 1,326 |  |  | (163) |  |  | — |  |  |  |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 37,922 |  |  | $ | 47,022 |  |  | $ | 35,825 |  |  |  |  |
| GAAP NET INCOME | $ | 25,437 |  |  | $ | 39,162 |  |  | $ | 26,601 |  |  |  |  |
| Stock-based compensation | 7,015 |  |  | 7,432 |  |  | 7,170 |  |  |  |  |
| Executive SEC settlement | — |  |  | — |  |  | (2,122) |  |  |  |  |
| Special performance bonuses | 453 |  |  | 672 |  |  | 90 |  |  |  |  |
| Other expenses | — |  |  | — |  |  | 241 |  |  |  |  |
| Controls remediation and litigation expenses | 1,326 |  |  | (163) |  |  | — |  |  |  |  |
| Adjustments to tax provision | (2,830) |  |  | (3,373) |  |  | (1,183) |  |  |  |  |
| NON-GAAP NET INCOME | $ | 31,401 |  |  | $ | 43,730 |  |  | $ | 30,797 |  |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.50 |  |  | $ | 0.78 |  |  | $ | 0.51 |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.12 |  |  | 0.09 |  |  | 0.08 |  |  |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.62 |  |  | $ | 0.87 |  |  | $ | 0.59 |  |  |  |  |

[0001375365-21-000078:8k_2_02:59]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000078:8k_2_02:60]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000078:8k_2_02:61]
(in thousands except per share amounts)

[0001375365-21-000078:8k_2_02:62]
(unaudited)

[0001375365-21-000078:8k_2_02:63]
|  | Three Months Ended |  |
|  | September 30, 2021 |  | June 30, 2021 |  | September 30, 2020 |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.48 |  |  | $ | 0.74 |  |  | $ | 0.49 |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.10 |  |  | 0.07 |  |  | 0.06 |  |  |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.58 |  |  | $ | 0.81 |  |  | $ | 0.55 |  |  |  |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 50,796 |  |  | 50,230 |  |  | 52,329 |  |  |  |  |
| BASIC - NON-GAAP | 50,796 |  |  | 50,230 |  |  | 52,329 |  |  |  |  |
| DILUTED – GAAP | 52,916 |  |  | 52,782 |  |  | 54,426 |  |  |  |  |
| DILUTED - NON-GAAP | 54,363 |  |  | 54,082 |  |  | 55,883 |  |  |  |  |
