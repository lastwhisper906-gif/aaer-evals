# SMCI MD&A — 0001375365-21-000083


## mdna

[0001375365-21-000083:mdna:1]
[same as prior period, unchanged from 0001375365-21-000034:mdna:1]

[0001375365-21-000083:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2021 (the “2021 10-K”), which includes our condensed consolidated financial statements for the fiscal years ended June 30, 2021 and 2020.

[0001375365-21-000083:mdna:3]
[same as prior period, unchanged from 0001375365-21-000034:mdna:3]

[0001375365-21-000083:mdna:4]
[same as prior period, unchanged from 0001375365-21-000034:mdna:4]

[0001375365-21-000083:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended September 30, 2021 decreased to $25.4 million from $26.6 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-21-000083:mdna:6]
[same as prior period, unchanged from 0001375365-21-000034:mdna:6]

[0001375365-21-000083:mdna:7]
[same as prior period, unchanged from 0001375365-21-000034:mdna:7]

[0001375365-21-000083:mdna:8]
[same as prior period, unchanged from 0001375365-21-000034:mdna:8]

[0001375365-21-000083:mdna:9]
[same as prior period, unchanged from 0001375365-21-000034:mdna:9]

[0001375365-21-000083:mdna:10]
Logistics has emerged as a new challenge as globally the transportation industry restricted the frequency of departures and increased logistics costs. We have experienced increased costs in freight as well as direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect this trend to continue for the duration of the COVID-19 pandemic.

[0001375365-21-000083:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or

[0001375365-21-000083:mdna:12]
geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage

[0001375365-21-000083:mdna:13]
our liquidity needs. In June 2021, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2026. In July 2021, we replaced our prior credit facility and term loan facility with CTBC Bank, with a new facility for omnibus credit lines. In September 2021, we replaced our prior credit facility with E.SUN Bank, with new credit facility and term facility. In September 2021, we entered into a term loan facility with Mega Bank which will be used to support our manufacturing activities (such as purchase of materials and components) and provide medium-term working capital. In October 2021, we entered into a credit facility with Chang Hwa Bank which will be used to support the growth of our Taiwan business. See “- Liquidity and Capital Resources – Other Factors Affecting Liquidity and Capital Resources.”

[0001375365-21-000083:mdna:14]
[same as prior period, unchanged from 0001375365-21-000034:mdna:12]

[0001375365-21-000083:mdna:15]
[same as prior period, unchanged from 0001375365-21-000034:mdna:13]

[0001375365-21-000083:mdna:16]
The following is a summary of our financial highlights of the first quarter of fiscal year 2022:

[0001375365-21-000083:mdna:17]
•Net sales increased by 35.5% in the three months ended September 30, 2021 as compared to the three months ended September 30, 2020.

[0001375365-21-000083:mdna:18]
•Gross margin decreased to 13.4% in the three months ended September 30, 2021 from 17.0% in the three months ended September 30, 2020.

[0001375365-21-000083:mdna:19]
•Operating expenses increased by 9.6% as compared to the three months ended September 30, 2020, and were equal to 10.6% and 13.0% of net sales in the three months ended September 30, 2021 and 2020, respectively.

[0001375365-21-000083:mdna:20]
•Effective tax rate decreased to 11.7% in the three months ended September 30, 2021 from 12.7% in the three months ended September 30, 2020.

[0001375365-21-000083:mdna:21]
[same as prior period, unchanged from 0001375365-21-000034:mdna:19]

[0001375365-21-000083:mdna:22]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses. We evaluate our estimates and assumptions on an ongoing basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for the judgments we make about the carrying value of assets and liabilities that are not readily apparent from other sources.  Because these estimates can vary depending on the situation, actual results may differ from these estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-21-000083:mdna:23]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2021 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Summary of Significant Accounting Policies" in our notes to condensed consolidated financial statements in this Quarterly Report.

[0001375365-21-000083:mdna:24]
[same as prior period, unchanged from 0001375365-21-000034:mdna:22]

[0001375365-21-000083:mdna:25]
[same as prior period, unchanged from 0001375365-21-000034:mdna:23]

[0001375365-21-000083:mdna:26]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 86.6 | % |  | 83.0 | % |  |  |  |  |
| Gross profit | 13.4 | % |  | 17.0 | % |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6.3 | % |  | 7.2 | % |  |  |  |  |
| Sales and marketing | 2.1 | % |  | 2.7 | % |  |  |  |  |
| General and administrative | 2.2 | % |  | 3.2 | % |  |  |  |  |
| Total operating expenses | 10.6 | % |  | 13.0 | % |  |  |  |  |
| Income from operations | 2.8 | % |  | 4.0 | % |  |  |  |  |
| Other (expense) income, net | — | % |  | (0.1) | % |  |  |  |  |
| Interest expense | (0.1) | % |  | (0.1) | % |  |  |  |  |
| Income before income tax provision | 2.7 | % |  | 3.8 | % |  |  |  |  |
| Income tax provision | (0.3) | % |  | (0.5) | % |  |  |  |  |
| Share of income from equity investee, net of taxes | — | % |  | 0.2 | % |  |  |  |  |
| Net income | 2.5 | % |  | 3.5 | % |  |  |  |  |

[0001375365-21-000083:mdna:27]
[same as prior period, unchanged from 0001375365-21-000034:mdna:25]

[0001375365-21-000083:mdna:28]
[same as prior period, unchanged from 0001375365-21-000034:mdna:26]

[0001375365-21-000083:mdna:29]
[same as prior period, unchanged from 0001375365-21-000034:mdna:27]

[0001375365-21-000083:mdna:30]
The following table presents net sales by product type for the three months ended September 30, 2021 and 2020 (dollars in millions):

[0001375365-21-000083:mdna:31]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849.9 |  |  | $ | 617.8 |  |  | $ | 232.1 |  |  | 37.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 82.3 | % |  | 81.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | $ | 182.9 |  |  | $ | 144.5 |  |  | $ | 38.4 |  |  | 26.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 17.7 | % |  | 19.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 1,032.7 |  |  | $ | 762.3 |  |  | $ | 270.4 |  |  | 35.5 | % |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:32]
[same as prior period, unchanged from 0001375365-21-000034:mdna:30]

[0001375365-21-000083:mdna:33]
Comparison of Three Months Ended September, 2021 and 2020

[0001375365-21-000083:mdna:34]
The period-over-period increase in net sales of our server and storage systems was due to a 25.5% increase in the number of units of compute nodes sold and a 11.8% increase in the average selling price. The increase in the number of units of compute nodes shipped was primarily due to more shipments of multinode systems compared to the same period last year.

[0001375365-21-000083:mdna:35]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the average selling price by 19.6% and an increase in number of units by 5.9%.

[0001375365-21-000083:mdna:36]
The following table presents net sales by geographic region for the three months ended September 30, 2021 and 2020 (dollars in millions):

[0001375365-21-000083:mdna:37]
|  | Three Months Ended September 30, |  | Change |  | Change |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| United States | $ | 560.9 |  |  | $ | 496.1 |  |  | $ | 64.8 |  |  | 13.1 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 54.3 | % |  | 65.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | 263.1 |  |  | 126.7 |  |  | 136.4 |  |  | 107.7 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 25.5 | % |  | 16.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe | 179.7 |  |  | 112.1 |  |  | 67.6 |  |  | 60.3 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 17.4 | % |  | 14.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | 29.0 |  |  | 27.3 |  |  | 1.7 |  |  | 6.2 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.8 | % |  | 3.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 1,032.7 |  |  | $ | 762.3 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:38]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:39]
The period-over-period increase in net sales in the United States for the three months ended September 30, 2021 and 2020 was primarily due to higher sales driven by higher server and storage systems unit volume combined with higher average selling price. The period-over-period increase in net sales in Asia was due primarily to increased sales in China, Taiwan, Japan, Korea and India, partially offset by decreased sales in Singapore. The increase of net sales in Europe was primarily due to higher sales in Germany, United Kingdom, France and Russia, partially offset by lower sales in the Netherlands. The period-over-period increase in net sales in other countries was primarily due to higher sales in Australia, Israel, UAE, Saudi Arabia, and South Africa, partially offset by decreased sales in Canada, Brazil, Mexico and New Zealand.

[0001375365-21-000083:mdna:40]
[same as prior period, unchanged from 0001375365-21-000034:mdna:44]

[0001375365-21-000083:mdna:41]
[same as prior period, unchanged from 0001375365-21-000034:mdna:45]

[0001375365-21-000083:mdna:42]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-21-000083:mdna:43]
Cost of sales and gross margin for the three months ended September 30, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000083:mdna:44]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Cost of sales | $ | 894.6 |  |  | $ | 632.3 |  |  | $ | 262.3 |  |  | 41.5 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 138.1 |  |  | $ | 129.9 |  |  | $ | 8.2 |  |  | 6.3 | % |  |  |  |  |  |  |  |  |
| Gross margin | 13.4 | % |  | 17.0 | % |  |  |  | (3.6) | % |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:45]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:46]
The period-over-period increase in cost of sales was primarily attributed to an increase of $236.8 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $15.0 million increase in freight charges, an increase in excess and obsolete inventory charges of $4.3 million, and a $10.0 million increase due to lower cost recovery of cost paid in prior periods offset by a decrease of $4.4 million in other overhead costs.

[0001375365-21-000083:mdna:47]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of sales. Since the start of the COVID-19 pandemic, we have experienced an increase in costs of sales, logistics costs as well as direct labor costs as we incentivize our employees. This increase in costs negatively impacts our gross margin, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-21-000083:mdna:48]
[same as prior period, unchanged from 0001375365-21-000034:mdna:55]

[0001375365-21-000083:mdna:49]
[same as prior period, unchanged from 0001375365-21-000034:mdna:56]

[0001375365-21-000083:mdna:50]
[same as prior period, unchanged from 0001375365-21-000034:mdna:57]

[0001375365-21-000083:mdna:51]
[same as prior period, unchanged from 0001375365-21-000034:mdna:58]

[0001375365-21-000083:mdna:52]
Operating expenses for the three months ended September 30, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000083:mdna:53]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Research and development | $ | 65.1 |  |  | $ | 54.8 |  |  | $ | 10.3 |  |  | 18.8 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 6.3 | % |  | 7.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 21.6 |  |  | $ | 20.3 |  |  | $ | 1.3 |  |  | 6.4 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.1 | % |  | 2.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 22.2 |  |  | $ | 24.4 |  |  | $ | (2.2) |  |  | (9.0) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.2 | % |  | 3.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 109.0 |  |  | $ | 99.5 |  |  | $ | 9.5 |  |  | 9.5 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 10.6 | % |  | 13.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:54]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:55]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $8.0 million increase in personnel expenses due to merit increases and higher headcount, a $0.9 million decrease in research and development credits from certain suppliers and customers towards our development efforts and a $0.8 million increase in product development costs.

[0001375365-21-000083:mdna:56]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $2.1 million increase in personnel expenses as a result of an increase in the number of personnel, partially offset by a decrease of $1.1 million in advertising and other expenses.

[0001375365-21-000083:mdna:57]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $1.6 million in professional fees driven by lower expenses incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements and a $0.6 million decrease in compensation expenses and other expenses.

[0001375365-21-000083:mdna:58]
Interest and Other Income (Expense), Net

[0001375365-21-000083:mdna:59]
Other income (expense), net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-21-000083:mdna:60]
Interest expense represents interest expense on our term loans and lines of credit and increased due to higher debt outstanding.

[0001375365-21-000083:mdna:61]
Interest and other income (expense), net for the three months ended September 30, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000083:mdna:62]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income (expense), net | $ | 0.1 |  |  | $ | (0.8) |  |  | $ | 0.9 |  |  | (112.5) | % |  |  |  |  |  |  |  |  |
| Interest expense | (0.8) |  |  | (0.7) |  |  | (0.1) |  |  | 14.3 | % |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | (0.7) |  |  | $ | (1.5) |  |  | $ | 0.8 |  |  | (53.3) | % |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:63]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:64]
The change of $0.9 million in other income (expense), net was attributable to an increase of $0.9 million in foreign exchange gain due to favorable foreign currency fluctuations.

[0001375365-21-000083:mdna:65]
[same as prior period, unchanged from 0001375365-21-000034:mdna:79]

[0001375365-21-000083:mdna:66]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock based compensation.

[0001375365-21-000083:mdna:67]
Provision for income taxes and effective tax rates for the three months ended September 30, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000083:mdna:68]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income tax provision | $ | 3.3 |  |  | $ | 3.7 |  |  | $ | (0.4) |  |  | (10.8) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 0.3 | % |  | 0.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective tax rate | 11.7 | % |  | 12.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:69]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:70]
The income tax provision and effective tax rate for the three months ended September 30, 2021 is lower than that for the three months ended September 30, 2020, primarily due to a decrease in certain non-deductible expenses and a decrease in foreign tax liabilities.

[0001375365-21-000083:mdna:71]
Share of Income from Equity Investee, Net of Taxes

[0001375365-21-000083:mdna:72]
Share of income from equity investee, net of taxes represents the Company’s share of income from the Corporate Venture in which the Company has 30% ownership.

[0001375365-21-000083:mdna:73]
Share of income from equity investee, net of taxes for the three months ended September 30, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000083:mdna:74]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2021 |  | 2020 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Share of income from equity investee, net of taxes | $ | 0.4 |  |  | $ | 1.3 |  |  | $ | (0.9) |  |  | (69.2)% |  |  |  |  |  |  |  |  |
| Percentage of total net sales | — | % |  | 0.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-21-000083:mdna:75]
Comparison of Three Months Ended September 30, 2021 and 2020

[0001375365-21-000083:mdna:76]
The period-over-period decrease of $0.9 million in share of income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-21-000083:mdna:77]
[same as prior period, unchanged from 0001375365-21-000034:mdna:95]

[0001375365-21-000083:mdna:78]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as an increase in the need for working capital due to longer supply chain manufacturing and delivery times. Our cash and cash equivalents were $270.0 million and $232.3 million as of September 30, 2021 and June 30, 2021, respectively. Our cash in foreign locations was $107.1 million and $152.6 million as of September 30, 2021 and June 30, 2021, respectively.

[0001375365-21-000083:mdna:79]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective, but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential

[0001375365-21-000083:mdna:80]
taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-21-000083:mdna:81]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses, and maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements. We expect to pay a special performance bonus of approximately $2.0 million to our CEO in the fiscal year 2022.

[0001375365-21-000083:mdna:82]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. The Company had $150.0 million of remaining availability under the share repurchase program as of September 30, 2021.

[0001375365-21-000083:mdna:83]
[same as prior period, unchanged from 0001375365-21-000034:mdna:102]

[0001375365-21-000083:mdna:84]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (134.6) |  |  | $ | 120.6 |  |  | $ | (255.2) |  |  |  |  |
| Net cash used in investing activities | $ | (11.9) |  |  | $ | (11.9) |  |  | $ | — |  |  |  |  |
| Net cash provided by (used in) financing activities | $ | 184.3 |  |  | $ | (19.3) |  |  | $ | 203.6 |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 37.8 |  |  | $ | 89.6 |  |  | $ | (51.8) |  |  |  |  |

[0001375365-21-000083:mdna:85]
[same as prior period, unchanged from 0001375365-21-000034:mdna:104]

[0001375365-21-000083:mdna:86]
Net cash provided by operating activities decreased by $255.2 million for the three months ended September 30, 2021 as compared to the three months ended September 30, 2020. The decrease was primarily due to an increase in net cash required for net working capital of $259.6 million to meet customer demand, support expected business growth and mitigate supply chain risk due to the COVID-19 pandemic environment and a $1.2 million decrease in net income. These decreases are partially offset by increases in the non-cash charges, including a $4.4 million increase related to excess and obsolete inventories and $1.0 million related to share of income from our equity investee.

[0001375365-21-000083:mdna:87]
[same as prior period, unchanged from 0001375365-21-000034:mdna:106]

[0001375365-21-000083:mdna:88]
Net cash used in investing activities was $11.9 million for both the three months ended September 30, 2021 and 2020, as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-21-000083:mdna:89]
[same as prior period, unchanged from 0001375365-21-000034:mdna:108]

[0001375365-21-000083:mdna:90]
Net cash provided by financing activities for the three months ended September 30, 2021 was $184.3 million while net cash used by financing activities for the three months ended September 30, 2020 was $19.3 million. The change in cash flows from financing activities was primarily due to an increase of $174.2 million in proceeds from borrowings net of repayment, offset by a $28.5 million decrease in stock repurchases and an increase in cash receipts from exercises of stock options of $1.0 million.

[0001375365-21-000083:mdna:91]
[same as prior period, unchanged from 0001375365-21-000034:mdna:110]

[0001375365-21-000083:mdna:92]
2018 Bank of America Credit Facility

[0001375365-21-000083:mdna:93]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility").  In June 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026 and reduce the size of the facility from $250.0 million to $200.0 million. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum. As of September 30, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $110.2 million and the interest rate was 1.50%. Our available borrowing capacity was $89.8 million, subject to the borrowing base limitation and compliance with other applicable terms. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-21-000083:mdna:94]
CTBC Credit Lines

[0001375365-21-000083:mdna:95]
We through our Taiwan subsidiary were party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank, which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”). On July 20, 2021 (the “Effective Date”), we through our Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalents) to use to purchase machinery and equipment for our Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

[0001375365-21-000083:mdna:96]
As of September 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.0 million and the interest rates for these loans were 0.45% per annum. Under the 2021 CTBC Machine Loan, the amounts outstanding were $1.4 million and the interest rates for these loans were 0.65% per annum at September 30, 2021. As of September 30, 2021, the total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.2 million and the interest rate for these loans were 0.74% per annum.  As of September 30, 2021, the outstanding borrowings of 2021 CTBC Credit Facility revolving line of credit were $68.1 million and the interest rates for these loans ranged from approximately 0.94% to 0.95% per annum. The amount available for future borrowing under the 2021 CTBC Credit Facility was $11.7 million as of September 30, 2021. The net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million and all financial covenants were satisfied under the 2021 CTBC Credit Lines as of September 30, 2021.

[0001375365-21-000083:mdna:97]
2021 E.SUN Bank Credit Facility

[0001375365-21-000083:mdna:98]
We through our Taiwan subsidiary were party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank, which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility was until September 18, 2021. On September 13, 2021 (the “E.SUN Bank Effective Date”), we through our Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57 million U.S. dollar equivalent) in financing for use in research & development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of September 30, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $4.9 million and the interest rates for these loans were 0.995% per annum. As of September 30, 2021, the amounts outstanding under the Import Loan were $30.0 million and the interest rates for these loans ranged approximately from 0.96% to 1.23% per annum. At September 30, 2021, the amount available for future borrowing under the Import Loan was $0.0 million.

[0001375365-21-000083:mdna:99]
Mega Bank Credit Facilities

[0001375365-21-000083:mdna:100]
On September 13, 2021 (the “Mega Bank Effective Date”), we through our Taiwan subsidiary entered into a NTD1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, range from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of September 30, 2021, there were no outstanding borrowings under the Mega Bank Credit Facility.

[0001375365-21-000083:mdna:101]
Chang Hwa Bank Credit Facility

[0001375365-21-000083:mdna:102]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), we through our Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility, which is being used to support our growth, permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent) including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting the Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the Company's other debt obligations. Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants. Under the Chang Hwa Bank Credit Facility, the Chang Hwa Bank has the right to demand collateral for debts owed.

[0001375365-21-000083:mdna:103]
Refer to Part I, Item 1, Note 7, “Short-term and Long-term Debt,” in our notes to condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding debt.

[0001375365-21-000083:mdna:104]
Capital Expenditure Requirements

[0001375365-21-000083:mdna:105]
We intend to continue to focus our capital expenditures in fiscal year 2022 to support the growth of our operations. We anticipate our capital expenditures for the remainder of fiscal year 2022 will be approximately $11 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our information systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-21-000083:mdna:106]
[same as prior period, unchanged from 0001375365-21-000034:mdna:122]

[0001375365-21-000083:mdna:107]
[same as prior period, unchanged from 0001375365-21-000034:mdna:123]

[0001375365-21-000083:mdna:108]
42
