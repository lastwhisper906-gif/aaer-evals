# SMCI note change history — 0001375365-21-000034 → 0001375365-21-000083


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:1]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021, and the Court has calendared the hearing for January 26, 2022. The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously.
  (was, 2021-05-07, similarity 0.66):
[0001375365-21-000034:note_history:1]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.  The parties are in the process of briefing demurrers, which are set for hearing on August 24, 2021. The case is otherwise stayed for the time being. The Company intends to defend the lawsuit vigorously.

- added (2021-11-05):
[0001375365-21-000083:note_history:2]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice.  On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval.  On October 27, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval.  The Court noted that, if no shareholder seeks to intervene during the notice period, plaintiff may file an administrative motion requesting that the Court dismiss the lawsuit with prejudice

- changed (2021-11-05):
[0001375365-21-000083:note_history:3]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.
  (was, 2021-05-07, similarity 0.8707):
[0001375365-21-000034:note_history:3]
article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

- changed (2021-11-05):
[0001375365-21-000083:note_history:4]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2021 and any prior periods.
  (was, 2021-05-07, similarity 0.9785):
[0001375365-21-000034:note_history:4]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2021 and any prior periods.

- added (2021-11-05):
[0001375365-21-000083:note_history:5]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

- changed (2021-11-05):
[0001375365-21-000083:note_history:6]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.
  (was, 2021-05-07, similarity 0.9201):
[0001375365-21-000034:note_history:6]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

- changed (2021-11-05):
[0001375365-21-000083:note_history:7]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2021, these remaining noncancelable commitments were $508.2 million, including $124.4 million for related parties.
  (was, 2021-05-07, similarity 0.848):
[0001375365-21-000034:note_history:7]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2021, these remaining noncancelable commitments were $306.4 million, including $79.5 million for related parties.

- added (2021-11-05):
[0001375365-21-000083:note_history:8]
Lease Commitments - See Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.

- removed (2021-11-05):
[0001375365-21-000034:note_history:9]
On November 13, 2020, Build Group Inc. (“Build Group”) filed a complaint against the Company in the Superior Court for Santa Clara County, seeking damages of approximately $2.0 million.  Build Group served the complaint on the Company on December 1, 2020.  Build Group alleged that the Company breached the construction contract between the Company and Build Group by failing to approve or reject certain requests for change orders to the scope of work covered by the construction project in a timely manner, or at all. A substantial portion of the amounts covered by the change orders at issue related to delays in the construction project.  Build Group asserted that these delays were beyond its control and that therefore it was entitled to additional payments as a result of the delays in completion of the project.  The Company believed that it had meritorious defenses to Build Group’s claims, but nonetheless negotiated a settlement with Build Group. The settlement agreement resolving this dispute was executed effective January 19, 2021. As a result, the Company did not have to respond to the complaint. Per the settlement agreement, Build Group agreed to dismiss the entire action with prejudice once the Company complied with its obligations under the settlement agreement. The Company complied with its obligations and paid $2.0 million in the quarter ended March 31, 2021. Build Group submitted the dismissal, which the court has granted that concludes the matter.

- removed (2021-11-05):
[0001375365-21-000034:note_history:10]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news

- removed (2021-11-05):
[0001375365-21-000034:note_history:11]
Standby Letter of Credit— In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:12]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 27, 2021, for the year ended June 30, 2021. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.
  (was, 2021-05-07, similarity 0.998):
[0001375365-21-000034:note_history:12]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies", in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.

- changed (2021-11-05):
[0001375365-21-000083:note_history:13]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2022.
  (was, 2021-05-07, similarity 0.7174):
[0001375365-21-000034:note_history:13]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.

- changed (2021-11-05):
[0001375365-21-000083:note_history:14]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 22.0% of total purchases for the three months ended September 30, 2021 and 2020, respectively. Purchases from Ablecom, and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 9.6% and 9.2% of total cost of sales for the three months ended September 30, 2021 and 2020, respectively.
  (was, 2021-05-07, similarity 0.7951):
[0001375365-21-000034:note_history:14]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 21.4% and 26.1% of total purchases for the three months ended March 31, 2021 and 2020, respectively, and 21.1% and 27.9% for the nine months ended March 31, 2021 and 2020, respectively. Purchases from Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 8.4% and 9.4% of total cost of sales for the three months ended March 31, 2021 and 2020, respectively, and a combined 8.5% and 9.8% for the nine months ended March 31, 2021 and 2020, respectively.

- changed (2021-11-05):
[0001375365-21-000083:note_history:15]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021 and 2020. One customer accounted for 11.7% and 13.5% of accounts receivable, net as of September 30, 2021 and June 30, 2021, respectively.
  (was, 2021-05-07, similarity 0.7778):
[0001375365-21-000034:note_history:15]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2021 and 2020. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2021, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.

- changed (2021-11-05):
[0001375365-21-000083:note_history:16]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021. The adoption of the guidance did not have a material impact on its condensed consolidated financial statements and disclosures.
  (was, 2021-05-07, similarity 0.8825):
[0001375365-21-000034:note_history:16]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its condensed consolidated financial statements and disclosures.

- changed (2021-11-05):
[0001375365-21-000083:note_history:17]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 which provided for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. As the amendment had changes not related to LIBOR replacement, optional expedients under this guidance cannot be elected. The E.SUN Credit Facility will terminate on July 29, 2022 before the phase out of LIBOR. Therefore, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.
  (was, 2021-05-07, similarity 0.7275):
[0001375365-21-000034:note_history:17]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 and E.SUN Credit Facility will terminate on September 18, 2021. As both credit facilities will expire before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its condensed consolidated financial statements and disclosures.

- removed (2021-11-05):
[0001375365-21-000034:note_history:18]
Investment in a Corporate Venture

- removed (2021-11-05):
[0001375365-21-000034:note_history:19]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- removed (2021-11-05):
[0001375365-21-000034:note_history:20]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of March 31, 2021 and June 30, 2020, the Company had unamortized deferred gain balance of $1.5 million and $2.0 million, respectively, in accrued liabilities and $0.0 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed

- removed (2021-11-05):
[0001375365-21-000034:note_history:21]
consolidated balance sheets.

- removed (2021-11-05):
[0001375365-21-000034:note_history:22]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with

- removed (2021-11-05):
[0001375365-21-000034:note_history:23]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of March 31, 2021. No impairment charge was recorded for the three and nine months ended March 31, 2021 and 2020, respectively.

- removed (2021-11-05):
[0001375365-21-000034:note_history:24]
The Company sold products worth $16.8 million and $14.0 million to the Corporate Venture in the three months ended March 31, 2021 and 2020, respectively, and $36.4 million and $51.5 million for the nine months ended March 31, 2021 and 2020, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2021 and June 30, 2020 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $11.4 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of March 31, 2021 and June 30, 2020, respectively.

- removed (2021-11-05):
[0001375365-21-000034:note_history:25]
Treasury Stock

- removed (2021-11-05):
[0001375365-21-000034:note_history:26]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

- removed (2021-11-05):
[0001375365-21-000034:note_history:27]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments. Under this new guidance, a company is required to estimate credit losses on certain types of financial instruments using an expected-loss model, replacing the current incurred-loss model, and record the estimate through an allowance for credit losses, which results in more timely recognition of credit losses. The Company adopted this guidance on July 1, 2020 using the modified retrospective transition method, which requires a cumulative-effect adjustment, if any, to the opening balance of retained earnings to be recognized on the date of adoption with prior periods not restated. The adoption of the guidance had no material impact on the Company’s condensed consolidated financial statements as of July 1, 2020.

- removed (2021-11-05):
[0001375365-21-000034:note_history:28]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three and nine months ended March 31, 2021.

- removed (2021-11-05):
[0001375365-21-000034:note_history:29]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of March 31, 2021, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial. See Note 5, "Fair Value Disclosure".

- removed (2021-11-05):
[0001375365-21-000034:note_history:30]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of

- removed (2021-11-05):
[0001375365-21-000034:note_history:31]
a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:32]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2021 and June 30, 2021 consisted of the following (in thousands):
  (was, 2021-05-07, similarity 0.913):
[0001375365-21-000034:note_history:32]
Short-term and Long-term Debt
    Short-term debt obligations as of March 31, 2021 and June 30, 2020 consisted of the following (in thousands):

- changed (2021-11-05):
[0001375365-21-000083:note_history:33]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 110,193 |  |  | $ | — |  |
| CTBC Bank | 68,100 |  |  | 18,000 |  |
| E.SUN Bank | 30,000 |  |  | 20,400 |  |
| Total line of credit | 208,293 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | 25,195 |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,018 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 1,434 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 4,868 |  |  | — |  |
| Total term loans | 70,515 |  |  | 59,790 |  |
| Total debt | 278,808 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 233,674 |  |  | 63,490 |  |
| Debt, Non-current | $ | 45,134 |  |  | $ | 34,700 |  |
  (was, 2021-05-07, similarity 0.8429):
[0001375365-21-000034:note_history:33]
|  | March 31, |  | June 30, |
|  | 2021 |  | 2020 |
| Line of credit: |  |  |  |
| CTBC Bank | $ | 18,000 |  |  | $ | — |  |
| E.SUN Bank | 15,000 |  |  | — |  |
| Total line of credit | 33,000 |  |  | — |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,503 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 27,867 |  |  | 5,697 |  |
| Total term loans | 52,370 |  |  | 29,401 |  |
| Total debt | 85,370 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 57,503 |  |  | 23,704 |  |
| Debt, Non-current | $ | 27,867 |  |  | $ | 5,697 |  |

- added (2021-11-05):
[0001375365-21-000083:note_history:34]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million, increase the maximum amount that the Company can request the facility be increased from $100.0 million to $150.0 million, and update provisions relating to erroneous payments and LIBOR replacement mechanics. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

- added (2021-11-05):
[0001375365-21-000083:note_history:35]
As of September 30, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $110.2 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2021 and June 30, 2021 were 1.50%. The balance of debt issuance costs outstanding as of September 30, 2021 and June 30, 2021 were $0.5 million. The

- added (2021-11-05):
[0001375365-21-000083:note_history:36]
Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2021, the Company's available borrowing capacity was $89.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2021-11-05):
[0001375365-21-000083:note_history:37]
2021 CTBC Credit Lines
  (was, 2021-05-07, similarity 0.7179):
[0001375365-21-000034:note_history:37]
CTBC Credit Facility

- added (2021-11-05):
[0001375365-21-000083:note_history:38]
The Company through its Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

- added (2021-11-05):
[0001375365-21-000083:note_history:39]
On July 20, 2021 (the “Effective Date”), the Company through its Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million  U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million  U.S. dollar equivalents) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

- added (2021-11-05):
[0001375365-21-000083:note_history:40]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

- added (2021-11-05):
[0001375365-21-000083:note_history:41]
As of September 30, 2021 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.0 million and $34.7 million, respectively. The interest rates for these loans were 0.45% per annum as of September 30, 2021 and June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $1.4 million at September 30, 2021. The interest rates for these loans were 0.65% per annum as of September 30, 2021. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

- added (2021-11-05):
[0001375365-21-000083:note_history:42]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.2 million and $25.1 million at September 30, 2021 and June 30, 2021, respectively. The interest rate for these loans were 0.74% and 0.75% per annum as of September 30, 2021 and June 30, 2021, respectively.  As of September 30, 2021, and June 30, 2021, the outstanding borrowings of 2021 CTBC Credit Facility revolving line of credit were $68.1 million and $18.0 million, respectively. The interest rates for these loans ranged from approximately 0.94% to 0.95% per annum as of September 30, 2021. The interest rate was 0.98% per annum as of June 30, 2021. As of September 30, 2021, the amount available for future borrowing under the 2021 CTBC Credit Facility was $11.7 million. As of September 30, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million. As of September 30, 2021, all financial covenants under the 2021 CTBC Credit Lines were satisfied.

- added (2021-11-05):
[0001375365-21-000083:note_history:43]
E.SUN Bank

- changed (2021-11-05):
[0001375365-21-000083:note_history:44]
2021 E.SUN Bank Credit Facility
  (was, 2021-05-07, similarity 0.963):
[0001375365-21-000034:note_history:44]
E.SUN Bank Credit Facility

- added (2021-11-05):
[0001375365-21-000083:note_history:45]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility was until September 18, 2021.

- added (2021-11-05):
[0001375365-21-000083:note_history:46]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements.

- added (2021-11-05):
[0001375365-21-000083:note_history:47]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and  development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of September 30, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $4.9 million and the interest rates for these loans were 0.995% per annum. As of September 30, 2021 and June 30, 2021, the amounts outstanding under the Import Loan were $30.0 and $20.4 million, respectively. The interest rates for these loans ranged approximately from 0.96% to 1.23% and 1.00% to 1.29% per annum as of September 30, 2021 and June 30, 2021, respectively. At September 30, 2021, the amount available for future borrowing under the Import Loan was $0.0 million and all financial covenants under the 2021 E.SUN Bank Credit Facility were satisfied.

- added (2021-11-05):
[0001375365-21-000083:note_history:48]
Mega Bank

- added (2021-11-05):
[0001375365-21-000083:note_history:49]
Mega Bank Credit Facilities

- added (2021-11-05):
[0001375365-21-000083:note_history:50]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of September 30, 2021, there were no outstanding borrowings under the Mega Bank Credit Facility.

- added (2021-11-05):
[0001375365-21-000083:note_history:51]
Chang Hwa Bank

- added (2021-11-05):
[0001375365-21-000083:note_history:52]
Chang Hwa Bank Credit Facility

- added (2021-11-05):
[0001375365-21-000083:note_history:53]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments.  The Chang Hwa Bank Credit Facility has customary default provisions permitting the Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed.

- added (2021-11-05):
[0001375365-21-000083:note_history:54]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants.

- added (2021-11-05):
[0001375365-21-000083:note_history:55]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:56]
Fiscal Year:                                                                                                               Principal Payments

- added (2021-11-05):
[0001375365-21-000083:note_history:57]
| 2022 | $ | 233,594 |  |
| 2023 | 1,696 |  |
| 2024 | 7,110 |  |
| 2025 | 7,110 |  |
| 2026 | 7,110 |  |
| 2027 and thereafter | 22,188 |  |
| Total short-term and long-term debt | $ | 278,808 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:58]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 30, 2021 and provide that in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. The amendment was accounted for as a modification and the impact was immaterial to the condensed consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

- removed (2021-11-05):
[0001375365-21-000034:note_history:59]
As of March 31, 2021 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2021 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.2 million and $0.6 million as of March 31, 2021 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of March 31, 2021, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- removed (2021-11-05):
[0001375365-21-000034:note_history:60]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. In February 2021, CTBC Bank amended the USD interest rate to be the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

- removed (2021-11-05):
[0001375365-21-000034:note_history:61]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.5 million and $23.7 million at March 31, 2021 and June 30, 2020, respectively. The interest rate for these loans were 0.74% per annum as of March 31, 2021 and 0.63% per annum as of June 30, 2020. As of March 31, 2021 and June 30, 2020, the outstanding borrowings under the CTBC Credit Facility revolving line of credit were $18.0 million and $0.0 million, respectively. The interest rates were from 1.03% to 1.26% per annum as of March 31, 2021. As of March 31, 2021, the amount available for future borrowing under the CTBC Credit Facility was $7.5 million. As of March 31, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.0 million.

- removed (2021-11-05):
[0001375365-21-000034:note_history:62]
2020 CTBC Term Loan Facility due June 4, 2030

- removed (2021-11-05):
[0001375365-21-000034:note_history:63]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

- removed (2021-11-05):
[0001375365-21-000034:note_history:64]
As of March 31, 2021 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $27.9 million and $5.7 million, respectively. The interest rates for these loans were 0.45% per annum as of March 31, 2021 and June 30, 2020. The net book value of the property serving as collateral as of March 31, 2021 was $38.1 million. As of March 31, 2021, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

- removed (2021-11-05):
[0001375365-21-000034:note_history:65]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. Such Credit Facility provides for the issuance of

- removed (2021-11-05):
[0001375365-21-000034:note_history:66]
loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. The term of the E.SUN Credit Facility expires on September 18, 2021.

- removed (2021-11-05):
[0001375365-21-000034:note_history:67]
Generally, the interest for base rate loans made under the E.SUN Credit Facility is based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment.  Interest for adjustable loan rate loans made under the E.SUN Credit Facility is based upon an average one-year fixed rate time saving deposit rate of a selected reference bank which shall be a well-known domestic bank in Taiwan, and is subject to occasional adjustment. The E.SUN Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event such Taiwan subsidiary of the Company has an overdue liability at another financial organization. There are no financial covenants associated with the E.SUN Credit Facility.

- removed (2021-11-05):
[0001375365-21-000034:note_history:68]
Terms for specific drawdown instruments issued under the E.SUN Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions negotiated with E.SUN Bank. A Notification and Confirmation of Credit Conditions agreement under the E.SUN Credit Facility was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days and with an interest rate calculated based on the higher of LIBOR plus 0.75% then divided by 0.946 or TAIFX plus 0.55% then divided by 0.946. As of March 31, 2021, the amounts outstanding under the E.SUN Credit Facility were  $15.0 million and the interest rates for these loans were approximately 1.0% per annum. At March 31, 2021, the amount available for future borrowing under the E.SUN Credit Facility was $15.0 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:69]
Short-term and long-term debt obligations as of September 30, 2021 and June 30, 2021 consisted of the following (in thousands):
  (was, 2021-05-07, similarity 0.8889):
[0001375365-21-000034:note_history:69]
Short-term debt obligations as of March 31, 2021 and June 30, 2020 consisted of the following (in thousands):

- changed (2021-11-05):
[0001375365-21-000083:note_history:70]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 110,193 |  |  | $ | — |  |
| CTBC Bank | 68,100 |  |  | 18,000 |  |
| E.SUN Bank | 30,000 |  |  | 20,400 |  |
| Total line of credit | 208,293 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | 25,195 |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,018 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 1,434 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 4,868 |  |  | — |  |
| Total term loans | 70,515 |  |  | 59,790 |  |
| Total debt | 278,808 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 233,674 |  |  | 63,490 |  |
| Debt, Non-current | $ | 45,134 |  |  | $ | 34,700 |  |
  (was, 2021-05-07, similarity 0.8429):
[0001375365-21-000034:note_history:70]
|  | March 31, |  | June 30, |
|  | 2021 |  | 2020 |
| Line of credit: |  |  |  |
| CTBC Bank | $ | 18,000 |  |  | $ | — |  |
| E.SUN Bank | 15,000 |  |  | — |  |
| Total line of credit | 33,000 |  |  | — |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,503 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 27,867 |  |  | 5,697 |  |
| Total term loans | 52,370 |  |  | 29,401 |  |
| Total debt | 85,370 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 57,503 |  |  | 23,704 |  |
| Debt, Non-current | $ | 27,867 |  |  | $ | 5,697 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-05):
[0001375365-21-000083:note_history:71]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:72]
Fiscal Year:                                                                                                               Principal Payments

- added (2021-11-05):
[0001375365-21-000083:note_history:73]
| 2022 | $ | 233,594 |  |
| 2023 | 1,696 |  |
| 2024 | 7,110 |  |
| 2025 | 7,110 |  |
| 2026 | 7,110 |  |
| 2027 and thereafter | 22,188 |  |
| Total short-term and long-term debt | $ | 278,808 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:74]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2021-05-07, similarity 0.9785):
[0001375365-21-000034:note_history:74]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- changed (2021-11-05):
[0001375365-21-000083:note_history:75]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.5% and 93.6% of the chassis included in the products sold by the Company during the three months ended September 30, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2021-05-07, similarity 0.9188):
[0001375365-21-000034:note_history:75]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.5% and 95.1% of the chassis included in the products sold by the Company during the three months ended March 31, 2021 and 2020, respectively, and 92.5% and 95.3% of the chassis included in the products sold by the Company during the nine months ended March 31, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2021-11-05):
[0001375365-21-000083:note_history:76]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.
  (was, 2021-05-07, similarity 0.6919):
[0001375365-21-000034:note_history:76]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the

- changed (2021-11-05):
[0001375365-21-000083:note_history:77]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $36.7 million and $40.2 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2021-05-07, similarity 0.9832):
[0001375365-21-000034:note_history:77]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $35.5 million and $23.2 million at March 31, 2021 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- added (2021-11-05):
[0001375365-21-000083:note_history:78]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

- changed (2021-11-05):
[0001375365-21-000083:note_history:79]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $87.8 million and $71.0 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2021-05-07, similarity 0.6358):
[0001375365-21-000034:note_history:79]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $44.0 million and $45.7 million at March 31, 2021 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- added (2021-11-05):
[0001375365-21-000083:note_history:80]
Dealings with Investment in a Corporate Venture

- added (2021-11-05):
[0001375365-21-000083:note_history:81]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- added (2021-11-05):
[0001375365-21-000083:note_history:82]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2021 and June 30, 2021, the Company had unamortized deferred gain balance of $0.5 million and $1.0 million, respectively, in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- added (2021-11-05):
[0001375365-21-000083:note_history:83]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of the third party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2021. No impairment charge was recorded for the three months ended September 30, 2021 and 2020, respectively.

- added (2021-11-05):
[0001375365-21-000083:note_history:84]
The Company sold products to the Corporate Venture and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities.

- added (2021-11-05):
[0001375365-21-000083:note_history:85]
Dealings with Monolithic Power Systems, Inc.

- added (2021-11-05):
[0001375365-21-000083:note_history:86]
The Company procures certain semiconductor products from Monolithic Power Systems, Inc. (“MPS”), a fabless manufacturer of high-performance analog and mixed-signal semiconductors, for use in its products. A member on the Board of Directors, also serves as an officer of MPS.

- changed (2021-11-05):
[0001375365-21-000083:note_history:87]
The Company had the following balances related to transactions with its related parties as of September 30, 2021 and June 30, 2021 (in thousands):
  (was, 2021-05-07, similarity 0.837):
[0001375365-21-000034:note_history:87]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2021 and June 30, 2020 (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:88]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 1,332 |  | $ | 198 |  | $ | 12,659 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 13,993 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,428 |  | $ | 5,575 |  | $ | 21,690 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 165 |  | $ | 89 |  | $ | 26,283 |  | $ | 23,837 |  |
| Accounts payable | $ | 40,730 |  | $ | 38,152 |  | $ | 37,024 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 77,754 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 1,813 |  | $ | 3,042 |  | $ | 17,790 |  | $ | 14,486 |  | $ | 500 |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,103 |  | $ | 18,528 |  |

- added (2021-11-05):
[0001375365-21-000083:note_history:89]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

- changed (2021-11-05):
[0001375365-21-000083:note_history:90]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):
  (was, 2021-05-07, similarity 0.8208):
[0001375365-21-000034:note_history:90]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2021 and 2020, are as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:91]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 7 |  | $ | 5 |  | $ | 15,702 |  | $ | 13,299 |  | $ | 15,213 |  | $ | 6,412 |  | — |  | — |  | $ | 30,922 |  | $ | 19,716 |  |
| Purchases - inventory | $ | 50,788 |  | $ | 23,871 |  | $ | 35,229 |  | $ | 34,197 |  | — |  | — |  | $ | 1,670 |  | $ | 791 |  | $ | 87,687 |  | $ | 58,859 |  |
| Purchases - other miscellaneous items | $ | 2,116 |  | $ | 2,718 |  | $ | 339 |  | $ | 333 |  | — |  | — |  | — |  | — |  | $ | 2,455 |  | $ | 3,051 |  |

- added (2021-11-05):
[0001375365-21-000083:note_history:92]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:93]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | — |  | $ | (27) |  | $ | (1,134) |  | $ | 353 |  | $ | (4,181) |  | $ | 7,184 |  | — |  | — |  | $ | (5,315) |  | $ | 7,510 |  |
| Changes in other receivable | $ | 1,147 |  | $ | 4,243 |  | $ | (3,517) |  | $ | 7,840 |  | — |  | — |  | $ | (76) |  | $ | 75 |  | $ | (2,446) |  | $ | 12,158 |  |
| Changes in accounts payable | $ | 2,578 |  | $ | (14,952) |  | $ | 5,080 |  | $ | (9,724) |  | — |  | — |  | — |  | — |  | $ | 7,658 |  | $ | (24,676) |  |
| Changes in accrued liabilities | $ | (1,229) |  | $ | (203) |  | $ | 3,304 |  | $ | (3,374) |  | $ | (500) |  | — |  | — |  | — |  | $ | 1,575 |  | $ | (3,577) |  |
| Changes in other long-term liabilities | — |  | $ | 47 |  | — |  | $ | (77) |  | — |  | $ | (500) |  | — |  | — |  | — |  | $ | (530) |  |
| Purchases of property, plant and equipment | $ | 338 |  | $ | 2,140 |  | $ | 62 |  | $ | 90 |  | — |  | — |  | — |  | — |  | $ | 400 |  | $ | 2,230 |  |
| Unpaid property, plant and equipment | $ | 1,360 |  | $ | 1,664 |  | — |  | — |  | — |  | — |  | — |  | — |  | $ | 1,360 |  | $ | 1,664 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:94]
Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- removed (2021-11-05):
[0001375365-21-000034:note_history:95]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

- removed (2021-11-05):
[0001375365-21-000034:note_history:96]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 34,924 |  |  | $ | 37,607 |  |  | $ | 85,827 |  |  | $ | 115,295 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,580 |  |  | $ | 7,503 |  |  | $ | 22,451 |  |  | $ | 19,456 |  |
| Purchases (1) | 32,340 |  |  | 24,908 |  |  | 100,911 |  |  | 91,662 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:97]
__________________________

- removed (2021-11-05):
[0001375365-21-000034:note_history:98]
(1) Includes principally purchases of inventory and other miscellaneous items.

- removed (2021-11-05):
[0001375365-21-000034:note_history:99]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2021 and 2020.

- removed (2021-11-05):
[0001375365-21-000034:note_history:100]
|  | March 31, 2021 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,620 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 32,243 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 14,486 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 36,355 |  |  | 46,518 |  |
| Other long-term liabilities (3) | — |  |  | 186 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:101]
____________________________

- removed (2021-11-05):
[0001375365-21-000034:note_history:102]
(1) Other receivables include receivables from vendors.

- removed (2021-11-05):
[0001375365-21-000034:note_history:103]
(2) Includes current portion of operating lease liabilities.

- removed (2021-11-05):
[0001375365-21-000034:note_history:104]
(3) Represents non-current portion of operating lease liabilities.

- removed (2021-11-05):
[0001375365-21-000034:note_history:105]
See Note 1, "Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:106]
The Company had the following balances related to transactions with its related parties as of September 30, 2021 and June 30, 2021 (in thousands):
  (was, 2021-05-07, similarity 0.837):
[0001375365-21-000034:note_history:106]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2021 and June 30, 2020 (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:107]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 1,332 |  | $ | 198 |  | $ | 12,659 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 13,993 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,428 |  | $ | 5,575 |  | $ | 21,690 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 165 |  | $ | 89 |  | $ | 26,283 |  | $ | 23,837 |  |
| Accounts payable | $ | 40,730 |  | $ | 38,152 |  | $ | 37,024 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 77,754 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 1,813 |  | $ | 3,042 |  | $ | 17,790 |  | $ | 14,486 |  | $ | 500 |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,103 |  | $ | 18,528 |  |

- added (2021-11-05):
[0001375365-21-000083:note_history:108]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

- changed (2021-11-05):
[0001375365-21-000083:note_history:109]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):
  (was, 2021-05-07, similarity 0.8208):
[0001375365-21-000034:note_history:109]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2021 and 2020, are as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:110]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 7 |  | $ | 5 |  | $ | 15,702 |  | $ | 13,299 |  | $ | 15,213 |  | $ | 6,412 |  | — |  | — |  | $ | 30,922 |  | $ | 19,716 |  |
| Purchases - inventory | $ | 50,788 |  | $ | 23,871 |  | $ | 35,229 |  | $ | 34,197 |  | — |  | — |  | $ | 1,670 |  | $ | 791 |  | $ | 87,687 |  | $ | 58,859 |  |
| Purchases - other miscellaneous items | $ | 2,116 |  | $ | 2,718 |  | $ | 339 |  | $ | 333 |  | — |  | — |  | — |  | — |  | $ | 2,455 |  | $ | 3,051 |  |

- added (2021-11-05):
[0001375365-21-000083:note_history:111]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:112]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | — |  | $ | (27) |  | $ | (1,134) |  | $ | 353 |  | $ | (4,181) |  | $ | 7,184 |  | — |  | — |  | $ | (5,315) |  | $ | 7,510 |  |
| Changes in other receivable | $ | 1,147 |  | $ | 4,243 |  | $ | (3,517) |  | $ | 7,840 |  | — |  | — |  | $ | (76) |  | $ | 75 |  | $ | (2,446) |  | $ | 12,158 |  |
| Changes in accounts payable | $ | 2,578 |  | $ | (14,952) |  | $ | 5,080 |  | $ | (9,724) |  | — |  | — |  | — |  | — |  | $ | 7,658 |  | $ | (24,676) |  |
| Changes in accrued liabilities | $ | (1,229) |  | $ | (203) |  | $ | 3,304 |  | $ | (3,374) |  | $ | (500) |  | — |  | — |  | — |  | $ | 1,575 |  | $ | (3,577) |  |
| Changes in other long-term liabilities | — |  | $ | 47 |  | — |  | $ | (77) |  | — |  | $ | (500) |  | — |  | — |  | — |  | $ | (530) |  |
| Purchases of property, plant and equipment | $ | 338 |  | $ | 2,140 |  | $ | 62 |  | $ | 90 |  | — |  | — |  | — |  | — |  | $ | 400 |  | $ | 2,230 |  |
| Unpaid property, plant and equipment | $ | 1,360 |  | $ | 1,664 |  | — |  | — |  | — |  | — |  | — |  | — |  | $ | 1,360 |  | $ | 1,664 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:113]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 34,924 |  |  | $ | 37,607 |  |  | $ | 85,827 |  |  | $ | 115,295 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,580 |  |  | $ | 7,503 |  |  | $ | 22,451 |  |  | $ | 19,456 |  |
| Purchases (1) | 32,340 |  |  | 24,908 |  |  | 100,911 |  |  | 91,662 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:114]
__________________________

- removed (2021-11-05):
[0001375365-21-000034:note_history:115]
(1) Includes principally purchases of inventory and other miscellaneous items.

- removed (2021-11-05):
[0001375365-21-000034:note_history:116]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2021 and 2020.

- removed (2021-11-05):
[0001375365-21-000034:note_history:117]
|  | March 31, 2021 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,620 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 32,243 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 14,486 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 36,355 |  |  | 46,518 |  |
| Other long-term liabilities (3) | — |  |  | 186 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:118]
____________________________

- removed (2021-11-05):
[0001375365-21-000034:note_history:119]
(1) Other receivables include receivables from vendors.

- removed (2021-11-05):
[0001375365-21-000034:note_history:120]
(2) Includes current portion of operating lease liabilities.

- removed (2021-11-05):
[0001375365-21-000034:note_history:121]
(3) Represents non-current portion of operating lease liabilities.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:122]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849,856 |  |  |  |  | $ | 617,788 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 182,874 |  |  |  |  | 144,462 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,032,730 |  |  |  |  | $ | 762,250 |  |  |  |  |  |  |  |  |  |  |  |
  (was, 2021-05-07, similarity 0.648):
[0001375365-21-000034:note_history:122]
|  | Three Months Ended March 31, |  |  |  | Nine Months Ended March 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |  |
| Server and storage systems | $ | 693,339 |  |  |  |  | $ | 571,291 |  |  |  |  | $ | 1,953,838 |  |  |  |  | $ | 1,880,043 |  |  |  |
| Subsystems and accessories | 202,542 |  |  |  |  | 201,117 |  |  |  |  | 534,599 |  |  |  |  | 563,112 |  |  |  |
| Total | $ | 895,881 |  |  |  |  | $ | 772,408 |  |  |  |  | $ | 2,488,437 |  |  |  |  | $ | 2,443,155 |  |  |  |

- changed (2021-11-05):
[0001375365-21-000083:note_history:123]
The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):
  (was, 2021-05-07, similarity 0.9243):
[0001375365-21-000034:note_history:123]
The following is a summary for the three and nine months ended March 31, 2021 and 2020, of net sales by geographic region (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:124]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 560,948 |  |  | $ | 496,086 |  |  |  |  |  |
| Asia | 263,086 |  |  | 126,707 |  |  |  |  |  |
| Europe | 179,694 |  |  | 112,089 |  |  |  |  |  |
| Other | 29,002 |  |  | 27,368 |  |  |  |  |  |
|  | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:125]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 499,061 |  |  | $ | 422,872 |  |  | $ | 1,458,249 |  |  | $ | 1,419,117 |  |
| Asia | 207,204 |  |  | 160,472 |  |  | 495,326 |  |  | 487,827 |  |
| Europe | 162,285 |  |  | 158,144 |  |  | 429,193 |  |  | 433,767 |  |
| Others | 27,331 |  |  | 30,920 |  |  | 105,669 |  |  | 102,444 |  |
|  | $ | 895,881 |  |  | $ | 772,408 |  |  | $ | 2,488,437 |  |  | $ | 2,443,155 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0001375365-21-000083:note_history:126]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849,856 |  |  |  |  | $ | 617,788 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 182,874 |  |  |  |  | 144,462 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,032,730 |  |  |  |  | $ | 762,250 |  |  |  |  |  |  |  |  |  |  |  |
  (was, 2021-05-07, similarity 0.648):
[0001375365-21-000034:note_history:126]
|  | Three Months Ended March 31, |  |  |  | Nine Months Ended March 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |  |
| Server and storage systems | $ | 693,339 |  |  |  |  | $ | 571,291 |  |  |  |  | $ | 1,953,838 |  |  |  |  | $ | 1,880,043 |  |  |  |
| Subsystems and accessories | 202,542 |  |  |  |  | 201,117 |  |  |  |  | 534,599 |  |  |  |  | 563,112 |  |  |  |
| Total | $ | 895,881 |  |  |  |  | $ | 772,408 |  |  |  |  | $ | 2,488,437 |  |  |  |  | $ | 2,443,155 |  |  |  |

- changed (2021-11-05):
[0001375365-21-000083:note_history:127]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):
  (was, 2021-05-07, similarity 0.8946):
[0001375365-21-000034:note_history:127]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2021 and 2020, of net sales by geographic region (in thousands):

- added (2021-11-05):
[0001375365-21-000083:note_history:128]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 560,948 |  |  | $ | 496,086 |  |  |  |  |  |
| Asia | 263,086 |  |  | 126,707 |  |  |  |  |  |
| Europe | 179,694 |  |  | 112,089 |  |  |  |  |  |
| Other | 29,002 |  |  | 27,368 |  |  |  |  |  |
|  | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |

- changed (2021-11-05):
[0001375365-21-000083:note_history:129]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2021, which was included in the opening deferred revenue balance as of June 30, 2021 of $202.3 million, was $30.0 million.
  (was, 2021-05-07, similarity 0.935):
[0001375365-21-000034:note_history:129]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and nine months ended March 31, 2021, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $24.1 million and $79.6 million, respectively.

- added (2021-11-05):
[0001375365-21-000083:note_history:130]
Deferred revenue increased $13.1 million during the three months ended September 30, 2021 as compared to the fiscal year ended June 30, 2021 mainly due to the increase in non-cancellable non-refundable advance considerations received from customers which precede the Company's satisfaction of the associated performance obligations.

- changed (2021-11-05):
[0001375365-21-000083:note_history:131]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2021 was $215.4 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2021-05-07, similarity 0.9877):
[0001375365-21-000034:note_history:131]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2021 was $190.0 million. The Company expects to recognize approximately 51% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- changed (2021-11-05):
[0001375365-21-000083:note_history:132]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.
  (was, 2021-05-07, similarity 0.7232):
[0001375365-21-000034:note_history:132]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies

- removed (2021-11-05):
[0001375365-21-000034:note_history:133]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 499,061 |  |  | $ | 422,872 |  |  | $ | 1,458,249 |  |  | $ | 1,419,117 |  |
| Asia | 207,204 |  |  | 160,472 |  |  | 495,326 |  |  | 487,827 |  |
| Europe | 162,285 |  |  | 158,144 |  |  | 429,193 |  |  | 433,767 |  |
| Others | 27,331 |  |  | 30,920 |  |  | 105,669 |  |  | 102,444 |  |
|  | $ | 895,881 |  |  | $ | 772,408 |  |  | $ | 2,488,437 |  |  | $ | 2,443,155 |  |

- removed (2021-11-05):
[0001375365-21-000034:note_history:134]
Starting July 1, 2020, the Company no longer separately discloses revenue by products sold to indirect sales channel partners or direct customers and original equipment manufacturers because management does not make business operational decisions based on this set of disaggregation so the disclosure is no longer material to investors.

- removed (2021-11-05):
[0001375365-21-000034:note_history:135]
Deferred revenue decreased $13.7 million during the nine months ended March 31, 2021 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

- removed (2021-11-05):
[0001375365-21-000034:note_history:136]
judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-11-05):
[0001375365-21-000034:note_history:137]
Subsequent EventOn May 5, 2021, certain current and former directors and officers were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW.  The Company was also named as a nominal defendant.  The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company's officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission.  The plaintiff seeks unspecified compensatory damages and other equitable relief.  The Company has not yet been formally served with the complaint, but the Company intends to defend the lawsuit vigorously.
