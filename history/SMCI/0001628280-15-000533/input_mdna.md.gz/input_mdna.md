# SMCI MD&A — 0001628280-15-000533


## mdna

[0001628280-15-000533:mdna:1]
[same as prior period, unchanged from 0001445305-14-004894:mdna:1]

[0001628280-15-000533:mdna:2]
[same as prior period, unchanged from 0001445305-14-004894:mdna:2]

[0001628280-15-000533:mdna:3]
We are a global leader in high-performance, high-efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the Data Center, Cloud Computing, Enterprise IT, Big Data, HPC and Embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Net sales of optimized servers were $302.3 million and $557.9 million for the three and six months ended December 31, 2014, respectively, and $174.1 million and $317.4 million for the three and six months ended December 31, 2013, respectively, and net sales of subsystems and accessories were $200.8 million and $388.5 million for the three and six months ended December 31, 2014, respectively, and $182.3 million and $348.0 million for the three and six months ended December 31, 2013, respectively. The increase in our net sales in the three and six months ended December 31, 2014 compared with the three and six months ended December 31, 2013 was primarily due to an increase in our sales of complete server systems based on Intel's DP Haswell processor, which was launched in September 2014 and to a lesser extent the increase in sales of our Twin family of servers and storage servers which offer higher density computing and more memory and hard disk derive capacity. The percentage of our net sales represented by sales of complete server systems increased to 60.1% and 58.9% in the three and six months ended December 31, 2014, respectively, from 48.8% and 47.7% in the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales were $503.0 million and $946.3 million for the three and six months ended December 31, 2014, respectively, and $356.4 million and $665.4 million for the three and six months ended December 31, 2013, respectively. Our net income was $31.2 million and $52.1 million for the three and six months ended December 31, 2014, respectively, and $13.3 million and $21.0 million for the three and six months ended December 31, 2013, respectively. Our increase in net income in the three and six months ended December 31, 2014 was primarily attributable to an increase in our gross profit resulting primarily from higher sales of server systems based on Intel's DP Haswell processor, benefits resulting from increased scale of our business, higher utilization of our manufacturing facilities in Taiwan and a refund of value added taxes on research and development expenses, partially offset by higher income tax expenses.

[0001628280-15-000533:mdna:5]
We sell our server systems and subsystems and accessories primarily through distributors and to a lesser extent to Original Equipment Manufacturers, or OEMs, as well as through our direct sales force. We derived 50.0% and 52.8% of our net sales from products sold to distributors and derived 50.0% and 47.2% from sales to OEMs and to end customers for the three and six months ended December 31, 2014, respectively, and 53.4% and 56.9% of our net sales from products sold to distributors, and 46.6% and 43.1% from sales to OEMs and to end customers for the three and six months ended December 31, 2013, respectively. One of our customers accounted for 15.1% and 11.9% of our net sales in the three and six months ended December 31, 2014, and none of our customers accounted for 10% or more of our net sales in the three and six months ended December 31, 2013. We derived 57.0% and 56.0% of our net sales from customers in the United States for the three and six months ended December 31, 2014, respectively, and 50.4% and 53.3% for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.1% and 5.0% of our net sales for the three and six months ended December 31, 2014, respectively, and 5.8% and 6.1% of our net sales for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2015, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands to support our Asian and European customers and we have increased our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and six months ended December 31, 2014, our purchases from Ablecom represented 13.8% and 14.1% of our cost of sales, respectively, compared to 18.1% and 17.7% of our cost of sales for the three and six months ended December 31, 2013, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-15-000533:mdna:8]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding, or DSOs. In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures. For example, in fiscal year 2012 and in certain prior years, our results were adversely impacted by customer order delays in anticipation of the introduction of the new lines of microprocessors and research and development expenditures necessary for us to prepare for the introduction.

[0001628280-15-000533:mdna:9]
[same as prior period, unchanged from 0001445305-14-004894:mdna:11]

[0001628280-15-000533:mdna:10]
The following is a summary of other financial highlights of the second quarter of fiscal year 2015:

[0001628280-15-000533:mdna:11]
| • | Net cash provided by (used in) operating activities was $(8.7) million and $18.4 million during the six months ended December 31, 2014 and 2013, respectively. Our cash and cash equivalents, together with our investments, were $85.9 million at the end of second quarter of fiscal year 2015, compared with $99.6 million at the end of fiscal year 2014. The decrease in our cash and cash equivalents, together with our investments at the end of second quarter of fiscal year 2015 was primarily due to increases in inventory and accounts receivable described below, as well as $9.2 million of repayments in loans, net of proceeds, $11.0 million of purchase of property, plant and equipment, of which $6.3 million was related to the development and construction of improvements on our property in San Jose, California, which is still in progress, offset in part by $12.7 million of proceeds from the exercise of stock options. |

[0001628280-15-000533:mdna:12]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the second quarter of fiscal year 2015 was 41 days, compared with 42 days at the end of the fourth quarter of fiscal year 2014. |

[0001628280-15-000533:mdna:13]
| • | Our inventory balance was $409.2 million at the end of the second quarter of fiscal year 2015, compared with $315.8 million at the end of the fiscal year 2014. Days sales of inventory (“DSI”) at the end of the second quarter of fiscal year 2015 was 83 days, compared with 77 days at the end of the fourth quarter of fiscal year 2014. The increase in our inventory was to support the transition to Intel's DP Haswell based products. |

[0001628280-15-000533:mdna:14]
| • | Our purchase commitments with contract manufacturers and suppliers were $564.6 million at the end of the second quarter of fiscal year 2015 and $211.1 million at the end of the fiscal year 2014. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $294.3 |

[0001628280-15-000533:mdna:15]
19

[0001628280-15-000533:mdna:16]
million, which have terms expiring through January 2017. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments.

[0001628280-15-000533:mdna:17]
[same as prior period, unchanged from 0001445305-14-004894:mdna:17]

[0001628280-15-000533:mdna:18]
[same as prior period, unchanged from 0001445305-14-004894:mdna:18]

[0001628280-15-000533:mdna:19]
[same as prior period, unchanged from 0001445305-14-004894:mdna:20]

[0001628280-15-000533:mdna:20]
[same as prior period, unchanged from 0001445305-14-004894:mdna:21]

[0001628280-15-000533:mdna:21]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally lower on server systems than on subsystems and accessories, but generally higher in the case of sales of server systems to internet data system customers. Because we have only limited long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001628280-15-000533:mdna:22]
[same as prior period, unchanged from 0001445305-14-004894:mdna:23]

[0001628280-15-000533:mdna:23]
[same as prior period, unchanged from 0001445305-14-004894:mdna:24]

[0001628280-15-000533:mdna:24]
[same as prior period, unchanged from 0001445305-14-004894:mdna:25]

[0001628280-15-000533:mdna:25]
[same as prior period, unchanged from 0001445305-14-004894:mdna:26]

[0001628280-15-000533:mdna:26]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, currently primarily the United States, Taiwan, the Netherlands, and to a lesser extent, China and Japan. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, the domestic production activities deduction and lower taxes in foreign jurisdictions which were partially offset by the impact of state taxes and stock option expenses. In recent years, our effective tax rate from period to period has been significantly impacted by delays in the approval of extensions of the U.S. research and development tax credit.

[0001628280-15-000533:mdna:27]
[same as prior period, unchanged from 0001445305-14-004894:mdna:29]

[0001628280-15-000533:mdna:28]
Our discussion and analysis of our financial condition and results of operations is based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, cooperative marketing accruals, investment valuations, inventory valuations, income taxes, warranty obligations and stock-based compensation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from the estimates.

[0001628280-15-000533:mdna:29]
We believe the following are our most critical accounting policies as they require more significant judgments in the preparation of our financial statements.

[0001628280-15-000533:mdna:30]
[same as prior period, unchanged from 0001445305-14-004894:mdna:32]

[0001628280-15-000533:mdna:31]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At December 31, 2014 and June 30, 2014, we had deferred revenue of $1.1 million and $7.7 million and related deferred product costs of $0.8 million and $6.7 million, respectively, related to shipments to customers pending acceptances.

[0001628280-15-000533:mdna:32]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision (recovery) for bad debt was $(33,000) and $(0.1) million in the three and six months ended December 31, 2014, respectively, and $0.2 million and $1.1 million in the three and six months ended December 31, 2013, respectively. If a major customer's credit worthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-15-000533:mdna:33]
[same as prior period, unchanged from 0001445305-14-004894:mdna:35]

[0001628280-15-000533:mdna:34]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience

[0001628280-15-000533:mdna:35]
and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.0 million and $7.1 million as of December 31, 2014 and June 30, 2014, respectively. The provision for warranty reserve was $3.3 million and $7.0 million in the three and six months ended December 31, 2014, respectively, and $3.5 million and $6.9 million in the three and six months ended December 31, 2013, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was ($0.1) million and $(0.3) million in the three and six months ended December 31, 2014, respectively, and $28,000 and $73,000 in the three and six months ended December 31, 2013, respectively. As a result of our decrease in warranty claims and lower cost of servicing warranty claims in the three months ended December 31, 2014, the provision for warranty reserve decreased $0.2 million compared to the three months ended December 31, 2013. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001628280-15-000533:mdna:36]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $2.5 million and $4.2 million in the three and six months ended December 31, 2014, respectively, and $1.5 million in both three and six months ended December 31, 2013.

[0001628280-15-000533:mdna:37]
[same as prior period, unchanged from 0001445305-14-004894:mdna:40]

[0001628280-15-000533:mdna:38]
[same as prior period, unchanged from 0001445305-14-004894:mdna:41]

[0001628280-15-000533:mdna:39]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of our Board of Directors including employee stock options and restricted stock awards based on estimated fair values. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. Compensation expense for options and restricted stock awards granted to employees was $3.2 million and $6.2 million for the three and six months ended December 31, 2014, respectively, and $2.8 million and $5.4 million for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:mdna:40]
As of December 31, 2014, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options granted since July 1, 2006 to employees and non-employee members of the Board of Directors, was $21.7 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.38 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001628280-15-000533:mdna:41]
[same as prior period, unchanged from 0001445305-14-004894:mdna:44]

[0001628280-15-000533:mdna:42]
[same as prior period, unchanged from 0001445305-14-004894:mdna:46]

[0001628280-15-000533:mdna:43]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-15-000533:mdna:44]
In May 2012, we and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of December 31, 2014, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2014, $10,000, $7,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2013 $7,000 and $13,000, respectively, of net loss attributable to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-15-000533:mdna:45]
24

[0001628280-15-000533:mdna:46]
[same as prior period, unchanged from 0001445305-14-004894:mdna:49]

[0001628280-15-000533:mdna:47]
[same as prior period, unchanged from 0001445305-14-004894:mdna:50]

[0001628280-15-000533:mdna:48]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 83.2 |  |  | 84.5 |  |  | 83.8 |  |  | 84.7 |  |
| Gross profit | 16.8 |  |  | 15.5 |  |  | 16.2 |  |  | 15.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.1 |  |  | 5.8 |  |  | 5.0 |  |  | 6.1 |  |
| Sales and marketing | 2.2 |  |  | 2.5 |  |  | 2.3 |  |  | 2.7 |  |
| General and administrative | 1.0 |  |  | 1.5 |  |  | 1.1 |  |  | 1.7 |  |
| Total operating expenses | 8.3 |  |  | 9.8 |  |  | 8.4 |  |  | 10.5 |  |
| Income from operations | 8.5 |  |  | 5.7 |  |  | 7.8 |  |  | 4.8 |  |
| Interest and other income, net | — |  |  | — |  |  | — |  |  | — |  |
| Interest expense | — |  |  | (0.1 | ) |  | — |  |  | — |  |
| Income before income tax provision | 8.5 |  |  | 5.6 |  |  | 7.8 |  |  | 4.8 |  |
| Income tax provision | 2.3 |  |  | 1.9 |  |  | 2.3 |  |  | 1.6 |  |
| Net income | 6.2 | % |  | 3.7 | % |  | 5.5 | % |  | 3.2 | % |

[0001628280-15-000533:mdna:49]
Comparison of Three Months Ended December 31, 2014 and 2013

[0001628280-15-000533:mdna:50]
Net sales. Net sales increased by $146.7 million, or 41.2%, to $503.0 million from $356.4 million, for the three months ended December 31, 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001628280-15-000533:mdna:51]
For the three months ended December 31, 2014, the number of server system units sold increased 23.8% to 78,000 compared to 63,000 for the three months ended December 31, 2013. The average selling price of server system units increased 44.4% to $3,900 in the three months ended December 31, 2014 compared to $2,700 in the three months ended December 31, 2013. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems based on Intel's DP Haswell processor which was launched in September 2014 and to a lesser extent due to the increase in sales of our Twin family of servers and storage servers which offered higher density computing and more memory and hard disk drive capacity and have a higher average selling price. Sales of server systems increased by $128.2 million or 73.6% from the three months ended December 31, 2013 to the three months ended December 31, 2014, primarily due to the increased sales of the products described above. Sales of server systems represented 60.1% of our net sales for the three months ended December 31, 2014 compared to 48.8% of our net sales for the three months ended December 31, 2013.

[0001628280-15-000533:mdna:52]
For both three months ended December 31, 2014 and 2013, the number of subsystems and accessories units sold was 1.2 million. Sales of subsystems and accessories increased by $18.5 million or 10.1% from the three months ended December 31, 2013 to the three months ended December 31, 2014, primarily related to an increased volume of hard disk drives and memory bundled with our server solutions sold to our distributors and system integrators who are purchasing additional accessories from us and completing the final assembly themselves. Sales of subsystems and accessories represented 39.9% of our net sales for the three months ended December 31, 2014 as compared to 51.2% of our net sales for the three months ended December 31, 2013.

[0001628280-15-000533:mdna:53]
For the three months ended December 31, 2014 and 2013, we derived 50.0% and 53.4%, respectively, of our net sales from products sold to distributors and we derived 50.0% and 46.6%, respectively, from sales to OEMs and to end customers. For the three months ended December 31, 2014, customers in the United States, Europe and Asia accounted for 57.0%, 18.2% and 15.6%, of our net sales, respectively, as compared to 50.4%, 23.9% and 23.0% of our net sales, respectively, for the three months ended December 31, 2013.

[0001628280-15-000533:mdna:54]
Cost of sales. Cost of sales increased by $117.3 million, or 38.9%, to $418.6 million from $301.3 million, for the three months ended December 31, 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 83.2% and 84.5% for the three months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales and an increase of $1.0 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to lower costs resulting from the increased scale of our business, an increase in the mix of complete server system sales from the introduction of systems based on Intel's DP Haswell processor and higher utilization of our manufacturing facilities in Taiwan. In the three months ended December 31, 2014, we recorded a $2.5 million expense, net of recovery, or 0.5% of net sales, related to the inventory provision as compared to $1.5 million, or 0.4% of net sales, in the three months ended December 31, 2013. The increase in the inventory provision was primarily due to higher inventory reserves for a specific product partially offset by higher sales of previously reserved inventory of $1.3 million.

[0001628280-15-000533:mdna:55]
In the three months ended December 31, 2014, we recorded a $3.3 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to $3.5 million, or 1.0% of net sales, in the three months ended December 31, 2013. The decrease in the provision for warranty reserve was primarily due to a decrease in warranty claims and lower cost of servicing warranty claims in the three months ended December 31, 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-15-000533:mdna:56]
Research and development expenses. Research and development expenses increased by $5.0 million, or 24.7%, to $25.5 million from $20.4 million, for the three months ended December 31, 2014 and 2013, respectively. Research and development expenses were 5.1% and 5.8% of net sales for the three months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $4.6 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan and an increase of $1.2 million in development costs as we continue to broaden our solutions based on the Intel's DP Haswell processor, partially offset by an increase of $1.1 million in non-recurring engineering funding from certain suppliers and customers. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended December 31, 2014.

[0001628280-15-000533:mdna:57]
Research and development expenses include stock-based compensation expense of $2.0 million and $1.7 million for the three months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:58]
Sales and marketing expenses. Sales and marketing expenses increased by $2.2 million, or 24.3%, to $11.2 million from $9.0 million, for the three months ended December 31, 2014 and 2013, respectively. Sales and marketing expenses were 2.2% and 2.5% of net sales for the three months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $2.0 million in compensation and benefits resulting from growth in sales and marketing personnel. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended December 31, 2014.

[0001628280-15-000533:mdna:59]
Sales and marketing expenses include stock-based compensation expense of $0.4 million and $0.3 million for the three months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:60]
General and administrative expenses. General and administrative expenses decreased by $0.5 million, or 9.8%, to $4.9 million from $5.5 million, for the three months ended December 31, 2014 and 2013, respectively. General and administrative expenses were 1.0% and 1.5% of net sales for the three months ended December 31, 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to an increase of $0.7 million in foreign currency transaction gain. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended December 31, 2014.

[0001628280-15-000533:mdna:61]
General and administrative expenses include stock-based compensation expense of $0.5 million for both three months ended December 31, 2014 and 2013.

[0001628280-15-000533:mdna:62]
Interest and other expense, net. Interest and other expense, net, was $0.1 million of expense for both three months ended December 31, 2014 and 2013, which primarily represented $0.2 million of expense for both three months ended December 31, 2014 and 2013.

[0001628280-15-000533:mdna:63]
Provision for income taxes. Provision for income taxes increased by $4.8 million, or 70.8%, to $11.5 million from $6.7 million, for the three months ended December 31, 2014 and 2013, respectively. The effective tax rate was 26.9% and 33.5% for the three months ended December 31, 2014 and 2013, respectively. The higher income tax provision for the three months ended December 31, 2014 was primarily attributable to our higher operating income. The lower effective tax rate for

[0001628280-15-000533:mdna:64]
the three months ended December 31, 2014 was primarily due to the extension of the U.S. federal R&D tax credit retroactively to January 1, 2014 through December 31, 2014. As a result, during the three months ended December 31, 2014, we recognized a total tax benefit of $2.8 million, of which $1.8 million related to fiscal year 2014.

[0001628280-15-000533:mdna:65]
Comparison of Six Months Ended December 31, 2014 and 2013

[0001628280-15-000533:mdna:66]
Net sales. Net sales increased by $281.0 million, or 42.2%, to $946.3 million from $665.4 million, for the six months ended December 31, 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001628280-15-000533:mdna:67]
For the six months ended December 31, 2014, the number of server system units sold increased 14.4% to 135,000 compared to 118,000 for the six months ended December 31, 2013. The average selling price of server system units increased 37.0% to $3,700 in the six months ended December 31, 2014 compared to $2,700 in the six months ended December 31, 2013. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems based on Intel's DP Haswell processor which was launched in September 2014 and to a lesser extent due to the increase in sales of our Twin family of servers and storage servers which offer higher density computing and more memory and hard disk drive capacity and have a higher average selling price. Sales of server systems increased by $240.5 million or 75.8% from the six months ended December 31, 2013 to the six months ended December 31, 2014, primarily due to the increased sales of the products described above. Sales of server systems represented 58.9% of our net sales for the six months ended December 31, 2014 compared to 47.7% of our net sales for the six months ended December 31, 2013.

[0001628280-15-000533:mdna:68]
For the six months ended December 31, 2014, the number of subsystems and accessories units sold increased 2.7% to $2.3 million compared to $2.2 million for the six months ended December 31, 2013. Sales of subsystems and accessories increased by $40.5 million or 11.6% from the six months ended December 31, 2013 to the six months ended December 31, 2014, primarily related to an increased volume of hard disk drives and memory bundled with our server solutions sold to our distributors and system integrators who are purchasing additional accessories from us and completing the final assembly themselves. Sales of subsystems and accessories represented 41.1% of our net sales for the six months ended December 31, 2014 as compared to 52.3% of our net sales for the six months ended December 31, 2013.

[0001628280-15-000533:mdna:69]
For the six months ended December 31, 2014 and 2013, we derived 52.8% and 56.9%, respectively, of our net sales from products sold to distributors and we derived 47.2% and 43.1%, respectively, from sales to OEMs and to end customers. For the six months ended December 31, 2014, customers in the United States, Europe and Asia accounted for 56.0%, 19.2% and 17.6%, of our net sales, respectively, as compared to 53.3%, 23.5% and 20.6% of our net sales, respectively, for the six months ended December 31, 2013.

[0001628280-15-000533:mdna:70]
Cost of sales. Cost of sales increased by $229.2 million, or 40.7%, to $792.7 million from $563.5 million, for the six months ended December 31, 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 83.8% and 84.7% for the six months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales and an increase of $2.6 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to lower costs resulting from the increased scale of our business, an increase in the mix of complete server system sales from the introduction of systems based on Intel's DP Haswell processor and higher utilization of our manufacturing facilities in Taiwan. In the six months ended December 31, 2014, we recorded a $4.2 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $1.5 million, or 0.2% of net sales, in the six months ended December 31, 2013. The increase in the inventory provision was primarily due to higher inventory reserves for a specific product partially offset by higher sales of previously reserved inventory of $3.4 million.

[0001628280-15-000533:mdna:71]
In the six months ended December 31, 2014, we recorded a $7.0 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to $6.9 million, or 1.0% of net sales, in the six months ended December 31, 2013. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the six months ended December 31, 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-15-000533:mdna:72]
Research and development expenses. Research and development expenses increased by $6.3 million, or 15.5%, to $47.0 million from $40.7 million, for the six months ended December 31, 2014 and 2013, respectively. Research and development expenses were 5.0% and 6.1% of net sales for the six months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $8.8 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives

[0001628280-15-000533:mdna:73]
in the United States and in Taiwan, partially offset by $2.4 million refund of value added taxes on research and development expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in the six months ended December 31, 2014.

[0001628280-15-000533:mdna:74]
Research and development expenses include stock-based compensation expense of $3.9 million and $3.3 million for the six months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:75]
Sales and marketing expenses. Sales and marketing expenses increased by $4.3 million, or 24.2%, to $22.2 million from $17.8 million, for the six months ended December 31, 2014 and 2013, respectively. Sales and marketing expenses were 2.3% and 2.7% of net sales for the three months ended December 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $3.7 million in compensation and benefits resulting from growth in sales and marketing personnel. The decrease as a percentage of net sales was primarily due to the increase in net sales in the six months ended December 31, 2014.

[0001628280-15-000533:mdna:76]
Sales and marketing expenses include stock-based compensation expense of $0.8 million and $0.6 million for the six months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:77]
General and administrative expenses. General and administrative expenses decreased by $1.1 million, or 10.2%, to $10.0 million from $11.1 million, for the six months ended December 31, 2014 and 2013, respectively. General and administrative expenses were 1.1% and 1.7% of net sales for the six months ended December 31, 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to an increase of $1.3 million in foreign currency transaction gain and a decrease of $1.2 million in bad debt expenses offset in part by an increase of $0.9 million in compensation and benefits and a decrease of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor in the prior year. The decrease as a percentage of net sales was primarily due to the increase in net sales in the six months ended December 31, 2014.

[0001628280-15-000533:mdna:78]
General and administrative expenses include stock-based compensation expense of $1.1 million and $1.0 million for the six months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:79]
Interest and other expense, net. Interest and other expense, net, was $0.3 million of expense for both six months ended December 31, 2014 and 2013, which primarily represented $0.4 million of interest expense for both six months ended December 31, 2014 and 2013.

[0001628280-15-000533:mdna:80]
Provision for income taxes. Provision for income taxes increased by $11.2 million, or 102.8%, to $22.1 million from $10.9 million, for the six months ended December 31, 2014 and 2013, respectively. The effective tax rate was 29.8% and 34.1% for the six months ended December 31, 2014 and 2013, respectively. The higher income tax provision for the six months ended December 31, 2014 was primarily attributable to our higher operating income. The lower effective tax rate for the six months ended December 31, 2014 was primarily due to the extension of the U.S. federal R&D tax credit retroactively to January 1, 2014 through December 31, 2014. As a result, during the six months ended December 31, 2014, we recognized a total tax benefit of $2.8 million, of which $1.8 million related to fiscal year 2014.

[0001628280-15-000533:mdna:81]
[same as prior period, unchanged from 0001445305-14-004894:mdna:69]

[0001628280-15-000533:mdna:82]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $83.3 million and $96.9 million as of December 31, 2014 and June 30, 2014, respectively. Our cash in foreign locations was $29.4 million and $28.3 million at December 31, 2014 and June 30, 2014, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-15-000533:mdna:83]
Operating Activities. Net cash provided by (used in) operating activities was $(8.7) million and $18.4 million for the six months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000533:mdna:84]
Net cash used in our operating activities for the six months ended December 31, 2014 was primarily due to an increase in inventory of $97.5 million and an increase in accounts receivable of $46.0 million, which were partially offset by an increase in accounts payable of $60.0 million, our net income of $52.1 million, stock-based compensation expense of $6.2 million, an increase in net income taxes payable of $5.3 million, an increase in accrued liabilities of $4.8 million, provision for lower of cost or market and excess and obsolete inventory of $4.2 million, and depreciation expense of $3.8 million.

[0001628280-15-000533:mdna:85]
Net cash provided by our operating activities for the six months ended December 31, 2013 was primarily due to our net income of $21.0 million, an increase in accounts payable of $32.0 million, stock-based compensation expense of $5.4 million, depreciation expense of $2.9 million, an increase in income tax payable of $2.7 million and an increase in accrued liability of $1.8 million which were partially offset by an increase in inventory of $38.3 million and an increase in accounts receivable of $12.9 million.

[0001628280-15-000533:mdna:86]
The increase for the six months ended December 31, 2014 in accounts receivable was primarily due to an increase in our net sales late in the quarter ended December 31, 2014. The increase for the six months ended December 31, 2014 in inventory and accounts payable was primarily due to higher purchases to support the transition to Intel's DP Haswell based products. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-15-000533:mdna:87]
The increase for the six months ended December 31, 2013 in accounts receivable was primarily due to an increase in our sales in the quarter ended December 31, 2013. The increase for the six months ended December 31, 2013 in accounts payable was due to higher purchases and timing of payments to our vendors. The increase for the six months ended December 31, 2013 in inventory was due to support the lunar new year holiday shutdown in Asia at the end of January 2014.

[0001628280-15-000533:mdna:88]
Investing activities. Net cash used in our investing activities was $11.7 million and $34.0 million for the six months ended December 31, 2014 and 2013, respectively. In the six months ended December 31, 2014, $11.0 million was related to the purchase of property, plant and equipment, of which $6.3 million was related to the development and construction of improvements on our property in San Jose, California, which is still in progress. In the six months ended December 31, 2013, $34.0 million was related to the purchase of property, plant and equipment, of which $30.2 million was related to the real property purchased in San Jose, California in October 2013.

[0001628280-15-000533:mdna:89]
We plan to develop five manufacturing buildings through fiscal 2016 on the real property we purchased in San Jose, California, to serve as our Green Computing Park. We anticipate costs for this development of approximately $19.6 million in the third and fourth quarter of fiscal year 2015 which we plan to finance through our operating cash flows and additional borrowings from banks.

[0001628280-15-000533:mdna:90]
Financing activities. Net cash provided by our financing activities was $7.2 million and $12.4 million for the six months ended December 31, 2014 and 2013, respectively. In the six months ended December 31, 2014, we received $12.7 million related to the proceeds from the exercise of stock options. Further, we borrowed an additional $5.2 million under our revolving line of credit from CTBC Bank and repaid $14.4 million in loans in the six months ended December 31, 2014. In the six months ended December 31, 2014, excess tax benefits from stock-based compensation were $2.8 million. We expect the net cash provided by financing activities will increase throughout fiscal year 2015 as we intend to obtain additional financing from banks to construct our manufacturing buildings at our Green Computing Park in San Jose, California.

[0001628280-15-000533:mdna:91]
In the six months ended December 31, 2013, we received $4.8 million related to proceeds from the exercise of stock options. Further, we borrowed additional $5.1 million under our secured term loan from CTBC Bank, borrowed $3.5 million under our revolving line of credit from CTBC Bank and repaid $1.4 million in loans in the six months ended December 31, 2013. In the six months ended December 31, 2013, excess tax benefits from stock-based compensation were $1.1 million.

[0001628280-15-000533:mdna:92]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on our revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-15-000533:mdna:93]
[same as prior period, unchanged from 0001445305-14-004894:mdna:82]

[0001628280-15-000533:mdna:94]
[same as prior period, unchanged from 0001445305-14-004894:mdna:83]

[0001628280-15-000533:mdna:95]
[same as prior period, unchanged from 0001445305-14-004894:mdna:84]

[0001628280-15-000533:mdna:96]
In October 2011, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $40.0 million revolving line of credit facility through June 15, 2013 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit to November 15, 2015.

[0001628280-15-000533:mdna:97]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at December 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-000533:mdna:98]
As of December 31, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan were $5.1 million and $6.5 million, respectively. The total outstanding borrowings under the Bank of America line of credit were $4.7 million and $17.7 million as of December 31, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.41% to 1.66% per annum at December 31, 2014 and 1.19% to 1.65% per annum at June 30, 2014. As of December 31, 2014, the unused revolving line of credit under Bank of America was $35.3 million.

[0001628280-15-000533:mdna:99]
In January 2015, we drew an additional $15.0 million from the Bank of America line of credit with an interest rate that ranged from 1.40% to 2.75% per annum to support our growth and expansion of our business.

[0001628280-15-000533:mdna:100]
[same as prior period, unchanged from 0001445305-14-004894:mdna:89]

[0001628280-15-000533:mdna:101]
[same as prior period, unchanged from 0001445305-14-004894:mdna:90]

[0001628280-15-000533:mdna:102]
In November 2013, we entered into an amendment to our existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700.0 million or $23.8 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100.0 million or $3.4 million U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500.0 million or $17.0 million U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $34.0 million U.S. dollar equivalents.

[0001628280-15-000533:mdna:103]
In December 2014, we entered into a second amendment to our existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700.0 million or $22.0 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000.0 million or $31.5 million U.S. dollar equivalents.

[0001628280-15-000533:mdna:104]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20.8 million and $22.1 million as of December 31, 2014 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $5.2 million and $0 at December 31, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 0.94% to 1.14% and 1.15% per annum at December 31, 2014 and June 30, 2014, respectively. At December 31, 2014, NT$174.7 million or $5.5 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-000533:mdna:105]
Covenant Compliance

[0001628280-15-000533:mdna:106]
Our credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-000533:mdna:107]
[same as prior period, unchanged from 0001445305-14-004894:mdna:95]

[0001628280-15-000533:mdna:108]
[same as prior period, unchanged from 0001445305-14-004894:mdna:96]

[0001628280-15-000533:mdna:109]
[same as prior period, unchanged from 0001445305-14-004894:mdna:97]

[0001628280-15-000533:mdna:110]
As of December 31, 2014, our total assets of $890.4 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of December 31, 2014, total assets collateralizing the term loan with Bank of America were $17.5 million. As of December 31, 2014, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001628280-15-000533:mdna:111]
As of December 31, 2014, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.2 million. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2014.

[0001628280-15-000533:mdna:112]
[same as prior period, unchanged from 0001445305-14-004894:mdna:101]

[0001628280-15-000533:mdna:113]
For the three and six months ended December 31, 2014, we paid our contract manufacturers within 35 to 77 days of invoice and Ablecom between 48 to 101 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of December 31, 2014 and June 30, 2014, amounts owed to Ablecom by us were approximately $57.2 million and $49.0 million, respectively.

[0001628280-15-000533:mdna:114]
[same as prior period, unchanged from 0001445305-14-004894:mdna:103]

[0001628280-15-000533:mdna:115]
As of December 31, 2014, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AAA or AA2 at December 31, 2014. These auction rate preferred shares have no stated maturity date.

[0001628280-15-000533:mdna:116]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of December 31, 2014, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at December 31, 2014, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three and six months ended December 31, 2014 and 2013, there were no auction rate securities redeemed or sold.

[0001628280-15-000533:mdna:117]
[same as prior period, unchanged from 0001445305-14-004894:mdna:106]

[0001628280-15-000533:mdna:118]
The following table describes our contractual obligations as of December 31, 2014:

[0001628280-15-000533:mdna:119]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 2,989 |  |  | $ | 2,271 |  |  | $ | 1,234 |  |  | $ | 305 |  |  | $ | 6,799 |  |
| Capital leases, including interest | 178 |  |  | 331 |  |  | 191 |  |  | — |  |  | 700 |  |
| Long-term debt, including interest (1) | 33,528 |  |  | 2,352 |  |  | — |  |  | — |  |  | 35,880 |  |
| Purchase commitments (2) | 404,584 |  |  | 160,000 |  |  | — |  |  | — |  |  | 564,584 |  |
| Total (3) | $ | 441,279 |  |  | $ | 164,954 |  |  | $ | 1,425 |  |  | $ | 305 |  |  | $ | 607,963 |  |

[0001628280-15-000533:mdna:120]
[same as prior period, unchanged from 0001445305-14-004894:mdna:109]

[0001628280-15-000533:mdna:121]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at December 31, 2014. |

[0001628280-15-000533:mdna:122]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $294.3 million of hard disk drive purchase commitments at December 31, 2014, which will be paid through January 2017. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-15-000533:mdna:123]
| (3) | The table above excludes liabilities for deferred revenue, net of cost, of $6.4 million and unrecognized tax benefits and related interest and penalties accrual of $10.6 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. |

[0001628280-15-000533:mdna:124]
[same as prior period, unchanged from 0001445305-14-004894:mdna:113]

[0001628280-15-000533:mdna:125]
[same as prior period, unchanged from 0001445305-14-004894:mdna:114]

[0001628280-15-000533:mdna:126]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. The adoption of this guidance did not have a material impact on our results of operations or financial position.

[0001628280-15-000533:mdna:127]
[same as prior period, unchanged from 0001445305-14-004894:mdna:118]

[0001628280-15-000533:mdna:128]
[same as prior period, unchanged from 0001445305-14-004894:mdna:119]

[0001628280-15-000533:mdna:129]
[same as prior period, unchanged from 0001445305-14-004894:mdna:120]

[0001628280-15-000533:mdna:130]
[same as prior period, unchanged from 0001445305-14-004894:mdna:121]
