# SMCI note change history — 0001445305-14-004894 → 0001628280-15-000533


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of December 31, 2014, these remaining non-cancellable commitments were $564,584,000 compared to $211,090,000 as of June 30, 2014.
  (was, 2014-11-06, similarity 0.678):
[0001445305-14-004894:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of September 30, 2014, these remaining non-cancellable commitments were $226,532,000 compared to $211,090,000 as of June 30, 2014.

- added (2015-02-09):
[0001628280-15-000533:note_history:2]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $294,260,000 as of December 31, 2014, an increase from $45,210,000 as of June 30, 2014 and will be paid through January 2017. The Company entered into amendments to its existing purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company negotiates the purchase price with the suppliers on an ongoing basis based upon market rates.

- removed (2015-02-09):
[0001445305-14-004894:note_history:3]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $29,224,000, which will be paid through December 2014. The Company entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.
  (was, 2014-11-06, similarity 0.7195):
[0001445305-14-004894:note_history:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.

- changed (2015-02-09):
[0001628280-15-000533:note_history:5]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.
  (was, 2014-11-06, similarity 0.9703):
[0001445305-14-004894:note_history:5]
The Company consolidates its investment in Super Micro Business Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:6]
Short-term and long-term obligations as of December 31, 2014 and June 30, 2014 consisted of the following (in thousands):
  (was, 2014-11-06, similarity 0.9776):
[0001445305-14-004894:note_history:6]
Short-term and long-term obligations as of September 30, 2014 and June 30, 2014 consisted of the following (in thousands):

- changed (2015-02-09):
[0001628280-15-000533:note_history:7]
|  | December 31, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 4,699 |  |  | $ | 17,699 |  |
| CTBC Bank | 5,200 |  |  | — |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,133 |  |  | 6,533 |  |
| CTBC Bank | 20,760 |  |  | 22,055 |  |
| Total building term loans | 25,893 |  |  | 28,588 |  |
| Total debt | 35,792 |  |  | 46,287 |  |
| Current portion | (33,459 | ) |  | (42,554 | ) |
| Long-term portion | $ | 2,333 |  |  | $ | 3,733 |  |
  (was, 2014-11-06, similarity 0.9565):
[0001445305-14-004894:note_history:7]
|  | September 30, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 9,899 |  |  | $ | 17,699 |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,833 |  |  | 6,533 |  |
| CTBC Bank | 21,747 |  |  | 22,055 |  |
| Total building term loans | 27,580 |  |  | 28,588 |  |
| Total debt | 37,479 |  |  | 46,287 |  |
| Current portion | (34,446 | ) |  | (42,554 | ) |
| Long-term portion | $ | 3,033 |  |  | $ | 3,733 |  |

- changed (2015-02-09):
[0001628280-15-000533:note_history:8]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2015.
  (was, 2014-11-06, similarity 0.9256):
[0001445305-14-004894:note_history:8]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2014. The Company is currently negotiating with Bank of America to renew the revolving line of credit.

- changed (2015-02-09):
[0001628280-15-000533:note_history:9]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at December 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.
  (was, 2014-11-06, similarity 0.6861):
[0001445305-14-004894:note_history:9]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at September 30, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- changed (2015-02-09):
[0001628280-15-000533:note_history:10]
As of December 31, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $5,133,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $4,699,000 and $17,699,000 as of December 31, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.41% to 1.66% per annum at December 31, 2014 and 1.19%  to 1.65% per annum at June 30, 2014. As of December 31, 2014, the unused revolving line of credit with Bank of America was $35,301,000.
  (was, 2014-11-06, similarity 0.8574):
[0001445305-14-004894:note_history:10]
As of September 30, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $5,833,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $9,899,000 and $17,699,000 as of September 30, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.19% to 1.66% per annum at September 30, 2014 and from 1.19%  to 1.65% per annum at June 30, 2014, respectively. As of September 30, 2014, the unused revolving line of credit with Bank of America was $30,101,000.

- added (2015-02-09):
[0001628280-15-000533:note_history:11]
In January 2015, the Company drew an additional $15,000,000 from the Bank of America line of credit with an interest rate that ranged from 1.40% to 2.75% per annum to support the Company's growth and expansion of its business.

- added (2015-02-09):
[0001628280-15-000533:note_history:12]
In December 2014, the Company entered into a second amendment to the existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $31,453,000 U.S. dollar equivalents.

- added (2015-02-09):
[0001628280-15-000533:note_history:13]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20,760,000 and $22,055,000 at December 31, 2014 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $5,200,000 and $0 at December 31, 2014 and June 30, 2014, respectively. The interest rate for these loans were ranged from 0.94%  to 1.14% at December 31, 2014 and 1.15% per annum at June 30, 2014. At December 31, 2014, NT$174,676,000 or $5,494,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

- changed (2015-02-09):
[0001628280-15-000533:note_history:14]
As of December 31, 2014 and June 30, 2014, total assets of $890,370,000 and $751,396,000, respectively, collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan.  As of December 31, 2014 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,469,000 and $17,584,000, respectively. As of December 31, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.
  (was, 2014-11-06, similarity 0.9624):
[0001445305-14-004894:note_history:14]
As of September 30, 2014 and June 30, 2014, the total assets of $783,506,000 and $751,396,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan, As of September 30, 2014 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,526,000 and $17,584,000, respectively. As of September 30, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

- changed (2015-02-09):
[0001628280-15-000533:note_history:15]
As of December 31, 2014 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,202,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2014.
  (was, 2014-11-06, similarity 0.9347):
[0001445305-14-004894:note_history:15]
As of September 30, 2014 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,243,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2014.

- removed (2015-02-09):
[0001445305-14-004894:note_history:16]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,747,000 and $22,055,000 at September 30, 2014 and June 30, 2014, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at September 30, 2014 and June 30, 2014. The interest rate for the loan was at 1.16% and 1.15% per annum at September 30, 2014 and June 30, 2014, respectively. At September 30, 2014, NT$340,000,000 or $11,203,000 U.S. dollar equivalents were available for future borrowing under this credit agreement. The Company is currently negotiating with CTBC Bank to renew the credit agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:17]
As of December 31, 2014 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at December 31, 2014 and June 30, 2014. These auction rate preferred shares have no stated maturity date.
  (was, 2014-11-06, similarity 0.9825):
[0001445305-14-004894:note_history:17]
As of September 30, 2014 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at September 30, 2014 and June 30, 2014. These auction rate preferred shares have no stated maturity date.

- changed (2015-02-09):
[0001628280-15-000533:note_history:18]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of December 31, 2014 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.
  (was, 2014-11-06, similarity 0.9916):
[0001445305-14-004894:note_history:18]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2014 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.

- changed (2015-02-09):
[0001628280-15-000533:note_history:19]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of December 31, 2014 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of December 31, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.78%, 3 years and 0.39%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.
  (was, 2014-11-06, similarity 0.9961):
[0001445305-14-004894:note_history:19]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of September 30, 2014 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of September 30, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.6%, 3 years and 0.3%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

- changed (2015-02-09):
[0001628280-15-000533:note_history:20]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three and six months ended December 31, 2014 and 2013. There was a cumulative total decline of $103,000 as of December 31, 2014 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of December 31, 2014 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.
  (was, 2014-11-06, similarity 0.9626):
[0001445305-14-004894:note_history:20]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three months ended September 30, 2014 and 2013. There was a cumulative total decline of $103,000 as of September 30, 2014 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of September 30, 2014 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

- changed (2015-02-09):
[0001628280-15-000533:note_history:21]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform a periodic impairment analysis. In the three and six months ended December 31, 2014 and 2013, there were no auction rate securities redeemed or sold.
  (was, 2014-11-06, similarity 0.953):
[0001445305-14-004894:note_history:21]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three months ended September 30, 2014 and 2013, there was no auction rate securities redeemed or sold.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:22]
Short-term and long-term obligations as of December 31, 2014 and June 30, 2014 consisted of the following (in thousands):
  (was, 2014-11-06, similarity 0.9776):
[0001445305-14-004894:note_history:22]
Short-term and long-term obligations as of September 30, 2014 and June 30, 2014 consisted of the following (in thousands):

- changed (2015-02-09):
[0001628280-15-000533:note_history:23]
|  | December 31, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 4,699 |  |  | $ | 17,699 |  |
| CTBC Bank | 5,200 |  |  | — |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,133 |  |  | 6,533 |  |
| CTBC Bank | 20,760 |  |  | 22,055 |  |
| Total building term loans | 25,893 |  |  | 28,588 |  |
| Total debt | 35,792 |  |  | 46,287 |  |
| Current portion | (33,459 | ) |  | (42,554 | ) |
| Long-term portion | $ | 2,333 |  |  | $ | 3,733 |  |
  (was, 2014-11-06, similarity 0.9565):
[0001445305-14-004894:note_history:23]
|  | September 30, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 9,899 |  |  | $ | 17,699 |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,833 |  |  | 6,533 |  |
| CTBC Bank | 21,747 |  |  | 22,055 |  |
| Total building term loans | 27,580 |  |  | 28,588 |  |
| Total debt | 37,479 |  |  | 46,287 |  |
| Current portion | (34,446 | ) |  | (42,554 | ) |
| Long-term portion | $ | 3,033 |  |  | $ | 3,733 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001628280-15-000533:note_history:24]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 42.9% of Ablecom at December 31, 2014.
  (was, 2014-11-06, similarity 0.9954):
[0001445305-14-004894:note_history:24]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at September 30, 2014.

- changed (2015-02-09):
[0001628280-15-000533:note_history:25]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $57,513,000 and $111,916,000, and sold products to Ablecom totaling $10,879,000 and $37,457,000 for the three and six months ended December 31, 2014, respectively. The Company purchased products from Ablecom totaling $54,424,000 and $99,741,000 and sold products to Ablecom totaling $3,859,000 and $7,387,000 for the three and six months ended December 31, 2013, respectively.
  (was, 2014-11-06, similarity 0.7097):
[0001445305-14-004894:note_history:25]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $54,403,000 and $45,317,000, and sold products to Ablecom totaling $26,578,000 and $3,528,000 for the three months ended September 30, 2014 and 2013, respectively.

- changed (2015-02-09):
[0001628280-15-000533:note_history:26]
Amounts owed to the Company by Ablecom as of December 31, 2014 and June 30, 2014, were $1,138,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2014 and June 30, 2014, were $57,154,000 and $48,969,000, respectively. For the three and six months ended December 31, 2014, the Company paid Ablecom the majority of invoiced dollars between 48 and 101 days of invoice date. For the three and six months ended December 31, 2014, the Company paid $2,495,000 and $4,497,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2013, the Company paid $1,460,000 and $3,736,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2014-11-06, similarity 0.7496):
[0001445305-14-004894:note_history:26]
Amounts owed to the Company by Ablecom as of September 30, 2014 and June 30, 2014, were $2,416,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2014 and June 30, 2014, were $45,145,000 and $48,969,000, respectively. For the three months ended September 30, 2014 and 2013, the Company paid Ablecom the majority of invoiced dollars between 52 and 66 days of invoice date. For the three months ended September 30, 2014 and 2013, the Company paid $2,002,000 and $2,276,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2015-02-09):
[0001628280-15-000533:note_history:27]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $83,969,000 and $64,464,000 at December 31, 2014 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2014-11-06, similarity 0.9954):
[0001445305-14-004894:note_history:27]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $70,455,000 and $64,464,000 at September 30, 2014 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2015-02-09):
[0001628280-15-000533:note_history:28]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2014, $10,000 and $7,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2013, $7,000 and $13,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2014-11-06, similarity 0.7841):
[0001445305-14-004894:note_history:28]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2014 and 2013, $3,000 and $(6,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
