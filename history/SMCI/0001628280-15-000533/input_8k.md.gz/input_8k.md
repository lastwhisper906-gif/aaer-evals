# SMCI 8-K — 0001628280-15-000167 filed 2015-01-20

## item codes, every 8-K on or before 2015-02-09

- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2015-02-09

- none on or before 2015-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-000167:8k_2_02:1]
EX-99.1
2
exhibit991q22015.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-15-000167:8k_2_02:2]
Exhibit 991 Q22015

[0001628280-15-000167:8k_2_02:3]
Exhibit 99.1

[0001628280-15-000167:8k_2_02:4]
Super Micro Computer, Inc. Announces 2nd Quarter 2015 Financial Results

[0001628280-15-000167:8k_2_02:5]
SAN JOSE, Calif., January 20, 2015 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a leader in application optimized, high performance server solutions, today announced second quarter of fiscal 2015 financial results for the quarter ended December 31, 2014.

[0001628280-15-000167:8k_2_02:6]
Fiscal 2nd Quarter Highlights

[0001628280-15-000167:8k_2_02:7]
| • | Quarterly net sales of $503.0 million, up 13.5% from the first quarter of fiscal year 2015 and up 41.2% from the same quarter of last year. |

[0001628280-15-000167:8k_2_02:8]
| • | GAAP net income of $31.2 million, up 49.7% from the first quarter of fiscal year 2015 and up 134.3% from the same quarter of last year. |

[0001628280-15-000167:8k_2_02:9]
| • | GAAP gross margin of 16.8%, up from 15.6% in the first quarter of fiscal year 2015 and up from 15.5% in the same quarter of last year. |

[0001628280-15-000167:8k_2_02:10]
| • | Server solutions accounted for 60.1% of net sales compared with 57.7% in the first quarter of fiscal year 2015 and 48.8% in the same quarter of last year. |

[0001628280-15-000167:8k_2_02:11]
Net sales for the second quarter ended December 31, 2014 totaled $503.0 million, up 13.5% from $443.3 million in the first quarter of fiscal year 2015. One customer accounted for more than 10% of net sales during the quarter ended December 31, 2014.

[0001628280-15-000167:8k_2_02:12]
GAAP net income for the second quarter of fiscal year 2015 was $31.2 million or $0.61 per diluted share, an increase of 134.3% from the net income of $13.3 million, or $0.30 per diluted share in the same period a year ago. Included in net income for the quarter is $3.2 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the second quarter was $33.5 million, or $0.65 per diluted share, compared to non-GAAP net income of $15.9 million, or $0.35 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the first quarter of fiscal year 2015 by $10.3 million or $0.19 per diluted share.

[0001628280-15-000167:8k_2_02:13]
GAAP gross margin and Non-GAAP gross margin for the second quarter were both 16.8% compared to 15.5% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the first quarter of fiscal year 2015 were 15.6% and 15.7%, respectively.

[0001628280-15-000167:8k_2_02:14]
The GAAP income tax provision for the second quarter of fiscal year 2015 was $11.5 million or 26.9% of income before tax provision compared to $6.7 million or 33.5% in the same period a year ago and $10.6 million or 33.7% in the first quarter of fiscal year 2015. The effective tax rate for the second quarter of fiscal year 2015 was lower primarily due to the reinstatement of U.S. federal research and development tax credits.

[0001628280-15-000167:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at December 31, 2014 were $85.9 million compared to $99.6 million at June 30, 2014. Free cash flow for the six months ended December 31, 2014 was $(19.7) million, primarily due to the development and construction of improvements on the Company's property, which is still in progress and an increase in the Company's cash used in operating activities.

[0001628280-15-000167:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-15-000167:8k_2_02:17]
The Company expects net sales of $450 million to $500 million for the third quarter of fiscal year 2015 ending March 31, 2015. The Company expects non-GAAP earnings per diluted share of approximately $0.46 to $0.52 for the third quarter.

[0001628280-15-000167:8k_2_02:18]
“Last quarter we achieved our fifth consecutive record high revenue which was 41.2% higher than last year and we reached our goal of $2 billion annual run rate for revenues in a quarter. Not only was this quarter outstanding from a revenue perspective, but we also continued to improve our operating margin. This performance was driven by a significant increase in our new Haswell product shipments in the first full quarter since its launch, and we are confident that a strong cycle of technology transition is underway. Strength in Storage and Cloud market verticals were part of a record for server systems revenue at 60.1%,” said Charles Liang, Chairman and Chief Executive of Supermicro. “Supermicro has the broadest product portfolio of application optimized server/storage technology in the industry featuring our Ultra line of servers as well as many choices for multi-node servers including our Twin architecture, Blades, MicroCloud and MicroBlade. We are well positioned for growth and market share gains.”

[0001628280-15-000167:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-15-000167:8k_2_02:20]
Conference Call Information

[0001628280-15-000167:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-428-9480 (International callers dial 1-719-325-2315) 10 minutes prior. A recording of the conference will be available until 11:59 pm ET on Tuesday, February 3, 2015 by dialing 1-877-870-5176

[0001628280-15-000167:8k_2_02:22]
(international callers dial 1-858-384-5517) and entering replay PIN 6183825. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-15-000167:8k_2_02:23]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-15-000167:8k_2_02:24]
Use of Non-GAAP Financial Measures

[0001628280-15-000167:8k_2_02:25]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-15-000167:8k_2_02:26]
About Super Micro Computer, Inc.

[0001628280-15-000167:8k_2_02:27]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-15-000167:8k_2_02:28]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-15-000167:8k_2_02:29]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001628280-15-000167:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | December 31, |  | June 30, |
|  |  |  |  | 2014 |  | 2014 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 83,201 |  |  | $ | 96,872 |  |
|  | Accounts receivable, net | 258,784 |  |  | 212,738 |  |
|  | Inventory |  | 409,205 |  |  | 315,837 |  |
|  | Deferred income taxes – current | 18,261 |  |  | 16,842 |  |
|  | Prepaid income taxes | 6,907 |  |  | 5,555 |  |
|  | Prepaid expenses and other current assets | 5,384 |  |  | 6,237 |  |
|  |  | Total current assets | 781,742 |  |  | 654,081 |  |
| Long-term investments | 2,647 |  |  | 2,647 |  |
| Property, plant and equipment, net | 142,660 |  |  | 130,589 |  |
| Deferred income taxes – noncurrent |  | 4,589 |  |  | 6,154 |  |
| Other assets |  |  | 3,403 |  |  | 2,854 |  |
|  |  | Total assets | $ | 935,041 |  |  | $ | 796,325 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 283,768 |  |  | $ | 219,354 |  |
|  | Accrued liabilities |  | 42,929 |  |  | 37,564 |  |
|  | Income taxes payable |  | 12,977 |  |  | 11,414 |  |
|  | Short-term debt and current portion of long-term debt | 33,459 |  |  | 42,554 |  |
|  |  | Total current liabilities | 373,133 |  |  | 310,886 |  |
| Long term debt-net of current portion | 2,333 |  |  | 3,733 |  |
| Other long-term liabilities | 14,353 |  |  | 12,475 |  |
|  |  | Total liabilities | 389,819 |  |  | 327,094 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital |  | 222,971 |  |  | 199,062 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (79 | ) |  | (63 | ) |
|  | Retained earnings |  | 324,192 |  |  | 272,087 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 545,054 |  |  | 469,056 |  |
|  | Noncontrolling interest | 168 |  |  | 175 |  |
|  |  | Total liabilities and stockholders' equity | $ | 935,041 |  |  | $ | 796,325 |  |

[0001628280-15-000167:8k_2_02:31]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended December 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 503,014 |  |  | $ | 356,362 |  |  | $ | 946,336 |  |  | $ | 665,378 |  |
| Cost of sales | 418,562 |  |  | 301,270 |  |  | 792,691 |  |  | 563,494 |  |
| Gross profit | 84,452 |  |  | 55,092 |  |  | 153,645 |  |  | 101,884 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 25,465 |  |  | 20,428 |  |  | 46,974 |  |  | 40,664 |  |
| Sales and marketing | 11,158 |  |  | 8,976 |  |  | 22,160 |  |  | 17,841 |  |
| General and administrative | 4,944 |  |  | 5,484 |  |  | 10,000 |  |  | 11,132 |  |
| Total operating expenses | 41,567 |  |  | 34,888 |  |  | 79,134 |  |  | 69,637 |  |
| Income from operations | 42,885 |  |  | 20,204 |  |  | 74,511 |  |  | 32,247 |  |
| Interest and other income, net | 36 |  |  | 46 |  |  | 71 |  |  | 63 |  |
| Interest expense | (183 | ) |  | (184 | ) |  | (379 | ) |  | (379 | ) |
| Income before income tax provision | 42,738 |  |  | 20,066 |  |  | 74,203 |  |  | 31,931 |  |
| Income tax provision | 11,496 |  |  | 6,731 |  |  | 22,098 |  |  | 10,897 |  |
| Net income | $ | 31,242 |  |  | $ | 13,335 |  |  | $ | 52,105 |  |  | $ | 21,034 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.68 |  |  | $ | 0.31 |  |  | $ | 1.14 |  |  | $ | 0.49 |  |
| Diluted | $ | 0.61 |  |  | $ | 0.30 |  |  | $ | 1.03 |  |  | $ | 0.47 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 46,131 |  |  | 42,915 |  |  | 45,802 |  |  | 42,706 |  |
| Diluted (b) | 51,091 |  |  | 45,039 |  |  | 50,567 |  |  | 45,052 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended December 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 222 |  |  | $ | 245 |  |  | $ | 429 |  |  | $ | 480 |  |
| Research and development | 1,997 |  |  | 1,709 |  |  | 3,893 |  |  | 3,270 |  |
| Sales and marketing | 414 |  |  | 305 |  |  | 779 |  |  | 619 |  |
| General and administrative | 548 |  |  | 529 |  |  | 1,060 |  |  | 1,008 |  |

[0001628280-15-000167:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 52,105 |  |  | $ | 21,034 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 3,845 |  |  | 2,920 |  |
| Stock-based compensation expense | 6,161 |  |  | 5,377 |  |
| Excess tax benefits from stock-based compensation | (2,782 | ) |  | (1,084 | ) |
| Allowance for doubtful accounts | (87 | ) |  | 1,076 |  |
| Provision for inventory | 4,175 |  |  | 1,538 |  |
| Exchange gain | (1,305 | ) |  | (115 | ) |
| Deferred income taxes, net | 121 |  |  | 242 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (45,959 | ) |  | (12,910 | ) |
| Inventory | (97,543 | ) |  | (38,295 | ) |
| Prepaid expenses and other assets | 793 |  |  | 1,428 |  |
| Accounts payable | 60,016 |  |  | 31,950 |  |
| Income taxes payable, net | 5,314 |  |  | 2,677 |  |
| Accrued liabilities | 4,795 |  |  | 1,760 |  |
| Other long-term liabilities | 1,664 |  |  | 797 |  |
| Net cash provided by (used in) operating activities | (8,687 | ) |  | 18,395 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (11,031 | ) |  | (33,956 | ) |
| Investment in a privately held company | (661 | ) |  | — |  |
| Restricted cash | (1 | ) |  | (8 | ) |
| Net cash used in investing activities | (11,693 | ) |  | (33,964 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 5,200 |  |  | 8,576 |  |
| Repayment of debt | (14,400 | ) |  | (1,400 | ) |
| Proceeds from exercise of stock options | 12,745 |  |  | 4,785 |  |
| Excess tax benefits from stock-based compensation | 2,782 |  |  | 1,084 |  |
| Payment of obligations under capital leases | (58 | ) |  | (15 | ) |
| Advances under receivable financing arrangements | 918 |  |  | 41 |  |
| Minimum tax withholding paid on behalf of an officer for restricted stock awards | — |  |  | (651 | ) |
| Net cash provided by financing activities | 7,187 |  |  | 12,420 |  |
| Effect of exchange rate fluctuations on cash | (478 | ) |  | (6 | ) |
| Net decrease in cash and cash equivalents | (13,671 | ) |  | (3,155 | ) |
| Cash and cash equivalents at beginning of period | 96,872 |  |  | 93,038 |  |
| Cash and cash equivalents at end of period | 83,201 |  |  | 89,883 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 382 |  |  | 378 |  |
| Cash paid for taxes, net of refunds | 15,464 |  |  | 6,840 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 336 |  |  | 57 |  |
| Accrued costs for property, plant and equipment purchases | 7,874 |  |  | 2,891 |  |

[0001628280-15-000167:8k_2_02:33]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months EndedDecember 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP GROSS PROFIT | $ | 84,452 |  |  | $ | 55,092 |  |  | $ | 153,645 |  |  | $ | 101,884 |  |
|  | Add back stock-based compensation (c) | 222 |  |  | 245 |  |  | 429 |  |  | 480 |  |
| Non-GAAP GROSS PROFIT | $ | 84,674 |  |  | $ | 55,337 |  |  | $ | 154,074 |  |  | $ | 102,364 |  |
| GAAP GROSS MARGIN | 16.8 | % |  | 15.5 | % |  | 16.2 | % |  | 15.3 | % |
|  | Add back stock-based compensation (c) | 0.0 | % |  | 0.0 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 16.8 | % |  | 15.5 | % |  | 16.3 | % |  | 15.4 | % |
| GAAP INCOME FROM OPERATIONS | $ | 42,885 |  |  | $ | 20,204 |  |  | $ | 74,511 |  |  | $ | 32,247 |  |
|  | Add back stock-based compensation (c) | 3,181 |  |  | 2,788 |  |  | 6,161 |  |  | 5,377 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 46,066 |  |  | $ | 22,992 |  |  | $ | 80,672 |  |  | $ | 37,624 |  |
| GAAP NET INCOME | $ | 31,242 |  |  | $ | 13,335 |  |  | $ | 52,105 |  |  | $ | 21,034 |  |
|  | Add back stock-based compensation (c) | 3,181 |  |  | 2,788 |  |  | 6,161 |  |  | 5,377 |  |
|  | Add back adjustments to tax provision (d) | (919 | ) |  | (239 | ) |  | (1,577 | ) |  | (653 | ) |
| Non-GAAP NET INCOME | $ | 33,504 |  |  | $ | 15,884 |  |  | $ | 56,689 |  |  | $ | 25,758 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.68 |  |  | $ | 0.31 |  |  | $ | 1.14 |  |  | $ | 0.49 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.05 |  |  | 0.06 |  |  | 0.10 |  |  | 0.11 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.73 |  |  | $ | 0.37 |  |  | $ | 1.24 |  |  | $ | 0.60 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.61 |  |  | $ | 0.30 |  |  | $ | 1.03 |  |  | $ | 0.47 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.04 |  |  | 0.05 |  |  | 0.08 |  |  | 0.10 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.65 |  |  | $ | 0.35 |  |  | $ | 1.11 |  |  | $ | 0.57 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP (g) | 46,131 |  |  | 42,915 |  |  | 45,802 |  |  | 42,706 |  |
|  | BASIC - Non-GAAP (h) | 46,131 |  |  | 42,918 |  |  | 45,802 |  |  | 42,762 |  |
|  | DILUTED – GAAP (g) | 51,091 |  |  | 45,039 |  |  | 50,567 |  |  | 45,052 |  |
|  | DILUTED - Non-GAAP (h) | 51,645 |  |  | 46,022 |  |  | 51,131 |  |  | 45,485 |  |

[0001628280-15-000167:8k_2_02:34]
(a)  Approximately $1,000 and $28,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:35]
(b) Approximately $1,000 and $26,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:36]
(c) Amortization of ASC Topic 718 stock-based compensation for the three and six months ended December 31, 2014 and 2013.

[0001628280-15-000167:8k_2_02:37]
(d) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 27.0% and 29.5% for the three and six months ended December 31, 2014, respectively, and 30.5% and 31.0% for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:38]
(e) Approximately $1,000 and $34,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:39]
(f) Approximately $1,000 and $32,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:40]
(g) 2,739 and 56,043 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:41]
(h) 2,739 and 56,043 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000167:8k_2_02:42]
SOURCE: Super Micro Computer, Inc.

[0001628280-15-000167:8k_2_02:43]
Super Micro Computer, Inc.

[0001628280-15-000167:8k_2_02:44]
Howard Hideshima, 408-503-8000

[0001628280-15-000167:8k_2_02:45]
SVP, Chief Financial Officer

[0001628280-15-000167:8k_2_02:46]
ir@supermicro.com

[0001628280-15-000167:8k_2_02:47]
or

[0001628280-15-000167:8k_2_02:48]
Perry G. Hayes

[0001628280-15-000167:8k_2_02:49]
SVP, Investor Relations

[0001628280-15-000167:8k_2_02:50]
ir@supermicro.com

[0001628280-15-000167:8k_2_02:51]
SMCI-F

## item 5.02 — body, verbatim

[0001628280-15-000167:8k_body:1]
Item 5.02

[0001628280-15-000167:8k_body:2]
Departure of Directors or Principal Officer; Election of Directors; Appointment of Principal Officers.

[0001628280-15-000167:8k_body:3]
On January 15, 2015, Gregory K. Hinckley has notified the Company that he will not be standing for re-election to the Board of Directors of the Company at the Company’s Annual Stockholders’ Meeting.  There are no disagreements with Mr. Hinckley on any matter relating to the Company’s operations, policies or practices.
