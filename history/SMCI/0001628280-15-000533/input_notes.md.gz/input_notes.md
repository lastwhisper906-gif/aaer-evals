# SMCI notes — 0001628280-15-000533


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-000533:notes:1]
Commitments and Contingencies

[0001628280-15-000533:notes:2]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-15-000533:notes:3]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of December 31, 2014, these remaining non-cancellable commitments were $564,584,000 compared to $211,090,000 as of June 30, 2014.

[0001628280-15-000533:notes:4]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $294,260,000 as of December 31, 2014, an increase from $45,210,000 as of June 30, 2014 and will be paid through January 2017. The Company entered into amendments to its existing purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company negotiates the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-15-000533:notes:5]
[same as prior period, unchanged from 0001445305-14-004894:notes:5]

[0001628280-15-000533:notes:6]
[same as prior period, unchanged from 0001445305-14-004894:notes:6]

[0001628280-15-000533:notes:7]
[same as prior period, unchanged from 0001445305-14-004894:notes:7]

[0001628280-15-000533:notes:8]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.

[0001628280-15-000533:notes:9]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-000533:notes:10]
Short-term and Long-term Obligations

[0001628280-15-000533:notes:11]
Short-term and long-term obligations as of December 31, 2014 and June 30, 2014 consisted of the following (in thousands):

[0001628280-15-000533:notes:12]
|  | December 31, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 4,699 |  |  | $ | 17,699 |  |
| CTBC Bank | 5,200 |  |  | — |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,133 |  |  | 6,533 |  |
| CTBC Bank | 20,760 |  |  | 22,055 |  |
| Total building term loans | 25,893 |  |  | 28,588 |  |
| Total debt | 35,792 |  |  | 46,287 |  |
| Current portion | (33,459 | ) |  | (42,554 | ) |
| Long-term portion | $ | 2,333 |  |  | $ | 3,733 |  |

[0001628280-15-000533:notes:13]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-15-000533:notes:14]
Bank of America

[0001628280-15-000533:notes:15]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2015.

[0001628280-15-000533:notes:16]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at December 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-000533:notes:17]
As of December 31, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $5,133,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $4,699,000 and $17,699,000 as of December 31, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.41% to 1.66% per annum at December 31, 2014 and 1.19%  to 1.65% per annum at June 30, 2014. As of December 31, 2014, the unused revolving line of credit with Bank of America was $35,301,000.

[0001628280-15-000533:notes:18]
In January 2015, the Company drew an additional $15,000,000 from the Bank of America line of credit with an interest rate that ranged from 1.40% to 2.75% per annum to support the Company's growth and expansion of its business.

[0001628280-15-000533:notes:19]
CTBC Bank

[0001628280-15-000533:notes:20]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollars or $9,898,000 U.S. dollars equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollars or $14,912,000 U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

[0001628280-15-000533:notes:21]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

[0001628280-15-000533:notes:22]
In December 2014, the Company entered into a second amendment to the existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $31,453,000 U.S. dollar equivalents.

[0001628280-15-000533:notes:23]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20,760,000 and $22,055,000 at December 31, 2014 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $5,200,000 and $0 at December 31, 2014 and June 30, 2014, respectively. The interest rate for these loans were ranged from 0.94%  to 1.14% at December 31, 2014 and 1.15% per annum at June 30, 2014. At December 31, 2014, NT$174,676,000 or $5,494,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-000533:notes:24]
Covenant Compliance

[0001628280-15-000533:notes:25]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-000533:notes:26]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001628280-15-000533:notes:27]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001628280-15-000533:notes:28]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001628280-15-000533:notes:29]
As of December 31, 2014 and June 30, 2014, total assets of $890,370,000 and $751,396,000, respectively, collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan.  As of December 31, 2014 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,469,000 and $17,584,000, respectively. As of December 31, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001628280-15-000533:notes:30]
As of December 31, 2014 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,202,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-000533:notes:31]
[same as prior period, unchanged from 0001445305-14-004894:notes:29]

[0001628280-15-000533:notes:32]
[same as prior period, unchanged from 0001445305-14-004894:notes:30]

[0001628280-15-000533:notes:33]
The authorized number of shares that may be issued under the Company's 2006 Equity Incentive Plan (the "2006 Plan") automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant and options vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. The 2006 Plan is the successor equity incentive plan to the Company's 1998 Stock Option Plan. As of December 31, 2014, the Company had 989,406 authorized shares available for future issuance under the 2006 Plan.

[0001628280-15-000533:notes:34]
[same as prior period, unchanged from 0001445305-14-004894:notes:32]

[0001628280-15-000533:notes:35]
[same as prior period, unchanged from 0001445305-14-004894:notes:33]

[0001628280-15-000533:notes:36]
[same as prior period, unchanged from 0001445305-14-004894:notes:34]

[0001628280-15-000533:notes:37]
[same as prior period, unchanged from 0001445305-14-004894:notes:35]

[0001628280-15-000533:notes:38]
[same as prior period, unchanged from 0001445305-14-004894:notes:36]

[0001628280-15-000533:notes:39]
[same as prior period, unchanged from 0001445305-14-004894:notes:37]

[0001628280-15-000533:notes:40]
[same as prior period, unchanged from 0001445305-14-004894:notes:38]

[0001628280-15-000533:notes:41]
The fair value of stock option grants for the three and six months ended December 31, 2014 and 2013 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-15-000533:notes:42]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Risk-free interest rate | 1.50 | % |  | 1.53 | % |  | 1.50% - 1.76% |  |  | 1.53% - 1.54% |  |
| Expected life | 5.44 years |  |  | 5.50 years |  |  | 5.44 years |  |  | 5.49 - 5.50 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 49.31 | % |  | 50.07 | % |  | 46.93% - 49.31% |  |  | 50.05% - 50.07% |  |
| Weighted-average fair value | $ | 11.64 |  |  | $ | 6.63 |  |  | $ | 11.69 |  |  | $ | 6.24 |  |

[0001628280-15-000533:notes:43]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000533:notes:44]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 222 |  |  | $ | 245 |  |  | $ | 429 |  |  | $ | 480 |  |
| Research and development | 1,997 |  |  | 1,709 |  |  | 3,893 |  |  | 3,270 |  |
| Sales and marketing | 414 |  |  | 305 |  |  | 779 |  |  | 619 |  |
| General and administrative | 548 |  |  | 529 |  |  | 1,060 |  |  | 1,008 |  |
| Stock-based compensation expense before taxes | 3,181 |  |  | 2,788 |  |  | 6,161 |  |  | 5,377 |  |
| Income tax impact | (785 | ) |  | (381 | ) |  | (1,392 | ) |  | (669 | ) |
| Stock-based compensation expense, net | $ | 2,396 |  |  | $ | 2,407 |  |  | $ | 4,769 |  |  | $ | 4,708 |  |

[0001628280-15-000533:notes:45]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $5,003,000 and $1,532,000 of excess tax benefits recorded in additional paid-in capital in the six months ended December 31, 2014 and 2013, respectively. The Company had excess tax benefits that are classified as cash from financing activities of $2,782,000 and $1,084,000 in the six months ended December 31, 2014 and 2013, respectively, for options issued since July 1, 2006.

[0001628280-15-000533:notes:46]
[same as prior period, unchanged from 0001445305-14-004894:notes:44]

[0001628280-15-000533:notes:47]
The following table summarizes stock option activity during the six months ended December 31, 2014 under all stock option plans:

[0001628280-15-000533:notes:48]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 (7,558,631 shares exercisable at weighted average exercise price of $11.05 per share) |  | 10,905,602 |  |  | $ | 12.24 |  |  |  |  |  |
| Granted |  | 832,500 |  |  | $ | 25.89 |  |  |  |  |  |
| Exercised |  | (1,160,444 | ) |  | $ | 10.96 |  |  |  |  |  |
| Forfeited |  | (108,091 | ) |  | $ | 17.85 |  |  |  |  |  |
| Balance as of December 31, 2014 |  | 10,469,567 |  |  | $ | 13.41 |  |  | 6.17 |  | $ | 224,743 |  |
| Options vested and expected to vest at December 31, 2014 |  | 10,227,938 |  |  | $ | 13.25 |  |  | 6.10 |  | $ | 221,184 |  |
| Options vested and exercisable at December 31, 2014 |  | 7,292,418 |  |  | $ | 11.53 |  |  | 5.08 |  | $ | 170,261 |  |

[0001628280-15-000533:notes:49]
The total pretax intrinsic value of options exercised was $16,721,000 and $22,070,000 during the three and six months ended December 31, 2014, respectively, and $3,234,000 and $5,215,000 for the three and six months ended December 31, 2013, respectively. As of December 31, 2014, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted since July 1, 2006 to employees and non-employee directors was $21,681,000, which will be recognized over a remaining weighted-average vesting period of approximately 2.38 years.

[0001628280-15-000533:notes:50]
[same as prior period, unchanged from 0001445305-14-004894:notes:48]

[0001628280-15-000533:notes:51]
The Company had no restricted stock award activity for the three and six months ended December 31, 2014 and the three months ended December 31, 2013. The total pretax intrinsic value of restricted stock awards vested was $2,337,000 for the six months ended December 31, 2013. In the six months ended December 31, 2013, upon vesting, 179,641 shares of restricted stock awards were partially net share-settled such that the Company withheld 50,000 shares with value equivalent to an officer's minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld was based on the value of the restricted stock awards on their vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities was $651,000 in the six months ended December 31, 2013 and is reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. There are no unvested restricted stock awards at December 31, 2014.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-15-000533:notes:52]
[same as prior period, unchanged from 0001445305-14-004894:notes:50]

[0001628280-15-000533:notes:53]
[same as prior period, unchanged from 0001445305-14-004894:notes:51]


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-000533:notes:54]
[same as prior period, unchanged from 0001445305-14-004894:notes:52]

[0001628280-15-000533:notes:55]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Basic net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 31,242 |  |  | $ | 13,335 |  |  | $ | 52,105 |  |  | $ | 21,034 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (1 | ) |  | — |  |  | (28 | ) |
| Net income attributable to common shares—basic | $ | 31,242 |  |  | $ | 13,334 |  |  | $ | 52,105 |  |  | $ | 21,006 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,131 |  |  | 42,915 |  |  | 45,802 |  |  | 42,706 |  |
| Basic net income per common share | $ | 0.68 |  |  | $ | 0.31 |  |  | $ | 1.14 |  |  | $ | 0.49 |  |
| Diluted net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 31,242 |  |  | $ | 13,335 |  |  | $ | 52,105 |  |  | $ | 21,034 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (1 | ) |  | — |  |  | (26 | ) |
| Net income attributable to common shares—diluted | $ | 31,242 |  |  | $ | 13,334 |  |  | $ | 52,105 |  |  | $ | 21,008 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,131 |  |  | 42,915 |  |  | 45,802 |  |  | 42,706 |  |
| Dilutive effect of options to purchase common stock | 4,960 |  |  | 2,124 |  |  | 4,765 |  |  | 2,346 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 51,091 |  |  | 45,039 |  |  | 50,567 |  |  | 45,052 |  |
| Diluted net income per common share | $ | 0.61 |  |  | $ | 0.30 |  |  | $ | 1.03 |  |  | $ | 0.47 |  |

[0001628280-15-000533:notes:56]
For the three and six months ended December 31, 2014 and 2013, the Company had stock options outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The shares of common stock issuable upon exercise of such anti-dilutive outstanding stock options were 707,000 and 470,000 for the three and six months ended December 31, 2014, respectively, and 6,288,000 and 5,461,000 for the three and six months ended December 31, 2013, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-15-000533:notes:57]
The following table sets forth the Company’s cash equivalents and long-term investments as of December 31, 2014 and June 30, 2014 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-15-000533:notes:58]
| December 31, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-15-000533:notes:59]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three and six months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000533:notes:60]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance as of beginning of period | $ | 2,647 |  |  | $ | 2,637 |  |  | $ | 2,647 |  |  | $ | 2,637 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |  | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |  | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 2,647 |  |  | $ | 2,637 |  |  | $ | 2,647 |  |  | $ | 2,637 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-000533:notes:61]
[same as prior period, unchanged from 0001445305-14-004894:notes:59]

[0001628280-15-000533:notes:62]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of December 31, 2014 and June 30, 2014. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001628280-15-000533:notes:63]
The above table excludes $82,666,000 and $96,324,000 of cash and $710,000 and $746,000 of certificates of deposit held by the Company as of December 31, 2014 and June 30, 2014, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and six months ended December 31, 2014 and 2013.

[0001628280-15-000533:notes:64]
The following is a summary of the Company’s long-term investments as of December 31, 2014 and June 30, 2014 (in thousands):

[0001628280-15-000533:notes:65]
|  | December 31, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |
|  | June 30, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |

[0001628280-15-000533:notes:66]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of December 31, 2014 and June 30, 2014, short-term and long-term debt of $35,792,000 and $46,287,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as they are not actively traded and are valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-000533:notes:67]
[same as prior period, unchanged from 0001445305-14-004894:notes:65]

[0001628280-15-000533:notes:68]
The Company recorded provisions for income taxes of $11,496,000 and $22,098,000 for the three and six months ended December 31, 2014, respectively, and $6,731,000 and $10,897,000 for the three and six months ended December 31, 2013, respectively. The effective tax rate was 26.9% and 29.8% for the three and six months ended December 31, 2014, respectively, and 33.5% and 34.1% for the three and six months ended December 31, 2013, respectively. The effective tax rate for the three and six months ended December 31, 2014 is estimated to be lower than the federal statutory rate primarily due to  the reinstatement of the U.S. federal research and development (“R&D”) tax credit, the benefit from disqualifying dispositions of shares issued upon exercise of incentive stock options and higher income taxed by foreign jurisdictions with lower tax rates, in part offset by the impact of stock option expenses.

[0001628280-15-000533:notes:69]
In the three months ended December 31, 2014, the Tax Increase Prevention Act of 2014 extended the U.S. federal R&D tax credit retroactively to January 1, 2014 through December 31, 2014. As a result, during the three months ended December 31, 2014, the Company recognized a total tax benefit of $2,773,000, of which $1,804,000 related to fiscal year 2014.

[0001628280-15-000533:notes:70]
As of December 31, 2014, the Company had a liability for gross unrecognized tax benefits of $11,998,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three and six months ended December 31, 2014, there were no material changes in the total amount of the liability for gross unrecognized tax benefits.

[0001628280-15-000533:notes:71]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of December 31, 2014, the Company had accrued $994,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-15-000533:notes:72]
[same as prior period, unchanged from 0001445305-14-004894:notes:69]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-15-000533:notes:73]
Long-term Investments

[0001628280-15-000533:notes:74]
As of December 31, 2014 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at December 31, 2014 and June 30, 2014. These auction rate preferred shares have no stated maturity date.

[0001628280-15-000533:notes:75]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of December 31, 2014 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.

[0001628280-15-000533:notes:76]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of December 31, 2014 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of December 31, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.78%, 3 years and 0.39%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001628280-15-000533:notes:77]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three and six months ended December 31, 2014 and 2013. There was a cumulative total decline of $103,000 as of December 31, 2014 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of December 31, 2014 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001628280-15-000533:notes:78]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform a periodic impairment analysis. In the three and six months ended December 31, 2014 and 2013, there were no auction rate securities redeemed or sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-15-000533:notes:79]
Adoption of New Accounting Pronouncements

[0001628280-15-000533:notes:80]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

[0001628280-15-000533:notes:81]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

[0001628280-15-000533:notes:82]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations or financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-15-000533:notes:83]
[same as prior period, unchanged from 0001445305-14-004894:notes:80]

[0001628280-15-000533:notes:84]
[same as prior period, unchanged from 0001445305-14-004894:notes:81]

[0001628280-15-000533:notes:85]
[same as prior period, unchanged from 0001445305-14-004894:notes:82]

[0001628280-15-000533:notes:86]
[same as prior period, unchanged from 0001445305-14-004894:notes:83]

[0001628280-15-000533:notes:87]
[same as prior period, unchanged from 0001445305-14-004894:notes:84]

[0001628280-15-000533:notes:88]
[same as prior period, unchanged from 0001445305-14-004894:notes:85]

[0001628280-15-000533:notes:89]
[same as prior period, unchanged from 0001445305-14-004894:notes:86]

[0001628280-15-000533:notes:90]
[same as prior period, unchanged from 0001445305-14-004894:notes:87]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-15-000533:notes:91]
[same as prior period, unchanged from 0001445305-14-004894:notes:88]

[0001628280-15-000533:notes:92]
|  | December 31, 2014 |  | June 30, 2014 |
| Land | $ | 63,962 |  |  | $ | 63,962 |  |
| Buildings | 51,959 |  |  | 51,959 |  |
| Building and leasehold improvements | 7,838 |  |  | 7,683 |  |
| Buildings construction in progress (1) | 8,708 |  |  | 587 |  |
| Machinery and equipment | 38,764 |  |  | 34,342 |  |
| Furniture and fixtures | 6,410 |  |  | 5,892 |  |
| Purchased software | 3,711 |  |  | 3,606 |  |
| Purchased software construction in progress (2) | 4,969 |  |  | 2,548 |  |
|  | 186,321 |  |  | 170,579 |  |
| Accumulated depreciation and amortization | (43,661 | ) |  | (39,990 | ) |
| Property, plant and equipment, net | $ | 142,660 |  |  | $ | 130,589 |  |

[0001628280-15-000533:notes:93]
[same as prior period, unchanged from 0001445305-14-004894:notes:90]

[0001628280-15-000533:notes:94]
[same as prior period, unchanged from 0001445305-14-004894:notes:91]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-15-000533:notes:95]
Related-party and Other Transactions

[0001628280-15-000533:notes:96]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 42.9% of Ablecom at December 31, 2014.

[0001628280-15-000533:notes:97]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-15-000533:notes:98]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-15-000533:notes:99]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-15-000533:notes:100]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $57,513,000 and $111,916,000, and sold products to Ablecom totaling $10,879,000 and $37,457,000 for the three and six months ended December 31, 2014, respectively. The Company purchased products from Ablecom totaling $54,424,000 and $99,741,000 and sold products to Ablecom totaling $3,859,000 and $7,387,000 for the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:notes:101]
Amounts owed to the Company by Ablecom as of December 31, 2014 and June 30, 2014, were $1,138,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2014 and June 30, 2014, were $57,154,000 and $48,969,000, respectively. For the three and six months ended December 31, 2014, the Company paid Ablecom the majority of invoiced dollars between 48 and 101 days of invoice date. For the three and six months ended December 31, 2014, the Company paid $2,495,000 and $4,497,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2013, the Company paid $1,460,000 and $3,736,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-15-000533:notes:102]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $83,969,000 and $64,464,000 at December 31, 2014 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-15-000533:notes:103]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2014, $10,000 and $7,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2013, $7,000 and $13,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-15-000533:notes:104]
[same as prior period, unchanged from 0001445305-14-004894:notes:101]

[0001628280-15-000533:notes:105]
|  | December 31, 2014 |  | June 30, 2014 |
| Accrued payroll and related expenses | $ | 15,858 |  |  | $ | 11,624 |  |
| Customer deposits | 5,454 |  |  | 4,185 |  |
| Accrued warranty costs | 6,960 |  |  | 7,083 |  |
| Accrued cooperative marketing expenses | 5,024 |  |  | 4,387 |  |
| Others | 9,633 |  |  | 10,285 |  |
| Total accrued liabilities | $ | 42,929 |  |  | $ | 37,564 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-15-000533:notes:106]
[same as prior period, unchanged from 0001445305-14-004894:notes:103]

[0001628280-15-000533:notes:107]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 302,256 |  |  | 60.1 | % |  | $ | 174,072 |  |  | 48.8 | % |  | $ | 557,865 |  |  | 58.9 | % |  | $ | 317,355 |  |  | 47.7 | % |
| Subsystems and accessories | 200,758 |  |  | 39.9 | % |  | 182,290 |  |  | 51.2 | % |  | 388,471 |  |  | 41.1 | % |  | 348,023 |  |  | 52.3 | % |
| Total | $ | 503,014 |  |  | 100.0 | % |  | $ | 356,362 |  |  | 100.0 | % |  | $ | 946,336 |  |  | 100.0 | % |  | $ | 665,378 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-15-000533:notes:108]
[same as prior period, unchanged from 0001445305-14-004894:notes:105]

[0001628280-15-000533:notes:109]
[same as prior period, unchanged from 0001445305-14-004894:notes:106]

[0001628280-15-000533:notes:110]
|  | December 31, 2014 |  | June 30, 2014 |
| Finished goods | $ | 304,190 |  |  | $ | 246,803 |  |
| Work in process | 43,963 |  |  | 18,794 |  |
| Purchased parts and raw materials | 61,052 |  |  | 50,240 |  |
| Total inventory | $ | 409,205 |  |  | $ | 315,837 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-15-000533:notes:111]
[same as prior period, unchanged from 0001445305-14-004894:notes:108]

[0001628280-15-000533:notes:112]
|  | December 31, 2014 |  | June 30, 2014 |
| Prepaid royalty license | $ | 1,122 |  |  | $ | 1,246 |  |
| Restricted cash | 427 |  |  | 450 |  |
| Investment in a privately held company | 1,411 |  |  | 750 |  |
| Others | 443 |  |  | 408 |  |
| Total other assets | $ | 3,403 |  |  | $ | 2,854 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-15-000533:notes:113]
[same as prior period, unchanged from 0001445305-14-004894:notes:110]

[0001628280-15-000533:notes:114]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance, beginning of period | $ | 7,077 |  |  | $ | 6,600 |  |  | $ | 7,083 |  |  | $ | 6,472 |  |
| Provision for warranty | 3,304 |  |  | 3,507 |  |  | 6,960 |  |  | 6,941 |  |
| Costs charged to accrual | (3,305 | ) |  | (3,313 | ) |  | (6,770 | ) |  | (6,664 | ) |
| Change in estimated liability for pre-existing warranties | (116 | ) |  | 28 |  |  | (313 | ) |  | 73 |  |
| Balance, end of period | $ | 6,960 |  |  | $ | 6,822 |  |  | $ | 6,960 |  |  | $ | 6,822 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-15-000533:notes:115]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2014 and 2013, of net sales by geographic region (in thousands):

[0001628280-15-000533:notes:116]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 286,748 |  |  | $ | 179,571 |  |  | $ | 530,126 |  |  | $ | 354,785 |  |
| Europe | 91,588 |  |  | 84,977 |  |  | 181,145 |  |  | 156,162 |  |
| Asia | 78,575 |  |  | 82,211 |  |  | 167,013 |  |  | 137,183 |  |
| Other | 46,103 |  |  | 9,603 |  |  | 68,052 |  |  | 17,248 |  |
|  | $ | 503,014 |  |  | $ | 356,362 |  |  | $ | 946,336 |  |  | $ | 665,378 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-15-000533:notes:117]
[same as prior period, unchanged from 0001445305-14-004894:notes:114]

[0001628280-15-000533:notes:118]
|  | December 31, 2014 |  | June 30, 2014 |
| Long-lived assets: |  |  |  |
| United States | $ | 104,076 |  |  | $ | 94,119 |  |
| Asia | 38,276 |  |  | 36,123 |  |
| Europe | 308 |  |  | 347 |  |
|  | $ | 142,660 |  |  | $ | 130,589 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-000533:notes:119]
[same as prior period, unchanged from 0001445305-14-004894:notes:116]

[0001628280-15-000533:notes:120]
[same as prior period, unchanged from 0001445305-14-004894:notes:117]

[0001628280-15-000533:notes:121]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute subsystems and accessories assembled by the Company. One customer represented 15.1% and 11.9% of the Company’s total net sales in the three and six months ended December 31, 2014, respectively, and no customer represented greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2013. No country other than the United States represents greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2014 and 2013.  The same customer accounted for 22.1% of the Company's accounts receivable as of December 31, 2014. No customer accounted for 10% or more of the Company's accounts receivable as of June 30, 2014.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-000533:notes:122]
[same as prior period, unchanged from 0001445305-14-004894:notes:119]

[0001628280-15-000533:notes:123]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $2,515,000 and $4,175,000 in the three and six months ended December 31, 2014, respectively, and $1,534,000 and $1,538,000 in the three and six months ended December 31, 2013, respectively.

[0001628280-15-000533:notes:124]
Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California and bank guarantees in connection with office leases in the Netherlands. In December 2014, the Company made an investment in a privately held company of $661,000.
