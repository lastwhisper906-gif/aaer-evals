# SMCI MD&A — 0001375365-26-000022


## mdna

[0001375365-26-000022:mdna:1]
Item 7.        Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-26-000022:mdna:2]
Overview

[0001375365-26-000022:mdna:3]
We are a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, we are committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. As a Total IT Solutions manufacturer, our offerings include server, artificial intelligence (“AI”) systems, storage, IoT devices, switches, software, and support services. Supermicro's expertise in motherboard, power, and chassis design drives our ability to develop and produce next-generation innovations, from cloud to edge, for our global customers. Our products are designed and manufactured in-house across facilities in the United States, Taiwan, and the Netherlands. Leveraging our global operations for scale and efficiency, we optimize solutions to improve TCO while reducing environmental impact through Green Computing initiatives. Our award-winning portfolio of Server Building Block Solutions empowers customers to tailor systems precisely to their exact workloads and applications. By selecting from a broad family of flexible and reusable building blocks, customers can configure a comprehensive range of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions, including air-conditioned, free air, and liquid cooling solutions.

[0001375365-26-000022:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2026, 2025, and 2024, our net income was $2,230.5 million, $1,048.9 million, and $1,152.7 million, respectively.

[0001375365-26-000022:mdna:5]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offerings and enhance customer service and support, particularly as we increase our focus on large enterprise and data center customers. A key component of our strategy is our DCBBS, which significantly reduces data center build time and enables full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services, and ongoing maintenance. To further expand our market share, we intend to strengthen our network of sales partners and distribution channels.

[0001375365-26-000022:mdna:6]
We measure our financial success based on various key indicators, including growth in net sales, gross profit, income from operations, and net income per common share. In addition to these financial metrics, a critical non-financial indicator of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. To support this, we work closely with the developers and manufacturers of key components, allowing us to integrate emerging technologies as they become available. Our ability to quickly bring new products to market, which we believe is enabled by our Building Block Solution architecture, has historically enabled us to capitalize on major technology transitions such as the launch of new GPUs, microprocessors and storage technologies. Accordingly, we closely monitor the product introduction cycles of industry leaders, including NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others. This strategic focus directly informs our research and development investments, as we continue to allocate resources toward both our current initiatives and future product innovation.

[0001375365-26-000022:mdna:7]
AI and Data Centers

[0001375365-26-000022:mdna:8]
The growing use of AI, which requires enhanced data center capabilities, has substantially increased demand for our products. We expect this trend to continue, with further demand for data center expansion driven by the AI market. As a result, we will continue to enhance our product capabilities and expand our service offerings, including DCBBS to address the growing demand in the AI market and data center markets. We believe that our ability to tailor certain products to the unique needs of these sectors sets us apart from many competitors and positions us to capture an even greater market share going forward.

[0001375365-26-000022:mdna:9]
SMCI | 2026 Form 10-K | 40

[0001375365-26-000022:mdna:10]
Macroeconomic Factors

[0001375365-26-000022:mdna:11]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints, tariffs, and global economic and geopolitical developments, have had and may continue to have direct and indirect impacts on our business and results of operations, particularly demand for our products and net sales. While difficult to isolate and quantify, these macroeconomic factors have also impacted and may continue to impact our supply chain and manufacturing costs, employee wages, costs for capital equipment, the value of our investments, revenue and competitive position. During fiscal year 2026, the computer server industry experienced supply constraints for certain components, including memory and storage, as well as GPU and CPU availability, which affected the timing of certain of our product deliveries, as well as the pricing of these items. Further, while many of these macroeconomic factors could have a long-term impact, others may have a short-term impact which could lead to our financial results not being comparable on a period-to-period basis. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001375365-26-000022:mdna:12]
Financial Highlights

[0001375365-26-000022:mdna:13]
The following is a summary of our financial highlights for fiscal years 2026 and 2025 (in thousands, except per share amounts):

[0001375365-26-000022:mdna:14]
|  |  | Years Ended June 30, |
|  |  | 2026 |  | 2025 |
| Net sales |  | $ | 39,063,072 |  |  | $ | 21,972,042 |  |
| Gross profit |  | $ | 4,227,251 |  |  | $ | 2,429,922 |  |
| Total operating expenses |  | $ | 1,456,765 |  |  | $ | 1,176,928 |  |
| Income from operations |  | $ | 2,770,486 |  |  | $ | 1,252,994 |  |
| Net income |  | $ | 2,230,453 |  |  | $ | 1,048,854 |  |
| Net income per common share - diluted |  | $ | 3.26 |  |  | $ | 1.68 |  |

[0001375365-26-000022:mdna:15]
•Net sales increased by 77.8% in fiscal year 2026, as compared to fiscal year 2025, primarily driven by fulfillment and shipment of orders to support our customers' data center deployment, including large design wins from a few customers. The strong year-on-year growth was driven by our product mix, customer diversification, growth in enterprise and channel revenues and an increase in our average selling prices.

[0001375365-26-000022:mdna:16]
•Gross margin decreased to 10.8% in fiscal year 2026, from 11.1% in fiscal year 2025, primarily due to our strategy to offer competitive pricing to gain market share, change in product and customer mix, and higher manufacturing related expenses.

[0001375365-26-000022:mdna:17]
•Operating expenses increased by 23.8% in fiscal year 2026, as compared to fiscal year 2025, primarily due to higher headcount and increases in salary and stock-based compensation.

[0001375365-26-000022:mdna:18]
•Net income increased to $2,230.5 million in fiscal year 2026, as compared to $1,048.9 million in fiscal year 2025, as the increase in net sales was greater than the increase in operating costs, and was also sufficient to offset the decline in gross margin percentage.

[0001375365-26-000022:mdna:19]
Critical Accounting Estimates

[0001375365-26-000022:mdna:20]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which are prepared in accordance with generally accepted accounting principles in the United States ("U.S. GAAP"). The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. On an ongoing basis, we regularly evaluate our accounting estimates based on historical experience and on various other assumptions that we believe are reasonable under the circumstances. The actual impact on our financial performance could differ from these estimates under different assumptions or conditions.

[0001375365-26-000022:mdna:21]
An accounting estimate is considered critical if both (i) the nature of the estimates or assumptions is material due to the levels of subjectivity and judgment involved, and (ii) the impact within a reasonable range of outcomes of the estimates and assumptions is material to our consolidated financial statements. Critical accounting estimates in the areas of revenue recognition, inventories, and income taxes, when applicable, have the greatest potential impact on our consolidated financial statements. Therefore, we consider these to be our critical accounting estimates.

[0001375365-26-000022:mdna:22]
SMCI | 2026 Form 10-K | 41

[0001375365-26-000022:mdna:23]
For further information on all of our significant accounting policies, see Note 1. “Organization and Summary of Significant Accounting Policies” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-26-000022:mdna:24]
Revenue Recognition

[0001375365-26-000022:mdna:25]
We generate revenues from the sale of server and storage systems, subsystems, accessories and services.

[0001375365-26-000022:mdna:26]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. We include estimated variable consideration in the transaction price only to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Estimates of variable consideration are reassessed each reporting period and recorded as an adjustment to revenue, as applicable.

[0001375365-26-000022:mdna:27]
We allocate the transaction price for each customer contract to each performance obligation based on the relative Stand-alone Selling Price (“SSP”) for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For all performance obligations, we are able to establish the SSP by maximizing the use of observable inputs. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-26-000022:mdna:28]
Revenue is recognized either over time or at a point in time, depending on when control of the underlying products or services are transferred to the customer, which may require judgment. Revenue is recognized at a point in time for products. Revenue is recognized over time for extended warranty, on-site services provided. Revenue related to system rack installation and integration services is recognized over time when services are performed and the customer receives and consumes the benefits.

[0001375365-26-000022:mdna:29]
Inventories

[0001375365-26-000022:mdna:30]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of raw materials (principally electronic components), work in process (principally products being assembled), and finished goods (principally finished products and products ready for sale). We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories.

[0001375365-26-000022:mdna:31]
We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products or components, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions, which requires management judgment, that vary based on inventory aging. Situations that may result in excess or obsolete inventory or excess product purchase commitments include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, including potential cancellation or deferral of customer purchase orders, inventory obsolescence because of changing technology and customer requirements, new product introductions resulting in less demand for existing products or inconsistent spikes in demand, failure to estimate customer demand properly, ordering in advance of historical lead-times, government regulations and the impact of changes in future demand, or increase in demand for competitive products, including competitive actions. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation.

[0001375365-26-000022:mdna:32]
SMCI | 2026 Form 10-K | 42

[0001375365-26-000022:mdna:33]
Our inventory and capacity purchase commitments are based on forecasts of future customer demand and consider our third-party manufacturers’ lead times and constraints. Our manufacturing lead times can be and have been long, and in some cases, extended beyond twelve months for some products. We may place non-cancellable inventory orders for certain product components in advance of our historical lead times, pay premiums and provide deposits to secure future supply and capacity. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001375365-26-000022:mdna:34]
Income Taxes

[0001375365-26-000022:mdna:35]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes and income tax assets and liabilities, including evaluating uncertainties in the application of accounting principles and complex tax laws.

[0001375365-26-000022:mdna:36]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S. or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001375365-26-000022:mdna:37]
We record a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized based on all available evidence. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001375365-26-000022:mdna:38]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001375365-26-000022:mdna:39]
Results of Operations

[0001375365-26-000022:mdna:40]
Components of Results of Operations

[0001375365-26-000022:mdna:41]
Net Sales

[0001375365-26-000022:mdna:42]
Net sales primarily consist of sales of our server and storage solutions, including systems and related services, subsystems, and accessories. The key factors that impact net sales of our server and storage systems are the number of servers and racks sold, as well as the average selling prices per server or rack. For subsystems and accessories, the main drivers of net sales are the number of units shipped and the average selling price per unit. The prices for our server and storage systems can vary widely depending on the configuration, including factors such as speed, functionality and performance of key components, including CPUs, GPUs, SSDs, cooling systems, and memory. Similarly, the prices for our subsystems and accessories fluctuate depending on the relative value of the specific item being purchased, such as power supplies, server boards, chassis or other accessories.

[0001375365-26-000022:mdna:43]
Cost of Sales, Gross Profit, and Gross Margin

[0001375365-26-000022:mdna:44]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of components and materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs, and inventory valuation adjustment write-downs.

[0001375365-26-000022:mdna:45]
SMCI | 2026 Form 10-K | 43

[0001375365-26-000022:mdna:46]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 2.1%, 3.3%, and 4.3% of cost of sales on our consolidated statements of operations for fiscal years 2026, 2025, and 2024, respectively. For further details on our dealings with related parties, see Note 11, “Related Party Transactions” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-26-000022:mdna:47]
Research and Development

[0001375365-26-000022:mdna:48]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services, and equipment and facility expenses related to our research and development activities.

[0001375365-26-000022:mdna:49]
Sales and Marketing

[0001375365-26-000022:mdna:50]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation, commissions and incentive bonuses, and related expenses for our sales and marketing personnel, cost for trade shows, sales representative fees, and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses.

[0001375365-26-000022:mdna:51]
General and Administrative

[0001375365-26-000022:mdna:52]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, corporate governance and compliance, outside legal, audit, tax fees, insurance, and credit losses on accounts receivable.

[0001375365-26-000022:mdna:53]
Other Income (Expense), Net, Interest Income, and Interest Expense

[0001375365-26-000022:mdna:54]
Other income (expense), net, interest income, and interest expense consists primarily of interest earned on our investments and cash balances, interest incurred on our debt, and foreign exchange gains and losses.

[0001375365-26-000022:mdna:55]
Income Tax Provision

[0001375365-26-000022:mdna:56]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income, and stock-based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Note 14, “Income Taxes” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-26-000022:mdna:57]
SMCI | 2026 Form 10-K | 44

[0001375365-26-000022:mdna:58]
The following table presents certain items of our consolidated statements of operations for the years ended June 30, 2026, 2025, and 2024 (in millions):

[0001375365-26-000022:mdna:59]
|  | Years Ended June 30, |
|  | 2026 |  | 2025 |  | 2024* |
| Net sales | $ | 39,063.1 |  |  | $ | 21,972.0 |  |  | $ | 14,989.2 |  |
| Cost of sales | 34,835.8 |  |  | 19,542.1 |  |  | 12,927.8 |  |
| Gross profit | 4,227.3 |  |  | 2,429.9 |  |  | 2,061.4 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 771.2 |  |  | 636.6 |  |  | 463.5 |  |
| Sales and marketing | 352.6 |  |  | 273.1 |  |  | 189.7 |  |
| General and administrative | 333.0 |  |  | 267.2 |  |  | 197.4 |  |
| Total operating expenses | 1,456.8 |  |  | 1,176.9 |  |  | 850.6 |  |
| Income from operations | 2,770.5 |  |  | 1,253.0 |  |  | 1,210.8 |  |
| Other income (expense), net | 26.5 |  |  | (41.3) |  |  | (6.3) |  |
| Interest income | 186.9 |  |  | 59.8 |  |  | 29.0 |  |
| Interest expense | (194.6) |  |  | (59.6) |  |  | (19.4) |  |
| Income before income tax provision | 2,789.3 |  |  | 1,211.9 |  |  | 1,214.1 |  |
| Income tax provision | (556.3) |  |  | (156.8) |  |  | (63.3) |  |
| Share of (loss) income from equity investees, net of taxes | (2.5) |  |  | (6.2) |  |  | 1.8 |  |
| Net income | $ | 2,230.5 |  |  | $ | 1,048.9 |  |  | $ | 1,152.7 |  |

[0001375365-26-000022:mdna:60]
*Totals may not sum due to rounding.

[0001375365-26-000022:mdna:61]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of net sales for the years ended June 30, 2026, 2025, and 2024:

[0001375365-26-000022:mdna:62]
|  | Years Ended June 30, |  |
|  | 2026 |  | 2025 |  | 2024 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 89.2 | % |  | 88.9 | % |  | 86.2 | % |  |
| Gross profit | 10.8 | % |  | 11.1 | % |  | 13.8 | % |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development | 2.0 | % |  | 2.9 | % |  | 3.1 | % |  |
| Sales and marketing | 0.9 | % |  | 1.2 | % |  | 1.3 | % |  |
| General and administrative | 0.8 | % |  | 1.3 | % |  | 1.3 | % |  |
| Total operating expenses | 3.7 | % |  | 5.4 | % |  | 5.7 | % |  |
| Income from operations | 7.1 | % |  | 5.7 | % |  | 8.1 | % |  |
| Other income (expense), net | 0.1 | % |  | (0.2) | % |  | (0.1) | % |  |
| Interest income | 0.4 | % |  | 0.3 | % |  | 0.2 | % |  |
| Interest expense | (0.5) | % |  | (0.3) | % |  | (0.1) | % |  |
| Income before income tax provision | 7.1 | % |  | 5.5 | % |  | 8.1 | % |  |
| Income tax provision | (1.4) | % |  | (0.7) | % |  | (0.4) | % |  |
| Share of (loss) income from equity investees, net of taxes* | — | % |  | — | % |  | — | % |  |
| Net income | 5.7 | % |  | 4.8 | % |  | 7.7 | % |  |

[0001375365-26-000022:mdna:63]
*Represents an amount less than 0.1%.

[0001375365-26-000022:mdna:64]
SMCI | 2026 Form 10-K | 45

[0001375365-26-000022:mdna:65]
Net Sales

[0001375365-26-000022:mdna:66]
The following table presents net sales for fiscal years 2026, 2025, and 2024 (dollars in millions):

[0001375365-26-000022:mdna:67]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Net sales | $ | 39,063.1 |  |  | $ | 21,972.0 |  |  | $ | 14,989.2 |  |  | $ | 17,091.1 |  |  | 77.8 | % |  | $ | 6,982.8 |  |  | 46.6 | % |

[0001375365-26-000022:mdna:68]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:69]
During fiscal year 2026, we continued to experience increased net sales from server rack and storage systems due to fulfillment and shipment of orders to support our customers' data centers deployment, including large design wins from a few customers. The $17,091.1 million or 77.8% year-over-year increase in net sales of server and storage systems was primarily due to strong demand and increased billing for Hyper Servers, GPU & Super Racks of $15,261.5 million or 83.4% compared to prior year, including liquid-cooled and air-cooled servers that are generally more complex and of higher value, primarily related to our GB200, and GB300 systems. Our services and software net sales increased from $330.5 million, in fiscal year 2025, to $538.3 million, in fiscal year 2026, and contributed to overall growth, although product revenue remained the primary driver.

[0001375365-26-000022:mdna:70]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:71]
During fiscal year 2025, we experienced increased net sales from server and storage systems, particularly from our large enterprise and data center customers. The $6,982.8 million or 46.6% year-over-year increase in net sales of server and storage systems was primarily due to the strong demand and increased billings for GPU & Super Racks of $5,804.0 million or 52% compared to prior year, including liquid-cooled and air-cooled servers which are generally more complex and of higher value, primarily related to our H200, H100, and B200 systems, resulting in an increase of average selling price of 34%. Our services and software net sales increased by $102.2 million year-over-year.

[0001375365-26-000022:mdna:72]
Cost of Sales, Gross Profit, and Gross Margin

[0001375365-26-000022:mdna:73]
Cost of sales and gross margin for fiscal years 2026, 2025, and 2024 were as follows (dollars in millions):

[0001375365-26-000022:mdna:74]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 34,835.8 |  |  | $ | 19,542.1 |  |  | $ | 12,927.8 |  |  | $ | 15,293.7 |  |  | 78.3 | % |  | $ | 6,614.3 |  |  | 51.2 | % |
| Percentage of total net sales | 89.2 | % |  | 88.9 | % |  | 86.2 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 4,227.3 |  |  | $ | 2,429.9 |  |  | $ | 2,061.4 |  |  | $ | 1,797.4 |  |  | 74.0 | % |  | $ | 368.5 |  |  | 17.9 | % |
| Gross margin | 10.8 | % |  | 11.1 | % |  | 13.8 | % |  |  |  | (0.3) | % |  |  |  | (2.7) | % |

[0001375365-26-000022:mdna:75]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:76]
The $15,293.7 million or 78.3% year-over-year increase in cost of sales was primarily driven by an increase of $14,699.8 million or 73.3% in certain products including GPU servers, HPC systems, and rack-scale solutions, consistent with the higher shipment volume during fiscal year 2026, as compared to fiscal year 2025. The remaining increases in cost of sales were driven by a $237.7 million or 228.3% increase in tariff expenses driven by new trade policies enacted during the year and a $312.9 million or 24.9% increase due to a decrease in vendor rebates, partially offset by a $43.8 million or 18.8% decrease in inventory write-down adjustments resulting from increased sales related to some of our aged inventory products during the year.

[0001375365-26-000022:mdna:77]
Gross margin decreased to 10.8% in the fiscal year 2026, from 11.1% in the fiscal year 2025, primarily due to our strategy to offer competitive pricing to gain market share, change in product and customer mix, and higher manufacturing related expenses.

[0001375365-26-000022:mdna:78]
SMCI | 2026 Form 10-K | 46

[0001375365-26-000022:mdna:79]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:80]
The $6,614.3 million or 51.2% year-over-year increase in cost of sales was primarily attributed to an increase of $6,353.2 million or 50.6% in costs of components, materials, and contract manufacturing expenses primarily due to increases in shipments of GPU servers, HPC, and rack-scale solutions which have higher costs and a $86.5 million or 493.6% increase in tariff expense related to new trade policies enacted during the year, a $149.6 million or 179.2% increase in inventory write-down adjustments from aged inventory, a $67.9 million or 28.6% increase in overhead costs which includes higher labor costs attributed to increase of operating activities, and a $43.6 million or 75.5% increase in freight charges.

[0001375365-26-000022:mdna:81]
The year-over-year decrease of 2.7% in gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-26-000022:mdna:82]
Operating Expenses

[0001375365-26-000022:mdna:83]
Operating expenses for fiscal years 2026, 2025, and 2024 were as follows (dollars in millions):

[0001375365-26-000022:mdna:84]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 771.2 |  |  | $ | 636.6 |  |  | $ | 463.5 |  |  | $ | 134.6 |  |  | 21.1 | % |  | $ | 173.1 |  |  | 37.3 | % |
| Percentage of total net sales | 2.0 | % |  | 2.9 | % |  | 3.1 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 352.6 |  |  | $ | 273.1 |  |  | $ | 189.7 |  |  | $ | 79.5 |  |  | 29.1 | % |  | $ | 83.4 |  |  | 44.0 | % |
| Percentage of total net sales | 0.9 | % |  | 1.2 | % |  | 1.3 | % |  |  |  |  |  |  |  |  |
| General and administrative | $ | 333.0 |  |  | $ | 267.2 |  |  | $ | 197.4 |  |  | $ | 65.8 |  |  | 24.6 | % |  | $ | 69.8 |  |  | 35.4 | % |
| Percentage of total net sales | 0.8 | % |  | 1.3 | % |  | 1.3 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 1,456.8 |  |  | $ | 1,176.9 |  |  | $ | 850.6 |  |  | $ | 279.9 |  |  | 23.8 | % |  | $ | 326.3 |  |  | 38.4 | % |

[0001375365-26-000022:mdna:85]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:86]
Research and development expenses. The $134.6 million or 21.1% year-over-year increase in research and development expenses was primarily driven by an increase in employee-related costs of $128.2 million or 22.8%, mainly comprised of a $74.5 million or 38.1% increase in stock-based compensation, and a $53.7 million or 14.6% increase in salaries and benefits as we expanded our workforce and invested in key talent to support our global growth across regions. These increases, along with other immaterial cost increases, were partially offset by a $6.1 million or 9.7% decrease in product development costs. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-26-000022:mdna:87]
Sales and marketing expenses. The $79.5 million or 29.1% year-over-year increase in sales and marketing expenses was primarily driven by an increase in employee-related costs of $112.7 million or 54.1%, mainly comprised of a $105.5 million or 61.9% increase in salaries and benefits, and a $7.2 million or 19.0% increase in stock-based compensation, similar to our research and development expenses as we expanded our workforce and invested in key talent company-wide. These increases were partially offset by $29.8 million or 81.6% higher marketing development funds received from certain business partners related to co-marketing and advertising events to promote products, which reduced sales and marketing expense, and a $3.3 million or 4.1% decrease in standard marketing and advertising activities during fiscal 2026 as compared to fiscal 2025. Looking ahead, we expect sales and marketing expenses to continue to rise as we expand our workforce and invest in key talent.

[0001375365-26-000022:mdna:88]
SMCI | 2026 Form 10-K | 47

[0001375365-26-000022:mdna:89]
General and administrative expenses. The $65.8 million or 24.6% year-over-year increase in general and administrative expenses was primarily driven by an increase in legal and internal investigation-related expenses of $31.7 million or 98.4%, and an increase in employee-related costs of $14.5 million or 10.6%, mainly comprised of a $8.4 million or 10.4% increase in salaries and benefits, and a $6.1 million or 10.8% increase in stock-based compensation, due to stock awards granted related to hiring and retention of key talent. Additionally, there was a $13.4 million or 248.1% increase in excise and franchise tax expense directly related to the increase in sales compared to prior-year, which increased the related tax expense, a $6.4 million or 711.1% increase in financing charges primarily driven by a $5.7 million or 100.0% increase in factoring fees for the receivables sold under the Receivables Purchase Agreement, and an increase of a $7.1 million or 54.6% in indirect facilities costs such as rental costs, utility costs, and depreciation costs.  These increases were partially offset by a $12.0 million or 48.8% reduction in audit and tax fees, which were driven by an absence of additional costs related to the delayed filing of our Annual Report on Form 10-K for fiscal year 2024. Looking ahead, we expect general and administrative expenses to continue rising as we invest in process improvements, expand our workforce, and attract key talent to support our strategic initiatives and operational growth.

[0001375365-26-000022:mdna:90]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:91]
Research and development expenses. The $173.1 million or 37.3% year-over-year increase in research and development expenses was primarily driven by a $153.2 million or 34.7% increase in employee-related costs, mainly comprised of a $81.0 million or 70.0% increase in stock-based compensation, and $60.2 million or 20.2% increase in salaries, as we expanded our workforce and invested in key talent. Additionally, there was a $28.3 million or 78.3% increase in product development costs to support the development of next-generation products and technologies. These increases along with other immaterial cost increases were partially offset by an $11.0 million or 50.9% increase in research and development fees received from certain suppliers and customers.

[0001375365-26-000022:mdna:92]
Sales and marketing expenses. The $83.4 million or 44.0% year-over-year increase in sales and marketing expenses was primarily driven by a $53.5 million or 30.9% increase in employee-related costs, mainly due to a $30.9 million  or 23.0% increase in salaries and a $16.6 million or 78.3% increase in stock-based compensation, similarly to our research and development expenses as we expanded our workforce and invested in key talent company-wide. Additionally, there was a $50.0 million or 164.6% increase in advertising, travel, and other related expenses due to an increase in our marketing efforts to support the launch and promotion of new products. These increases, along with other immaterial cost increases, were partially offset by a $20.8 million or 132.6% increase in additional marketing development funds received from certain business partners.

[0001375365-26-000022:mdna:93]
General and administrative expenses. The $69.8 million or 35.4% year-over-year increase in general and administrative expenses was primarily driven by a $74.0 million or 241.0% increase in professional and service fees, reflecting higher costs for external accounting, audit, tax, legal, and advisory services, primarily driven by the Special Committee investigation and the delay in filing our Annual Report on Form 10-K for fiscal year 2024. These services were necessary to support enhancements in our external reporting processes and compliance activities during fiscal year ended 2025. Additionally, there was a $20.7 million or 37.5% increase in facilities costs such as rental costs, utility costs, and indirect depreciation costs, which are related to our efforts to expand our production capacity in order to support growing customer demands. These increases, along with other immaterial cost increases, were partially offset by a $22.8 million or 28.6% decrease in employee-related costs related to stock-based compensation.

[0001375365-26-000022:mdna:94]
SMCI | 2026 Form 10-K | 48

[0001375365-26-000022:mdna:95]
Other Income (Expense), Net, Interest Income, and Interest Expense

[0001375365-26-000022:mdna:96]
Other income (expense), net, interest income, and interest expense for fiscal years 2026, 2025, and 2024 were as follows (dollars in millions):

[0001375365-26-000022:mdna:97]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Other income (expense), net | $ | 26.5 |  |  | $ | (41.3) |  |  | $ | (6.3) |  |  | $ | 67.8 |  |  | (164.2) | % |  | $ | (35.0) |  |  | 555.6 | % |
| Percentage of total net sales | 0.1 | % |  | (0.2) | % |  | (0.1) | % |  |  |  |  |  |  |  |  |
| Interest income | $ | 186.9 |  |  | $ | 59.8 |  |  | $ | 29.0 |  |  | $ | 127.1 |  |  | 212.5 | % |  | $ | 30.8 |  |  | 106.2 | % |
| Percentage of total net sales | 0.4 | % |  | 0.3 | % |  | 0.2 | % |  |  |  |  |  |  |  |  |
| Interest expense | $ | (194.6) |  |  | $ | (59.6) |  |  | $ | (19.4) |  |  | $ | (135.0) |  |  | 226.5 | % |  | $ | (40.2) |  |  | 207.2 | % |
| Percentage of total net sales | (0.5) | % |  | (0.3) | % |  | (0.1) | % |  |  |  |  |  |  |  |  |
| Other (expense) income, net, interest income, and interest expense | $ | 18.8 |  |  | $ | (41.1) |  |  | $ | 3.3 |  |  | $ | 59.9 |  |  | (145.7) | % |  | $ | (44.4) |  |  | (1,345.5) | % |

[0001375365-26-000022:mdna:98]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:99]
The $67.8 million or 164.2% year-over-year increase in other income (expense), net was primarily driven by a $14.3 million or 550.0% gain from mark-to-market adjustments on a marketable equity security investment for fiscal year 2026, as compared to fiscal year 2025, a $17.5 million or 150.9% increase due to favorable foreign currency exchange rate fluctuations during fiscal year 2026, and a $30.3 million loss on extinguishment of our Original 2029 Convertible Notes resulting from the 2029 Convertible Notes Amendments (see Note 9, “Convertible Notes” in the notes to the consolidated financial statements in this Annual Report) recorded during fiscal year 2025 which did not recur in fiscal year 2026.

[0001375365-26-000022:mdna:100]
The $127.1 million or 212.5% year-over-year increase in interest income was primarily driven by higher interest income as a result of increased cash deposits funded by the proceeds from our convertible notes issuance and financing arrangements with a customer.

[0001375365-26-000022:mdna:101]
The $135.0 million or 226.5% increase in interest expense was primarily driven by a $58.6 million or 160.5% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025, as well as $83.0 million additional interest expense related to the drawdown on our revolving credit facilities during the second half of fiscal 2026. These increases were partially offset by a $10.6 million decrease in interest expense associated with our Bank of America and Cathay Bank line of credit and term loans, which were fully repaid during the first half of fiscal 2025.

[0001375365-26-000022:mdna:102]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:103]
The $35.0 million or 555.6% year-over-year decrease in other income (expense), net was primarily attributable to a $30.3 million or 100.0% increase for loss on extinguishment of our Original 2029 Convertible Notes resulting from the 2029 Convertible Notes Amendments (see Note 9, “Convertible Notes” in the notes to the consolidated financial statements in this Annual Report), and a $17.9 million or 283.8% increase in foreign exchange losses. These increases in expense were partially offset by a $15.7 million or 119.5% net movement in investment gains/(loss), as we incurred a loss in fiscal 2024 of $13.1 million and a gain in fiscal 2025 of $2.6 million.

[0001375365-26-000022:mdna:104]
The $30.8 million or 106.2% year-over-year increase in interest income was primarily attributable to a $31.0 million or 104.8% increase in interest income due to higher average monthly cash balances held in interest-bearing demand deposit accounts.

[0001375365-26-000022:mdna:105]
The $40.2 million or 207.2% increase in interest expense was primarily due to a $34.6 million or 1774.1% increase in interest and amortization related to the amended 2029 Convertible Note and newly issued 2028 Convertible Notes and 2030 Convertible Notes.

[0001375365-26-000022:mdna:106]
SMCI | 2026 Form 10-K | 49

[0001375365-26-000022:mdna:107]
Income Tax Provision

[0001375365-26-000022:mdna:108]
Income tax provision and effective tax rates for fiscal years 2026, 2025, and 2024 were as follows (dollars in millions):

[0001375365-26-000022:mdna:109]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | (556.3) |  |  | $ | (156.8) |  |  | $ | (63.3) |  |  | $ | (399.5) |  |  | 254.8 | % |  | $ | (93.5) |  |  | 147.7 | % |
| Percentage of total net sales | (1.4) | % |  | (0.7) | % |  | (0.4) | % |  |  |  |  |  |  |  |  |
| Effective tax rate | (19.9) | % |  | (12.9) | % |  | (5.2) | % |  |  |  |  |  |  |  |  |

[0001375365-26-000022:mdna:110]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:111]
Income tax provision increased by $399.5 million or 254.8% primarily due to an increase in worldwide income before income tax provision that increased tax expense by $331.2 million, a lower tax benefit from stock-based compensation of approximately $30.2 million, a lower tax benefit from U.S. federal research tax credit of $18.7 million, an increase of state tax expense by $35.1 million, an increase of unrecognized tax benefits by $10.0 million, and other miscellaneous immaterial tax items of approximately $5.4 million. These increases were partially offset by a higher tax benefit from foreign derived intangible income of $31.2 million.

[0001375365-26-000022:mdna:112]
The year-over-year increase in the effective tax rate is attributable to a decrease in the stock-based compensation tax deduction and lower U.S. federal research tax credit, both driven by the decrease in our stock price. The total effective tax rate increased by 7.0%, from 12.9% in the fiscal year ended June 30, 2025, to 19.9% in the fiscal year ended June 30, 2026.

[0001375365-26-000022:mdna:113]
On July 4, 2025, the OBBBA was enacted into law and contains several changes to key U.S. federal income tax laws, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027. As of June 30, 2026, we have recognized the tax effects of certain OBBBA provisions. We will continue to evaluate the impact of the OBBBA upon our future effective tax rate, tax liabilities, and cash taxes.

[0001375365-26-000022:mdna:114]
On June 29, 2026, California enacted Senate Bill 122, which extends the existing limitation of $5 million on the utilization of California business tax credits, including research and development credits, through taxable years beginning before January 1, 2030. For taxable years beginning on or after January 1, 2030, business credits generally may not reduce California tax liability by more than 70% of the tax imposed or $5 million, whichever is greater. We have evaluated the impact of this legislation on our California deferred tax assets and the realizability of our state tax credit carryforwards and concluded that the enactment did not have a material impact on our consolidated financial statements as of June 30, 2026. We will continue to evaluate its ongoing impact on our future effective tax rate, tax liabilities, and cash taxes.

[0001375365-26-000022:mdna:115]
Our effective tax rate also reflects our expectation that future income generated by our Malaysian subsidiary will substantially benefit from a Malaysian government tax incentive program for which we have applied but have not yet received final approval. Qualification is conditioned on satisfying a minimum eligible investment threshold by December 16, 2026. If we do not meet this threshold or the incentive is not otherwise granted, our Malaysian subsidiary's income would become subject to tax at the standard statutory rate rather than the anticipated exemption, which would increase our effective tax rate and cash tax payments in future periods. We continue to monitor administrative guidance from the OECD and Malaysian tax authorities regarding the interaction between the anticipated incentive and the 15% minimum tax requirement under Pillar Two and will evaluate the impact when the outcome of our application and such guidance are known.

[0001375365-26-000022:mdna:116]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:117]
The year-over-year increase in the effective tax rate is attributable to a decrease in the stock compensation tax deduction and lower research and development tax credits, both driven by the decrease in our stock price. The total effective tax rate increased by 7.7%, from 5.2% in fiscal year 2024, to 12.9% in fiscal year 2025.

[0001375365-26-000022:mdna:118]
SMCI | 2026 Form 10-K | 50

[0001375365-26-000022:mdna:119]
Share of (Loss) Income from Equity Investees, Net of Taxes

[0001375365-26-000022:mdna:120]
Share of (loss) income from equity investees, net of taxes represents our share of income (loss) from the Corporate Venture in which we had a 30% ownership, prior to the divestiture in fiscal 2026, as well as our investments in privately held companies without readily determinable fair values that are measured using the equity method.

[0001375365-26-000022:mdna:121]
Share of income (loss) from equity investee, net of taxes for fiscal years 2026, 2025 and 2024 were as follows (dollars in millions):

[0001375365-26-000022:mdna:122]
|  | Years Ended June 30, |  | 2026 over 2025 Change |  | 2025 over 2024 Change |
|  | 2026 |  | 2025 |  | 2024 |  | $ |  | % |  | $ |  | % |
| Share of (loss) income from equity investees, net of taxes | $ | (2.5) |  |  | $ | (6.2) |  |  | $ | 1.8 |  |  | $ | 3.7 |  |  | (59.7) | % |  | $ | (8.0) |  |  | (444.4) | % |
| Percentage of total net sales* | — | % |  | — | % |  | — | % |  |  |  |  |  |  |  |  |

[0001375365-26-000022:mdna:123]
*Represents an amount less than 0.1%.

[0001375365-26-000022:mdna:124]
Fiscal Year 2026 Compared with Fiscal Year 2025

[0001375365-26-000022:mdna:125]
The period-over-period decrease of $3.7 million or 59.7% in share of loss from equity investees, net of taxes was primarily due to the impairment of the Corporate Venture investment in fiscal year 2025, which did not recur in fiscal year 2026. This was partially offset by losses of $2.5 million from our equity method investees recorded in fiscal year 2026. Refer to Note 11, “Related Party Transactions” in the notes to the consolidated financial statements in this Annual Report for more details on the impairment of our Corporate Venture investment.

[0001375365-26-000022:mdna:126]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-26-000022:mdna:127]
The period-over-period decrease of $8.0 million in share of income from equity investees, net of taxes was primarily due to reduction in profitability from reduced sales of the Corporate Venture. During the year ended June 30, 2025, we recognized an impairment of $6.7 million on this investment. Refer to Note 11, “Related Party Transactions” in the notes to the consolidated financial statements in this Annual Report for more details.

[0001375365-26-000022:mdna:128]
Liquidity and Capital Resources

[0001375365-26-000022:mdna:129]
We have financed our growth primarily with funds generated from operations, as well as utilizing borrowing facilities, selling our common stock, issuing our Mandatory Convertible Preferred Stock, and issuing convertible notes. Recent drivers of liquidity changes included an increase in the need for working capital due to higher levels of inventory and accounts receivable required to support future revenue growth. Our cash and cash equivalents were $7,521.5 million and $5,169.9 million as of June 30, 2026 and 2025, respectively. Our cash and cash equivalents held in foreign locations were $870.5 million and $607.2 million as of June 30, 2026 and 2025, respectively.

[0001375365-26-000022:mdna:130]
Amounts held outside of the United States are typically used to meet non-U.S. liquidity needs and to comply with the requirements of our credit facilities. Repatriations of these funds are generally not subject to U.S. federal income tax, though state income or foreign withholding taxes may apply. In cases where local restrictions prevent the intercompany transfer of funds, our strategy is to retain cash balances outside the U.S. and meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes on the repatriation of amounts held outside the U.S. to materially affect our overall liquidity, financial condition, or results of operations.

[0001375365-26-000022:mdna:131]
In addition, because a large portion of our future expenditures will be to fund our growth, we expect that if needed we will be able to adjust our capital and operating expenditures as necessary. We  continually evaluate our cash needs and may decide it is best to raise additional capital or seek alternative financing sources to fund the rapid growth of our business, including through drawdowns on existing or new debt facilities or financing funds. Conversely, we may also from time to time determine that it is in our best interests to voluntarily repay certain indebtedness early.

[0001375365-26-000022:mdna:132]
Accordingly, we believe that our current and forecasted sources of funds will provide us with adequate liquidity during the 12-month period following the issuance of these consolidated financial statements, to meet our working capital, committed capital expenditures and contractual obligations.

[0001375365-26-000022:mdna:133]
SMCI | 2026 Form 10-K | 51

[0001375365-26-000022:mdna:134]
Our key cash flow metrics were as follows (in millions):

[0001375365-26-000022:mdna:135]
|  | Years Ended June 30, |  | 2026 over 2025 |  | 2025 over 2024 |  |  |
|  | 2026 |  | 2025 |  | 2024 |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (6,809.9) |  |  | $ | 1,659.5 |  |  | $ | (2,486.0) |  |  | $ | (8,469.4) |  |  | $ | 4,145.5 |  |  |  |
| Net cash used in investing activities | (200.3) |  |  | (183.2) |  |  | (194.2) |  |  | (17.1) |  |  | 11.0 |  |  |  |
| Net cash provided by financing activities | 9,478.8 |  |  | 2,024.0 |  |  | 3,911.7 |  |  | 7,454.8 |  |  | (1,887.7) |  |  |  |
| Effect of exchange rate fluctuations on cash | (9.4) |  |  | 1.7 |  |  | (2.2) |  |  | (11.1) |  |  | 3.9 |  |  |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 2,459.2 |  |  | $ | 3,502.0 |  |  | $ | 1,229.3 |  |  | $ | (1,042.8) |  |  | $ | 2,272.7 |  |  |  |

[0001375365-26-000022:mdna:136]
Operating Activities

[0001375365-26-000022:mdna:137]
Our largest source of operating cash flow is cash collections from our customers following the purchase of our products and service agreements. Our primary uses of cash from operating activities are typically for payments to suppliers for purchasing components for our inventory to support our manufacturing process, employee-related expenditures, expenses related to data center leases, taxes, and interest payments.

[0001375365-26-000022:mdna:138]
Net cash (used in) provided by operating activities during fiscal 2026 mostly consisted of $2,230.5 million net income adjusted for certain non-cash items, such as $412.1 million of stock-based compensation expense, $188.1 million of inventory valuation adjustment write-downs, $95.4 million of deferred income taxes, net, $53.7 million of depreciation and amortization expense, and changes in working capital. The decrease in cash flows from operating activities during fiscal 2026, as compared to fiscal 2025, was due to an increase in inventory purchases, accounts receivable from customers, and increased operational spending.

[0001375365-26-000022:mdna:139]
Investing Activities

[0001375365-26-000022:mdna:140]
The changes in cash flows from investing activities primarily relate to our investments in capital assets including property, plant and equipment, to support the growth in business and purchases and sales of our investments in marketable securities and other instruments.

[0001375365-26-000022:mdna:141]
Net cash used in investing activities during fiscal 2026 mostly consisted of $162.0 million of purchases of property, plant, and equipment as we continued to invest in real estate, servers, data centers, and network infrastructure, as well as investments made in equity securities of $51.6 million. The increase in cash used in investing activities during fiscal 2026, as compared to fiscal 2025, was mostly due to an increase in purchases of property, plant, and equipment.

[0001375365-26-000022:mdna:142]
Financing Activities

[0001375365-26-000022:mdna:143]
The changes in cash flows from financing activities primarily relate to borrowings and repayments related to our debt instruments, issuance of other financing or equity instruments, stock repurchases, dividend payments, and net proceeds related to employee stock programs.

[0001375365-26-000022:mdna:144]
Net cash provided by financing activities during fiscal 2026 mostly consisted of net proceeds from lines of credit and term loans of $3,948.3 million, as well as proceeds received from our equity offerings completed during the fourth quarter of fiscal 2026 of $5,638.6 million. These proceeds were partially offset by payment for withholding taxes related to settlement of equity awards of $129.9 million. The increase in cash provided by financing activities during fiscal 2026, as compared to fiscal 2025, was mostly due to this increase in net proceeds from lines of credit and term loans, as well as the proceeds received from our equity offerings completed during the fourth quarter of fiscal 2026.

[0001375365-26-000022:mdna:145]
Material Cash Requirements

[0001375365-26-000022:mdna:146]
Refer to Note 8, “Lines of Credit, Revolving Credit Facilities, and Term Loans” in the notes to the consolidated financial statements in this Annual Report for further information on our outstanding debt.

[0001375365-26-000022:mdna:147]
SMCI | 2026 Form 10-K | 52

[0001375365-26-000022:mdna:148]
Refer to Note 9, “Convertible Notes”, in the notes to the consolidated financial statements in this Annual Report for further information on the amendment of the terms of the 2029 Convertible Notes, and the issuance of the 2028 Convertible Notes and the 2030 Convertible Notes.

[0001375365-26-000022:mdna:149]
Refer to Note 13, “Stockholders’ Equity”, in the notes to the consolidated financial statements in this Annual Report for further information on our equity offerings, including our Mandatory Convertible Preferred Stock, common stock offering, and the at-the-market equity offering program.

[0001375365-26-000022:mdna:150]
Capital Expenditure Requirements

[0001375365-26-000022:mdna:151]
We anticipate our total capital expenditures for the fiscal year 2027 will be in the range of $380.0 million to $400.0 million, primarily relating to costs associated with our global manufacturing capabilities, including tooling for new products, new IT investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on net sales growth, productivity, expenses, service levels and customer retention).

[0001375365-26-000022:mdna:152]
Our future capital requirements will depend on a variety of factors, including our growth rate, the timing and scale of investments to support product development, the expansion of sales and marketing efforts, the launch of new and enhanced software and services offerings, and continued investments in our office facilities and IT system infrastructure.

[0001375365-26-000022:mdna:153]
Material Contractual Obligations

[0001375365-26-000022:mdna:154]
Our estimated future obligations as of June 30, 2026, include both current and long-term obligations. For our long-term debt as noted in Note 8, “Lines of Credit, Revolving Credit Facilities, and Term Loans” in the notes to the consolidated financial statements, we have a current obligation of $2,039.8 million and a long-term obligation of $2,016.4 million. Additionally, as noted in Note 9, “Convertible Notes” in the notes to the consolidated financial statements, we have a convertible debt obligation of $4,725.0 million. Under our operating leases as noted in Note 10, “Leases” in the notes to the consolidated financial statements, we have a current obligation of $40.6 million and a long-term obligation of $499.0 million. As noted in Note 15, “Commitments and Contingencies” in the notes to the consolidated financial statements, we have current obligations related to non-cancelable purchase commitments of $34.2 billion.

[0001375365-26-000022:mdna:155]
Recent Accounting Pronouncements

[0001375365-26-000022:mdna:156]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report.

[0001375365-26-000022:mdna:157]
SMCI | 2026 Form 10-K | 53
