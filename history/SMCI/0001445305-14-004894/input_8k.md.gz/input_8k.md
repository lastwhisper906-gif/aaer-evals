# SMCI 8-K — 0001445305-14-004352 filed 2014-10-21

## item codes, every 8-K on or before 2014-11-06

- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2014-11-06

- none on or before 2014-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-004352:8k_2_02:1]
EX-99.1
2
exhibit991q12015.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001445305-14-004352:8k_2_02:2]
Exhibit 991 Q12015

[0001445305-14-004352:8k_2_02:3]
Exhibit 99.1

[0001445305-14-004352:8k_2_02:4]
Super Micro Computer, Inc. Announces 1st Quarter 2015 Financial Results

[0001445305-14-004352:8k_2_02:5]
SAN JOSE, Calif., October 21, 2014 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a leader in application optimized, high performance server solutions, today announced first quarter fiscal 2015 financial results for the quarter ended September 30, 2014.

[0001445305-14-004352:8k_2_02:6]
Fiscal 1st Quarter Highlights

[0001445305-14-004352:8k_2_02:7]
| • | Quarterly net sales of $443.3 million, up 3.6% from the fourth quarter of fiscal year 2014 and up 43.5% from the same quarter of last year. |

[0001445305-14-004352:8k_2_02:8]
| • | GAAP net income of $20.9 million, up 26.1% from the fourth quarter of fiscal year 2014 and up 171.0% from the same quarter of last year. |

[0001445305-14-004352:8k_2_02:9]
| • | GAAP gross margin of 15.6%, up from 15.5% in the fourth quarter of fiscal year 2014 and up from 15.1% in the same quarter of last year. |

[0001445305-14-004352:8k_2_02:10]
| • | Server solutions accounted for 57.7% of net sales compared with 55.2% in the fourth quarter of fiscal year 2014 and 46.4% in the same quarter of last year. |

[0001445305-14-004352:8k_2_02:11]
Net sales for the first quarter ended September 30, 2014 totaled $443.3 million, up 3.6% from $428.1 million in the fourth quarter of fiscal year 2014. No customer accounted for more than 10% of net sales during the quarter ended September 30, 2014.

[0001445305-14-004352:8k_2_02:12]
GAAP net income for the first quarter of fiscal year 2015 was $20.9 million or $0.42 per diluted share, an increase of 171.0% from the net income of $7.7 million, or $0.17 per diluted share in the same period a year ago. Included in net income for the quarter is $3.0 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the first quarter was $23.2 million, or $0.46 per diluted share, compared to non-GAAP net income of $9.9 million, or $0.22 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the fourth quarter of fiscal year 2014 by $3.8 million or $0.06 per diluted share.

[0001445305-14-004352:8k_2_02:13]
GAAP gross margin for the first quarter was 15.6% compared to 15.1% in the same period a year ago. Non-GAAP gross margin for the first quarter was 15.7% compared to 15.2% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the fourth quarter of fiscal year 2014 were 15.5% and 15.6%, respectively.

[0001445305-14-004352:8k_2_02:14]
The GAAP income tax provision was $10.6 million or 33.7% of income before tax provision compared to $4.2 million or 35.1% in the same period a year ago and $9.8 million or 37.2% in the fourth quarter of fiscal year 2014.

[0001445305-14-004352:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at September 30, 2014 were $120.2 million compared to $99.6 million at June 30, 2014. Free cash flow for the three months ended September 30, 2014 was $24.3 million, primarily due to an increase in our cash provided by operating activities.

[0001445305-14-004352:8k_2_02:16]
Business Outlook & Management Commentary

[0001445305-14-004352:8k_2_02:17]
The Company expects net sales of $440 million to $480 million for the second quarter of fiscal year 2015 ending December 31, 2014. The Company expects non-GAAP earnings per diluted share of approximately $0.44 to $0.50 for the second quarter.

[0001445305-14-004352:8k_2_02:18]
“We began fiscal 2015 with an exceptional first quarter of record revenue and profits. In the first quarter, we grew revenues 43.5% over last year and posted our fourth consecutive quarter of record results. This again outperformed multiple times the industry growth rate. With 57.7% of our revenue coming from systems based on our Storage, GPU/Xeon Phi, Twin, MicroCloud and Network Switches, we continue to improve margin through a mix of higher value system products," said Charles Liang, Chairman and CEO. “As we ship our latest X10 generation Haswell DP products, a brand new I/O optimized Ultra server architecture and industry-leading hot-swappable NVMe solutions, we are confident our technology innovation will continue to drive our growth momentum into the remainder fiscal 2015."

[0001445305-14-004352:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001445305-14-004352:8k_2_02:20]
Conference Call Information

[0001445305-14-004352:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate the conference, please call 1-888-438-5453 (International callers dial 1-719-785-1753) 10 minutes prior. A recording of the conference will be available until 11:59 pm ET on Tuesday, November 4, 2014 by dialing 1-877-870-5176 (international callers dial 1-858-384-5517) and entering replay PIN 8567910. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001445305-14-004352:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001445305-14-004352:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001445305-14-004352:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001445305-14-004352:8k_2_02:25]
About Super Micro Computer, Inc.

[0001445305-14-004352:8k_2_02:26]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001445305-14-004352:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001445305-14-004352:8k_2_02:28]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001445305-14-004352:8k_2_02:29]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | September 30, |  | June 30, |
|  |  |  |  | 2014 |  | 2014 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 117,512 |  |  | $ | 96,872 |  |
|  | Accounts receivable, net | 194,370 |  |  | 212,738 |  |
|  | Inventory |  | 341,541 |  |  | 315,837 |  |
|  | Deferred income taxes – current | 17,392 |  |  | 16,842 |  |
|  | Prepaid income taxes | 9,578 |  |  | 5,555 |  |
|  | Prepaid expenses and other current assets | 4,709 |  |  | 6,237 |  |
|  |  | Total current assets | 685,102 |  |  | 654,081 |  |
| Long-term investments | 2,647 |  |  | 2,647 |  |
| Property, plant and equipment, net | 133,067 |  |  | 130,589 |  |
| Deferred income taxes – noncurrent |  | 4,631 |  |  | 6,154 |  |
| Other assets |  |  | 2,828 |  |  | 2,854 |  |
|  |  | Total assets | $ | 828,275 |  |  | $ | 796,325 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 222,556 |  |  | $ | 219,354 |  |
|  | Accrued liabilities |  | 35,704 |  |  | 37,564 |  |
|  | Income taxes payable |  | 21,248 |  |  | 11,414 |  |
|  | Short-term debt and current portion of long-term debt | 34,446 |  |  | 42,554 |  |
|  |  | Total current liabilities | 313,954 |  |  | 310,886 |  |
| Long term debt-net of current portion | 3,033 |  |  | 3,733 |  |
| Other long-term liabilities | 12,814 |  |  | 12,475 |  |
|  |  | Total liabilities | 329,801 |  |  | 327,094 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital |  | 207,442 |  |  | 199,062 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (66 | ) |  | (63 | ) |
|  | Retained earnings |  | 292,950 |  |  | 272,087 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 498,296 |  |  | 469,056 |  |
|  | Noncontrolling interest | 178 |  |  | 175 |  |
|  |  | Total liabilities and stockholders' equity | $ | 828,275 |  |  | $ | 796,325 |  |

[0001445305-14-004352:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Net sales | $ | 443,322 |  |  | $ | 309,016 |  |
| Cost of sales | 374,129 |  |  | 262,224 |  |
| Gross profit | 69,193 |  |  | 46,792 |  |
| Operating expenses: |  |  |  |
| Research and development | 21,509 |  |  | 20,236 |  |
| Sales and marketing | 11,002 |  |  | 8,865 |  |
| General and administrative | 5,056 |  |  | 5,648 |  |
| Total operating expenses | 37,567 |  |  | 34,749 |  |
| Income from operations | 31,626 |  |  | 12,043 |  |
| Interest and other income, net | 35 |  |  | 17 |  |
| Interest expense | (196 | ) |  | (195 | ) |
| Income before income tax provision | 31,465 |  |  | 11,865 |  |
| Income tax provision | 10,602 |  |  | 4,166 |  |
| Net income | $ | 20,863 |  |  | $ | 7,699 |  |
| Net income per common share: |  |  |  |
| Basic | $ | 0.46 |  |  | $ | 0.18 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.17 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |
| Basic (a) | 45,473 |  |  | 42,496 |  |
| Diluted (b) | 49,687 |  |  | 44,602 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Cost of sales | $ | 207 |  |  | $ | 235 |  |
| Research and development | 1,896 |  |  | 1,561 |  |
| Sales and marketing | 365 |  |  | 314 |  |
| General and administrative | 512 |  |  | 479 |  |

[0001445305-14-004352:8k_2_02:31]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Three Months EndedSeptember 30, |
|  | 2014 |  | 2013 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 20,863 |  |  | $ | 7,699 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 1,847 |  |  | 1,393 |  |
| Stock-based compensation expense | 2,980 |  |  | 2,589 |  |
| Excess tax benefits from stock-based compensation | (705 | ) |  | (882 | ) |
| Allowance for doubtful accounts | (54 | ) |  | 849 |  |
| Provision for inventory | 1,660 |  |  | 4 |  |
| Exchange loss (gain) | (235 | ) |  | 241 |  |
| Deferred income taxes, net | 973 |  |  | 91 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 18,422 |  |  | 14,435 |  |
| Inventory | (27,364 | ) |  | (144 | ) |
| Prepaid expenses and other assets | 1,547 |  |  | 960 |  |
| Accounts payable | 2,131 |  |  | (7,732 | ) |
| Income taxes payable, net | 6,726 |  |  | 1,841 |  |
| Accrued liabilities | (1,903 | ) |  | (3,207 | ) |
| Other long-term liabilities | 158 |  |  | 170 |  |
| Net cash provided by operating activities | 27,046 |  |  | 18,307 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (2,766 | ) |  | (1,948 | ) |
| Restricted cash | 10 |  |  | (14 | ) |
| Net cash used in investing activities | (2,756 | ) |  | (1,962 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Repayment of debt | (8,500 | ) |  | (700 | ) |
| Proceeds from exercise of stock options | 4,485 |  |  | 1,535 |  |
| Excess tax benefits from stock-based compensation | 705 |  |  | 882 |  |
| Payment of obligations under capital leases | (28 | ) |  | (5 | ) |
| Advances (payments) under receivable financing arrangements | (4 | ) |  | 736 |  |
| Minimum tax withholding paid on behalf of an officer for restricted stock awards | — |  |  | (651 | ) |
| Net cash provided by (used in) financing activities | (3,342 | ) |  | 1,797 |  |
| Effect of exchange rate fluctuations on cash | (308 | ) |  | 278 |  |
| Net increase in cash and cash equivalents | 20,640 |  |  | 18,420 |  |
| Cash and cash equivalents at beginning of period | 96,872 |  |  | 93,038 |  |
| Cash and cash equivalents at end of period | 117,512 |  |  | 111,458 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 202 |  |  | 200 |  |
| Cash paid for taxes, net of refunds | 3,123 |  |  | 1,807 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 256 |  |  | — |  |
| Accrued costs for property, plant and equipment purchases | 2,976 |  |  | 1,836 |  |

[0001445305-14-004352:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2014 |  | 2013 |
| GAAP GROSS PROFIT | $ | 69,193 |  |  | $ | 46,792 |  |
|  | Add back stock-based compensation (c) | 207 |  |  | 235 |  |
| Non-GAAP GROSS PROFIT | $ | 69,400 |  |  | $ | 47,027 |  |
| GAAP GROSS MARGIN | 15.6 | % |  | 15.1 | % |
|  | Add back stock-based compensation (c) | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 15.7 | % |  | 15.2 | % |
| GAAP INCOME FROM OPERATIONS | $ | 31,626 |  |  | $ | 12,043 |  |
|  | Add back stock-based compensation (c) | 2,980 |  |  | 2,589 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 34,606 |  |  | $ | 14,632 |  |
| GAAP NET INCOME | $ | 20,863 |  |  | $ | 7,699 |  |
|  | Add back stock-based compensation (c) | 2,980 |  |  | 2,589 |  |
|  | Add back adjustments to tax benefit (provision) (d) | (658 | ) |  | (414 | ) |
| Non-GAAP NET INCOME | $ | 23,185 |  |  | $ | 9,874 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.46 |  |  | $ | 0.18 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.05 |  |  | 0.05 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.51 |  |  | $ | 0.23 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.42 |  |  | $ | 0.17 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.04 |  |  | 0.05 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.46 |  |  | $ | 0.22 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |
|  | BASIC –GAAP (g) | 45,473 |  |  | 42,496 |  |
|  | BASIC - Non-GAAP (h) | 45,473 |  |  | 42,605 |  |
|  | DILUTED – GAAP (g) | 49,687 |  |  | 44,602 |  |
|  | DILUTED - Non-GAAP (h) | 50,305 |  |  | 44,984 |  |

[0001445305-14-004352:8k_2_02:33]
(a) Approximately $20,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:34]
(b) Approximately $19,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:35]
(c) Amortization of ASC Topic 718 stock-based compensation for the three months ended September 30, 2014 and 2013.

[0001445305-14-004352:8k_2_02:36]
(d) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 32.7% and 31.7% the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004352:8k_2_02:37]
(e) Approximately $25,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:38]
(f) Approximately $24,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:39]
(g) 109,347 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:40]
(h) 109,347 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three months ended September 30, 2013.

[0001445305-14-004352:8k_2_02:41]
SOURCE: Super Micro Computer, Inc.

[0001445305-14-004352:8k_2_02:42]
Super Micro Computer, Inc.

[0001445305-14-004352:8k_2_02:43]
Howard Hideshima, 408-503-8000

[0001445305-14-004352:8k_2_02:44]
SVP, Chief Financial Officer

[0001445305-14-004352:8k_2_02:45]
ir@supermicro.com

[0001445305-14-004352:8k_2_02:46]
or

[0001445305-14-004352:8k_2_02:47]
Perry G. Hayes

[0001445305-14-004352:8k_2_02:48]
SVP, Investor Relations

[0001445305-14-004352:8k_2_02:49]
ir@supermicro.com

[0001445305-14-004352:8k_2_02:50]
SMCI-F
