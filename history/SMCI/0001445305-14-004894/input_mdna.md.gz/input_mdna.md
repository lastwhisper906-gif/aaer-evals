# SMCI MD&A — 0001445305-14-004894


## mdna

[0001445305-14-004894:mdna:1]
[same as prior period, unchanged from 0001445305-14-001932:mdna:1]

[0001445305-14-004894:mdna:2]
[same as prior period, unchanged from 0001445305-14-001932:mdna:2]

[0001445305-14-004894:mdna:3]
We are a global leader in high-performance, high-efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the Data Center, Cloud Computing, Enterprise IT, Big Data, HPC and Embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. For the three months ended September 30, 2014 and 2013, net sales of optimized servers were $255.6 million and $143.3 million, respectively, and net sales of subsystems and accessories were $187.7 million and $165.7 million, respectively. The increase in our net sales in the three months ended September 30, 2014 compared with the three months ended September 30, 2013 was primarily due to our continued increased sales of our complete integrated-high-end server solutions such as the Twin family of servers, storage, and GPU/Xeon Phi servers which offered higher density computing and more memory and hard disk drive capacity. The percentage of our net sales represented by sales of complete server systems increased to 57.7% in the three months ended September 30, 2014 from 46.4% in the three months ended September 30, 2013.

[0001445305-14-004894:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales were $443.3 million and $309.0 million for the three months ended September 30, 2014 and 2013, respectively. Our net income was $20.9 million and $7.7 million for the three months ended September 30, 2014 and 2013, respectively. Our increase in net income in the three months ended September 30, 2014 was primarily attributable to an increase in our gross profit resulting primarily from higher sales of server systems, higher utilization of our manufacturing facilities in Taiwan and a $1.9 million refund of  value added taxes on research and development expenses, partially offset by higher income tax expenses.

[0001445305-14-004894:mdna:5]
We sell our server systems and subsystems and accessories primarily through distributors and to a lesser extent to Building Block Solution Original Equipment Manufacturers, or OEMs, as well as through our direct sales force. For the three months ended September 30, 2014 and 2013, we derived 56.0% and 60.9%, respectively, of our net sales from products sold to distributors, and derived 44.0% and 39.1% from sales to OEMs and to end customers, respectively. None of our customers accounted for 10% or more of our net sales in the three months ended September 30, 2014 and 2013. We derived 54.9% and 56.7% of our net sales from customers in the United States for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 4.9% and 6.5% of our net sales for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2015, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands to support our Asian and European customers and we have increased our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three months ended September 30, 2014 and 2013, our purchases from Ablecom represented 14.5% and 17.3% of our cost of sales, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-

[0001445305-14-004894:mdna:8]
WEST\249206192.2                                           18

[0001445305-14-004894:mdna:9]
negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001445305-14-004894:mdna:10]
[same as prior period, unchanged from 0001445305-14-001932:mdna:9]

[0001445305-14-004894:mdna:11]
[same as prior period, unchanged from 0001445305-14-001932:mdna:10]

[0001445305-14-004894:mdna:12]
The following is a summary of other financial highlights of the first quarter of fiscal year 2015:

[0001445305-14-004894:mdna:13]
| • | Net cash provided by operating activities was $27.0 million and $18.3 million during the three months ended September 30, 2014 and 2013, respectively. Our cash and cash equivalents, together with our investments, were $120.2 million at the end of first quarter of fiscal year 2015, compared with $99.6 million at the end of fiscal year 2014. The increase in our cash and cash equivalents, together with our investments at the end of first quarter of fiscal year 2015 was primarily due to $27.0 million of cash generated from our operating activities, $4.5 million of proceeds from the exercise of stock options, offset in part by $8.5 million of repayments in loans and $2.8 million of purchases of property and equipment. |

[0001445305-14-004894:mdna:14]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the first quarter of fiscal year 2015 and at the end of the fourth quarter of fiscal year 2014 was both 42 days. |

[0001445305-14-004894:mdna:15]
| • | Our inventory balance was $341.5 million at the end of the first quarter of fiscal year 2015, compared with $315.8 million at the end of the fiscal year 2014. Days sales of inventory (“DSI”) at the end of the first quarter of fiscal year 2015 was 81 days, compared with 77 days at the end of the fourth quarter of fiscal year 2014. The increase in our inventory was to support our anticipated level of growth in net sales in fiscal year 2015 and the transition to Intel's Haswell DP processor based products. |

[0001445305-14-004894:mdna:16]
| • | Our purchase commitments with contract manufacturers and suppliers were $226.5 million at the end of the first quarter of fiscal year 2015 and $211.1 million at the end of the fiscal year 2014. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $29.2 million, which have terms expiring through December 2014. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001445305-14-004894:mdna:17]
[same as prior period, unchanged from 0001445305-14-001932:mdna:16]

[0001445305-14-004894:mdna:18]
Our fiscal year ends on June 30. References to fiscal year 2015, for example, refer to the fiscal year ending June 30, 2015.

[0001445305-14-004894:mdna:19]
WEST\249206192.2                                           19

[0001445305-14-004894:mdna:20]
[same as prior period, unchanged from 0001445305-14-001932:mdna:18]

[0001445305-14-004894:mdna:21]
[same as prior period, unchanged from 0001445305-14-001932:mdna:19]

[0001445305-14-004894:mdna:22]
[same as prior period, unchanged from 0001445305-14-001932:mdna:20]

[0001445305-14-004894:mdna:23]
Research and development expenses. Research and development expenses consist of the personnel and related expenses of our research and development teams, and materials and supplies, consulting services, third party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering, or NRE, funding from certain suppliers and customers. Under these programs, we are reimbursed for certain research and development costs that we incur as part of the joint development of our products and those of our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001445305-14-004894:mdna:24]
[same as prior period, unchanged from 0001445305-14-001932:mdna:22]

[0001445305-14-004894:mdna:25]
[same as prior period, unchanged from 0001445305-14-001932:mdna:23]

[0001445305-14-004894:mdna:26]
[same as prior period, unchanged from 0001445305-14-001932:mdna:24]

[0001445305-14-004894:mdna:27]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, currently primarily the United States, Taiwan, the Netherlands, and to a lesser extent, China and Japan. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, the domestic production activities deduction and lower taxes in foreign jurisdictions which were partially offset by the impact of state taxes and stock option expenses. In recent years, our effective tax rate from period to period has been significantly impacted by delays in the approval of extensions of the U.S. research and development tax credit. If Congress extends the research and development tax credit within our fiscal year 2015, there will be a favorable impact on our effective income tax rate.

[0001445305-14-004894:mdna:28]
WEST\249206192.2                                           20

[0001445305-14-004894:mdna:29]
[same as prior period, unchanged from 0001445305-14-001932:mdna:26]

[0001445305-14-004894:mdna:30]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, cooperative marketing accruals, investment valuations, inventory valuations, income taxes, warranty obligations and stock-based compensation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates.

[0001445305-14-004894:mdna:31]
[same as prior period, unchanged from 0001445305-14-001932:mdna:29]

[0001445305-14-004894:mdna:32]
Revenue recognition. We recognize revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. Our standard arrangement with our customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination. We generally do not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, we regularly review our history of actual returns for each major product line. We also communicate regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with our distributors.

[0001445305-14-004894:mdna:33]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At September 30, 2014 and June 30, 2014, we had deferred revenue of $43,000 and $7.7 million and related deferred product costs of $38,000 and $6.7 million, respectively, related to shipments to customers pending acceptances.

[0001445305-14-004894:mdna:34]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision (recovery) for bad debt was $(54,000) and $0.8 million in the three months ended September 30, 2014 and 2013, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001445305-14-004894:mdna:35]
We  have an immaterial amount of service revenue relating to on-site service and non-warranty repairs. Revenue for on-site service is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001445305-14-004894:mdna:36]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are

[0001445305-14-004894:mdna:37]
WEST\249206192.2                                           21

[0001445305-14-004894:mdna:38]
charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.1 million as of September 30, 2014 and June 30, 2014. The provision for warranty reserve was $3.7 million and $3.4 million in the three months ended September 30, 2014 and 2013, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was ($0.2) million and $45,000 in the three months ended September 30, 2014 and 2013, respectively. As a result of our increase in cost of servicing warranty claims from our increase in net sales in the three months ended September 30, 2014 and 2013, the provision for warranty reserve increased $0.2 million compared to the three months ended September 30, 2013. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001445305-14-004894:mdna:39]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $1.7 million and $4,000 in the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:40]
[same as prior period, unchanged from 0001445305-14-001932:mdna:37]

[0001445305-14-004894:mdna:41]
[same as prior period, unchanged from 0001445305-14-001932:mdna:38]

[0001445305-14-004894:mdna:42]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors including employee stock options and restricted stock awards based on estimated fair values. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. Compensation expense for options and restricted stock awards granted to employees was $3.0 million and $2.6 million for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:43]
As of September 30, 2014, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options granted since July 1, 2006 to employees and non-employee members of the Board of Directors, was $20.3 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.37 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001445305-14-004894:mdna:44]
[same as prior period, unchanged from 0001445305-14-001932:mdna:41]

[0001445305-14-004894:mdna:45]
WEST\249206192.2                                           22

[0001445305-14-004894:mdna:46]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and exercise behavior for the stock options granted prior to June 30, 2011. For stock options and restricted stock awards granted after June 30, 2011, expected term is based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001445305-14-004894:mdna:47]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001445305-14-004894:mdna:48]
In May 2012, we and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of September 30, 2014, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2014 and 2013, $3,000 and $(6,000) of net income (loss) attributable to Ablecom's interest was included in our general and administrative expenses in the consolidated statements of operations, respectively.

[0001445305-14-004894:mdna:49]
[same as prior period, unchanged from 0001445305-14-001932:mdna:47]

[0001445305-14-004894:mdna:50]
[same as prior period, unchanged from 0001445305-14-001932:mdna:48]

[0001445305-14-004894:mdna:51]
|  | Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Net sales | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.4 |  |  | 84.9 |  |
| Gross profit | 15.6 |  |  | 15.1 |  |
| Operating expenses: |  |  |  |
| Research and development | 4.9 |  |  | 6.5 |  |
| Sales and marketing | 2.5 |  |  | 2.9 |  |
| General and administrative | 1.1 |  |  | 1.8 |  |
| Total operating expenses | 8.5 |  |  | 11.2 |  |
| Income from operations | 7.1 |  |  | 3.9 |  |
| Interest and other income, net | — |  |  | — |  |
| Interest expense | — |  |  | (0.1 | ) |
| Income before income tax provision | 7.1 |  |  | 3.8 |  |
| Income tax provision | 2.4 |  |  | 1.3 |  |
| Net income | 4.7 | % |  | 2.5 | % |

[0001445305-14-004894:mdna:52]
WEST\249206192.2                                           23

[0001445305-14-004894:mdna:53]
Comparison of Three Months Ended September 30, 2014 and 2013

[0001445305-14-004894:mdna:54]
Net sales. Net sales increased by $134.3 million, or 43.5%, to $443.3 million from $309.0 million, for the three months ended September 30, 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001445305-14-004894:mdna:55]
For the three months ended September 30, 2014, the number of server system units sold increased 29.1% to 71,000 compared to 55,000 for the three months ended September 30, 2013. The average selling price of server system units increased 38.5% to $3,600 in the three months ended September 30, 2014 compared to $2,600 in the three months ended September 30, 2013. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete integrated-high-end servers solutions such as the Twin family of servers, storage and GPU/Xeon Phi servers which offered higher density computing and more memory and hard disk drive capacity. Sales of server systems increased by $112.3 million or 78.4% from the three months ended September 30, 2013 to the three months ended September 30, 2014, primarily due to the increased sales of the products described above. Sales of server systems represented 57.7% of our net sales for the three months ended September 30, 2014 compared to 46.4% of our net sales for the three months ended September 30, 2013.

[0001445305-14-004894:mdna:56]
For the three months ended September 30, 2014, the number of subsystems and accessories units sold increased 18.8% to 1.3 million compared to 1.1 million for the three months ended September 30, 2013. Sales of subsystems and accessories increased by $22.0 million or 13.3% from the three months ended September 30, 2013 to the three months ended September 30, 2014, primarily related to higher sales of hard disk drives and memory bundled with our server solutions sold to our distributors and system integrators who are purchasing additional accessories from us and completing the final assembly themselves. Sales of subsystems and accessories represented 42.3% of our net sales for the three months ended September 30, 2014 as compared to 53.6% of our net sales for the three months ended September 30, 2013.

[0001445305-14-004894:mdna:57]
For the three months ended September 30, 2014 and 2013, we derived 56.0% and 60.9%, respectively, of our net sales from products sold to distributors and we derived 44.0% and 39.1%, respectively, from sales to OEMs and to end customers. For the three months ended September 30, 2014, customers in the United States, Europe and Asia accounted for 54.9%, 20.2% and 19.9%, of our net sales, respectively, as compared to 56.7%, 23.0% and 17.8% of our net sales, respectively, for the three months ended September 30, 2013.

[0001445305-14-004894:mdna:58]
Cost of sales. Cost of sales increased by $111.9 million, or 42.7%, to $374.1 million from $262.2 million, for the three months ended September 30, 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 84.4% and 84.9% for the three months ended September 30, 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales and an increase of $1.7 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to an increase in purchasing power, an increase in the mix of complete server system sales and higher utilization of our manufacturing facilities in Taiwan offset in part by higher internet data center sales which generally have a lower margin. In the three months ended September 30, 2014, we recorded a $1.7 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $4,000, or 0.0% of net sales, in the three months ended September 30, 2013. The increase in the inventory provision was primarily due to higher inventory reserves for earlier generation products partially offset by higher sales of previously reserved inventory of $2.1 million.

[0001445305-14-004894:mdna:59]
In the three months ended September 30, 2014, we recorded a $3.7 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to $3.4 million, or 1.1% of net sales, in the three months ended September 30, 2013. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the three months ended September 30, 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001445305-14-004894:mdna:60]
Research and development expenses. Research and development expenses increased by $1.3 million, or 6.3%, to $21.5 million from $20.2 million, for the three months ended September 30, 2014 and 2013, respectively. Research and development expenses were 4.9% and 6.5% of net sales for the three months ended September 30, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $4.2 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan, partially offset by a $1.9 million refund of value added taxes on research and development expenses and an increase of $0.7 million in non-recurring engineering funding from certain suppliers and customers. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended September 30, 2014.

[0001445305-14-004894:mdna:61]
WEST\249206192.2                                           24

[0001445305-14-004894:mdna:62]
Research and development expenses include stock-based compensation expense of $1.9 million and $1.6 million for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:63]
Sales and marketing expenses. Sales and marketing expenses increased by $2.1 million, or 24.1%, to $11.0 million from $8.9 million, for the three months ended September 30, 2014 and 2013, respectively. Sales and marketing expenses were 2.5% and 2.9% of net sales for the three months ended September 30, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $1.7 million in compensation and benefits resulting from growth in sales and marketing personnel. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended September 30, 2014.

[0001445305-14-004894:mdna:64]
Sales and marketing expenses include stock-based compensation expense of $0.4 million and $0.3 million for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:65]
General and administrative expenses. General and administrative expenses decreased by $0.6 million, or 10.5%, to $5.1 million from $5.6 million, for the three months ended September 30, 2014 and 2013, respectively. General and administrative expenses were 1.1% and 1.8% of net sales for the three months ended September 30, 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to a decrease of $0.9 million in bad debt expenses, an increase of $0.7 million in foreign currency transaction gain, offset in part by a decrease of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor in the prior year. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended September 30, 2014.

[0001445305-14-004894:mdna:66]
General and administrative expenses include stock-based compensation expense of $0.5 million for both three months ended September 30, 2014 and 2013.

[0001445305-14-004894:mdna:67]
Interest and other expense, net. Interest and other expense, net, was $0.2 million of expense for both three months ended September 30, 2014 and 2013, represented interest expense for both three months ended September 30, 2014 and 2013.

[0001445305-14-004894:mdna:68]
Provision for income taxes. Provision for income taxes increased by $6.4 million, or 154.5%, to $10.6 million from $4.2 million, for the three months ended September 30, 2014 and 2013, respectively. The effective tax rate was 33.7% and 35.1% for the three months ended September 30, 2014 and 2013, respectively. The higher income tax provision for the three months ended September 30, 2014 was primarily attributable to our higher operating income.

[0001445305-14-004894:mdna:69]
[same as prior period, unchanged from 0001445305-14-001932:mdna:80]

[0001445305-14-004894:mdna:70]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $117.6 million and $96.9 million as of September 30, 2014 and June 30, 2014, respectively. Our cash in foreign locations was $42.1 million and $28.3 million at September 30, 2014 and June 30, 2014, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001445305-14-004894:mdna:71]
Operating Activities. Net cash provided by operating activities was $27.0 million and $18.3 million for the three months ended September 30, 2014 and 2013, respectively.

[0001445305-14-004894:mdna:72]
Net cash provided by our operating activities for the three months ended September 30, 2014 was primarily due to our net income of $20.9 million, a decrease in accounts receivable of $18.4 million, an increase in net income taxes payable of $6.7 million, stock-based compensation expense of $3.0 million, an increase in accounts payable of $2.1 million, depreciation expense of $1.8 million, a decrease in prepaid expenses and other assets of $1.5 million, which were partially offset by an increase in inventory of $27.4 million and a decrease in accrued liabilities of $1.9 million.

[0001445305-14-004894:mdna:73]
Net cash provided by our operating activities for the three months ended September 30, 2013 was primarily due to our net income of $7.7 million, a decrease in accounts receivable of $14.4 million, stock-based compensation expense of $2.6 million, an increase in net income tax payable of $1.8 million, depreciation expense of $1.4 million and a decrease in prepaid expenses and other assets of $1.0 million, which were partially offset by a decrease in accounts payable of $7.7 million and a decrease in accrued liabilities of $3.2 million.

[0001445305-14-004894:mdna:74]
WEST\249206192.2                                           25

[0001445305-14-004894:mdna:75]
The decrease for the three months ended September 30, 2014 in accounts receivable was primarily due to higher accounts receivable collection in the first quarter of fiscal year 2015 partially offset by an increase in our net sales late in the first quarter. The increase for the three months ended September 30, 2014 in inventory and accounts payable was primarily due to higher purchases to support the anticipated level of growth in our net sales in the second quarter of fiscal year 2015. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001445305-14-004894:mdna:76]
The decrease for the three months ended September 30, 2013 in accounts receivable was primarily due to a lower net sales in the first quarter of fiscal year 2014. The decrease for the three months ended September 30, 2013 in accounts payable was due to lower cost of goods sold in the first quarter of fiscal year 2014.

[0001445305-14-004894:mdna:77]
Investing activities. Net cash used in our investing activities was $2.8 million and $2.0 million for the three months ended September 30, 2014 and 2013, respectively. In the three months ended September 30, 2014 and 2013, $2.8 million and $1.9 million, respectively, was related to the purchase of property, plant and equipment.

[0001445305-14-004894:mdna:78]
We plan to develop five manufacturing buildings through fiscal 2016 on the real property we purchased in San Jose, California, to serve as our Green Computing Park. We anticipate the costs of approximately $22.1 million during fiscal year 2015. We plan to finance this development through our operating cash flows and additional borrowings from banks.

[0001445305-14-004894:mdna:79]
Financing activities. Net cash provided by (used in) our financing activities was $(3.3) million and $1.8 million for the three months ended September 30, 2014 and 2013, respectively. In the three months ended September 30, 2014, we received $4.5 million related to the proceeds from the exercise of stock options. Further, we repaid $8.5 million in loans in the three months ended September 30, 2014.We expect the net cash provided by financing activities will increase throughout fiscal year 2015 as we intend to obtain additional financing from banks to construct our manufacturing buildings at our Green Computing Park in San Jose, California.

[0001445305-14-004894:mdna:80]
In the three months ended September 30, 2013, we received $1.5 million related to the proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding on behalf of one executive officer for his restricted stock awards of $0.7 million for the three months ended September 30, 2013. Further, we received $0.7 million in advance from our receivable financing arrangements and repaid $0.7 million in loans in the three months ended September 30, 2013. In the three months ended September 30, 2013, excess tax benefits from stock-based compensation were $0.9 million.

[0001445305-14-004894:mdna:81]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001445305-14-004894:mdna:82]
[same as prior period, unchanged from 0001445305-14-001932:mdna:93]

[0001445305-14-004894:mdna:83]
[same as prior period, unchanged from 0001445305-14-001932:mdna:94]

[0001445305-14-004894:mdna:84]
[same as prior period, unchanged from 0001445305-14-001932:mdna:95]

[0001445305-14-004894:mdna:85]
In October 2011, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $40.0 million revolving line of credit facility through June 15, 2013 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit to November 15, 2014. We are currently negotiating with Bank of America to renew the revolving line of credit.

[0001445305-14-004894:mdna:86]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at September 30, 2014. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001445305-14-004894:mdna:87]
WEST\249206192.2                                           26

[0001445305-14-004894:mdna:88]
As of September 30, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $5.8 million and $6.5 million, respectively. The total outstanding borrowings under the Bank of America line of credit was $9.9 million and $17.7 million as of September 30, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.19% to 1.66% per annum at September 30, 2014 and 1.19% to 1.65% per annum at June 30, 2014, respectively. As of September 30, 2014, the unused revolving line of credit under Bank of America was $30.1 million.

[0001445305-14-004894:mdna:89]
[same as prior period, unchanged from 0001445305-14-001932:mdna:99]

[0001445305-14-004894:mdna:90]
In October 2011, we obtained an unsecured revolving line of credit from CTBC Bank totaling NT$300.0 million or $9.9 million U.S. dollars equivalents. In July 2012, we increased the credit line to NT$450.0 million or $14.9 million U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate at the lender's established interest rate plus 0.3% which is adjusted monthly.

[0001445305-14-004894:mdna:91]
In November 2013, we entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700.0 million or $23.8 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100.0 million or $3.4 million U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500.0 million or $17.0 million U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $34.0 million U.S. dollar equivalents.

[0001445305-14-004894:mdna:92]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21.7 million and $22.1 million as of September 30, 2014 and 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at September 30, 2014 and 2013. The interest rate for the loan was at 1.16% and 1.15% per annum at June 30, 2014 and 2013, respectively. At September 30, 2014, NT$340.0 million or $11.2 million U.S. dollar equivalents were available for future borrowing under this credit agreement. We are currently negotiating with CTBC Bank to renew the credit agreement.

[0001445305-14-004894:mdna:93]
Covenant Compliance

[0001445305-14-004894:mdna:94]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001445305-14-004894:mdna:95]
[same as prior period, unchanged from 0001445305-14-001932:mdna:105]

[0001445305-14-004894:mdna:96]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001445305-14-004894:mdna:97]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001445305-14-004894:mdna:98]
As of September 30, 2014, our total assets of $783.5 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of September 30, 2014, total assets collateralizing the term loan with Bank of America were $17.5 million. As of September 30, 2014, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001445305-14-004894:mdna:99]
As of September 30, 2014, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.2 million. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2014.

[0001445305-14-004894:mdna:100]
WEST\249206192.2                                           27

[0001445305-14-004894:mdna:101]
[same as prior period, unchanged from 0001445305-14-001932:mdna:110]

[0001445305-14-004894:mdna:102]
For the three months ended September 30, 2014, we paid our contract manufacturers within 43 to 71 days of invoice and Ablecom between 52 to 66 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of September 30, 2014 and June 30, 2014, amounts owed to Ablecom by us were approximately $45.1 million and $49.0 million, respectively.

[0001445305-14-004894:mdna:103]
[same as prior period, unchanged from 0001445305-14-001932:mdna:112]

[0001445305-14-004894:mdna:104]
As of September 30, 2014, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AAA or AA2 at September 30, 2014. These auction rate preferred shares have no stated maturity date.

[0001445305-14-004894:mdna:105]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2014, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at September 30, 2014, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three months ended September 30, 2014 and 2013, there was no auction rate securities redeemed or sold.

[0001445305-14-004894:mdna:106]
[same as prior period, unchanged from 0001445305-14-001932:mdna:115]

[0001445305-14-004894:mdna:107]
The following table describes our contractual obligations as of September 30, 2014:

[0001445305-14-004894:mdna:108]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 2,968 |  |  | $ | 959 |  |  | $ | 17 |  |  | $ | — |  |  | $ | 3,944 |  |
| Capital leases, including interest | 159 |  |  | 299 |  |  | 185 |  |  | — |  |  | 643 |  |
| Long-term debt, including interest (1) | 34,528 |  |  | 3,065 |  |  | — |  |  | — |  |  | 37,593 |  |
| Purchase commitments (2) | 226,532 |  |  | — |  |  | — |  |  | — |  |  | 226,532 |  |
| Total (3) | $ | 264,187 |  |  | $ | 4,323 |  |  | $ | 202 |  |  | $ | — |  |  | $ | 268,712 |  |

[0001445305-14-004894:mdna:109]
[same as prior period, unchanged from 0001445305-14-001932:mdna:118]

[0001445305-14-004894:mdna:110]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at September 30, 2014. |

[0001445305-14-004894:mdna:111]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $29.2 million of hard disk drive purchase commitments at September 30, 2014, which will be paid through December 2014. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001445305-14-004894:mdna:112]
| (3) | The table above excludes liabilities for deferred revenue for warranty and on-site services of $6.6 million and unrecognized tax benefits and related interest and penalties accrual of $9.2 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. |

[0001445305-14-004894:mdna:113]
[same as prior period, unchanged from 0001445305-14-001932:mdna:122]

[0001445305-14-004894:mdna:114]
[same as prior period, unchanged from 0001445305-14-001932:mdna:123]

[0001445305-14-004894:mdna:115]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral

[0001445305-14-004894:mdna:116]
WEST\249206192.2                                           28

[0001445305-14-004894:mdna:117]
rights) within a foreign entity. The adoption of this guidance did not have a material impact on our results of operations or financial position.

[0001445305-14-004894:mdna:118]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The adoption of this guidance did not have a material impact on our results of operations or financial position.

[0001445305-14-004894:mdna:119]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for us on July 1, 2017. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations or financial position.

[0001445305-14-004894:mdna:120]
[same as prior period, unchanged from 0001445305-14-001932:mdna:127]

[0001445305-14-004894:mdna:121]
[same as prior period, unchanged from 0001445305-14-001932:mdna:128]
