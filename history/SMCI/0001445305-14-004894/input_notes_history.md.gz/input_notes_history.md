# SMCI note change history — 0001445305-14-001932 → 0001445305-14-004894


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001445305-14-004894:note_history:1]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.
  (was, 2014-05-07, similarity 0.9855):
[0001445305-14-001932:note_history:1]
Litigation and Claims — The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s condensed consolidated financial condition, results of operations or liquidity.

- added (2014-11-06):
[0001445305-14-004894:note_history:2]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of September 30, 2014, these remaining non-cancellable commitments were $226,532,000 compared to $211,090,000 as of June 30, 2014.

- removed (2014-11-06):
[0001445305-14-001932:note_history:3]
Purchase Commitments — The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of March 31, 2014, these remaining non-cancellable commitments were $271,209,000 compared to $249,005,000 at June 30, 2013. The increase was primarily due to support the growth of the Company's revenue.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2014-11-06):
[0001445305-14-004894:note_history:4]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in San Jose, California, the Netherlands, Taiwan, China and Japan.
  (was, 2014-05-07, similarity 0.9677):
[0001445305-14-001932:note_history:4]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in San Jose, California, the Netherlands, Taiwan and China.

- changed (2014-11-06):
[0001445305-14-004894:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.
  (was, 2014-05-07, similarity 0.7227):
[0001445305-14-001932:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2014.

- added (2014-11-06):
[0001445305-14-004894:note_history:6]
The Company consolidates its investment in Super Micro Business Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.

- changed (2014-11-06):
[0001445305-14-004894:note_history:7]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.
  (was, 2014-05-07, similarity 0.7788):
[0001445305-14-001932:note_history:7]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. The Company is currently reviewing the provisions but does not expect it to have a material impact on the Company’s financial statement disclosures, results of operations or financial position.

- changed (2014-11-06):
[0001445305-14-004894:note_history:8]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.
  (was, 2014-05-07, similarity 0.8742):
[0001445305-14-001932:note_history:8]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company currently plans to adopt the new disclosure requirement on July 1, 2014. The Company does not believe the adoption of this guidance will have a material impact on its financial statement disclosures, results of operations or financial position.

- added (2014-11-06):
[0001445305-14-004894:note_history:9]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations or financial position.

- removed (2014-11-06):
[0001445305-14-001932:note_history:10]
As of March 31, 2014, the Company contributed $168,000 and owned a 50% interest in Super Micro Business Park, Inc. ("Management Company") in Taiwan. The Management Company was established to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. The Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. Therefore, the accounts of the Management Company have been consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income(loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.

- removed (2014-11-06):
[0001445305-14-001932:note_history:11]
In February 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance associated with reporting of amounts reclassified out of accumulated other comprehensive income, which requires companies to present significant reclassifications out of accumulated other comprehensive income in their entirety in the statement of operations or in a separate footnote to the financial statements. For amounts that are not required to be reclassified in their entirety to net income, the standard requires companies to cross-reference to related footnoted disclosures. The new disclosure requirements are effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2012 and early adoption is permitted. The adoption of this guidance did not have a material impact on the Company's financial statement disclosures, results of operations or financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001445305-14-004894:note_history:12]
Short-term and long-term obligations as of September 30, 2014 and June 30, 2014 consisted of the following (in thousands):
  (was, 2014-05-07, similarity 0.9545):
[0001445305-14-001932:note_history:12]
Short-term and long-term obligations as of March 31, 2014 and June 30, 2013 consisted of the following (in thousands):

- changed (2014-11-06):
[0001445305-14-004894:note_history:13]
|  | September 30, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 9,899 |  |  | $ | 17,699 |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,833 |  |  | 6,533 |  |
| CTBC Bank | 21,747 |  |  | 22,055 |  |
| Total building term loans | 27,580 |  |  | 28,588 |  |
| Total debt | 37,479 |  |  | 46,287 |  |
| Current portion | (34,446 | ) |  | (42,554 | ) |
| Long-term portion | $ | 3,033 |  |  | $ | 3,733 |  |
  (was, 2014-05-07, similarity 0.882):
[0001445305-14-001932:note_history:13]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,233 |  |  | 9,333 |  |
| CTBC Bank | 21,631 |  |  | 14,939 |  |
| Total building term loans | 28,864 |  |  | 24,272 |  |
| Total debt | 46,563 |  |  | 35,171 |  |
| Current portion | (42,130 | ) |  | (28,638 | ) |
| Long-term portion | $ | 4,433 |  |  | $ | 6,533 |  |

- changed (2014-11-06):
[0001445305-14-004894:note_history:14]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2014. The Company is currently negotiating with Bank of America to renew the revolving line of credit.
  (was, 2014-05-07, similarity 0.9045):
[0001445305-14-001932:note_history:14]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America, N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to August 15, 2014.

- changed (2014-11-06):
[0001445305-14-004894:note_history:15]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.16% at September 30, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.
  (was, 2014-05-07, similarity 0.9836):
[0001445305-14-001932:note_history:15]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at March 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- changed (2014-11-06):
[0001445305-14-004894:note_history:16]
As of September 30, 2014 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $5,833,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $9,899,000 and $17,699,000 as of September 30, 2014 and June 30, 2014, respectively. The interest rates for these loans ranged from 1.19% to 1.66% per annum at September 30, 2014 and from 1.19%  to 1.65% per annum at June 30, 2014, respectively. As of September 30, 2014, the unused revolving line of credit with Bank of America was $30,101,000.
  (was, 2014-05-07, similarity 0.8013):
[0001445305-14-001932:note_history:16]
As of March 31, 2014 and June 30, 2013, the total outstanding borrowings under the Bank of America term loan was $7,233,000 and $9,333,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $17,699,000 as of March 31, 2014 and $10,899,000 as of June 30, 2013, respectively. The interest rates for these loans ranged from 1.19% to 1.65% per annum at March 31, 2014 and 1.23% to 1.69% per annum at June 30, 2013, respectively. As of March 31, 2014, the unused revolving line of credit with Bank of America was $22,301,000.

- added (2014-11-06):
[0001445305-14-004894:note_history:17]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollars or $9,898,000 U.S. dollars equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollars or $14,912,000 U.S. dollars equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

- changed (2014-11-06):
[0001445305-14-004894:note_history:18]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.
  (was, 2014-05-07, similarity 0.986):
[0001445305-14-001932:note_history:18]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established New Taiwan Dollar ("NTD") interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

- added (2014-11-06):
[0001445305-14-004894:note_history:19]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,747,000 and $22,055,000 at September 30, 2014 and June 30, 2014, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at September 30, 2014 and June 30, 2014. The interest rate for the loan was at 1.16% and 1.15% per annum at September 30, 2014 and June 30, 2014, respectively. At September 30, 2014, NT$340,000,000 or $11,203,000 U.S. dollar equivalents were available for future borrowing under this credit agreement. The Company is currently negotiating with CTBC Bank to renew the credit agreement.

- added (2014-11-06):
[0001445305-14-004894:note_history:20]
As of September 30, 2014 and June 30, 2014, the total assets of $783,506,000 and $751,396,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan, As of September 30, 2014 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,526,000 and $17,584,000, respectively. As of September 30, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

- changed (2014-11-06):
[0001445305-14-004894:note_history:21]
As of September 30, 2014 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,243,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2014.
  (was, 2014-05-07, similarity 0.8924):
[0001445305-14-001932:note_history:21]
As of March 31, 2014 and June 30, 2013, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,394,000 and $27,702,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2014.

- removed (2014-11-06):
[0001445305-14-001932:note_history:22]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000, or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which was adjusted monthly.

- removed (2014-11-06):
[0001445305-14-001932:note_history:23]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,631,000 and $14,939,000 at March 31, 2014 and June 30, 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at March 31, 2014 and June 30, 2013. The interest rate for the loan was at 1.13% per annum at March 31, 2014 and was at 1.20% per annum at June 30, 2013. At March 31, 2014, NT$340,000,000 or $11,143,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

- removed (2014-11-06):
[0001445305-14-001932:note_history:24]
As of March 31, 2014 and June 30, 2013, total assets of $705,506,000 and $586,742,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings located in San Jose, California and the land and building located in Bade, Taiwan. As of March 31, 2014 and June 30, 2013, total assets collateralizing the term loan with Bank of America were $17,641,000 and $17,813,000, respectively. As of March 31, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-11-06):
[0001445305-14-004894:note_history:25]
Long-term Investments

- added (2014-11-06):
[0001445305-14-004894:note_history:26]
As of September 30, 2014 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at September 30, 2014 and June 30, 2014. These auction rate preferred shares have no stated maturity date.

- added (2014-11-06):
[0001445305-14-004894:note_history:27]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2014 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.

- added (2014-11-06):
[0001445305-14-004894:note_history:28]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of September 30, 2014 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of September 30, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.6%, 3 years and 0.3%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

- added (2014-11-06):
[0001445305-14-004894:note_history:29]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three months ended September 30, 2014 and 2013. There was a cumulative total decline of $103,000 as of September 30, 2014 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of September 30, 2014 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

- added (2014-11-06):
[0001445305-14-004894:note_history:30]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three months ended September 30, 2014 and 2013, there was no auction rate securities redeemed or sold.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001445305-14-004894:note_history:31]
Short-term and long-term obligations as of September 30, 2014 and June 30, 2014 consisted of the following (in thousands):
  (was, 2014-05-07, similarity 0.9545):
[0001445305-14-001932:note_history:31]
Short-term and long-term obligations as of March 31, 2014 and June 30, 2013 consisted of the following (in thousands):

- changed (2014-11-06):
[0001445305-14-004894:note_history:32]
|  | September 30, 2014 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 9,899 |  |  | $ | 17,699 |  |
| Total line of credit | 9,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 5,833 |  |  | 6,533 |  |
| CTBC Bank | 21,747 |  |  | 22,055 |  |
| Total building term loans | 27,580 |  |  | 28,588 |  |
| Total debt | 37,479 |  |  | 46,287 |  |
| Current portion | (34,446 | ) |  | (42,554 | ) |
| Long-term portion | $ | 3,033 |  |  | $ | 3,733 |  |
  (was, 2014-05-07, similarity 0.882):
[0001445305-14-001932:note_history:32]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,233 |  |  | 9,333 |  |
| CTBC Bank | 21,631 |  |  | 14,939 |  |
| Total building term loans | 28,864 |  |  | 24,272 |  |
| Total debt | 46,563 |  |  | 35,171 |  |
| Current portion | (42,130 | ) |  | (28,638 | ) |
| Long-term portion | $ | 4,433 |  |  | $ | 6,533 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0001445305-14-004894:note_history:33]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at September 30, 2014.
  (was, 2014-05-07, similarity 0.9908):
[0001445305-14-001932:note_history:33]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at March 31, 2014.

- changed (2014-11-06):
[0001445305-14-004894:note_history:34]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $54,403,000 and $45,317,000, and sold products to Ablecom totaling $26,578,000 and $3,528,000 for the three months ended September 30, 2014 and 2013, respectively.
  (was, 2014-05-07, similarity 0.7132):
[0001445305-14-001932:note_history:34]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $45,398,000 and $145,139,000 and sold products to Ablecom totaling $3,418,000 and $10,805,000 for the three and nine months ended March 31, 2014, respectively. The Company purchased products from Ablecom totaling $44,765,000 and $132,704,000 and sold products to Ablecom totaling $3,600,000 and $9,390,000 for the three and nine months ended March 31, 2013, respectively.

- changed (2014-11-06):
[0001445305-14-004894:note_history:35]
Amounts owed to the Company by Ablecom as of September 30, 2014 and June 30, 2014, were $2,416,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2014 and June 30, 2014, were $45,145,000 and $48,969,000, respectively. For the three months ended September 30, 2014 and 2013, the Company paid Ablecom the majority of invoiced dollars between 52 and 66 days of invoice date. For the three months ended September 30, 2014 and 2013, the Company paid $2,002,000 and $2,276,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2014-05-07, similarity 0.7339):
[0001445305-14-001932:note_history:35]
Amounts owed to the Company by Ablecom as of March 31, 2014 and June 30, 2013, were $469,000 and $974,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2014 and June 30, 2013, were $42,198,000 and $50,448,000, respectively. For the three and nine months ended March 31, 2014, the Company paid Ablecom the majority of invoiced dollars between 50 and 96 days of invoice. For the three and nine months ended March 31, 2014, the Company paid $2,187,000 and $5,923,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2013, the Company paid $531,000 and $3,398,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2014-11-06):
[0001445305-14-004894:note_history:36]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $70,455,000 and $64,464,000 at September 30, 2014 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2014-05-07, similarity 0.9908):
[0001445305-14-001932:note_history:36]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $63,997,000 and $53,684,000 at March 31, 2014 and June 30, 2013, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2014-11-06):
[0001445305-14-004894:note_history:37]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2014 and 2013, $3,000 and $(6,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2014-05-07, similarity 0.8847):
[0001445305-14-001932:note_history:37]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
