# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001445305-14-004894:item_4_controls:1]
Item 4.    Controls and Procedures

[0001445305-14-004894:item_4_controls:2]
Evaluation of Effectiveness of Disclosure Controls and Procedures

[0001445305-14-004894:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, we evaluated the effectiveness of our disclosure controls and procedures, as such term is defined in Rule 13a-15(e) and 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The evaluation considered the procedures designed to ensure that information required to be disclosed by us in the reports filed or submitted by us under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were effective at a reasonable assurance level as of September 30, 2014.

[0001445305-14-004894:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001445305-14-004894:item_4_controls:5]
There were no changes in our internal control over financial reporting (as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended September 30, 2014 that have materially affected, or are reasonably likely to materially affect our internal control over financial reporting.
