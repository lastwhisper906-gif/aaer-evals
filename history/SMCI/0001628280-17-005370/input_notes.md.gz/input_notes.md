# SMCI notes — 0001628280-17-005370


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-005370:notes:1]
Commitments and Contingencies

[0001628280-17-005370:notes:2]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-17-005370:notes:3]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through the next 12 months. As of March 31, 2017, these remaining non-cancellable commitments were $412,541,000 compared to $334,010,000 as of June 30, 2016.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-17-005370:notes:4]
[same as prior period, unchanged from 0001628280-17-000961:notes:4]

[0001628280-17-005370:notes:5]
[same as prior period, unchanged from 0001628280-17-000961:notes:5]

[0001628280-17-005370:notes:6]
[same as prior period, unchanged from 0001628280-17-000961:notes:6]

[0001628280-17-005370:notes:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.

[0001628280-17-005370:notes:8]
[same as prior period, unchanged from 0001628280-17-000961:notes:8]


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-005370:notes:9]
Short-term and Long-term Debt Obligations

[0001628280-17-005370:notes:10]
Short-term and long-term obligations as of March 31, 2017 and June 30, 2016 consisted of the following (in thousands):

[0001628280-17-005370:notes:11]
|  | March 31, |  | June 30, |
|  | 2017 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 63,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,300 |  |  | 10,100 |  |
| Total line of credit | 83,499 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 42,500 |  |  | 933 |  |
| CTBC Bank | 19,838 |  |  | 20,357 |  |
| Total term loans | 62,338 |  |  | 21,290 |  |
| Total debt | 145,837 |  |  | 93,589 |  |
| Less: debt issuance costs | (326 | ) |  | — |  |
| Total debt, net of debt issuance costs | 145,511 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (113,260 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 32,251 |  |  | $ | 40,000 |  |

[0001628280-17-005370:notes:12]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-17-005370:notes:13]
Bank of America

[0001628280-17-005370:notes:14]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The Company extended the revolving line of credit to mature on June 30, 2016.

[0001628280-17-005370:notes:15]
In June 2016, the Company entered into a new credit agreement with Bank of America, which provided for (i) a $55,000,000 revolving line of credit facility including a $5,000,000 letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50,000,000 term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-17-005370:notes:16]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.78% at March 31, 2017. The letter of credit is charged at 1.25% per annum.

[0001628280-17-005370:notes:17]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10,000,000 for the Taiwan and the Netherlands subsidiaries that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds.

[0001628280-17-005370:notes:18]
In December 2016, the Company entered into an amendment to the credit agreement with Bank of America to reduce the $55,000,000 revolving line of credit facility to $45,000,000 and increase the revolving line of credit for the Taiwan and the Netherlands subsidiaries from $10,000,000 to $20,000,000.

[0001628280-17-005370:notes:19]
As of March 31, 2017 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $42,500,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $63,199,000 and $62,199,000 as of March 31, 2017 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.37% to 2.16% per annum at March 31, 2017 and from 1.02% to 1.96% per annum at June 30, 2016. As of March 31, 2017, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $1,801,000.

[0001628280-17-005370:notes:20]
In May 2017, The Company entered into a second amendment to the credit agreement with Bank of America to increase the revolving line of credit facility for the Company from $45,000,000 to $85,000,000 and extended the maturity date of the revolving lines of credit facility of the Company and the Netherlands subsidiary to October 31, 2018. In May 2017, the Company drew $20,000,000 from Bank of America revolving line of credit with interest rate at 2.24% per annum to support the Company's growth.

[0001628280-17-005370:notes:21]
CTBC Bank

[0001628280-17-005370:notes:22]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The Company has extended the credit agreement to mature on May 31, 2017 and is currently negotiating with CTBC Bank to renew the credit agreement.

[0001628280-17-005370:notes:23]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19,838,000 and $20,357,000 at March 31, 2017 and June 30, 2016, respectively. At March 31, 2017 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20,300,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.94% and 1.83% at March 31, 2017 and 0.90% and 1.25% per annum at June 30, 2016. At March 31, 2017, there was no available amount for future borrowing under this credit agreement.

[0001628280-17-005370:notes:24]
Covenant Compliance

[0001628280-17-005370:notes:25]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-17-005370:notes:26]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001628280-17-005370:notes:27]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; |

[0001628280-17-005370:notes:28]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $40,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-17-005370:notes:29]
As of March 31, 2017 and June 30, 2016, total assets of $1,049,629,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of March 31, 2017 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the credit agreement were $97,625,000 and $59,258,000, respectively. As of March 31, 2017, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

[0001628280-17-005370:notes:30]
As of March 31, 2017 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,523,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-005370:notes:31]
[same as prior period, unchanged from 0001628280-17-000961:notes:33]

[0001628280-17-005370:notes:32]
[same as prior period, unchanged from 0001628280-17-000961:notes:34]

[0001628280-17-005370:notes:33]
In July 2016, the Company’s Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of the Company’s common stock in the open market or in private transactions during the next twelve months at prevailing market prices. Repurchases will be made under the program using the Company’s own cash resources. This share repurchase program does not obligate the Company to acquire any particular amount of common stock, and it may be suspended at any time at the Company’s discretion. During the three months ended March 31, 2017, the Company did not purchase any shares of its common stock in the open market. During the nine months ended March 31, 2017, the Company purchased 888,097 shares of the Company's common stock in the open market at a weighted average price of $20.79 for $18,461,000.

[0001628280-17-005370:notes:34]
[same as prior period, unchanged from 0001628280-17-000961:notes:36]

[0001628280-17-005370:notes:35]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other share-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of such date, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006" Plan). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan but that are forfeited in the future will become available for use under the 2016 Plan. In addition, 1,153,412 shares of common stock originally reserved for issuance under the 2006 Plan were cancelled upon the adoption of the 2016 Plan. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value of the underlying share on grant date. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of March 31, 2017, the Company had 3,156,856 shares available for future issuance under the 2016 Plan.

[0001628280-17-005370:notes:36]
[same as prior period, unchanged from 0001628280-17-000961:notes:38]

[0001628280-17-005370:notes:37]
[same as prior period, unchanged from 0001628280-17-000961:notes:39]

[0001628280-17-005370:notes:38]
[same as prior period, unchanged from 0001628280-17-000961:notes:40]

[0001628280-17-005370:notes:39]
[same as prior period, unchanged from 0001628280-17-000961:notes:41]

[0001628280-17-005370:notes:40]
[same as prior period, unchanged from 0001628280-17-000961:notes:42]

[0001628280-17-005370:notes:41]
[same as prior period, unchanged from 0001628280-17-000961:notes:43]

[0001628280-17-005370:notes:42]
[same as prior period, unchanged from 0001628280-17-000961:notes:44]

[0001628280-17-005370:notes:43]
The fair value of stock option grants for the three and nine months ended March 31, 2017 and 2016 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-17-005370:notes:44]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Risk-free interest rate | 2.03 | % |  | 1.38% - 1.48% |  |  | 1.12% - 2.03% |  |  | 1.38% - 1.57% |  |
| Expected term | 5.31 years |  |  | 5.31 years |  |  | 5.31 - 5.38 years |  |  | 5.31 - 5.33 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 43.84% - 49.12% |  |  | 49.09% - 50.89% |  |  | 43.84% - 49.64% |  |  | 47.06% - 50.89% |  |
| Weighted-average fair value | $ | 12.72 |  |  | $ | 12.99 |  |  | $ | 10.90 |  |  | $ | 12.04 |  |

[0001628280-17-005370:notes:45]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2017 and 2016 (in thousands):

[0001628280-17-005370:notes:46]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of sales | $ | 334 |  |  | $ | 294 |  |  | $ | 968 |  |  | $ | 792 |  |
| Research and development | 3,069 |  |  | 2,549 |  |  | 8,989 |  |  | 7,423 |  |
| Sales and marketing | 541 |  |  | 491 |  |  | 1,539 |  |  | 1,330 |  |
| General and administrative | 889 |  |  | 552 |  |  | 2,550 |  |  | 2,223 |  |
| Stock-based compensation expense before taxes | 4,833 |  |  | 3,886 |  |  | 14,046 |  |  | 11,768 |  |
| Income tax impact | (1,549 | ) |  | (1,191 | ) |  | (4,270 | ) |  | (3,290 | ) |
| Stock-based compensation expense, net | $ | 3,284 |  |  | $ | 2,695 |  |  | $ | 9,776 |  |  | $ | 8,478 |  |

[0001628280-17-005370:notes:47]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options and vesting of RSUs in excess of the compensation expense recorded for those share-based awards (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. The Company had $1,224,000 and $3,548,000 of excess tax benefits recorded in additional paid-in capital in the nine months ended March 31, 2017 and March 31, 2016, respectively. The Company had excess tax benefits classified as cash provided by financing activities of $1,893,000 and $2,506,000 in the nine months ended March 31, 2017 and 2016, respectively, for share-based awards issued since July 1, 2006.

[0001628280-17-005370:notes:48]
As of March 31, 2017, the Company’s total unrecognized compensation cost related to non-vested share-based awards granted to employees and non-employee directors was $39,249,000, which will be recognized over a weighted-average vesting period of approximately 2.40 years.

[0001628280-17-005370:notes:49]
[same as prior period, unchanged from 0001628280-17-000961:notes:51]

[0001628280-17-005370:notes:50]
The following table summarizes stock option activity during the nine months ended March 31, 2017 under all plans:

[0001628280-17-005370:notes:51]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2016 (7,495,131 shares exercisable at weighted average exercise price of $13.35 per share) |  | 8,960,867 |  |  | $ | 14.88 |  |  |  |  |  |
| Granted (weighted average fair value of $10.90) |  | 341,400 |  |  | $ | 24.11 |  |  |  |  |  |
| Exercised |  | (827,875 | ) |  | $ | 11.02 |  |  |  |  |  |
| Forfeited |  | (24,011 | ) |  | $ | 20.76 |  |  |  |  |  |
| Balance as of March 31, 2017 |  | 8,450,381 |  |  | $ | 15.62 |  |  | 4.90 |  | $ | 86,351 |  |
| Options vested and expected to vest at March 31, 2017 |  | 8,378,933 |  |  | $ | 15.53 |  |  | 4.86 |  | $ | 86,238 |  |
| Options vested and exercisable at March 31, 2017 |  | 7,364,413 |  |  | $ | 14.29 |  |  | 4.41 |  | $ | 83,637 |  |

[0001628280-17-005370:notes:52]
The total pretax intrinsic value of options exercised was $5,237,000 and $11,312,000 during the three and nine months ended March 31, 2017, respectively, and $11,637,000 and $16,491,000 during the three and nine months ended March 31, 2016, respectively.

[0001628280-17-005370:notes:53]
[same as prior period, unchanged from 0001628280-17-000961:notes:55]

[0001628280-17-005370:notes:54]
[same as prior period, unchanged from 0001628280-17-000961:notes:56]

[0001628280-17-005370:notes:55]
The following table summarizes RSUs activity during the nine months ended March 31, 2017 under all plans:

[0001628280-17-005370:notes:56]
|  | RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2016 | 926,983 |  |  | $ | 30.23 |  |  |  |
| Granted | 613,310 |  |  | $ | 23.42 |  |  |  |
| Released | (285,037 | ) |  | $ | 27.45 |  |  |  |
| Forfeited | (81,869 | ) |  | $ | 26.67 |  |  |  |
| Balance as of March 31, 2017 | 1,173,387 |  |  | $ | 27.59 |  |  | $ | 29,745 |  |

[0001628280-17-005370:notes:57]
The total pretax intrinsic value of RSUs vested was $2,620,000 and $7,015,000 during the three and nine months ended March 31, 2017, respectively, and $1,579,000 and $2,937,000 during the three and nine months ended March 31, 2016, respectively. In the three and nine months ended March 31, 2017, upon vesting, 97,392 and 285,037 shares of RSUs were partially net share-settled such that the Company withheld 34,727 and 100,609 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities, respectively. In the three and nine months ended March 31, 2016, upon vesting, 50,912 and 102,918 shares of RSUs were partially net share-settled such that the Company withheld 19,480 and 38,801 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities, respectively. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $934,000 and $2,476,000 during the three and nine months ended March 31, 2017, respectively, and $604,000 and $1,108,000 during the three and nine months ended March 31, 2016, respectively, and are reflected as a financing activity within the condensed consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-17-005370:notes:58]
[same as prior period, unchanged from 0001628280-17-000961:notes:60]

[0001628280-17-005370:notes:59]
[same as prior period, unchanged from 0001628280-17-000961:notes:61]


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-005370:notes:60]
[same as prior period, unchanged from 0001628280-17-000961:notes:62]

[0001628280-17-005370:notes:61]
The following table shows the computation of basic and diluted net income per share for the three and nine months ended March 31, 2017 and 2016 (in thousands, except per share amounts):

[0001628280-17-005370:notes:62]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 16,666 |  |  | $ | 16,662 |  |  | $ | 52,194 |  |  | $ | 65,050 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 48,445 |  |  | 48,047 |  |  | 48,243 |  |  | 47,737 |  |
| Effect of dilutive securities | 3,473 |  |  | 4,191 |  |  | 3,336 |  |  | 3,900 |  |
| Weighted-average diluted shares | 51,918 |  |  | 52,238 |  |  | 51,579 |  |  | 51,637 |  |
| Basic net income per share | $ | 0.34 |  |  | $ | 0.35 |  |  | $ | 1.08 |  |  | $ | 1.36 |  |
| Diluted net income per share | $ | 0.32 |  |  | $ | 0.32 |  |  | $ | 1.01 |  |  | $ | 1.26 |  |

[0001628280-17-005370:notes:63]
For the three and nine months ended March 31, 2017 and 2016, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding share-based awards were 1,675,000 and 1,594,000 for the three and nine months ended March 31, 2017, respectively, and 1,287,000 and 1,235,000 for the three and nine months ended March 31, 2016, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-17-005370:notes:64]
The following table sets forth the Company’s cash equivalents and long-term investments as of March 31, 2017 and June 30, 2016 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-17-005370:notes:65]
| March 31, 2017 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 324 |  |  | $ | — |  |  | $ | — |  |  | $ | 324 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total | $ | 324 |  |  | $ | — |  |  | $ | 2,643 |  |  | $ | 2,967 |  |
| June 30, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 315 |  |  | $ | — |  |  | $ | — |  |  | $ | 315 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total | $ | 315 |  |  | $ | — |  |  | $ | 2,643 |  |  | $ | 2,958 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-17-005370:notes:66]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2017 and 2016 (in thousands):

[0001628280-17-005370:notes:67]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance as of beginning of period | $ | 2,643 |  |  | $ | 2,633 |  |  | $ | 2,643 |  |  | $ | 2,633 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |  | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |  | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 2,643 |  |  | $ | 2,633 |  |  | $ | 2,643 |  |  | $ | 2,633 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-005370:notes:68]
[same as prior period, unchanged from 0001628280-17-000961:notes:70]

[0001628280-17-005370:notes:69]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs as of March 31, 2017 and June 30, 2016. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2017 and June 30, 2016. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001628280-17-005370:notes:70]
The above table excludes $107,335,000 and $180,426,000 of cash and $2,369,000 and $2,133,000 of certificates of deposit held by the Company as of March 31, 2017 and June 30, 2016, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and nine months ended March 31, 2017 and 2016.

[0001628280-17-005370:notes:71]
The following is a summary of the Company’s long-term investments as of March 31, 2017 and June 30, 2016 (in thousands):

[0001628280-17-005370:notes:72]
|  | March 31, 2017 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |
|  | June 30, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |

[0001628280-17-005370:notes:73]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2017 and June 30, 2016, short-term and long-term debt of $145,511,000 and $93,589,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-005370:notes:74]
[same as prior period, unchanged from 0001628280-17-000961:notes:76]

[0001628280-17-005370:notes:75]
The Company recorded provisions for income taxes of $5,140,000 and $20,824,000 for the three and nine months ended March 31, 2017, respectively, and $7,386,000 and $28,951,000 for the three and nine months ended March 31, 2016, respectively. The effective tax rate was 23.6% and 28.5% for the three and nine months ended March 31, 2017, respectively, and 30.7% and 30.8% for the three and nine months ended March 31, 2016, respectively. The effective tax rate for the three and nine months ended March 31, 2017 is estimated to be lower than the federal statutory rate primarily due to a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction, the benefit from U.S. federal research and development ("R&D") tax credits and domestic production activities deductions.

[0001628280-17-005370:notes:76]
As of March 31, 2017, the Company had a liability for gross unrecognized tax benefits of $17,329,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three and nine months ended March 31, 2017, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2017, the Company had accrued $1,418,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-17-005370:notes:77]
The Company is subject to United States federal income tax as well as income taxes in many state and foreign jurisdictions. The Company's 2012 and 2013 federal tax returns are currently under the Internal Revenue Service ("IRS") examination. The Company has responded to Information Document Requests ("IDRs"), issued by the IRS. No adjustment has been proposed by the IRS as of March 31, 2017. The Company was also under audit in Taiwan for tax year 2013 related to local income tax exemption regime which the Company has participated in. The Taiwan taxing authority issued a tax assessment related to the 2013 tax exemption which the Company appealed for. On January 9, 2017, the Company received a notification letter from the Taiwan taxing authority that the audit was completed. The audit resulted in minimal adjustments. The Company does not plan to appeal or litigate the audit results.

[0001628280-17-005370:notes:78]
The federal statute of limitations remain open in general for tax years 2012 through 2016. The state statute of limitations remain open in general for tax years 2012 through 2016. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2010 through 2016.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-17-005370:notes:79]
Recently Issued Accounting Pronouncements

[0001628280-17-005370:notes:80]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectability and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016.

[0001628280-17-005370:notes:81]
The Company intends to apply the new standard starting from the first quarter of fiscal year 2019. Based on the Company's preliminary plan, the Company intends to adopt the new standard using the modified retrospective method. The Company’s decision was based on a number of factors such as the significance of the impact of the new standard on the Company’s financial results, system readiness, including that of software procured from third-party providers, and the Company’s ability to accumulate and analyze the information necessary to assess the cumulative effect of the new standard through July 1, 2018. However, the Company continues to assess this in connection with its entire project plan. The Company expects the implementation of the new standard to impact the recognition of its revenue as follows:

[0001628280-17-005370:notes:82]
| • | Substantially all of the Company's current revenue is from the sale of hardware products. The Company does not expect any material changes to the timing or amount of revenue for these types of sales under the new standard. |

[0001628280-17-005370:notes:83]
| • | For extended warranty and on-site services, the Company is still assessing the impact and timing to revenue from the implementation of the new standard. However, the Company does not currently expect the new standard to have a material impact on its revenue for these types of arrangements. |

[0001628280-17-005370:notes:84]
| • | For software and intellectual property licenses, the Company is still assessing the impact and timing to revenue from the implementation of the new standard. However, the Company does not currently expect the new standard to have a material impact on its revenue for these types of arrangements. |

[0001628280-17-005370:notes:85]
| • | The Company's revenue disclosures are expected to expand. |

[0001628280-17-005370:notes:86]
The Company is still assessing the impact to its processes and systems configuration from the implementation of the new revenue standard and does not currently expect any significant changes to its other accounting policies from the adoption of the new revenue standard. The Company's implementation efforts are progressing as planned.

[0001628280-17-005370:notes:87]
In April 2015, the FASB issued an amendment to the accounting guidance, Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance, Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements. This amendment clarifies that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company adopted these amendments in the first quarter of fiscal year 2017. There was no material impact on its financial statement disclosures, results of operations and financial position.

[0001628280-17-005370:notes:88]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-17-005370:notes:89]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-17-005370:notes:90]
In March 2016, the FASB issued new accounting guidance, Compensation—Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. Early adoption is permitted for any interim or annual periods. This guidance is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-17-005370:notes:91]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. This amendment is effective for the Company on July 1, 2019. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-17-005370:notes:92]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. This amendment is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosure, results of operations and financial position.

[0001628280-17-005370:notes:93]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This amendment is effective for the Company on July 1, 2018. Early adoption is permitted. The Company does not expect the impact of adopting this guidance to be significant.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-17-005370:notes:94]
[same as prior period, unchanged from 0001628280-17-000961:notes:90]

[0001628280-17-005370:notes:95]
[same as prior period, unchanged from 0001628280-17-000961:notes:91]

[0001628280-17-005370:notes:96]
[same as prior period, unchanged from 0001628280-17-000961:notes:92]

[0001628280-17-005370:notes:97]
[same as prior period, unchanged from 0001628280-17-000961:notes:93]

[0001628280-17-005370:notes:98]
[same as prior period, unchanged from 0001628280-17-000961:notes:94]

[0001628280-17-005370:notes:99]
[same as prior period, unchanged from 0001628280-17-000961:notes:95]

[0001628280-17-005370:notes:100]
[same as prior period, unchanged from 0001628280-17-000961:notes:96]

[0001628280-17-005370:notes:101]
[same as prior period, unchanged from 0001628280-17-000961:notes:97]


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001628280-17-005370:notes:102]
[same as prior period, unchanged from 0001628280-17-000961:notes:98]

[0001628280-17-005370:notes:103]
|  | March 31, 2017 |  | June 30, 2016 |
| Deferred revenue-net of current portion (1) | $ | 40,666 |  |  | $ | 21,940 |  |
| Accrued unrecognized tax benefits including related interests and penalties-net of current portion | 17,329 |  |  | 16,056 |  |
| Accrued warranty costs-net of current portion | 1,304 |  |  | 1,313 |  |
| Others | 1,348 |  |  | 1,294 |  |
| Total other long-term liabilities | $ | 60,647 |  |  | $ | 40,603 |  |

[0001628280-17-005370:notes:104]
(1) As of March 31, 2017 and June 30, 2016, deferred revenue-net of current portion consist primarily of deferred extended warranty and on-site service revenue of $34,017,000 and $21,265,000, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-17-005370:notes:105]
[same as prior period, unchanged from 0001628280-17-000961:notes:101]

[0001628280-17-005370:notes:106]
|  | March 31, 2017 |  | June 30, 2016 |
| Land | $ | 70,484 |  |  | $ | 70,454 |  |
| Buildings | 71,665 |  |  | 71,665 |  |
| Building and leasehold improvements | 14,616 |  |  | 10,941 |  |
| Buildings construction in progress (1) | 22,507 |  |  | 15,803 |  |
| Machinery and equipment | 58,577 |  |  | 53,282 |  |
| Furniture and fixtures | 13,306 |  |  | 10,364 |  |
| Purchased software | 14,276 |  |  | 13,920 |  |
| Purchased software construction in progress | 435 |  |  | 532 |  |
|  | 265,866 |  |  | 246,961 |  |
| Accumulated depreciation and amortization | (70,313 | ) |  | (59,012 | ) |
| Property, plant and equipment, net | $ | 195,553 |  |  | $ | 187,949 |  |

[0001628280-17-005370:notes:107]
[same as prior period, unchanged from 0001628280-17-000961:notes:103]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-17-005370:notes:108]
Related-party and Other Transactions

[0001628280-17-005370:notes:109]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.4% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at March 31, 2017.

[0001628280-17-005370:notes:110]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-17-005370:notes:111]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-17-005370:notes:112]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-17-005370:notes:113]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $62,378,000 and $177,513,000, and sold products to Ablecom totaling $4,069,000 and $14,414,000 for the three and nine months ended March 31, 2017, respectively. The Company purchased products from Ablecom totaling $55,133,000 and $185,845,000, and sold products to Ablecom totaling $4,413,000 and $12,125,000 for the three and nine months ended March 31, 2016, respectively.

[0001628280-17-005370:notes:114]
Amounts owed to the Company by Ablecom as of March 31, 2017 and June 30, 2016 were $7,614,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2017 and June 30, 2016 were $50,407,000 and $39,152,000, respectively. For the three and nine months ended March 31, 2017, the Company paid Ablecom the majority of invoiced dollars between 45 and 86 days of invoice date. For the three and nine months ended March 31, 2017, the Company paid $1,776,000 and $4,712,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2016, the Company paid $3,003,000 and $5,901,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-17-005370:notes:115]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $102,502,000 and $62,782,000 at March 31, 2017 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-17-005370:notes:116]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2017, $5,000 and $(19,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively. In the three and nine months ended March 31, 2016, $13,000 and $9,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively.

[0001628280-17-005370:notes:117]
Investment in a Corporate Venture— In October 2016, the Company entered into agreements pursuant to which the Company agreed to contribute certain technology rights in connection with an investment in a privately-held company ("Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another investor in China. The transaction was closed in the three months ended March 31, 2017 and the investment has been accounted for under the equity method of accounting. The equity in earnings (losses) of the Corporate Venture were immaterial for the three months ended March 31, 2017 and were included in the Interest and Other Income (Expense), Net in the Company's condensed consolidated statements of operations. The Company recorded a deferred gain related to the contribution of certain technology rights of $6,650,000 in the transaction as of March 31, 2017. The deferred gain will be recognized as license revenue over time on the Company's statement of operations.

[0001628280-17-005370:notes:118]
Additionally, the Company sold products to the Corporate Venture in the three months ended March 31, 2017 and all the related intra-entity sales and profits on the products which remained unsold by the Corporate Venture as of March 31, 2017 have been eliminated and reduced the Company's investment in the Corporate Venture. As of March 31, 2017, the Company's equity investment in the Corporate Venture was $6,714,000 and was recorded under Other Assets on the Company's condensed consolidated balance sheets.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-17-005370:notes:119]
[same as prior period, unchanged from 0001628280-17-000961:notes:113]

[0001628280-17-005370:notes:120]
|  | March 31, 2017 |  | June 30, 2016 |
| Accrued payroll and related expenses | $ | 18,403 |  |  | $ | 16,015 |  |
| Customer deposits | 8,778 |  |  | 6,265 |  |
| Accrued warranty costs | 5,805 |  |  | 5,816 |  |
| Accrued cooperative marketing expenses | 7,832 |  |  | 7,300 |  |
| Deferred revenue (1) | 24,038 |  |  | 13,418 |  |
| Others | 6,037 |  |  | 6,804 |  |
| Total accrued liabilities | $ | 70,893 |  |  | $ | 55,618 |  |

[0001628280-17-005370:notes:121]
(1) As of March 31, 2017 and June 30, 2016, deferred revenue consist primarily of deferred extended warranty and on-site service revenue of $21,281,000 and $12,746,000, respectively.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-17-005370:notes:122]
[same as prior period, unchanged from 0001628280-17-000961:notes:116]

[0001628280-17-005370:notes:123]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 441,822 |  |  | 70.0 | % |  | $ | 372,404 |  |  | 69.9 | % |  | $ | 1,243,313 |  |  | 68.6 | % |  | $ | 1,182,362 |  |  | 69.9 | % |
| Subsystems and accessories | 189,302 |  |  | 30.0 | % |  | 160,317 |  |  | 30.1 | % |  | 568,733 |  |  | 31.4 | % |  | 508,941 |  |  | 30.1 | % |
| Total | $ | 631,124 |  |  | 100.0 | % |  | $ | 532,721 |  |  | 100.0 | % |  | $ | 1,812,046 |  |  | 100.0 | % |  | $ | 1,691,303 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-17-005370:notes:124]
[same as prior period, unchanged from 0001628280-17-000961:notes:118]

[0001628280-17-005370:notes:125]
|  | March 31, 2017 |  | June 30, 2016 |
| Finished goods | $ | 475,031 |  |  | $ | 351,209 |  |
| Work in process | 63,207 |  |  | 19,105 |  |
| Purchased parts and raw materials | 104,076 |  |  | 78,666 |  |
| Total inventory | $ | 642,314 |  |  | $ | 448,980 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-17-005370:notes:126]
[same as prior period, unchanged from 0001628280-17-000961:notes:120]

[0001628280-17-005370:notes:127]
|  | March 31, 2017 |  | June 30, 2016 |
| Long-term deferred service costs | $ | 2,742 |  |  | $ | 3,498 |  |
| Restricted cash | 2,190 |  |  | 1,851 |  |
| Investments in privately held companies | 8,124 |  |  | 1,411 |  |
| Deposits | 258 |  |  | 910 |  |
| Prepaid royalty license | 561 |  |  | 748 |  |
| Others | 165 |  |  | 128 |  |
| Total other assets | $ | 14,040 |  |  | $ | 8,546 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-17-005370:notes:128]
[same as prior period, unchanged from 0001628280-17-000961:notes:122]

[0001628280-17-005370:notes:129]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Balance, beginning of period | $ | 6,925 |  |  | $ | 7,777 |  |  | $ | 7,129 |  |  | $ | 7,700 |  |
| Provision for warranty | 5,332 |  |  | 3,685 |  |  | 15,030 |  |  | 12,229 |  |
| Costs charged to accrual | (5,362 | ) |  | (3,872 | ) |  | (14,919 | ) |  | (10,545 | ) |
| Change in estimated liability for pre-existing warranties | 214 |  |  | (460 | ) |  | (131 | ) |  | (2,254 | ) |
| Balance, end of period | 7,109 |  |  | 7,130 |  |  | 7,109 |  |  | 7,130 |  |
| Current portion | (5,805 | ) |  | (5,634 | ) |  | (5,805 | ) |  | (5,634 | ) |
| Long-term portion | $ | 1,304 |  |  | $ | 1,496 |  |  | $ | 1,304 |  |  | $ | 1,496 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-17-005370:notes:130]
The following is a summary for the three and nine months ended March 31, 2017 and 2016, of net sales by geographic region (in thousands):

[0001628280-17-005370:notes:131]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 333,945 |  |  | $ | 326,392 |  |  | $ | 987,357 |  |  | $ | 1,072,126 |  |
| Europe | 114,832 |  |  | 93,279 |  |  | 358,619 |  |  | 294,239 |  |
| Asia | 150,791 |  |  | 78,544 |  |  | 384,872 |  |  | 241,595 |  |
| Other | 31,556 |  |  | 34,506 |  |  | 81,198 |  |  | 83,343 |  |
|  | $ | 631,124 |  |  | $ | 532,721 |  |  | $ | 1,812,046 |  |  | $ | 1,691,303 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-17-005370:notes:132]
[same as prior period, unchanged from 0001628280-17-000961:notes:126]

[0001628280-17-005370:notes:133]
|  | March 31, |  | June 30, |
|  | 2017 |  | 2016 |
| Long-lived assets: |  |  |  |
| United States | $ | 152,051 |  |  | $ | 142,764 |  |
| Asia | 40,949 |  |  | 42,052 |  |
| Europe | 2,553 |  |  | 3,133 |  |
|  | $ | 195,553 |  |  | $ | 187,949 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-005370:notes:134]
[same as prior period, unchanged from 0001628280-17-000961:notes:128]

[0001628280-17-005370:notes:135]
[same as prior period, unchanged from 0001628280-17-000961:notes:129]

[0001628280-17-005370:notes:136]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2017 and 2016, of net sales by geographic region (in thousands):

[0001628280-17-005370:notes:137]
Server systems constitute an assembly of subsystems and accessories. Subsystems and accessories are comprised of serverboards, chassis and accessories. No customer represented greater than 10% of the Company's total net sales in the three and nine months ended March 31, 2017 and one customer represented 10.2% and 12.6% of the Company's total net sales in the three and nine months ended March 31, 2016, respectively. China represented 10.4% of the Company's total net sales in the three months ended March 31, 2017 and no country other than the United States represented greater than 10% of the Company's total net sales in the nine months ended March 31, 2017. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2016. No customer accounted for 10% or more of the Company's accounts receivable as of March 31, 2017 and June 30, 2016.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-17-005370:notes:138]
[same as prior period, unchanged from 0001628280-17-000961:notes:132]

[0001628280-17-005370:notes:139]
[same as prior period, unchanged from 0001628280-17-000961:notes:133]

[0001628280-17-005370:notes:140]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $1,771,000 and $8,162,000 in the three and nine months ended March 31, 2017, respectively, and $2,246,000 and $6,026,000 in the three and nine months ended March 31, 2016, respectively.
