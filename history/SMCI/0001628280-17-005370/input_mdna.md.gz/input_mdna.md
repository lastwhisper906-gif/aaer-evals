# SMCI MD&A — 0001628280-17-005370


## mdna

[0001628280-17-005370:mdna:1]
[same as prior period, unchanged from 0001628280-17-000961:mdna:1]

[0001628280-17-005370:mdna:2]
[same as prior period, unchanged from 0001628280-17-000961:mdna:2]

[0001628280-17-005370:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, high performance or accelerated computing (“HPC”), and Internet of Things (“IoT”)/embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Our net sales were $631.1 million and $1,812.0 million for the three and nine months ended March 31, 2017, respectively, and $532.7 million and $1,691.3 million for the three and nine months ended March 31, 2016, respectively. The increase in our net sales in the three and nine months ended March 31, 2017 compared with the three and nine months ended March 31, 2016 was primarily due to increased sales of our optimized server systems from storage, HPC, IoT/embedded and enterprise market verticals. Net sales of optimized servers were $441.8 million and $1,243.3 million for the three and nine months ended March 31, 2017, respectively, and $372.4 million and $1,182.4 million for the three and nine months ended March 31, 2016, respectively, and net sales of subsystems and accessories were $189.3 million and $568.7 million for the three and nine months ended March 31, 2017, respectively, and $160.3 million and $508.9 million for the three and nine months ended March 31, 2016, respectively. In the three and nine months ended March 31, 2017, we experienced strong growth in sales of our complete server systems including storage, accelerated computing servers, MicroBlade, high density Twin family of servers and strong growth from sales to customers in Asia Pacific, particularly Greater China. The percentage of our net sales represented by sales of server systems increased to 70.0% and decreased to 68.6% in the three and nine months ended March 31, 2017, respectively, from 69.9% in both the three and nine months ended March 31, 2016.

[0001628280-17-005370:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $16.7 million and $52.2 million for the three and nine months ended March 31, 2017, respectively, and $16.7 million and $65.1 million for the three and nine months ended March 31, 2016, respectively. Our decrease in net income in the nine months ended March 31, 2017 was primarily attributable to lower gross margins from sales of our complete server systems due to higher costs related to shortages of memory and solid state drives ("SSD") and higher operating expenses from headcount and annual salary increases to support the growth of our business.

[0001628280-17-005370:mdna:5]
We sell our server systems and subsystems and accessories through our direct sales force as well as through OEMs and distributors. We derived 54.0% and 52.8% of our net sales from products sold to direct customers and OEMs for the three and nine months ended March 31, 2017, respectively. We derived 54.4% and 55.8% of our net sales from products sold to direct customers and OEMs for the three and nine months ended March 31, 2016, respectively. None of our customers accounted for 10% or more of our net sales in the three and nine months ended March 31, 2017. Sales to SoftLayer, a division of IBM Corporation, represented 10.2% and 12.6% of our net sales in the three and nine months ended March 31, 2016, respectively. We derived 52.9% and 54.5% of our net sales from customers in the United States for the three and nine months ended March 31, 2017, respectively, and 61.3% and 63.4% for the three and nine months ended March 31, 2016, respectively.

[0001628280-17-005370:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.7% of our net sales for both the three and nine months ended March 31, 2017, and 5.9% and 5.3% of our net sales for the three and nine months ended March 31, 2016, respectively.

[0001628280-17-005370:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2017, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers, and we have continued to improve our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. Our purchases from Ablecom represented 11.5% of our cost of sales for both the three and nine months ended March 31, 2017, compared to 12.2% and 13.0% of our cost of sales for the three and nine months ended March 31, 2016, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in an effort to reduce our cost of sales. In addition to providing contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-17-005370:mdna:8]
In order to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding (“DSOs”). In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001628280-17-005370:mdna:9]
[same as prior period, unchanged from 0001628280-17-000961:mdna:10]

[0001628280-17-005370:mdna:10]
The following is a summary of other financial highlights of the third quarter of fiscal 2017:

[0001628280-17-005370:mdna:11]
| • | Net cash provided by (used in) operating activities was $(90.3) million and $92.8 million during the nine months ended March 31, 2017 and 2016, respectively. Our cash and cash equivalents, together with our investments, were $110.5 million at the end of the third quarter of fiscal year 2017, compared with $183.7 million at the end of fiscal year 2016. The decrease in our cash and cash equivalents, together with our investments at the end of the third quarter of fiscal year 2017 was primarily due to $90.3 million of cash used in our operating activities, $23.3 million used to purchase property and equipment, of which $13.1 million was related to property and equipment for use at our Green Computing Park in San Jose, California and $18.5 million used to purchase outstanding common stock, partially offset by $50.6 million of borrowings, net of repayments. |

[0001628280-17-005370:mdna:12]
| • | DSO at the end of the third quarter of fiscal year 2017 was 54 days, compared with 50 days at the end of fiscal year 2016. |

[0001628280-17-005370:mdna:13]
| • | Our inventory balance was $642.3 million at the end of the third quarter of fiscal year 2017, compared with $449.0 million at the end of fiscal year 2016. Days sales of inventory at the end of the third quarter of fiscal year 2017 was 103 days, compared with 87 days at the end of fiscal year 2016. The increase in days sales of inventory was primarily due to higher inventory purchases in light of memory and SSD component shortages sourcing for new product lines related to SkyLake launch and supporting for the seasonally strong quarter ending June 30, 2017. |

[0001628280-17-005370:mdna:14]
| • | Our purchase commitments with contract manufacturers and suppliers were $412.5 million at the end of the third quarter of fiscal year 2017 and $334.0 million at the end of fiscal year 2016. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-17-005370:mdna:15]
21

[0001628280-17-005370:mdna:16]
[same as prior period, unchanged from 0001628280-17-000961:mdna:16]

[0001628280-17-005370:mdna:17]
[same as prior period, unchanged from 0001628280-17-000961:mdna:17]

[0001628280-17-005370:mdna:18]
[same as prior period, unchanged from 0001628280-17-000961:mdna:18]

[0001628280-17-005370:mdna:19]
[same as prior period, unchanged from 0001628280-17-000961:mdna:19]

[0001628280-17-005370:mdna:20]
[same as prior period, unchanged from 0001628280-17-000961:mdna:20]

[0001628280-17-005370:mdna:21]
[same as prior period, unchanged from 0001628280-17-000961:mdna:21]

[0001628280-17-005370:mdna:22]
[same as prior period, unchanged from 0001628280-17-000961:mdna:22]

[0001628280-17-005370:mdna:23]
[same as prior period, unchanged from 0001628280-17-000961:mdna:23]

[0001628280-17-005370:mdna:24]
[same as prior period, unchanged from 0001628280-17-000961:mdna:24]

[0001628280-17-005370:mdna:25]
[same as prior period, unchanged from 0001628280-17-000961:mdna:25]

[0001628280-17-005370:mdna:26]
[same as prior period, unchanged from 0001628280-17-000961:mdna:26]

[0001628280-17-005370:mdna:27]
[same as prior period, unchanged from 0001628280-17-000961:mdna:27]

[0001628280-17-005370:mdna:28]
There have been no material changes in the matters for which we make critical accounting policies and estimates in the preparation of our Condensed Consolidated Financial Statements during the three and nine months ended March 31, 2017, as compared to those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2016.

[0001628280-17-005370:mdna:29]
[same as prior period, unchanged from 0001628280-17-000961:mdna:29]

[0001628280-17-005370:mdna:30]
[same as prior period, unchanged from 0001628280-17-000961:mdna:30]

[0001628280-17-005370:mdna:31]
The following table presents net sales by product type for the three and nine months ended March 31, 2017 and 2016 (dollars in millions):

[0001628280-17-005370:mdna:32]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Server systems | $ | 441.8 |  |  | $ | 372.4 |  |  | $ | 69.4 |  |  | 18.6 | % |  | $ | 1,243.3 |  |  | $ | 1,182.4 |  |  | $ | 61.0 |  |  | 5.2 | % |
| Percentage of total net sales | 70.0 | % |  | 69.9 | % |  |  |  |  |  | 68.6 | % |  | 69.9 | % |  |  |  |  |
| Subsystems and accessories | 189.3 |  |  | 160.3 |  |  | 29.0 |  |  | 18.1 | % |  | 568.7 |  |  | 508.9 |  |  | 59.8 |  |  | 11.7 | % |
| Percentage of total net sales | 30.0 | % |  | 30.1 | % |  |  |  |  |  | 31.4 | % |  | 30.1 | % |  |  |  |  |
| Total net sales | $ | 631.1 |  |  | $ | 532.7 |  |  | $ | 98.4 |  |  | 18.5 | % |  | $ | 1,812.0 |  |  | $ | 1,691.3 |  |  | $ | 120.7 |  |  | 7.1 | % |

[0001628280-17-005370:mdna:33]
The following table presents the number of compute node sales and average selling price per node of our server systems for the three and nine months ended March 31, 2017 and 2016 (nodes in thousands):

[0001628280-17-005370:mdna:34]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| Server systems: |  |  |  |  |  |  |  |  |  |  |  |
| Number of compute node sales (1) | 139 |  |  | 126 |  |  | 10.3 | % |  | 406 |  |  | 375 |  |  | 8.3 | % |
| Average selling price per node | $ | 3,179 |  |  | $ | 2,956 |  |  | 7.5 | % |  | $ | 3,062 |  |  | $ | 3,153 |  |  | (2.9 | )% |

[0001628280-17-005370:mdna:35]
[same as prior period, unchanged from 0001628280-17-000961:mdna:35]

[0001628280-17-005370:mdna:36]
The following table presents unit sales and average selling price of our subsystems and accessories for the three and nine months ended March 31, 2017 and 2016 (units in thousands):

[0001628280-17-005370:mdna:37]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| Subsystems and accessories: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 1,085 |  |  | 950 |  |  | 14.2 | % |  | 3,443 |  |  | 2,960 |  |  | 16.3 | % |
| Average selling price per unit | $ | 174 |  |  | $ | 169 |  |  | 3.0 | % |  | $ | 165 |  |  | $ | 172 |  |  | (4.1 | )% |

[0001628280-17-005370:mdna:38]
Comparison of Three Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:39]
The increase in our net sales in the three months ended March 31, 2017 compared with the three months ended March 31, 2016 was primarily due to an increased sales of our storage, accelerated computing servers or HPC, MicroBlade and high density Twin family of servers. The year-over-year increase in net sales of our server systems in the three months ended March 31, 2017 was due primarily to an increase in the number of compute node sales of our server systems as we sold higher nodes

[0001628280-17-005370:mdna:40]
per systems for our MicroBlade and Twin family product line of servers and an increase in the average selling price per node of our accelerated computing servers or HPC which offset a decrease in sales of our data center optimized servers.

[0001628280-17-005370:mdna:41]
The year-over-year increase in net sales and unit sales of our subsystems and accessories in the three months ended March 31, 2017 was primarily due to higher sales of server accessories and serverboards to our distributors.

[0001628280-17-005370:mdna:42]
Comparison of Nine Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:43]
The increase in our net sales in the nine months ended March 31, 2017 compared with the nine months ended March 31, 2016 was primarily due to an increased sales of our storage, accelerated computing servers or HPC, MicroBlade and high density Twin family of servers. The year-over-year increase in net sales of our server systems in the nine months ended March 31, 2017 was primarily due to an increase in the number of compute node sales as we sold higher nodes per systems for our our MicroBlade and Twin family product line of servers and an increase in the average selling price per node of our accelerated computing servers or HPC which offset a decrease in sales of our data center optimized servers.

[0001628280-17-005370:mdna:44]
The year-over-year increase in net sales and unit sales of our subsystems and accessories in the nine months ended March 31, 2017 was primarily due to higher sales of serverboards and server accessories to our distributors.

[0001628280-17-005370:mdna:45]
The following table presents the percentages of net sales from products sold to distributors and direct and OEM customers for the three and nine months ended March 31, 2017 and 2016:

[0001628280-17-005370:mdna:46]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| Distributors | 46.0 | % |  | 45.6 | % |  | 0.4 | % |  | 47.2 | % |  | 44.2 | % |  | 3.0 | % |
| Direct and OEM customers | 54.0 | % |  | 54.4 | % |  | (0.4 | )% |  | 52.8 | % |  | 55.8 | % |  | (3.0 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-17-005370:mdna:47]
The year-over-year increase in net sales to distributors in the three and nine months ended March 31, 2017 as a percentage of total net sales was primarily due to the higher demand for our subsystem and accessories which are typically sold through distributors and higher demand by distributors for server systems as well. The year-over-year decrease in net sales to direct and OEM customers in the three and nine months ended March 31, 2017 as a percentage of total net sales was primarily due to the lower demand for our complete server systems from cloud/internet data center computing.

[0001628280-17-005370:mdna:48]
The following table presents percentages of net sales by geographic region for the three and nine months ended March 31, 2017 and 2016:

[0001628280-17-005370:mdna:49]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | % |  | 2017 |  | 2016 |  | % |
| United States | 52.9 | % |  | 61.3 | % |  | (8.4 | )% |  | 54.5 | % |  | 63.4 | % |  | (8.9 | )% |
| Europe | 18.2 | % |  | 17.5 | % |  | 0.7 | % |  | 19.8 | % |  | 17.4 | % |  | 2.4 | % |
| Asia | 23.9 | % |  | 14.7 | % |  | 9.2 | % |  | 21.2 | % |  | 14.3 | % |  | 6.9 | % |
| Others | 5.0 | % |  | 6.5 | % |  | (1.5 | )% |  | 4.5 | % |  | 4.9 | % |  | (0.4 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-17-005370:mdna:50]
The year-over-year decrease in net sales in the United States in the three and nine months ended March 31, 2017 as a percentage of total net sales was primarily due to the lower demand for our server systems from cloud/internet data center customers which represents a higher portion of sales in the United States than in other regions. The year-over-year increase in net sales in Asia and Europe in the three and nine months ended March 31, 2017 as a percentage of total net sales was primarily due to the higher demand for our server systems in Greater China and the Netherlands.

[0001628280-17-005370:mdna:51]
[same as prior period, unchanged from 0001628280-17-000961:mdna:50]

[0001628280-17-005370:mdna:52]
Cost of sales and gross margin for the three and nine months ended March 31, 2017 and 2016 are as follows (dollars in millions):

[0001628280-17-005370:mdna:53]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Total cost of sales | $ | 542.8 |  |  | $ | 453.6 |  |  | $ | 89.2 |  |  | 19.7 | % |  | $ | 1,550.3 |  |  | $ | 1,433.6 |  |  | $ | 116.7 |  |  | 8.1 | % |
| Total gross profit | 88.3 |  |  | 79.2 |  |  | 9.2 |  |  | 11.6 | % |  | 261.8 |  |  | 257.7 |  |  | 4.0 |  |  | 1.6 | % |
| Total gross margin | 14.0 | % |  | 14.9 | % |  |  |  | (0.9 | )% |  | 14.4 | % |  | 15.2 | % |  |  |  | (0.8 | )% |

[0001628280-17-005370:mdna:54]
Comparison of Three Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:55]
The year-over-year increase in absolute dollars of cost of sales in the three months ended March 31, 2017 compared to the three months ended March 31, 2016 was primarily attributable to the increase in net sales. In the three months ended March 31, 2017, we recorded a $1.8 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $2.2 million, or 0.4% of net sales, in the three months ended March 31, 2016.

[0001628280-17-005370:mdna:56]
In the three months ended March 31, 2017, we recorded a $5.3 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to a $3.7 million expense, or 0.7% of net sales, in the three months ended March 31, 2016. The increase in the provision for warranty reserve was primarily due to an increase in cost of servicing warranty claims in the three months ended March 31, 2017. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-17-005370:mdna:57]
Gross margin percentage was 14.0% and 14.9% for the three months ended March 31, 2017 and 2016, respectively. The decrease was primarily due to higher component costs related to shortages of memory and SSD as well as a higher percentage of sales of our server systems based on mature, late life cycle processors such as Grantley which generally are lower margin sales. Geographically, we had higher sales in Asia where pricing is typically more competitive.

[0001628280-17-005370:mdna:58]
Comparison of Nine Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:59]
The year-over-year increase in absolute dollars of cost of sales in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016 was primarily attributable to the increase in net sales. In the nine months ended March 31, 2017, we recorded a $8.2 million expense, net of recovery, or 0.5% of net sales, related to the inventory provision as compared to $6.0 million, or 0.4% of net sales, in the nine months ended March 31, 2016.

[0001628280-17-005370:mdna:60]
In the nine months ended March 31, 2017, we recorded a $15.0 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to a $12.2 million expense, or 0.7% of net sales, in the nine months ended March 31, 2016. The increase in the provision for warranty reserve was primarily due to an increase in cost of servicing warranty claims in the nine months ended March 31, 2017.

[0001628280-17-005370:mdna:61]
Gross margin percentage was 14.4% and 15.2% for the nine months ended March 31, 2017 and 2016, respectively. The decrease was primarily due to higher costs related to shortages of memory and SSD as well as a higher percentage of sales of our server systems based on mature, late life cycle processors such as Grantley which generally are lower margin sales. Geographically, we had higher sales in Asia where pricing is typically more competitive.

[0001628280-17-005370:mdna:62]
[same as prior period, unchanged from 0001628280-17-000961:mdna:61]

[0001628280-17-005370:mdna:63]
Operating expenses for the three and nine months ended March 31, 2017 and 2016 are as follows (dollars in millions):

[0001628280-17-005370:mdna:64]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Research and development | $ | 35.9 |  |  | $ | 31.3 |  |  | $ | 4.6 |  |  | 14.8 | % |  | $ | 103.1 |  |  | $ | 89.8 |  |  | $ | 13.2 |  |  | 14.7 | % |
| Percentage of total net sales | 5.7 | % |  | 5.9 | % |  |  |  |  |  | 5.7 | % |  | 5.3 | % |  |  |  |  |
| Sales and marketing | 17.2 |  |  | 14.5 |  |  | 2.7 |  |  | 18.7 | % |  | 51.2 |  |  | 45.2 |  |  | 6.1 |  |  | 13.4 | % |
| Percentage of total net sales | 2.7 | % |  | 2.7 | % |  |  |  |  |  | 2.8 | % |  | 2.7 | % |  |  |  |  |
| General and administrative | 12.9 |  |  | 9.0 |  |  | 3.9 |  |  | 43.3 | % |  | 33.1 |  |  | 27.7 |  |  | 5.4 |  |  | 19.4 | % |
| Percentage of total net sales | 2.0 | % |  | 1.7 | % |  |  |  |  |  | 1.8 | % |  | 1.6 | % |  |  |  |  |
| Total operating expenses | $ | 65.9 |  |  | $ | 54.7 |  |  | $ | 11.2 |  |  | 20.5 | % |  | $ | 187.4 |  |  | $ | 162.7 |  |  | $ | 24.7 |  |  | 15.2 | % |
| Percentage of total net sales | 10.4 | % |  | 10.3 | % |  |  |  |  |  | 10.3 | % |  | 9.6 | % |  |  |  |  |

[0001628280-17-005370:mdna:65]
Comparison of Three Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:66]
Research and development expenses. Research and development expenses increased by $4.6 million, or 14.8% in the three months ended March 31, 2017 compared to the three months ended March 31, 2016. Research and development expenses were 5.7% and 5.9% of net sales for the three months ended March 31, 2017 and 2016, respectively. The increase in absolute dollars was driven primarily by an increase of $4.9 million in compensation and benefits including stock-based compensation expense, partially offset by an increase of $1.0 million in non-recurring engineering funding from certain suppliers and customers.

[0001628280-17-005370:mdna:67]
Research and development expenses include stock-based compensation expense of $3.1 million and $2.5 million for the three months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:68]
Our compensation and benefit expense in research and development increased from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan for the upcoming technology refresh cycle. We continue to believe that investments in research and development are critical to our future growth and competitive position in the marketplace. As such, we expect to continue to spend on current and future product development efforts.

[0001628280-17-005370:mdna:69]
Sales and marketing expenses. Sales and marketing expenses increased by $2.7 million, or 18.7% in the three months ended March 31, 2017 compared to the three months ended March 31, 2016. Sales and marketing expenses were 2.7% of net sales for both the three months ended March 31, 2017 and 2016. The increase in absolute dollars was primarily due to an increase of $1.2 million in compensation and benefits including stock-based compensation expense, resulting primarily from growth in sales and marketing personnel and an increase of $0.9 million in advertising, marketing promotional and trade show expenses.

[0001628280-17-005370:mdna:70]
Sales and marketing expenses include stock-based compensation expense of $0.5 million for both the three months ended March 31, 2017 and 2016.

[0001628280-17-005370:mdna:71]
General and administrative expenses. General and administrative expenses increased by $3.9 million, or 43.3% in the three months ended March 31, 2017 compared to the three months ended March 31, 2016. General and administrative expenses were 2.0% and 1.7% of net sales for the three months ended March 31, 2017 and 2016, respectively. The increase in absolute dollars was primarily due to an increase of $1.7 million in compensation and benefits including stock-based compensation expense and a $1.5 million foreign currency transaction loss in the three months ended March 31, 2017 as compared to a $0.2 million foreign currency transaction gain in the three months ended March 31, 2016.

[0001628280-17-005370:mdna:72]
General and administrative expenses include stock-based compensation expense of $0.9 million and $0.6 million for the three months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:73]
Comparison of Nine Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:74]
Research and development expenses. Research and development expenses increased by $13.2 million, or 14.7% in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016. Research and development expenses were 5.7% and 5.3% of net sales for the nine months ended March 31, 2017 and 2016, respectively. The increase in absolute dollars was driven primarily by an increase of $13.8 million in compensation and benefits including stock-based compensation expense and an increase of $0.5 million in development expenses for prototype materials, partially offset by an increase of $2.6 million in non-recurring engineering funding from certain suppliers and customers.

[0001628280-17-005370:mdna:75]
Research and development expenses include stock-based compensation expense of $9.0 million and $7.4 million for the nine months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:76]
Sales and marketing expenses. Sales and marketing expenses increased by $6.1 million, or 13.4% in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016. Sales and marketing expenses were 2.8% and 2.7% of net sales for the nine months ended March 31, 2017 and 2016, respectively. The increase in absolute dollars was primarily due to an increase of $3.3 million in compensation and benefits including stock-based compensation expense, resulting primarily from growth in sales and marketing personnel, an increase of $0.6 million in cooperative marketing funding to our customers and an increase of $0.4 million in advertising, marketing promotional and trade show expenses.

[0001628280-17-005370:mdna:77]
Sales and marketing expenses include stock-based compensation expense of $1.5 million and $1.3 million for the nine months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:78]
General and administrative expenses. General and administrative expenses increased by $5.4 million, or 19.4% in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016. General and administrative expenses were 1.8% and 1.6% of net sales for the nine months ended March 31, 2017 and 2016, respectively. The increase in absolute dollars was primarily due to an increase of $4.0 million in compensation and benefits including stock-based compensation expense, a $1.4 million foreign currency translation loss in the nine months ended March 31, 2017 as compared to a $1.6 million foreign currency transaction gain in the nine months ended March 31, 2016, partially offset by a decrease of $2.1 million in legal expenses.

[0001628280-17-005370:mdna:79]
General and administrative expenses include stock-based compensation expense of $2.6 million and $2.2 million for the nine months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:80]
[same as prior period, unchanged from 0001628280-17-000961:mdna:80]

[0001628280-17-005370:mdna:81]
Interest and other expense, net for the three and nine months ended March 31, 2017 and 2016 are as follows (dollars in millions):

[0001628280-17-005370:mdna:82]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Interest and other income, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | N/M* |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | (0.1 | ) |  | N/M* |  |
| Interest expense | (0.6 | ) |  | (0.4 | ) |  | (0.2 | ) |  | 33.8 | % |  | (1.4 | ) |  | (1.1 | ) |  | (0.3 | ) |  | 21.4 | % |
| Interest and other expense, net | $ | (0.6 | ) |  | $ | (0.4 | ) |  | $ | (0.2 | ) |  | 53.4 | % |  | $ | (1.4 | ) |  | $ | (1.0 | ) |  | $ | (0.4 | ) |  | 34.9 | % |

[0001628280-17-005370:mdna:83]
[same as prior period, unchanged from 0001628280-17-000961:mdna:83]

[0001628280-17-005370:mdna:84]
Comparison of Three Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:85]
Interest and other expense, net. Interest and other expense, net increased by $0.2 million in the three months ended March 31, 2017 compared to the three months ended March 31, 2016. The increases were primarily due to an increase in interest expense from our revolving lines of credit and term loans.

[0001628280-17-005370:mdna:86]
Comparison of Nine Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:87]
Interest and other expense, net. Interest and other expense, net increased by $0.4 million in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016. The increases were primarily due to an increase in interest expense from our revolving lines of credit and term loans.

[0001628280-17-005370:mdna:88]
[same as prior period, unchanged from 0001628280-17-000961:mdna:88]

[0001628280-17-005370:mdna:89]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2017 and 2016 are as follows (dollars in millions):

[0001628280-17-005370:mdna:90]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2017 |  | 2016 |  | $ |  | % |  | 2017 |  | 2016 |  | $ |  | % |
| Provision for income taxes | $ | 5.1 |  |  | $ | 7.4 |  |  | $ | (2.2 | ) |  | (30.4 | )% |  | $ | 20.8 |  |  | $ | 29.0 |  |  | $ | (8.1 | ) |  | (28.1 | )% |
| Percentage of total net sales | 0.9 | % |  | 1.4 | % |  |  |  |  |  | 1.1 | % |  | 1.7 | % |  |  |  |  |
| Effective tax rate | 23.6 | % |  | 30.7 | % |  |  |  |  |  | 28.5 | % |  | 30.8 | % |  |  |  |  |

[0001628280-17-005370:mdna:91]
Comparison of Three Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:92]
Provision for income taxes. Provision for income taxes decreased by $2.2 million, or 30.4% in the three months ended March 31, 2017 compared to the three months ended March 31, 2016. The effective tax rate was 23.6% and 30.7% for the three months ended March 31, 2017 and 2016, respectively. The lower income tax provision for the three months ended March 31, 2017 was primarily attributable to our lower operating income and a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction. The effective tax rate for the three months ended March 31, 2017 was lower primarily due to a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction.

[0001628280-17-005370:mdna:93]
Comparison of Nine Months Ended March 31, 2017 and 2016

[0001628280-17-005370:mdna:94]
Provision for income taxes. Provision for income taxes decreased by $8.1 million, or 28.1% in the nine months ended March 31, 2017 compared to the nine months ended March 31, 2016. The effective tax rate was 28.5% and 30.8% for the nine months ended March 31, 2017 and 2016, respectively. The lower income tax provision for the nine months ended March 31, 2017 was primarily attributable to our lower operating income and a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction. The effective tax rate for the nine months ended March 31, 2017 was lower primarily due to a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction.

[0001628280-17-005370:mdna:95]
[same as prior period, unchanged from 0001628280-17-000961:mdna:95]

[0001628280-17-005370:mdna:96]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $107.8 million and $181.0 million as of March 31, 2017 and June 30, 2016, respectively. Our cash in foreign locations was $40.4 million and $46.5 million at March 31, 2017 and June 30, 2016, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-17-005370:mdna:97]
Operating Activities. Net cash provided by (used in) operating activities was $(90.3) million and $92.8 million for the nine months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005370:mdna:98]
Net cash used in our operating activities for the nine months ended March 31, 2017 was primarily due to an increase in inventory of $201.5 million, an increase in accounts receivable of $103.0 million and an increase in deferred income taxes assets of $7.0 million, which were partially offset by an increase in accounts payable of $103.8 million, our net income of $52.2 million, an increase in other long-term liabilities of $14.4 million, stock-based compensation expense of $14.0 million, an increase in accrued liabilities of $13.6 million, depreciation and amortization expense of $11.8 million and provision for inventory of $8.2 million.

[0001628280-17-005370:mdna:99]
Net cash provided by our operating activities for the nine months ended March 31, 2016 was primarily due to our net income of $65.1 million, a decrease in accounts receivable of $35.9 million, an increase in other long-term liabilities of $21.8 million, stock-based compensation expense of $11.8 million, depreciation expense of $9.5 million, an increase in accrued liabilities of $5.7 million, and provision for inventory of $6.0 million, which were partially offset by a decrease in accounts payable of $23.2 million, an increase in inventory of $21.8 million, a decrease in income tax payable of $8.6 million, an increase in prepaid expenses and other assets of $3.8 million and an increase in deferred income taxes assets of $2.7 million.

[0001628280-17-005370:mdna:100]
The increase for the nine months ended March 31, 2017 in accounts receivable was primarily due to higher sales in the last month of the third quarter of fiscal year 2017 as compared to the last month of the fourth quarter of fiscal year 2016. The increase for the nine months ended March 31, 2017 in inventory and accounts payable was primarily due to higher inventory purchases in light of memory and SSD component shortages, sourcing for new product lines related to the SkyLake launch and supporting for the seasonally strong quarter ending June 30, 2017. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-17-005370:mdna:101]
The decrease for the nine months ended March 31, 2016 in accounts receivable was primarily due to lower sales in the last month of the third quarter of fiscal year 2016 as compared to the last month of the fourth quarter of fiscal year 2015. The decrease for the nine months ended March 31, 2016 in accounts payable was due to lower purchases of inventory in the third quarter of fiscal year 2016. The increase for the nine months ended March 31, 2016 in inventory was primarily due to lower sales in the third quarter of fiscal year 2016.

[0001628280-17-005370:mdna:102]
Investing activities. Net cash used in our investing activities was $23.6 million and $26.1 million for the nine months ended March 31, 2017 and 2016, respectively. In the nine months ended March 31, 2017, of the net cash used in our investing activities, $23.3 million was related to the purchase of property, plant and equipment, of which $13.1 million was related to the property and equipment for the manufacturing buildings at our Green Computing Park in San Jose, California. We anticipate investing approximately $3.6 million through August 2017 to complete the construction of a second manufacturing facility in the Green Computing Park. We plan to finance this development through our operating cash flows and additional borrowings from banks. In the nine months ended March 31, 2016, $25.1 million was related to the purchase of property, plant and equipment.

[0001628280-17-005370:mdna:103]
Financing activities. Net cash provided by our financing activities was $40.5 million and $13.2 million for the nine months ended March 31, 2017 and 2016, respectively. In the nine months ended March 31, 2017, we borrowed an additional $170.4 million under our term loan and revolving lines of credit from Bank of America and CTBC Bank and repaid $119.9 million in loans. We received $9.1 million related to the proceeds from the exercise of stock options in the nine months ended March 31, 2017. Further, we used $18.5 million to repurchase our outstanding common stock.

[0001628280-17-005370:mdna:104]
In the nine months ended March 31, 2016, we borrowed an additional $24.1 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $23.7 million in loans. Further, we received $10.7 million related to the proceeds from the exercise of stock options in the nine months ended March 31, 2016.

[0001628280-17-005370:mdna:105]
[same as prior period, unchanged from 0001628280-17-000961:mdna:105]

[0001628280-17-005370:mdna:106]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-17-005370:mdna:107]
[same as prior period, unchanged from 0001628280-17-000961:mdna:107]

[0001628280-17-005370:mdna:108]
[same as prior period, unchanged from 0001628280-17-000961:mdna:108]

[0001628280-17-005370:mdna:109]
[same as prior period, unchanged from 0001628280-17-000961:mdna:109]

[0001628280-17-005370:mdna:110]
In June 2015, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, we extended the revolving line of credit to mature on June 30, 2016.

[0001628280-17-005370:mdna:111]
In June 2016, we entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50.0 million term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-17-005370:mdna:112]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.78% at March 31, 2017. The letter of credit is charged at 1.25% per annum.

[0001628280-17-005370:mdna:113]
[same as prior period, unchanged from 0001628280-17-000961:mdna:113]

[0001628280-17-005370:mdna:114]
In December 2016, we entered into an amendment to the credit agreement with Bank of America to reduce the $55.0 million revolving line of credit facility to $45.0 million and increase the revolving line of credit for the Taiwan and the Netherlands subsidiaries from $10.0 million to $20.0 million.

[0001628280-17-005370:mdna:115]
As of March 31, 2017 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $42.5 million and $0.9 million, respectively. The total outstanding borrowings under the Bank of America lines of credit was $63.2 million and $62.2 million as of March 31, 2017 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.37% to 2.16% per annum at March 31, 2017 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of March 31, 2017, the unused revolving lines of credit amount with Bank of America under the credit agreements were $1.8 million.

[0001628280-17-005370:mdna:116]
In May 2017, we entered into a second amendment to the credit agreement with Bank of America to increase the revolving line of credit facility for the Company from $45.0 million to $85.0 million and extended the maturity date of the revolving lines of credit facility to October 31, 2018. In May 2017, we drew $20.0 million from Bank of America revolving line of credit with interest rate at 2.24% per annum to support our growth.

[0001628280-17-005370:mdna:117]
[same as prior period, unchanged from 0001628280-17-000961:mdna:117]

[0001628280-17-005370:mdna:118]
In April 2016, we entered into a new credit agreement with CTBC Bank that provides for (i) a 12-month NTD$700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100.0 million or $3.1 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40.0 million. We have extended the credit agreement to mature on May 31, 2017 and are currently negotiating with CTBC Bank to renew the credit agreement.

[0001628280-17-005370:mdna:119]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19.8 million and $20.4 million at March 31, 2017 and June 30, 2016, respectively. At March 31, 2017 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20.3 million and

[0001628280-17-005370:mdna:120]
$10.1 million, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.94% and 1.83% at March 31, 2017 and 0.90% and 1.25% per annum at June 30, 2016. At March 31, 2017, there was no available amount for future borrowing under this credit agreement.

[0001628280-17-005370:mdna:121]
Covenant Compliance

[0001628280-17-005370:mdna:122]
The credit agreement with Bank of America contain customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-17-005370:mdna:123]
[same as prior period, unchanged from 0001628280-17-000961:mdna:125]

[0001628280-17-005370:mdna:124]
[same as prior period, unchanged from 0001628280-17-000961:mdna:126]

[0001628280-17-005370:mdna:125]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $40,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-17-005370:mdna:126]
As of March 31, 2017, our total assets of $1,049.6 million collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarters company except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of March 31, 2017, total assets collateralizing the term loan with Bank of America were $97.6 million. As of March 31, 2017, we were in compliance with all financial covenants associated with the term loan and lines of credit with Bank of America under the credit agreement.

[0001628280-17-005370:mdna:127]
As of March 31, 2017, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.5 million. There are no financial covenants associated with the term loan with CTBC Bank.

[0001628280-17-005370:mdna:128]
[same as prior period, unchanged from 0001628280-17-000961:mdna:130]

[0001628280-17-005370:mdna:129]
In the three and nine months ended March 31, 2017, we paid our contract manufacturers within 34 to 76 days of invoice and Ablecom between 45 to 86 days of invoice. Ablecom is one of our major contract manufacturers and a related party. As of March 31, 2017 and June 30, 2016 amounts owed to Ablecom by us were approximately $50.4 million and $39.2 million, respectively.

[0001628280-17-005370:mdna:130]
[same as prior period, unchanged from 0001628280-17-000961:mdna:132]

[0001628280-17-005370:mdna:131]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of our common stock in the open market or in private transactions during the following twelve months at prevailing market prices. Repurchases will be made under the program using our own cash resources. This share repurchase program does not obligate us to acquire any particular amount of common stock, and it may be suspended at any time at our discretion. During the three months ended March 31, 2017, we did not purchase any shares of our common stock in the open market. During the nine months ended March 31, 2017, we purchased 888,097 shares of our common stock in the open market at a weighted average price of $20.79 per share for approximately $18.5 million.

[0001628280-17-005370:mdna:132]
[same as prior period, unchanged from 0001628280-17-000961:mdna:134]

[0001628280-17-005370:mdna:133]
The following table describes our contractual obligations as of March 31, 2017:

[0001628280-17-005370:mdna:134]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,750 |  |  | $ | 8,389 |  |  | $ | 3,940 |  |  | $ | 3,197 |  |  | $ | 20,276 |  |
| Capital leases, including interest | 314 |  |  | 476 |  |  | 173 |  |  | — |  |  | 963 |  |
| Debt, including interest (1) | 114,050 |  |  | 20,864 |  |  | 12,657 |  |  | — |  |  | 147,571 |  |
| Purchase commitments (2) | 412,541 |  |  | — |  |  | — |  |  | — |  |  | 412,541 |  |
| Total (3) | $ | 531,655 |  |  | $ | 29,729 |  |  | $ | 16,770 |  |  | $ | 3,197 |  |  | $ | 581,351 |  |

[0001628280-17-005370:mdna:135]
[same as prior period, unchanged from 0001628280-17-000961:mdna:137]

[0001628280-17-005370:mdna:136]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at March 31, 2017. |

[0001628280-17-005370:mdna:137]
[same as prior period, unchanged from 0001628280-17-000961:mdna:139]

[0001628280-17-005370:mdna:138]
| (3) | The table above excludes liabilities for deferred service revenue of $58.1 million and unrecognized tax benefits and related interest and penalties accrual of $17.3 million. Deferred service revenue represents billed services in advance which include extended warranty, on-site technical support, hardware and software maintenance. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 8 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes. |

[0001628280-17-005370:mdna:139]
[same as prior period, unchanged from 0001628280-17-000961:mdna:141]

[0001628280-17-005370:mdna:140]
[same as prior period, unchanged from 0001628280-17-000961:mdna:142]

[0001628280-17-005370:mdna:141]
[same as prior period, unchanged from 0001628280-17-000961:mdna:143]

[0001628280-17-005370:mdna:142]
[same as prior period, unchanged from 0001628280-17-000961:mdna:144]

[0001628280-17-005370:mdna:143]
[same as prior period, unchanged from 0001628280-17-000961:mdna:145]
