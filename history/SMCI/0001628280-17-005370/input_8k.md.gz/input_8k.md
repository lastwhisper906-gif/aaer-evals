# SMCI 8-K — 0001628280-17-004432 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-10

- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2017-05-10

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-17-004432:8k_2_02:1]
EX-99.1
2
exhibit991q3-2017.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-17-004432:8k_2_02:2]
Exhibit

[0001628280-17-004432:8k_2_02:3]
Exhibit 99.1

[0001628280-17-004432:8k_2_02:4]
Super Micro Computer, Inc. Announces 3rd Quarter 2017 Financial Results

[0001628280-17-004432:8k_2_02:5]
SAN JOSE, Calif., April 27, 2017 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced third quarter fiscal 2017 financial results for the quarter ended March 31, 2017.

[0001628280-17-004432:8k_2_02:6]
Fiscal 3rd Quarter Highlights

[0001628280-17-004432:8k_2_02:7]
| • | Quarterly net sales of $631.1 million, down 3.2% from the second quarter of fiscal year 2017 and up 18.5% from the same quarter of last year. |

[0001628280-17-004432:8k_2_02:8]
| • | GAAP net income of $16.7 million, down 24.2% from the second quarter of fiscal year 2017 and equal to the same quarter of last year. |

[0001628280-17-004432:8k_2_02:9]
| • | GAAP gross margin was 14.0%, down from 14.3% in the second quarter of fiscal year 2017 and down from 14.9% in the same quarter of last year. |

[0001628280-17-004432:8k_2_02:10]
| • | Server solutions accounted for 70.0% of net sales compared with 68.1% in the second quarter of fiscal year 2017 and 69.9% in the same quarter of last year. |

[0001628280-17-004432:8k_2_02:11]
Net sales for the third quarter ended March 31, 2017 totaled $631.1 million, down 3.2% from $652.0 million in the second quarter of fiscal year 2017. No customer accounted for more than 10% of net sales during the quarter ended March 31, 2017.

[0001628280-17-004432:8k_2_02:12]
GAAP net income for the third quarter of fiscal year 2017 and for the same period a year ago were both $16.7 million or $0.32 per diluted share. Included in net income for the quarter is $4.8 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the third quarter was $20.3 million, or $0.38 per diluted share, compared to non-GAAP net income of $19.0 million, or $0.36 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income decreased from the second quarter of fiscal year 2017 by $4.7 million or $(0.1) per diluted share.

[0001628280-17-004432:8k_2_02:13]
GAAP gross margin for the third quarter of fiscal year 2017 was 14.0% compared to 14.9% in the same period a year ago. Non-GAAP gross margin for the third quarter was 14.0% compared to 14.9% in the same period a year ago. GAAP gross margin for the second quarter of fiscal year 2017 was 14.3% and Non-GAAP gross margin for the second quarter of fiscal year 2017 was 14.4%.

[0001628280-17-004432:8k_2_02:14]
The GAAP income tax provision for the third quarter of fiscal year 2017 was $5.1 million or 23.6% of income before tax provision compared to $7.4 million or 30.7% in the same period a year ago and $9.3 million or 29.7% in the second quarter of fiscal year 2017. The effective tax rate for the third quarter of fiscal year 2017 was lower primarily due to a tax benefit resulting from the completion of an income tax audit in a foreign jurisdiction.

[0001628280-17-004432:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at March 31, 2017 were $110.5 million compared to $183.7 million at June 30, 2016. Free cash flow for the nine months ended March 31, 2017 was $(113.5) million, primarily due to an increase in the Company's cash used in operating activities.

[0001628280-17-004432:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-17-004432:8k_2_02:17]
The Company expects net sales of $655 million to $715 million for the fourth quarter of fiscal year 2017 ending June 30, 2017. The Company expects non-GAAP earnings per diluted share of approximately $0.40 to $0.50 for the fourth quarter.

[0001628280-17-004432:8k_2_02:18]
“We are pleased to report third quarter revenues that exceeded our guidance in a quarter complicated by shortages in memory and SSD. Our resurgent revenue growth and market share gains are a result of our strategy of developing vertical markets that expand our TAMs. Storage, IOT, Accelerated Computing, Enterprise and Asia contributed to the 18.5% growth from last year,” said Charles Liang, Chairman and Chief Executive Officer. “Supermicro’s preparation for the upcoming new Xeon processor launches has never been stronger and our traction with new customer engagement for seeding and early deployment has been outstanding. We expect to lead the industry with the most innovative platform architectures, the broadest product array and total solutions during the upcoming technology transitions.”

[0001628280-17-004432:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-17-004432:8k_2_02:20]
Conference Call Information

[0001628280-17-004432:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-715-1389 (International callers dial 1-913-312-1383) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, May 11, 2017, by dialing 1-844-512-2921 (International callers dial 1-412-317-6671) and entering replay PIN 7820076. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-17-004432:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-17-004432:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-17-004432:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-17-004432:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-17-004432:8k_2_02:26]
Supermicro®, a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, TwinPro, FatTwin™, Ultra Series, MicroCloud, MicroBlade, SuperBlade®, Simply Double, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-17-004432:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-17-004432:8k_2_02:28]
Supermicro, FatTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001628280-17-004432:8k_2_02:29]
All other brands, names and trademarks are the property of their respective owners.

[0001628280-17-004432:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | March 31, |  | June 30, |
|  |  |  |  | 2017 |  | 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 107,779 |  |  | $ | 180,964 |  |
|  | Accounts receivable, net | 391,334 |  |  | 288,941 |  |
|  | Inventory |  | 642,314 |  |  | 448,980 |  |
|  | Prepaid income taxes | 1,795 |  |  | 5,682 |  |
|  | Prepaid expenses and other current assets | 13,485 |  |  | 13,435 |  |
|  |  | Total current assets | 1,156,707 |  |  | 938,002 |  |
| Long-term investments | 2,643 |  |  | 2,643 |  |
| Property, plant and equipment, net | 195,553 |  |  | 187,949 |  |
| Deferred income taxes – noncurrent |  | 35,513 |  |  | 28,460 |  |
| Other assets |  |  | 14,040 |  |  | 8,546 |  |
|  |  | Total assets | $ | 1,404,456 |  |  | $ | 1,165,600 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 348,733 |  |  | $ | 249,239 |  |
|  | Accrued liabilities |  | 70,893 |  |  | 55,618 |  |
|  | Income taxes payable |  | 1,646 |  |  | 5,172 |  |
|  | Short-term debt and current portion of long-term debt, net of debt issuance costs | 113,260 |  |  | 53,589 |  |
|  |  | Total current liabilities | 534,532 |  |  | 363,618 |  |
| Long term debt, net of current portion and debt issuance costs | 32,251 |  |  | 40,000 |  |
| Other long-term liabilities | 60,647 |  |  | 40,603 |  |
|  |  | Total liabilities | 627,430 |  |  | 444,221 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 299,256 |  |  | 277,339 |  |
|  | Treasury stock (at cost) | (20,491 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (70 | ) |  | (85 | ) |
|  | Retained earnings |  | 498,165 |  |  | 445,971 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 776,860 |  |  | 721,195 |  |
|  | Noncontrolling interest | 166 |  |  | 184 |  |
|  |  | Total stockholders' equity | 777,026 |  |  | 721,379 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,404,456 |  |  | $ | 1,165,600 |  |

[0001628280-17-004432:8k_2_02:31]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 631,124 |  |  | $ | 532,721 |  |  | $ | 1,812,046 |  |  | $ | 1,691,303 |  |
| Cost of sales | 542,798 |  |  | 453,569 |  |  | 1,550,278 |  |  | 1,433,574 |  |
| Gross profit | 88,326 |  |  | 79,152 |  |  | 261,768 |  |  | 257,729 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 35,870 |  |  | 31,256 |  |  | 103,094 |  |  | 89,846 |  |
| Sales and marketing | 17,167 |  |  | 14,467 |  |  | 51,236 |  |  | 45,177 |  |
| General and administrative | 12,874 |  |  | 8,984 |  |  | 33,058 |  |  | 27,695 |  |
| Total operating expenses | 65,911 |  |  | 54,707 |  |  | 187,388 |  |  | 162,718 |  |
| Income from operations | 22,415 |  |  | 24,445 |  |  | 74,380 |  |  | 95,011 |  |
| Interest and other income, net | (51 | ) |  | 20 |  |  | 23 |  |  | 131 |  |
| Interest expense | (558 | ) |  | (417 | ) |  | (1,385 | ) |  | (1,141 | ) |
| Income before income tax provision | 21,806 |  |  | 24,048 |  |  | 73,018 |  |  | 94,001 |  |
| Income tax provision | 5,140 |  |  | 7,386 |  |  | 20,824 |  |  | 28,951 |  |
| Net income | $ | 16,666 |  |  | $ | 16,662 |  |  | $ | 52,194 |  |  | $ | 65,050 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.34 |  |  | $ | 0.35 |  |  | $ | 1.08 |  |  | $ | 1.36 |  |
| Diluted | $ | 0.32 |  |  | $ | 0.32 |  |  | $ | 1.01 |  |  | $ | 1.26 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 48,445 |  |  | 48,047 |  |  | 48,243 |  |  | 47,737 |  |
| Diluted | 51,918 |  |  | 52,238 |  |  | 51,579 |  |  | 51,637 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of sales | $ | 334 |  |  | $ | 294 |  |  | $ | 968 |  |  | $ | 792 |  |
| Research and development | 3,069 |  |  | 2,549 |  |  | 8,989 |  |  | 7,423 |  |
| Sales and marketing | 541 |  |  | 491 |  |  | 1,539 |  |  | 1,330 |  |
| General and administrative | 889 |  |  | 552 |  |  | 2,550 |  |  | 2,223 |  |
| Stock-based compensation expense before taxes | $ | 4,833 |  |  | $ | 3,886 |  |  | $ | 14,046 |  |  | $ | 11,768 |  |

[0001628280-17-004432:8k_2_02:32]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Nine Months Ended |
|  | March 31, |
|  | 2017 |  | 2016 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 52,194 |  |  | $ | 65,050 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 11,768 |  |  | 9,538 |  |
| Stock-based compensation expense | 14,046 |  |  | 11,768 |  |
| Excess tax benefits from stock-based compensation | (1,893 | ) |  | (2,506 | ) |
| Allowance for doubtful accounts | 611 |  |  | 1,014 |  |
| Provision for inventory | 8,162 |  |  | 6,026 |  |
| Exchange loss (gain) | 1,331 |  |  | (1,492 | ) |
| Deferred income taxes, net | (6,998 | ) |  | (2,657 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (103,004 | ) |  | 35,875 |  |
| Inventory | (201,496 | ) |  | (21,809 | ) |
| Prepaid expenses and other assets | 1,800 |  |  | (3,756 | ) |
| Accounts payable | 103,767 |  |  | (23,176 | ) |
| Income taxes payable, net | 1,511 |  |  | (8,583 | ) |
| Accrued liabilities | 13,564 |  |  | 5,701 |  |
| Other long-term liabilities | 14,365 |  |  | 21,833 |  |
| Net cash provided by (used in) operating activities | (90,272 | ) |  | 92,826 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (23,270 | ) |  | (25,120 | ) |
| Restricted cash | (286 | ) |  | (1,018 | ) |
| Net cash used in investing activities | (23,556 | ) |  | (26,138 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt, net of debt issuance costs | 170,416 |  |  | 24,100 |  |
| Repayment of debt | (119,852 | ) |  | (23,700 | ) |
| Payment to acquire treasury stock | (18,461 | ) |  | — |  |
| Proceeds from exercise of stock options | 9,123 |  |  | 10,661 |  |
| Excess tax benefits from stock-based compensation | 1,893 |  |  | 2,506 |  |
| Payment of obligations under capital leases | (184 | ) |  | (133 | ) |
| Advances under receivable financing arrangements | 4 |  |  | 835 |  |
| Minimum tax withholding paid on behalf of employees for restricted stock units | (2,476 | ) |  | (1,108 | ) |
| Net cash provided by financing activities | 40,463 |  |  | 13,161 |  |
| Effect of exchange rate fluctuations on cash | 180 |  |  | 1,115 |  |
| Net increase (decrease) in cash and cash equivalents | (73,185 | ) |  | 80,964 |  |
| Cash and cash equivalents at beginning of period | 180,964 |  |  | 95,442 |  |
| Cash and cash equivalents at end of period | $ | 107,779 |  |  | $ | 176,406 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | $ | 1,335 |  |  | $ | 1,136 |  |
| Cash paid for taxes, net of refunds | 24,958 |  |  | 34,562 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 314 |  |  | 299 |  |
| Accrued costs for property, plant and equipment purchases | 4,833 |  |  | 7,316 |  |

[0001628280-17-004432:8k_2_02:33]
| SUPER MICRO COMPUTER, INC. |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP GROSS PROFIT | $ | 88,326 |  |  | $ | 79,152 |  |  | $ | 261,768 |  |  | $ | 257,729 |  |
|  | Add back stock-based compensation (a) | 334 |  |  | 294 |  |  | 968 |  |  | 792 |  |
| Non-GAAP GROSS PROFIT | $ | 88,660 |  |  | $ | 79,446 |  |  | $ | 262,736 |  |  | $ | 258,521 |  |
| GAAP GROSS MARGIN | 14.0 | % |  | 14.9 | % |  | 14.4 | % |  | 15.2 | % |
|  | Add back stock-based compensation (a) | 0.0 | % |  | 0.0 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 14.0 | % |  | 14.9 | % |  | 14.5 | % |  | 15.3 | % |
| GAAP INCOME FROM OPERATIONS | $ | 22,415 |  |  | $ | 24,445 |  |  | $ | 74,380 |  |  | $ | 95,011 |  |
|  | Add back stock-based compensation (a) | 4,833 |  |  | 3,886 |  |  | 14,046 |  |  | 11,768 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 27,248 |  |  | $ | 28,331 |  |  | $ | 88,426 |  |  | $ | 106,779 |  |
| GAAP NET INCOME | $ | 16,666 |  |  | $ | 16,662 |  |  | $ | 52,194 |  |  | $ | 65,050 |  |
|  | Add back stock-based compensation (a) | 4,833 |  |  | 3,886 |  |  | 14,046 |  |  | 11,768 |  |
|  | Add back adjustments to tax provision (b) | (1,179 | ) |  | (1,554 | ) |  | (4,214 | ) |  | (3,341 | ) |
| Non-GAAP NET INCOME | $ | 20,320 |  |  | $ | 18,994 |  |  | $ | 62,026 |  |  | $ | 73,477 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.34 |  |  | $ | 0.35 |  |  | $ | 1.08 |  |  | $ | 1.36 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.08 |  |  | 0.05 |  |  | 0.21 |  |  | 0.18 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.42 |  |  | $ | 0.40 |  |  | $ | 1.29 |  |  | $ | 1.54 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.32 |  |  | $ | 0.32 |  |  | $ | 1.01 |  |  | $ | 1.26 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.06 |  |  | 0.04 |  |  | 0.17 |  |  | 0.14 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.38 |  |  | $ | 0.36 |  |  | $ | 1.18 |  |  | $ | 1.40 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP | 48,445 |  |  | 48,047 |  |  | 48,243 |  |  | 47,737 |  |
|  | BASIC - Non-GAAP | 48,445 |  |  | 48,047 |  |  | 48,243 |  |  | 47,737 |  |
|  | DILUTED – GAAP | 51,918 |  |  | 52,238 |  |  | 51,579 |  |  | 51,637 |  |
|  | DILUTED - Non-GAAP | 52,978 |  |  | 53,119 |  |  | 52,592 |  |  | 52,494 |  |

[0001628280-17-004432:8k_2_02:34]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three and nine months ended March 31, 2017 and 2016.

[0001628280-17-004432:8k_2_02:35]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 23.7% and 28.8% for the three and nine months ended March 31, 2017, respectively, and 32.0% and 30.5% for the three and nine months ended March 31, 2016, respectively.

[0001628280-17-004432:8k_2_02:36]
SOURCE: Super Micro Computer, Inc.

[0001628280-17-004432:8k_2_02:37]
Super Micro Computer, Inc.

[0001628280-17-004432:8k_2_02:38]
Howard Hideshima, 408-503-8000

[0001628280-17-004432:8k_2_02:39]
SVP, Chief Financial Officer

[0001628280-17-004432:8k_2_02:40]
ir@supermicro.com

[0001628280-17-004432:8k_2_02:41]
or

[0001628280-17-004432:8k_2_02:42]
Perry G. Hayes

[0001628280-17-004432:8k_2_02:43]
SVP, Investor Relations

[0001628280-17-004432:8k_2_02:44]
ir@supermicro.com

[0001628280-17-004432:8k_2_02:45]
SMCI-F
