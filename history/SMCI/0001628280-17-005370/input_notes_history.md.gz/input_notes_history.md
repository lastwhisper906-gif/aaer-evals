# SMCI note change history — 0001628280-17-000961 → 0001628280-17-005370


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001628280-17-005370:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through the next 12 months. As of March 31, 2017, these remaining non-cancellable commitments were $412,541,000 compared to $334,010,000 as of June 30, 2016.
  (was, 2017-02-07, similarity 0.8766):
[0001628280-17-000961:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of December 31, 2016, these remaining non-cancellable commitments were $402,229,000 compared to $334,010,000 as of June 30, 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001628280-17-005370:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.
  (was, 2017-02-07, similarity 0.9555):
[0001628280-17-000961:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.

- changed (2017-05-10):
[0001628280-17-005370:note_history:3]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectability and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016.
  (was, 2017-02-07, similarity 0.9034):
[0001628280-17-000961:note_history:3]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectibility and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position. The Company has not yet selected a transition method nor has it determined the effect of the guidance on its ongoing financial reporting.

- added (2017-05-10):
[0001628280-17-005370:note_history:4]
The Company intends to apply the new standard starting from the first quarter of fiscal year 2019. Based on the Company's preliminary plan, the Company intends to adopt the new standard using the modified retrospective method. The Company’s decision was based on a number of factors such as the significance of the impact of the new standard on the Company’s financial results, system readiness, including that of software procured from third-party providers, and the Company’s ability to accumulate and analyze the information necessary to assess the cumulative effect of the new standard through July 1, 2018. However, the Company continues to assess this in connection with its entire project plan. The Company expects the implementation of the new standard to impact the recognition of its revenue as follows:

- added (2017-05-10):
[0001628280-17-005370:note_history:5]
| • | Substantially all of the Company's current revenue is from the sale of hardware products. The Company does not expect any material changes to the timing or amount of revenue for these types of sales under the new standard. |

- added (2017-05-10):
[0001628280-17-005370:note_history:6]
| • | For extended warranty and on-site services, the Company is still assessing the impact and timing to revenue from the implementation of the new standard. However, the Company does not currently expect the new standard to have a material impact on its revenue for these types of arrangements. |

- added (2017-05-10):
[0001628280-17-005370:note_history:7]
| • | For software and intellectual property licenses, the Company is still assessing the impact and timing to revenue from the implementation of the new standard. However, the Company does not currently expect the new standard to have a material impact on its revenue for these types of arrangements. |

- added (2017-05-10):
[0001628280-17-005370:note_history:8]
| • | The Company's revenue disclosures are expected to expand. |

- added (2017-05-10):
[0001628280-17-005370:note_history:9]
The Company is still assessing the impact to its processes and systems configuration from the implementation of the new revenue standard and does not currently expect any significant changes to its other accounting policies from the adoption of the new revenue standard. The Company's implementation efforts are progressing as planned.

- changed (2017-05-10):
[0001628280-17-005370:note_history:10]
In March 2016, the FASB issued new accounting guidance, Compensation—Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. Early adoption is permitted for any interim or annual periods. This guidance is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.
  (was, 2017-02-07, similarity 0.6086):
[0001628280-17-000961:note_history:10]
In March 2016, the FASB issued new accounting guidance, Compensation—Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001628280-17-005370:note_history:11]
Short-term and long-term obligations as of March 31, 2017 and June 30, 2016 consisted of the following (in thousands):
  (was, 2017-02-07, similarity 0.9589):
[0001628280-17-000961:note_history:11]
Short-term and long-term obligations as of December 31, 2016 and June 30, 2016 consisted of the following (in thousands):

- changed (2017-05-10):
[0001628280-17-005370:note_history:12]
|  | March 31, |  | June 30, |
|  | 2017 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 63,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,300 |  |  | 10,100 |  |
| Total line of credit | 83,499 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 42,500 |  |  | 933 |  |
| CTBC Bank | 19,838 |  |  | 20,357 |  |
| Total term loans | 62,338 |  |  | 21,290 |  |
| Total debt | 145,837 |  |  | 93,589 |  |
| Less: debt issuance costs | (326 | ) |  | — |  |
| Total debt, net of debt issuance costs | 145,511 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (113,260 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 32,251 |  |  | $ | 40,000 |  |
  (was, 2017-02-07, similarity 0.9903):
[0001628280-17-000961:note_history:12]
|  | December 31, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 43,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,800 |  |  | 10,100 |  |
| Total line of credit | 63,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 45,000 |  |  | 933 |  |
| CTBC Bank | 18,521 |  |  | 20,357 |  |
| Total term loans | 63,521 |  |  | 21,290 |  |
| Total debt | 127,520 |  |  | 93,589 |  |
| Less: debt issuance costs | (345 | ) |  | — |  |
| Total debt, net of debt issuance costs | 127,175 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (92,443 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 34,732 |  |  | $ | 40,000 |  |

- changed (2017-05-10):
[0001628280-17-005370:note_history:13]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.78% at March 31, 2017. The letter of credit is charged at 1.25% per annum.
  (was, 2017-02-07, similarity 0.9718):
[0001628280-17-000961:note_history:13]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.61% at December 31, 2016. The letter of credit is charged at 1.25% per annum.

- changed (2017-05-10):
[0001628280-17-005370:note_history:14]
As of March 31, 2017 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $42,500,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $63,199,000 and $62,199,000 as of March 31, 2017 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.37% to 2.16% per annum at March 31, 2017 and from 1.02% to 1.96% per annum at June 30, 2016. As of March 31, 2017, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $1,801,000.
  (was, 2017-02-07, similarity 0.9485):
[0001628280-17-000961:note_history:14]
As of December 31, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $45,000,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $43,199,000 and $62,199,000 as of December 31, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.19% to 2.14% per annum at December 31, 2016 and from 1.02% to 1.96% per annum at June 30, 2016. As of December 31, 2016, the amount of the unused revolving lines of credit with Bank of America under the credit agreements was $21,801,000.

- added (2017-05-10):
[0001628280-17-005370:note_history:15]
In May 2017, The Company entered into a second amendment to the credit agreement with Bank of America to increase the revolving line of credit facility for the Company from $45,000,000 to $85,000,000 and extended the maturity date of the revolving lines of credit facility of the Company and the Netherlands subsidiary to October 31, 2018. In May 2017, the Company drew $20,000,000 from Bank of America revolving line of credit with interest rate at 2.24% per annum to support the Company's growth.

- changed (2017-05-10):
[0001628280-17-005370:note_history:16]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The Company has extended the credit agreement to mature on May 31, 2017 and is currently negotiating with CTBC Bank to renew the credit agreement.
  (was, 2017-02-07, similarity 0.8961):
[0001628280-17-000961:note_history:16]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

- changed (2017-05-10):
[0001628280-17-005370:note_history:17]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19,838,000 and $20,357,000 at March 31, 2017 and June 30, 2016, respectively. At March 31, 2017 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20,300,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.94% and 1.83% at March 31, 2017 and 0.90% and 1.25% per annum at June 30, 2016. At March 31, 2017, there was no available amount for future borrowing under this credit agreement.
  (was, 2017-02-07, similarity 0.9178):
[0001628280-17-000961:note_history:17]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $18,521,000 and $20,357,000 at December 31, 2016 and June 30, 2016, respectively. At December 31, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $20,800,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.95% and 2.15% at December 31, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At December 31, 2016, available for future borrowing under this credit agreement was $612,000.

- changed (2017-05-10):
[0001628280-17-005370:note_history:18]
As of March 31, 2017 and June 30, 2016, total assets of $1,049,629,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of March 31, 2017 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the credit agreement were $97,625,000 and $59,258,000, respectively. As of March 31, 2017, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.
  (was, 2017-02-07, similarity 0.9696):
[0001628280-17-000961:note_history:18]
As of December 31, 2016 and June 30, 2016, total assets of $998,259,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of December 31, 2016 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the credit agreement were $101,074,000 and $59,258,000, respectively. As of December 31, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

- changed (2017-05-10):
[0001628280-17-005370:note_history:19]
As of March 31, 2017 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,523,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2017.
  (was, 2017-02-07, similarity 0.9328):
[0001628280-17-000961:note_history:19]
As of December 31, 2016 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,623,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2016.

- removed (2017-05-10):
[0001628280-17-000961:note_history:20]
In February 2017, the Company drew an additional $10,000,000 from Bank of America revolving line of credit with interest rate at 1.29% per annum to support the Company's growth and expansion of its business in the Netherlands.

- removed (2017-05-10):
[0001628280-17-000961:note_history:21]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NTD$1,000,000,000 or $30,340,000 U.S. dollar equivalent. In January 2016, the Company extended the revolving line of credit to mature on March 31, 2016.

- removed (2017-05-10):
[0001628280-17-000961:note_history:22]
In January 2017, the Company drew an additional $8,000,000 from CTBC Bank revolving line of credit with the interest rate at 1.55% per annum to support the Company's growth and expansion of its business in the Netherlands.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001628280-17-005370:note_history:23]
Short-term and long-term obligations as of March 31, 2017 and June 30, 2016 consisted of the following (in thousands):
  (was, 2017-02-07, similarity 0.9589):
[0001628280-17-000961:note_history:23]
Short-term and long-term obligations as of December 31, 2016 and June 30, 2016 consisted of the following (in thousands):

- changed (2017-05-10):
[0001628280-17-005370:note_history:24]
|  | March 31, |  | June 30, |
|  | 2017 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 63,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,300 |  |  | 10,100 |  |
| Total line of credit | 83,499 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 42,500 |  |  | 933 |  |
| CTBC Bank | 19,838 |  |  | 20,357 |  |
| Total term loans | 62,338 |  |  | 21,290 |  |
| Total debt | 145,837 |  |  | 93,589 |  |
| Less: debt issuance costs | (326 | ) |  | — |  |
| Total debt, net of debt issuance costs | 145,511 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (113,260 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 32,251 |  |  | $ | 40,000 |  |
  (was, 2017-02-07, similarity 0.9903):
[0001628280-17-000961:note_history:24]
|  | December 31, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America | $ | 43,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 20,800 |  |  | 10,100 |  |
| Total line of credit | 63,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America | 45,000 |  |  | 933 |  |
| CTBC Bank | 18,521 |  |  | 20,357 |  |
| Total term loans | 63,521 |  |  | 21,290 |  |
| Total debt | 127,520 |  |  | 93,589 |  |
| Less: debt issuance costs | (345 | ) |  | — |  |
| Total debt, net of debt issuance costs | 127,175 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (92,443 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 34,732 |  |  | $ | 40,000 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001628280-17-005370:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.4% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at March 31, 2017.
  (was, 2017-02-07, similarity 0.9914):
[0001628280-17-000961:note_history:25]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.4% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at December 31, 2016.

- changed (2017-05-10):
[0001628280-17-005370:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $62,378,000 and $177,513,000, and sold products to Ablecom totaling $4,069,000 and $14,414,000 for the three and nine months ended March 31, 2017, respectively. The Company purchased products from Ablecom totaling $55,133,000 and $185,845,000, and sold products to Ablecom totaling $4,413,000 and $12,125,000 for the three and nine months ended March 31, 2016, respectively.
  (was, 2017-02-07, similarity 0.9016):
[0001628280-17-000961:note_history:26]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $64,930,000 and $115,135,000, and sold products to Ablecom totaling $7,003,000 and $10,345,000 for the three and six months ended December 31, 2016, respectively. The Company purchased products from Ablecom totaling $71,451,000 and $130,712,000, and sold products to Ablecom totaling $2,492,000 and $7,712,000 for the three and six months ended December 31, 2015, respectively.

- changed (2017-05-10):
[0001628280-17-005370:note_history:27]
Amounts owed to the Company by Ablecom as of March 31, 2017 and June 30, 2016 were $7,614,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2017 and June 30, 2016 were $50,407,000 and $39,152,000, respectively. For the three and nine months ended March 31, 2017, the Company paid Ablecom the majority of invoiced dollars between 45 and 86 days of invoice date. For the three and nine months ended March 31, 2017, the Company paid $1,776,000 and $4,712,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2016, the Company paid $3,003,000 and $5,901,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2017-02-07, similarity 0.864):
[0001628280-17-000961:note_history:27]
Amounts owed to the Company by Ablecom as of December 31, 2016 and June 30, 2016 were $12,378,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2016 and June 30, 2016 were $54,278,000 and $39,152,000, respectively. For the three and six months ended December 31, 2016, the Company paid Ablecom the majority of invoiced dollars between 48 and 83 days of invoice date. For the three and six months ended December 31, 2016, the Company paid $1,191,000 and $2,936,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2015, the Company paid $1,736,000 and $2,898,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2017-05-10):
[0001628280-17-005370:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $102,502,000 and $62,782,000 at March 31, 2017 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2017-02-07, similarity 0.9915):
[0001628280-17-000961:note_history:28]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $104,569,000 and $62,782,000 at December 31, 2016 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2017-05-10):
[0001628280-17-005370:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2017, $5,000 and $(19,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively. In the three and nine months ended March 31, 2016, $13,000 and $9,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively.
  (was, 2017-02-07, similarity 0.9498):
[0001628280-17-000961:note_history:29]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2016, $29,000 and $24,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively. In the three and six months ended December 31, 2015, $6,000 and $4,000 of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations, respectively.

- added (2017-05-10):
[0001628280-17-005370:note_history:30]
Investment in a Corporate Venture— In October 2016, the Company entered into agreements pursuant to which the Company agreed to contribute certain technology rights in connection with an investment in a privately-held company ("Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another investor in China. The transaction was closed in the three months ended March 31, 2017 and the investment has been accounted for under the equity method of accounting. The equity in earnings (losses) of the Corporate Venture were immaterial for the three months ended March 31, 2017 and were included in the Interest and Other Income (Expense), Net in the Company's condensed consolidated statements of operations. The Company recorded a deferred gain related to the contribution of certain technology rights of $6,650,000 in the transaction as of March 31, 2017. The deferred gain will be recognized as license revenue over time on the Company's statement of operations.

- added (2017-05-10):
[0001628280-17-005370:note_history:31]
Additionally, the Company sold products to the Corporate Venture in the three months ended March 31, 2017 and all the related intra-entity sales and profits on the products which remained unsold by the Corporate Venture as of March 31, 2017 have been eliminated and reduced the Company's investment in the Corporate Venture. As of March 31, 2017, the Company's equity investment in the Corporate Venture was $6,714,000 and was recorded under Other Assets on the Company's condensed consolidated balance sheets.
