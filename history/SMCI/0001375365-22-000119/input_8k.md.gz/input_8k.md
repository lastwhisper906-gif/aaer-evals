# SMCI 8-K — 0001375365-22-000115 filed 2022-11-01

## item codes, every 8-K on or before 2022-11-04

- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2022-11-04

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-22-000115:8k_2_02:1]
EX-99.1
2
exhibit991_20220930.htm
EX-99.1

[0001375365-22-000115:8k_2_02:2]
Document

[0001375365-22-000115:8k_2_02:3]
Exhibit 99.1

[0001375365-22-000115:8k_2_02:4]
Supermicro Announces First Quarter Fiscal Year 2023 Financial Results

[0001375365-22-000115:8k_2_02:5]
SAN JOSE, Calif. -- November 1, 2022 (BUSINESS WIRE) -- Supermicro (Nasdaq: SMCI), a Total IT Solution Provider for Cloud, AI/ML, Storage, and 5G/Edge, today announced financial results for its first quarter of fiscal year 2023 ended September 30, 2022.

[0001375365-22-000115:8k_2_02:6]
First Quarter Fiscal Year 2023 Highlights

[0001375365-22-000115:8k_2_02:7]
•Net sales of $1.85 billion versus $1.64 billion in the fourth quarter of fiscal year 2022 and $1.03 billion in the same quarter of last year.

[0001375365-22-000115:8k_2_02:8]
•Gross margin of 18.8% versus 17.6% in the fourth quarter of fiscal year 2022 and 13.4% in the same quarter of last year.

[0001375365-22-000115:8k_2_02:9]
•Net income of $184 million versus $141 million in the fourth quarter of fiscal year 2022 and $25 million in the same quarter of last year.

[0001375365-22-000115:8k_2_02:10]
•Diluted net income per common share of $3.35 versus $2.60 in the fourth quarter of fiscal year 2022 and $0.48 in the same quarter of last year.

[0001375365-22-000115:8k_2_02:11]
•Non-GAAP diluted net income per common share of $3.42 versus $2.62 in the fourth quarter of fiscal year 2022 and $0.58 in the same quarter of last year.

[0001375365-22-000115:8k_2_02:12]
•Cash flow provided by operations for the first quarter of fiscal year 2023 of $314 million and capital expenditures of $11 million.

[0001375365-22-000115:8k_2_02:13]
Non-GAAP gross margin for the first quarter of fiscal year 2023 was 18.8%. Non-GAAP diluted net income per common share for the first quarter of fiscal year 2023 was $3.42, which adds back stock-based compensation expenses of $7.8 million,  net of the related tax effects.

[0001375365-22-000115:8k_2_02:14]
As of September 30, 2022, total cash and cash equivalents was $238 million and total bank debt was $250 million.

[0001375365-22-000115:8k_2_02:15]
“In Q1 fiscal 2023, our revenue reached a record $1.85 billion dollars, which makes it our 7th consecutive quarter of accelerating YoY growth,” said Charles Liang, Chairman and CEO, Supermicro. “The 79% YoY quarterly growth is about ten times faster than the current industry average. It proves that our Green Computing and Total IT Solutions continue to gain customers’ acceptance and trust. We recognize the opportunities being driven by more demanding compute, storage, telco and AI workloads. Our new generation of products based on optimized system building blocks is the foundation behind our strong, continued growth going forward.”

[0001375365-22-000115:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-22-000115:8k_2_02:17]
For the second quarter of fiscal year 2023 ending December 31, 2022, the Company expects net sales of $1.7 billion to $1.8 billion, GAAP net income per diluted share of $2.54 to $2.81 and non-GAAP net income per diluted share of $2.64 to $2.90. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 17.4% and 19.4%, respectively, and a fully diluted share count of 55.7 million shares for GAAP and fully diluted share count of 57.0 million shares for non-GAAP. The outlook for Q2 of fiscal year 2023 GAAP net income per diluted share includes approximately $11.8 million in expected stock-based compensation expense.

[0001375365-22-000115:8k_2_02:18]
For fiscal year 2023 ending June 30, 2023, the Company raises its guidance for net sales from a range of $6.2 billion to $7.0 billion to $6.5 billion to $7.5 billion, GAAP net income per diluted share from at least $7.27 to a range of $8.50 to $11.00, and non-GAAP net income per diluted share from at least $7.50 to a range of $9.00 to $11.30. The Company’s projections for annual GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 19.2% and 19.8%, respectively, and a fully diluted share count of 57.0 million shares for GAAP and fully diluted share count of 58.4 million shares for non-GAAP. The outlook for fiscal year 2023 GAAP net income per diluted share includes approximately $32.7 million in expected stock-based compensation and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000115:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-22-000115:8k_2_02:20]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its first quarter of fiscal year 2023.

[0001375365-22-000115:8k_2_02:21]
Those wishing to access the live webcast may use the following link:

[0001375365-22-000115:8k_2_02:22]
https://events.q4inc.com/attendee/707364803

[0001375365-22-000115:8k_2_02:23]
The conference call can be accessed by registering online at:

[0001375365-22-000115:8k_2_02:24]
https://conferencingportals.com/event/fIceWmPv

[0001375365-22-000115:8k_2_02:25]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-22-000115:8k_2_02:26]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-22-000115:8k_2_02:27]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-22-000115:8k_2_02:28]
Use of Non-GAAP Financial Measures

[0001375365-22-000115:8k_2_02:29]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, litigation and controls remediation expense and other expenses, adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-22-000115:8k_2_02:30]
About Super Micro Computer, Inc.

[0001375365-22-000115:8k_2_02:31]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-22-000115:8k_2_02:32]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-22-000115:8k_2_02:33]
Investor Relations Contact

[0001375365-22-000115:8k_2_02:34]
Nicole Noutsios

[0001375365-22-000115:8k_2_02:35]
email: ir@supermicro.com

[0001375365-22-000115:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000115:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-22-000115:8k_2_02:38]
(in thousands)

[0001375365-22-000115:8k_2_02:39]
(unaudited)

[0001375365-22-000115:8k_2_02:40]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 238,268 |  |  | $ | 267,397 |  |
| Accounts receivable, net of allowance for credit losses | 736,312 |  |  | 834,513 |  |
| Inventories | 1,736,055 |  |  | 1,545,606 |  |
| Prepaid expenses and other current assets | 169,245 |  |  | 158,799 |  |
| Total current assets | 2,879,880 |  |  | 2,806,315 |  |
| Investment in equity investee | 4,352 |  |  | 5,329 |  |
| Property, plant and equipment, net | 290,752 |  |  | 285,972 |  |
| Deferred income taxes, net | 89,155 |  |  | 69,929 |  |
| Other assets | 37,144 |  |  | 37,532 |  |
| Total assets | $ | 3,301,283 |  |  | $ | 3,205,077 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 785,025 |  |  | $ | 655,403 |  |
| Accrued liabilities | 213,521 |  |  | 212,419 |  |
| Income taxes payable | 68,411 |  |  | 41,743 |  |
| Short-term debt | 101,173 |  |  | 449,146 |  |
| Deferred revenue | 185,225 |  |  | 111,313 |  |
| Total current liabilities | 1,353,355 |  |  | 1,470,024 |  |
| Deferred revenue, non-current | 134,625 |  |  | 122,548 |  |
| Long-term debt | 148,551 |  |  | 147,618 |  |
| Other long-term liabilities | 39,549 |  |  | 39,140 |  |
| Total liabilities | 1,676,080 |  |  | 1,779,330 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 497,183 |  |  | 481,741 |  |
| Accumulated other comprehensive income | 514 |  |  | 911 |  |
| Retained earnings | 1,127,339 |  |  | 942,923 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,625,036 |  |  | 1,425,575 |  |
| Noncontrolling interest | 167 |  |  | 172 |  |
| Total stockholders’ equity | 1,625,203 |  |  | 1,425,747 |  |
| Total liabilities and stockholders’ equity | $ | 3,301,283 |  |  | $ | 3,205,077 |  |

[0001375365-22-000115:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000115:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-22-000115:8k_2_02:43]
(in thousands except per share amounts)

[0001375365-22-000115:8k_2_02:44]
(unaudited)

[0001375365-22-000115:8k_2_02:45]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net sales | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |
| Cost of sales | 1,504,595 |  |  | 894,591 |  |  |  |  |  |
| Gross profit | 347,535 |  |  | 138,139 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 74,243 |  |  | 65,143 |  |  |  |  |  |
| Sales and marketing | 29,363 |  |  | 21,624 |  |  |  |  |  |
| General and administrative | 23,806 |  |  | 22,244 |  |  |  |  |  |
| Total operating expenses | 127,412 |  |  | 109,011 |  |  |  |  |  |
| Income from operations | 220,123 |  |  | 29,128 |  |  |  |  |  |
| Other income, net | 8,054 |  |  | 50 |  |  |  |  |  |
| Interest expense | (3,938) |  |  | (804) |  |  |  |  |  |
| Income before income tax provision | 224,239 |  |  | 28,374 |  |  |  |  |  |
| Income tax (provision) | (38,934) |  |  | (3,325) |  |  |  |  |  |
| Share of (loss) income from equity investee, net of taxes | (889) |  |  | 388 |  |  |  |  |  |
| Net income | $ | 184,416 |  |  | $ | 25,437 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 3.51 |  |  | $ | 0.50 |  |  |  |  |  |
| Diluted | $ | 3.35 |  |  | $ | 0.48 |  |  |  |  |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 52,598 |  |  | 50,796 |  |  |  |  |  |
| Diluted | 55,017 |  |  | 52,916 |  |  |  |  |  |

[0001375365-22-000115:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-22-000115:8k_2_02:47]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Cost of sales | $ | 884 |  |  | $ | 447 |  |  |  |  |  |
| Research and development | 6,118 |  |  | 3,880 |  |  |  |  |  |
| Sales and marketing | 809 |  |  | 517 |  |  |  |  |  |
| General and administrative | 3,203 |  |  | 2,171 |  |  |  |  |  |
| Stock-based compensation expense | $ | 11,014 |  |  | $ | 7,015 |  |  |  |  |  |

[0001375365-22-000115:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000115:8k_2_02:49]
SELECTED CASH FLOW INFORMATION

[0001375365-22-000115:8k_2_02:50]
(in thousands)

[0001375365-22-000115:8k_2_02:51]
(unaudited)

[0001375365-22-000115:8k_2_02:52]
|  | Three Months EndedSeptember 30, |
|  | 2022 |  | 2021 |
| Net cash provided by (used in) operating activities | $ | 313,587 |  |  | $ | (134,571) |  |
| Net cash (used in) investing activities | (10,746) |  |  | (11,902) |  |
| Net cash (used in) provided by financing activities | (331,183) |  |  | 184,262 |  |
| Effect of exchange rate fluctuations on cash | (1,472) |  |  | (11) |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | (29,813) |  |  | 37,778 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 268,559 |  |  | 233,449 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 238,746 |  |  | $ | 271,227 |  |

[0001375365-22-000115:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000115:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000115:8k_2_02:55]
(in thousands except per share amounts)

[0001375365-22-000115:8k_2_02:56]
(unaudited)

[0001375365-22-000115:8k_2_02:57]
|  | Three Months Ended |  |  |
|  | September 30, 2022 |  | June 30, 2022 |  | September 30, 2021 |  |  |  |  |
| GAAP GROSS PROFIT | $ | 347,535 |  |  | $ | 287,344 |  |  | $ | 138,139 |  |  |  |  |  |
| Stock-based compensation | 884 |  |  | 498 |  |  | 447 |  |  |  |  |  |
| Other expenses | — |  |  | — |  |  | 295 |  |  |  |  |  |
| NON-GAAP GROSS PROFIT | $ | 348,419 |  |  | $ | 287,842 |  |  | $ | 138,881 |  |  |  |  |  |
| GAAP GROSS MARGIN | 18.8 | % |  | 17.6 | % |  | 13.4 | % |  |  |  |  |
| Stock-based compensation | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  |  |  |  |
| Other expenses | — | % |  | — | % |  | 0.0%. |  |  |  |  |
| NON-GAAP GROSS MARGIN | 18.8 | % |  | 17.6 | % |  | 13.4 | % |  |  |  |  |
| GAAP OPERATING EXPENSE | $ | 127,412 |  |  | $ | 122,131 |  |  | $ | 109,011 |  |  |  |  |  |
| Stock-based compensation | (10,130) |  |  | (8,386) |  |  | (6,568) |  |  |  |  |  |
| Special performance bonuses | — |  |  | — |  |  | (158) |  |  |  |  |  |
| Litigation and controls remediation expenses | — |  |  | (234) |  |  | (1,326) |  |  |  |  |  |
| NON-GAAP OPERATING EXPENSE | $ | 117,282 |  |  | $ | 113,511 |  |  | $ | 100,959 |  |  |  |  |  |
| GAAP INCOME FROM OPERATIONS | $ | 220,123 |  |  | $ | 165,213 |  |  | $ | 29,128 |  |  |  |  |  |
| Stock-based compensation | 11,014 |  |  | 8,884 |  |  | 7,015 |  |  |  |  |  |
| Special performance bonuses | — |  |  | — |  |  | 453 |  |  |  |  |  |
| Litigation and controls remediation expenses | — |  |  | 234 |  |  | 1,326 |  |  |  |  |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 231,137 |  |  | $ | 174,331 |  |  | $ | 37,922 |  |  |  |  |  |
| GAAP OPERATING MARGIN | 11.9 | % |  | 10.1 | % |  | 2.8 | % |  |  |  |  |
| Stock-based compensation | 0.6 | % |  | 0.6 | % |  | 0.7 | % |  |  |  |  |
| Special performance bonuses | — | % |  | — | % |  | 0.1 | % |  |  |  |  |
| Litigation and controls remediation expenses | — | % |  | 0.0 | % |  | 0.1 | % |  |  |  |  |
| NON-GAAP OPERATING MARGIN | 12.5 | % |  | 10.7 | % |  | 3.7 | % |  |  |  |  |
| GAAP TAX EXPENSE | $ | 38,934 |  |  | $ | 25,760 |  |  | $ | 3,325 |  |  |  |  |  |
| Adjustments to tax provision | 3,230 |  |  | 4,137 |  |  | 2,830 |  |  |  |  |  |
| NON-GAAP TAX EXPENSE | $ | 42,164 |  |  | $ | 29,897 |  |  | $ | 6,155 |  |  |  |  |  |
| GAAP NET INCOME | $ | 184,416 |  |  | $ | 140,822 |  |  | $ | 25,437 |  |  |  |  |  |
| Stock-based compensation | 11,014 |  |  | 8,884 |  |  | 7,015 |  |  |  |  |  |
| Special performance bonuses | — |  |  | — |  |  | 453 |  |  |  |  |  |
| Litigation and controls remediation expenses | — |  |  | 234 |  |  | 1,326 |  |  |  |  |  |
| Adjustments to tax provision | (3,230) |  |  | (4,137) |  |  | (2,830) |  |  |  |  |  |
| NON-GAAP NET INCOME | $ | 192,200 |  |  | $ | 145,803 |  |  | $ | 31,401 |  |  |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.51 |  |  | $ | 2.70 |  |  | $ | 0.50 |  |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.14 |  |  | 0.10 |  |  | 0.12 |  |  |  |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.65 |  |  | $ | 2.80 |  |  | $ | 0.62 |  |  |  |  |  |

[0001375365-22-000115:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000115:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000115:8k_2_02:60]
(in thousands except per share amounts)

[0001375365-22-000115:8k_2_02:61]
(unaudited)

[0001375365-22-000115:8k_2_02:62]
|  | Three Months Ended |  |  |
|  | September 30, 2022 |  | June 30, 2022 |  | September 30, 2021 |  |  |  |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.35 |  |  | $ | 2.60 |  |  | $ | 0.48 |  |  |  |  |  |
| Impact of Non-GAAP adjustments | 0.07 |  |  | 0.02 |  |  | 0.10 |  |  |  |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.42 |  |  | $ | 2.62 |  |  | $ | 0.58 |  |  |  |  |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 52,598 |  |  | 52,111 |  |  | 50,796 |  |  |  |  |  |
| BASIC – NON-GAAP | 52,598 |  |  | 52,111 |  |  | 50,796 |  |  |  |  |  |
| DILUTED – GAAP | 55,017 |  |  | 54,260 |  |  | 52,916 |  |  |  |  |  |
| DILUTED – NON-GAAP | 56,271 |  |  | 55,611 |  |  | 54,363 |  |  |  |  |  |
