# SMCI notes — 0001375365-22-000119


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-22-000119:notes:1]
[same as prior period, unchanged from 0001375365-22-000058:notes:1]

[0001375365-22-000119:notes:2]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Part II, Item 8, Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 29, 2022, for the year ended June 30, 2022. Management's estimates take into consideration, as applicable, general macroeconomic conditions, inflation, changes in interest rates and geopolitical events.

[0001375365-22-000119:notes:3]
[same as prior period, unchanged from 0001375365-22-000058:notes:3]

[0001375365-22-000119:notes:4]
[same as prior period, unchanged from 0001375365-22-000058:notes:4]

[0001375365-22-000119:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.

[0001375365-22-000119:notes:6]
[same as prior period, unchanged from 0001375365-22-000058:notes:6]

[0001375365-22-000119:notes:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 16.1% and 25.7% of total purchases for the three months ended September 30, 2022, and two suppliers accounted for 20.1% and 6.3% of total purchases for the three months ended September 30, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% and 9.6% of total cost of sales for the three months ended September 30, 2022 and 2021, respectively.

[0001375365-22-000119:notes:8]
[same as prior period, unchanged from 0001375365-22-000058:notes:8]

[0001375365-22-000119:notes:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022 and no single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021. Two customers accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2022 which accounted for 11.0% and 10.3%. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.

[0001375365-22-000119:notes:10]
[same as prior period, unchanged from 0001375365-22-000058:notes:10]

[0001375365-22-000119:notes:11]
There were no new pronouncements recently adopted.

[0001375365-22-000119:notes:12]
[same as prior period, unchanged from 0001375365-22-000058:notes:12]

[0001375365-22-000119:notes:13]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendments are effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In April 2022, FASB issued a proposed accounting standard update for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The proposed amendment defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have material impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-22-000119:notes:14]
[same as prior period, unchanged from 0001375365-22-000058:notes:14]

[0001375365-22-000119:notes:15]
The Company disaggregates revenue by type of product and by the geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

[0001375365-22-000119:notes:16]
[same as prior period, unchanged from 0001375365-22-000058:notes:16]

[0001375365-22-000119:notes:17]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713,056 |  |  |  |  | $ | 849,856 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 139,074 |  |  |  |  | 182,874 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  |  |  | $ | 1,032,730 |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-22-000119:notes:18]
[same as prior period, unchanged from 0001375365-22-000058:notes:18]

[0001375365-22-000119:notes:19]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):

[0001375365-22-000119:notes:20]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 1,295,504 |  |  | $ | 560,948 |  |  |  |  |  |
| Asia | 270,024 |  |  | 263,086 |  |  |  |  |  |
| Europe | 235,074 |  |  | 179,694 |  |  |  |  |  |
| Other | 51,528 |  |  | 29,002 |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |

[0001375365-22-000119:notes:21]
[same as prior period, unchanged from 0001375365-22-000058:notes:21]

[0001375365-22-000119:notes:22]
[same as prior period, unchanged from 0001375365-22-000058:notes:22]

[0001375365-22-000119:notes:23]
[same as prior period, unchanged from 0001375365-22-000058:notes:23]

[0001375365-22-000119:notes:24]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2022, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $33.5 million.

[0001375365-22-000119:notes:25]
Deferred revenue increased $86.0 million as of September 30, 2022 as compared to the fiscal year ended June 30, 2022 of which $69.6 million was due to the increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-22-000119:notes:26]
[same as prior period, unchanged from 0001375365-22-000058:notes:26]

[0001375365-22-000119:notes:27]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2022 was $319.8 million. The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-22-000119:notes:28]
[same as prior period, unchanged from 0001375365-22-000058:notes:28]

[0001375365-22-000119:notes:29]
[same as prior period, unchanged from 0001375365-22-000058:notes:29]

[0001375365-22-000119:notes:30]
[same as prior period, unchanged from 0001375365-22-000058:notes:30]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-22-000119:notes:31]
The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-22-000119:notes:32]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2022 and 2021 (in thousands, except per share amounts):

[0001375365-22-000119:notes:33]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 184,416 |  |  | $ | 25,437 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 52,598 |  |  | 50,796 |  |  |  |  |  |
| Effect of dilutive securities | 2,419 |  |  | 2,120 |  |  |  |  |  |
| Weighted-average diluted shares | 55,017 |  |  | 52,916 |  |  |  |  |  |
| Basic net income per common share | $ | 3.51 |  |  | $ | 0.50 |  |  |  |  |  |
| Diluted net income per common share | $ | 3.35 |  |  | $ | 0.48 |  |  |  |  |  |

[0001375365-22-000119:notes:34]
For the three months ended September 30, 2022 and 2021, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 307,395 and 694,211 for the three months ended September 30, 2022 and 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-22-000119:notes:35]
[same as prior period, unchanged from 0001375365-22-000058:notes:35]

[0001375365-22-000119:notes:36]
[same as prior period, unchanged from 0001375365-22-000058:notes:36]

[0001375365-22-000119:notes:37]
|  | September 30, 2022 |  | June 30, 2022 |
| Finished goods | $ | 1,096,811 |  |  | $ | 1,025,555 |  |
| Work in process | 333,092 |  |  | 209,576 |  |
| Purchased parts and raw materials | 306,152 |  |  | 310,475 |  |
| Total inventories | $ | 1,736,055 |  |  | $ | 1,545,606 |  |

[0001375365-22-000119:notes:38]
During the three months ended September 30, 2022 and 2021, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $9.6 million and $3.5 million, respectively. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.

[0001375365-22-000119:notes:39]
[same as prior period, unchanged from 0001375365-22-000058:notes:39]

[0001375365-22-000119:notes:40]
|  | September 30, 2022 |  | June 30, 2022 |
| Other receivables (1) | $ | 150,082 |  |  | $ | 138,054 |  |
| Prepaid expenses | 7,534 |  | 5,632 |
| Deferred service costs | 6,113 |  | 5,562 |
| Prepaid income tax | — |  |  | 2,352 |
| Restricted cash | — |  |  | 251 |  |
| Others | 5,516 |  |  | 6,948 |  |
| Total prepaid expenses and other current assets | $ | 169,245 |  |  | $ | 158,799 |  |

[0001375365-22-000119:notes:41]
(1) Other receivables are receivables from contract manufacturers based on certain buy-sell arrangements of $120.3 million and $98.9 million as of September 30, 2022 and June 30, 2022, respectively.

[0001375365-22-000119:notes:42]
Cash, Cash equivalents and Restricted cash:

[0001375365-22-000119:notes:43]
|  | September 30, 2022 |  | June 30, 2022 |
| Cash and cash equivalents | $ | 238,268 |  |  | $ | 267,397 |  |
| Restricted cash included in prepaid expenses and other current assets | — |  |  | 251 |  |
| Restricted cash included in other assets | 478 |  |  | 911 |  |
| Total cash, cash equivalents and restricted cash | $ | 238,746 |  |  | $ | 268,559 |  |

[0001375365-22-000119:notes:44]
[same as prior period, unchanged from 0001375365-22-000058:notes:45]

[0001375365-22-000119:notes:45]
|  | September 30, 2022 |  | June 30, 2022 |
| Buildings | $ | 143,496 |  |  | $ | 143,509 |  |
| Machinery and equipment | 119,978 |  |  | 113,665 |  |
| Land | 84,616 |  |  | 84,616 |  |
| Furniture and fixtures | 47,600 |  |  | 43,282 |  |
| Building and leasehold improvements | 45,709 |  |  | 45,169 |  |
| Software | 23,273 |  |  | 23,186 |  |
| Building construction in progress | 303 |  |  | 303 |  |
|  | 464,975 |  |  | 453,730 |  |
| Accumulated depreciation and amortization | (174,223) |  |  | (167,758) |  |
| Property, plant and equipment, net | $ | 290,752 |  |  | $ | 285,972 |  |

[0001375365-22-000119:notes:46]
[same as prior period, unchanged from 0001375365-22-000058:notes:48]

[0001375365-22-000119:notes:47]
|  | September 30, 2022 |  | June 30, 2022 |
| Operating lease right-of-use asset | $ | 22,497 |  |  | $ | 23,679 |  |
| Deferred service costs, non-current | 7,518 |  |  | 6,316 |  |
| Prepaid expense, non-current | 1,949 |  |  | 2,011 |  |
| Investment in auction rate security | 1,590 |  |  | 1,590 |  |
| Deposits | 1,215 |  |  | 1,069 |  |
| Restricted cash, non-current | 478 |  |  | 911 |  |
| Others | 1,897 |  |  | 1,956 |  |
| Total other assets | $ | 37,144 |  |  | $ | 37,532 |  |

[0001375365-22-000119:notes:48]
[same as prior period, unchanged from 0001375365-22-000058:notes:50]

[0001375365-22-000119:notes:49]
|  | September 30, 2022 |  | June 30, 2022 |
| Accrued payroll and related expenses | $ | 48,779 |  |  | $ | 57,736 |  |
| Contract manufacturers liabilities | 48,579 |  |  | 41,125 |  |
| Customer deposits | 35,099 |  |  | 30,421 |  |
| Accrued legal liabilities (Note 11) | 18,250 |  | 18,250 |  |
| Accrued cooperative marketing expenses | 9,722 |  |  | 8,757 |  |
| Accrued warranty costs | 8,540 |  |  | 9,073 |  |
| Operating lease liability | 6,960 |  |  | 7,139 |  |
| Accrued professional fees | 3,130 |  |  | 4,281 |  |
| Others | 34,461 |  |  | 35,637 |  |
| Total accrued liabilities | $ | 213,521 |  |  | $ | 212,419 |  |

[0001375365-22-000119:notes:50]
[same as prior period, unchanged from 0001375365-22-000058:notes:52]

[0001375365-22-000119:notes:51]
[same as prior period, unchanged from 0001375365-22-000058:notes:53]

[0001375365-22-000119:notes:52]
[same as prior period, unchanged from 0001375365-22-000058:notes:54]

[0001375365-22-000119:notes:53]
In September 2021, after the Company had closed its books for the year ended June 30, 2021, the Board decided to exercise its discretion to reduce the amount to be paid to the Chief Executive Officer for the first tranche to $2.0 million, which was paid in the quarter ended December 31, 2021. As a result of the Board’s decision to reduce the amount to be paid under the first tranche, the Company adjusted the $3.6 million expense previously recorded for the first tranche to the new amount of $2.0 million, which resulted in the Company recognizing a $1.6 million benefit from this adjustment during the quarter ended September 30, 2021. This performance award to the Chief Executive Officer was concluded in the year ended June 30, 2022. As such, there is no further transaction thereafter. The benefit recognized during the three months ended September 30, 2022 and 2021 was none and $1.6 million, respectively.

[0001375365-22-000119:notes:54]
[same as prior period, unchanged from 0001375365-22-000058:notes:56]

[0001375365-22-000119:notes:55]
|  | September 30, 2022 |  | June 30, 2022 |
| Accrued unrecognized tax benefits including related interests and penalties, non-current | $ | 19,686 |  |  | $ | 18,866 |  |
| Operating lease liability, non-current | 15,218 |  | 16,661 |
| Accrued warranty costs, non-current | 4,163 |  |  | 3,064 |  |
| Other | 482 |  |  | 549 |  |
| Total other long-term liabilities | $ | 39,549 |  |  | $ | 39,140 |  |

[0001375365-22-000119:notes:56]
[same as prior period, unchanged from 0001375365-22-000058:notes:58]

[0001375365-22-000119:notes:57]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Balance, beginning of the period | $ | 12,136 |  |  | $ | 12,863 |  |  |  |  |  |
| Provision for warranty | 8,617 |  |  | 6,386 |  |  |  |  |  |
| Costs utilized | (8,473) |  |  | (7,199) |  |  |  |  |  |
| Change in estimated liability for pre-existing warranties | 423 |  |  | 183 |  |  |  |  |  |
| Balance, end of the period | 12,703 |  |  | 12,233 |  |  |  |  |  |
| Current portion | 8,540 |  |  | 9,532 |  |  |  |  |  |
| Non-current portion | $ | 4,163 |  |  | $ | 2,701 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-22-000119:notes:58]
Fair Value DisclosureThe financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2022 and June 30, 2022. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-22-000119:notes:59]
[same as prior period, unchanged from 0001375365-22-000058:notes:61]

[0001375365-22-000119:notes:60]
The following table sets forth the Company’s financial instruments as of September 30, 2022 and June 30, 2022, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-22-000119:notes:61]
| September 30, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,550 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,550 |  |
| Certificates of deposit (2) | — |  |  | 553 |  |  | — |  |  | 553 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,550 |  |  | $ | 553 |  |  | $ | 1,590 |  |  | $ | 22,693 |  |
| June 30, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,220 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,220 |  |
| Certificates of deposit (2) | — |  |  | 832 |  |  | — |  |  | 832 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,220 |  |  | $ | 832 |  |  | $ | 1,590 |  |  | $ | 22,642 |  |

[0001375365-22-000119:notes:62]
(1) $20.4 million and $20.0 million in money market funds are included cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2022 and June 30, 2022, respectively.

[0001375365-22-000119:notes:63]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.1 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.3 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2022 and June 30, 2022, respectively.

[0001375365-22-000119:notes:64]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three months ended September 30, 2022, the credit losses related to the Company’s investments were not significant.

[0001375365-22-000119:notes:65]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three months ended September 30, 2022 and 2021.

[0001375365-22-000119:notes:66]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three months ended September 30, 2022 and 2021.

[0001375365-22-000119:notes:67]
The following is a summary of the Company’s investment in an auction rate security as of September 30, 2022 and June 30, 2022 (in thousands):

[0001375365-22-000119:notes:68]
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (160) |  |  | $ | 1,590 |  |

[0001375365-22-000119:notes:69]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three months ended September 30, 2022 and 2021.

[0001375365-22-000119:notes:70]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2022 and June 30, 2022, total debt of $249.7 million and $596.8 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-22-000119:notes:71]
[same as prior period, unchanged from 0001375365-22-000058:notes:73]

[0001375365-22-000119:notes:72]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $1.2 million as of September 30, 2022 and June 30, 2022. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three months ended September 30, 2022 and 2021, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three months ended September 30, 2022 and 2021.


## us-gaap:DebtDisclosureTextBlock

[0001375365-22-000119:notes:73]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands):

[0001375365-22-000119:notes:74]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 60,284 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | 11,000 |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | 9,000 |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 80,284 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,487 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 37,785 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,706 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 40,304 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,373 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,785 |  |  | 40,372 |  |
| Total term loans | 169,440 |  |  | 162,919 |  |
| Total debt | 249,724 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 101,173 |  |  | 449,146 |  |
| Debt, non-current | $ | 148,551 |  |  | $ | 147,618 |  |

[0001375365-22-000119:notes:75]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-22-000119:notes:76]
Available borrowings and interest rates as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

[0001375365-22-000119:notes:77]
|  | September 30, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 289,716 |  | 4.03% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | 105,000 |  | 1.80% - 2.52% |  | $ | 20,200 |  | 1.80% - 2.52% |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.14% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 19,000 |  | 3.84% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | 1.81% |  | $ | 22,200 |  | 1.81% |
| 2022 E.SUN Bank Credit Facility | $ | 21,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.30% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 0.95% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | 5,193 |  | 1.15% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.495% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.495% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |

[0001375365-22-000119:notes:78]
The Company entered into a new General Credit Agreement with ESUN Bank during the three months ended September 30, 2022 with the following terms:

[0001375365-22-000119:notes:79]
E.SUN Bank

[0001375365-22-000119:notes:80]
2022 E.SUN Bank Credit Facility

[0001375365-22-000119:notes:81]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

[0001375365-22-000119:notes:82]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of September 30, 2022 the amount outstanding under the Import O/A Loan was $16.4 million. The interest rate as of September 30, 2022 was 1.495% per annum. As of September 30, 2022 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $9.0 million and $7.8 million, respectively. The interest rate as of September 30, 2022 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of September 30, 2022, the amount available for future borrowing under the Import O/A Loan was $21.0 million.

[0001375365-22-000119:notes:83]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-22-000119:notes:84]
Fiscal Year:                                                                                                                                                                                             Principal Payments

[0001375365-22-000119:notes:85]
| Remainder of 2023 | $ | 94,631 |  |
| 2024 | 37,660 |  |
| 2025 | 41,491 |  |
| 2026 | 41,491 |  |
| 2027 | 18,025 |  |
| 2028 and thereafter | 16,426 |  |
| Total short-term and long-term debt | $ | 249,724 |  |

[0001375365-22-000119:notes:86]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-22-000119:notes:87]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2022 and 2021 were as follows (in thousands):

[0001375365-22-000119:notes:88]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Operating lease expense (including expense for lease agreements with related parties of $143 and $246 for the three months ended September 30, 2022 and 2021, respectively) | $ | 2,110 |  |  | $ | 2,182 |  |  |  |  |  |
| Cash payments for operating leases (including payments to related parties of $130 and $279 for the three months ended September 30, 2022 and 2021, respectively) | $ | 2,038 |  |  | $ | 2,205 |  |  |  |  |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 750 |  |  | $ | 6,119 |  |  |  |  |  |

[0001375365-22-000119:notes:89]
During the three months ended September 30, 2022 and 2021, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three months ended September 30, 2022 and 2021 were immaterial.

[0001375365-22-000119:notes:90]
As of September 30, 2022, the weighted average remaining lease term for operating leases was 3.6 years and the weighted average discount rate was 3.0%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of September 30, 2022 were as follows (in thousands):

[0001375365-22-000119:notes:91]
| Fiscal Year: |  | Maturities of operating leases |
| 2023 |  | $ | 5,828 |  |
| 2024 |  | 6,664 |  |
| 2025 |  | 6,252 |  |
| 2026 |  | 2,542 |  |
| 2027 |  | 1,563 |  |
| 2028 and beyond |  | 535 |  |
| Total future lease payments |  | 23,384 |  |
| Less: Imputed interest |  | (1,206) |  |
| Present value of operating lease liabilities |  | $ | 22,178 |  |

[0001375365-22-000119:notes:92]
As of September 30, 2022, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-22-000119:notes:93]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 8, "Related Party Transactions," for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-22-000119:notes:94]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-22-000119:notes:95]
Dealings with Ablecom

[0001375365-22-000119:notes:96]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-22-000119:notes:97]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.4% and 92.5% of the chassis included in the products sold by the Company during the three months ended September 30, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-22-000119:notes:98]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-22-000119:notes:99]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2022 were $37.1 million and $28.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-22-000119:notes:100]
Dealings with Compuware

[0001375365-22-000119:notes:101]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-22-000119:notes:102]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-22-000119:notes:103]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-22-000119:notes:104]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-22-000119:notes:105]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2022 were $198.9 million and $69.0 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-22-000119:notes:106]
Dealings with Investment in a Corporate Venture

[0001375365-22-000119:notes:107]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-22-000119:notes:108]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2022 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-22-000119:notes:109]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2022. No impairment charge was recorded for the three months ended September 30, 2022 or 2021.

[0001375365-22-000119:notes:110]
The Company sold products worth $11.6 million and $15.2 million to the Corporate Venture for the three months ended September 30, 2022 and 2021, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2022 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $9.4 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of September 30, 2022 and June 30, 2022, respectively.

[0001375365-22-000119:notes:111]
The Company had the following balances related to transactions with its related parties as of September 30, 2022 and June 30, 2022 (in thousands):

[0001375365-22-000119:notes:112]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 |  |  | September 30, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 882 |  | $ | 404 |  | $ | 9,365 |  | $ | 7,992 |  |  |  | $ | 10,249 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,540 |  | $ | 4,816 |  | $ | 31,011 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 34,551 |  | $ | 24,412 |  |
| Accounts payable | $ | 43,127 |  | $ | 42,463 |  | $ | 50,902 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 94,029 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,999 |  | $ | 3,531 |  | $ | 26,262 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 28,261 |  | $ | 18,676 |  |

[0001375365-22-000119:notes:113]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-22-000119:notes:114]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

[0001375365-22-000119:notes:115]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 7 |  | $ | 13,760 |  | $ | 15,702 |  | $ | 11,293 |  | $ | 15,213 |  | $ | — |  | $ | — |  | $ | 25,055 |  | $ | 30,922 |  |
| Purchases - inventory | $ | 47,847 |  | $ | 50,788 |  | $ | 48,689 |  | $ | 35,229 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,670 |  | $ | 96,536 |  | $ | 87,687 |  |
| Purchases - other miscellaneous items | $ | 4,763 |  | $ | 2,116 |  | $ | 258 |  | $ | 339 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,021 |  | $ | 2,455 |  |

[0001375365-22-000119:notes:116]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

[0001375365-22-000119:notes:117]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):

[0001375365-22-000119:notes:118]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | — |  | $ | (478) |  | $ | (1,134) |  | $ | (1,373) |  | $ | (4,181) |  | $ | — |  | $ | — |  | $ | (1,851) |  | $ | (5,315) |  |
| Changes in other receivable | $ | 1,276 |  | $ | 1,147 |  | $ | (11,415) |  | $ | (3,517) |  | $ | — |  | $ | — |  | $ | — |  | $ | (76) |  | $ | (10,139) |  | $ | (2,446) |  |
| Changes in accounts payable | $ | 664 |  | $ | 2,578 |  | $ | 6,010 |  | $ | 5,080 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,674 |  | $ | 7,658 |  |
| Changes in accrued liabilities | $ | (1,532) |  | $ | (1,229) |  | $ | 11,117 |  | $ | 3,304 |  | $ | — |  | $ | (500) |  | $ | — |  | $ | — |  | $ | 9,585 |  | $ | 1,575 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 146 |  | $ | 62 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 400 |  |
| Unpaid property, plant and equipment | $ | 3,782 |  | $ | 1,360 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,782 |  | $ | 1,360 |  |

[0001375365-22-000119:notes:119]
Tripartite Agreement

[0001375365-22-000119:notes:120]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. While the Agreement is currently still in effect, Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-22-000119:notes:121]
[same as prior period, unchanged from 0001375365-22-000058:notes:150]

[0001375365-22-000119:notes:122]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "Original 2020 Plan"). The maximum number of shares available under the Original 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan (as amended and restated, the “2020 Plan”) which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-22-000119:notes:123]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-22-000119:notes:124]
As of September 30, 2022, the Company had 3,095,739 authorized shares available for future issuance under the 2020 Plan.

[0001375365-22-000119:notes:125]
[same as prior period, unchanged from 0001375365-22-000058:notes:153]

[0001375365-22-000119:notes:126]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company's Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. No shares were repurchased under any share repurchase programs during the three months ended September 30, 2022.

[0001375365-22-000119:notes:127]
[same as prior period, unchanged from 0001375365-22-000058:notes:155]

[0001375365-22-000119:notes:128]
[same as prior period, unchanged from 0001375365-22-000058:notes:156]

[0001375365-22-000119:notes:129]
[same as prior period, unchanged from 0001375365-22-000058:notes:157]

[0001375365-22-000119:notes:130]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-22-000119:notes:131]
[same as prior period, unchanged from 0001375365-22-000058:notes:159]

[0001375365-22-000119:notes:132]
[same as prior period, unchanged from 0001375365-22-000058:notes:160]

[0001375365-22-000119:notes:133]
The fair value of stock option grants for the three months ended September 30, 2022 and 2021 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-22-000119:notes:134]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Risk-free interest rate | 2.81% - 4.06% |  | 0.81% |  |  |  |  |
| Expected term | 6.07 years |  | 6.09 years |  |  |  |  |
| Dividend yield | —% |  | —% |  |  |  |  |
| Volatility | 50.62% - 51.30% |  | 49.71% |  |  |  |  |
| Weighted-average fair value | $28.67 |  | $17.94 |  |  |  |  |

[0001375365-22-000119:notes:135]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2022 and 2021 (in thousands):

[0001375365-22-000119:notes:136]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Cost of sales | $ | 884 |  |  | $ | 447 |  |  |  |  |  |
| Research and development | 6,118 |  |  | 3,880 |  |  |  |  |  |
| Sales and marketing | 809 |  |  | 517 |  |  |  |  |  |
| General and administrative | 3,203 |  |  | 2,171 |  |  |  |  |  |
| Stock-based compensation expense before taxes | 11,014 |  |  | 7,015 |  |  |  |  |  |
| Income tax impact | (1,339) |  |  | (1,888) |  |  |  |  |  |
| Stock-based compensation expense, net | $ | 9,675 |  |  | $ | 5,127 |  |  |  |  |  |

[0001375365-22-000119:notes:137]
As of September 30, 2022, $14.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.20 years and $73.1 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.52 years. Additionally, as described below, $4.3 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 2.75 years.

[0001375365-22-000119:notes:138]
[same as prior period, unchanged from 0001375365-22-000058:notes:166]

[0001375365-22-000119:notes:139]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 1,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). The 2021 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2021 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $120.00 per share thereafter (based on a 60 trading day average stock price), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to March 2, 2024, the Company’s CEO must hold shares that he acquires until March 2, 2024, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-22-000119:notes:140]
The achievement status of the operational and stock price milestones as of September 30, 2022 was as follows:

[0001375365-22-000119:notes:141]
| Annualized Revenue Milestone |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| (in billions) |  |  |  |  |  |  |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Probable |  | $75 |  | Not yet achieved |  |  |
| $6.8 |  | Probable |  | $95 |  | Not yet achieved |  |  |
| $8.0 |  | Probable |  | $120 |  | Not yet achieved |  |  |

[0001375365-22-000119:notes:142]
(1)The vesting of the first tranche of 200,000 option shares under the 2021 CEO Performance Stock Option, representing one-fifth of such award, was certified by the Company's Compensation Committee in August 2022.

[0001375365-22-000119:notes:143]
(2)The vesting of the second tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company's Compensation Committee on October 25, 2022.

[0001375365-22-000119:notes:144]
[same as prior period, unchanged from 0001375365-22-000058:notes:170]

[0001375365-22-000119:notes:145]
During the three months ended September 30, 2022 and 2021, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $1.3 million and $0.9 million, respectively. As of September 30, 2022 and June 30, 2022, the Company had $4.3 million and $5.6 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of September 30, 2022 is expected to be recognized over a period of more than 2.75 years.

[0001375365-22-000119:notes:146]
The following table summarizes stock option activity during the three months ended September 30, 2022 under all plans:

[0001375365-22-000119:notes:147]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2022 |  | 4,311,416 |  |  | $ | 29.99 |  |  |  |  |  |
| Granted |  | 123,750 |  |  | $ | 55.67 |  |  |  |  |  |
| Exercised |  | (405,226) |  |  | $ | 20.10 |  |  |  |  |  |
| Forfeited/Cancelled |  | (9,238) |  |  | $ | 26.61 |  |  |  |  |  |
| Balance as of September 30, 2022 |  | 4,020,702 |  |  | $ | 31.79 |  |  | 5.77 |  |  |
| Options vested and exercisable at September 30, 2022 |  | 2,373,832 |  |  | $ | 24.87 |  |  | 3.78 |  |  |

[0001375365-22-000119:notes:148]
[same as prior period, unchanged from 0001375365-22-000058:notes:174]

[0001375365-22-000119:notes:149]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units were earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units vested in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units vested in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019. An additional 2,939 units were earned for fiscal year 2021 that was vested on November 10, 2021.

[0001375365-22-000119:notes:150]
The following table summarizes RSU and PRSU activity during the three months ended September 30, 2022 under all plans:

[0001375365-22-000119:notes:151]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2022 | 1,879,073 |  |  | $ | 33.72 |  |  |  |  |  |  |
| Granted | 446,309 |  |  | $ | 59.84 |  |  |  |  |  |  |
| Released | (193,532) |  |  | $ | 29.61 |  |  |  |  |  |  |
| Forfeited | (52,535) |  |  | $ | 36.99 |  |  |  |  |  |  |
| Balance as of September 30, 2022 | 2,079,315 |  |  | $ | 39.63 |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-22-000119:notes:152]
Income Taxes
The Company recorded a provision for income taxes of $38.9 million and $3.3 million for the three months ended September 30, 2022 and 2021, respectively. The effective tax rate was 17.4% and 11.7% for the three months ended September 30, 2022 and 2021, respectively. The effective tax rate for the three months ended September 30, 2022 is higher than that for the three months ended September 30, 2021, primarily due to significant increase in taxable income in the first quarter of fiscal year 2023, whereas the income tax deduction items such as R&D credit and foreign tax deduction comparably did not increase in the same proportion.

[0001375365-22-000119:notes:153]
The Tax Cuts and Jobs Act of 2017 eliminated the option to deduct research and development (“R&D”) expenses in the year incurred and instead requires taxpayers to capitalize R&D expenses, including software development cost, and subsequently amortize such expenses over five years for R&D activities conducted in the United States and over fifteen years for R&D activities conducted outside of the United States beginning in the Company’s fiscal year 2023. Although Congress has considered legislation that would defer, modify, or repeal the capitalization and amortization requirement, there is no assurance the provision will be deferred, repealed, or otherwise modified.

[0001375365-22-000119:notes:154]
As of September 30, 2022, the Company had gross unrecognized tax benefits of $41.7 million, of which, $23.9 million if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2022, there was a $3.7 million increase in gross unrecognized tax benefits. The Company's policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2022, the Company had accrued $3.2 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-22-000119:notes:155]
[same as prior period, unchanged from 0001375365-22-000058:notes:181]

[0001375365-22-000119:notes:156]
The federal statute of limitations remains open in general for tax years ended June 30, 2019 through 2022. Various states statutes of limitations remain open in general for tax years ended June 30, 2018 through 2022. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2017 through 2022. It is reasonably possible that the Company's gross unrecognized tax benefits will decrease by approximately $3.0 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact the Company's effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-22-000119:notes:157]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. Consequently, the parties expect the Court will grant preliminary approval and calendar a future hearing for final approval. This settlement, if finally approved by the Court, will fully resolve the action.

[0001375365-22-000119:notes:158]
Other legal proceedings and indemnifications

[0001375365-22-000119:notes:159]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2022 and any prior periods.

[0001375365-22-000119:notes:160]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-22-000119:notes:161]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-22-000119:notes:162]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2022, these remaining noncancelable commitments were $512.3 million, including $97.7 million for related parties.

[0001375365-22-000119:notes:163]
Lease Commitments - See Part I, Item 1, Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-22-000119:notes:164]
Segment Reporting
The Company operates in one operating segment that develops and provides high-performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-22-000119:notes:165]
[same as prior period, unchanged from 0001375365-22-000058:notes:193]

[0001375365-22-000119:notes:166]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Long-lived assets: |  |  |  |
| United States | $ | 183,428 |  |  | $ | 180,846 |  |
| Asia | 104,482 |  |  | 102,241 |  |
| Europe | 2,842 |  |  | 2,885 |  |
|  | $ | 290,752 |  |  | $ | 285,972 |  |

[0001375365-22-000119:notes:167]
The Company’s revenue is presented on a disaggregated basis in Part I, Item 1, Note 2, “Revenue,” by type of product and by geographical market.
