# SMCI note change history — 0001375365-22-000058 → 0001375365-22-000119


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. Consequently, the parties expect the Court will grant preliminary approval and calendar a future hearing for final approval. This settlement, if finally approved by the Court, will fully resolve the action.
  (was, 2022-05-06, similarity 0.8565):
[0001375365-22-000058:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss.  Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes.  Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales.  The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, entered into an agreement in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement with plaintiff's counsel. Pursuant to the terms of the stipulation of settlement, and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. This settlement, if approved by the Court, will fully resolve the action. A hearing on preliminary approval of the proposed settlement is scheduled for June 2, 2022. As of March 31, 2022, the Company recorded a liability of $18,250,000 for the Hessefort case settlement in accrued liabilities and $16,250,000 of litigation settlement costs recovery in other receivables in its condensed consolidated balance sheets. The net Hessefort litigation settlement costs of $2,000,000 is recorded as a charge to general and administrative expense in the Company's condensed consolidated statement of operations for the three and nine months ended March 31, 2022.

- changed (2022-11-04):
[0001375365-22-000119:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2022 and any prior periods.
  (was, 2022-05-06, similarity 0.9785):
[0001375365-22-000058:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2022 and any prior periods.

- changed (2022-11-04):
[0001375365-22-000119:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2022, these remaining noncancelable commitments were $512.3 million, including $97.7 million for related parties.
  (was, 2022-05-06, similarity 0.6795):
[0001375365-22-000058:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2022, these remaining noncancelable commitments were $628.6 million, including $82.8 million for related parties.
Lease Commitments - See Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.

- added (2022-11-04):
[0001375365-22-000119:note_history:4]
Lease Commitments - See Part I, Item 1, Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.

- removed (2022-11-04):
[0001375365-22-000058:note_history:5]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021. Following a March 23, 2022 hearing, on March 25, 2022, the Court granted defendants’ demurrers on the grounds that plaintiffs had failed to allege demand futility and the Court dismissed the amended complaint, but with leave to amend by May 20, 2022.  The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously if a second amended complaint is filed.

- removed (2022-11-04):
[0001375365-22-000058:note_history:6]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice.  On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval.  On December 16, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval.  The Company provided notice as required by the Court on December 21, 2021. No shareholder sought to intervene during the 45-day notice period ending on February 4, 2022, and on March 24, 2022, the Court issued an order dismissing the lawsuit with prejudice as to the named plaintiff.

- removed (2022-11-04):
[0001375365-22-000058:note_history:7]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations in the first  quarter of fiscal 2021. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense in the first quarter of fiscal 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:8]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Part II, Item 8, Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 29, 2022, for the year ended June 30, 2022. Management's estimates take into consideration, as applicable, general macroeconomic conditions, inflation, changes in interest rates and geopolitical events.
  (was, 2022-05-06, similarity 0.8084):
[0001375365-22-000058:note_history:8]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on August 27, 2021, for the year ended June 30, 2021. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.

- changed (2022-11-04):
[0001375365-22-000119:note_history:9]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.
  (was, 2022-05-06, similarity 0.7174):
[0001375365-22-000058:note_history:9]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2022 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2022.

- changed (2022-11-04):
[0001375365-22-000119:note_history:10]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 16.1% and 25.7% of total purchases for the three months ended September 30, 2022, and two suppliers accounted for 20.1% and 6.3% of total purchases for the three months ended September 30, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% and 9.6% of total cost of sales for the three months ended September 30, 2022 and 2021, respectively.
  (was, 2022-05-06, similarity 0.6237):
[0001375365-22-000058:note_history:10]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 13.0% and 19.4% of total purchases for the three months ended March 31, 2022, and two suppliers accounted for 21.4% and 14.7% of total purchases for the three months ended March 31, 2021. Two suppliers accounted for 18.0% and 11.4% of total purchases for the nine months ended March 31, 2022, and two suppliers accounted for 21.1% and 13.8% of total purchases for the nine months ended March 31, 2021. Purchases from Ablecom, and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 8.2% and 7.3% of total cost of sales for the three months ended March 31, 2022 and 2021, respectively, and a combined 9.0% and 7.9% of total cost of sales for the nine months ended March 31, 2022 and 2021, respectively.

- changed (2022-11-04):
[0001375365-22-000119:note_history:11]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022 and no single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021. Two customers accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2022 which accounted for 11.0% and 10.3%. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.
  (was, 2022-05-06, similarity 0.722):
[0001375365-22-000058:note_history:11]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 10.2% of the net sales for the three months ended March 31, 2022 and no customer accounted for 10% or more of the net sales for the nine months ended March 31, 2022 or for the three and nine months ended March 31, 2021. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2022, whereas one customer accounted for 13.5% of accounts receivable, net as of June 30, 2021.

- added (2022-11-04):
[0001375365-22-000119:note_history:12]
There were no new pronouncements recently adopted.

- added (2022-11-04):
[0001375365-22-000119:note_history:13]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendments are effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In April 2022, FASB issued a proposed accounting standard update for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The proposed amendment defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have material impact on its consolidated financial statements and disclosures.

- removed (2022-11-04):
[0001375365-22-000058:note_history:14]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021. The adoption of the guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

- removed (2022-11-04):
[0001375365-22-000058:note_history:15]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022, that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. The amendments are effective for all entities on December 31, 2022, with early adoption permitted for an interim period beginning after March 12, 2020. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, Mega Bank Credit Facilities. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 which provided for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to secured overnight financing rate (“SOFR"). As these amendments had other contemporaneous changes to the facility including the amount and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of adoption of the guidance on its consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:16]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands):
  (was, 2022-05-06, similarity 0.9655):
[0001375365-22-000058:note_history:16]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of March 31, 2022 and June 30, 2021 consisted of the following (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:17]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 60,284 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | 11,000 |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | 9,000 |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 80,284 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,487 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 37,785 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,706 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 40,304 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,373 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,785 |  |  | 40,372 |  |
| Total term loans | 169,440 |  |  | 162,919 |  |
| Total debt | 249,724 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 101,173 |  |  | 449,146 |  |
| Debt, non-current | $ | 148,551 |  |  | $ | 147,618 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:18]
Available borrowings and interest rates as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

- added (2022-11-04):
[0001375365-22-000119:note_history:19]
|  | September 30, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 289,716 |  | 4.03% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | 105,000 |  | 1.80% - 2.52% |  | $ | 20,200 |  | 1.80% - 2.52% |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.14% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 19,000 |  | 3.84% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | 1.81% |  | $ | 22,200 |  | 1.81% |
| 2022 E.SUN Bank Credit Facility | $ | 21,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.30% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 0.95% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | 5,193 |  | 1.15% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.495% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.495% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |

- added (2022-11-04):
[0001375365-22-000119:note_history:20]
The Company entered into a new General Credit Agreement with ESUN Bank during the three months ended September 30, 2022 with the following terms:

- added (2022-11-04):
[0001375365-22-000119:note_history:21]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin, and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

- added (2022-11-04):
[0001375365-22-000119:note_history:22]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Subsidiary and E.SUN Bank have agreed to both a medium term credit loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of September 30, 2022 the amount outstanding under the Import O/A Loan was $16.4 million. The interest rate as of September 30, 2022 was 1.495% per annum. As of September 30, 2022 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $9.0 million and $7.8 million, respectively. The interest rate as of September 30, 2022 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of September 30, 2022, the amount available for future borrowing under the Import O/A Loan was $21.0 million.

- changed (2022-11-04):
[0001375365-22-000119:note_history:23]
| Remainder of 2023 | $ | 94,631 |  |
| 2024 | 37,660 |  |
| 2025 | 41,491 |  |
| 2026 | 41,491 |  |
| 2027 | 18,025 |  |
| 2028 and thereafter | 16,426 |  |
| Total short-term and long-term debt | $ | 249,724 |  |
  (was, 2022-05-06, similarity 0.9556):
[0001375365-22-000058:note_history:23]
| 2022 | $ | 377,969 |  |
| 2023 | 29,853 |  |
| 2024 | 33,530 |  |
| 2025 | 37,014 |  |
| 2026 | 37,014 |  |
| 2027 and thereafter | 32,088 |  |
| Total short-term and long-term debt | $ | 547,468 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:24]
The Company is in compliance with all the covenants for the outstanding debt.

- removed (2022-11-04):
[0001375365-22-000058:note_history:25]
|  | March 31, |  | June 30, |
|  | 2022 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 241,469 |  |  | $ | — |  |
| CTBC Bank | 101,000 |  |  | 18,000 |  |
| HSBC Bank | 30,000 |  |  | — |  |
| E.SUN Bank | 23,000 |  |  | 20,400 |  |
| Total line of credit | 395,469 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | — |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 41,718 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 5,505 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 28,138 |  |  | — |  |
| Mega Bank term loan, due September 15, 2026 | 41,803 |  |  | — |  |
| Chang Hwa Bank term loan due October 15, 2026 | 34,835 |  |  | — |  |
| Total term loans | 151,999 |  |  | 59,790 |  |
| Total debt | 547,468 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 403,045 |  |  | 63,490 |  |
| Debt, non-current | $ | 144,423 |  |  | $ | 34,700 |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:26]
Bank of America

- removed (2022-11-04):
[0001375365-22-000058:note_history:27]
2018 Bank of America Credit Facility

- removed (2022-11-04):
[0001375365-22-000058:note_history:28]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and change provisions relating to payments and LIBOR replacement mechanics to secured overnight financing rate (“SOFR"). The obligations bear a base interest rate plus 0.5% to 1.5% based on the SOFR availability. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Prior to that, on June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026 and increase the maximum amount that the Company can request the facility be increased from $100 million to $150 million. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

- removed (2022-11-04):
[0001375365-22-000058:note_history:29]
As of March 31, 2022, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $241.5 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2022 and June 30, 2021 range from 1.50% to 1.54%. The balance of debt issuance costs outstanding as of March 31, 2022 and June 30, 2021 was $0.8 million and $0.5 million, respectively. The Company is in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of March 31, 2022, the Company's available borrowing capacity was $108.5 million, subject to the borrowing base limitation and compliance with other applicable terms.

- removed (2022-11-04):
[0001375365-22-000058:note_history:30]
On March 23, 2022 (the “Effective Date”), the Company through its Taiwan subsidiary entered into an Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch (the “2022 Bank of America Credit Facility”), for an amount not to exceed in aggregate $20.0 million. The interest rate will be quoted by Bank of America – Taipei Branch for each drawdown. As of March 31, 2022, there were no outstanding borrowings under this Bank of America Credit Facility.

- removed (2022-11-04):
[0001375365-22-000058:note_history:31]
CTBC Bank

- removed (2022-11-04):
[0001375365-22-000058:note_history:32]
2021 CTBC Credit Lines

- removed (2022-11-04):
[0001375365-22-000058:note_history:33]
The Company through its Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

- removed (2022-11-04):
[0001375365-22-000058:note_history:34]
On July 20, 2021 (the “Effective Date”), the Company through its Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million  U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million  U.S. dollar equivalents) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

- removed (2022-11-04):
[0001375365-22-000058:note_history:35]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

- removed (2022-11-04):
[0001375365-22-000058:note_history:36]
As of March 31, 2022 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $41.7 million and $34.7 million, respectively. The interest rates for these loans were 0.70% per annum as of March 31, 2022, and 0.45% as of June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $5.5 million on March 31, 2022. The interest rates for this loan was 0.90% per annum as of March 31, 2022. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

- removed (2022-11-04):
[0001375365-22-000058:note_history:37]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $0.0 million and $25.1 million at March 31, 2022 and June 30, 2021, respectively. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. The interest rate for the 2021 CTBC Credit Facility term loan was 0.75% per annum as of June 30, 2021. As of March 31, 2022 and June 30, 2021, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were $101.0 million and $18.0 million, respectively. The interest rates for these loans ranges from 0.94% to 1.40% per annum as of March 31, 2022 and 0.98% per annum as of June 30, 2021. As of March 31, 2022, the amount available for future borrowing under the 2021 CTBC Credit Facility was $4.0 million. As of March 31, 2022, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million. The financial covenants under the 2021 CTBC Credit Lines will be reviewed by CTBC Bank every six months on June 30 and December 31.

- removed (2022-11-04):
[0001375365-22-000058:note_history:38]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30.0 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility expired on September 18, 2021.

- removed (2022-11-04):
[0001375365-22-000058:note_history:39]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements to be reviewed on a yearly basis at fiscal year end.

- removed (2022-11-04):
[0001375365-22-000058:note_history:40]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of March 31, 2022, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $28.1 million and the interest rates for these loans were 1.245% per annum. As of March 31, 2022 and June 30, 2021, the amounts outstanding under the Import Loan were $23.0 million and $20.4 million, respectively. The interest rate for the quarter ended March 31, 2022 ranges from 1.09% to 1.33% per annum. The interest rate for the quarter ended June 30, 2021 ranges from 1.00% to 1.29% per annum. At March 31, 2022, the amount available for future borrowing under the Import Loan was $7.0 million.

- removed (2022-11-04):
[0001375365-22-000058:note_history:41]
Mega Bank

- removed (2022-11-04):
[0001375365-22-000058:note_history:42]
Mega Bank Credit Facilities

- removed (2022-11-04):
[0001375365-22-000058:note_history:43]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. The first drawdown date was on October 4, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of March 31, 2022, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $41.8 million and the interest rates ranged from 0.895% to 1.095% per annum.

- removed (2022-11-04):
[0001375365-22-000058:note_history:44]
Credit Agreement with Mega Bank

- removed (2022-11-04):
[0001375365-22-000058:note_history:45]
On April 25, 2022, the Company through its Taiwan subsidiary, entered into a $20.0 million (or foreign currency equivalent) (the “Credit Limit”) Omnibus Credit Authorization Agreement (the “Omnibus Credit Authorization Agreement”) with Mega Bank. The Omnibus Credit Authorization Agreement permits individual credit authorizations subject to specified drawdown conditions up to the Credit Limit (on a revolving basis) to be used as loans for the purchase of materials or supplies. During the loan period, the Company is required to maintain 100% direct or indirect share ownership of the Taiwan subsidiary.

- removed (2022-11-04):
[0001375365-22-000058:note_history:46]
Pursuant to the Omnibus Credit Authorization Agreement, the Taiwan subsidiary also entered into both a Credit Authorization Agreement (the “Credit Authorization Agreement”) and Credit Authorization Approval Notice (the “Credit Authorization Approval Notice”) with Mega Bank and associated branch of Mega Bank, respectively. Pursuant to such Agreement and Notice, Mega Bank permits the Taiwan subsidiary to make drawdowns up to the Credit Limit for short-term loans for material purchases with a tenor not to exceed 120 days on a revolving basis. Drawdowns under the Mega Bank facility may be made through March 2023. The interest rate for each individual credit authorization is adjusted according to the Mega Bank’s USD basic loan interest rate at the time of signing the agreement which was 0.90% per annum. Interest on such drawdowns is based upon TAIFX OFFER for six months plus 0.23% and divided by 0.946, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to the bank’s right of set off. The interest rate shall be adjusted once every month but shall not be lower than the USD basic loan interest rate plus 0.1%. If the loan involves the acceptance of bill of exchange, the Company would pay handling fee at the annual rate of 0.75% calculated based on the number of actual acceptance days.  The fee is paid in full upon acceptance and a minimum handling fee of NTD 400 is charged for each transaction. Amounts borrowed are otherwise unsecured, and the Credit Authorization Agreement has customary default provisions permitting Mega Bank to reduce the extension of credit, shorten the term for loan repayment or declare all of the amounts immediately due and payable. The Company is not a guarantor under the Credit Authorization Agreement or Credit Authorization Approval Notice.

- removed (2022-11-04):
[0001375365-22-000058:note_history:47]
Chang Hwa Bank

- removed (2022-11-04):
[0001375365-22-000058:note_history:48]
Chang Hwa Bank Credit Facility

- removed (2022-11-04):
[0001375365-22-000058:note_history:49]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed. As of March 31, 2022, the total outstanding borrowings under the Chang Hwa Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $34.8 million and the interest rate is 1.05% per annum.

- removed (2022-11-04):
[0001375365-22-000058:note_history:50]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants.

- removed (2022-11-04):
[0001375365-22-000058:note_history:51]
HSBC Bank

- removed (2022-11-04):
[0001375365-22-000058:note_history:52]
HSBC Bank Credit Facility

- removed (2022-11-04):
[0001375365-22-000058:note_history:53]
On January 7, 2022 (the “HSBC Bank Effective Date”), the Company through its Taiwan subsidiary entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with the Taiwan affiliate of HSBC Bank (“HSBC Bank”).  The Loan Agreement provides for borrowings in the form of loans, export/import financings, overdrafts, commercial paper guaranties, and other types of drawdown instruments.  The Loan Agreement has customary default provisions permitting HSBC Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event its Taiwan subsidiary fails to make payment of sums under another agreement which permits acceleration of maturity of such indebtedness. The Company is not a guarantor of the Loan Agreement.

- removed (2022-11-04):
[0001375365-22-000058:note_history:54]
Terms for specific drawdown instruments issued under the Loan Agreement, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, may be set forth in Facility Letters (a “Facility Letter”) negotiated with the HSBC Bank. Under a Facility Letter entered into on the HSBC Bank Effective Date, the Taiwan subsidiary and the HSBC Bank have agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on the HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date.

- removed (2022-11-04):
[0001375365-22-000058:note_history:55]
As of March 31, 2022, the outstanding borrowings under the 2022 HSBC Bank Credit Facility revolving line of credit were $30.0 million. The interest rates for these loans were approximately 0.96% per annum as of March 31, 2022. As of March 31, 2022, there was no amount available for future borrowing under the 2022 HSBC Bank Credit Facility.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:56]
Short-term and long-term debt obligations as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands):
  (was, 2022-05-06, similarity 0.9565):
[0001375365-22-000058:note_history:56]
Short-term and long-term debt obligations as of March 31, 2022 and June 30, 2021 consisted of the following (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:57]
|  | September 30, |  | June 30, |
|  | 2022 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 60,284 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | 11,000 |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | 9,000 |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 80,284 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 31,487 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 37,785 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,706 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 40,304 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 16,373 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,785 |  |  | 40,372 |  |
| Total term loans | 169,440 |  |  | 162,919 |  |
| Total debt | 249,724 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 101,173 |  |  | 449,146 |  |
| Debt, non-current | $ | 148,551 |  |  | $ | 147,618 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:58]
Activities under Revolving Lines of Credit and Term Loans

- added (2022-11-04):
[0001375365-22-000119:note_history:59]
Available borrowings and interest rates as of September 30, 2022 and June 30, 2022 consisted of the following (in thousands except for percentages):

- added (2022-11-04):
[0001375365-22-000119:note_history:60]
|  | September 30, 2022 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 289,716 |  | 4.03% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 4.328% |  | $ | 102,000 |  | 4.004% |
| 2021 CTBC Credit Lines | $ | 105,000 |  | 1.80% - 2.52% |  | $ | 20,200 |  | 1.80% - 2.52% |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 5.14% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 19,000 |  | 3.84% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | 1.81% |  | $ | 22,200 |  | 1.81% |
| 2022 E.SUN Bank Credit Facility | $ | 21,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.30% |  | $ | — |  | 1.175% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 0.95% |  | $ | — |  | 0.825% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | 5,193 |  | 1.15% |  | $ | 6,308 |  | 1.025% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.495% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.495% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.145% - 1.345% |  | $ | — |  | 1.02% - 1.22% |

- removed (2022-11-04):
[0001375365-22-000058:note_history:61]
|  | March 31, |  | June 30, |
|  | 2022 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 241,469 |  |  | $ | — |  |
| CTBC Bank | 101,000 |  |  | 18,000 |  |
| HSBC Bank | 30,000 |  |  | — |  |
| E.SUN Bank | 23,000 |  |  | 20,400 |  |
| Total line of credit | 395,469 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | — |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 41,718 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 5,505 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 28,138 |  |  | — |  |
| Mega Bank term loan, due September 15, 2026 | 41,803 |  |  | — |  |
| Chang Hwa Bank term loan due October 15, 2026 | 34,835 |  |  | — |  |
| Total term loans | 151,999 |  |  | 59,790 |  |
| Total debt | 547,468 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 403,045 |  |  | 63,490 |  |
| Debt, non-current | $ | 144,423 |  |  | $ | 34,700 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:62]
| Remainder of 2023 | $ | 94,631 |  |
| 2024 | 37,660 |  |
| 2025 | 41,491 |  |
| 2026 | 41,491 |  |
| 2027 | 18,025 |  |
| 2028 and thereafter | 16,426 |  |
| Total short-term and long-term debt | $ | 249,724 |  |
  (was, 2022-05-06, similarity 0.9556):
[0001375365-22-000058:note_history:62]
| 2022 | $ | 377,969 |  |
| 2023 | 29,853 |  |
| 2024 | 33,530 |  |
| 2025 | 37,014 |  |
| 2026 | 37,014 |  |
| 2027 and thereafter | 32,088 |  |
| Total short-term and long-term debt | $ | 547,468 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:63]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:64]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2022-05-06, similarity 0.9789):
[0001375365-22-000058:note_history:64]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2022. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- changed (2022-11-04):
[0001375365-22-000119:note_history:65]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.4% and 92.5% of the chassis included in the products sold by the Company during the three months ended September 30, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2022-05-06, similarity 0.9188):
[0001375365-22-000058:note_history:65]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.8% and 92.5% of the chassis included in the products sold by the Company during the three months ended March 31, 2022 and 2021, respectively, and 82.5% and 92.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2022 and 2021, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2022-11-04):
[0001375365-22-000119:note_history:66]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2022 were $37.1 million and $28.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2022-05-06, similarity 0.9941):
[0001375365-22-000058:note_history:66]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on March 31, 2022 were $44.6 million and $40.5 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2021 were $44.9 million and $40.2 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2022-11-04):
[0001375365-22-000119:note_history:67]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.
  (was, 2022-05-06, similarity 0.9948):
[0001375365-22-000058:note_history:67]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

- changed (2022-11-04):
[0001375365-22-000119:note_history:68]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2022 were $198.9 million and $69.0 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2022-05-06, similarity 0.9909):
[0001375365-22-000058:note_history:68]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on March 31, 2022 were $192.4 million and $42.3 million, respectively and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2021 were $123.3 million and $71.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2022-11-04):
[0001375365-22-000119:note_history:69]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2022 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2022-05-06, similarity 0.7966):
[0001375365-22-000058:note_history:69]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of March 31, 2022 and June 30, 2021, the Company had unamortized deferred gain balance of $0 million and $1.0 million, respectively, in accrued liabilities in the Company’s condensed consolidated balance sheets.

- changed (2022-11-04):
[0001375365-22-000119:note_history:70]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2022. No impairment charge was recorded for the three months ended September 30, 2022 or 2021.
  (was, 2022-05-06, similarity 0.9441):
[0001375365-22-000058:note_history:70]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of the third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of March 31, 2022. No impairment charge was recorded for the three and nine months ended March 31, 2022 and 2021, respectively.

- added (2022-11-04):
[0001375365-22-000119:note_history:71]
The Company sold products worth $11.6 million and $15.2 million to the Corporate Venture for the three months ended September 30, 2022 and 2021, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2022 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $9.4 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of September 30, 2022 and June 30, 2022, respectively.

- changed (2022-11-04):
[0001375365-22-000119:note_history:72]
The Company had the following balances related to transactions with its related parties as of September 30, 2022 and June 30, 2022 (in thousands):
  (was, 2022-05-06, similarity 0.9627):
[0001375365-22-000058:note_history:72]
The Company had the following balances related to transactions with its related parties as of March 31, 2022 and June 30, 2021 (in thousands):

- changed (2022-11-04):
[0001375365-22-000119:note_history:73]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 |  |  | September 30, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 882 |  | $ | 404 |  | $ | 9,365 |  | $ | 7,992 |  |  |  | $ | 10,249 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,540 |  | $ | 4,816 |  | $ | 31,011 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 34,551 |  | $ | 24,412 |  |
| Accounts payable | $ | 43,127 |  | $ | 42,463 |  | $ | 50,902 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 94,029 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,999 |  | $ | 3,531 |  | $ | 26,262 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 28,261 |  | $ | 18,676 |  |
  (was, 2022-05-06, similarity 0.8368):
[0001375365-22-000058:note_history:73]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 |
| Accounts receivable | $ | 1 |  | $ | 2 |  | $ | 381 |  | $ | 198 |  | $ | 33,702 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 34,084 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 2,415 |  | $ | 5,575 |  | $ | 27,105 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 41 |  | $ | 89 |  | $ | 29,561 |  | $ | 23,837 |  |
| Accounts payable | $ | 38,966 |  | $ | 38,152 |  | $ | 48,300 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 87,266 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 982 |  | $ | 3,042 |  | $ | 14,333 |  | $ | 14,486 |  | $ | — |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 15,315 |  | $ | 18,528 |  |

- changed (2022-11-04):
[0001375365-22-000119:note_history:74]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):
  (was, 2022-05-06, similarity 0.9662):
[0001375365-22-000058:note_history:74]
The Company's results from transactions with its related parties for each of the three months ended March 31, 2022 and 2021, are as follows (in thousands):

- changed (2022-11-04):
[0001375365-22-000119:note_history:75]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 7 |  | $ | 13,760 |  | $ | 15,702 |  | $ | 11,293 |  | $ | 15,213 |  | $ | — |  | $ | — |  | $ | 25,055 |  | $ | 30,922 |  |
| Purchases - inventory | $ | 47,847 |  | $ | 50,788 |  | $ | 48,689 |  | $ | 35,229 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,670 |  | $ | 96,536 |  | $ | 87,687 |  |
| Purchases - other miscellaneous items | $ | 4,763 |  | $ | 2,116 |  | $ | 258 |  | $ | 339 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,021 |  | $ | 2,455 |  |
  (was, 2022-05-06, similarity 0.7926):
[0001375365-22-000058:note_history:75]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 3,928 |  | $ | 3,580 |  | $ | 43,739 |  | $ | 16,850 |  | $ | — |  | $ | — |  | $ | 47,669 |  | $ | 20,432 |  |
| Purchases - inventory | $ | 49,472 |  | $ | 32,150 |  | $ | 43,989 |  | $ | 24,115 |  | $ | — |  | $ | — |  | $ | 2,018 |  | $ | 1,189 |  | $ | 95,479 |  | $ | 57,454 |  |
| Purchases - other miscellaneous items | $ | 1,687 |  | $ | 2,002 |  | $ | 404 |  | $ | 475 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,091 |  | $ | 2,477 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:76]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- changed (2022-11-04):
[0001375365-22-000119:note_history:77]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):
  (was, 2022-05-06, similarity 0.9457):
[0001375365-22-000058:note_history:77]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2022 and 2021, are as follows (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:78]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | — |  | $ | (478) |  | $ | (1,134) |  | $ | (1,373) |  | $ | (4,181) |  | $ | — |  | $ | — |  | $ | (1,851) |  | $ | (5,315) |  |
| Changes in other receivable | $ | 1,276 |  | $ | 1,147 |  | $ | (11,415) |  | $ | (3,517) |  | $ | — |  | $ | — |  | $ | — |  | $ | (76) |  | $ | (10,139) |  | $ | (2,446) |  |
| Changes in accounts payable | $ | 664 |  | $ | 2,578 |  | $ | 6,010 |  | $ | 5,080 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,674 |  | $ | 7,658 |  |
| Changes in accrued liabilities | $ | (1,532) |  | $ | (1,229) |  | $ | 11,117 |  | $ | 3,304 |  | $ | — |  | $ | (500) |  | $ | — |  | $ | — |  | $ | 9,585 |  | $ | 1,575 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 146 |  | $ | 62 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 400 |  |
| Unpaid property, plant and equipment | $ | 3,782 |  | $ | 1,360 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,782 |  | $ | 1,360 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:79]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- added (2022-11-04):
[0001375365-22-000119:note_history:80]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. While the Agreement is currently still in effect, Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated.

- removed (2022-11-04):
[0001375365-22-000058:note_history:81]
The Company sold products to the Corporate Venture and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities.

- removed (2022-11-04):
[0001375365-22-000058:note_history:82]
Dealings with Monolithic Power Systems, Inc.

- removed (2022-11-04):
[0001375365-22-000058:note_history:83]
The Company procures certain semiconductor products from Monolithic Power Systems, Inc. (“MPS”), a fabless manufacturer of high-performance analog and mixed-signal semiconductors, for use in its products. A member of the Board of Directors, also serves as an officer of MPS.

- removed (2022-11-04):
[0001375365-22-000058:note_history:84]
The Company's results from transactions with its related parties for each of the nine months ended March 31, 2022 and 2021, are as follows (in thousands):

- removed (2022-11-04):
[0001375365-22-000058:note_history:85]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 12 |  | $ | (25) |  | $ | 22,932 |  | $ | 22,451 |  | $ | 97,262 |  | $ | 36,427 |  | $ | — |  | $ | — |  | $ | 120,206 |  | $ | 58,853 |  |
| Purchases - inventory | $ | 147,780 |  | $ | 77,838 |  | $ | 126,039 |  | $ | 87,330 |  | $ | — |  | $ | — |  | $ | 6,074 |  | $ | 2,677 |  | $ | 279,893 |  | $ | 167,845 |  |
| Purchases - other miscellaneous items | $ | 6,671 |  | $ | 7,482 |  | $ | 1,090 |  | $ | 1,434 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 7,761 |  | $ | 8,916 |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:86]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | 1 |  | $ | (30) |  | $ | (182) |  | $ | 133 |  | $ | (25,224) |  | $ | (3,635) |  | $ | — |  | $ | — |  | $ | (25,405) |  | $ | (3,532) |  |
| Changes in other receivable | $ | 3,159 |  | $ | (211) |  | $ | (8,933) |  | $ | (296) |  | $ | — |  | $ | — |  | $ | 48 |  | $ | 65 |  | $ | (5,726) |  | $ | (442) |  |
| Changes in accounts payable | $ | 814 |  | $ | (8,768) |  | $ | 16,356 |  | $ | (9,528) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 17,170 |  | $ | (18,296) |  |
| Changes in accrued liabilities | $ | (2,060) |  | $ | 955 |  | $ | (153) |  | $ | (635) |  | $ | (1,000) |  | $ | (500) |  | $ | — |  | $ | — |  | $ | (3,213) |  | $ | (180) |  |
| Changes in other long-term liabilities | $ | — |  | $ | (513) |  | $ | 596 |  | $ | (186) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | 596 |  | $ | (1,699) |  |
| Purchases of property, plant and equipment | $ | 2,365 |  | $ | 5,675 |  | $ | 140 |  | $ | 170 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,505 |  | $ | 5,845 |  |
| Unpaid property, plant and equipment | $ | 681 |  | $ | 1,434 |  | $ | 48 |  | 68 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 1,502 |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:87]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. 
Pursuant to the Agreement, the Subsidiary will participate in purchasing 33.33% of the 137,225.97 square meters (approximately 34 acres) of land Ablecom has agreed to acquire from third-party landowners in proximity to the Company’s campus in Bade, Taiwan. Compuware will acquire 17.21% of such land and Ablecom will retain the remaining 49.46% of the land. Under the Agreement, fees and costs related to such land purchase would be borne by the parties according to their proportionate share of the land purchased. The Company intends to fund its proportionate share of the land purchased under the Agreement which is estimated to be approximately NTD 789 million (or approximately US$28.3 million) from either available cash and/or borrowings under loan agreements the Subsidiary has in Taiwan. Amounts payable related to the purchase of the land are due in three installments based upon the achievement of specified milestones. The transaction is subject to various customary conditions precedent, including the receipt of government approvals, the discharge of mortgages and leases on the land, and the completion of due diligence. As of March 31, 2022, due diligence and discussions with government officials are continuing, and no installment payments have been made with respect to the transaction. If the transaction does not close within 12 months, Ablecom may offer the land to other parties.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:88]
The Company had the following balances related to transactions with its related parties as of September 30, 2022 and June 30, 2022 (in thousands):
  (was, 2022-05-06, similarity 0.9627):
[0001375365-22-000058:note_history:88]
The Company had the following balances related to transactions with its related parties as of March 31, 2022 and June 30, 2021 (in thousands):

- changed (2022-11-04):
[0001375365-22-000119:note_history:89]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 | September 30, 2022 | June 30, 2022 |  |  | September 30, 2022 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 882 |  | $ | 404 |  | $ | 9,365 |  | $ | 7,992 |  |  |  | $ | 10,249 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 3,540 |  | $ | 4,816 |  | $ | 31,011 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 34,551 |  | $ | 24,412 |  |
| Accounts payable | $ | 43,127 |  | $ | 42,463 |  | $ | 50,902 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 94,029 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,999 |  | $ | 3,531 |  | $ | 26,262 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 28,261 |  | $ | 18,676 |  |
  (was, 2022-05-06, similarity 0.8368):
[0001375365-22-000058:note_history:89]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 | March 31, 2022 | June 30, 2021 |
| Accounts receivable | $ | 1 |  | $ | 2 |  | $ | 381 |  | $ | 198 |  | $ | 33,702 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 34,084 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 2,415 |  | $ | 5,575 |  | $ | 27,105 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 41 |  | $ | 89 |  | $ | 29,561 |  | $ | 23,837 |  |
| Accounts payable | $ | 38,966 |  | $ | 38,152 |  | $ | 48,300 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 87,266 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 982 |  | $ | 3,042 |  | $ | 14,333 |  | $ | 14,486 |  | $ | — |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 15,315 |  | $ | 18,528 |  |

- changed (2022-11-04):
[0001375365-22-000119:note_history:90]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):
  (was, 2022-05-06, similarity 0.9662):
[0001375365-22-000058:note_history:90]
The Company's results from transactions with its related parties for each of the three months ended March 31, 2022 and 2021, are as follows (in thousands):

- changed (2022-11-04):
[0001375365-22-000119:note_history:91]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 7 |  | $ | 13,760 |  | $ | 15,702 |  | $ | 11,293 |  | $ | 15,213 |  | $ | — |  | $ | — |  | $ | 25,055 |  | $ | 30,922 |  |
| Purchases - inventory | $ | 47,847 |  | $ | 50,788 |  | $ | 48,689 |  | $ | 35,229 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,670 |  | $ | 96,536 |  | $ | 87,687 |  |
| Purchases - other miscellaneous items | $ | 4,763 |  | $ | 2,116 |  | $ | 258 |  | $ | 339 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,021 |  | $ | 2,455 |  |
  (was, 2022-05-06, similarity 0.7926):
[0001375365-22-000058:note_history:91]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 3,928 |  | $ | 3,580 |  | $ | 43,739 |  | $ | 16,850 |  | $ | — |  | $ | — |  | $ | 47,669 |  | $ | 20,432 |  |
| Purchases - inventory | $ | 49,472 |  | $ | 32,150 |  | $ | 43,989 |  | $ | 24,115 |  | $ | — |  | $ | — |  | $ | 2,018 |  | $ | 1,189 |  | $ | 95,479 |  | $ | 57,454 |  |
| Purchases - other miscellaneous items | $ | 1,687 |  | $ | 2,002 |  | $ | 404 |  | $ | 475 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,091 |  | $ | 2,477 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:92]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- changed (2022-11-04):
[0001375365-22-000119:note_history:93]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2022 and 2021, are as follows (in thousands):
  (was, 2022-05-06, similarity 0.9457):
[0001375365-22-000058:note_history:93]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2022 and 2021, are as follows (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:94]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | $ | — |  | $ | — |  | $ | (478) |  | $ | (1,134) |  | $ | (1,373) |  | $ | (4,181) |  | $ | — |  | $ | — |  | $ | (1,851) |  | $ | (5,315) |  |
| Changes in other receivable | $ | 1,276 |  | $ | 1,147 |  | $ | (11,415) |  | $ | (3,517) |  | $ | — |  | $ | — |  | $ | — |  | $ | (76) |  | $ | (10,139) |  | $ | (2,446) |  |
| Changes in accounts payable | $ | 664 |  | $ | 2,578 |  | $ | 6,010 |  | $ | 5,080 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,674 |  | $ | 7,658 |  |
| Changes in accrued liabilities | $ | (1,532) |  | $ | (1,229) |  | $ | 11,117 |  | $ | 3,304 |  | $ | — |  | $ | (500) |  | $ | — |  | $ | — |  | $ | 9,585 |  | $ | 1,575 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (105) |  | $ | — |  |
| Purchases of property, plant and equipment | $ | 583 |  | $ | 338 |  | $ | 146 |  | $ | 62 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 400 |  |
| Unpaid property, plant and equipment | $ | 3,782 |  | $ | 1,360 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,782 |  | $ | 1,360 |  |

- added (2022-11-04):
[0001375365-22-000119:note_history:95]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

- removed (2022-11-04):
[0001375365-22-000058:note_history:96]
The Company's results from transactions with its related parties for each of the nine months ended March 31, 2022 and 2021, are as follows (in thousands):

- removed (2022-11-04):
[0001375365-22-000058:note_history:97]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Net sales | $ | 12 |  | $ | (25) |  | $ | 22,932 |  | $ | 22,451 |  | $ | 97,262 |  | $ | 36,427 |  | $ | — |  | $ | — |  | $ | 120,206 |  | $ | 58,853 |  |
| Purchases - inventory | $ | 147,780 |  | $ | 77,838 |  | $ | 126,039 |  | $ | 87,330 |  | $ | — |  | $ | — |  | $ | 6,074 |  | $ | 2,677 |  | $ | 279,893 |  | $ | 167,845 |  |
| Purchases - other miscellaneous items | $ | 6,671 |  | $ | 7,482 |  | $ | 1,090 |  | $ | 1,434 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 7,761 |  | $ | 8,916 |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:98]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 | 2022 | 2021 |
| Changes in accounts receivable | 1 |  | $ | (30) |  | $ | (182) |  | $ | 133 |  | $ | (25,224) |  | $ | (3,635) |  | $ | — |  | $ | — |  | $ | (25,405) |  | $ | (3,532) |  |
| Changes in other receivable | $ | 3,159 |  | $ | (211) |  | $ | (8,933) |  | $ | (296) |  | $ | — |  | $ | — |  | $ | 48 |  | $ | 65 |  | $ | (5,726) |  | $ | (442) |  |
| Changes in accounts payable | $ | 814 |  | $ | (8,768) |  | $ | 16,356 |  | $ | (9,528) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 17,170 |  | $ | (18,296) |  |
| Changes in accrued liabilities | $ | (2,060) |  | $ | 955 |  | $ | (153) |  | $ | (635) |  | $ | (1,000) |  | $ | (500) |  | $ | — |  | $ | — |  | $ | (3,213) |  | $ | (180) |  |
| Changes in other long-term liabilities | $ | — |  | $ | (513) |  | $ | 596 |  | $ | (186) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | 596 |  | $ | (1,699) |  |
| Purchases of property, plant and equipment | $ | 2,365 |  | $ | 5,675 |  | $ | 140 |  | $ | 170 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,505 |  | $ | 5,845 |  |
| Unpaid property, plant and equipment | $ | 681 |  | $ | 1,434 |  | $ | 48 |  | 68 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 729 |  | $ | 1,502 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:99]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713,056 |  |  |  |  | $ | 849,856 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 139,074 |  |  |  |  | 182,874 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  |  |  | $ | 1,032,730 |  |  |  |  |  |  |  |  |  |  |  |
  (was, 2022-05-06, similarity 0.648):
[0001375365-22-000058:note_history:99]
|  | Three Months Ended March 31, |  |  |  | Nine Months Ended March 31, |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2021 |  |  |
| Server and storage systems | $ | 1,145,869 |  |  |  |  | $ | 693,339 |  |  |  |  | $ | 2,981,777 |  |  |  |  | $ | 1,953,838 |  |  |  |
| Subsystems and accessories | 209,621 |  |  |  |  | 202,542 |  |  |  |  | 578,862 |  |  |  |  | 534,599 |  |  |  |
| Total | $ | 1,355,490 |  |  |  |  | $ | 895,881 |  |  |  |  | $ | 3,560,639 |  |  |  |  | $ | 2,488,437 |  |  |  |

- changed (2022-11-04):
[0001375365-22-000119:note_history:100]
The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):
  (was, 2022-05-06, similarity 0.9243):
[0001375365-22-000058:note_history:100]
The following is a summary for the three and nine months ended March 31, 2022 and 2021, of net sales by geographic region (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:101]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 1,295,504 |  |  | $ | 560,948 |  |  |  |  |  |
| Asia | 270,024 |  |  | 263,086 |  |  |  |  |  |
| Europe | 235,074 |  |  | 179,694 |  |  |  |  |  |
| Other | 51,528 |  |  | 29,002 |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:102]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 762,418 |  |  | $ | 499,061 |  |  | $ | 1,961,573 |  |  | $ | 1,458,249 |  |
| Asia | 309,972 |  |  | 207,204 |  |  | 857,165 |  |  | 495,326 |  |
| Europe | 205,444 |  |  | 162,285 |  |  | 600,589 |  |  | 429,193 |  |
| Other | 77,656 |  |  | 27,331 |  |  | 141,312 |  |  | 105,669 |  |
|  | $ | 1,355,490 |  |  | $ | 895,881 |  |  | $ | 3,560,639 |  |  | $ | 2,488,437 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0001375365-22-000119:note_history:103]
The Company disaggregates revenue by type of product and by the geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.
  (was, 2022-05-06, similarity 0.9934):
[0001375365-22-000058:note_history:103]
The Company disaggregates revenue by type of product and by geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue, and are aggregated within the respective categories.

- changed (2022-11-04):
[0001375365-22-000119:note_history:104]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713,056 |  |  |  |  | $ | 849,856 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 139,074 |  |  |  |  | 182,874 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  |  |  | $ | 1,032,730 |  |  |  |  |  |  |  |  |  |  |  |
  (was, 2022-05-06, similarity 0.648):
[0001375365-22-000058:note_history:104]
|  | Three Months Ended March 31, |  |  |  | Nine Months Ended March 31, |  |  |
|  | 2022 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2021 |  |  |
| Server and storage systems | $ | 1,145,869 |  |  |  |  | $ | 693,339 |  |  |  |  | $ | 2,981,777 |  |  |  |  | $ | 1,953,838 |  |  |  |
| Subsystems and accessories | 209,621 |  |  |  |  | 202,542 |  |  |  |  | 578,862 |  |  |  |  | 534,599 |  |  |  |
| Total | $ | 1,355,490 |  |  |  |  | $ | 895,881 |  |  |  |  | $ | 3,560,639 |  |  |  |  | $ | 2,488,437 |  |  |  |

- changed (2022-11-04):
[0001375365-22-000119:note_history:105]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2022 and 2021, of net sales by geographic region (in thousands):
  (was, 2022-05-06, similarity 0.8946):
[0001375365-22-000058:note_history:105]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2022 and 2021, of net sales by geographic region (in thousands):

- added (2022-11-04):
[0001375365-22-000119:note_history:106]
|  | Three Months Ended September 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| United States | $ | 1,295,504 |  |  | $ | 560,948 |  |  |  |  |  |
| Asia | 270,024 |  |  | 263,086 |  |  |  |  |  |
| Europe | 235,074 |  |  | 179,694 |  |  |  |  |  |
| Other | 51,528 |  |  | 29,002 |  |  |  |  |  |
| Total | $ | 1,852,130 |  |  | $ | 1,032,730 |  |  |  |  |  |

- changed (2022-11-04):
[0001375365-22-000119:note_history:107]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2022, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $33.5 million.
  (was, 2022-05-06, similarity 0.9485):
[0001375365-22-000058:note_history:107]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2022, which was included in the deferred revenue balance as of June 30, 2021 of $202.3 million, was $23.0 million and $79.7 million, respectively.

- added (2022-11-04):
[0001375365-22-000119:note_history:108]
Deferred revenue increased $86.0 million as of September 30, 2022 as compared to the fiscal year ended June 30, 2022 of which $69.6 million was due to the increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

- changed (2022-11-04):
[0001375365-22-000119:note_history:109]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2022 was $319.8 million. The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2022-05-06, similarity 0.9925):
[0001375365-22-000058:note_history:109]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2022 was $229.8 million. The Company expects to recognize approximately 50% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2022-11-04):
[0001375365-22-000058:note_history:110]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States | $ | 762,418 |  |  | $ | 499,061 |  |  | $ | 1,961,573 |  |  | $ | 1,458,249 |  |
| Asia | 309,972 |  |  | 207,204 |  |  | 857,165 |  |  | 495,326 |  |
| Europe | 205,444 |  |  | 162,285 |  |  | 600,589 |  |  | 429,193 |  |
| Other | 77,656 |  |  | 27,331 |  |  | 141,312 |  |  | 105,669 |  |
|  | $ | 1,355,490 |  |  | $ | 895,881 |  |  | $ | 3,560,639 |  |  | $ | 2,488,437 |  |

- removed (2022-11-04):
[0001375365-22-000058:note_history:111]
Deferred revenue increased $27.4 million as of March 31, 2022 as compared to the fiscal year ended June 30, 2021 mainly because the deferral on invoiced amounts for service contracts during the period exceeded the recognition of revenue from contracts entered into in prior periods.
