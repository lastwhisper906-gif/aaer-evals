# SMCI MD&A — 0001375365-22-000119


## mdna

[0001375365-22-000119:mdna:1]
[same as prior period, unchanged from 0001375365-22-000058:mdna:1]

[0001375365-22-000119:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2022 (the “2022 10-K”), which includes our condensed consolidated financial statements for the fiscal years ended June 30, 2022 and 2021.

[0001375365-22-000119:mdna:3]
[same as prior period, unchanged from 0001375365-22-000058:mdna:3]

[0001375365-22-000119:mdna:4]
We are a Silicon Valley-based provider of accelerated compute platforms that are application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence, 5G and edge computing. Our Total IT Solutions include complete servers, storage systems, modular blade servers, blades, workstations, full rack scale solutions, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-22-000119:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended September 30, 2022 increased to $184.4 million from $25.4 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-22-000119:mdna:6]
SMCI | Q1 2023 Form 10-Q | 31

[0001375365-22-000119:mdna:7]
[same as prior period, unchanged from 0001375365-22-000058:mdna:13]

[0001375365-22-000119:mdna:8]
The following is a summary of our financial highlights of the first quarter of fiscal year 2023:

[0001375365-22-000119:mdna:9]
•Net sales increased by 79.3% in the three months ended September 30, 2022 as compared to the three months ended September 30, 2021.

[0001375365-22-000119:mdna:10]
•Gross margin increased to 18.8% in the three months ended September 30, 2022 from 13.4% in the three months ended September 30, 2021.

[0001375365-22-000119:mdna:11]
•Operating expenses increased by 16.9% as compared to the three months ended September 30, 2021 and were equal to 6.9% and 10.6% of net sales in the three months ended September 30, 2022 and 2021, respectively.

[0001375365-22-000119:mdna:12]
•Effective tax rate increased to 17.4% in the three months ended September 30, 2022 from 11.7% in the three months ended September 30, 2021.

[0001375365-22-000119:mdna:13]
[same as prior period, unchanged from 0001375365-22-000058:mdna:19]

[0001375365-22-000119:mdna:14]
[same as prior period, unchanged from 0001375365-22-000058:mdna:20]

[0001375365-22-000119:mdna:15]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2022 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Summary of Significant Accounting Policies" in our notes to condensed consolidated financial statements in this Quarterly Report.

[0001375365-22-000119:mdna:16]
SMCI | Q1 2023 Form 10-Q | 32

[0001375365-22-000119:mdna:17]
[same as prior period, unchanged from 0001375365-22-000058:mdna:22]

[0001375365-22-000119:mdna:18]
[same as prior period, unchanged from 0001375365-22-000058:mdna:23]

[0001375365-22-000119:mdna:19]
|  | Three Months EndedSeptember 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net sales | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of sales | 81.2 | % |  | 86.6 | % |  |  |  |  |
| Gross profit | 18.8 | % |  | 13.4 | % |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4.0 | % |  | 6.3 | % |  |  |  |  |
| Sales and marketing | 1.6 | % |  | 2.1 | % |  |  |  |  |
| General and administrative | 1.3 | % |  | 2.2 | % |  |  |  |  |
| Total operating expenses | 6.9 | % |  | 10.6 | % |  |  |  |  |
| Income from operations | 11.9 | % |  | 2.8 | % |  |  |  |  |
| Other income, net | 0.4 | % |  | — | % |  |  |  |  |
| Interest expense | (0.2) | % |  | (0.1) | % |  |  |  |  |
| Income before income tax provision | 12.1 | % |  | 2.7 | % |  |  |  |  |
| Income tax provision | (2.1) | % |  | (0.3) | % |  |  |  |  |
| Share of income (loss) from equity investee, net of taxes | — | % |  | — | % |  |  |  |  |
| Net income | 10.0 | % |  | 2.5 | % |  |  |  |  |

[0001375365-22-000119:mdna:20]
[same as prior period, unchanged from 0001375365-22-000058:mdna:25]

[0001375365-22-000119:mdna:21]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-22-000119:mdna:22]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPU/GPU, memory and storage.

[0001375365-22-000119:mdna:23]
SMCI | Q1 2023 Form 10-Q | 33

[0001375365-22-000119:mdna:24]
The following table presents net sales by product type for the three months ended September 30, 2022 and 2021 (dollars in millions):

[0001375365-22-000119:mdna:25]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 1,713.1 |  |  | $ | 849.9 |  |  | $ | 863.2 |  |  | 101.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 92.5 | % |  | 82.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | $ | 139.0 |  |  | $ | 182.9 |  |  | $ | (43.9) |  |  | (24.0) | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 7.5 | % |  | 17.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 1,852.1 |  |  | $ | 1,032.8 |  |  | $ | 819.3 |  |  | 79.3 | % |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:26]
Server and storage systems constitute an assembly and integration of subsystems and accessories and related services. Subsystems and accessories are comprised of server-boards, chassis and accessories.

[0001375365-22-000119:mdna:27]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:28]
The period-over-period increase in net sales of our server and storage systems was due to a 36.2% increase in the number of units of compute nodes sold and a 50.4% increase in the average selling price.

[0001375365-22-000119:mdna:29]
The period-over-period decrease in net sales for our subsystems and accessories of 24.0% is primarily due to recent supply chain constraints and higher sales of complete systems.

[0001375365-22-000119:mdna:30]
The following table presents net sales by geographic region for the three months ended September 30, 2022 and 2021 (dollars in millions):

[0001375365-22-000119:mdna:31]
|  | Three Months Ended September 30, |  | Change |  | Change |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| United States | $ | 1,295.5 |  |  | $ | 560.9 |  |  | $ | 734.6 |  |  | 131.0 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 69.9 | % |  | 54.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 270.0 |  |  | $ | 263.1 |  |  | $ | 6.9 |  |  | 2.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 14.6 | % |  | 25.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe | $ | 235.1 |  |  | $ | 179.7 |  |  | $ | 55.4 |  |  | 30.8 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 12.7 | % |  | 17.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | $ | 51.5 |  |  | $ | 29.0 |  |  | $ | 22.5 |  |  | 77.6 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.8 | % |  | 2.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net sales | $ | 1,852.1 |  |  | $ | 1,032.7 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:32]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:33]
The period-over-period increase in overall net sales is the result of increased selling prices, led by higher GPU based products and quantities of product shipments. The increase in the United States is primarily due to higher sales driven by high demand of GPU based server and storage systems. The increase of net sales in Europe was primarily due to increases in net sales in the Netherlands, UK and Germany.

[0001375365-22-000119:mdna:34]
SMCI | Q1 2023 Form 10-Q | 34

[0001375365-22-000119:mdna:35]
[same as prior period, unchanged from 0001375365-22-000058:mdna:43]

[0001375365-22-000119:mdna:36]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in average selling prices are not matched by corresponding changes in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions.

[0001375365-22-000119:mdna:37]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-22-000119:mdna:38]
Cost of sales and gross margin for the three months ended September 30, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000119:mdna:39]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Cost of sales | $ | 1,504.6 |  |  | $ | 894.6 |  |  | $ | 610.0 |  |  | 68.2 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 347.5 |  |  | $ | 138.1 |  |  | $ | 209.4 |  |  | 151.6 | % |  |  |  |  |  |  |  |  |
| Gross margin | 18.8 | % |  | 13.4 | % |  |  |  | 5.4 | % |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:40]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:41]
The period-over-period increase in cost of sales was primarily attributed to an increase of $583.8 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $19.4 million increase in overhead costs, a $6.2 million increase in excess and obsolete inventory charges and a $0.6 million increase in freight costs.

[0001375365-22-000119:mdna:42]
The period-over-period increase in the gross margin percentage was primarily due to sales price increases and recent price drop in key components. Throughout the COVID-19 pandemic, we experienced an increase in costs of sales, logistics costs as well as direct labor costs to retain our employees. For the quarter ended September 30, 2022, the cost of freight and some components started to decrease.

[0001375365-22-000119:mdna:43]
[same as prior period, unchanged from 0001375365-22-000058:mdna:54]

[0001375365-22-000119:mdna:44]
[same as prior period, unchanged from 0001375365-22-000058:mdna:55]

[0001375365-22-000119:mdna:45]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-22-000119:mdna:46]
SMCI | Q1 2023 Form 10-Q | 35

[0001375365-22-000119:mdna:47]
[same as prior period, unchanged from 0001375365-22-000058:mdna:57]

[0001375365-22-000119:mdna:48]
Operating expenses for the three months ended September 30, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000119:mdna:49]
|  | Three Months Ended September 30, |  | Change |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Research and development | $ | 74.2 |  |  | $ | 65.1 |  |  | $ | 9.1 |  |  | 14.0 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 4.0 | % |  | 6.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | 29.4 |  |  | $ | 21.6 |  |  | $ | 7.8 |  |  | 36.1 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.6 | % |  | 2.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | $ | 23.8 |  |  | $ | 22.2 |  |  | $ | 1.6 |  |  | 7.2 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 1.3 | % |  | 2.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 127.4 |  |  | $ | 109.0 |  |  | $ | 18.4 |  |  | 16.9 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 6.9 | % |  | 10.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:50]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:51]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $7.6 million increase in personnel expenses and a higher headcount, a $1.4 million increase in product development costs and $0.1 million lower research and development credits from certain suppliers and customers towards our development efforts.

[0001375365-22-000119:mdna:52]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $5.6 million increase in personnel expenses and a higher headcount and a $2.2 million increase in advertising and other expenses.

[0001375365-22-000119:mdna:53]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to a $1.6 million increase in personnel expenses and a higher headcount.

[0001375365-22-000119:mdna:54]
Interest Expense and Other Income, Net

[0001375365-22-000119:mdna:55]
Other income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-22-000119:mdna:56]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-22-000119:mdna:57]
Interest expense and other income, net for the three months ended September 30, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000119:mdna:58]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income, net | $ | 8.1 |  |  | $ | 0.1 |  |  | $ | 8.0 |  |  | 8,000.0 | % |  |  |  |  |  |  |  |  |
| Interest expense | (3.9) |  |  | (0.8) |  |  | (3.1) |  |  | 387.5 | % |  |  |  |  |  |  |  |  |
| Interest expense and other income, net | $ | 4.2 |  |  | $ | (0.7) |  |  | $ | 4.9 |  |  | (700.0) | % |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:59]
SMCI | Q1 2023 Form 10-Q | 36

[0001375365-22-000119:mdna:60]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:61]
The change of $4.9 million in interest expense and other income, net was primarily attributable to a $8.0 million increase in foreign exchange gain due to favorable currency fluctuations offset by a $3.1 million increase in interest expense due to increase in average loan balances and interest rates.

[0001375365-22-000119:mdna:62]
Income Tax Provision

[0001375365-22-000119:mdna:63]
[same as prior period, unchanged from 0001375365-22-000058:mdna:78]

[0001375365-22-000119:mdna:64]
Provision for income taxes and effective tax rates for the three months ended September 30, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000119:mdna:65]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income tax provision | $ | 38.9 |  |  | $ | 3.3 |  |  | $ | 35.6 |  |  | 1,078.8 | % |  |  |  |  |  |  |  |  |
| Percentage of total net sales | 2.1 | % |  | 0.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Effective tax rate | 17.4 | % |  | 11.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:66]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:67]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The income tax provision and effective tax rate for the three months ended September 30, 2022 is higher than that for the three months ended September 30, 2021, primarily due to a significant increase in annual forecasted taxable income while the deductible expenses and the quarter discrete items kept at a much lower rate of growth.

[0001375365-22-000119:mdna:68]
Share of (Loss) Income from Equity Investee, Net of Taxes

[0001375365-22-000119:mdna:69]
Share of (loss) income from equity investee, net of taxes represents our share of income from the Corporate Venture in which we have 30% ownership.

[0001375365-22-000119:mdna:70]
Share of (loss) income from equity investee, net of taxes for the three months ended September 30, 2022 and 2021 are as follows (dollars in millions):

[0001375365-22-000119:mdna:71]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
| Share of (loss) income from equity investee, net of taxes | $ | (0.9) |  |  | $ | 0.4 |  |  | $ | (1.3) |  |  | (325.0)% |  |  |  |  |  |  |  |  |
| Percentage of total net sales | — | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001375365-22-000119:mdna:72]
Comparison of Three Months Ended September 30, 2022 and 2021

[0001375365-22-000119:mdna:73]
The period-over-period decrease of $1.3 million in share of (loss) income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-22-000119:mdna:74]
SMCI | Q1 2023 Form 10-Q | 37

[0001375365-22-000119:mdna:75]
[same as prior period, unchanged from 0001375365-22-000058:mdna:93]

[0001375365-22-000119:mdna:76]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities. The credit facilities were related to an increase in the need for working capital due to increasing sales, longer supply chain manufacturing and delivery times as well as the financing of property, plant and equipment acquisitions. We also received funds from the exercise of employee stock options. Our cash and cash equivalents were $238.3 million and $267.4 million as of September 30, 2022 and June 30, 2022, respectively. Our cash in foreign locations was $128.2 million and $169.5 million as of September 30, 2022 and June 30, 2022, respectively.

[0001375365-22-000119:mdna:77]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-22-000119:mdna:78]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these consolidated financial statements. In August 2022, we entered into a new general credit agreement with E.SUN Bank. This New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million in loans that will support the growth of our Taiwan business.

[0001375365-22-000119:mdna:79]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first.

[0001375365-22-000119:mdna:80]
[same as prior period, unchanged from 0001375365-22-000058:mdna:98]

[0001375365-22-000119:mdna:81]
|  | Three Months EndedSeptember 30, |  | Change |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 313.6 |  |  | $ | (134.6) |  |  | $ | 448.2 |  |  |  |  |
| Net cash (used in) investing activities | $ | (10.7) |  |  | $ | (11.9) |  |  | $ | 1.2 |  |  |  |  |
| Net cash (used in) provided by financing activities | $ | (331.2) |  |  | $ | 184.3 |  |  | $ | (515.5) |  |  |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (29.8) |  |  | $ | 37.8 |  |  | $ | (67.6) |  |  |  |  |

[0001375365-22-000119:mdna:82]
[same as prior period, unchanged from 0001375365-22-000058:mdna:100]

[0001375365-22-000119:mdna:83]
Net cash provided by operating activities increased by $448.2 million for the three months ended September 30, 2022 as compared to the three months ended September 30, 2021. The increase was primarily due to an increase of net income of $160.2 million offset by $9.2 million of unrealized gain and $6.8 million of various non-cash items, faster collection of accounts receivable as well as the prepayment by customers for products.

[0001375365-22-000119:mdna:84]
[same as prior period, unchanged from 0001375365-22-000058:mdna:102]

[0001375365-22-000119:mdna:85]
Net cash used in investing activities increased by $1.2 million for the three months ended September 30, 2022 as compared to the three months ended September 30, 2021 due to an investment made in a privately held company in the three months ended September 30, 2021.

[0001375365-22-000119:mdna:86]
[same as prior period, unchanged from 0001375365-22-000058:mdna:104]

[0001375365-22-000119:mdna:87]
Net cash used by financing activities for the three months ended September 30, 2022 was $331.2 million while net cash provided by financing activities for the three months ended September 30, 2021 was $184.3 million. The change in cash flows from financing activities was primarily due to a decrease of $190.7 million in proceeds from borrowings and a decrease of $325.3 million in repayment of debt.

[0001375365-22-000119:mdna:88]
SMCI | Q1 2023 Form 10-Q | 38

[0001375365-22-000119:mdna:89]
[same as prior period, unchanged from 0001375365-22-000058:mdna:106]

[0001375365-22-000119:mdna:90]
[same as prior period, unchanged from 0001375365-22-000058:mdna:140]

[0001375365-22-000119:mdna:91]
[same as prior period, unchanged from 0001375365-22-000058:mdna:141]

[0001375365-22-000119:mdna:92]
We anticipate our capital expenditures for the remainder of fiscal year 2023 will be approximately $35 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-22-000119:mdna:93]
We intend to continue to focus our capital expenditures in fiscal year 2023 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-22-000119:mdna:94]
[same as prior period, unchanged from 0001375365-22-000058:mdna:143]

[0001375365-22-000119:mdna:95]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Summary of Significant Accounting Policies,” to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q.

[0001375365-22-000119:mdna:96]
SMCI | Q1 2023 Form 10-Q | 39
