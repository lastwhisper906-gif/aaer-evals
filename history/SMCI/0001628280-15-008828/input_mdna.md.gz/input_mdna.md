# SMCI MD&A — 0001628280-15-008828


## mdna

[0001628280-15-008828:mdna:1]
[same as prior period, unchanged from 0001628280-15-003900:mdna:1]

[0001628280-15-008828:mdna:2]
[same as prior period, unchanged from 0001628280-15-003900:mdna:2]

[0001628280-15-008828:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, HPC and embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Net sales of optimized servers were $356.2 million and $255.6 million for the three months ended September 30, 2015 and 2014, respectively, and net sales of subsystems and accessories were $163.4 million and $187.7 million, respectively. The increase in our net sales in the three months ended September 30, 2015 compared with the three months ended September 30, 2014 was primarily due to increased sales of our products optimized for OEM and cloud/internet data center computing. In the three months ended September 30, 2015, we experienced strong growth in sales of our complete systems including ultra, storage and data center optimized servers. The percentage of our net sales represented by sales of complete server systems increased to 68.6% in the three months ended September 30, 2015 from 57.7% in the three months ended September 30, 2014.

[0001628280-15-008828:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales were $519.6 million and $443.3 million for the three months ended September 30, 2015 and 2014, respectively, and our net income was $13.7 million and $20.9 million for the three months ended September 30, 2015 and 2014, respectively. Our decrease in net income in the three months ended September 30, 2015 was primarily attributable to the recording of a $9.3 million out-of-period adjustment relating to extended warranty revenue in the three months ended September 30, 2015. This deferred revenue will be recognized through fiscal year 2019. The impact on net income from this out-of-period adjustment was $5.9 million. See Note 12 of the Notes to our Condensed Consolidated Financial Statements.

[0001628280-15-008828:mdna:5]
We sell our server systems and subsystems and accessories through distributors and OEMs as well as through our direct sales force. For the three months ended September 30, 2015 and 2014, we derived 45.6% and 56.0%, respectively, of our net sales from products sold to distributors. Sales to SoftLayer, a division of IBM Corporation, represented 12.2% of our net sales in the three months ended September 30, 2015, and none of our customers accounted for 10% or more of our net sales in the three months ended September 30, 2014. We derived 65.2% and 54.9% of our net sales from customers in the United States for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.5% and 4.9% of our net sales for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the three months ended September 30, 2015, we continued to increase manufacturing and service operations in Taiwan and the Netherlands to primarily support our Asian and European customers and we have improved our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three months ended September 30, 2015 and 2014, our purchases from Ablecom represented 13.2% and 14.5% of our cost of sales, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party

[0001628280-15-008828:mdna:8]
supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-15-008828:mdna:9]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding, or DSOs. In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures.

[0001628280-15-008828:mdna:10]
[same as prior period, unchanged from 0001628280-15-003900:mdna:10]

[0001628280-15-008828:mdna:11]
The following is a summary of other financial highlights of the first quarter of fiscal 2016:

[0001628280-15-008828:mdna:12]
| • | Net cash provided by operating activities was $20.3 million and $27.0 million during the three months ended September 30, 2015 and 2014, respectively. Our cash and cash equivalents, together with our investments, were $113.6 million at the end of the first quarter of fiscal year 2016, compared with $98.1 million at the end of fiscal year 2015. The increase in our cash and cash equivalents, together with our investments at the end of the first quarter of fiscal year 2016 was primarily due to $20.3 million of cash provided by our operating activities and $1.8 million of borrowings, net of repayments offset in part by $7.7 million of purchases of property and equipment, of which $2.8 million was related to the property and equipment of our first manufacturing building at our Green Computing Park in San Jose, California, which was completed in August 2015. |

[0001628280-15-008828:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the first quarter of fiscal year 2016 was 55 days, compared with 43 days at the end of fiscal year 2015. The increase in our DSO was primarily due to lower sales in the quarter. |

[0001628280-15-008828:mdna:14]
| • | Our inventory balance was $461.4 million at the end of the first quarter of fiscal year 2016, compared with $463.5 million at the end of fiscal year 2015. Days sales of inventory at the end of the first quarter of fiscal year 2016 was 95 days, compared with 83 days at the end of fiscal year 2015. The increase in our days sales of inventory was due to lower cost of goods sold from lower sales in the first quarter of fiscal year 2016 than we had anticipated. |

[0001628280-15-008828:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $392.0 million at the end of the first quarter of fiscal year 2016 and $378.3 million at the end of fiscal year 2015. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $201.6 million, which have terms expiring through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-15-008828:mdna:16]
Prior Period Adjustment Recorded in Current Quarter

[0001628280-15-008828:mdna:17]
In November 2015, we identified and corrected certain errors related to certain contracts which included extended product warranties which were recorded as revenue in prior periods instead of being deferred and amortized over the contractual period. See Note 12 of Notes to our Condensed Consolidated Financial Statements for additional details. Consequently, the condensed consolidated statement of operations for the three months ended September 30, 2015 and condensed consolidated balance sheet as of September 30, 2015 have been revised from those originally announced by the Company on October 22, 2015 to correct for these errors. This Management's Discussion and Analysis of Financial Condition and Results of Operations is based on the revised financial results.

[0001628280-15-008828:mdna:18]
[same as prior period, unchanged from 0001628280-15-003900:mdna:17]

[0001628280-15-008828:mdna:19]
Our fiscal year ends on June 30. References to fiscal year 2016, for example, refer to the fiscal year ending June 30, 2016.

[0001628280-15-008828:mdna:20]
[same as prior period, unchanged from 0001628280-15-003900:mdna:19]

[0001628280-15-008828:mdna:21]
[same as prior period, unchanged from 0001628280-15-003900:mdna:20]

[0001628280-15-008828:mdna:22]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally lower on server systems than on subsystems and accessories, but generally higher in the case of sales of server systems to internet data system customers. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001628280-15-008828:mdna:23]
[same as prior period, unchanged from 0001628280-15-003900:mdna:22]

[0001628280-15-008828:mdna:24]
[same as prior period, unchanged from 0001628280-15-003900:mdna:23]

[0001628280-15-008828:mdna:25]
[same as prior period, unchanged from 0001628280-15-003900:mdna:24]

[0001628280-15-008828:mdna:26]
[same as prior period, unchanged from 0001628280-15-003900:mdna:25]

[0001628280-15-008828:mdna:27]
[same as prior period, unchanged from 0001628280-15-003900:mdna:26]

[0001628280-15-008828:mdna:28]
[same as prior period, unchanged from 0001628280-15-003900:mdna:27]

[0001628280-15-008828:mdna:29]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, inventory valuations, income taxes, warranty obligations and stock-based compensation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from the estimates.

[0001628280-15-008828:mdna:30]
We believe the following are our most critical accounting policies as they require our more significant judgments in the preparation of our financial statements.

[0001628280-15-008828:mdna:31]
[same as prior period, unchanged from 0001628280-15-003900:mdna:30]

[0001628280-15-008828:mdna:32]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At September 30, 2015 and June 30, 2015, we had deferred product revenue of $0.4 million and $0.5 million and related deferred product costs of $0.2 million and $0.2 million, respectively, related to shipments to customers pending acceptances.

[0001628280-15-008828:mdna:33]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision for bad debt was $98,000 and $(54,000) in the three months ended September 30, 2015 and 2014, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-15-008828:mdna:34]
We  have an immaterial amount of service revenue relating to on-site service, extended warranty and non-warranty repairs. Revenue for on-site service and extended warranty is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001628280-15-008828:mdna:35]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are

[0001628280-15-008828:mdna:36]
charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.5 million as of September 30, 2015, compared with $7.7 million as of June 30, 2015. The provision for warranty reserve was $3.9 million and $3.7 million in the three months ended September 30, 2015 and 2014, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was ($0.2) million for both the three months ended September 30, 2015 and 2014. As a result of our increase in cost of servicing warranty claims from our increase in net sales in the three months ended September 30, 2015, the provision for warranty reserve increased $0.2 million compared to the three months ended September 30, 2014. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001628280-15-008828:mdna:37]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $1.7 million in both three months ended September 30, 2015 and 2014.

[0001628280-15-008828:mdna:38]
[same as prior period, unchanged from 0001628280-15-003900:mdna:36]

[0001628280-15-008828:mdna:39]
[same as prior period, unchanged from 0001628280-15-003900:mdna:37]

[0001628280-15-008828:mdna:40]
[same as prior period, unchanged from 0001628280-15-003900:mdna:38]

[0001628280-15-008828:mdna:41]
[same as prior period, unchanged from 0001628280-15-003900:mdna:39]

[0001628280-15-008828:mdna:42]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-15-008828:mdna:43]
Compensation expense for options and restricted stock units granted to employees was $3.9 million and $3.0 million for the three months ended September 30, 2015 and 2014, respectively. As of September 30, 2015, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options and restricted stock units to employees and non-employee members of our Board of Directors, was $30.7 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.27 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001628280-15-008828:mdna:44]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-15-008828:mdna:45]
In May 2012, we and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of September 30, 2015, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2015 and 2014, $2,000 and $3,000, respectively, of net income attributable to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-15-008828:mdna:46]
[same as prior period, unchanged from 0001628280-15-003900:mdna:45]

[0001628280-15-008828:mdna:47]
Net Sales

[0001628280-15-008828:mdna:48]
The following table presents net sales by product type for the three months ended September 30, 2015 and 2014 (dollars in millions):

[0001628280-15-008828:mdna:49]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |
| Server systems | $ | 356.2 |  |  | $ | 255.6 |  |  | $ | 100.6 |  |  | 39.4 | % |
| Percentage of total net sales | 68.6 | % |  | 57.7 | % |  |  |  |  |
| Subsystems and accessories | 163.4 |  |  | 187.7 |  |  | (24.3 | ) |  | (12.9 | )% |
| Percentage of total net sales | 31.4 | % |  | 42.3 | % |  |  |  |  |
| Total net sales | $ | 519.6 |  |  | $ | 443.3 |  |  | $ | 76.3 |  |  | 17.2 | % |

[0001628280-15-008828:mdna:50]
The following table presents unit sales and average selling price by product type for the three months ended September 30, 2015 and 2014 (units in thousands):

[0001628280-15-008828:mdna:51]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | % |
| Server systems: |  |  |  |  |  |
| Unit sales | 87 |  |  | 71 |  |  | 22.5 | % |
| Average selling price | $ | 4,094 |  |  | $ | 3,600 |  |  | 13.7 | % |
| Subsystems and accessories: |  |  |  |  |  |
| Unit sales | 916 |  |  | 1,254 |  |  | (27.0 | )% |
| Average selling price | $ | 178 |  |  | $ | 150 |  |  | 18.7 | % |

[0001628280-15-008828:mdna:52]
Comparison of Three Months Ended September 30, 2015 and 2014

[0001628280-15-008828:mdna:53]
The increase in our net sales in the three months ended September 30, 2015 compared with the three months ended September 30, 2014 was primarily due to continued increased sales of our products optimized for OEM and cloud/internet data center computing who increasingly are purchasing complete server systems from us offset in part by a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three prior fiscal year period ended June 30, 2015 and deferred in the three months ended September 30, 2015. The year-over-year growth in net sales of our server systems in the three months ended September 30, 2015 was due primarily to an increase in unit volumes of server systems and to a lesser extent an increase in the average selling price of our server systems. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, storage and data center optimized servers.

[0001628280-15-008828:mdna:54]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in the three months ended September 30, 2015 was primarily due to lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who are purchasing additional accessories from us and completing the final assembly themselves.

[0001628280-15-008828:mdna:55]
The following table presents the percentages of net sales from products sold to distributors and OEMs and to end customers for the three months ended September 30, 2015 and 2014:

[0001628280-15-008828:mdna:56]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | % |
| Distributors | 45.6 | % |  | 56.0 | % |  | (10.4 | )% |
| OEMs and end customers | 54.4 | % |  | 44.0 | % |  | 10.4 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-15-008828:mdna:57]
The following table presents percentages of net sales by geographic region for the three months ended September 30, 2015 and 2014:

[0001628280-15-008828:mdna:58]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | % |
| United States | 65.2 | % |  | 54.9 | % |  | 10.3 | % |
| Europe | 16.8 | % |  | 20.2 | % |  | (3.4 | )% |
| Asia | 14.3 | % |  | 19.9 | % |  | (5.6 | )% |
| Others | 3.7 | % |  | 5.0 | % |  | (1.3 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-15-008828:mdna:59]
Cost of Sales and Gross Margin

[0001628280-15-008828:mdna:60]
Cost of sales and gross margin for the three months ended September 30, 2015 and 2014 are as follows (dollars in millions):

[0001628280-15-008828:mdna:61]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |
| Total cost of sales | $ | 447.4 |  |  | $ | 374.1 |  |  | $ | 73.3 |  |  | 19.6 | % |
| Total gross profit | 72.2 |  |  | 69.2 |  |  | $ | 3.0 |  |  | 4.4 | % |
| Total gross margin | 13.9 | % |  | 15.6 | % |  |  |  | (1.7 | )% |

[0001628280-15-008828:mdna:62]
Comparison of Three Months Ended September 30, 2015 and 2014

[0001628280-15-008828:mdna:63]
The year-over-year increase in absolute dollars of cost of sales in the three months ended September 30, 2015 compared to the three months ended September 30, 2014 was primarily attributable to the increase in net sales. In the three months ended September 30, 2015, we recorded a $1.7 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $1.7 million, or 0.4% of net sales, in the three months ended September 30, 2014.

[0001628280-15-008828:mdna:64]
In the three months ended September 30, 2015, we recorded a $3.9 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to a $3.7 million expense, or 0.8% of net sales, in the three months ended September 30, 2014. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the three months ended September 30, 2015. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-15-008828:mdna:65]
Gross margin percentage was 13.9% and 15.6% for the three months ended September 30, 2015 and 2014, respectively. The year-over-year decrease in gross margins in the three months ended September 30, 2015 was mainly due to a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three fiscal year period ended June 30, 2015. Gross margin percentage would have been 15.4% without this out-of-period adjustment. The remaining decrease in gross margin percentage was primarily attributable to lower gross margins from sales of our subsystem and accessories and higher cloud/internet data center sales, partially offset by higher sales of complete server systems such as ultra and storage servers which have higher gross margins.

[0001628280-15-008828:mdna:66]
Operating Expenses

[0001628280-15-008828:mdna:67]
Operating expenses for the three months ended September 30, 2015 and 2014 are as follows (dollars in millions):

[0001628280-15-008828:mdna:68]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |
| Research and development | $ | 28.3 |  |  | $ | 21.5 |  |  | $ | 6.8 |  |  | 31.7 | % |
| Percentage of total net sales | 5.5 | % |  | 4.9 | % |  |  |  |  |
| Sales and marketing | 14.2 |  |  | 11.0 |  |  | 3.2 |  |  | 29.5 | % |
| Percentage of total net sales | 2.7 | % |  | 2.5 | % |  |  |  |  |
| General and administrative | 8.2 |  |  | 5.1 |  |  | 3.1 |  |  | 62.2 | % |
| Percentage of total net sales | 1.6 | % |  | 1.1 | % |  |  |  |  |
| Total operating expenses | 50.8 |  |  | $ | 37.6 |  |  | $ | 13.2 |  |  | 35.2 | % |
| Percentage of total net sales | 9.8 | % |  | 8.5 | % |  |  |  |  |

[0001628280-15-008828:mdna:69]
Research and development expenses. Research and development expenses increased by $6.8 million, or 31.7% in the three months ended September 30, 2015 compared to the three months ended September 30, 2014. Research and development expenses were 5.5% and 4.9% of net sales for the three months ended September 30, 2015 and 2014, respectively. The increase in absolute dollars was driven primarily by an increase of $4.6 million in compensation and benefits including stock-based compensation expense and a decrease of $1.9 million refund of value added taxes on research and development expenses.

[0001628280-15-008828:mdna:70]
Research and development expenses include stock-based compensation expense of $2.4 million and $1.9 million for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:mdna:71]
Our compensation and benefit expense in research and development increased from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. We continue to believe that investments in research and development are critical to our future growth and competitive position in the marketplace. As such, we expect to continue to spend on current and future product development efforts.

[0001628280-15-008828:mdna:72]
Sales and marketing expenses. Sales and marketing expenses increased by $3.2 million, or 29.5% in the three months ended September 30, 2015 compared to the three months ended September 30, 2014. Sales and marketing expenses were 2.7%

[0001628280-15-008828:mdna:73]
and 2.5% of net sales for the three months ended September 30, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $1.8 million in compensation and benefits resulting primarily from growth in sales and marketing personnel and an increase of $1.6 million in advertising, marketing promotional and trade show expenses.

[0001628280-15-008828:mdna:74]
Sales and marketing expenses include stock-based compensation expense of $0.4 million for both three months ended September 30, 2015 and 2014.

[0001628280-15-008828:mdna:75]
General and administrative expenses. General and administrative expenses increased by $3.1 million, or 62.2% in the three months ended September 30, 2015 compared to the three months ended September 30, 2014. General and administrative expenses were 1.6% and 1.1% of net sales for the three months ended September 30, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $2.7 million in compensation and benefits including stock-based compensation expense and an increase of $2.0 million in legal and audit expenses offset in part by an increase of $1.4 million in foreign currency transaction gain.

[0001628280-15-008828:mdna:76]
General and administrative expenses include stock-based compensation expense of $0.8 million and $0.5 million for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:mdna:77]
Interest and Other Expense, Net

[0001628280-15-008828:mdna:78]
Interest and other expense, net for the three months ended September 30, 2015 and 2014 are as follows (dollars in millions):

[0001628280-15-008828:mdna:79]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |
| Interest and other income, net | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | 148.6 | % |
| Interest expense | (0.3 | ) |  | (0.2 | ) |  | (0.1 | ) |  | 65.3 | % |
| Interest and other expense, net | $ | (0.2 | ) |  | $ | (0.2 | ) |  | $ | 0.1 |  |  | 47.2 | % |

[0001628280-15-008828:mdna:80]
Interest and other expense, net. Interest and other expense, net increased by $0.1 million in the three months ended September 30, 2015 compared to the three months ended September 30, 2014. The increases were primarily due to higher interest expense on debt.

[0001628280-15-008828:mdna:81]
Provision for Income Taxes

[0001628280-15-008828:mdna:82]
Provision for income taxes and effective tax rates for the three months ended September 30, 2015 and 2014 are as follows (dollars in millions):

[0001628280-15-008828:mdna:83]
|  | Three Months Ended September 30, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |
| Provision for income taxes | $ | 7.5 |  |  | $ | 10.6 |  |  | $ | (3.1 | ) |  | (29.2 | )% |
| Percentage of total net sales | 1.5 | % |  | 2.4 | % |  |  |  |  |
| Effective tax rate | 35.4 | % |  | 33.7 | % |  |  |  |  |

[0001628280-15-008828:mdna:84]
Provision for income taxes. Provision for income taxes decreased by $3.1 million, or 29.2% in the three months ended September 30, 2015 compared to the three months ended September 30, 2014. The effective tax rate was 35.4% and 33.7% for the three months ended September 30, 2015 and the three months ended September 30, 2014, respectively. The lower income tax provision for the three months ended September 30, 2015 was primarily attributable to our lower operating income. The effective tax rate for the three months ended September 30, 2015 was higher primarily due to lower benefit from disqualifying dispositions of  shares issued upon exercise of incentive stock options.

[0001628280-15-008828:mdna:85]
[same as prior period, unchanged from 0001628280-15-003900:mdna:79]

[0001628280-15-008828:mdna:86]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $111.0 million and $95.5 million

[0001628280-15-008828:mdna:87]
as of September 30, 2015 and June 30, 2015, respectively. Our cash in foreign locations was $37.3 million and $26.3 million at September 30, 2015 and June 30, 2015, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-15-008828:mdna:88]
Operating Activities. Net cash provided by operating activities was $20.3 million and $27.0 million for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:mdna:89]
Net cash provided by our operating activities for the three months ended September 30, 2015 was primarily due to a decrease in accounts receivable of $25.4 million, our net income of $13.7 million, an increase in other long-term liabilities of $8.9 million, stock-based compensation expense of $3.9 million, net income taxes payable of $3.0 million, depreciation expense of $2.8 million and an increase in provision for inventory of $1.7 million, which were partially offset by a decrease in accounts payable of $37.7 million and foreign exchange gain of $2.0 million.

[0001628280-15-008828:mdna:90]
Net cash provided by our operating activities for the three months ended September 30, 2014 was primarily due to our net income of $20.9 million, a decrease in accounts receivable of $18.4 million, an increase in net income taxes payable of $6.7 million, stock-based compensation expense of $3.0 million, an increase in accounts payable of $2.1 million, depreciation expense of $1.8 million, a decrease in prepaid expenses and other assets of $1.5 million, which were partially offset by an increase in inventory of $27.4 million and a decrease in accrued liabilities of $1.9 million.

[0001628280-15-008828:mdna:91]
The decrease for the three months ended September 30, 2015 in accounts receivable was primarily due to lower sales in the first quarter of fiscal year 2016 as compared to the fourth quarter of fiscal year 2015. The decrease for the three months ended September 30, 2015 in accounts payable was primarily due to lower purchases and lower sales in the three months ended September 30, 2015. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-15-008828:mdna:92]
The decrease for the three months ended September 30, 2014 in accounts receivable was primarily due to higher accounts receivable collection in the first quarter of fiscal year 2015 partially offset by an increase in our net sales late in the first quarter. The increase for the three months ended September 30, 2014 in inventory and accounts payable was primarily due to higher purchases to support the anticipated level of growth in our net sales in the second quarter of fiscal year 2015.

[0001628280-15-008828:mdna:93]
Investing activities. Net cash used in our investing activities was $7.7 million and $2.8 million for the three months ended September 30, 2015 and 2014, respectively. In the three months ended September 30, 2015, of the net cash used in our investing activities, $7.7 million was related to the purchase of property, plant and equipment, of which $2.8 million was related to the property and equipment of our first manufacturing building and warehouse at our Green Computing Park in San Jose, California, which was completed in August 2015. We plan to continue the development and construction of improvements to our properties through fiscal year 2017. We anticipate investing approximately $22.1 million through November 2016 to build the second manufacturing facility and remodel our office building. We plan to finance this development through our operating cash flows and additional borrowings from banks.

[0001628280-15-008828:mdna:94]
In the three months ended September 30, 2014, the $2.8 million net cash used in our investing activities was related to the purchase of property, plant and equipment.

[0001628280-15-008828:mdna:95]
Financing activities. Net cash provided by (used in) our financing activities was $2.6 million and $(3.3) million for the three months ended September 30, 2015 and 2014, respectively. In the three months ended September 30, 2015, we borrowed an additional $4.7 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $2.9 million in loans. Further, we received $1.0 million related to the proceeds from the exercise of stock options in the three months ended September 30, 2015.

[0001628280-15-008828:mdna:96]
In the three months ended September 30, 2014, we received $4.5 million related to the proceeds from the exercise of stock options. Further, we repaid $8.5 million in loans in the three months ended September 30, 2014.

[0001628280-15-008828:mdna:97]
In the three months ended September 30, 2015 and 2014, $0.1 million and $0.7 million was related to the excess tax benefits from stock-based compensation, respectively. We expect the net cash provided by financing activities will increase throughout fiscal year 2016 as we intend to obtain additional financing from banks for our working capital requirements.

[0001628280-15-008828:mdna:98]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing

[0001628280-15-008828:mdna:99]
activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-15-008828:mdna:100]
[same as prior period, unchanged from 0001628280-15-003900:mdna:91]

[0001628280-15-008828:mdna:101]
[same as prior period, unchanged from 0001628280-15-003900:mdna:92]

[0001628280-15-008828:mdna:102]
[same as prior period, unchanged from 0001628280-15-003900:mdna:93]

[0001628280-15-008828:mdna:103]
In June 2015, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility that matures on November 15, 2015 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In November 2015, we extended the revolving line of credit to mature on February 15, 2016, and we are currently negotiating with Bank of America to renew the revolving line of credit.

[0001628280-15-008828:mdna:104]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.20% at September 30, 2015. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-008828:mdna:105]
As of September 30, 2015 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan was $3.0 million and $3.7 million, respectively. The total outstanding borrowings under the Bank of America line of credit was $62.2 million and $59.7 million as of September 30, 2015 and June 30, 2015, respectively. The interest rates for these loans ranged from 0.8% to 1.70% per annum at September 30, 2015 and 0.79% to 1.68% per annum at June 30, 2015, respectively. As of September 30, 2015, the unused revolving line of credit under Bank of America was $2.8 million.

[0001628280-15-008828:mdna:106]
[same as prior period, unchanged from 0001628280-15-003900:mdna:99]

[0001628280-15-008828:mdna:107]
In December 2014, we entered into an amendment to our existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700.0 million or $22.0 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $30.2 million U.S. dollar equivalents.

[0001628280-15-008828:mdna:108]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19.9 million and $21.3 million as of September 30, 2015 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9.7 million in U.S. dollars at September 30, 2015 and June 30, 2015. The interest rate for these loans were ranged from 0.85% and 1.11% at September 30, 2015 and 0.82% and 1.16% per annum at June 30, 2015. At September 30, 2015, NT$19.1 million or $0.6 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-008828:mdna:109]
Covenant Compliance

[0001628280-15-008828:mdna:110]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-008828:mdna:111]
[same as prior period, unchanged from 0001628280-15-003900:mdna:106]

[0001628280-15-008828:mdna:112]
[same as prior period, unchanged from 0001628280-15-003900:mdna:107]

[0001628280-15-008828:mdna:113]
[same as prior period, unchanged from 0001628280-15-003900:mdna:108]

[0001628280-15-008828:mdna:114]
As of September 30, 2015, our total assets of $1,037.6 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of September 30, 2015, total assets collateralizing the term loan with Bank of America were $17.3 million. As of September 30, 2015, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001628280-15-008828:mdna:115]
As of September 30, 2015, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.1 million. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2015.

[0001628280-15-008828:mdna:116]
[same as prior period, unchanged from 0001628280-15-003900:mdna:111]

[0001628280-15-008828:mdna:117]
In the three months ended September 30, 2015, we paid our contract manufacturers within 36 to 73 days of invoice and Ablecom between 41 to 69 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of September 30, 2015 and June 30, 2015 amounts owed to Ablecom by us were approximately $55.9 million and $59.0 million, respectively.

[0001628280-15-008828:mdna:118]
[same as prior period, unchanged from 0001628280-15-003900:mdna:113]

[0001628280-15-008828:mdna:119]
As of September 30, 2015, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AA2 at September 30, 2015. These auction rate preferred shares have no stated maturity date.

[0001628280-15-008828:mdna:120]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2015, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at September 30, 2015, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three months ended September 30, 2015 and 2014, there was no auction rate securities redeemed or sold.

[0001628280-15-008828:mdna:121]
[same as prior period, unchanged from 0001628280-15-003900:mdna:116]

[0001628280-15-008828:mdna:122]
The following table describes our contractual obligations as of September 30, 2015:

[0001628280-15-008828:mdna:123]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,230 |  |  | $ | 5,783 |  |  | $ | 5,179 |  |  | $ | 2,715 |  |  | $ | 17,907 |  |
| Capital leases, including interest | 210 |  |  | 367 |  |  | 140 |  |  | — |  |  | 717 |  |
| Debt, including interest (1) | 94,605 |  |  | 233 |  |  | — |  |  | — |  |  | 94,838 |  |
| Purchase commitments (2) | 347,641 |  |  | 44,320 |  |  | — |  |  | — |  |  | 391,961 |  |
| Total (3) | $ | 446,686 |  |  | $ | 50,703 |  |  | $ | 5,319 |  |  | $ | 2,715 |  |  | $ | 505,423 |  |

[0001628280-15-008828:mdna:124]
[same as prior period, unchanged from 0001628280-15-003900:mdna:119]

[0001628280-15-008828:mdna:125]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at September 30, 2015. |

[0001628280-15-008828:mdna:126]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $201.6 million of hard disk drive purchase commitments at September 30, 2015, which will be paid through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-15-008828:mdna:127]
| (3) | The table above excludes liabilities for deferred revenue of $20.9 million and unrecognized tax benefits and related interest and penalties accrual of $11.2 million. We have not provided a detailed estimate of the payment timing of |

[0001628280-15-008828:mdna:128]
unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes.

[0001628280-15-008828:mdna:129]
[same as prior period, unchanged from 0001628280-15-003900:mdna:123]

[0001628280-15-008828:mdna:130]
[same as prior period, unchanged from 0001628280-15-003900:mdna:124]

[0001628280-15-008828:mdna:131]
[same as prior period, unchanged from 0001628280-15-003900:mdna:127]

[0001628280-15-008828:mdna:132]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued new accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The new standard clarified that an entity may defer and present debt issuing costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The new standard is effective for us on July 1, 2016. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-15-008828:mdna:133]
In July 2015, the FASB issued authoritative guidance related to inventory measurement. The new standard requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The new standard is effective for us on July 1, 2017. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-15-008828:mdna:134]
[same as prior period, unchanged from 0001628280-15-003900:mdna:129]

[0001628280-15-008828:mdna:135]
[same as prior period, unchanged from 0001628280-15-003900:mdna:130]
