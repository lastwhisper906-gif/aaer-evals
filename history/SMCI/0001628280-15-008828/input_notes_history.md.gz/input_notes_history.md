# SMCI note change history — 0001628280-15-003900 → 0001628280-15-008828


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:1]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.
  (was, 2015-05-07, similarity 0.983):
[0001628280-15-003900:note_history:1]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any such pending matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

- changed (2015-11-16):
[0001628280-15-008828:note_history:2]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of September 30, 2015, these remaining non-cancellable commitments were $391,961,000 compared to $378,341,000 as of June 30, 2015.
  (was, 2015-05-07, similarity 0.8283):
[0001628280-15-003900:note_history:2]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of March 31, 2015, these remaining non-cancellable commitments were $491,188,000 compared to $211,090,000 as of June 30, 2014.

- added (2015-11-16):
[0001628280-15-008828:note_history:3]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $201,583,000, which will be paid through December 2016. The Company has entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.

- removed (2015-11-16):
[0001628280-15-003900:note_history:4]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $237,389,000 as of March 31, 2015, an increase from $45,210,000 as of June 30, 2014 and will be paid through January 2017. The Company entered into amendments to its existing purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company negotiates the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.
  (was, 2015-05-07, similarity 0.7227):
[0001628280-15-003900:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2015 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.

- changed (2015-11-16):
[0001628280-15-008828:note_history:6]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.
  (was, 2015-05-07, similarity 0.9983):
[0001628280-15-003900:note_history:6]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.

- added (2015-11-16):
[0001628280-15-008828:note_history:7]
The Company's basic earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.

- added (2015-11-16):
[0001628280-15-008828:note_history:8]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued new accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The new standard clarified that an entity may defer and present debt issuing costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The new standard is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- added (2015-11-16):
[0001628280-15-008828:note_history:9]
In July 2015, the FASB issued authoritative guidance related to inventory measurement. The new standard requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The new standard is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- removed (2015-11-16):
[0001628280-15-003900:note_history:10]
The Company’s restricted share awards subject to repurchase and settled in shares of common stock upon vesting have the nonforfeitable right to receive dividends on an equal basis with common stock and therefore are considered participating securities that must be included in the calculation of net income per share using the two-class method. Under the two-class method, basic and diluted net income per common share is determined by calculating net income per share for common stock and participating securities based on participation rights in undistributed earnings. Diluted net income per common share is calculated by adjusting outstanding shares, assuming any dilutive effects of stock incentive awards calculated using the treasury stock method. Under the treasury stock method, an increase in the fair market value of our common stock results in a greater dilutive effect from outstanding stock options and restricted stock units. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.

- removed (2015-11-16):
[0001628280-15-003900:note_history:11]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

- removed (2015-11-16):
[0001628280-15-003900:note_history:12]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

- removed (2015-11-16):
[0001628280-15-003900:note_history:13]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The new standard is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:14]
Short-term and long-term obligations as of September 30, 2015 and June 30, 2015 consisted of the following (in thousands):
  (was, 2015-05-07, similarity 0.9545):
[0001628280-15-003900:note_history:14]
Short-term and long-term obligations as of March 31, 2015 and June 30, 2014 consisted of the following (in thousands):

- changed (2015-11-16):
[0001628280-15-008828:note_history:15]
|  | September 30, |  | June 30, |
|  | 2015 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 3,033 |  |  | 3,733 |  |
| CTBC Bank | 19,875 |  |  | 21,280 |  |
| Total building term loans | 22,908 |  |  | 25,013 |  |
| Total debt | 94,807 |  |  | 94,412 |  |
| Current portion | (94,574 | ) |  | (93,479 | ) |
| Long-term portion | $ | 233 |  |  | $ | 933 |  |
  (was, 2015-05-07, similarity 0.9643):
[0001628280-15-003900:note_history:15]
|  | March 31, 2015 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 11,199 |  |  | $ | 17,699 |  |
| CTBC Bank | 9,700 |  |  | — |  |
| Total line of credit | 20,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 4,433 |  |  | 6,533 |  |
| CTBC Bank | 21,137 |  |  | 22,055 |  |
| Total building term loans | 25,570 |  |  | 28,588 |  |
| Total debt | 46,469 |  |  | 46,287 |  |
| Current portion | (44,836 | ) |  | (42,554 | ) |
| Long-term portion | $ | 1,633 |  |  | $ | 3,733 |  |

- added (2015-11-16):
[0001628280-15-008828:note_history:16]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that matures on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In November 2015, the Company extended the revolving line of credit to mature on February 15, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.

- changed (2015-11-16):
[0001628280-15-008828:note_history:17]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.20% at September 30, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.
  (was, 2015-05-07, similarity 0.9836):
[0001628280-15-003900:note_history:17]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.17% at March 31, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- changed (2015-11-16):
[0001628280-15-008828:note_history:18]
As of September 30, 2015 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan was $3,033,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $62,199,000 and $59,699,000 as of September 30, 2015 and June 30, 2015, respectively. The interest rates for these loans ranged from 0.80% to 1.70% per annum at September 30, 2015 and from 0.79%  to 1.68% per annum at June 30, 2015, respectively. As of September 30, 2015, the unused revolving line of credit with Bank of America was $2,801,000.
  (was, 2015-05-07, similarity 0.7251):
[0001628280-15-003900:note_history:18]
As of March 31, 2015 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $4,433,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $11,199,000 and $17,699,000 as of March 31, 2015 and June 30, 2014, respectively. The interest rates for these loans ranged from 0.82% to 1.67% per annum at March 31, 2015 and 1.19%  to 1.65% per annum at June 30, 2014. As of March 31, 2015, the unused revolving line of credit with Bank of America was $28,801,000.

- changed (2015-11-16):
[0001628280-15-008828:note_history:19]
In December 2014, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,153,000 U.S. dollar equivalents.
  (was, 2015-05-07, similarity 0.9621):
[0001628280-15-003900:note_history:19]
In December 2014, the Company entered into a second amendment to the existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $31,453,000 U.S. dollar equivalents.

- added (2015-11-16):
[0001628280-15-008828:note_history:20]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19,875,000 and $21,280,000 at September 30, 2015 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9,700,000 in U.S. dollars at September 30, 2015 and June 30, 2015. The interest rate for this loan ranged from 0.85% and 1.11% at September 30, 2015 and 0.82% and 1.16% per annum at June 30, 2015. At September 30, 2015, NT$19,124,000 or $578,000 U.S. dollar equivalents were available for future borrowing under this credit agreement. The Company is currently negotiating with CTBC Bank to renew the credit agreement.

- changed (2015-11-16):
[0001628280-15-008828:note_history:21]
As of September 30, 2015 and June 30, 2015, total assets of $1,037,634,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of September 30, 2015 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,296,000 and $17,354,000. As of September 30, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.
  (was, 2015-05-07, similarity 0.7236):
[0001628280-15-003900:note_history:21]
As of March 31, 2015 and June 30, 2014, total assets of $916,396,000 and $751,396,000, respectively, collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan.  As of March 31, 2015 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,411,000 and $17,584,000, respectively. As of March 31, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

- added (2015-11-16):
[0001628280-15-008828:note_history:22]
As of September 30, 2015 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $27,057,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with China Trust Bank at September 30, 2015.

- removed (2015-11-16):
[0001628280-15-003900:note_history:23]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2015.

- removed (2015-11-16):
[0001628280-15-003900:note_history:24]
In April 2015, the Company drew an additional $10,000,000 from Bank of America line of credit with an interest rate at 1.43% per annum to support the Company's growth and expansion of its business.

- removed (2015-11-16):
[0001628280-15-003900:note_history:25]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollar or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollar or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

- removed (2015-11-16):
[0001628280-15-003900:note_history:26]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

- removed (2015-11-16):
[0001628280-15-003900:note_history:27]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,137,000 and $22,055,000 at March 31, 2015 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9,700,000 and $0 at March 31, 2015 and June 30, 2014, respectively. The interest rate for these loans were ranged from 0.81% to 1.15% at March 31, 2015 and 1.15% per annum at June 30, 2014. At March 31, 2015, NT$37,118,000 or $1,189,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

- removed (2015-11-16):
[0001628280-15-003900:note_history:28]
As of March 31, 2015 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,154,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2015.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:29]
As of September 30, 2015 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at September 30, 2015 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.
  (was, 2015-05-07, similarity 0.9146):
[0001628280-15-003900:note_history:29]
As of March 31, 2015 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at March 31, 2015 and June 30, 2014. These auction rate preferred shares have no stated maturity date.

- changed (2015-11-16):
[0001628280-15-008828:note_history:30]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2015 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.
  (was, 2015-05-07, similarity 0.9855):
[0001628280-15-003900:note_history:30]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2015 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.

- changed (2015-11-16):
[0001628280-15-008828:note_history:31]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of September 30, 2015 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of September 30, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.79%, 3 years and 0.40%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.
  (was, 2015-05-07, similarity 0.9922):
[0001628280-15-003900:note_history:31]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2015 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of March 31, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.82%, 3 years and 0.41%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

- changed (2015-11-16):
[0001628280-15-008828:note_history:32]
Based on this assessment of fair value, the Company determined that there was no recovery (loss) in fair value of its auction rate securities during the three months ended September 30, 2015 and 2014. There was a cumulative total decline of $117,000 as of September 30, 2015 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of September 30, 2015 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.
  (was, 2015-05-07, similarity 0.6463):
[0001628280-15-003900:note_history:32]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2015 and 2014. There was a cumulative total decline of $103,000 as of March 31, 2015 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of March 31, 2015 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

- changed (2015-11-16):
[0001628280-15-008828:note_history:33]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three months ended September 30, 2015 and 2014, there were no auction rate securities redeemed or sold.
  (was, 2015-05-07, similarity 0.95):
[0001628280-15-003900:note_history:33]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform a periodic impairment analysis. In the three and nine months ended March 31, 2015 and 2014, there were no auction rate securities redeemed or sold.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:34]
Short-term and long-term obligations as of September 30, 2015 and June 30, 2015 consisted of the following (in thousands):
  (was, 2015-05-07, similarity 0.9545):
[0001628280-15-003900:note_history:34]
Short-term and long-term obligations as of March 31, 2015 and June 30, 2014 consisted of the following (in thousands):

- changed (2015-11-16):
[0001628280-15-008828:note_history:35]
|  | September 30, |  | June 30, |
|  | 2015 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 3,033 |  |  | 3,733 |  |
| CTBC Bank | 19,875 |  |  | 21,280 |  |
| Total building term loans | 22,908 |  |  | 25,013 |  |
| Total debt | 94,807 |  |  | 94,412 |  |
| Current portion | (94,574 | ) |  | (93,479 | ) |
| Long-term portion | $ | 233 |  |  | $ | 933 |  |
  (was, 2015-05-07, similarity 0.9643):
[0001628280-15-003900:note_history:35]
|  | March 31, 2015 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 11,199 |  |  | $ | 17,699 |  |
| CTBC Bank | 9,700 |  |  | — |  |
| Total line of credit | 20,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 4,433 |  |  | 6,533 |  |
| CTBC Bank | 21,137 |  |  | 22,055 |  |
| Total building term loans | 25,570 |  |  | 28,588 |  |
| Total debt | 46,469 |  |  | 46,287 |  |
| Current portion | (44,836 | ) |  | (42,554 | ) |
| Long-term portion | $ | 1,633 |  |  | $ | 3,733 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-11-16):
[0001628280-15-008828:note_history:36]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at September 30, 2015.
  (was, 2015-05-07, similarity 0.9868):
[0001628280-15-003900:note_history:36]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 42.9% of Ablecom at March 31, 2015.

- changed (2015-11-16):
[0001628280-15-008828:note_history:37]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $59,261,000 and $54,403,000 and sold products to Ablecom totaling $5,220,000, $26,578,000 for the three months ended September 30, 2015 and 2014, respectively.
  (was, 2015-05-07, similarity 0.6642):
[0001628280-15-003900:note_history:37]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $58,002,000 and $169,918,000, and sold products to Ablecom totaling $6,067,000 and $43,524,000 for the three and nine months ended March 31, 2015, respectively. The Company purchased products from Ablecom totaling $45,398,000 and $145,139,000 and sold products to Ablecom totaling $3,418,000 and $10,805,000 for the three and nine months ended March 31, 2014, respectively.

- changed (2015-11-16):
[0001628280-15-008828:note_history:38]
Amounts owed to the Company by Ablecom as of September 30, 2015 and June 30, 2015 were $11,974,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2015 and June 30, 2015 were $55,886,000 and $59,015,000, respectively. For the three months ended September 30, 2015, the Company paid Ablecom the majority of invoiced dollars between 41 and 69 days of invoice date. For the three months ended September 30, 2015 and 2014, the Company paid $1,162,000 and $2,002,000 , respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2015-05-07, similarity 0.6951):
[0001628280-15-003900:note_history:38]
Amounts owed to the Company by Ablecom as of March 31, 2015 and June 30, 2014, were $4,602,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2015 and June 30, 2014, were $51,922,000 and $48,969,000, respectively. For the three and nine months ended March 31, 2015, the Company paid Ablecom the majority of invoiced dollars between 48 and 105 days of invoice date. For the three and nine months ended March 31, 2015, the Company paid $231,000 and $4,728,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2014, the Company paid $2,187,000 and $5,923,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2015-11-16):
[0001628280-15-008828:note_history:39]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $60,947,000 and $67,261,000 at September 30, 2015 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2015-05-07, similarity 0.9908):
[0001628280-15-003900:note_history:39]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $88,593,000 and $64,464,000 at March 31, 2015 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2015-11-16):
[0001628280-15-008828:note_history:40]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2015 and 2014, $2,000 and $3,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2015-05-07, similarity 0.861):
[0001628280-15-003900:note_history:40]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2015, $4,000 and $(3,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income  (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
