# SMCI notes — 0001628280-15-008828


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001628280-15-008828:notes:1]
Prior Period Adjustment Recorded in Current Quarter

[0001628280-15-008828:notes:2]
In November 2015, the Company identified errors related to revenue which was recognized prior to meeting US GAAP revenue recognition criteria which impacted fiscal years 2013, 2014 and 2015. The Company determined that certain contracts for extended warranties on products were recorded as revenue at the time of sale of the product in prior periods instead of being deferred and amortized over the contractual warranty period. The cumulative impact of this error pertaining to prior periods through June 30, 2015 was to overstate net sales and net income by $9,259,000 and $5,926,000, respectively. To compute the amount of the error, the Company determined a best estimated selling price for the extended warranty contracts based on prices charged to customers for these contracts when sold separately.  This error was corrected in the quarter ended September 30, 2015 by reducing net sales by $9,259,000 and net income by $5,926,000, respectively.

[0001628280-15-008828:notes:3]
The Company assessed the materiality of these errors on each of the fiscal years ended June 30, 2013, 2014 and 2015, and concluded that the errors were not material to any of these periods. The Company also concluded that recording an out-of-period correction would not be material to the three months ended September 30, 2015. Consequently, the accompanying condensed consolidated statement of operations for the three month period ended September 30, 2015 have been corrected.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-008828:notes:4]
Commitments and Contingencies

[0001628280-15-008828:notes:5]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-15-008828:notes:6]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of September 30, 2015, these remaining non-cancellable commitments were $391,961,000 compared to $378,341,000 as of June 30, 2015.

[0001628280-15-008828:notes:7]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $201,583,000, which will be paid through December 2016. The Company has entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-15-008828:notes:8]
[same as prior period, unchanged from 0001628280-15-003900:notes:5]

[0001628280-15-008828:notes:9]
[same as prior period, unchanged from 0001628280-15-003900:notes:6]

[0001628280-15-008828:notes:10]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (“SEC”) and include the accounts of the Company and its wholly-owned subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles have been condensed or omitted pursuant to such rules and regulations. These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015 included in its Annual Report on Form 10-K, as filed with the SEC (the “Annual Report”).

[0001628280-15-008828:notes:11]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.

[0001628280-15-008828:notes:12]
The Company consolidates its investment in Super Micro Asia Science and Technology Park, Inc. as it is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interest is presented as a separate component from the Company's equity in the equity section of the condensed consolidated balance sheets. Net income attributable to the noncontrolling interest is not presented separately in the condensed consolidated statements of operations and is included in the general and administrative expenses as the amount is not material for any of the fiscal periods presented.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-008828:notes:13]
Short-term and Long-term Obligations

[0001628280-15-008828:notes:14]
Short-term and long-term obligations as of September 30, 2015 and June 30, 2015 consisted of the following (in thousands):

[0001628280-15-008828:notes:15]
|  | September 30, |  | June 30, |
|  | 2015 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 3,033 |  |  | 3,733 |  |
| CTBC Bank | 19,875 |  |  | 21,280 |  |
| Total building term loans | 22,908 |  |  | 25,013 |  |
| Total debt | 94,807 |  |  | 94,412 |  |
| Current portion | (94,574 | ) |  | (93,479 | ) |
| Long-term portion | $ | 233 |  |  | $ | 933 |  |

[0001628280-15-008828:notes:16]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-15-008828:notes:17]
Bank of America

[0001628280-15-008828:notes:18]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that matures on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In November 2015, the Company extended the revolving line of credit to mature on February 15, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.

[0001628280-15-008828:notes:19]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.20% at September 30, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-008828:notes:20]
As of September 30, 2015 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan was $3,033,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $62,199,000 and $59,699,000 as of September 30, 2015 and June 30, 2015, respectively. The interest rates for these loans ranged from 0.80% to 1.70% per annum at September 30, 2015 and from 0.79%  to 1.68% per annum at June 30, 2015, respectively. As of September 30, 2015, the unused revolving line of credit with Bank of America was $2,801,000.

[0001628280-15-008828:notes:21]
CTBC Bank

[0001628280-15-008828:notes:22]
In December 2014, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,153,000 U.S. dollar equivalents.

[0001628280-15-008828:notes:23]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19,875,000 and $21,280,000 at September 30, 2015 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9,700,000 in U.S. dollars at September 30, 2015 and June 30, 2015. The interest rate for this loan ranged from 0.85% and 1.11% at September 30, 2015 and 0.82% and 1.16% per annum at June 30, 2015. At September 30, 2015, NT$19,124,000 or $578,000 U.S. dollar equivalents were available for future borrowing under this credit agreement. The Company is currently negotiating with CTBC Bank to renew the credit agreement.

[0001628280-15-008828:notes:24]
Covenant Compliance

[0001628280-15-008828:notes:25]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-008828:notes:26]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001628280-15-008828:notes:27]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001628280-15-008828:notes:28]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001628280-15-008828:notes:29]
As of September 30, 2015 and June 30, 2015, total assets of $1,037,634,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of September 30, 2015 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,296,000 and $17,354,000. As of September 30, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001628280-15-008828:notes:30]
As of September 30, 2015 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $27,057,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with China Trust Bank at September 30, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-008828:notes:31]
[same as prior period, unchanged from 0001628280-15-003900:notes:31]

[0001628280-15-008828:notes:32]
[same as prior period, unchanged from 0001628280-15-003900:notes:32]

[0001628280-15-008828:notes:33]
The authorized number of shares that may be issued under the Company's 2006 Equity Incentive Plan (the "2006 Plan") automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and restricted stock units vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of September 30, 2015, the Company had 1,731,305 authorized shares available for future issuance under the 2006 Plan.

[0001628280-15-008828:notes:34]
[same as prior period, unchanged from 0001628280-15-003900:notes:34]

[0001628280-15-008828:notes:35]
[same as prior period, unchanged from 0001628280-15-003900:notes:35]

[0001628280-15-008828:notes:36]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and the Company's historical experience.

[0001628280-15-008828:notes:37]
[same as prior period, unchanged from 0001628280-15-003900:notes:37]

[0001628280-15-008828:notes:38]
[same as prior period, unchanged from 0001628280-15-003900:notes:38]

[0001628280-15-008828:notes:39]
[same as prior period, unchanged from 0001628280-15-003900:notes:39]

[0001628280-15-008828:notes:40]
[same as prior period, unchanged from 0001628280-15-003900:notes:40]

[0001628280-15-008828:notes:41]
The fair value of stock option grants for the three months ended September 30, 2015 and 2014 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-15-008828:notes:42]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Risk-free interest rate | 1.57 | % |  | 1.76 | % |
| Expected life | 5.33 years |  |  | 5.44 years |  |
| Dividend yield | — | % |  | — | % |
| Volatility | 47.06 | % |  | 46.93 | % |
| Weighted-average fair value | $ | 11.64 |  |  | $ | 11.75 |  |

[0001628280-15-008828:notes:43]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2015 (in thousands):

[0001628280-15-008828:notes:44]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Cost of sales | $ | 240 |  |  | $ | 207 |  |
| Research and development | 2,402 |  |  | 1,896 |  |
| Sales and marketing | 404 |  |  | 365 |  |
| General and administrative | 830 |  |  | 512 |  |
| Stock-based compensation expense before taxes | 3,876 |  |  | 2,980 |  |
| Income tax impact | (285 | ) |  | (607 | ) |
| Stock-based compensation expense, net | $ | 3,591 |  |  | $ | 2,373 |  |

[0001628280-15-008828:notes:45]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $714,000 and $915,000 of excess tax benefits recorded in additional paid-in capital in the three months ended September 30, 2015 and 2014, respectively. The Company had excess tax benefits classified as cash from financing activities of $134,000 and $705,000 in the three months ended September 30, 2015 and 2014, respectively, for options issued since July 1, 2006.

[0001628280-15-008828:notes:46]
As of September 30, 2015, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted to employees and non-employee directors was $30,705,000, which will be recognized over a weighted-average vesting period of approximately 2.27 years.

[0001628280-15-008828:notes:47]
[same as prior period, unchanged from 0001628280-15-003900:notes:47]

[0001628280-15-008828:notes:48]
The following table summarizes stock option activity during the three months ended September 30, 2015 under all stock option plans:

[0001628280-15-008828:notes:49]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2015 (7,208,475 shares exercisable at weighted average exercise price of $12.24 per share) |  | 9,702,843 |  |  | $ | 14.21 |  |  |  |  |  |
| Granted (weighted average fair value of $11.64) |  | 58,650 |  |  | $ | 26.61 |  |  |  |  |  |
| Exercised |  | (136,163 | ) |  | $ | 6.99 |  |  |  |  |  |
| Forfeited |  | (10,240 | ) |  | $ | 20.28 |  |  |  |  |  |
| Balance as of September 30, 2015 |  | 9,615,090 |  |  | $ | 14.39 |  |  | 5.74 |  | $ | 126,048 |  |
| Options vested and expected to vest at September 30, 2015 |  | 9,487,502 |  |  | $ | 14.25 |  |  | 5.70 |  | $ | 125,461 |  |
| Options vested and exercisable at September 30, 2015 |  | 7,462,651 |  |  | $ | 12.61 |  |  | 4.99 |  | $ | 109,294 |  |

[0001628280-15-008828:notes:50]
The total pretax intrinsic value of options exercised during the three months ended September 30, 2015 and 2014 was $2,741,000 and $5,349,000, respectively.

[0001628280-15-008828:notes:51]
[same as prior period, unchanged from 0001628280-15-003900:notes:51]

[0001628280-15-008828:notes:52]
[same as prior period, unchanged from 0001628280-15-003900:notes:52]

[0001628280-15-008828:notes:53]
The following table summarizes restricted stock unit activity during the three months ended September 30, 2015 under the 2006 Plan:

[0001628280-15-008828:notes:54]
|  |  | Restricted Stock UnitsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2015 |  | 303,324 |  |  | $ | 36.02 |  |  |  |
| Granted |  | 154,870 |  |  | $ | 35.07 |  |  |  |
| Vested |  | (20,199 | ) |  | $ | 35.75 |  |  |  |
| Forfeited |  | (8,883 | ) |  | $ | 35.38 |  |  |  |
| Balance as of September 30, 2015 |  | 429,112 |  |  | $ | 35.70 |  |  | $ | 11,698 |  |

[0001628280-15-008828:notes:55]
The total pretax intrinsic value of restricted stock units vested was $547,000 for the three months ended September 30, 2015. In the three months ended September 30, 2015, upon vesting, 20,199 shares of restricted stock units were partially net share-settled such that the Company withheld 7,232 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock units on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $196,000 during the three months ended September 30, 2015 and are reflected as a financing activity within the condensed consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2006 Plan, shares withheld in connection with net-share settlements are returned to the 2006 Plan and are available for future grants under the 2006 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-15-008828:notes:56]
[same as prior period, unchanged from 0001628280-15-003900:notes:57]

[0001628280-15-008828:notes:57]
The Company's basic earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-008828:notes:58]
The following table shows the computation of basic and diluted net income per share for the three months ended September 30, 2015 and 2014 (in thousands, except per share amounts):

[0001628280-15-008828:notes:59]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Numerator: |  |  |  |
| Net income | $ | 13,699 |  |  | $ | 20,863 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 47,517 |  |  | 45,473 |  |
| Effect of dilutive securities | 3,835 |  |  | 4,214 |  |
| Weighted-average diluted shares | 51,352 |  |  | 49,687 |  |
| Basic net income per share | $ | 0.29 |  |  | $ | 0.46 |  |
| Diluted net income per share | $ | 0.27 |  |  | $ | 0.42 |  |

[0001628280-15-008828:notes:60]
For the three months ended September 30, 2015 and 2014, the Company had stock options and restricted stock units outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,248,000 and 1,135,000 for the three months ended September 30, 2015 and 2014, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-15-008828:notes:61]
The following table sets forth the Company’s cash equivalents and long-term investments as of September 30, 2015 and June 30, 2015 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-15-008828:notes:62]
| September 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,944 |  |
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,943 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-15-008828:notes:63]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three months ended September 30, 2015 and 2014 (in thousands):

[0001628280-15-008828:notes:64]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Balance as of beginning of period | $ | 2,633 |  |  | $ | 2,647 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |
| Balance as of end of period | $ | 2,633 |  |  | $ | 2,647 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-008828:notes:65]
[same as prior period, unchanged from 0001628280-15-003900:notes:66]

[0001628280-15-008828:notes:66]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of September 30, 2015 and June 30, 2015. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001628280-15-008828:notes:67]
The above table excludes $110,367,000 and $94,901,000 of cash and $1,104,000 and $1,130,000 of certificates of deposit held by the Company as of September 30, 2015 and June 30, 2015, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three months ended September 30, 2015 and 2014.

[0001628280-15-008828:notes:68]
The following is a summary of the Company’s long-term investments as of September 30, 2015 and June 30, 2015 (in thousands):

[0001628280-15-008828:notes:69]
|  | September 30, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |
|  | June 30, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |

[0001628280-15-008828:notes:70]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2015 and June 30, 2015, short-term and long-term debt of $94,807,000 and $94,412,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-008828:notes:71]
[same as prior period, unchanged from 0001628280-15-003900:notes:72]

[0001628280-15-008828:notes:72]
The Company recorded provisions for income taxes of $7,504,000 and $10,602,000 for the three months ended September 30, 2015 and 2014, respectively. The effective tax rate was 35.4% and 33.7% for the three months ended September 30, 2015 and 2014, respectively. The effective tax rate for the three months ended September 30, 2015 is estimated to be lower than the federal statutory rate primarily due to the impact of stock option expenses partially offset by the benefit from the domestic manufacturing activities deduction.

[0001628280-15-008828:notes:73]
As of September 30, 2015, the Company had a liability for gross unrecognized tax benefits of $15,769,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2015, there were no material changes in the total amount of the liability for gross unrecognized tax benefits.

[0001628280-15-008828:notes:74]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2015, the Company had accrued $1,124,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-15-008828:notes:75]
The Company is subject to U.S. federal income tax as well as income taxes in many state and foreign jurisdictions.  In August 2015, the Company scheduled a meeting with the Internal Revenue Service to commence a pre-examination of the federal income tax returns for tax years 2013 and 2014. The Company does not expect a resolution to be reached during the next twelve months. While management believes that the Company has adequately provided reserves for all uncertain tax positions, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. The federal statute of limitations remain open in general for tax years 2012 through 2015. The state statute of limitations remain open in general for tax years 2010 through 2015. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2008 through 2015. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-15-008828:notes:76]
Long-term Investments

[0001628280-15-008828:notes:77]
As of September 30, 2015 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at September 30, 2015 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.

[0001628280-15-008828:notes:78]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of September 30, 2015 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.

[0001628280-15-008828:notes:79]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of September 30, 2015 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of September 30, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.79%, 3 years and 0.40%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001628280-15-008828:notes:80]
Based on this assessment of fair value, the Company determined that there was no recovery (loss) in fair value of its auction rate securities during the three months ended September 30, 2015 and 2014. There was a cumulative total decline of $117,000 as of September 30, 2015 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of September 30, 2015 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001628280-15-008828:notes:81]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three months ended September 30, 2015 and 2014, there were no auction rate securities redeemed or sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-15-008828:notes:82]
Adoption of New Accounting Pronouncements

[0001628280-15-008828:notes:83]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-15-008828:notes:84]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued new accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The new standard clarified that an entity may defer and present debt issuing costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The new standard is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-15-008828:notes:85]
In July 2015, the FASB issued authoritative guidance related to inventory measurement. The new standard requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The new standard is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-15-008828:notes:86]
[same as prior period, unchanged from 0001628280-15-003900:notes:87]

[0001628280-15-008828:notes:87]
[same as prior period, unchanged from 0001628280-15-003900:notes:88]

[0001628280-15-008828:notes:88]
[same as prior period, unchanged from 0001628280-15-003900:notes:89]

[0001628280-15-008828:notes:89]
[same as prior period, unchanged from 0001628280-15-003900:notes:90]

[0001628280-15-008828:notes:90]
[same as prior period, unchanged from 0001628280-15-003900:notes:91]

[0001628280-15-008828:notes:91]
[same as prior period, unchanged from 0001628280-15-003900:notes:92]

[0001628280-15-008828:notes:92]
[same as prior period, unchanged from 0001628280-15-003900:notes:93]

[0001628280-15-008828:notes:93]
[same as prior period, unchanged from 0001628280-15-003900:notes:94]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-15-008828:notes:94]
[same as prior period, unchanged from 0001628280-15-003900:notes:95]

[0001628280-15-008828:notes:95]
|  | September 30, 2015 |  | June 30, 2015 |
| Land | $ | 70,454 |  |  | $ | 63,962 |  |
| Buildings | 71,665 |  |  | 51,959 |  |
| Building and leasehold improvements | 8,735 |  |  | 8,323 |  |
| Buildings and leasehold improvements construction in progress (1) | 2,574 |  |  | 25,572 |  |
| Machinery and equipment | 43,132 |  |  | 40,689 |  |
| Furniture and fixtures | 9,564 |  |  | 7,421 |  |
| Purchased software | 11,223 |  |  | 3,343 |  |
| Purchased software construction in progress (2) | 1,336 |  |  | 8,567 |  |
|  | 218,683 |  |  | 209,836 |  |
| Accumulated depreciation and amortization | (49,534 | ) |  | (46,798 | ) |
| Property, plant and equipment, net | $ | 169,149 |  |  | $ | 163,038 |  |

[0001628280-15-008828:notes:96]
(1) In connection with the purchase of the property located in San Jose, California, the Company engaged several contractors for the development and construction of improvements on the property, which was completed in August 2015. In the three months ended September 30, 2015, the Company also engaged a contractor for the construction of improvements on the leasehold property located in the Netherlands, which was completed in October 2015.

[0001628280-15-008828:notes:97]
(2) The Company completed its implementation of a new enterprise resource planning, or ERP, system for its U.S. headquarters on July 5, 2015 and has capitalized the costs of the new ERP software and certain expenses associated directly with the development of the ERP system as of July 4, 2015. The Company began to depreciate these costs in the three months ended September 30, 2015. In the three months ended September 30, 2015, the Company also started its implementation of the ERP system for its subsidiaries in Taiwan and the Netherlands and has capitalized the development costs of the ERP system, which is still in progress.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-15-008828:notes:98]
Related-party and Other Transactions

[0001628280-15-008828:notes:99]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at September 30, 2015.

[0001628280-15-008828:notes:100]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-15-008828:notes:101]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-15-008828:notes:102]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-15-008828:notes:103]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $59,261,000 and $54,403,000 and sold products to Ablecom totaling $5,220,000, $26,578,000 for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:notes:104]
Amounts owed to the Company by Ablecom as of September 30, 2015 and June 30, 2015 were $11,974,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2015 and June 30, 2015 were $55,886,000 and $59,015,000, respectively. For the three months ended September 30, 2015, the Company paid Ablecom the majority of invoiced dollars between 41 and 69 days of invoice date. For the three months ended September 30, 2015 and 2014, the Company paid $1,162,000 and $2,002,000 , respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-15-008828:notes:105]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $60,947,000 and $67,261,000 at September 30, 2015 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-15-008828:notes:106]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2015 and 2014, $2,000 and $3,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-15-008828:notes:107]
[same as prior period, unchanged from 0001628280-15-003900:notes:108]

[0001628280-15-008828:notes:108]
|  | September 30, 2015 |  | June 30, 2015 |
| Accrued payroll and related expenses | $ | 13,524 |  |  | $ | 15,141 |  |
| Customer deposits | 4,611 |  |  | 6,314 |  |
| Accrued warranty costs | 7,545 |  |  | 7,700 |  |
| Accrued cooperative marketing expenses | 6,465 |  |  | 5,690 |  |
| Deferred service revenue | 7,786 |  |  | 4,085 |  |
| Others | 10,238 |  |  | 7,813 |  |
| Total accrued liabilities | $ | 50,169 |  |  | $ | 46,743 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-15-008828:notes:109]
[same as prior period, unchanged from 0001628280-15-003900:notes:110]

[0001628280-15-008828:notes:110]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 356,211 |  |  | 68.6 | % |  | $ | 255,609 |  |  | 57.7 | % |
| Subsystems and accessories | 163,407 |  |  | 31.4 | % |  | 187,713 |  |  | 42.3 | % |
| Total | $ | 519,618 |  |  | 100.0 | % |  | $ | 443,322 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-15-008828:notes:111]
[same as prior period, unchanged from 0001628280-15-003900:notes:113]

[0001628280-15-008828:notes:112]
|  | September 30, 2015 |  | June 30, 2015 |
| Finished goods | $ | 374,045 |  |  | $ | 384,647 |  |
| Work in process | 42,290 |  |  | 23,214 |  |
| Purchased parts and raw materials | 45,036 |  |  | 55,632 |  |
| Total inventory | $ | 461,371 |  |  | $ | 463,493 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-15-008828:notes:113]
[same as prior period, unchanged from 0001628280-15-003900:notes:115]

[0001628280-15-008828:notes:114]
|  | September 30, 2015 |  | June 30, 2015 |
| Long-term deferred service costs | $ | 1,704 |  |  | $ | 1,490 |  |
| Prepaid royalty license | 935 |  |  | 997 |  |
| Investment in a privately held company | 1,411 |  |  | 1,411 |  |
| Restricted cash | 829 |  |  | 840 |  |
| Others | 1,268 |  |  | 488 |  |
| Total other assets | $ | 6,147 |  |  | $ | 5,226 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-15-008828:notes:115]
[same as prior period, unchanged from 0001628280-15-003900:notes:117]

[0001628280-15-008828:notes:116]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Balance, beginning of period | $ | 7,700 |  |  | $ | 7,083 |  |
| Provision for warranty | 3,866 |  |  | 3,656 |  |
| Costs charged to accrual | (3,819 | ) |  | (3,465 | ) |
| Change in estimated liability for pre-existing warranties | (202 | ) |  | (197 | ) |
| Balance, end of period | $ | 7,545 |  |  | $ | 7,077 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-15-008828:notes:117]
The following is a summary for the three months ended September 30, 2015 and 2014, of net sales by geographic region (in thousands):

[0001628280-15-008828:notes:118]
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Net sales: |  |  |  |
| United States | $ | 338,696 |  |  | $ | 243,378 |  |
| Europe | 86,826 |  |  | 89,557 |  |
| Asia | 74,657 |  |  | 88,438 |  |
| Other | 19,439 |  |  | 21,949 |  |
|  | $ | 519,618 |  |  | $ | 443,322 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-15-008828:notes:119]
[same as prior period, unchanged from 0001628280-15-003900:notes:121]

[0001628280-15-008828:notes:120]
|  | September 30, |  | June 30, |
|  | 2015 |  | 2015 |
| Long-lived assets: |  |  |  |
| United States | $ | 128,625 |  |  | $ | 124,292 |  |
| Asia | 37,859 |  |  | 37,695 |  |
| Europe | 2,665 |  |  | 1,051 |  |
|  | $ | 169,149 |  |  | $ | 163,038 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-008828:notes:121]
[same as prior period, unchanged from 0001628280-15-003900:notes:123]

[0001628280-15-008828:notes:122]
[same as prior period, unchanged from 0001628280-15-003900:notes:124]

[0001628280-15-008828:notes:123]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2015 and 2014, of net sales by geographic region (in thousands):

[0001628280-15-008828:notes:124]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories. One customer represented 12.2% of the Company's total net sales in the three months ended September 30, 2015 and no customer represented greater than 10% of the Company’s total net sales for the three months ended September 30, 2014. No country other than the United States represent greater than 10% of the Company’s total net sales in the three months ended September 30, 2015 and 2014. One customer represented 10.3% of the Company's accounts receivable as of September 30, 2015 and no customer accounted for 10% or more of the Company's accounts receivable as of June 30, 2015.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-008828:notes:125]
[same as prior period, unchanged from 0001628280-15-003900:notes:126]

[0001628280-15-008828:notes:126]
The following tables provide details of the selected balance sheet items (in thousands):

[0001628280-15-008828:notes:127]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $1,718,000, and $1,660,000 in the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-008828:notes:128]
[same as prior period, unchanged from 0001628280-15-003900:notes:128]
