# SMCI 8-K — 0001628280-15-007783 filed 2015-10-22

## item codes, every 8-K on or before 2015-11-16

- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2015-11-16

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-007783:8k_2_02:1]
EX-99.1
2
exhibit991q1-2016.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-15-007783:8k_2_02:2]
Exhibit

[0001628280-15-007783:8k_2_02:3]
Exhibit 99.1

[0001628280-15-007783:8k_2_02:4]
Super Micro Computer, Inc. Announces 1st Quarter 2016 Financial Results

[0001628280-15-007783:8k_2_02:5]
SAN JOSE, Calif., October 22, 2015 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced first quarter fiscal 2016 financial results for the quarter ended September 30, 2015. The final results are in line with the preliminary results announced by the Company on October 8, 2015.

[0001628280-15-007783:8k_2_02:6]
Fiscal 1st Quarter Highlights

[0001628280-15-007783:8k_2_02:7]
| • | Quarterly net sales of $530.2 million, down 7.6% from the fourth quarter of fiscal year 2015 and up 19.6% from the same quarter of last year. |

[0001628280-15-007783:8k_2_02:8]
| • | GAAP net income of $20.5 million, down 23.2% from the fourth quarter of fiscal year 2015 and down 1.8% from the same quarter of last year. |

[0001628280-15-007783:8k_2_02:9]
| • | GAAP gross margin was 15.6% in the first quarter of fiscal year 2016, the fourth quarter of fiscal year 2015 and the same quarter of last year. |

[0001628280-15-007783:8k_2_02:10]
| • | Server solutions accounted for 69.2% of net sales compared with 61.7% in the fourth quarter of fiscal year 2015 and 57.7% in the same quarter of last year. |

[0001628280-15-007783:8k_2_02:11]
Net sales for the first quarter ended September 30, 2015 totaled $530.2 million, down 7.6% from $573.6 million in the fourth quarter of fiscal year 2015. One customer accounted for 11.9% of net sales during the quarter ended September 30, 2015.

[0001628280-15-007783:8k_2_02:12]
GAAP net income for the first quarter of fiscal year 2016 was $20.5 million or $0.40 per diluted share, a decrease of 1.8% from net income of $20.9 million, or $0.42 per diluted share in the same period a year ago. Included in net income for the quarter is $3.9 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the first quarter was $23.4 million, or $0.45 per diluted share, compared to non-GAAP net income of $23.2 million, or $0.46 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income decreased from the fourth quarter of fiscal year 2015 by $6.6 million or $0.12 per diluted share.

[0001628280-15-007783:8k_2_02:13]
GAAP gross margin was 15.6% for the first quarter of fiscal year 2016, the fourth quarter of fiscal year 2015 and the same period a year ago. Non-GAAP gross margin was 15.7% for the first quarter of fiscal year 2016, the fourth quarter of fiscal year 2015 and the same period a year ago.

[0001628280-15-007783:8k_2_02:14]
The GAAP income tax provision was $11.3 million or 35.6% of income before tax provision compared to $10.6 million or 33.7% in the same period a year ago and $13.8 million or 34.1% in the fourth quarter of fiscal year 2015.

[0001628280-15-007783:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at September 30, 2015 were $113.6 million compared to $98.1 million at June 30, 2015. Free cash flow for the three months ended September 30, 2015 was $12.6 million, primarily due to an increase in the Company's cash provided by operating activities and partially offset by the cash used in the development and construction of improvements on the Company's property.

[0001628280-15-007783:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-15-007783:8k_2_02:17]
The Company expects net sales of $580 million to $630 million for the second quarter of fiscal year 2016 ending December 31, 2015. The Company expects non-GAAP earnings per diluted share of approximately $0.54 to $0.64 for the second quarter.

[0001628280-15-007783:8k_2_02:18]
“As previously disclosed, first quarter revenue was lower than expected due to stronger seasonal effects combined with customer push outs and weaker European and Asia business activity. Nonetheless, with 19.6% growth in a seasonally weak quarter, we are off to a strong start to fiscal 2016. Our growth strategy for 2016 will be to continue to introduce new technologies such as NVMe and all flash storage array to evolve and grow key business verticals in Storage, Cloud/Internet Datacenter, HPC, Embedded and Enterprise,” said Charles Liang, Chairman and Chief Executive Officer. “With our system management software, onsite service and system solution capacity are fully ready for the worldwide market, we expect to continue our strong growth with over 20% revenue growth for fiscal 2016”.

[0001628280-15-007783:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-15-007783:8k_2_02:20]
Conference Call Information

[0001628280-15-007783:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-401-4668 (International callers dial 1-719-325-2464) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, November 5, 2015, by dialing 1-877-870-5176 (International callers dial 1-858-384-5517) and entering replay PIN 9354543. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-15-007783:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-15-007783:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-15-007783:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-15-007783:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-15-007783:8k_2_02:26]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-15-007783:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-15-007783:8k_2_02:28]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001628280-15-007783:8k_2_02:29]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | September 30, |  | June 30, |
|  |  |  |  | 2015 |  | 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 110,894 |  |  | $ | 95,442 |  |
|  | Accounts receivable, net | 297,078 |  |  | 322,594 |  |
|  | Inventory |  | 461,371 |  |  | 463,493 |  |
|  | Deferred income taxes – current | 18,712 |  |  | 17,863 |  |
|  | Prepaid income taxes | 2,391 |  |  | 7,507 |  |
|  | Prepaid expenses and other current assets | 7,796 |  |  | 7,516 |  |
|  |  | Total current assets | 898,242 |  |  | 914,415 |  |
| Long-term investments | 2,633 |  |  | 2,633 |  |
| Property, plant and equipment, net | 169,149 |  |  | 163,038 |  |
| Deferred income taxes – noncurrent |  | 5,816 |  |  | 4,497 |  |
| Other assets |  |  | 6,147 |  |  | 5,226 |  |
|  |  | Total assets | $ | 1,081,987 |  |  | $ | 1,089,809 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 263,223 |  |  | $ | 299,774 |  |
|  | Accrued liabilities |  | 46,967 |  |  | 46,743 |  |
|  | Income taxes payable |  | 14,866 |  |  | 14,111 |  |
|  | Short-term debt and current portion of long-term debt | 94,574 |  |  | 93,479 |  |
|  |  | Total current liabilities | 419,630 |  |  | 454,107 |  |
| Long term debt-net of current portion | 233 |  |  | 933 |  |
| Other long-term liabilities | 17,215 |  |  | 15,684 |  |
|  |  | Total liabilities | 437,078 |  |  | 470,724 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 252,426 |  |  | 247,081 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (98 | ) |  | (80 | ) |
|  | Retained earnings |  | 394,444 |  |  | 373,950 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 644,742 |  |  | 618,921 |  |
|  | Noncontrolling interest | 167 |  |  | 164 |  |
|  |  | Total stockholders' equity | 644,909 |  |  | 619,085 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,081,987 |  |  | $ | 1,089,809 |  |

[0001628280-15-007783:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Net sales | $ | 530,235 |  |  | $ | 443,322 |  |
| Cost of sales | 447,403 |  |  | 374,129 |  |
| Gross profit | 82,832 |  |  | 69,193 |  |
| Operating expenses: |  |  |  |
| Research and development | 28,326 |  |  | 21,509 |  |
| Sales and marketing | 14,249 |  |  | 11,002 |  |
| General and administrative | 8,200 |  |  | 5,056 |  |
| Total operating expenses | 50,775 |  |  | 37,567 |  |
| Income from operations | 32,057 |  |  | 31,626 |  |
| Interest and other income, net | 87 |  |  | 35 |  |
| Interest expense | (324 | ) |  | (196 | ) |
| Income before income tax provision | 31,820 |  |  | 31,465 |  |
| Income tax provision | 11,326 |  |  | 10,602 |  |
| Net income | $ | 20,494 |  |  | $ | 20,863 |  |
| Net income per common share: |  |  |  |
| Basic | $ | 0.43 |  |  | $ | 0.46 |  |
| Diluted | $ | 0.40 |  |  | $ | 0.42 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |
| Basic (a) | 47,517 |  |  | 45,473 |  |
| Diluted (b) | 51,352 |  |  | 49,687 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Cost of sales | $ | 240 |  |  | $ | 207 |  |
| Research and development | 2,402 |  |  | 1,896 |  |
| Sales and marketing | 404 |  |  | 365 |  |
| General and administrative | 830 |  |  | 512 |  |

[0001628280-15-007783:8k_2_02:31]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Three Months EndedSeptember 30, |
|  | 2015 |  | 2014 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 20,494 |  |  | $ | 20,863 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 2,753 |  |  | 1,847 |  |
| Stock-based compensation expense | 3,876 |  |  | 2,980 |  |
| Excess tax benefits from stock-based compensation | (134 | ) |  | (705 | ) |
| Allowance for doubtful accounts | 98 |  |  | (54 | ) |
| Provision for inventory | 1,718 |  |  | 1,660 |  |
| Exchange gain | (2,007 | ) |  | (235 | ) |
| Deferred income taxes, net | (2,221 | ) |  | 973 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 25,418 |  |  | 18,422 |  |
| Inventory | 404 |  |  | (27,364 | ) |
| Prepaid expenses and other assets | (1,247 | ) |  | 1,547 |  |
| Accounts payable | (37,652 | ) |  | 2,131 |  |
| Income taxes payable, net | 6,787 |  |  | 6,726 |  |
| Accrued liabilities | 484 |  |  | (1,903 | ) |
| Other long-term liabilities | 1,535 |  |  | 158 |  |
| Net cash provided by operating activities | 20,306 |  |  | 27,046 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (7,662 | ) |  | (2,766 | ) |
| Restricted cash | (3 | ) |  | 10 |  |
| Net cash used in investing activities | (7,665 | ) |  | (2,756 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 4,700 |  |  | — |  |
| Repayment of debt | (2,900 | ) |  | (8,500 | ) |
| Proceeds from exercise of stock options | 951 |  |  | 4,485 |  |
| Excess tax benefits from stock-based compensation | 134 |  |  | 705 |  |
| Payment of obligations under capital leases | (39 | ) |  | (28 | ) |
| Payments under receivable financing arrangements | (37 | ) |  | (4 | ) |
| Minimum tax withholding paid on behalf of employees for restricted stock awards | (196 | ) |  | — |  |
| Net cash provided by (used in) financing activities | 2,613 |  |  | (3,342 | ) |
| Effect of exchange rate fluctuations on cash | 198 |  |  | (308 | ) |
| Net increase in cash and cash equivalents | 15,452 |  |  | 20,640 |  |
| Cash and cash equivalents at beginning of period | 95,442 |  |  | 96,872 |  |
| Cash and cash equivalents at end of period | 110,894 |  |  | 117,512 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 298 |  |  | 202 |  |
| Cash paid for taxes, net of refunds | 5,736 |  |  | 3,123 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 42 |  |  | 256 |  |
| Accrued costs for property, plant and equipment purchases | 5,735 |  |  | 2,976 |  |

[0001628280-15-007783:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2015 |  | 2014 |
| GAAP GROSS PROFIT | $ | 82,832 |  |  | $ | 69,193 |  |
|  | Add back stock-based compensation (a) | 240 |  |  | 207 |  |
| Non-GAAP GROSS PROFIT | $ | 83,072 |  |  | $ | 69,400 |  |
| GAAP GROSS MARGIN | 15.6 | % |  | 15.6 | % |
|  | Add back stock-based compensation (a) | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 15.7 | % |  | 15.7 | % |
| GAAP INCOME FROM OPERATIONS | $ | 32,057 |  |  | $ | 31,626 |  |
|  | Add back stock-based compensation (a) | 3,876 |  |  | 2,980 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 35,933 |  |  | $ | 34,606 |  |
| GAAP NET INCOME | $ | 20,494 |  |  | $ | 20,863 |  |
|  | Add back stock-based compensation (a) | 3,876 |  |  | 2,980 |  |
|  | Add back adjustments to tax provision (b) | (948 | ) |  | (658 | ) |
| Non-GAAP NET INCOME | $ | 23,422 |  |  | $ | 23,185 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.43 |  |  | $ | 0.46 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.06 |  |  | 0.05 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.49 |  |  | $ | 0.51 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.40 |  |  | $ | 0.42 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.05 |  |  | 0.04 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.45 |  |  | $ | 0.46 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |
|  | BASIC –GAAP | 47,517 |  |  | 45,473 |  |
|  | BASIC - Non-GAAP | 47,517 |  |  | 45,473 |  |
|  | DILUTED – GAAP | 51,352 |  |  | 49,687 |  |
|  | DILUTED - Non-GAAP | 52,042 |  |  | 50,305 |  |

[0001628280-15-007783:8k_2_02:33]
(a) Amortization of ASC Topic 718 stock-based compensation for the three months ended September 30, 2015 and 2014.

[0001628280-15-007783:8k_2_02:34]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 34.4% and 32.7% for the three months ended September 30, 2015 and 2014, respectively.

[0001628280-15-007783:8k_2_02:35]
SOURCE: Super Micro Computer, Inc.

[0001628280-15-007783:8k_2_02:36]
Super Micro Computer, Inc.

[0001628280-15-007783:8k_2_02:37]
Howard Hideshima, 408-503-8000

[0001628280-15-007783:8k_2_02:38]
SVP, Chief Financial Officer

[0001628280-15-007783:8k_2_02:39]
ir@supermicro.com

[0001628280-15-007783:8k_2_02:40]
or

[0001628280-15-007783:8k_2_02:41]
Perry G. Hayes

[0001628280-15-007783:8k_2_02:42]
SVP, Investor Relations

[0001628280-15-007783:8k_2_02:43]
ir@supermicro.com

[0001628280-15-007783:8k_2_02:44]
SMCI-F
