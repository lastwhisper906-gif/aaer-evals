# SMCI notes — 0001628280-16-020941


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-020941:notes:1]
Commitments and Contingencies

[0001628280-16-020941:notes:2]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-16-020941:notes:3]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of September 30, 2016, these remaining non-cancellable commitments were $354,796,000 compared to $334,010,000 as of June 30, 2016.

[0001628280-16-020941:notes:4]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $42,200,000, which will be paid through December 2016. The Company has entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-16-020941:notes:5]
[same as prior period, unchanged from 0001628280-16-015755:notes:8]

[0001628280-16-020941:notes:6]
[same as prior period, unchanged from 0001628280-16-015755:notes:9]

[0001628280-16-020941:notes:7]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (“SEC”) and include the accounts of the Company and its wholly-owned subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles have been condensed or omitted pursuant to such rules and regulations. These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016 included in its Annual Report on Form 10-K, as filed with the SEC (the “Annual Report”).

[0001628280-16-020941:notes:8]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.

[0001628280-16-020941:notes:9]
[same as prior period, unchanged from 0001628280-16-015755:notes:12]


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-020941:notes:10]
Short-term and Long-term Debt Obligations

[0001628280-16-020941:notes:11]
Short-term and long-term obligations as of September 30, 2016 and June 30, 2016 consisted of the following (in thousands):

[0001628280-16-020941:notes:12]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 11,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 18,800 |  |  | 10,100 |  |
| Total line of credit | 29,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America (1) | 47,500 |  |  | 933 |  |
| CTBC Bank | 21,061 |  |  | 20,357 |  |
| Total term loans | 68,561 |  |  | 21,290 |  |
| Total debt | 98,560 |  |  | 93,589 |  |
| Less: debt issuance costs | (365 | ) |  | — |  |
| Total debt, net of debt issuance costs | 98,195 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (60,983 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 37,212 |  |  | $ | 40,000 |  |

[0001628280-16-020941:notes:13]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan at September 30, 2016 and June 30, 2016.

[0001628280-16-020941:notes:14]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-16-020941:notes:15]
Bank of America

[0001628280-16-020941:notes:16]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The Company extended the revolving line of credit to mature on June 30, 2016.

[0001628280-16-020941:notes:17]
In June 2016, the Company entered into a new credit agreement with Bank of America, which provided for (i) a $55,000,000 revolving line of credit facility including a $5,000,000 letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50,000,000 term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-16-020941:notes:18]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.52% at September 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, the Company received $50,000,000 term loan proceeds from Bank of America under the new credit agreement with an interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America.

[0001628280-16-020941:notes:19]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10,000,000 for the Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds.

[0001628280-16-020941:notes:20]
As of September 30, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $47,500,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $11,199,000 and $62,199,000 as of September 30, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.08% to 1.77% per annum at September 30, 2016 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of September 30, 2016, the amount of the unused revolving lines of credit with Bank of America under the new credit agreements was $53,801,000.

[0001628280-16-020941:notes:21]
In October 2016, the Company drew an additional $30,000,000 from Bank of America revolving line of credit with interest rates ranging from 2.14% to 3.75% per annum to support the Company's growth and expansion of its business in the Netherlands.

[0001628280-16-020941:notes:22]
CTBC Bank

[0001628280-16-020941:notes:23]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NTD$1,000,000,000 or $30,340,000 U.S. dollar equivalent. In January 2016, the Company extended the revolving line of credit to mature on March 31, 2016.

[0001628280-16-020941:notes:24]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

[0001628280-16-020941:notes:25]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,061,000 and $20,357,000 at September 30, 2016 and June 30, 2016, respectively. At September 30, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $18,800,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.89% and 1.40% at September 30, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At September 30, 2016, available for future borrowing under this credit agreement was $139,000.

[0001628280-16-020941:notes:26]
Covenant Compliance

[0001628280-16-020941:notes:27]
The new credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The new credit agreement contains certain financial covenants, including the following:

[0001628280-16-020941:notes:28]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001628280-16-020941:notes:29]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; |

[0001628280-16-020941:notes:30]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $30,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-16-020941:notes:31]
As of September 30, 2016 and June 30, 2016, total assets of $959,924,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of September 30, 2016 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the new credit agreement were $82,006,000 and $59,258,000, respectively. As of September 30, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

[0001628280-16-020941:notes:32]
As of September 30, 2016 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,691,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-020941:notes:33]
[same as prior period, unchanged from 0001628280-16-015755:notes:32]

[0001628280-16-020941:notes:34]
Share Repurchase Program

[0001628280-16-020941:notes:35]
In July 2016, the Company’s Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of the Company’s common stock in the open market or in private transactions during the next twelve months at prevailing market prices. Repurchases will be made under the program using the Company’s own cash resources. This share repurchase program does not obligate the Company to acquire any particular amount of common stock, and it may be suspended at any time at the Company’s discretion. During the three months ended September 30, 2016, the Company purchased 888,097 shares of the Company's common stock in the open market at a weighted average price of $20.79 for $18,461,000.

[0001628280-16-020941:notes:36]
[same as prior period, unchanged from 0001628280-16-015755:notes:33]

[0001628280-16-020941:notes:37]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other share-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of such date, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006" Plan). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan but that are forfeited in the future will become available for use under the 2016 Plan. In addition, 1,153,412 shares of common stock originally reserved for issuance under the 2006 Plan were cancelled upon the adoption of the 2016 Plan. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of September 30, 2016, the Company had 3,884,570 shares available for future issuance under the 2016 Plan.

[0001628280-16-020941:notes:38]
[same as prior period, unchanged from 0001628280-16-015755:notes:35]

[0001628280-16-020941:notes:39]
The Company's fair value of RSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-16-020941:notes:40]
Expected Term—The Company’s expected term represents the period that the Company’s share-based awards are expected to be outstanding and was determined based on a combination of the Company's peer group and the Company's historical experience.

[0001628280-16-020941:notes:41]
[same as prior period, unchanged from 0001628280-16-015755:notes:38]

[0001628280-16-020941:notes:42]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001628280-16-020941:notes:43]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001628280-16-020941:notes:44]
[same as prior period, unchanged from 0001628280-16-015755:notes:41]

[0001628280-16-020941:notes:45]
The fair value of stock option grants for the three months ended September 30, 2016 and 2015 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-16-020941:notes:46]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Risk-free interest rate | 1.12 | % |  | 1.57 | % |
| Expected term | 5.38 years |  |  | 5.33 years |  |
| Dividend yield | — | % |  | — | % |
| Volatility | 49.64 | % |  | 47.06 | % |
| Weighted-average fair value | $ | 9.29 |  |  | $ | 11.64 |  |

[0001628280-16-020941:notes:47]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2016 and 2015 (in thousands):

[0001628280-16-020941:notes:48]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Cost of sales | $ | 309 |  |  | $ | 240 |  |
| Research and development | 2,908 |  |  | 2,402 |  |
| Sales and marketing | 478 |  |  | 404 |  |
| General and administrative | 809 |  |  | 830 |  |
| Stock-based compensation expense before taxes | 4,504 |  |  | 3,876 |  |
| Income tax impact | (1,286 | ) |  | (285 | ) |
| Stock-based compensation expense, net | $ | 3,218 |  |  | $ | 3,591 |  |

[0001628280-16-020941:notes:49]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options and vesting of RSUs in excess of the compensation expense recorded for those share-based awards (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $32,000 of shortfalls recorded in additional paid-in capital in the three months ended September 30, 2016, and the Company had $714,000 of excess tax benefits recorded in additional paid-in capital in the three months ended September 30, 2015. The Company had excess tax benefits classified as cash provided by financing activities of $302,000 and $134,000 in the three months ended September 30, 2016 and 2015, respectively, for share-based awards issued since July 1, 2006.

[0001628280-16-020941:notes:50]
As of September 30, 2016, the Company’s total unrecognized compensation cost related to non-vested share-based awards granted to employees and non-employee directors was $37,947,000, which will be recognized over a weighted-average vesting period of approximately 2.34 years.

[0001628280-16-020941:notes:51]
[same as prior period, unchanged from 0001628280-16-015755:notes:48]

[0001628280-16-020941:notes:52]
The following table summarizes stock option activity during the three months ended September 30, 2016 under all plans:

[0001628280-16-020941:notes:53]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2016 (7,495,131 shares exercisable at weighted average exercise price of $13.35 per share) |  | 8,960,867 |  |  | $ | 14.88 |  |  |  |  |  |
| Granted (weighted average fair value of $9.29) |  | 127,620 |  |  | $ | 20.54 |  |  |  |  |  |
| Exercised |  | (257,453 | ) |  | $ | 11.41 |  |  |  |  |  |
| Forfeited |  | (12,854 | ) |  | $ | 19.78 |  |  |  |  |  |
| Balance as of September 30, 2016 |  | 8,818,180 |  |  | $ | 15.06 |  |  | 5.09 |  | $ | 79,505 |  |
| Options vested and expected to vest at September 30, 2016 |  | 8,744,510 |  |  | $ | 14.97 |  |  | 5.06 |  | $ | 79,405 |  |
| Options vested and exercisable at September 30, 2016 |  | 7,494,049 |  |  | $ | 13.62 |  |  | 4.55 |  | $ | 75,717 |  |

[0001628280-16-020941:notes:54]
The total pretax intrinsic value of options exercised was $2,652,000 and $2,741,000 during the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:notes:55]
RSU Activity

[0001628280-16-020941:notes:56]
The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting and settlement.

[0001628280-16-020941:notes:57]
The following table summarizes RSUs activity during the three months ended September 30, 2016 under all plans:

[0001628280-16-020941:notes:58]
|  | RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2016 | 926,983 |  |  | $ | 30.23 |  |  |  |
| Granted | 214,370 |  |  | $ | 20.54 |  |  |  |
| Released | (86,445 | ) |  | $ | 28.36 |  |  |  |
| Forfeited | (29,831 | ) |  | $ | 28.43 |  |  |  |
| Balance as of September 30, 2016 | 1,025,077 |  |  | $ | 28.41 |  |  | $ | 23,956 |  |

[0001628280-16-020941:notes:59]
The total pretax intrinsic value of RSUs vested was $1,852,000 and $547,000 for the three months ended September 30, 2016 and 2015, respectively. In the three months ended September 30, 2016 and 2015, upon vesting, 86,445 and 20,199 shares of RSUs were partially net share-settled such that the Company withheld 30,799 and 7,232 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities, respectively. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $660,000 and 196,000 during the three months ended September 30, 2016 and 2015, respectively, and are reflected as a financing activity within the condensed consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-16-020941:notes:60]
[same as prior period, unchanged from 0001628280-16-015755:notes:57]

[0001628280-16-020941:notes:61]
The Company's basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units (“RSUs”). Under the treasury stock method, an increase in the fair market value of the Company’s common stock results in a greater dilutive effect from outstanding stock options and RSUs. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-020941:notes:62]
Net Income Per Share

[0001628280-16-020941:notes:63]
The following table shows the computation of basic and diluted net income per share for the three months ended September 30, 2016 and 2015 (in thousands, except per share amounts):

[0001628280-16-020941:notes:64]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Numerator: |  |  |  |
| Net income | $ | 13,532 |  |  | $ | 13,699 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 48,165 |  |  | 47,517 |  |
| Effect of dilutive securities | 2,955 |  |  | 3,835 |  |
| Weighted-average diluted shares | 51,120 |  |  | 51,352 |  |
| Basic net income per share | $ | 0.28 |  |  | $ | 0.29 |  |
| Diluted net income per share | $ | 0.26 |  |  | $ | 0.27 |  |

[0001628280-16-020941:notes:65]
For the three months ended September 30, 2016 and 2015, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding share-based awards were 1,976,000 and 1,248,000 for the three months ended September 30, 2016 and 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-16-020941:notes:66]
The following table sets forth the Company’s cash equivalents and long-term investments as of September 30, 2016 and June 30, 2016 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-16-020941:notes:67]
| September 30, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 312 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total | $ | 312 |  |  | $ | — |  |  | $ | 2,643 |  |  | $ | 2,955 |  |
| June 30, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 315 |  |  | $ | — |  |  | $ | — |  |  | $ | 315 |  |
| Auction rate securities | — |  |  | — |  |  | 2,643 |  |  | 2,643 |  |
| Total | $ | 315 |  |  | $ | — |  |  | $ | 2,643 |  |  | $ | 2,958 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-16-020941:notes:68]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three months ended September 30, 2016 and 2015 (in thousands):

[0001628280-16-020941:notes:69]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Balance as of beginning of period | $ | 2,643 |  |  | $ | 2,633 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |
| Balance as of end of period | $ | 2,643 |  |  | $ | 2,633 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-020941:notes:70]
[same as prior period, unchanged from 0001628280-16-015755:notes:66]

[0001628280-16-020941:notes:71]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs as of September 30, 2016 and June 30, 2016. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of September 30, 2016 and June 30, 2016. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001628280-16-020941:notes:72]
The above table excludes $146,153,000 and $180,426,000 of cash and $2,054,000 and $2,133,000 of certificates of deposit held by the Company as of September 30, 2016 and June 30, 2016, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three months ended September 30, 2016 and 2015.

[0001628280-16-020941:notes:73]
The following is a summary of the Company’s long-term investments as of September 30, 2016 and June 30, 2016 (in thousands):

[0001628280-16-020941:notes:74]
|  | September 30, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |
|  | June 30, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (107 | ) |  | $ | 2,643 |  |

[0001628280-16-020941:notes:75]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2016 and June 30, 2016, short-term and long-term debt of $98,195,000 and $93,589,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-020941:notes:76]
[same as prior period, unchanged from 0001628280-16-015755:notes:72]

[0001628280-16-020941:notes:77]
The Company recorded provisions for income taxes of $6,369,000 and $7,504,000 for the three months ended September 30, 2016 and 2015, respectively. The effective tax rate was 32.0% and 35.4% for the three months ended September 30, 2016 and 2015, respectively. The effective tax rate for the three months ended September 30, 2016 is estimated to be lower than the federal statutory rate primarily due to the benefit from U.S. federal research and development ("R&D") tax credit and

[0001628280-16-020941:notes:78]
domestic production activities deduction.

[0001628280-16-020941:notes:79]
As of September 30, 2016, the Company had a liability for gross unrecognized tax benefits of $17,080,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2016, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2016, the Company had accrued $1,524,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-16-020941:notes:80]
The Company is subject to United States federal income tax as well as income taxes in many state and foreign jurisdictions. The Company's 2012 and 2013 federal tax returns are currently under the IRS examination. The Company has responded to Information Document Requests ("IDRs"), issued by the Internal Revenue Service ("IRS"). No adjustment has been proposed by the IRS as of September 30, 2016. The Company is also currently under audit in Taiwan. The Taiwan Tax Authority issued income tax assessments for tax years 2013 and 2014 related to the local income tax exemption regime which the Company has participated in. The Company is currently in the process of appealing the assessments. While management believes that the Company has adequately provided reserves for all uncertain tax positions, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001628280-16-020941:notes:81]
The federal statute of limitations remain open in general for tax years 2012 through 2015. The state statute of limitations remain open in general for tax years 2011 through 2015. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2009 through 2015. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-020941:notes:82]
Recently Issued Accounting Pronouncements

[0001628280-16-020941:notes:83]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectibility and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-020941:notes:84]
In April 2015, the FASB issued an amendment to the accounting guidance, Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance, Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements. This amendment clarifies that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company adopted these amendments in the first quarter of fiscal year 2017. There was no material impact on its financial statement disclosures, results of operations and financial position.

[0001628280-16-020941:notes:85]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the amendment to the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-020941:notes:86]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-020941:notes:87]
In March 2016, the FASB issued new accounting guidance, Compensation—Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-020941:notes:88]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. This amendment is effective for the Company on July 1, 2019. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-16-020941:notes:89]
[same as prior period, unchanged from 0001628280-16-015755:notes:90]

[0001628280-16-020941:notes:90]
[same as prior period, unchanged from 0001628280-16-015755:notes:91]

[0001628280-16-020941:notes:91]
[same as prior period, unchanged from 0001628280-16-015755:notes:92]

[0001628280-16-020941:notes:92]
[same as prior period, unchanged from 0001628280-16-015755:notes:93]

[0001628280-16-020941:notes:93]
[same as prior period, unchanged from 0001628280-16-015755:notes:94]

[0001628280-16-020941:notes:94]
[same as prior period, unchanged from 0001628280-16-015755:notes:95]

[0001628280-16-020941:notes:95]
[same as prior period, unchanged from 0001628280-16-015755:notes:96]

[0001628280-16-020941:notes:96]
[same as prior period, unchanged from 0001628280-16-015755:notes:97]


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001628280-16-020941:notes:97]
Other Long-term Liabilities:

[0001628280-16-020941:notes:98]
|  | September 30, 2016 |  | June 30, 2016 |
| Deferred revenue-net of current portion (1) | $ | 25,028 |  |  | $ | 21,940 |  |
| Accrued unrecognized tax benefits including related interests and penalties-net of current portion | 17,080 |  |  | 16,056 |  |
| Accrued warranty costs-net of current portion | 1,326 |  |  | 1,313 |  |
| Others | 1,227 |  |  | 1,294 |  |
| Total other long-term liabilities | $ | 44,661 |  |  | $ | 40,603 |  |

[0001628280-16-020941:notes:99]
(1) As of September 30, 2016 and June 30, 2016, deferred revenue-net of current portion consist primarily of a deferred extended warranty and on-site service revenue of $23,717,000 and $21,265,000, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-16-020941:notes:100]
[same as prior period, unchanged from 0001628280-16-015755:notes:98]

[0001628280-16-020941:notes:101]
|  | September 30, 2016 |  | June 30, 2016 |
| Land | $ | 70,457 |  |  | $ | 70,454 |  |
| Buildings | 71,665 |  |  | 71,665 |  |
| Building and leasehold improvements | 10,874 |  |  | 10,941 |  |
| Buildings construction in progress (1) | 19,834 |  |  | 15,803 |  |
| Machinery and equipment | 54,699 |  |  | 53,282 |  |
| Furniture and fixtures | 11,355 |  |  | 10,364 |  |
| Purchased software | 14,001 |  |  | 13,920 |  |
| Purchased software construction in progress | 450 |  |  | 532 |  |
|  | 253,335 |  |  | 246,961 |  |
| Accumulated depreciation and amortization | (62,487 | ) |  | (59,012 | ) |
| Property, plant and equipment, net | $ | 190,848 |  |  | $ | 187,949 |  |

[0001628280-16-020941:notes:102]
(1) In connection with the purchase of property located in San Jose, California for the Company's Green Computing Park, the Company continues to engage several contractors for the development and construction of improvements on the property.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-020941:notes:103]
Related-party and Other Transactions

[0001628280-16-020941:notes:104]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at September 30, 2016.

[0001628280-16-020941:notes:105]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-16-020941:notes:106]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-16-020941:notes:107]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-16-020941:notes:108]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $50,205,000 and $59,261,000, and sold products to Ablecom totaling $3,342,000 and $5,220,000 for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:notes:109]
Amounts owed to the Company by Ablecom as of September 30, 2016 and June 30, 2016 were $7,251,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2016 and June 30, 2016 were $38,290,000 and $39,152,000, respectively. For the three months ended September 30, 2016, the Company paid Ablecom the majority of invoiced dollars between 47 and 77 days of invoice date. For the three months ended September 30, 2016 and 2015, the Company paid $1,745,000 and $1,162,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-16-020941:notes:110]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $77,369,000 and $62,782,000 at September 30, 2016 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-16-020941:notes:111]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2016 and 2015, $5,000 and $2,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-16-020941:notes:112]
[same as prior period, unchanged from 0001628280-16-015755:notes:111]

[0001628280-16-020941:notes:113]
|  | September 30, 2016 |  | June 30, 2016 |
| Accrued payroll and related expenses | $ | 16,252 |  |  | $ | 16,015 |  |
| Customer deposits | 7,385 |  |  | 6,265 |  |
| Accrued warranty costs | 5,600 |  |  | 5,816 |  |
| Accrued cooperative marketing expenses | 7,399 |  |  | 7,300 |  |
| Deferred revenue (1) | 16,462 |  |  | 13,418 |  |
| Others | 7,745 |  |  | 6,804 |  |
| Total accrued liabilities | $ | 60,843 |  |  | $ | 55,618 |  |

[0001628280-16-020941:notes:114]
(1) As of September 30, 2016 and June 30, 2016, deferred revenue consist primarily of a deferred extended warranty and on-site service revenue of $15,160,000 and $12,746,000, respectively.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-16-020941:notes:115]
[same as prior period, unchanged from 0001628280-16-015755:notes:113]

[0001628280-16-020941:notes:116]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 357,493 |  |  | 67.6 | % |  | $ | 356,211 |  |  | 68.6 | % |
| Subsystems and accessories | 171,475 |  |  | 32.4 | % |  | 163,407 |  |  | 31.4 | % |
| Total | $ | 528,968 |  |  | 100.0 | % |  | $ | 519,618 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-16-020941:notes:117]
[same as prior period, unchanged from 0001628280-16-015755:notes:115]

[0001628280-16-020941:notes:118]
|  | September 30, 2016 |  | June 30, 2016 |
| Finished goods | $ | 366,251 |  |  | $ | 351,209 |  |
| Work in process | 51,333 |  |  | 19,105 |  |
| Purchased parts and raw materials | 82,403 |  |  | 78,666 |  |
| Total inventory | $ | 499,987 |  |  | $ | 448,980 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-16-020941:notes:119]
[same as prior period, unchanged from 0001628280-16-015755:notes:117]

[0001628280-16-020941:notes:120]
|  | September 30, 2016 |  | June 30, 2016 |
| Long-term deferred service costs | $ | 3,604 |  |  | $ | 3,498 |  |
| Restricted cash | 1,764 |  |  | 1,851 |  |
| Investment in a privately held company | 1,411 |  |  | 1,411 |  |
| Deposits | 472 |  |  | 910 |  |
| Prepaid royalty license | 685 |  |  | 748 |  |
| Others | $ | 117 |  |  | $ | 128 |  |
| Total other assets | $ | 8,053 |  |  | $ | 8,546 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-16-020941:notes:121]
[same as prior period, unchanged from 0001628280-16-015755:notes:119]

[0001628280-16-020941:notes:122]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Balance, beginning of period | $ | 7,129 |  |  | $ | 7,700 |  |
| Provision for warranty | 4,926 |  |  | 3,866 |  |
| Costs charged to accrual | (4,808 | ) |  | (3,819 | ) |
| Change in estimated liability for pre-existing warranties | (321 | ) |  | (202 | ) |
| Balance, end of period | 6,926 |  |  | 7,545 |  |
| Current portion | (5,600 | ) |  | (7,545 | ) |
| Long-term portion | $ | 1,326 |  |  | $ | — |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-020941:notes:123]
The following is a summary for the three months ended September 30, 2016 and 2015, of net sales by geographic region (in thousands):

[0001628280-16-020941:notes:124]
|  | Three Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Net sales: |  |  |  |
| United States | $ | 295,531 |  |  | $ | 338,696 |  |
| Europe | 113,711 |  |  | 86,826 |  |
| Asia | 96,280 |  |  | 74,657 |  |
| Other | 23,446 |  |  | 19,439 |  |
|  | $ | 528,968 |  |  | $ | 519,618 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-16-020941:notes:125]
[same as prior period, unchanged from 0001628280-16-015755:notes:123]

[0001628280-16-020941:notes:126]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Long-lived assets: |  |  |  |
| United States | $ | 146,379 |  |  | $ | 142,764 |  |
| Asia | 41,533 |  |  | 42,052 |  |
| Europe | 2,936 |  |  | 3,133 |  |
|  | $ | 190,848 |  |  | $ | 187,949 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-020941:notes:127]
[same as prior period, unchanged from 0001628280-16-015755:notes:125]

[0001628280-16-020941:notes:128]
[same as prior period, unchanged from 0001628280-16-015755:notes:126]

[0001628280-16-020941:notes:129]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2016 and 2015, of net sales by geographic region (in thousands):

[0001628280-16-020941:notes:130]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories. No customer represented greater than 10% of the Company's total net sales in the three months ended September 30, 2016 and one customer represented 12.2% of the Company's total net sales in the three months ended September 30, 2015. No country other than the United States represented greater than 10% of the Company’s total net sales in the three months ended September 30, 2016 and 2015. No customer accounted for 10% or more of the Company's accounts receivable as of September 30, 2016 and June 30, 2016.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-16-020941:notes:131]
[same as prior period, unchanged from 0001628280-16-015755:notes:129]

[0001628280-16-020941:notes:132]
[same as prior period, unchanged from 0001628280-16-015755:notes:130]

[0001628280-16-020941:notes:133]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $3,893,000 and $1,718,000 in the three months ended September 30, 2016 and 2015, respectively.
