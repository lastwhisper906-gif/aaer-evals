# SMCI MD&A — 0001628280-16-020941


## mdna

[0001628280-16-020941:mdna:1]
[same as prior period, unchanged from 0001628280-16-015755:mdna:1]

[0001628280-16-020941:mdna:2]
[same as prior period, unchanged from 0001628280-16-015755:mdna:2]

[0001628280-16-020941:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, high performance computing (“HPC”), and Internet of Things (“IoT”)/embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Our net sales were $529.0 million and $519.6 million for the three months ended September 30, 2016 and 2015, respectively. The increase in our net sales in the three months ended September 30, 2016 compared with the three months ended September 30, 2015 was primarily due to increased sales of our subsystems and accessories to our distributors and to a lesser extent our server systems. Net sales of optimized servers were $357.5 million and $356.2 million for the three months ended September 30, 2016 and 2015, respectively, and net sales of subsystems and accessories were $171.5 million and $163.4 million for the three months ended September 30, 2016 and 2015, respectively. In the three months ended September 30, 2016, we experienced growth in sales of our complete systems including microblade, high density Twin family of servers, storage, IoT/embedded servers, accelerated GPU computing servers and rack scale cloud server solutions offset in part by a decrease in sales of our ultra and data center optimized servers. The percentage of our net sales represented by sales of complete server systems decreased to 67.6% in the three months ended September 30, 2016 from 68.6% in the three months ended September 30, 2015.

[0001628280-16-020941:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $13.5 million and $13.7 million for the three months ended September 30, 2016 and 2015, respectively. Our decrease in net income in the three months ended September 30, 2016 was primarily attributable to higher operating expenses from headcount and annual salary increases to support our business growth which offset increased gross profit in the quarter ended September 30, 2016.

[0001628280-16-020941:mdna:5]
We sell our server systems and subsystems and accessories through our direct sales force as well as through distributors and OEMs. We derived 50.0% and 54.4% of our net sales from products sold to direct customers and OEMs for the three months ended September 30, 2016 and 2015, respectively. None of our customers accounted for 10% or more of our net sales in the three months ended September 30, 2016. Sales to SoftLayer, a division of IBM Corporation, represented 12.2% of our net sales in the three months ended September 30, 2015. We derived 55.9% and 65.2% of our net sales from customers in the United States for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 6.3% and 5.5% of our net sales for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2017, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers, and we have continued to improve our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three months ended September 30, 2016 and 2015, our purchases from Ablecom represented 11.2% and 13.2% of our cost of sales, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in an effort to reduce our cost of sales. In addition to providing contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our

[0001628280-16-020941:mdna:8]
future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-16-020941:mdna:9]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise sales. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding (“DSOs”). In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures.

[0001628280-16-020941:mdna:10]
[same as prior period, unchanged from 0001628280-16-015755:mdna:10]

[0001628280-16-020941:mdna:11]
The following is a summary of other financial highlights of the first quarter of fiscal 2017:

[0001628280-16-020941:mdna:12]
| • | Net cash provided by (used in) operating activities was $(11.0) million and $20.3 million during the three months ended September 30, 2016 and 2015, respectively. Our cash and cash equivalents, together with our investments, were $149.4 million at the end of the first quarter of fiscal year 2017, compared with $183.7 million at the end of fiscal year 2016. The decrease in our cash and cash equivalents, together with our investments at the end of the first quarter of fiscal year 2017 was primarily due to $11.0 million of cash used in our operating activities, $18.5 million used to purchase outstanding common stock and $11.6 million used to purchase property and equipment, of which $5.3 million was related to property and equipment for use at our Green Computing Park in San Jose, California. |

[0001628280-16-020941:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the first quarter of fiscal year 2017 was 54 days, compared with 50 days at the end of fiscal year 2016. |

[0001628280-16-020941:mdna:14]
| • | Our inventory balance was $500.0 million at the end of the first quarter of fiscal year 2017, compared with $449.0 million at the end of fiscal year 2016. Days sales of inventory at the end of the first quarter of fiscal year 2017 was 97 days, compared with 87 days at the end of fiscal year 2016. |

[0001628280-16-020941:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $354.8 million at the end of the first quarter of fiscal year 2017 and $334.0 million at the end of fiscal year 2016. Included in these non-cancellable commitments are hard disk drive purchase commitments totaling approximately $42.2 million which have terms expiring through December 2016. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-16-020941:mdna:16]
[same as prior period, unchanged from 0001628280-16-015755:mdna:16]

[0001628280-16-020941:mdna:17]
Our fiscal year ends on June 30. References to fiscal year 2017, for example, refer to the fiscal year ending June 30, 2017.

[0001628280-16-020941:mdna:18]
[same as prior period, unchanged from 0001628280-16-015755:mdna:19]

[0001628280-16-020941:mdna:19]
Net sales. Net sales consist of sales of our server solutions, including server systems, subsystems and accessories. The main factors which impact our net sales are the number of compute nodes shipped and average selling prices per node for our server system sales and units shipped and average selling price per unit for our subsystem and accessories sales. The prices for server systems range widely depending upon the configuration including the number of compute nodes on a server system, and the prices for our subsystems and accessories vary based on the type. A compute node is a hardware configuration having its own CPU, RAM and storage and that is capable of running its own instance of a non-virtualized operating system. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based products, average selling prices typically are highest at the time of introduction of new products which utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products.

[0001628280-16-020941:mdna:20]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally higher on server systems than on subsystems and accessories in the case of sales of server systems to cloud/internet data center computing customers. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001628280-16-020941:mdna:21]
Research and development expenses. Research and development expenses consist of the personnel and related expenses including stock based compensation of our research and development teams, and materials and supplies, consulting services, third party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering (“NRE”), funding from certain suppliers and customers. Under these programs, we are reimbursed for certain research and development costs that we incur as part of the joint development of our products and those of our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001628280-16-020941:mdna:22]
Sales and marketing expenses. Sales and marketing expenses consist primarily of salaries, stock based compensation and incentive bonuses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these programs, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. Similarly, we from time to time offer our distributors cooperative marketing funding. To the extent the funding is not recorded as contra-revenue, it has the effect of increasing our expenses. The timing, magnitude and estimated usage of our programs and those of our suppliers can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, either by us or our suppliers, typically increases in connection with significant product releases by us or our suppliers.

[0001628280-16-020941:mdna:23]
[same as prior period, unchanged from 0001628280-16-015755:mdna:24]

[0001628280-16-020941:mdna:24]
Interest and other income, net. Interest and other income, net consist primarily of interest earned on our investment and cash balances.

[0001628280-16-020941:mdna:25]
Interest expense. Interest expense represents interest expense on our term loans and lines of credit.

[0001628280-16-020941:mdna:26]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits and the domestic production activities deduction which were partially offset by state taxes and unrecognized tax benefits related to permanent establishment exposures.

[0001628280-16-020941:mdna:27]
Critical Accounting Policies and Estimates

[0001628280-16-020941:mdna:28]
There have been no material changes in the matters for which we make critical accounting policies and estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended September 30, 2016, as compared to those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2016.

[0001628280-16-020941:mdna:29]
[same as prior period, unchanged from 0001628280-16-015755:mdna:44]

[0001628280-16-020941:mdna:30]
[same as prior period, unchanged from 0001628280-16-015755:mdna:45]

[0001628280-16-020941:mdna:31]
The following table presents net sales by product type for the three months ended September 30, 2016 and 2015 (dollars in millions):

[0001628280-16-020941:mdna:32]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |
| Server systems | $ | 357.5 |  |  | $ | 356.2 |  |  | $ | 1.3 |  |  | 0.4 | % |
| Percentage of total net sales | 67.6 | % |  | 68.6 | % |  |  |  |  |
| Subsystems and accessories | 171.5 |  |  | 163.4 |  |  | 8.1 |  |  | 4.9 | % |
| Percentage of total net sales | 32.4 | % |  | 31.4 | % |  |  |  |  |
| Total net sales | $ | 529.0 |  |  | $ | 519.6 |  |  | $ | 9.4 |  |  | 1.8 | % |

[0001628280-16-020941:mdna:33]
The following table presents the number of compute node sales and average selling price per node of our server systems for the three months ended September 30, 2016 and 2015 (nodes in thousands):

[0001628280-16-020941:mdna:34]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | % |
| Server systems: |  |  |  |  |  |
| Number of compute node sales (1) | 122 |  |  | 116 |  |  | 5.2 | % |
| Average selling price per node | $ | 2,927 |  |  | $ | 3,074 |  |  | (4.8 | )% |

[0001628280-16-020941:mdna:35]
(1) A compute node is a hardware configuration having its own CPU, RAM and storage and that is capable of running its own instance of a non-virtualized operating system.

[0001628280-16-020941:mdna:36]
The following table presents unit sales and average selling price of our subsystems and accessories for the three months ended September 30, 2016 and 2015 (units in thousands):

[0001628280-16-020941:mdna:37]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | % |
| Subsystems and accessories: |  |  |  |  |  |
| Unit sales | 1,144 |  |  | 916 |  |  | 24.9 | % |
| Average selling price per unit | $ | 150 |  |  | $ | 178 |  |  | (15.7 | )% |

[0001628280-16-020941:mdna:38]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001628280-16-020941:mdna:39]
The increase in our net sales in the three months ended September 30, 2016 compared with the three months ended September 30, 2015 was primarily due to an increase in sales of our subsystems and accessories to our distributors. The year-over-year growth in net sales of our server systems in the three months ended September 30, 2016 was due primarily to an increase in the number of compute node sales which offset a lower average selling price per node of our server systems as we sold higher nodes per systems. The increase in the sales of these complete systems include our microblade, high density Twin family of servers, storage, IoT/embedded servers, accelerated GPU computing servers and rack scale cloud server solutions offset in part by a decrease in sales of our ultra and data center optimized servers.

[0001628280-16-020941:mdna:40]
The year-over-year increase in net sales and unit sales of our subsystems and accessories in the three months ended September 30, 2016 was primarily due to higher sales of serverboards and server accessories to our distributors.

[0001628280-16-020941:mdna:41]
The following table presents the percentages of net sales from products sold to distributors and direct/OEM customers for the three months ended September 30, 2016 and 2015:

[0001628280-16-020941:mdna:42]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | % |
| Distributors | 50.0 | % |  | 45.6 | % |  | 4.4 | % |
| Direct/OEM customers | 50.0 | % |  | 54.4 | % |  | (4.4 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-020941:mdna:43]
The year-over-year increase in net sales to distributors in the three months ended September 30, 2016 was primarily due to the higher demand for our subsystem and accessories which are typically sold through distributors. The year-over-year decrease in net sales to direct/OEM customers in the three months ended September 30, 2016 was primarily due to the lower demand for our server systems from cloud/internet data center computing partially offset by an increase demand for our server systems from enterprise and IoT/embedded customers.

[0001628280-16-020941:mdna:44]
The following table presents percentages of net sales by geographic region for the three months ended September 30, 2016 and 2015:

[0001628280-16-020941:mdna:45]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | % |
| United States | 55.9 | % |  | 65.2 | % |  | (9.3 | )% |
| Europe | 21.5 | % |  | 16.8 | % |  | 4.7 | % |
| Asia | 18.2 | % |  | 14.3 | % |  | 3.9 | % |
| Others | 4.4 | % |  | 3.7 | % |  | 0.7 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-020941:mdna:46]
The year-over-year decrease in net sales in the United States in the three months ended September 30, 2016 as a percentage of total net sales was primarily due to the lower demand for our server systems from cloud/internet data center computing which represents a higher portion of sales in the United States than in other regions. The year-over-year increase in net sales in Europe and Asia in the three months ended September 30, 2016 as a percentage of total net sales was primarily due to the higher demand for our server systems in the Netherlands, Japan and China.

[0001628280-16-020941:mdna:47]
[same as prior period, unchanged from 0001628280-16-015755:mdna:60]

[0001628280-16-020941:mdna:48]
Cost of sales and gross margin for the three months ended September 30, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-020941:mdna:49]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |
| Total cost of sales | $ | 448.9 |  |  | $ | 447.4 |  |  | $ | 1.5 |  |  | 0.3 | % |
| Total gross profit | 80.1 |  |  | 72.2 |  |  | $ | 7.8 |  |  | 10.9 | % |
| Total gross margin | 15.1 | % |  | 13.9 | % |  |  |  | 1.2 | % |

[0001628280-16-020941:mdna:50]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001628280-16-020941:mdna:51]
The quarter-over-quarter increase in absolute dollars of cost of sales in the three months ended September 30, 2016 compared to the three months ended September 30, 2015 was primarily attributable to the increase in net sales. In the three months ended September 30, 2016, we recorded a $3.9 million expense, net of recovery, or 0.7% of net sales, related to the inventory provision as compared to $1.7 million, or 0.3% of net sales, in the three months ended September 30, 2015.

[0001628280-16-020941:mdna:52]
In the three months ended September 30, 2016, we recorded a $4.9 million expense, or 0.9% of net sales, related to the provision for warranty reserve as compared to a $3.9 million expense, or 0.7% of net sales, in the three months ended

[0001628280-16-020941:mdna:53]
September 30, 2015. The increase in the provision for warranty reserve was primarily due to an increase in warranty claims and cost of servicing warranty claims in the three months ended September 30, 2016. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-020941:mdna:54]
Gross margin percentage was 15.1% and 13.9% for the three months ended September 30, 2016 and 2015, respectively. The increase was primarily due to a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three fiscal year period ended June 30, 2015 and deferred in the three months ended September 30, 2015, lower sales of cloud/internet data center server systems which typically have lower margins offset in part by lower global utilization and higher provision for inventory and warranty reserves.

[0001628280-16-020941:mdna:55]
[same as prior period, unchanged from 0001628280-16-015755:mdna:72]

[0001628280-16-020941:mdna:56]
Operating expenses for the three months ended September 30, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-020941:mdna:57]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |
| Research and development | $ | 33.2 |  |  | $ | 28.3 |  |  | $ | 4.9 |  |  | 17.2 | % |
| Percentage of total net sales | 6.3 | % |  | 5.5 | % |  |  |  |  |
| Sales and marketing | 15.9 |  |  | 14.2 |  |  | 1.7 |  |  | 11.7 | % |
| Percentage of total net sales | 3.0 | % |  | 2.7 | % |  |  |  |  |
| General and administrative | 10.8 |  |  | 8.2 |  |  | 2.6 |  |  | 31.2 | % |
| Percentage of total net sales | 2.0 | % |  | 1.6 | % |  |  |  |  |
| Total operating expenses | $ | 59.9 |  |  | $ | 50.8 |  |  | $ | 9.1 |  |  | 17.9 | % |
| Percentage of total net sales | 11.3 | % |  | 9.8 | % |  |  |  |  |

[0001628280-16-020941:mdna:58]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001628280-16-020941:mdna:59]
Research and development expenses. Research and development expenses increased by $4.9 million, or 17.2% in the three months ended September 30, 2016 compared to the three months ended September 30, 2015. Research and development expenses were 6.3% and 5.5% of net sales for the three months ended September 30, 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $4.6 million in compensation and benefits including stock-based compensation expense.

[0001628280-16-020941:mdna:60]
Research and development expenses include stock-based compensation expense of $2.9 million and $2.4 million for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:mdna:61]
[same as prior period, unchanged from 0001628280-16-015755:mdna:78]

[0001628280-16-020941:mdna:62]
Sales and marketing expenses. Sales and marketing expenses increased by $1.7 million, or 11.7% in the three months ended September 30, 2016 compared to the three months ended September 30, 2015. Sales and marketing expenses were 3.0% and 2.7% of net sales for the three months ended September 30, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $1.4 million in compensation and benefits including stock-based compensation expense, resulting primarily from growth in sales and marketing personnel, a decrease of $0.5 million in marketing cooperative funding from certain suppliers, an increase of $0.3 million in freight out expenses to customers, an increase of $0.3 million in cooperative marketing funding to our customers, partially offset by a decrease of $1.2 million in advertising, marketing promotional and trade show expenses.

[0001628280-16-020941:mdna:63]
Sales and marketing expenses include stock-based compensation expense of $0.5 million and $0.4 million for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:mdna:64]
General and administrative expenses. General and administrative expenses increased by $2.6 million, or 31.2% in the three months ended September 30, 2016 compared to the three months ended September 30, 2015. General and administrative expenses were 2.0% and 1.6% of net sales for the three months ended September 30, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to a $1.9 million foreign currency transaction gain in the three months ended September 30, 2015 as compared to a $0.5 million foreign currency transaction loss in the three months ended September 30, 2016, an increase of $1.0 million in compensation and benefits including stock-based compensation expense, partially offset by a decrease of $1.1 million in legal expenses.

[0001628280-16-020941:mdna:65]
General and administrative expenses include stock-based compensation expense of $0.8 million for both three months ended September 30, 2016 and 2015.

[0001628280-16-020941:mdna:66]
[same as prior period, unchanged from 0001628280-16-015755:mdna:91]

[0001628280-16-020941:mdna:67]
Interest and other expense, net for the three months ended September 30, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-020941:mdna:68]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |
| Interest and other income, net | $ | — |  |  | $ | 0.1 |  |  | $ | (0.1 | ) |  | (66.7 | )% |
| Interest expense | (0.3 | ) |  | (0.3 | ) |  | — |  |  | 1.9 | % |
| Interest and other expense, net | $ | (0.3 | ) |  | $ | (0.2 | ) |  | $ | (0.1 | ) |  | 27.0 | % |

[0001628280-16-020941:mdna:69]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001628280-16-020941:mdna:70]
Interest and other expense, net. Interest and other expense, net increased by $0.1 million in the three months ended September 30, 2016 compared to the three months ended September 30, 2015. The increases were primarily due to a decrease in other income.

[0001628280-16-020941:mdna:71]
[same as prior period, unchanged from 0001628280-16-015755:mdna:99]

[0001628280-16-020941:mdna:72]
Provision for income taxes and effective tax rates for the three months ended September 30, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-020941:mdna:73]
|  | Three Months EndedSeptember 30, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |
| Provision for income taxes | $ | 6.4 |  |  | $ | 7.5 |  |  | $ | (1.1 | ) |  | (15.1 | )% |
| Percentage of total net sales | 1.2 | % |  | 1.5 | % |  |  |  |  |
| Effective tax rate | 32.0 | % |  | 35.4 | % |  |  |  |  |

[0001628280-16-020941:mdna:74]
Comparison of Three Months Ended September 30, 2016 and 2015

[0001628280-16-020941:mdna:75]
Provision for income taxes. Provision for income taxes decreased by $1.1 million, or 15.1% in the three months ended September 30, 2016 compared to the three months ended September 30, 2015. The effective tax rate was 32.0% and 35.4% for the three months ended September 30, 2016 and 2015, respectively. The lower income tax provision for the three months ended September 30, 2016 was primarily attributable to our lower operating income. The effective tax rate for the three months ended September 30, 2016 was lower primarily due to the benefits from U.S. federal research and development ("R&D") tax credit and domestic production activities deduction.

[0001628280-16-020941:mdna:76]
[same as prior period, unchanged from 0001628280-16-015755:mdna:106]

[0001628280-16-020941:mdna:77]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $146.8 million and $181.0 million as of September 30, 2016 and June 30, 2016, respectively. Our cash in foreign locations was $41.3 million and $46.5 million at

[0001628280-16-020941:mdna:78]
September 30, 2016 and June 30, 2016, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-16-020941:mdna:79]
Operating Activities. Net cash provided by (used in) operating activities was $(11.0) million and $20.3 million for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020941:mdna:80]
Net cash used in our operating activities for the three months ended September 30, 2016 was primarily due to an increase in inventory of $54.9 million and an increase in accounts receivable of $39.4 million, which were partially offset by an increase in accounts payable of $43.4 million, our net income of $13.5 million, an increase in income tax payable of $5.3 million, an increase in accrued liabilities of $5.0 million, stock-based compensation expense of $4.5 million, an increase in other long-term liabilities of $4.1 million, provision for inventory of $3.9 million, and depreciation expense of $3.8 million.

[0001628280-16-020941:mdna:81]
Net cash provided by our operating activities for the three months ended September 30, 2015 was primarily due to a decrease in accounts receivable of $25.4 million, our net income of $13.7 million, an increase in other long-term liabilities of $8.9 million, stock-based compensation expense of $3.9 million, net income taxes payable of $3.0 million, depreciation expense of $2.8 million and an increase in provision for inventory of $1.7 million, which were partially offset by a decrease in accounts payable of $37.7 million and foreign exchange gain of $2.0 million.

[0001628280-16-020941:mdna:82]
The increase for the three months ended September 30, 2016 in accounts receivable was primarily due to higher sales in the last month of the first quarter of fiscal year 2017 as compared to the last month of the fourth quarter of fiscal year 2016. The increase for the three months ended September 30, 2016 in inventory and accounts payable was due to higher purchases to support the anticipated level of growth in our net sales in the second quarter of fiscal year 2017. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-16-020941:mdna:83]
The decrease for the three months ended September 30, 2015 in accounts receivable was primarily due to lower sales in the first quarter of fiscal year 2016 as compared to the fourth quarter of fiscal year 2015. The decrease for the three months ended September 30, 2015 in accounts payable was primarily due to lower purchases and lower sales in the three months ended September 30, 2015.

[0001628280-16-020941:mdna:84]
Investing activities. Net cash used in our investing activities was $11.5 million and $7.7 million for the three months ended September 30, 2016 and 2015, respectively. In the three months ended September 30, 2016, of the net cash used in our investing activities, $11.6 million was related to the purchase of property, plant and equipment, of which $5.3 million was related to the property and equipment for the manufacturing buildings at our Green Computing Park in San Jose, California. We anticipate investing approximately $9.5 million through April 2017 to complete the construction of a second manufacturing facility and the remodeling of our office building. We plan to finance this development through our operating cash flows and additional borrowings from banks. In the three months ended September 30, 2015, $7.7 million was related to the purchase of property, plant and equipment.

[0001628280-16-020941:mdna:85]
Financing activities. Net cash provided by (used in) our financing activities was $(12.0) million and $2.6 million for the three months ended September 30, 2016 and 2015, respectively. In the three months ended September 30, 2016, we used $18.5 million to repurchase outstanding common stock. We borrowed an additional $73.9 million under term loan and revolving lines of credit from Bank of America and CTBC Bank and repaid $70.0 million in loans. Further, we received $2.9 million related to the proceeds from the exercise of stock options in the three months ended September 30, 2016.

[0001628280-16-020941:mdna:86]
In the three months ended September 30, 2015, we borrowed an additional $4.7 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $2.9 million in loans. Further, we received $1.0 million related to the proceeds from the exercise of stock options in the three months ended September 30, 2015.

[0001628280-16-020941:mdna:87]
We expect our net cash provided by financing activities will increase throughout fiscal year 2017 as we intend to obtain additional financing from banks for our working capital requirements.

[0001628280-16-020941:mdna:88]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will

[0001628280-16-020941:mdna:89]
be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-16-020941:mdna:90]
[same as prior period, unchanged from 0001628280-16-015755:mdna:117]

[0001628280-16-020941:mdna:91]
[same as prior period, unchanged from 0001628280-16-015755:mdna:118]

[0001628280-16-020941:mdna:92]
[same as prior period, unchanged from 0001628280-16-015755:mdna:119]

[0001628280-16-020941:mdna:93]
In June 2015, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In May 2016, we extended the revolving line of credit to mature on June 30, 2016.

[0001628280-16-020941:mdna:94]
In June 2016, we entered into a new credit agreement with Bank of America, which provided for (i) a $55.0 million revolving line of credit facility including a $5.0 million letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50.0 million term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

[0001628280-16-020941:mdna:95]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.52% at September 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, we received $50.0 million term loan proceeds from Bank of America under the new credit agreement with an interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America.

[0001628280-16-020941:mdna:96]
In June 2016, we also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10.0 million for our Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of fund.

[0001628280-16-020941:mdna:97]
As of September 30, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $47.5 million and $0.9 million, respectively. The total outstanding borrowings under the Bank of America lines of credit was $11.2 million and $62.2 million as of September 30, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.08% to 1.77% per annum at September 30, 2016 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of September 30, 2016, the unused revolving lines of credit amount with Bank of America under the new credit agreements were $53.8 million.

[0001628280-16-020941:mdna:98]
In October 2016, we drew an additional $30.0 million from Bank of America revolving line of credit with interest rates ranging from 2.14% to 3.75% per annum to support our growth and expansion of our business in the Netherlands.

[0001628280-16-020941:mdna:99]
[same as prior period, unchanged from 0001628280-16-015755:mdna:123]

[0001628280-16-020941:mdna:100]
In November 2015, we entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million or $22.0 million U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NTD$1.0 billion or $30.3 million U.S. dollar equivalent. In January 2016, we extended the revolving line of credit to mature on March 31, 2016.

[0001628280-16-020941:mdna:101]
In April 2016, we entered into a new credit agreement with CTBC Bank that provides for (i) a 12-month NTD$700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100.0 million or $3.1 million U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30%

[0001628280-16-020941:mdna:102]
per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40.0 million. The credit agreement matures on March 31, 2017.

[0001628280-16-020941:mdna:103]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21.1 million and $20.4 million at September 30, 2016 and June 30, 2016, respectively. At September 30, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $18.8 million and $10.1 million, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.89% and 1.40% at September 30, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At September 30, 2016, available for future borrowing under this credit agreement was $0.1 million.

[0001628280-16-020941:mdna:104]
Covenant Compliance

[0001628280-16-020941:mdna:105]
The credit agreement with Bank of America contain customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-16-020941:mdna:106]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |

[0001628280-16-020941:mdna:107]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months, shall not be greater than 2.00; |

[0001628280-16-020941:mdna:108]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $30,000,000, measured quarterly as of the last day of each fiscal quarter. |

[0001628280-16-020941:mdna:109]
As of September 30, 2016, our total assets of $959.9 million collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarters company except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of September 30, 2016, total assets collateralizing the term loan with Bank of America were $82.0 million. As of September 30, 2016, we were in compliance with all financial covenants associated with the term loan and lines of credit with Bank of America under the new credit agreement.

[0001628280-16-020941:mdna:110]
As of September 30, 2016, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.7 million. There are no financial covenants associated with the term loan with CTBC Bank.

[0001628280-16-020941:mdna:111]
[same as prior period, unchanged from 0001628280-16-015755:mdna:134]

[0001628280-16-020941:mdna:112]
In the three months ended September 30, 2016, we paid our contract manufacturers within 35 to 76 days of invoice and Ablecom between 47 to 77 days of invoice. Ablecom is one of our major contract manufacturers and a related party. As of September 30, 2016 and June 30, 2016 amounts owed to Ablecom by us were approximately $38.3 million and $39.2 million, respectively.

[0001628280-16-020941:mdna:113]
Share Repurchase Program

[0001628280-16-020941:mdna:114]
In July 2016, our Board of Directors adopted a program to repurchase from time to time at management’s discretion up to $100,000,000 of our common stock in the open market or in private transactions during the next twelve months at prevailing market prices. Repurchases will be made under the program using our own cash resources. This share repurchase program does not obligate us to acquire any particular amount of common stock, and it may be suspended at any time at our discretion. During the three months ended September 30, 2016, we purchased 888,097 shares of our common stock in the open market at a weighted average price of $20.79 per share for approximately $18.5 million.

[0001628280-16-020941:mdna:115]
[same as prior period, unchanged from 0001628280-16-015755:mdna:139]

[0001628280-16-020941:mdna:116]
The following table describes our contractual obligations as of September 30, 2016:

[0001628280-16-020941:mdna:117]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3Years |  | 3 to 5Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,262 |  |  | $ | 7,627 |  |  | $ | 4,807 |  |  | $ | 2,387 |  |  | $ | 19,083 |  |
| Capital leases, including interest | 254 |  |  | 404 |  |  | 98 |  |  | — |  |  | 756 |  |
| Debt, including interest (1) | 61,794 |  |  | 20,955 |  |  | 17,775 |  |  | — |  |  | 100,524 |  |
| Purchase commitments (2) | 354,796 |  |  | — |  |  | — |  |  | — |  |  | 354,796 |  |
| Total (3) | $ | 421,106 |  |  | $ | 28,986 |  |  | $ | 22,680 |  |  | $ | 2,387 |  |  | $ | 475,159 |  |

[0001628280-16-020941:mdna:118]
[same as prior period, unchanged from 0001628280-16-015755:mdna:142]

[0001628280-16-020941:mdna:119]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at September 30, 2016. |

[0001628280-16-020941:mdna:120]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $42.2 million of hard disk drive purchase commitments at September 30, 2016, which will be paid through December 2016. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-16-020941:mdna:121]
| (3) | The table above excludes liabilities for deferred revenue of $41.5 million and unrecognized tax benefits and related interest and penalties accrual of $17.1 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 8 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes. |

[0001628280-16-020941:mdna:122]
[same as prior period, unchanged from 0001628280-16-015755:mdna:147]

[0001628280-16-020941:mdna:123]
[same as prior period, unchanged from 0001628280-16-015755:mdna:148]

[0001628280-16-020941:mdna:124]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our Condensed Consolidated Financial Statements, see Note 1, “Summary of Significant Accounting Policies,” of the Notes to Condensed Consolidated Financial Statements.

[0001628280-16-020941:mdna:125]
[same as prior period, unchanged from 0001628280-16-015755:mdna:155]

[0001628280-16-020941:mdna:126]
[same as prior period, unchanged from 0001628280-16-015755:mdna:156]
