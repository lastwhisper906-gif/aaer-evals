# SMCI 8-K — 0001628280-16-020384 filed 2016-10-27

## item codes, every 8-K on or before 2016-11-07

- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2016-11-07

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-020384:8k_2_02:1]
EX-99.1
2
exhibit991q1-2017.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-16-020384:8k_2_02:2]
Exhibit

[0001628280-16-020384:8k_2_02:3]
Exhibit 99.1

[0001628280-16-020384:8k_2_02:4]
Super Micro Computer, Inc. Announces 1st Quarter 2017 Financial Results

[0001628280-16-020384:8k_2_02:5]
SAN JOSE, Calif., October 27, 2016 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced first quarter fiscal 2017 financial results for the quarter ended September 30, 2016.

[0001628280-16-020384:8k_2_02:6]
Fiscal 1st Quarter Highlights

[0001628280-16-020384:8k_2_02:7]
| • | Quarterly net sales of $529.0 million, up 0.9% from the fourth quarter of fiscal year 2016 and up 1.8% from the same quarter of last year. |

[0001628280-16-020384:8k_2_02:8]
| • | GAAP net income of $13.5 million, up 94.1% from the fourth quarter of fiscal year 2016 and down 1.2% from the same quarter of last year. |

[0001628280-16-020384:8k_2_02:9]
| • | GAAP gross margin was 15.1%, up from 14.1% in the fourth quarter of fiscal year 2016 and up from 13.9% in the same quarter of last year. |

[0001628280-16-020384:8k_2_02:10]
| • | Server solutions accounted for 67.6% of net sales compared with 65.5% in the fourth quarter of fiscal year 2016 and 68.6% in the same quarter of last year. |

[0001628280-16-020384:8k_2_02:11]
Net sales for the first quarter ended September 30, 2016 totaled $529.0 million, up 0.9% from $524.3 million in the fourth quarter of fiscal year 2016. No customer accounted for more than 10% of net sales during the quarter ended September 30, 2016.

[0001628280-16-020384:8k_2_02:12]
GAAP net income for the first quarter of fiscal year 2017 was $13.5 million or $0.26 per diluted share, a decrease of 1.2% from net income of $13.7 million, or $0.27 per diluted share in the same period a year ago. Included in net income for the quarter is $4.5 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the first quarter was $16.7 million, or $0.32 per diluted share, compared to non-GAAP net income of $16.5 million, or $0.32 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the fourth quarter of fiscal year 2016 by $6.3 million or $0.12 per diluted share.

[0001628280-16-020384:8k_2_02:13]
GAAP gross margin for the first quarter of fiscal year 2017 was 15.1% compared to 13.9% in the same period a year ago. Non-GAAP gross margin for the first quarter was 15.2% compared to 13.9% in the same period a year ago. GAAP and Non-GAAP gross margin for the fourth quarter of fiscal year 2016 were both 14.1%.

[0001628280-16-020384:8k_2_02:14]
The GAAP income tax provision for the first quarter of fiscal year 2017 was $6.4 million or 32.0% of income before tax provision compared to $7.5 million or 35.4% in the same period a year ago and $4.5 million or 39.0% in the fourth quarter of fiscal year 2016. The effective tax rates for the first quarter of fiscal year 2017 was lower primarily due to an increase in the domestic production activities deduction and U.S. federal research and development ("R&D") tax credits.

[0001628280-16-020384:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at September 30, 2016 were $149.4 million compared to $183.7 million at June 30, 2016. Free cash flow for the three months ended September 30, 2016 was $(22.7) million, primarily due to an increase in the Company's cash used in the development and construction of improvements on the Company's properties and the cash used in operating activities.

[0001628280-16-020384:8k_2_02:16]
Share Repurchase Activity

[0001628280-16-020384:8k_2_02:17]
On July 18, 2016, the Company announced that the Company's Board of Directors has adopted a program to repurchase from time to time at management's discretion up to $100 million dollars of the Company's common stock in the open market or in private transactions during the next 12 months at prevailing market prices. During the quarter ended September 30, 2016, the Company repurchased 888,097 shares at a total cost of $18.5 million, reflecting an average price of $20.79 per share.

[0001628280-16-020384:8k_2_02:18]
Business Outlook & Management Commentary

[0001628280-16-020384:8k_2_02:19]
The Company expects net sales of $570 million to $640 million for the second quarter of fiscal year 2017 ending December 31, 2016. The Company expects non-GAAP earnings per diluted share of approximately $0.38 to $0.52 for the second quarter.

[0001628280-16-020384:8k_2_02:20]
“We are pleased that Supermicro was able to report revenues and profits at the higher end of our expectations for the first quarter. Strong growth from storage, IoT Embedded, and accelerated computing contributed to our results. Although internet datacenter and cloud were lower than previous quarters and same quarter last year, we have many opportunities to win more business in the coming quarters to increase utilization of our current capacity” said Charles Liang, President and Chief Executive Officer. “Technology is changing rapidly with several technology transitions coming soon and Supermicro is the best positioned company in IT infrastructure today to quickly adapt to the new technologies. We believe that we have opportunities for growth across all of our product lines and we will continue to focus on being first to market with the latest technology.”

[0001628280-16-020384:8k_2_02:21]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-16-020384:8k_2_02:22]
Conference Call Information

[0001628280-16-020384:8k_2_02:23]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-500-6974 (International callers dial 1-719-325-2133) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, November 10, 2016, by dialing 1-844-512-2921 (International callers dial 1-412-317-6671) and entering replay PIN 8620920. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-16-020384:8k_2_02:24]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-16-020384:8k_2_02:25]
Use of Non-GAAP Financial Measures

[0001628280-16-020384:8k_2_02:26]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-16-020384:8k_2_02:27]
About Super Micro Computer, Inc.

[0001628280-16-020384:8k_2_02:28]
Supermicro®, a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, TwinPro, FatTwin™, Ultra Series, MicroCloud, MicroBlade, SuperBlade®, Simply Double, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-16-020384:8k_2_02:29]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-16-020384:8k_2_02:30]
Supermicro, FatTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001628280-16-020384:8k_2_02:31]
All other brands, names and trademarks are the property of their respective owners.

[0001628280-16-020384:8k_2_02:32]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | September 30, |  | June 30, |
|  |  |  |  | 2016 |  | 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 146,696 |  |  | $ | 180,964 |  |
|  | Accounts receivable, net | 328,267 |  |  | 288,941 |  |
|  | Inventory |  | 499,987 |  |  | 448,980 |  |
|  | Prepaid income taxes | 1,019 |  |  | 5,682 |  |
|  | Prepaid expenses and other current assets | 13,402 |  |  | 13,435 |  |
|  |  | Total current assets | 989,371 |  |  | 938,002 |  |
| Long-term investments | 2,643 |  |  | 2,643 |  |
| Property, plant and equipment, net | 190,848 |  |  | 187,949 |  |
| Deferred income taxes – noncurrent |  | 29,666 |  |  | 28,460 |  |
| Other assets |  |  | 8,053 |  |  | 8,546 |  |
|  |  | Total assets | $ | 1,220,581 |  |  | $ | 1,165,600 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 287,638 |  |  | $ | 249,239 |  |
|  | Accrued liabilities |  | 60,843 |  |  | 55,618 |  |
|  | Income taxes payable |  | 6,029 |  |  | 5,172 |  |
|  | Short-term debt and current portion of long-term debt, net of debt issuance costs | 60,983 |  |  | 53,589 |  |
|  |  | Total current liabilities | 415,493 |  |  | 363,618 |  |
| Long term debt, net of current portion and debt issuance costs | 37,212 |  |  | 40,000 |  |
| Other long-term liabilities | 44,661 |  |  | 40,603 |  |
|  |  | Total liabilities | 497,366 |  |  | 444,221 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 284,090 |  |  | 277,339 |  |
|  | Treasury stock (at cost) | (20,491 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (76 | ) |  | (85 | ) |
|  | Retained earnings |  | 459,503 |  |  | 445,971 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 723,026 |  |  | 721,195 |  |
|  | Noncontrolling interest | 189 |  |  | 184 |  |
|  |  | Total stockholders' equity | 723,215 |  |  | 721,379 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,220,581 |  |  | $ | 1,165,600 |  |

[0001628280-16-020384:8k_2_02:33]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |
|  | September 30, |
|  | 2016 |  | 2015 |
| Net sales | $ | 528,968 |  |  | $ | 519,618 |  |
| Cost of sales | 448,904 |  |  | 447,403 |  |
| Gross profit | 80,064 |  |  | 72,215 |  |
| Operating expenses: |  |  |  |
| Research and development | 33,191 |  |  | 28,326 |  |
| Sales and marketing | 15,916 |  |  | 14,249 |  |
| General and administrative | 10,755 |  |  | 8,200 |  |
| Total operating expenses | 59,862 |  |  | 50,775 |  |
| Income from operations | 20,202 |  |  | 21,440 |  |
| Interest and other income, net | 29 |  |  | 87 |  |
| Interest expense | (330 | ) |  | (324 | ) |
| Income before income tax provision | 19,901 |  |  | 21,203 |  |
| Income tax provision | 6,369 |  |  | 7,504 |  |
| Net income | $ | 13,532 |  |  | $ | 13,699 |  |
| Net income per common share: |  |  |  |
| Basic | $ | 0.28 |  |  | $ | 0.29 |  |
| Diluted | $ | 0.26 |  |  | $ | 0.27 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |
| Basic | 48,165 |  |  | 47,517 |  |
| Diluted | 51,120 |  |  | 51,352 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended |
|  | September 30, |
|  | 2016 |  | 2015 |
| Cost of sales | $ | 309 |  |  | $ | 240 |  |
| Research and development | 2,908 |  |  | 2,402 |  |
| Sales and marketing | 478 |  |  | 404 |  |
| General and administrative | 809 |  |  | 830 |  |
| Stock-based compensation expense before taxes | $ | 4,504 |  |  | $ | 3,876 |  |

[0001628280-16-020384:8k_2_02:34]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Three Months Ended |
|  | September 30, |
|  | 2016 |  | 2015 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 13,532 |  |  | $ | 13,699 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 3,802 |  |  | 2,753 |  |
| Stock-based compensation expense | 4,504 |  |  | 3,876 |  |
| Excess tax benefits from stock-based compensation | (302 | ) |  | (134 | ) |
| Allowance for doubtful accounts | 73 |  |  | 98 |  |
| Provision for inventory | 3,893 |  |  | 1,718 |  |
| Exchange loss (gain) | 698 |  |  | (2,007 | ) |
| Deferred income taxes, net | (1,182 | ) |  | (2,221 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (39,399 | ) |  | 25,418 |  |
| Inventory | (54,900 | ) |  | 404 |  |
| Prepaid expenses and other assets | 465 |  |  | (1,247 | ) |
| Accounts payable | 43,362 |  |  | (37,652 | ) |
| Income taxes payable, net | 5,314 |  |  | 2,966 |  |
| Accrued liabilities | 4,992 |  |  | 3,686 |  |
| Other long-term liabilities | 4,105 |  |  | 8,949 |  |
| Net cash provided by (used in) operating activities | (11,043 | ) |  | 20,306 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (11,646 | ) |  | (7,662 | ) |
| Restricted cash | 116 |  |  | (3 | ) |
| Net cash used in investing activities | (11,530 | ) |  | (7,665 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt, net of debt issuance costs | 73,916 |  |  | 4,700 |  |
| Repayment of debt | (70,033 | ) |  | (2,900 | ) |
| Purchases of treasury stock | (18,461 | ) |  | — |  |
| Proceeds from exercise of stock options | 2,939 |  |  | 951 |  |
| Excess tax benefits from stock-based compensation | 302 |  |  | 134 |  |
| Payment of obligations under capital leases | (56 | ) |  | (39 | ) |
| Advances (payments) under receivable financing arrangements | 19 |  |  | (37 | ) |
| Minimum tax withholding paid on behalf of employees for restricted stock units | (660 | ) |  | (196 | ) |
| Net cash provided by (used in) financing activities | (12,034 | ) |  | 2,613 |  |
| Effect of exchange rate fluctuations on cash | 339 |  |  | 198 |  |
| Net increase (decrease) in cash and cash equivalents | (34,268 | ) |  | 15,452 |  |
| Cash and cash equivalents at beginning of period | 180,964 |  |  | 95,442 |  |
| Cash and cash equivalents at end of period | 146,696 |  |  | 110,894 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 316 |  |  | 298 |  |
| Cash paid for taxes, net of refunds | 1,212 |  |  | 5,736 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | — |  |  | 42 |  |
| Accrued costs for property, plant and equipment purchases | 4,070 |  |  | 5,735 |  |

[0001628280-16-020384:8k_2_02:35]
| SUPER MICRO COMPUTER, INC. |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| GAAP GROSS PROFIT | $ | 80,064 |  |  | $ | 72,215 |  |
|  | Add back stock-based compensation (a) | 309 |  |  | 240 |  |
| Non-GAAP GROSS PROFIT | $ | 80,373 |  |  | $ | 72,455 |  |
| GAAP GROSS MARGIN | 15.1 | % |  | 13.9 | % |
|  | Add back stock-based compensation (a) | 0.1 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 15.2 | % |  | 13.9 | % |
| GAAP INCOME FROM OPERATIONS | $ | 20,202 |  |  | $ | 21,440 |  |
|  | Add back stock-based compensation (a) | 4,504 |  |  | 3,876 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 24,706 |  |  | $ | 25,316 |  |
| GAAP NET INCOME | $ | 13,532 |  |  | $ | 13,699 |  |
|  | Add back stock-based compensation (a) | 4,504 |  |  | 3,876 |  |
|  | Add back adjustments to tax provision (b) | (1,362 | ) |  | (1,083 | ) |
| Non-GAAP NET INCOME | $ | 16,674 |  |  | $ | 16,492 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.28 |  |  | $ | 0.29 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.07 |  |  | 0.06 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.35 |  |  | $ | 0.35 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.26 |  |  | $ | 0.27 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.06 |  |  | 0.05 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.32 |  |  | $ | 0.32 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |
|  | BASIC –GAAP | 48,165 |  |  | 47,517 |  |
|  | BASIC - Non-GAAP | 48,165 |  |  | 47,517 |  |
|  | DILUTED – GAAP | 51,120 |  |  | 51,352 |  |
|  | DILUTED - Non-GAAP | 52,192 |  |  | 52,042 |  |

[0001628280-16-020384:8k_2_02:36]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three months ended September 30, 2016 and 2015.

[0001628280-16-020384:8k_2_02:37]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 31.7% and 34.2% for the three months ended September 30, 2016 and 2015, respectively.

[0001628280-16-020384:8k_2_02:38]
SOURCE: Super Micro Computer, Inc.

[0001628280-16-020384:8k_2_02:39]
Super Micro Computer, Inc.

[0001628280-16-020384:8k_2_02:40]
Howard Hideshima, 408-503-8000

[0001628280-16-020384:8k_2_02:41]
SVP, Chief Financial Officer

[0001628280-16-020384:8k_2_02:42]
ir@supermicro.com

[0001628280-16-020384:8k_2_02:43]
or

[0001628280-16-020384:8k_2_02:44]
Perry G. Hayes

[0001628280-16-020384:8k_2_02:45]
SVP, Investor Relations

[0001628280-16-020384:8k_2_02:46]
ir@supermicro.com

[0001628280-16-020384:8k_2_02:47]
SMCI-F
