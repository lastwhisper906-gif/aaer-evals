# SMCI note change history — 0001628280-16-015755 → 0001628280-16-020941


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001628280-16-020941:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of September 30, 2016, these remaining non-cancellable commitments were $354,796,000 compared to $334,010,000 as of June 30, 2016.
  (was, 2016-05-06, similarity 0.8283):
[0001628280-16-015755:note_history:1]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of March 31, 2016, these remaining non-cancellable commitments were $341,559,000 compared to $378,341,000 as of June 30, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001628280-16-020941:note_history:2]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (“SEC”) and include the accounts of the Company and its wholly-owned subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles have been condensed or omitted pursuant to such rules and regulations. These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016 included in its Annual Report on Form 10-K, as filed with the SEC (the “Annual Report”).
  (was, 2016-05-06, similarity 0.9987):
[0001628280-16-015755:note_history:2]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (“SEC”) and include the accounts of the Company and its wholly-owned subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles have been condensed or omitted pursuant to such rules and regulations. These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015 included in its Annual Report on Form 10-K/A, as filed with the SEC (the “Annual Report”).

- changed (2016-11-07):
[0001628280-16-020941:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2017.
  (was, 2016-05-06, similarity 0.7227):
[0001628280-16-015755:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.

- changed (2016-11-07):
[0001628280-16-020941:note_history:4]
The Company's basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units (“RSUs”). Under the treasury stock method, an increase in the fair market value of the Company’s common stock results in a greater dilutive effect from outstanding stock options and RSUs. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.
  (was, 2016-05-06, similarity 0.7214):
[0001628280-16-015755:note_history:4]
The Company's basic earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common stockholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.

- changed (2016-11-07):
[0001628280-16-020941:note_history:5]
Recently Issued Accounting Pronouncements
  (was, 2016-05-06, similarity 0.8767):
[0001628280-16-015755:note_history:5]
Recent Accounting Pronouncements

- added (2016-11-07):
[0001628280-16-020941:note_history:6]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, Revenue from Contracts with Customers, that replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which clarifies the implementation guidance for principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing, which clarifies the guidance related to identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB issued an amendment to the accounting guidance, Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients, which clarifies the guidance related to collectibility and non-cash consideration, as well as provides practical expedients for the transition to the new accounting guidance. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- added (2016-11-07):
[0001628280-16-020941:note_history:7]
In April 2015, the FASB issued an amendment to the accounting guidance, Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance, Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements. This amendment clarifies that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company adopted these amendments in the first quarter of fiscal year 2017. There was no material impact on its financial statement disclosures, results of operations and financial position.

- added (2016-11-07):
[0001628280-16-020941:note_history:8]
In July 2015, the FASB issued an amendment to the accounting guidance, Inventory: Simplifying the Measurement of Inventory. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the amendment to the guidance will have on its financial statement disclosures, results of operations and financial position.

- changed (2016-11-07):
[0001628280-16-020941:note_history:9]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.
  (was, 2016-05-06, similarity 0.9884):
[0001628280-16-015755:note_history:9]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- changed (2016-11-07):
[0001628280-16-020941:note_history:10]
In March 2016, the FASB issued new accounting guidance, Compensation—Stock Compensation: Improvements to Employee Share-Based Payment Accounting on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.
  (was, 2016-05-06, similarity 0.8266):
[0001628280-16-015755:note_history:10]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- added (2016-11-07):
[0001628280-16-020941:note_history:11]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. This amendment is effective for the Company on July 1, 2019. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

- removed (2016-11-07):
[0001628280-16-015755:note_history:12]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. These guidances can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- removed (2016-11-07):
[0001628280-16-015755:note_history:13]
In April 2015, the FASB issued an amendment to the accounting guidance related to presentation of debt issuance costs. The amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The amendment clarified that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The amendment is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- removed (2016-11-07):
[0001628280-16-015755:note_history:14]
In July 2015, the FASB issued an amendment to the authoritative guidance related to inventory measurement. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

- removed (2016-11-07):
[0001628280-16-015755:note_history:15]
In November 2015, the FASB issued an amendment to the accounting guidance related to balance sheet classification of deferred taxes. The amendment requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. Early adoption is permitted as of the beginning of an interim or annual reporting period. The amendment is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001628280-16-020941:note_history:16]
Short-term and Long-term Debt Obligations
  (was, 2016-05-06, similarity 0.9351):
[0001628280-16-015755:note_history:16]
Short-term and Long-term Obligations

- changed (2016-11-07):
[0001628280-16-020941:note_history:17]
Short-term and long-term obligations as of September 30, 2016 and June 30, 2016 consisted of the following (in thousands):
  (was, 2016-05-06, similarity 0.9545):
[0001628280-16-015755:note_history:17]
Short-term and long-term obligations as of March 31, 2016 and June 30, 2015 consisted of the following (in thousands):

- changed (2016-11-07):
[0001628280-16-020941:note_history:18]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 11,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 18,800 |  |  | 10,100 |  |
| Total line of credit | 29,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America (1) | 47,500 |  |  | 933 |  |
| CTBC Bank | 21,061 |  |  | 20,357 |  |
| Total term loans | 68,561 |  |  | 21,290 |  |
| Total debt | 98,560 |  |  | 93,589 |  |
| Less: debt issuance costs | (365 | ) |  | — |  |
| Total debt, net of debt issuance costs | 98,195 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (60,983 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 37,212 |  |  | $ | 40,000 |  |
  (was, 2016-05-06, similarity 0.796):
[0001628280-16-015755:note_history:18]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 1,633 |  |  | 3,733 |  |
| CTBC Bank | 20,263 |  |  | 21,280 |  |
| Total building term loans | 21,896 |  |  | 25,013 |  |
| Total debt | 93,795 |  |  | 94,412 |  |
| Current portion | (93,795 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |

- added (2016-11-07):
[0001628280-16-020941:note_history:19]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan at September 30, 2016 and June 30, 2016.

- changed (2016-11-07):
[0001628280-16-020941:note_history:20]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest were payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The Company extended the revolving line of credit to mature on June 30, 2016.
  (was, 2016-05-06, similarity 0.6361):
[0001628280-16-015755:note_history:20]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In April 2016, the Company extended the revolving line of credit to mature on May 31, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.

- added (2016-11-07):
[0001628280-16-020941:note_history:21]
In June 2016, the Company entered into a new credit agreement with Bank of America, which provided for (i) a $55,000,000 revolving line of credit facility including a $5,000,000 letter of credit sublimit that matures on June 30, 2017 and (ii) a five-year $50,000,000 term loan facility. This revolving line of credit facility replaced the existing revolving line of credit facility with Bank of America. This additional term loan is secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the term loan are payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum.

- added (2016-11-07):
[0001628280-16-020941:note_history:22]
The interest rate for the revolving line of credit under the above credit agreements with Bank of America is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.52% at September 30, 2016. The letter of credit is charged at 1.25% per annum. In July 2016, the Company received $50,000,000 term loan proceeds from Bank of America under the new credit agreement with an interest rate at 1.71% per annum and paid down the outstanding amounts under the revolving line of credit with Bank of America.

- added (2016-11-07):
[0001628280-16-020941:note_history:23]
In June 2016, the Company also entered into a separate credit agreement with Bank of America, which provided for a revolving line of credit of $10,000,000 for the Taiwan subsidiary that matures on June 30, 2017. The interest rate of the revolving line of credit is equal to a minimum of 0.9% per annum plus the lender's cost of funds.

- changed (2016-11-07):
[0001628280-16-020941:note_history:24]
As of September 30, 2016 and June 30, 2016, the total outstanding borrowings under the Bank of America term loan was $47,500,000 and $933,000, respectively. The total outstanding borrowings under the Bank of America lines of credit was $11,199,000 and $62,199,000 as of September 30, 2016 and June 30, 2016, respectively. The interest rates for these loans ranged from 1.08% to 1.77% per annum at September 30, 2016 and from 1.02% to 1.96% per annum at June 30, 2016, respectively. As of September 30, 2016, the amount of the unused revolving lines of credit with Bank of America under the new credit agreements was $53,801,000.
  (was, 2016-05-06, similarity 0.6534):
[0001628280-16-015755:note_history:24]
As of March 31, 2016 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $1,633,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit were $62,199,000 and $59,699,000 as of March 31, 2016 and June 30, 2015, respectively. The interest rates for these loans ranged from 1.00% to 1.94% per annum at March 31, 2016 and from 0.79% to 1.68% per annum at June 30, 2015, respectively. As of March 31, 2016, the unused revolving line of credit with Bank of America was $2,801,000.

- added (2016-11-07):
[0001628280-16-020941:note_history:25]
In October 2016, the Company drew an additional $30,000,000 from Bank of America revolving line of credit with interest rates ranging from 2.14% to 3.75% per annum to support the Company's growth and expansion of its business in the Netherlands.

- changed (2016-11-07):
[0001628280-16-020941:note_history:26]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NTD$1,000,000,000 or $30,340,000 U.S. dollar equivalent. In January 2016, the Company extended the revolving line of credit to mature on March 31, 2016.
  (was, 2016-05-06, similarity 0.9422):
[0001628280-16-015755:note_history:26]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,340,000 U.S. dollar equivalent.

- changed (2016-11-07):
[0001628280-16-020941:note_history:27]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NTD$700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NTD$100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.00% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.
  (was, 2016-05-06, similarity 0.9976):
[0001628280-16-015755:note_history:27]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NT700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NT100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

- added (2016-11-07):
[0001628280-16-020941:note_history:28]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,061,000 and $20,357,000 at September 30, 2016 and June 30, 2016, respectively. At September 30, 2016 and June 30, 2016, the total outstanding borrowings under the CTBC Bank revolving line of credit was $18,800,000 and $10,100,000, respectively, in U.S. dollars. The interest rate for these loans ranged from 0.89% and 1.40% at September 30, 2016 and 0.90% and 1.25% per annum at June 30, 2016. At September 30, 2016, available for future borrowing under this credit agreement was $139,000.

- added (2016-11-07):
[0001628280-16-020941:note_history:29]
The new credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The new credit agreement contains certain financial covenants, including the following:

- changed (2016-11-07):
[0001628280-16-020941:note_history:30]
| • | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items for any two consecutive fiscal quarters; |
  (was, 2016-05-06, similarity 0.8732):
[0001628280-16-015755:note_history:30]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

- added (2016-11-07):
[0001628280-16-020941:note_history:31]
| • | The Consolidated Leverage Ratio, as defined in the agreement, as of the end of any fiscal quarter, measured for the most recently completed twelve (12) months of the Company, shall not be greater than 2.00; |

- changed (2016-11-07):
[0001628280-16-020941:note_history:32]
| • | The domestic unencumbered liquid assets, as defined in the agreement, maintained in accounts within the United States shall have an aggregate market value of not less than $30,000,000, measured quarterly as of the last day of each fiscal quarter. |
  (was, 2016-05-06, similarity 0.6506):
[0001628280-16-015755:note_history:32]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

- added (2016-11-07):
[0001628280-16-020941:note_history:33]
As of September 30, 2016 and June 30, 2016, total assets of $959,924,000 and $934,625,000, respectively, collateralized the line of credit with Bank of America under the new credit agreement, which represent the total assets of the United States headquarter company, except for seven buildings located in San Jose, California and property, plant and equipment and inventory in those buildings. As of September 30, 2016 and June 30, 2016, total assets collateralizing the term loan with Bank of America under the new credit agreement were $82,006,000 and $59,258,000, respectively. As of September 30, 2016, the Company was in compliance with all financial covenants associated with the credit agreements with Bank of America.

- changed (2016-11-07):
[0001628280-16-020941:note_history:34]
As of September 30, 2016 and June 30, 2016, the land and building located in Bade, Taiwan with a value of $26,691,000 and $26,804,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at September 30, 2016.
  (was, 2016-05-06, similarity 0.9291):
[0001628280-16-015755:note_history:34]
As of March 31, 2016 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $26,909,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2016.

- removed (2016-11-07):
[0001628280-16-015755:note_history:35]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.44% at March 31, 2016. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- removed (2016-11-07):
[0001628280-16-015755:note_history:36]
The total outstanding borrowings under the CTBC Bank term loan are denominated in Taiwanese dollars and were translated into U.S. dollars of $20,263,000 and $21,280,000 at March 31, 2016 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit were $9,700,000 in U.S. dollars at March 31, 2016 and June 30, 2015. The interest rate for this loan ranged from 0.92% and 1.06% at March 31, 2016 and 0.82% and 1.16% per annum at June 30, 2015.

- removed (2016-11-07):
[0001628280-16-015755:note_history:37]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

- removed (2016-11-07):
[0001628280-16-015755:note_history:38]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

- removed (2016-11-07):
[0001628280-16-015755:note_history:39]
As of March 31, 2016 and June 30, 2015, total assets of $1,137,023,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of March 31, 2016 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,181,000 and $17,354,000. As of March 31, 2016, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-11-07):
[0001628280-16-015755:note_history:40]
Long-term Investments

- removed (2016-11-07):
[0001628280-16-015755:note_history:41]
As of March 31, 2016 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at March 31, 2016 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.

- removed (2016-11-07):
[0001628280-16-015755:note_history:42]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2016 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.

- removed (2016-11-07):
[0001628280-16-015755:note_history:43]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2016 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of March 31, 2016, the discount rate, the time period until redemption and the estimated rate of return were 1.81%, 3 years and 0.41%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

- removed (2016-11-07):
[0001628280-16-015755:note_history:44]
Based on this assessment of fair value, the Company determined that there was no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2016 and 2015. There was a cumulative total decline of $117,000 as of March 31, 2016 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of March 31, 2016 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

- removed (2016-11-07):
[0001628280-16-015755:note_history:45]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three and nine months ended March 31, 2016 and 2015, there were no auction rate securities redeemed or sold.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001628280-16-020941:note_history:46]
Short-term and long-term obligations as of September 30, 2016 and June 30, 2016 consisted of the following (in thousands):
  (was, 2016-05-06, similarity 0.9545):
[0001628280-16-015755:note_history:46]
Short-term and long-term obligations as of March 31, 2016 and June 30, 2015 consisted of the following (in thousands):

- changed (2016-11-07):
[0001628280-16-020941:note_history:47]
|  | September 30, |  | June 30, |
|  | 2016 |  | 2016 |
| Line of credit: |  |  |  |
| Bank of America (1) | $ | 11,199 |  |  | $ | 62,199 |  |
| CTBC Bank | 18,800 |  |  | 10,100 |  |
| Total line of credit | 29,999 |  |  | 72,299 |  |
| Term loans: |  |  |  |
| Bank of America (1) | 47,500 |  |  | 933 |  |
| CTBC Bank | 21,061 |  |  | 20,357 |  |
| Total term loans | 68,561 |  |  | 21,290 |  |
| Total debt | 98,560 |  |  | 93,589 |  |
| Less: debt issuance costs | (365 | ) |  | — |  |
| Total debt, net of debt issuance costs | 98,195 |  |  | 93,589 |  |
| Current portion, net of debt issuance costs | (60,983 | ) |  | (53,589 | ) |
| Long-term portion, net of debt issuance costs | $ | 37,212 |  |  | $ | 40,000 |  |
  (was, 2016-05-06, similarity 0.796):
[0001628280-16-015755:note_history:47]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 1,633 |  |  | 3,733 |  |
| CTBC Bank | 20,263 |  |  | 21,280 |  |
| Total building term loans | 21,896 |  |  | 25,013 |  |
| Total debt | 93,795 |  |  | 94,412 |  |
| Current portion | (93,795 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |

- added (2016-11-07):
[0001628280-16-020941:note_history:48]
(1) In July 2016, $50,000,000 of the revolving line of credit was refinanced to a five-year term loan under the new credit agreement with Bank of America and was reclassified to long-term loan at September 30, 2016 and June 30, 2016.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001628280-16-020941:note_history:49]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at September 30, 2016.
  (was, 2016-05-06, similarity 0.9908):
[0001628280-16-015755:note_history:49]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.3% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at March 31, 2016.

- changed (2016-11-07):
[0001628280-16-020941:note_history:50]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $50,205,000 and $59,261,000, and sold products to Ablecom totaling $3,342,000 and $5,220,000 for the three months ended September 30, 2016 and 2015, respectively.
  (was, 2016-05-06, similarity 0.7132):
[0001628280-16-015755:note_history:50]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $55,133,000 and $185,845,000, and sold products to Ablecom totaling $4,413,000 and $12,125,000 for the three and nine months ended March 31, 2016, respectively. The Company purchased products from Ablecom totaling $58,002,000 and $169,918,000, and sold products to Ablecom totaling $6,067,000 and $43,524,000 for the three and nine months ended March 31, 2015, respectively.

- changed (2016-11-07):
[0001628280-16-020941:note_history:51]
Amounts owed to the Company by Ablecom as of September 30, 2016 and June 30, 2016 were $7,251,000 and $4,678,000, respectively. Amounts owed to Ablecom by the Company as of September 30, 2016 and June 30, 2016 were $38,290,000 and $39,152,000, respectively. For the three months ended September 30, 2016, the Company paid Ablecom the majority of invoiced dollars between 47 and 77 days of invoice date. For the three months ended September 30, 2016 and 2015, the Company paid $1,745,000 and $1,162,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2016-05-06, similarity 0.7473):
[0001628280-16-015755:note_history:51]
Amounts owed to the Company by Ablecom as of March 31, 2016 and June 30, 2015 were $6,034,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2016 and June 30, 2015 were $45,357,000 and $59,015,000, respectively. For the three and nine months ended March 31, 2016, the Company paid Ablecom the majority of invoiced dollars between 34 and 88 days of invoice date. For the three and nine months ended March 31, 2016, the Company paid $3,003,000 and $5,901,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2015, the Company paid $231,000 and $4,728,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2016-11-07):
[0001628280-16-020941:note_history:52]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $77,369,000 and $62,782,000 at September 30, 2016 and June 30, 2016, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2016-05-06, similarity 0.9908):
[0001628280-16-015755:note_history:52]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $65,227,000 and $67,261,000 at March 31, 2016 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2016-11-07):
[0001628280-16-020941:note_history:53]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three months ended September 30, 2016 and 2015, $5,000 and $2,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2016-05-06, similarity 0.8854):
[0001628280-16-015755:note_history:53]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2016, $13,000 and $9,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2015, $4,000 and $(3,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
