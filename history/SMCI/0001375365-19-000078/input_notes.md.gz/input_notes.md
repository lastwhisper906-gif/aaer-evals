# SMCI notes — 0001375365-19-000078


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-19-000078:notes:1]
Commitments and Contingencies

[0001375365-19-000078:notes:2]
Litigation and Claims— In February 2018, the Company became a party to legal proceedings whereby complainants have alleged that it has violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions. In July 2019, the Company filed a motion to dismiss which remains pending. See Note 12, "Subsequent Events" for further details. From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001375365-19-000078:notes:3]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-19-000078:notes:4]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2019, these remaining noncancelable commitments were $262.8 million, including $95.6 million for related parties.

[0001375365-19-000078:notes:5]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001375365-19-000078:notes:6]
[same as prior period, unchanged from 0001375365-19-000077:notes:6]

[0001375365-19-000078:notes:7]
[same as prior period, unchanged from 0001375365-19-000077:notes:7]

[0001375365-19-000078:notes:8]
[same as prior period, unchanged from 0001375365-19-000077:notes:8]


## us-gaap:ConsolidationPolicyTextBlock

[0001375365-19-000078:notes:9]
[same as prior period, unchanged from 0001375365-19-000077:notes:9]

[0001375365-19-000078:notes:10]
[same as prior period, unchanged from 0001375365-19-000077:notes:10]

[0001375365-19-000078:notes:11]
[same as prior period, unchanged from 0001375365-19-000077:notes:11]

[0001375365-19-000078:notes:12]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2019.


## us-gaap:DebtDisclosureTextBlock

[0001375365-19-000078:notes:13]
Short-term Debt

[0001375365-19-000078:notes:14]
Short-term debt obligations as of March 31, 2019 and June 30, 2018 consisted of the following (in thousands):

[0001375365-19-000078:notes:15]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | — |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,660 |  |  | 22,935 |  |
| Total short-term debt | $ | 22,660 |  |  | $ | 116,181 |  |

[0001375365-19-000078:notes:16]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000078:notes:17]
Bank of America

[0001375365-19-000078:notes:18]
2016 Bank of America Credit Facility

[0001375365-19-000078:notes:19]
In June 2016, the Company entered into a credit agreement with Bank of America (the “2016 Bank of America Credit Facility”). Prior to its maturity in April 2018, the Company repaid and terminated the 2016 Bank of America Credit Facility using the proceeds from its 2018 Bank of America Credit Facility (defined below). Immediately prior to its termination, the 2016 Bank of America Credit Facility (giving effect to all amendments since the inception of the 2016 Bank of America Credit Facility), provided for (i) a $85.0 million revolving line of credit including a $5.0 million letter of credit sublimit (ii) a $20.0 million revolving line of credit for the Company's Taiwan and the Netherlands entities, and (iii) a five-year $50.0 million term loan. The 2016 Bank of America Credit Facility term loan was secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan were payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the $85.0 million revolving line of credit was at the LIBOR rate plus 1.25% per annum. The interest rate of the $20.0 million revolving line of credit was equal to a minimum of 0.9% per annum plus the lender's cost of funds, as defined in the agreements.

[0001375365-19-000078:notes:20]
2018 Bank of America Credit Facility

[0001375365-19-000078:notes:21]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

[0001375365-19-000078:notes:22]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility. The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

[0001375365-19-000078:notes:23]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000078:notes:24]
As of March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $0.0 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2019 and June 30, 2018 were 5.25% per annum and 4.75% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.7 million and $2.8 million as of March 31, 2019 and June 30, 2018, respectively. As of March 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000078:notes:25]
CTBC Bank

[0001375365-19-000078:notes:26]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD$100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. The Company extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000078:notes:27]
In May 2017, the Company renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, the Company entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

[0001375365-19-000078:notes:28]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000078:notes:29]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000078:notes:30]
The total outstanding borrowings under the 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.7 million and $22.9 million at March 31, 2019 and June 30, 2018, respectively. At March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $0.0 million and $25.9 million, respectively, in U.S. dollars. The interest rate for these loans was 0.92% and 0.95% as of March 31, 2019 and June 30, 2018, respectively. At March 31, 2019, the amount available for future borrowing under the 2018 CTBC Credit Facility was $17.3 million. As of March 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2018 CTBC Credit Facility term loan was $26.0 million.

[0001375365-19-000078:notes:31]
Covenant Compliance

[0001375365-19-000078:notes:32]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000078:notes:33]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company is required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

[0001375365-19-000078:notes:34]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-19-000078:notes:35]
[same as prior period, unchanged from 0001375365-19-000077:notes:35]

[0001375365-19-000078:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 592,783 |  |  | 79.7 | % |  | $ | 669,114 |  |  | 80.1 | % |  | $ | 2,161,321 |  |  | 81.7 | % |  | $ | 1,841,218 |  |  | 77.4 | % |
| Subsystems and accessories | 150,716 |  |  | 20.3 | % |  | 165,996 |  |  | 19.9 | % |  | 484,805 |  |  | 18.3 | % |  | 537,612 |  |  | 22.6 | % |
| Total | $ | 743,499 |  |  | 100.0 | % |  | $ | 835,110 |  |  | 100.0 | % |  | $ | 2,646,126 |  |  | 100.0 | % |  | $ | 2,378,830 |  |  | 100.0 | % |

[0001375365-19-000078:notes:37]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-19-000078:notes:38]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2019 and 2018, of net sales by geographic region (in thousands):

[0001375365-19-000078:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 436,734 |  |  | $ | 455,021 |  |  | $ | 1,516,262 |  |  | $ | 1,317,175 |  |
| Europe | 128,789 |  |  | 150,319 |  |  | 472,325 |  |  | 392,797 |  |
| Asia | 146,120 |  |  | 188,101 |  |  | 549,296 |  |  | 561,807 |  |
| Others | 31,856 |  |  | 41,669 |  |  | 108,243 |  |  | 107,051 |  |
|  | $ | 743,499 |  |  | $ | 835,110 |  |  | $ | 2,646,126 |  |  | $ | 2,378,830 |  |

[0001375365-19-000078:notes:40]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:

[0001375365-19-000078:notes:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 over 2018 |  | 2019 |  | 2018 |  | 2019 over 2018 |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-19-000078:notes:42]
[same as prior period, unchanged from 0001375365-19-000077:notes:41]

[0001375365-19-000078:notes:43]
[same as prior period, unchanged from 0001375365-19-000077:notes:42]

[0001375365-19-000078:notes:44]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of the date the 2016 Plan became effective, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006 Plan"). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards have been or will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan at the time the 2016 Plan became effective, if those awards were or are forfeited at any time after the 2016 Plan became effective, will become available for use under the 2016 Plan. At the time the 2016 Plan became effective, all remaining ungranted shares under the 2006 Plan were canceled. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. Under the 2016 Plan, the Company granted PRSUs to its Chief Executive Officer, 50% of which vest based on the achievement of certain performance metrics at the end of the performance period while the remainder vest in equal amounts over the following ten quarters provided he continues to be employed by the Company. As of March 31, 2019, the Company had 1,193,710 authorized shares available for future issuance under the 2016 Plan.

[0001375365-19-000078:notes:45]
[same as prior period, unchanged from 0001375365-19-000077:notes:44]

[0001375365-19-000078:notes:46]
[same as prior period, unchanged from 0001375365-19-000077:notes:45]

[0001375365-19-000078:notes:47]
[same as prior period, unchanged from 0001375365-19-000077:notes:46]

[0001375365-19-000078:notes:48]
[same as prior period, unchanged from 0001375365-19-000077:notes:47]

[0001375365-19-000078:notes:49]
[same as prior period, unchanged from 0001375365-19-000077:notes:48]

[0001375365-19-000078:notes:50]
[same as prior period, unchanged from 0001375365-19-000077:notes:49]

[0001375365-19-000078:notes:51]
The fair value of stock option grants for the three and nine months ended March 31, 2019 and 2018 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-19-000078:notes:52]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Risk-free interest rate | 2.56 | % |  | 2.47 | % |  | 2.56% - 2.97% |  |  | 1.92% - 2.47% |  |
| Expected term | 6.05 years |  |  | 5.82 years |  |  | 6.05 years |  |  | 5.82 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 50.25 | % |  | 47.39 | % |  | 47.34% - 50.25% |  |  | 45.32% - 48.07% |  |
| Weighted-average fair value | $ | 7.55 |  |  | $ | 10.79 |  |  | $ | 8.56 |  |  | $ | 11.45 |  |

[0001375365-19-000078:notes:53]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2019 and 2018 (in thousands):

[0001375365-19-000078:notes:54]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of sales | $ | 390 |  |  | $ | 449 |  |  | $ | 1,256 |  |  | $ | 1,362 |  |
| Research and development | 3,107 |  |  | 3,494 |  |  | 9,816 |  |  | 10,412 |  |
| Sales and marketing | 418 |  |  | 482 |  |  | 1,359 |  |  | 1,545 |  |
| General and administrative | 1,045 |  |  | 1,663 |  |  | 3,650 |  |  | 5,330 |  |
| Stock-based compensation expense before taxes | 4,960 |  |  | 6,088 |  |  | 16,081 |  |  | 18,649 |  |
| Income tax impact | (1,016 | ) |  | (1,506 | ) |  | (3,339 | ) |  | (5,385 | ) |
| Stock-based compensation expense, net | $ | 3,944 |  |  | $ | 4,582 |  |  | $ | 12,742 |  |  | $ | 13,264 |  |

[0001375365-19-000078:notes:55]
As of March 31, 2019, $6.6 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.54 years, $28.3 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.66 years and $0.4 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 1.75 years.

[0001375365-19-000078:notes:56]
[same as prior period, unchanged from 0001375365-19-000077:notes:55]

[0001375365-19-000078:notes:57]
The following table summarizes stock option activity during the nine months ended March 31, 2019 under all plans:

[0001375365-19-000078:notes:58]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |
| Balance as of June 30, 2018 |  | 8,301,138 |  |  | $ | 16.50 |  |  |  |
| Granted |  | 321,920 |  |  | $ | 17.24 |  |  |  |
| Exercised |  | — |  |  | $ | — |  |  |  |
| Forfeited/Cancelled |  | (1,110,289 | ) |  | $ | 9.61 |  |  |  |
| Balance as of March 31, 2019 |  | 7,512,769 |  |  | $ | 17.55 |  |  | 3.84 |
| Options vested and exercisable at March 31, 2019 |  | 6,769,528 |  |  | $ | 17.13 |  |  | 3.32 |

[0001375365-19-000078:notes:59]
[same as prior period, unchanged from 0001375365-19-000077:notes:58]

[0001375365-19-000078:notes:60]
[same as prior period, unchanged from 0001375365-19-000077:notes:59]

[0001375365-19-000078:notes:61]
[same as prior period, unchanged from 0001375365-19-000077:notes:60]

[0001375365-19-000078:notes:62]
[same as prior period, unchanged from 0001375365-19-000077:notes:61]

[0001375365-19-000078:notes:63]
The following table summarizes RSUs and PRSUs activity during the nine months ended March 31, 2019 under all plans:

[0001375365-19-000078:notes:64]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2018 | 1,480,605 |  |  | $ | 23.34 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Granted | 738,880 |  |  | $ | 16.46 |  |  | — |  |  |  |  |
| Released (2) | (439,379 | ) |  | $ | 24.83 |  |  | — |  |  |  |  |
| Forfeited | (114,018 | ) |  | $ | 20.76 |  |  | — |  |  |  |  |
| Balance as of March 31, 2019 | 1,666,088 |  |  | $ | 20.08 |  |  | 120,000 |  |  |  | $ | 27.10 |  |

[0001375365-19-000078:notes:65]
[same as prior period, unchanged from 0001375365-19-000077:notes:64]

[0001375365-19-000078:notes:66]
[same as prior period, unchanged from 0001375365-19-000077:notes:65]

[0001375365-19-000078:notes:67]
| (2) | The number of shares released excludes 101,952 RSUs that were vested but not released as of March 31, 2019. The number of shares released excludes 78,000 PRSUs that were vested but not released as of March 31, 2019, of which 60,000 PRSUs were vested as of June 30, 2018. These vested RSUs and PRSUs will be released upon the effectiveness of the Company's Registration Statement on Form S-8. |


## us-gaap:EarningsPerShareTextBlock

[0001375365-19-000078:notes:68]
[same as prior period, unchanged from 0001375365-19-000077:notes:67]

[0001375365-19-000078:notes:69]
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2019 and 2018 (in thousands, except per share amounts):

[0001375365-19-000078:notes:70]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 10,646 |  |  | $ | 14,595 |  |  | $ | 48,208 |  |  | $ | 19,891 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 49,988 |  |  | 49,425 |  |  | 49,845 |  |  | 49,285 |  |
| Effect of dilutive securities | 1,570 |  |  | 2,254 |  |  | 1,712 |  |  | 2,805 |  |
| Weighted-average diluted shares | 51,558 |  |  | 51,679 |  |  | 51,557 |  |  | 52,090 |  |
| Basic net income per common share | $ | 0.21 |  |  | $ | 0.30 |  |  | $ | 0.97 |  |  | $ | 0.40 |  |
| Diluted net income per common share | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.94 |  |  | $ | 0.38 |  |

[0001375365-19-000078:notes:71]
For the three and nine months ended March 31, 2019 and 2018, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 4,443,127 and 4,194,283 for the three and nine months ended March 31, 2019, respectively, and 3,241,873 and 2,302,333 for the three and nine months ended March 31, 2018, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001375365-19-000078:notes:72]
The following table sets forth the Company’s cash equivalents, certificates of deposit and investment in an auction rate security as of March 31, 2019 and June 30, 2018 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-19-000078:notes:73]
| March 31, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,149 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,149 |  |
| Certificates of deposit (2) | — |  |  | 30,788 |  |  | — |  |  | 30,788 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,149 |  |  | $ | 30,788 |  |  | $ | 1,571 |  |  | $ | 33,508 |  |
| June 30, 2018 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,136 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,136 |  |
| Certificates of deposit (2) | — |  |  | 30,219 |  |  | — |  |  | 30,219 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,136 |  |  | $ | 30,219 |  |  | $ | 1,571 |  |  | $ | 32,926 |  |

[0001375365-19-000078:notes:74]
(1) $0.3 million and $0.3 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2019 and June 30, 2018, respectively.

[0001375365-19-000078:notes:75]
(2) $29.7 million and $29.2 million in certificates of deposit are included in cash and cash equivalents and $1.1 million and $1.0 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2019 and June 30, 2018, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001375365-19-000078:notes:76]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of auction rate securities, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2019 and 2018 (in thousands):

[0001375365-19-000078:notes:77]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Balance as of the beginning of the period | $ | 1,571 |  |  | $ | 2,571 |  |  | $ | 1,571 |  |  | $ | 2,625 |  |
| Sales and settlements at par | — |  |  | (1,000 | ) |  | — |  |  | (1,000 | ) |
| Total unrealized loss included in other comprehensive income | — |  |  | — |  |  | — |  |  | (54 | ) |
| Balance as of the end of the period | $ | 1,571 |  |  | $ | 1,571 |  |  | $ | 1,571 |  |  | $ | 1,571 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-19-000078:notes:78]
[same as prior period, unchanged from 0001375365-19-000077:notes:77]

[0001375365-19-000078:notes:79]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and other assets. The Company classifies its cash equivalents and other assets, except for its investment in an auction rate security within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2019 and June 30, 2018. The Company used discounted cash flows to estimate the fair value of the auction rate security as of March 31, 2019 and June 30, 2018. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-19-000078:notes:80]
[same as prior period, unchanged from 0001375365-19-000077:notes:79]

[0001375365-19-000078:notes:81]
The above table excludes $139.7 million and $85.9 million of cash included in cash and cash equivalents, $17.2 million and $2.8 million of restricted cash included in prepaid expenses and other current assets, and $0.4 million and $0.4 million of restricted cash, non-current included in other assets in the condensed consolidated balance sheets as of March 31, 2019 and June 30, 2018, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and nine months ended March 31, 2019 and 2018.

[0001375365-19-000078:notes:82]
The following is a summary of the Company’s investment in an auction rate security as of March 31, 2019 and June 30, 2018 (in thousands):

[0001375365-19-000078:notes:83]
|  | March 31, 2019 and June 30, 2018 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-19-000078:notes:84]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2019 and June 30, 2018, total debt of $22.7 million and $116.2 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-19-000078:notes:85]
[same as prior period, unchanged from 0001375365-19-000077:notes:84]

[0001375365-19-000078:notes:86]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values. Prior to July 1, 2018, the Company accounted for its investment in non-marketable equity securities at cost less impairment. Realized gains and losses on non-marketable equity securities sold or impaired were recognized in other income (expense), net. Upon adoption of the new guidance, Financial Instruments - Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, on July 1, 2018, the Company classifies its investment in non-marketable equity instruments as Level 3 as the fair value is determined using significant unobservable inputs. During the three and nine months ended March 31, 2019 the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities. During the three months ended March 31, 2019, the Company recorded impairment charges of $0.7 million for its non-marketable equity securities which had an initial cost basis of $0.7 million as it was determined the carrying value of the investments were not recoverable. For the three and nine months ended March 31, 2018, the Company did not record any other-than-temporary impairments on financial assets required to be measured at fair value on a nonrecurring basis.

[0001375365-19-000078:notes:87]
There were no transfers of financial assets measured on a non-recurring basis between Level 1, Level 2 or Level 3 securities during the three and nine months ended March 31, 2019 and 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-19-000078:notes:88]
[same as prior period, unchanged from 0001375365-19-000077:notes:87]

[0001375365-19-000078:notes:89]
The Company recorded provisions for income taxes of $0.5 million and $10.5 million for three and nine months ended March 31, 2019, respectively, and $4.2 million and $25.7 million for the three and nine months ended March 31, 2018, respectively. The effective tax rate was 4.3% and 16.9% for the three and nine months ended March 31, 2019, respectively, and 21.4% and 53.5% for the three and nine months ended March 31, 2018, respectively. The effective tax rates for the three and nine months ended March 31, 2019 were lower than the statutory tax rate of 21%, primarily due to releases of unrecognized tax benefits as a result of lapse of statute of limitations. The effective tax rates for the three and nine months ended March 31, 2018 were higher than that for the three and nine months ended March 31, 2019, primarily due to a one-time $12.9 million write down of U.S. deferred tax assets and liabilities, and a one-time transition tax of $2.8 million, as a result of the 2017 Tax Reform Act.

[0001375365-19-000078:notes:90]
As of March 31, 2019, the Company had a liability for gross unrecognized tax benefits of $26.3 million, substantially all of which, if recognized, would affect the Company's effective tax rate. During the nine months ended March 31, 2019, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2019, the Company had accrued $1.5 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-19-000078:notes:91]
[same as prior period, unchanged from 0001375365-19-000077:notes:90]

[0001375365-19-000078:notes:92]
[same as prior period, unchanged from 0001375365-19-000077:notes:91]

[0001375365-19-000078:notes:93]
[same as prior period, unchanged from 0001375365-19-000077:notes:92]

[0001375365-19-000078:notes:94]
[same as prior period, unchanged from 0001375365-19-000077:notes:93]

[0001375365-19-000078:notes:95]
[same as prior period, unchanged from 0001375365-19-000077:notes:94]

[0001375365-19-000078:notes:96]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made as or the underlying matters are settled or otherwise resolved.

[0001375365-19-000078:notes:97]
The federal statute of limitations remains open in general for tax years ended June 30, 2016 through 2019. Various states statute of limitations remain open in general for tax years ended June 30, 2015 through 2019. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2013 through 2019. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months, except for the reductions arising from the lapse of the statute of limitations. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.0 million in the next 12 months, primarily due to the lapse of the statute of limitations and settlement with the Tax Authorities. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0001375365-19-000078:notes:98]
[same as prior period, unchanged from 0001375365-19-000077:notes:97]

[0001375365-19-000078:notes:99]
[same as prior period, unchanged from 0001375365-19-000077:notes:98]


## us-gaap:InventoryPolicyTextBlock

[0001375365-19-000078:notes:100]
[same as prior period, unchanged from 0001375365-19-000077:notes:99]

[0001375365-19-000078:notes:101]
[same as prior period, unchanged from 0001375365-19-000077:notes:100]

[0001375365-19-000078:notes:102]
[same as prior period, unchanged from 0001375365-19-000077:notes:101]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001375365-19-000078:notes:103]
Accounting Pronouncements Recently Adopted

[0001375365-19-000078:notes:104]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance,ASC 606, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to ASC 606. The Company adopted ASC 606 on July 1, 2018 using the modified retrospective method. In connection with the adoption of ASC 606, the Company recorded a transition adjustment to increase retained earnings by $6.8 million as of July 1, 2018. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

[0001375365-19-000078:notes:105]
The primary impact of the adoption of ASC 606 was the acceleration of revenue recognition for (i) sales to distributors where the Company previously accounted for such sales on a sell-through basis and (ii) software arrangements. The following tables summarize the impacts of the adoption of ASC 606 on the Company’s condensed consolidated financial statements. The adoption of ASC 606 did not have any impact on the net cash provided by operating activities.

[0001375365-19-000078:notes:106]
Selected Captions from the Condensed Consolidated Balance Sheet as of March 31, 2019 (in thousands)

[0001375365-19-000078:notes:107]
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| ASSETS |  |  |  |  |  |
| Accounts receivable, net of allowances | $ | 327,366 |  |  | $ | (17,367 | ) |  | $ | 309,999 |  |
| Inventories | 761,113 |  |  | 11,808 |  |  | 772,921 |  |
| Prepaid expenses and other current assets | 97,857 |  |  | (1,916 | ) |  | 95,941 |  |
| Deferred income taxes, net | 33,776 |  |  | 1,558 |  |  | 35,334 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Accrued liabilities | $ | 112,951 |  |  | $ | (4,655 | ) |  | $ | 108,296 |  |
| Deferred revenue | 87,746 |  |  | 653 |  |  | 88,399 |  |
| Income taxes payable | 8,729 |  |  | 71 |  |  | 8,800 |  |
| Deferred revenue, non-current | 105,584 |  |  | 2,783 |  |  | 108,367 |  |
| Retained earnings | 588,193 |  |  | (4,769 | ) |  | 583,424 |  |

[0001375365-19-000078:notes:108]
Selected Captions from the Condensed Consolidated Statement of Operations for the Three and Nine Months ended March 31, 2019 (in thousands)

[0001375365-19-000078:notes:109]
|  | Three Months Ended March 31, 2019 |  | Nine Months Ended March 31, 2019 |
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Net sales | $ | 743,499 |  |  | $ | (1,621 | ) |  | $ | 741,878 |  |  | $ | 2,646,126 |  |  | $ | 18,449 |  |  | $ | 2,664,575 |  |
| Cost of sales | 631,172 |  |  | (403 | ) |  | 630,769 |  |  | 2,282,638 |  |  | 18,995 |  |  | 2,301,633 |  |
| Gross profit | 112,327 |  |  | (1,218 | ) |  | 111,109 |  |  | 363,488 |  |  | (546 | ) |  | 362,942 |  |
| General and administrative | 36,174 |  |  | (1,626 | ) |  | 34,548 |  |  | 106,214 |  |  | (2,662 | ) |  | 103,552 |  |
| Income before income tax provision | 11,502 |  |  | 408 |  |  | 11,910 |  |  | 62,320 |  |  | 2,116 |  |  | 64,436 |  |
| Income tax provision | 497 |  |  | (244 | ) |  | 253 |  |  | 10,540 |  |  | 71 |  |  | 10,611 |  |
| Net income | 10,646 |  |  | 652 |  |  | 11,298 |  |  | 48,208 |  |  | 2,045 |  |  | 50,253 |  |

[0001375365-19-000078:notes:110]
In January 2016, the FASB issued new guidance, Financial Instruments - Overall: Recognition and Measurement of Financial Assets and Financial Liabilities. This guidance changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of equity investments not accounted for under the equity method to be recorded at fair value through the consolidated statement of operations at the end of each reporting period.  The Company adopted this accounting standard update as of July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements. As a result of the adoption of the new standard, the Company’s equity investments are accounted for as follows:

[0001375365-19-000078:notes:111]
| • | Marketable equity securities that have a readily determinable fair value are measured and recorded at fair value. |

[0001375365-19-000078:notes:112]
| • | Non-marketable equity securities that do not have a readily determinable fair value and for which the Company does not control the investee nor is it able to exert significant influence over the investee are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. |

[0001375365-19-000078:notes:113]
| • | Equity method investments are equity securities for which the Company does not control the investee but is able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus the Company's share of equity method investee income or loss. |

[0001375365-19-000078:notes:114]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated statements of cash flows.

[0001375365-19-000078:notes:115]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements and related disclosures.

[0001375365-19-000078:notes:116]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The Company adopted the accounting guidance on July 1, 2018 using a retrospective transition method to each period presented. The adoption did not have a material impact on the consolidated statements of cash flows. Presentation of prior period information has been retrospectively adjusted.

[0001375365-19-000078:notes:117]
In February 2017, the FASB issued new accounting guidance, Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets: Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets. This guidance clarifies the scope and application on the sale or transfer of nonfinancial assets and in substance nonfinancial assets to noncustomers, including partial sales. The Company adopted this guidance on July 1, 2018. Prior to adoption, the Company had previously contributed certain technology rights in exchange for 30% ownership in a privately-held company (the “Corporate Venture”) and accounted for the transaction in accordance with the guidance related to exchanges of a nonfinancial asset for a noncontrolling ownership interest in ASC 845 - Nonmonetary Transactions, which has been eliminated by the new guidance. As a result of the adoption of the new guidance, the Company recognized $3.0 million increase in the carrying value of the equity-method investment, a $2.1 million increase in deferred gain, and a $0.9 million increase in retained earnings.

[0001375365-19-000078:notes:118]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018. The SEC staff subsequently indicated that it would not object if a filer’s first presentation of changes in stockholders’ equity is included in its Form 10-Q for the quarter that begins after the final rule’s effective date. Among the amendments is the requirement to present the changes in stockholders’ equity in the interim financial statements (either in a separate statement or footnote) in Quarterly Reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The Company adopted this guidance in the first quarter of fiscal year 2019.

[0001375365-19-000078:notes:119]
Accounting Pronouncements Not Yet Adopted

[0001375365-19-000078:notes:120]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. Since its issuance, the FASB has issued several amendments to the new lease standard. The standard is effective for the Company from July 1, 2019 and the Company will apply this standard using the modified retrospective approach and will not restate prior comparative periods.  The Company will elect the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new standard its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease guidance. While the Company is currently finalizing its implementation of new policies, processes and internal controls to comply with the new rules, it is anticipated that the adoption of the new standard will result in the recognition of right-of-use assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, as of July 1, 2019, primarily related to real estate leases. The adoption of the new standard will not have a material impact on the Company’s consolidated statement of operations or consolidated statement of cash flows.

[0001375365-19-000078:notes:121]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000078:notes:122]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election and is effective for the Company from July 1, 2019. The adoption of the guidance will not have a material impact on its consolidated financial statements.

[0001375365-19-000078:notes:123]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The new amendment is effective for the Company from July 1, 2019. The adoption of the new standard will not have a material impact on its consolidated financial statements and related disclosures.

[0001375365-19-000078:notes:124]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the Concepts Statement, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

[0001375365-19-000078:notes:125]
In August 2018, the FASB issued amended guidance to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-19-000078:notes:126]
[same as prior period, unchanged from 0001375365-19-000077:notes:125]

[0001375365-19-000078:notes:127]
[same as prior period, unchanged from 0001375365-19-000077:notes:126]

[0001375365-19-000078:notes:128]
[same as prior period, unchanged from 0001375365-19-000077:notes:127]

[0001375365-19-000078:notes:129]
[same as prior period, unchanged from 0001375365-19-000077:notes:128]

[0001375365-19-000078:notes:130]
[same as prior period, unchanged from 0001375365-19-000077:notes:129]

[0001375365-19-000078:notes:131]
[same as prior period, unchanged from 0001375365-19-000077:notes:130]

[0001375365-19-000078:notes:132]
[same as prior period, unchanged from 0001375365-19-000077:notes:131]

[0001375365-19-000078:notes:133]
[same as prior period, unchanged from 0001375365-19-000077:notes:132]

[0001375365-19-000078:notes:134]
[same as prior period, unchanged from 0001375365-19-000077:notes:133]

[0001375365-19-000078:notes:135]
[same as prior period, unchanged from 0001375365-19-000077:notes:134]

[0001375365-19-000078:notes:136]
[same as prior period, unchanged from 0001375365-19-000077:notes:135]

[0001375365-19-000078:notes:137]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-19-000078:notes:138]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

[0001375365-19-000078:notes:139]
[same as prior period, unchanged from 0001375365-19-000077:notes:138]

[0001375365-19-000078:notes:140]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2019 and June 30, 2018, the Company's equity investment in the Corporate Venture was $1.4 million and $2.4 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $0.4 million and $0.7 million for the three months ended March 31, 2019 and 2018, respectively, and $3.6 million and $2.5 million for the nine months ended March 31, 2019 and 2018, respectively.

[0001375365-19-000078:notes:141]
[same as prior period, unchanged from 0001375365-19-000077:notes:140]

[0001375365-19-000078:notes:142]
As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of March 31, 2019 and June 30, 2018, the Company had unamortized deferred gain balance of $2.0 million and $1.4 million, respectively, in accrued liabilities and $3.5 million and $3.5 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-19-000078:notes:143]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2019 and March 31, 2018, respectively.

[0001375365-19-000078:notes:144]
Additionally, the Company sold products worth $13.7 million and $3.1 million to the Corporate Venture in the three months ended March 31, 2019 and March 31, 2018, respectively, and $35.2 million and $14.5 million in the nine months ended March 31, 2019 and March 31, 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2019 and June 30, 2018 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $11.6 million and $2.9 million due from the Corporate Venture in accounts receivable, net as of March 31, 2019 and June 30, 2018, respectively, in its condensed consolidated balance sheets.

[0001375365-19-000078:notes:145]
[same as prior period, unchanged from 0001375365-19-000077:notes:144]

[0001375365-19-000078:notes:146]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 26.9% of total purchases for the three months ended March 31, 2019 and 2018, respectively, and 21.2% and 26.2% for the nine months ended March 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 8, "Related Party Transactions," accounted for 9.9% and 8.6% of total cost of sales for the three months ended March 31, 2019 and 2018, respectively, and 9.4% and 9.2% for the nine months ended March 31, 2019 and 2018, respectively.

[0001375365-19-000078:notes:147]
[same as prior period, unchanged from 0001375365-19-000077:notes:146]

[0001375365-19-000078:notes:148]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2019 and 2018. No country other than the United States accounted for 10% or more of the net sales in the three and nine months ended March 31, 2019. No country other than the United States accounted for 10% or more of the net sales in the three months ended March 31, 2018, whereas the United States and China accounted for 55.4% and 11.4%, respectively, of the net sales in the nine months ended March 31, 2018. One customer accounted for 14.9% of the Company's accounts receivable, net as of March 31, 2019, and one customer accounted for 11.6% of the Company's accounts receivable, net as of June 30, 2018.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001375365-19-000078:notes:149]
[same as prior period, unchanged from 0001375365-19-000077:notes:148]

[0001375365-19-000078:notes:150]
|  | March 31, 2019 |  | June 30, 2018 |
| Accrued unrecognized tax benefits including related interest and penalties | $ | 17,926 |  |  | $ | 17,872 |  |
| Accrued warranty costs, non-current | 2,316 |  |  | 2,295 |  |
| Others | 4,199 |  |  | 4,398 |  |
| Total other long-term liabilities | $ | 24,441 |  |  | $ | 24,565 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001375365-19-000078:notes:151]
[same as prior period, unchanged from 0001375365-19-000077:notes:150]

[0001375365-19-000078:notes:152]
|  | March 31, 2019 |  | June 30, 2018 |
| Buildings | $ | 86,136 |  |  | $ | 88,689 |  |
| Machinery and equipment | 78,666 |  |  | 71,081 |  |
| Land | 74,922 |  |  | 74,919 |  |
| Building and leasehold improvements | 22,018 |  |  | 18,760 |  |
| Furniture and fixtures | 19,957 |  |  | 18,475 |  |
| Software | 18,046 |  |  | 15,522 |  |
| Buildings construction in progress (1) | 7,930 |  |  | 1,779 |  |
|  | 307,675 |  |  | 289,225 |  |
| Accumulated depreciation and amortization | (104,233 | ) |  | (92,594 | ) |
| Property, plant and equipment, net | $ | 203,442 |  |  | $ | 196,631 |  |

[0001375365-19-000078:notes:153]
[same as prior period, unchanged from 0001375365-19-000077:notes:152]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-19-000078:notes:154]
Related Party Transactions

[0001375365-19-000078:notes:155]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang owned approximately 0.4% of the Company's common stock as of June 30, 2017, but owned no shares as of June 30, 2018 and thereafter. As of March 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of March 31, 2019. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-19-000078:notes:156]
Dealings with Ablecom

[0001375365-19-000078:notes:157]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-19-000078:notes:158]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.0% and 97.6% of the chassis included in the products sold by the Company during the three months ended March 31, 2019 and 2018, respectively; and approximately 95.5% and 97.7% of the chassis included in the products sold by the Company during the nine months ended March 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-19-000078:notes:159]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-19-000078:notes:160]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $28.3 million and $39.3 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-19-000078:notes:161]
Dealings with Compuware

[0001375365-19-000078:notes:162]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-19-000078:notes:163]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-19-000078:notes:164]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-19-000078:notes:165]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-19-000078:notes:166]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $67.3 million and $111.7 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-19-000078:notes:167]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2019, and 2018, are as follows (in thousands):

[0001375365-19-000078:notes:168]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 29,372 |  |  | $ | 37,405 |  |  | $ | 110,290 |  |  | $ | 107,644 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,846 |  |  | $ | 14,528 |  |  | $ | 13,628 |  |  | $ | 31,645 |  |
| Purchases (1) | 34,140 |  |  | 27,969 |  |  | 111,629 |  |  | 91,925 |  |

[0001375365-19-000078:notes:169]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-19-000078:notes:170]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2019 and 2018.

[0001375365-19-000078:notes:171]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2019 and June 30, 2018 (in thousands):

[0001375365-19-000078:notes:172]
|  | March 31, 2019 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,950 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 26,925 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 8,588 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 33,109 |  |  | 45,617 |  |

[0001375365-19-000078:notes:173]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and nine months ended March 31, 2019 and 2018.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-19-000078:notes:174]
[same as prior period, unchanged from 0001375365-19-000077:notes:174]

[0001375365-19-000078:notes:175]
[same as prior period, unchanged from 0001375365-19-000077:notes:175]

[0001375365-19-000078:notes:176]
[same as prior period, unchanged from 0001375365-19-000077:notes:176]

[0001375365-19-000078:notes:177]
[same as prior period, unchanged from 0001375365-19-000077:notes:177]

[0001375365-19-000078:notes:178]
[same as prior period, unchanged from 0001375365-19-000077:notes:178]

[0001375365-19-000078:notes:179]
[same as prior period, unchanged from 0001375365-19-000077:notes:179]

[0001375365-19-000078:notes:180]
[same as prior period, unchanged from 0001375365-19-000077:notes:180]

[0001375365-19-000078:notes:181]
[same as prior period, unchanged from 0001375365-19-000077:notes:181]

[0001375365-19-000078:notes:182]
[same as prior period, unchanged from 0001375365-19-000077:notes:182]

[0001375365-19-000078:notes:183]
[same as prior period, unchanged from 0001375365-19-000077:notes:183]

[0001375365-19-000078:notes:184]
[same as prior period, unchanged from 0001375365-19-000077:notes:184]

[0001375365-19-000078:notes:185]
[same as prior period, unchanged from 0001375365-19-000077:notes:185]

[0001375365-19-000078:notes:186]
[same as prior period, unchanged from 0001375365-19-000077:notes:186]

[0001375365-19-000078:notes:187]
[same as prior period, unchanged from 0001375365-19-000077:notes:187]

[0001375365-19-000078:notes:188]
[same as prior period, unchanged from 0001375365-19-000077:notes:188]

[0001375365-19-000078:notes:189]
[same as prior period, unchanged from 0001375365-19-000077:notes:189]

[0001375365-19-000078:notes:190]
[same as prior period, unchanged from 0001375365-19-000077:notes:190]

[0001375365-19-000078:notes:191]
[same as prior period, unchanged from 0001375365-19-000077:notes:191]

[0001375365-19-000078:notes:192]
[same as prior period, unchanged from 0001375365-19-000077:notes:192]

[0001375365-19-000078:notes:193]
[same as prior period, unchanged from 0001375365-19-000077:notes:193]

[0001375365-19-000078:notes:194]
[same as prior period, unchanged from 0001375365-19-000077:notes:194]

[0001375365-19-000078:notes:195]
[same as prior period, unchanged from 0001375365-19-000077:notes:195]

[0001375365-19-000078:notes:196]
[same as prior period, unchanged from 0001375365-19-000077:notes:196]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-19-000078:notes:197]
Revenue

[0001375365-19-000078:notes:198]
[same as prior period, unchanged from 0001375365-19-000077:notes:199]

[0001375365-19-000078:notes:199]
[same as prior period, unchanged from 0001375365-19-000077:notes:200]

[0001375365-19-000078:notes:200]
[same as prior period, unchanged from 0001375365-19-000077:notes:201]

[0001375365-19-000078:notes:201]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On July 1, 2018, deferred revenue totaled $143.5 million after recognizing the cumulative effect of initially applying ASC 606. Of that amount, $14.1 million and $39.8 million was recognized as revenue during the three and nine months ended March 31, 2019, respectively.

[0001375365-19-000078:notes:202]
Deferred revenue increased during the nine months ended March 31, 2019 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

[0001375365-19-000078:notes:203]
[same as prior period, unchanged from 0001375365-19-000077:notes:204]

[0001375365-19-000078:notes:204]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2019 was approximately $193.3 million. The Company expects to recognize approximately 45% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-19-000078:notes:205]
[same as prior period, unchanged from 0001375365-19-000077:notes:206]

[0001375365-19-000078:notes:206]
[same as prior period, unchanged from 0001375365-19-000077:notes:207]

[0001375365-19-000078:notes:207]
[same as prior period, unchanged from 0001375365-19-000077:notes:208]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001375365-19-000078:notes:208]
[same as prior period, unchanged from 0001375365-19-000077:notes:209]

[0001375365-19-000078:notes:209]
|  | March 31, 2019 |  | June 30, 2018 |
| Accrued payroll and related expenses | $ | 24,621 |  |  | $ | 25,532 |  |
| Contract manufacturers liability | 20,748 |  |  | 28,754 |  |
| Customer deposits | 17,895 |  |  | 14,938 |  |
| Accrued professional fees | 10,937 |  |  | 6,626 |  |
| Accrued warranty costs | 8,200 |  |  | 7,589 |  |
| Accrued cooperative marketing expenses | 6,910 |  |  | 6,413 |  |
| Others | 23,640 |  |  | 12,626 |  |
| Total accrued liabilities | $ | 112,951 |  |  | $ | 102,478 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001375365-19-000078:notes:210]
[same as prior period, unchanged from 0001375365-19-000077:notes:211]

[0001375365-19-000078:notes:211]
|  | March 31, 2019 |  | June 30, 2018 |
| Cash and cash equivalents | $ | 169,735 |  |  | $ | 115,377 |  |
| Restricted cash included in prepaid expenses and other current assets | 17,234 |  |  | 2,803 |  |
| Restricted cash included in other assets | 2,301 |  |  | 2,202 |  |
| Total cash, cash equivalents and restricted cash | $ | 189,270 |  |  | $ | 120,382 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001375365-19-000078:notes:212]
[same as prior period, unchanged from 0001375365-19-000077:notes:213]

[0001375365-19-000078:notes:213]
|  | March 31, 2019 |  | June 30, 2018 |
| Finished goods | $ | 525,344 |  |  | $ | 633,348 |  |
| Work in process | 84,293 |  |  | 61,162 |  |
| Purchased parts and raw materials | 151,476 |  |  | 158,742 |  |
| Total inventories | $ | 761,113 |  |  | $ | 853,252 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001375365-19-000078:notes:214]
[same as prior period, unchanged from 0001375365-19-000077:notes:215]

[0001375365-19-000078:notes:215]
|  | March 31, 2019 |  | June 30, 2018 |
| Deferred service costs, non-current | $ | 3,473 |  |  | $ | 3,583 |  |
| Non-marketable equity securities (1) | 2,878 |  |  | 3,539 |  |
| Restricted cash, non-current | 2,301 |  |  | 2,202 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 607 |  |  | 671 |  |
| Prepaid expense, non-current | 1,763 |  |  | 2,471 |  |
| Total other assets | $ | 12,593 |  |  | $ | 14,037 |  |

[0001375365-19-000078:notes:216]
(1) As of March 31, 2019, the balance represents investments in non-marketable equity securities without readily determinable fair values. As of June 30, 2018, the balance represents investments in equity securities accounted for under the cost method.


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001375365-19-000078:notes:217]
[same as prior period, unchanged from 0001375365-19-000077:notes:219]

[0001375365-19-000078:notes:218]
|  | March 31, 2019 |  | June 30, 2018 |
| Receivables from vendors (1) | $ | 60,741 |  |  | $ | 93,003 |  |
| Restricted cash | 17,234 |  |  | 2,803 |  |
| Prepaid expenses | 7,578 |  |  | 6,321 |  |
| Deferred service costs | 3,354 |  |  | 2,920 |  |
| Others | 8,950 |  |  | 5,809 |  |
| Total prepaid expenses and other current assets | $ | 97,857 |  |  | $ | 110,856 |  |

[0001375365-19-000078:notes:219]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $59.7 million and $87.4 million as of March 31, 2019 and June 30, 2018, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001375365-19-000078:notes:220]
[same as prior period, unchanged from 0001375365-19-000077:notes:222]

[0001375365-19-000078:notes:221]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Balance, beginning of the period | $ | 10,434 |  |  | $ | 8,796 |  |  | $ | 9,884 |  |  | $ | 7,721 |  |
| Provision for warranty | 5,510 |  |  | 5,126 |  |  | 17,163 |  |  | 15,380 |  |
| Costs utilized | (6,346 | ) |  | (4,959 | ) |  | (18,083 | ) |  | (15,387 | ) |
| Change in estimated liability for pre-existing warranties | 918 |  |  | 151 |  |  | 1,552 |  |  | 1,400 |  |
| Balance, end of the period | 10,516 |  |  | 9,114 |  |  | 10,516 |  |  | 9,114 |  |
| Current portion | 8,200 |  |  | 7,013 |  |  | 8,200 |  |  | 7,013 |  |
| Non-current portion | $ | 2,316 |  |  | $ | 2,101 |  |  | $ | 2,316 |  |  | $ | 2,101 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001375365-19-000078:notes:222]
[same as prior period, unchanged from 0001375365-19-000077:notes:224]

[0001375365-19-000078:notes:223]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Long-lived assets: |  |  |  |
| United States | $ | 158,307 |  |  | $ | 151,567 |  |
| Asia | 42,530 |  |  | 42,533 |  |
| Europe | 2,605 |  |  | 2,531 |  |
|  | $ | 203,442 |  |  | $ | 196,631 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-19-000078:notes:224]
[same as prior period, unchanged from 0001375365-19-000077:notes:226]

[0001375365-19-000078:notes:225]
[same as prior period, unchanged from 0001375365-19-000077:notes:227]

[0001375365-19-000078:notes:226]
[same as prior period, unchanged from 0001375365-19-000077:notes:228]


## us-gaap:SubsequentEventsTextBlock

[0001375365-19-000078:notes:227]
Subsequent Events

[0001375365-19-000078:notes:228]
On February 8, 2018, two putative class action complaints were filed against us, our Chief Executive Officer, and our former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff and it filed an amended complaint naming our Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, plaintiff filed a further amended complaint naming our former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, we filed a motion to dismiss which remains pending. We believe the allegations filed are without merit and intend to vigorously defend against the lawsuit.

[0001375365-19-000078:notes:229]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring is not expected to have a material impact to the estimated annual effective tax rate.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-19-000078:notes:230]
[same as prior period, unchanged from 0001375365-19-000077:notes:232]

[0001375365-19-000078:notes:231]
[same as prior period, unchanged from 0001375365-19-000077:notes:233]

[0001375365-19-000078:notes:232]
The Company recorded a provision for excess and obsolete inventory totaling $4.7 million and $17.3 million in the three and nine months ended March 31, 2019, respectively, and $1.9 million and $6.2 million in the three and nine months ended March 31, 2018, respectively, excluding a provision for adjusting the cost of certain inventories to net realizable value of $5.7 million and $7.3 million for the three and nine months ended March 31, 2019, respectively. The provision for adjusting the cost of certain inventories to net realizable value was not material for the three and nine months ended March 31, 2018.
