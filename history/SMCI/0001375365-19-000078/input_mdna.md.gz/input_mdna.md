# SMCI MD&A — 0001375365-19-000078


## mdna

[0001375365-19-000078:mdna:1]
[same as prior period, unchanged from 0001375365-19-000077:mdna:1]

[0001375365-19-000078:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Q3 2019 Quarterly Report and included in our 2019 Comprehensive 10-K, which we expect to file subsequent to the filing of this Q3 2019  Quarterly Report and which will include our consolidated financial statements for the fiscal years ended June 30, 2019 and 2018.

[0001375365-19-000078:mdna:3]
[same as prior period, unchanged from 0001375365-19-000077:mdna:3]

[0001375365-19-000078:mdna:4]
[same as prior period, unchanged from 0001375365-19-000077:mdna:4]

[0001375365-19-000078:mdna:5]
[same as prior period, unchanged from 0001375365-19-000077:mdna:5]

[0001375365-19-000078:mdna:6]
[same as prior period, unchanged from 0001375365-19-000077:mdna:6]

[0001375365-19-000078:mdna:7]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $10.6 million and $48.2 million for the three and nine months ended March 31, 2019, respectively, and $14.6 million and $19.9 million for the three and nine months ended March 31, 2018, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-19-000078:mdna:8]
The decrease in our net sales from the three months ended March 31, 2018 to the three months ended March 31, 2019 reflected a softening demand for our products due to an overall market slowdown in the second half of fiscal year 2019. In addition, adverse publicity associated with false assertions made against our company in a news article published in October 2018 and the unrelated suspension of trading in our common stock on NASDAQ in August 2018 may have been factors contributing to the slower growth in our net sales for fiscal year 2019. The sales of our server and storage systems were approximately 80% of our total net sales during the three months ended March 31, 2019 and 2018 as we continued to focus our efforts on selling server and storage systems to larger customers such as enterprise and data center customers. Server and storage systems generally have higher average selling prices and provide an opportunity to sell services.

[0001375365-19-000078:mdna:9]
[same as prior period, unchanged from 0001375365-19-000077:mdna:9]

[0001375365-19-000078:mdna:10]
The following is a summary of our financial highlights of the third quarter of fiscal 2019:

[0001375365-19-000078:mdna:11]
| • | Net sales decreased by 11.0% as compared to the three months ended March 31, 2018. |

[0001375365-19-000078:mdna:12]
| • | Gross margin increased to 15.1% from 12.7% in the three months ended March 31, 2018, primarily due to lower prices for key components, a favorable geographic mix with less competitive pricing, and increased service revenues that have higher margins. |

[0001375365-19-000078:mdna:13]
| • | Operating expenses increased by 17.3% as compared to the three months ended March 31, 2018 and were equal to 13.4% and 10.1% of sales in the three months ended March 31, 2019 and 2018, respectively. The increase was primarily due to professional fees that were incurred to investigate, assess and begin remediating the causes that lead to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements. |

[0001375365-19-000078:mdna:14]
| • | Effective tax rate decreased from 21.4% in the three months ended March 31, 2018 to 4.3% in the three months ended March 31, 2019. |

[0001375365-19-000078:mdna:15]
Subsequent Events

[0001375365-19-000078:mdna:16]
For details, see Part I, Item 1, Note 12, "Subsequent Events," in our notes to the condensed consolidated financial statements in this Q3 2019 Quarterly Report.

[0001375365-19-000078:mdna:17]
[same as prior period, unchanged from 0001375365-19-000077:mdna:17]

[0001375365-19-000078:mdna:18]
[same as prior period, unchanged from 0001375365-19-000077:mdna:18]

[0001375365-19-000078:mdna:19]
[same as prior period, unchanged from 0001375365-19-000077:mdna:19]

[0001375365-19-000078:mdna:20]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the fiscal years 2019 and 2018, we continued to expand manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related

[0001375365-19-000078:mdna:21]
party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 9.9% and 8.6% of our cost of sales for the three months ended March 31, 2019 and 2018, respectively, and 9.4% and 9.2% of our cost of sales for the nine months ended March 31, 2019 and 2018, respectively. For further details on our dealings with related parties, see Part I, Item 1, Note 8, “Related Party Transactions.”

[0001375365-19-000078:mdna:22]
[same as prior period, unchanged from 0001375365-19-000077:mdna:22]

[0001375365-19-000078:mdna:23]
[same as prior period, unchanged from 0001375365-19-000077:mdna:23]

[0001375365-19-000078:mdna:24]
[same as prior period, unchanged from 0001375365-19-000077:mdna:24]

[0001375365-19-000078:mdna:25]
[same as prior period, unchanged from 0001375365-19-000077:mdna:25]

[0001375365-19-000078:mdna:26]
[same as prior period, unchanged from 0001375365-19-000077:mdna:26]

[0001375365-19-000078:mdna:27]
[same as prior period, unchanged from 0001375365-19-000077:mdna:27]

[0001375365-19-000078:mdna:28]
[same as prior period, unchanged from 0001375365-19-000077:mdna:28]

[0001375365-19-000078:mdna:29]
[same as prior period, unchanged from 0001375365-19-000077:mdna:29]

[0001375365-19-000078:mdna:30]
Except for the changes to our accounting policy as a result of the adoption of ASC 606 on July 1, 2018, there have been no material change to our critical accounting policies and estimates. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Organization and Summary of Significant Accounting Policies" in our notes to the condensed consolidated financial statements in this Q3 2019 Quarterly Report.

[0001375365-19-000078:mdna:31]
[same as prior period, unchanged from 0001375365-19-000077:mdna:31]

[0001375365-19-000078:mdna:32]
[same as prior period, unchanged from 0001375365-19-000077:mdna:32]

[0001375365-19-000078:mdna:33]
The following table presents net sales by product type for the three and nine months ended March 31, 2019 and 2018 (dollars in millions):

[0001375365-19-000078:mdna:34]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Server and storage systems | $ | 592.8 |  |  | $ | 669.1 |  |  | $ | (76.3 | ) |  | (11.4 | )% |  | $ | 2,161.3 |  |  | $ | 1,841.2 |  |  | $ | 320.1 |  |  | 17.4 | % |
| Percentage of total net sales | 79.7 | % |  | 80.1 | % |  |  |  |  |  | 81.7 | % |  | 77.4 | % |  |  |  |  |
| Subsystems and accessories | $ | 150.7 |  |  | $ | 166.0 |  |  | $ | (15.3 | ) |  | (9.2 | )% |  | $ | 484.8 |  |  | $ | 537.6 |  |  | $ | (52.8 | ) |  | (9.8 | )% |
| Percentage of total net sales | 20.3 | % |  | 19.9 | % |  |  |  |  |  | 18.3 | % |  | 22.6 | % |  |  |  |  |
| Total net sales | $ | 743.5 |  |  | $ | 835.1 |  |  | $ | (91.6 | ) |  | (11.0 | )% |  | $ | 2,646.1 |  |  | $ | 2,378.8 |  |  | $ | 267.3 |  |  | 11.2 | % |

[0001375365-19-000078:mdna:35]
During the three and nine months ended March 31, 2019, we continued our trend of concentrating our efforts on selling server and storage systems to larger customers such as enterprise, internet data center and cloud customers.

[0001375365-19-000078:mdna:36]
Comparison of Three Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:37]
The period-over-period decrease in net sales of our server and storage systems was primarily due to a decrease of approximately 9% in the number of units of compute nodes shipped attributable to an overall market slowdown in the second half of fiscal year 2019. This decrease was partially offset by an increase in the average selling price per compute node by approximately 8%. The modest increase in the average selling prices of our server and storage systems is due to the change in mix of compute and memory density of products sold.

[0001375365-19-000078:mdna:38]
The period-over-period decrease in net sales of our subsystems and accessories is primarily due to a decrease in the  average selling price per unit by approximately 7% offset by an increase in the volume of subsystems and accessories sold by approximately 7%.

[0001375365-19-000078:mdna:39]
Comparison of Nine Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:40]
The period-over-period increase in net sales of our server and storage systems was primarily due to an increase in the average selling price per node by approximately 22%. The increase in the average selling prices of our server and storage systems was primarily due to increased selling prices to customers consistent with the increases in the cost of memory and SSDs and sales of our systems configured with higher density computing and more memory and storage capacity.

[0001375365-19-000078:mdna:41]
The decrease in net sales of our subsystems and accessories is primarily due to a decrease in the volume of subsystems and accessories sold by approximately 6%.

[0001375365-19-000078:mdna:42]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:

[0001375365-19-000078:mdna:43]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000078:mdna:44]
The period-over-period increase in net sales to direct customers and OEMs as a percentage of total net sales for the three and nine months ended March 31, 2019 and 2018 was primarily due to higher sales of our server and storage systems to internet data center and cloud, enterprise and OEM customers. The period-over-period decrease in net sales through our indirect sales channel as a percentage of total net sales was primarily due to the higher sales to our direct customers and OEMs.

[0001375365-19-000078:mdna:45]
The following table presents percentages of net sales by geographic region for the three and nine months ended March 31, 2019 and 2018:

[0001375365-19-000078:mdna:46]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| United States | 58.7 | % |  | 54.5 | % |  | 4.2 | % |  | 57.3 | % |  | 55.4 | % |  | 1.9 | % |
| Europe | 17.3 | % |  | 18.0 | % |  | (0.7 | )% |  | 17.8 | % |  | 16.5 | % |  | 1.3 | % |
| Asia | 19.7 | % |  | 22.5 | % |  | (2.8 | )% |  | 20.8 | % |  | 23.6 | % |  | (2.8 | )% |
| Others | 4.3 | % |  | 5.0 | % |  | (0.7 | )% |  | 4.1 | % |  | 4.5 | % |  | (0.4 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000078:mdna:47]
The period-over-period increase in net sales in the United States as a percentage of total net sales for the three and nine months ended March 31, 2019 and 2018 was primarily due to the higher sales of our server and storage systems to our direct customers and OEMs. The period-over-period decrease in net sales in Asia as a percentage of total net sales for the three and nine months ended March 31, 2019 and 2018 was due primarily to decreased sales through our indirect sales channel in China, partially offset by increased sales in Taiwan. The decreased percentage of total net sales for the three months ended March 31, 2019 in Europe is primarily due to decreased sales in the United Kingdom, while the increased percentage of net sales for the nine months ended March 31, 2019 in Europe was primarily due to higher sales in the Netherlands and stronger overall European market demand in first six months of fiscal 2019.

[0001375365-19-000078:mdna:48]
[same as prior period, unchanged from 0001375365-19-000077:mdna:48]

[0001375365-19-000078:mdna:49]
Cost of sales and gross margin for the three and nine months ended March 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000078:mdna:50]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Cost of sales | $ | 631.2 |  |  | $ | 729.2 |  |  | $ | (98.0 | ) |  | (13.4 | )% |  | $ | 2,282.6 |  |  | $ | 2,081.2 |  |  | $ | 201.4 |  |  | 9.7 | % |
| Gross profit | $ | 112.3 |  |  | $ | 105.9 |  |  | $ | 6.4 |  |  | 6.0 | % |  | $ | 363.5 |  |  | $ | 297.7 |  |  | $ | 65.8 |  |  | 22.1 | % |
| Gross margin | 15.1 | % |  | 12.7 | % |  |  |  | 2.4 | % |  | 13.7 | % |  | 12.5 | % |  |  |  | 1.2 | % |

[0001375365-19-000078:mdna:51]
Comparison of Three Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:52]
The period-over-period decrease in cost of sales was primarily attributable to a decrease of $107.4 million in product costs as related to the decrease in net sales, partially offset by an increase of $8.9 million in inventory excess and obsolescence provision.

[0001375365-19-000078:mdna:53]
The period-over-period increase in the gross margin percentage was primarily due to a higher percentage of sales of our server and storage systems which have higher average selling prices and lower costs for key components. In addition, in the three months ended March 31, 2019, as compared with three months ended March 31, 2018, we had lower net sales in Asia where pricing is typically more competitive, which had a positive impact on our gross margin percentage.

[0001375365-19-000078:mdna:54]
Comparison of Nine Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:55]
The period-over-period increase in cost of sales was primarily attributable to an increase of $171.1 million in product costs related to the increase in net sales volume, an increase of $18.4 million in inventory excess and obsolescence provision, an increase in overhead costs of $7.8 million attributable to increased tariffs for import of components from China and an increase of $7.5 million in compensation and benefits including stock-based compensation, partially offset by a decrease of $3.3 million in other costs including warranty.

[0001375365-19-000078:mdna:56]
The period-over-period increase in the gross margin percentage was primarily due to a higher percentage of sales of our server and storage systems which have higher average selling prices. In addition, in the nine months ended March 31, 2019, as compared with the nine months ended March 31, 2018, we had lower net sales in Asia where pricing is typically more competitive, which had a positive impact on our gross margin percentage.

[0001375365-19-000078:mdna:57]
[same as prior period, unchanged from 0001375365-19-000077:mdna:57]

[0001375365-19-000078:mdna:58]
Operating expenses for the three and nine months ended March 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000078:mdna:59]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Research and development | $ | 44.8 |  |  | $ | 42.3 |  |  | $ | 2.5 |  |  | 5.9 | % |  | $ | 133.7 |  |  | $ | 122.5 |  |  | $ | 11.2 |  |  | 9.1 | % |
| Percentage of total net sales | 6.0 | % |  | 5.1 | % |  |  |  |  |  | 5.1 | % |  | 5.1 | % |  |  |  |  |
| Sales and marketing | $ | 18.5 |  |  | $ | 18.9 |  |  | $ | (0.4 | ) |  | (2.1 | )% |  | $ | 56.5 |  |  | $ | 53.7 |  |  | $ | 2.8 |  |  | 5.2 | % |
| Percentage of total net sales | 2.5 | % |  | 2.3 | % |  |  |  |  |  | 2.1 | % |  | 2.3 | % |  |  |  |  |
| General and administrative | $ | 36.2 |  |  | $ | 23.6 |  |  | $ | 12.6 |  |  | 53.4 | % |  | $ | 106.2 |  |  | $ | 68.3 |  |  | $ | 37.9 |  |  | 55.5 | % |
| Percentage of total net sales | 4.9 | % |  | 2.7 | % |  |  |  |  |  | 4.0 | % |  | 2.9 | % |  |  |  |  |
| Total operating expenses | $ | 99.5 |  |  | $ | 84.8 |  |  | $ | 14.7 |  |  | 17.3 | % |  | $ | 296.4 |  |  | $ | 244.5 |  |  | $ | 51.9 |  |  | 21.2 | % |
| Percentage of total net sales | 13.4 | % |  | 10.1 | % |  |  |  |  |  | 11.2 | % |  | 10.3 | % |  |  |  |  |

[0001375365-19-000078:mdna:60]
Comparison of Three Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:61]
Research and development expenses. The period-over-period increase in research and development expenses was due primarily to an increase of $3.7 million in personnel expenses, a decrease of $1.0 million in reimbursements received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products, partially offset by a decrease of $2.2 million in product development costs.

[0001375365-19-000078:mdna:62]
Sales and marketing expenses. The period-over-period decrease in sales and marketing expenses was due primarily to a decrease in advertising and promotion expense.

[0001375365-19-000078:mdna:63]
General and administrative expenses. The period-over-period increase in general and administrative expenses includes an increase of $10.7 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements and an increase of $1.5 million in bad debt provision expense.

[0001375365-19-000078:mdna:64]
Comparison of Nine Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:65]
Research and development expenses. The period-over-period increase in research and development expenses was due primarily to an increase of $13.0 million in personnel expenses, a decrease of $3.5 million in reimbursements received for certain research and development costs that we incur as part of the joint development of our and our suppliers’ and customers’ products, offset by a decrease of $5.3 million in product development costs.

[0001375365-19-000078:mdna:66]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was due primarily to an increase of $4.6 million in personnel expenses, partially offset by a decrease of $2.1 million in advertising and promotion expense.

[0001375365-19-000078:mdna:67]
General and administrative expenses. The period-over-period increase in general and administrative expenses includes an increase of $34.0 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, an increase of $1.8 million in certain accrued liabilities and an increase of $3.0 million in bad debt provision expense.

[0001375365-19-000078:mdna:68]
Our compensation and benefit expense related to operating expenses increased primarily as a result of an increase in annual salaries and benefits, and an increase in the number of personnel to support our expanded product development initiatives and to support the growth of our business in many market verticals.

[0001375365-19-000078:mdna:69]
[same as prior period, unchanged from 0001375365-19-000077:mdna:68]

[0001375365-19-000078:mdna:70]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances, and foreign exchange gains and losses.

[0001375365-19-000078:mdna:71]
[same as prior period, unchanged from 0001375365-19-000077:mdna:70]

[0001375365-19-000078:mdna:72]
Interest and other expense, net for the three and nine months ended March 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000078:mdna:73]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Other (expense) income, net | $ | (0.1 | ) |  | $ | (0.4 | ) |  | $ | 0.3 |  |  | (75.0 | )% |  | $ | 0.7 |  |  | $ | (1.6 | ) |  | $ | 2.3 |  |  | (143.8 | )% |
| Interest expense | (1.3 | ) |  | (1.3 | ) |  | — |  |  | — | % |  | (5.5 | ) |  | (3.5 | ) |  | (2.0 | ) |  | 57.1 | % |
| Interest and other expense, net | $ | (1.4 | ) |  | $ | (1.7 | ) |  | $ | 0.3 |  |  | (17.6 | )% |  | $ | (4.8 | ) |  | $ | (5.1 | ) |  | $ | 0.3 |  |  | (5.9 | )% |

[0001375365-19-000078:mdna:74]
Comparison of Three Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:75]
Interest and other expense, net remained largely consistent period-over-period.

[0001375365-19-000078:mdna:76]
Comparison of Nine Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:77]
The period-over-period increase in interest and other expense, net was primarily due to an increase of $2.0 million in interest expense related to amortization of loan origination fees in connection with refinancing of our 2018 Bank of America Credit Facility in the last quarter of fiscal year 2018, partially offset by an increase of $2.3 million attributable to increase in interest income on our deposits and foreign exchange gain due to favorable foreign currency fluctuations.

[0001375365-19-000078:mdna:78]
[same as prior period, unchanged from 0001375365-19-000077:mdna:77]

[0001375365-19-000078:mdna:79]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000078:mdna:80]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Income tax provision | $ | 0.5 |  |  | $ | 4.2 |  |  | $ | (3.7 | ) |  | (88.1 | )% |  | $ | 10.5 |  |  | $ | 25.7 |  |  | $ | (15.2 | ) |  | (59.1 | )% |
| Percentage of total net sales | 0.1 | % |  | 0.5 | % |  |  |  |  |  | 0.4 | % |  | 1.1 | % |  |  |  |  |
| Effective tax rate | 4.3 | % |  | 21.4 | % |  |  |  |  |  | 16.9 | % |  | 53.5 | % |  |  |  |  |

[0001375365-19-000078:mdna:81]
Comparison of Three Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:82]
The lower income tax provision and effective tax rate for the three months ended March 31, 2019 was primarily attributable to the recognition of certain discrete tax benefits in the three months ended March 31, 2019.

[0001375365-19-000078:mdna:83]
Comparison of Nine Months Ended March 31, 2019 and 2018

[0001375365-19-000078:mdna:84]
The lower income tax provision and effective tax rate for the nine months ended March 31, 2019 was primarily attributable to a $12.9 million one-time write down of U.S. deferred tax assets and liabilities resulting from the U.S. federal corporate income tax rate decrease from 35% to 21%, and the U.S. federal one-time transition tax of $2.8 million, as a result of the 2017 Tax Reform Act during the nine months ended March 31, 2018.

[0001375365-19-000078:mdna:85]
[same as prior period, unchanged from 0001375365-19-000077:mdna:84]

[0001375365-19-000078:mdna:86]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $169.7 million and $115.4 million as of March 31, 2019 and June 30, 2018, respectively. Our cash in foreign locations was $74.3 million and $114.0 million as of March 31, 2019 and June 30, 2018, respectively.

[0001375365-19-000078:mdna:87]
[same as prior period, unchanged from 0001375365-19-000077:mdna:86]

[0001375365-19-000078:mdna:88]
[same as prior period, unchanged from 0001375365-19-000077:mdna:87]

[0001375365-19-000078:mdna:89]
[same as prior period, unchanged from 0001375365-19-000077:mdna:88]

[0001375365-19-000078:mdna:90]
[same as prior period, unchanged from 0001375365-19-000077:mdna:89]

[0001375365-19-000078:mdna:91]
|  | Nine Months Ended March 31, |  | Change |
|  | 2019 |  | 2018 |  |
| Net cash provided by operating activities | $ | 180.7 |  |  | $ | 19.4 |  |  | $ | 161.3 |  |
| Net cash used in investing activities | $ | (15.8 | ) |  | $ | (17.7 | ) |  | $ | 1.9 |  |
| Net cash (used in) provided by financing activities | $ | (95.9 | ) |  | $ | 23.4 |  |  | $ | (119.3 | ) |
| Net increase in cash, cash equivalents and restricted cash | $ | 68.9 |  |  | $ | 25.3 |  |  | $ | 43.6 |  |

[0001375365-19-000078:mdna:92]
[same as prior period, unchanged from 0001375365-19-000077:mdna:91]

[0001375365-19-000078:mdna:93]
Net cash provided by operating activities increased by $161.3 million for the nine months ended March 31, 2019 as compared to the nine months ended March 31, 2018. The increase was due primarily to a reduction of net working capital of $125.9 million from improved working capital management and reduced costs for key components during the period, an increase in net income in the current period of $28.3 million, an increase in provision for excess and obsolete inventories of $18.4 million from older generation products, and an increase from changes in deferred revenue of $6.6 million related to the growth in our service business partially offset by decrease in non-cash charges of $20.4 million from changes in deferred tax assets primarily due to the increase in provision for excess and obsolete inventories and deferred revenue. In the six months ended December 31, 2017 the change in our deferred tax assets included a $12.9 million one-time write down of U.S. deferred tax assets and liabilities, as a result of the U.S. federal corporate income tax rate decrease from 35% to 21%, due to the 2017 Tax Reform Act, whereas there was no such decrease in the deferred tax assets in the six months ended December 31, 2018.

[0001375365-19-000078:mdna:94]
[same as prior period, unchanged from 0001375365-19-000077:mdna:93]

[0001375365-19-000078:mdna:95]
Net cash used in investing activities were $15.8 million and $17.7 million for the nine months ended March 31, 2019 and the nine months ended March 31, 2018, respectively, as we continued to invest in our Green Computing Park in San Jose to expand our capacity and office space.

[0001375365-19-000078:mdna:96]
[same as prior period, unchanged from 0001375365-19-000077:mdna:95]

[0001375365-19-000078:mdna:97]
Net cash used in financing activities increased by $119.3 million for the nine months ended March 31, 2019 as compared to the nine months ended March 31, 2018 primarily due to an increased debt repayments, net of borrowings of $116.8 million.

[0001375365-19-000078:mdna:98]
[same as prior period, unchanged from 0001375365-19-000077:mdna:97]

[0001375365-19-000078:mdna:99]
[same as prior period, unchanged from 0001375365-19-000077:mdna:98]

[0001375365-19-000078:mdna:100]
[same as prior period, unchanged from 0001375365-19-000077:mdna:99]

[0001375365-19-000078:mdna:101]
2016 Bank of America Credit Facility

[0001375365-19-000078:mdna:102]
In June 2016, we entered into a credit agreement with Bank of America (the “2016 Bank of America Credit Facility”). Prior to its maturity in April 2018, we repaid and terminated the 2016 Bank of America Credit Facility using the proceeds from our 2018 Bank of America Credit Facility (defined below). Immediately prior to its termination, the 2016 Bank of America

[0001375365-19-000078:mdna:103]
Credit Facility (giving effect to all amendments since the inception of the 2016 Bank of America Credit Facility), provided for (i) a $85.0 million revolving line of credit including a $5.0 million letter of credit sublimit, (ii) a $20.0 million revolving line of credit for our Taiwan and the Netherlands entities, and (iii) a five-year $50.0 million term loan. The 2016 Bank of America Credit Facility term loan was secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan were payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the $85.0 million revolving line of credit was at the LIBOR rate plus 1.25% per annum. The interest rate of the $20.0 million revolving line of credit was equal to a minimum of 0.9% per annum plus the lender's cost of funds, as defined in the agreements.

[0001375365-19-000078:mdna:104]
2018 Bank of America Credit Facility

[0001375365-19-000078:mdna:105]
In April 2018, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at our option and if certain conditions are satisfied, including being current on all of our delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against our line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to a five-year revolving credit facility, Super Micro Computer’s assets, and at our option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to either repurchase our shares or pay any dividends.

[0001375365-19-000078:mdna:106]
In the fourth fiscal quarter of 2018, we paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in our consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in our consolidated balance sheets.

[0001375365-19-000078:mdna:107]
On January 31, 2019, we paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, we entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000078:mdna:108]
As of March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $0.0 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2019 and June 30, 2018 were 5.25% per annum and 4.75% per annum, respectively. As of March 31, 2019, a $3.2 million letter of credit was outstanding under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.7 million and $2.8 million as of March 31, 2019 and June 30, 2018, respectively. As of March 31, 2019, our available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000078:mdna:109]
[same as prior period, unchanged from 0001375365-19-000077:mdna:108]

[0001375365-19-000078:mdna:110]
In April 2016, we entered into a credit agreement with CTBC Bank Co., Ltd (“CTBC Bank”) that provides for (i) a 12-month NTD $700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in

[0001375365-19-000078:mdna:111]
Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum, which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. We extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

[0001375365-19-000078:mdna:112]
In May 2017, we renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum, which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, we entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

[0001375365-19-000078:mdna:113]
In January 2018, we entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000078:mdna:114]
In June 2019, we entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000078:mdna:115]
The total outstanding borrowings under the 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.7 million and $22.9 million at March 31, 2019 and June 30, 2018, respectively. At March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $0.0 million and $25.9 million, respectively, in U.S. dollars. The interest rates for these loans were 0.92% and 0.95% as of March 31, 2019 and June 30, 2018, respectively. At March 31, 2019, the amount available for future borrowing under the 2018 CTBC Credit Facility was $17.3 million. As of March 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2018 CTBC Credit Facility term loan was $26.0 million.

[0001375365-19-000078:mdna:116]
Covenant Compliance

[0001375365-19-000078:mdna:117]
2018 Bank of America Credit Facility

[0001375365-19-000078:mdna:118]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains a financial covenant, which requires that we maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. We have been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000078:mdna:119]
On September 7, 2018, Bank of America issued an extension letter to us in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, we entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, we paid a fee to extend the delivery to June 30, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, we are required to deliver our audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver our audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If we elect to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, we are required to deliver our audited financial statements by March 31, 2020.

[0001375365-19-000078:mdna:120]
[same as prior period, unchanged from 0001375365-19-000077:mdna:119]

[0001375365-19-000078:mdna:121]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.

[0001375365-19-000078:mdna:122]
[same as prior period, unchanged from 0001375365-19-000077:mdna:121]

[0001375365-19-000078:mdna:123]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Organization and Summary of Significant Accounting Policies,” in our notes to the condensed consolidated financial statements in this Q3 2019 Quarterly Report.

[0001375365-19-000078:mdna:124]
[same as prior period, unchanged from 0001375365-19-000077:mdna:123]

[0001375365-19-000078:mdna:125]
[same as prior period, unchanged from 0001375365-19-000077:mdna:124]
