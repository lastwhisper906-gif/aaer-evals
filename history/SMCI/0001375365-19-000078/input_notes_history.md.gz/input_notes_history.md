# SMCI note change history — 0001375365-19-000077 → 0001375365-19-000078


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:1]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2019, these remaining noncancelable commitments were $262.8 million, including $95.6 million for related parties.
  (was, 2019-12-19, similarity 0.8497):
[0001375365-19-000077:note_history:1]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2018, these remaining noncancelable commitments were $329.8 million, including $125.2 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2019.
  (was, 2019-12-19, similarity 0.9546):
[0001375365-19-000077:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2018 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2019.

- changed (2019-12-19):
[0001375365-19-000078:note_history:3]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.
  (was, 2019-12-19, similarity 0.9772):
[0001375365-19-000077:note_history:3]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and six months ended December 31, 2018 and 2017, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- changed (2019-12-19):
[0001375365-19-000078:note_history:4]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2019 and June 30, 2018, the Company's equity investment in the Corporate Venture was $1.4 million and $2.4 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $0.4 million and $0.7 million for the three months ended March 31, 2019 and 2018, respectively, and $3.6 million and $2.5 million for the nine months ended March 31, 2019 and 2018, respectively.
  (was, 2019-12-19, similarity 0.9633):
[0001375365-19-000077:note_history:4]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of December 31, 2018 and June 30, 2018, the Company's equity investment in the Corporate Venture was $2.1 million and $2.4 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $1.8 million and $1.2 million for the three months ended December 31, 2018 and 2017, respectively, and $3.2 million and $1.8 million for the six months ended December 31, 2018 and 2017, respectively.

- changed (2019-12-19):
[0001375365-19-000078:note_history:5]
As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of March 31, 2019 and June 30, 2018, the Company had unamortized deferred gain balance of $2.0 million and $1.4 million, respectively, in accrued liabilities and $3.5 million and $3.5 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2019-12-19, similarity 0.9894):
[0001375365-19-000077:note_history:5]
As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of December 31, 2018 and June 30, 2018, the Company had unamortized deferred gain balance of $2.0 million and $1.4 million, respectively, in accrued liabilities and $4.0 million and $3.5 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2019-12-19):
[0001375365-19-000078:note_history:6]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2019 and March 31, 2018, respectively.
  (was, 2019-12-19, similarity 0.9157):
[0001375365-19-000077:note_history:6]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and six months ended December 31, 2018 and 2017, respectively.

- changed (2019-12-19):
[0001375365-19-000078:note_history:7]
Additionally, the Company sold products worth $13.7 million and $3.1 million to the Corporate Venture in the three months ended March 31, 2019 and March 31, 2018, respectively, and $35.2 million and $14.5 million in the nine months ended March 31, 2019 and March 31, 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2019 and June 30, 2018 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $11.6 million and $2.9 million due from the Corporate Venture in accounts receivable, net as of March 31, 2019 and June 30, 2018, respectively, in its condensed consolidated balance sheets.
  (was, 2019-12-19, similarity 0.8904):
[0001375365-19-000077:note_history:7]
Additionally, the Company sold products worth $12.1 million and $6.4 million to the Corporate Venture in the three months ended December 31, 2018 and December 31, 2017, respectively, and $21.5 million and $11.5 million in the six months ended December 31, 2018 and December 31, 2017, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2018 and June 30, 2018 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $9.2 million and $2.9 million due from the Corporate Venture in accounts receivable, net as of December 31, 2018 and June 30, 2018, respectively, in its condensed consolidated balance sheets.

- changed (2019-12-19):
[0001375365-19-000078:note_history:8]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 26.9% of total purchases for the three months ended March 31, 2019 and 2018, respectively, and 21.2% and 26.2% for the nine months ended March 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 8, "Related Party Transactions," accounted for 9.9% and 8.6% of total cost of sales for the three months ended March 31, 2019 and 2018, respectively, and 9.4% and 9.2% for the nine months ended March 31, 2019 and 2018, respectively.
  (was, 2019-12-19, similarity 0.8761):
[0001375365-19-000077:note_history:8]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 23.4% and 25.1% of total purchases for the three months ended December 31, 2018 and 2017, respectively, and 21.5% and 25.8% for the six months ended December 31, 2018 and December 31, 2017, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 8, "Related Party Transactions," accounted for 9.3% and 9.5% of total cost of sales for the three months ended December 31, 2018 and 2017, respectively, and 9.2% and 9.5% for the six months ended December 31, 2018 and December 31, 2017, respectively.

- added (2019-12-19):
[0001375365-19-000078:note_history:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2019 and 2018. No country other than the United States accounted for 10% or more of the net sales in the three and nine months ended March 31, 2019. No country other than the United States accounted for 10% or more of the net sales in the three months ended March 31, 2018, whereas the United States and China accounted for 55.4% and 11.4%, respectively, of the net sales in the nine months ended March 31, 2018. One customer accounted for 14.9% of the Company's accounts receivable, net as of March 31, 2019, and one customer accounted for 11.6% of the Company's accounts receivable, net as of June 30, 2018.

- changed (2019-12-19):
[0001375365-19-000078:note_history:10]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance,ASC 606, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to ASC 606. The Company adopted ASC 606 on July 1, 2018 using the modified retrospective method. In connection with the adoption of ASC 606, the Company recorded a transition adjustment to increase retained earnings by $6.8 million as of July 1, 2018. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.
  (was, 2019-12-19, similarity 0.9995):
[0001375365-19-000077:note_history:10]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance, ASC 606, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to ASC 606. The Company adopted ASC 606 on July 1, 2018 using the modified retrospective method. In connection with the adoption of ASC 606, the Company recorded a transition adjustment to increase retained earnings by $6.8 million as of July 1, 2018. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

- changed (2019-12-19):
[0001375365-19-000078:note_history:11]
Selected Captions from the Condensed Consolidated Balance Sheet as of March 31, 2019 (in thousands)
  (was, 2019-12-19, similarity 0.9529):
[0001375365-19-000077:note_history:11]
Selected Captions from the Condensed Consolidated Balance Sheet as of December 31, 2018 (in thousands)

- changed (2019-12-19):
[0001375365-19-000078:note_history:12]
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| ASSETS |  |  |  |  |  |
| Accounts receivable, net of allowances | $ | 327,366 |  |  | $ | (17,367 | ) |  | $ | 309,999 |  |
| Inventories | 761,113 |  |  | 11,808 |  |  | 772,921 |  |
| Prepaid expenses and other current assets | 97,857 |  |  | (1,916 | ) |  | 95,941 |  |
| Deferred income taxes, net | 33,776 |  |  | 1,558 |  |  | 35,334 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Accrued liabilities | $ | 112,951 |  |  | $ | (4,655 | ) |  | $ | 108,296 |  |
| Deferred revenue | 87,746 |  |  | 653 |  |  | 88,399 |  |
| Income taxes payable | 8,729 |  |  | 71 |  |  | 8,800 |  |
| Deferred revenue, non-current | 105,584 |  |  | 2,783 |  |  | 108,367 |  |
| Retained earnings | 588,193 |  |  | (4,769 | ) |  | 583,424 |  |
  (was, 2019-12-19, similarity 0.9889):
[0001375365-19-000077:note_history:12]
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| ASSETS |  |  |  |  |  |
| Accounts receivable, net of allowances | $ | 429,574 |  |  | $ | (15,024 | ) |  | $ | 414,550 |  |
| Inventories | 829,166 |  | 11,406 |  |  | 840,572 |  |
| Prepaid expenses and other current assets | 122,110 |  | (2,106 | ) |  | 120,004 |  |
| Deferred income taxes, net | 32,004 |  | 1,558 |  |  | 33,562 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Accrued liabilities | $ | 112,159 |  |  | $ | (3,920 | ) |  | $ | 108,239 |  |
| Deferred revenue | 78,547 |  | 1,784 |  |  | 80,331 |  |
| Income taxes payable | 9,724 |  | 315 |  |  | 10,039 |  |
| Deferred revenue, non-current | 103,242 |  | 3,074 |  |  | 106,316 |  |
| Retained earnings | 577,547 |  | (5,419 | ) |  | 572,128 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:13]
Selected Captions from the Condensed Consolidated Statement of Operations for the Three and Nine Months ended March 31, 2019 (in thousands)
  (was, 2019-12-19, similarity 0.9481):
[0001375365-19-000077:note_history:13]
Selected Captions from the Condensed Consolidated Statement of Operations for the Three and Six Months ended December 31, 2018 (in thousands)

- added (2019-12-19):
[0001375365-19-000078:note_history:14]
|  | Three Months Ended March 31, 2019 |  | Nine Months Ended March 31, 2019 |
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Net sales | $ | 743,499 |  |  | $ | (1,621 | ) |  | $ | 741,878 |  |  | $ | 2,646,126 |  |  | $ | 18,449 |  |  | $ | 2,664,575 |  |
| Cost of sales | 631,172 |  |  | (403 | ) |  | 630,769 |  |  | 2,282,638 |  |  | 18,995 |  |  | 2,301,633 |  |
| Gross profit | 112,327 |  |  | (1,218 | ) |  | 111,109 |  |  | 363,488 |  |  | (546 | ) |  | 362,942 |  |
| General and administrative | 36,174 |  |  | (1,626 | ) |  | 34,548 |  |  | 106,214 |  |  | (2,662 | ) |  | 103,552 |  |
| Income before income tax provision | 11,502 |  |  | 408 |  |  | 11,910 |  |  | 62,320 |  |  | 2,116 |  |  | 64,436 |  |
| Income tax provision | 497 |  |  | (244 | ) |  | 253 |  |  | 10,540 |  |  | 71 |  |  | 10,611 |  |
| Net income | 10,646 |  |  | 652 |  |  | 11,298 |  |  | 48,208 |  |  | 2,045 |  |  | 50,253 |  |

- removed (2019-12-19):
[0001375365-19-000077:note_history:15]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2018 and 2017. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2018, whereas the United States and China represented 54.3% and 14.4%, respectively, of the Company's net sales in the three months ended December 31, 2017, and represented 55.8% and 13.3%, respectively, in the six months ended December 31, 2017. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2018, and one customer accounted for 11.6% of the Company's accounts receivable, net as of June 30, 2018.

- removed (2019-12-19):
[0001375365-19-000077:note_history:16]
|  | Three Months Ended December 31, 2018 |  | Six Months Ended December 31, 2018 |
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Net sales | $ | 931,509 |  |  | $ | 8,211 |  |  | $ | 939,720 |  |  | $ | 1,902,627 |  |  | $ | 20,071 |  |  | $ | 1,922,698 |  |
| Cost of sales | 803,587 |  | 8,818 |  |  | 812,405 |  |  | 1,651,466 |  |  | 19,398 |  |  | 1,670,864 |  |
| Gross profit | 127,922 |  |  | (607 | ) |  | 127,315 |  |  | 251,161 |  |  | 673 |  |  | 251,834 |  |
| General and administrative | 36,580 |  | (1,036 | ) |  | 35,544 |  |  | 70,040 |  | (1,036 | ) |  | 69,004 |  |
| Income before income tax provision | 24,534 |  |  | 429 |  |  | 24,963 |  |  | 50,818 |  |  | 1,709 |  |  | 52,527 |  |
| Income tax provision | 4,520 |  |  | 126 |  |  | 4,646 |  |  | 10,043 |  |  | 315 |  |  | 10,358 |  |
| Net income | 18,220 |  |  | 303 |  |  | 18,523 |  |  | 37,562 |  |  | 1,394 |  |  | 38,956 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:17]
Short-term debt obligations as of March 31, 2019 and June 30, 2018 consisted of the following (in thousands):
  (was, 2019-12-19, similarity 0.9552):
[0001375365-19-000077:note_history:17]
Short-term debt obligations as of December 31, 2018 and June 30, 2018 consisted of the following (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:18]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | — |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,660 |  |  | 22,935 |  |
| Total short-term debt | $ | 22,660 |  |  | $ | 116,181 |  |
  (was, 2019-12-19, similarity 0.8489):
[0001375365-19-000077:note_history:18]
|  | December 31, |  | June 30, |
|  | 2018 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | 25,455 |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | 25,455 |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,717 |  |  | 22,935 |  |
| Total short-term debt | $ | 48,172 |  |  | $ | 116,181 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:19]
As of March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $0.0 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2019 and June 30, 2018 were 5.25% per annum and 4.75% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.7 million and $2.8 million as of March 31, 2019 and June 30, 2018, respectively. As of March 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.
  (was, 2019-12-19, similarity 0.964):
[0001375365-19-000077:note_history:19]
As of December 31, 2018 and June 30, 2018, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $25.5 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2018 and June 30, 2018 were 5.13% per annum and 4.75% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $1.1 million and $2.8 million as of December 31, 2018 and June 30, 2018, respectively. As of December 31, 2018, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $221.3 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2019-12-19):
[0001375365-19-000078:note_history:20]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD$100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. The Company extended the 2016 CTBC Credit Facility to mature on May 31, 2017.
  (was, 2019-12-19, similarity 0.9995):
[0001375365-19-000077:note_history:20]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. The Company extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

- changed (2019-12-19):
[0001375365-19-000078:note_history:21]
In May 2017, the Company renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, the Company entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.
  (was, 2019-12-19, similarity 0.9995):
[0001375365-19-000077:note_history:21]
In May 2017, the Company renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum, which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, the Company entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

- changed (2019-12-19):
[0001375365-19-000078:note_history:22]
The total outstanding borrowings under the 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.7 million and $22.9 million at March 31, 2019 and June 30, 2018, respectively. At March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $0.0 million and $25.9 million, respectively, in U.S. dollars. The interest rate for these loans was 0.92% and 0.95% as of March 31, 2019 and June 30, 2018, respectively. At March 31, 2019, the amount available for future borrowing under the 2018 CTBC Credit Facility was $17.3 million. As of March 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2018 CTBC Credit Facility term loan was $26.0 million.
  (was, 2019-12-19, similarity 0.9264):
[0001375365-19-000077:note_history:22]
The total outstanding borrowings under the 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.7 million and $22.9 million at December 31, 2018 and June 30, 2018, respectively. At December 31, 2018 and June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $0.0 million and $25.9 million, respectively, in U.S. dollars. The interest rates for these loans were 0.94% and 0.95% as of December 31, 2018 and June 30, 2018, respectively. At December 31, 2018, the amount available for future borrowing under the 2018 CTBC Credit Facility was $17.3 million. As of December 31, 2018, the net book value of land and building located in Bade, Taiwan collateralizing the 2018 CTBC Credit Facility term loan was $26.1 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:23]
Short-term debt obligations as of March 31, 2019 and June 30, 2018 consisted of the following (in thousands):
  (was, 2019-12-19, similarity 0.9552):
[0001375365-19-000077:note_history:23]
Short-term debt obligations as of December 31, 2018 and June 30, 2018 consisted of the following (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:24]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | — |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,660 |  |  | 22,935 |  |
| Total short-term debt | $ | 22,660 |  |  | $ | 116,181 |  |
  (was, 2019-12-19, similarity 0.8489):
[0001375365-19-000077:note_history:24]
|  | December 31, |  | June 30, |
|  | 2018 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | 25,455 |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | 25,455 |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,717 |  |  | 22,935 |  |
| Total short-term debt | $ | 48,172 |  |  | $ | 116,181 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:25]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang owned approximately 0.4% of the Company's common stock as of June 30, 2017, but owned no shares as of June 30, 2018 and thereafter. As of March 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of March 31, 2019. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.
  (was, 2019-12-19, similarity 0.988):
[0001375365-19-000077:note_history:25]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang owned approximately 0.4% of the Company's common stock as of June 30, 2017, but owned no shares as of June 30, 2018 and thereafter. As of December 31, 2018, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of December 31, 2018. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of December 31, 2018. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

- changed (2019-12-19):
[0001375365-19-000078:note_history:26]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.0% and 97.6% of the chassis included in the products sold by the Company during the three months ended March 31, 2019 and 2018, respectively; and approximately 95.5% and 97.7% of the chassis included in the products sold by the Company during the nine months ended March 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2019-12-19, similarity 0.9687):
[0001375365-19-000077:note_history:26]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 94.8% and 97.9% of the chassis included in the products sold by the Company during the three months ended December 31, 2018 and 2017, respectively; and approximately 95.3% and 97.8% of the chassis included in the products sold by the Company during the six months ended December 31, 2018 and 2017, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2019-12-19):
[0001375365-19-000078:note_history:27]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $28.3 million and $39.3 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2019-12-19, similarity 0.9936):
[0001375365-19-000077:note_history:27]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $31.4 million and $39.3 million at December 31, 2018 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2019-12-19):
[0001375365-19-000078:note_history:28]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $67.3 million and $111.7 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2019-12-19, similarity 0.9899):
[0001375365-19-000077:note_history:28]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $93.9 million and $111.7 million at December 31, 2018 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2019-12-19):
[0001375365-19-000078:note_history:29]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2019, and 2018, are as follows (in thousands):
  (was, 2019-12-19, similarity 0.9557):
[0001375365-19-000077:note_history:29]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2018 and 2017, are as follows (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:30]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 29,372 |  |  | $ | 37,405 |  |  | $ | 110,290 |  |  | $ | 107,644 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,846 |  |  | $ | 14,528 |  |  | $ | 13,628 |  |  | $ | 31,645 |  |
| Purchases (1) | 34,140 |  |  | 27,969 |  |  | 111,629 |  |  | 91,925 |  |
  (was, 2019-12-19, similarity 0.9289):
[0001375365-19-000077:note_history:30]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 36,282 |  |  | $ | 37,250 |  |  | $ | 80,918 |  |  | $ | 70,239 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 4,640 |  |  | $ | 10,283 |  |  | $ | 9,782 |  |  | $ | 17,117 |  |
| Purchases (1) | 40,277 |  |  | 32,772 |  |  | 77,489 |  |  | 63,956 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:31]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9333):
[0001375365-19-000077:note_history:31]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2018 and 2017.

- changed (2019-12-19):
[0001375365-19-000078:note_history:32]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2019 and June 30, 2018 (in thousands):
  (was, 2019-12-19, similarity 0.9668):
[0001375365-19-000077:note_history:32]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2018 and June 30, 2018 (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:33]
|  | March 31, 2019 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,950 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 26,925 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 8,588 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 33,109 |  |  | 45,617 |  |
  (was, 2019-12-19, similarity 0.9829):
[0001375365-19-000077:note_history:33]
|  | December 31, 2018 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 9,623 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 42,517 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 26,818 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 51,906 |  |  | 45,617 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:34]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and nine months ended March 31, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9434):
[0001375365-19-000077:note_history:34]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and six months ended December 31, 2018 and 2017.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:35]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2019, and 2018, are as follows (in thousands):
  (was, 2019-12-19, similarity 0.9557):
[0001375365-19-000077:note_history:35]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2018 and 2017, are as follows (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:36]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 29,372 |  |  | $ | 37,405 |  |  | $ | 110,290 |  |  | $ | 107,644 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,846 |  |  | $ | 14,528 |  |  | $ | 13,628 |  |  | $ | 31,645 |  |
| Purchases (1) | 34,140 |  |  | 27,969 |  |  | 111,629 |  |  | 91,925 |  |
  (was, 2019-12-19, similarity 0.9289):
[0001375365-19-000077:note_history:36]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 36,282 |  |  | $ | 37,250 |  |  | $ | 80,918 |  |  | $ | 70,239 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 4,640 |  |  | $ | 10,283 |  |  | $ | 9,782 |  |  | $ | 17,117 |  |
| Purchases (1) | 40,277 |  |  | 32,772 |  |  | 77,489 |  |  | 63,956 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:37]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9333):
[0001375365-19-000077:note_history:37]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2018 and 2017.

- changed (2019-12-19):
[0001375365-19-000078:note_history:38]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2019 and June 30, 2018 (in thousands):
  (was, 2019-12-19, similarity 0.9668):
[0001375365-19-000077:note_history:38]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2018 and June 30, 2018 (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:39]
|  | March 31, 2019 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,950 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 26,925 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 8,588 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 33,109 |  |  | 45,617 |  |
  (was, 2019-12-19, similarity 0.9829):
[0001375365-19-000077:note_history:39]
|  | December 31, 2018 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 9,623 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 42,517 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 26,818 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 51,906 |  |  | 45,617 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 592,783 |  |  | 79.7 | % |  | $ | 669,114 |  |  | 80.1 | % |  | $ | 2,161,321 |  |  | 81.7 | % |  | $ | 1,841,218 |  |  | 77.4 | % |
| Subsystems and accessories | 150,716 |  |  | 20.3 | % |  | 165,996 |  |  | 19.9 | % |  | 484,805 |  |  | 18.3 | % |  | 537,612 |  |  | 22.6 | % |
| Total | $ | 743,499 |  |  | 100.0 | % |  | $ | 835,110 |  |  | 100.0 | % |  | $ | 2,646,126 |  |  | 100.0 | % |  | $ | 2,378,830 |  |  | 100.0 | % |
  (was, 2019-12-19, similarity 0.9501):
[0001375365-19-000077:note_history:40]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 762,622 |  |  | 81.9 | % |  | $ | 629,673 |  |  | 76.1 | % |  | $ | 1,568,538 |  |  | 82.4 | % |  | $ | 1,172,104 |  |  | 75.9 | % |
| Subsystems and accessories | 168,887 |  |  | 18.1 | % |  | 197,310 |  |  | 23.9 | % |  | 334,089 |  |  | 17.6 | % |  | 371,616 |  |  | 24.1 | % |
| Total | $ | 931,509 |  |  | 100.0 | % |  | $ | 826,983 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |  | $ | 1,543,720 |  |  | 100.0 | % |

- added (2019-12-19):
[0001375365-19-000078:note_history:41]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

- changed (2019-12-19):
[0001375365-19-000078:note_history:42]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-19, similarity 0.8933):
[0001375365-19-000077:note_history:42]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2018 and 2017, of net sales by geographic region (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 436,734 |  |  | $ | 455,021 |  |  | $ | 1,516,262 |  |  | $ | 1,317,175 |  |
| Europe | 128,789 |  |  | 150,319 |  |  | 472,325 |  |  | 392,797 |  |
| Asia | 146,120 |  |  | 188,101 |  |  | 549,296 |  |  | 561,807 |  |
| Others | 31,856 |  |  | 41,669 |  |  | 108,243 |  |  | 107,051 |  |
|  | $ | 743,499 |  |  | $ | 835,110 |  |  | $ | 2,646,126 |  |  | $ | 2,378,830 |  |
  (was, 2019-12-19, similarity 0.8):
[0001375365-19-000077:note_history:43]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| United States | $ | 511,913 |  |  | $ | 449,039 |  |  | $ | 1,079,528 |  |  | $ | 862,154 |  |
| Europe | 180,976 |  |  | 136,864 |  |  | 343,536 |  |  | 242,478 |  |
| Asia | 196,308 |  |  | 204,566 |  |  | 403,176 |  |  | 373,706 |  |
| Others | 42,312 |  |  | 36,514 |  |  | 76,387 |  |  | 65,382 |  |
|  | $ | 931,509 |  |  | $ | 826,983 |  |  | $ | 1,902,627 |  |  | $ | 1,543,720 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:44]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:
  (was, 2019-12-19, similarity 0.8868):
[0001375365-19-000077:note_history:44]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2018 and 2017:

- added (2019-12-19):
[0001375365-19-000078:note_history:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 over 2018 |  | 2019 |  | 2018 |  | 2019 over 2018 |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- removed (2019-12-19):
[0001375365-19-000077:note_history:46]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | % |  | 2018 |  | 2017 |  | % |
| Indirect sales channel | 40.8 | % |  | 41.5 | % |  | (0.7 | )% |  | 37.5 | % |  | 44.2 | % |  | (6.7 | )% |
| Direct customers and OEMs | 59.2 | % |  | 58.5 | % |  | 0.7 | % |  | 62.5 | % |  | 55.8 | % |  | 6.7 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- removed (2019-12-19):
[0001375365-19-000077:note_history:47]
Revenue


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-19):
[0001375365-19-000078:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 592,783 |  |  | 79.7 | % |  | $ | 669,114 |  |  | 80.1 | % |  | $ | 2,161,321 |  |  | 81.7 | % |  | $ | 1,841,218 |  |  | 77.4 | % |
| Subsystems and accessories | 150,716 |  |  | 20.3 | % |  | 165,996 |  |  | 19.9 | % |  | 484,805 |  |  | 18.3 | % |  | 537,612 |  |  | 22.6 | % |
| Total | $ | 743,499 |  |  | 100.0 | % |  | $ | 835,110 |  |  | 100.0 | % |  | $ | 2,646,126 |  |  | 100.0 | % |  | $ | 2,378,830 |  |  | 100.0 | % |
  (was, 2019-12-19, similarity 0.9501):
[0001375365-19-000077:note_history:48]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 762,622 |  |  | 81.9 | % |  | $ | 629,673 |  |  | 76.1 | % |  | $ | 1,568,538 |  |  | 82.4 | % |  | $ | 1,172,104 |  |  | 75.9 | % |
| Subsystems and accessories | 168,887 |  |  | 18.1 | % |  | 197,310 |  |  | 23.9 | % |  | 334,089 |  |  | 17.6 | % |  | 371,616 |  |  | 24.1 | % |
| Total | $ | 931,509 |  |  | 100.0 | % |  | $ | 826,983 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |  | $ | 1,543,720 |  |  | 100.0 | % |

- changed (2019-12-19):
[0001375365-19-000078:note_history:49]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.
  (was, 2019-12-19, similarity 0.7398):
[0001375365-19-000077:note_history:49]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

- changed (2019-12-19):
[0001375365-19-000078:note_history:50]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-19, similarity 0.8933):
[0001375365-19-000077:note_history:50]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2018 and 2017, of net sales by geographic region (in thousands):

- changed (2019-12-19):
[0001375365-19-000078:note_history:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 436,734 |  |  | $ | 455,021 |  |  | $ | 1,516,262 |  |  | $ | 1,317,175 |  |
| Europe | 128,789 |  |  | 150,319 |  |  | 472,325 |  |  | 392,797 |  |
| Asia | 146,120 |  |  | 188,101 |  |  | 549,296 |  |  | 561,807 |  |
| Others | 31,856 |  |  | 41,669 |  |  | 108,243 |  |  | 107,051 |  |
|  | $ | 743,499 |  |  | $ | 835,110 |  |  | $ | 2,646,126 |  |  | $ | 2,378,830 |  |
  (was, 2019-12-19, similarity 0.8):
[0001375365-19-000077:note_history:51]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| United States | $ | 511,913 |  |  | $ | 449,039 |  |  | $ | 1,079,528 |  |  | $ | 862,154 |  |
| Europe | 180,976 |  |  | 136,864 |  |  | 343,536 |  |  | 242,478 |  |
| Asia | 196,308 |  |  | 204,566 |  |  | 403,176 |  |  | 373,706 |  |
| Others | 42,312 |  |  | 36,514 |  |  | 76,387 |  |  | 65,382 |  |
|  | $ | 931,509 |  |  | $ | 826,983 |  |  | $ | 1,902,627 |  |  | $ | 1,543,720 |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:52]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:
  (was, 2019-12-19, similarity 0.8868):
[0001375365-19-000077:note_history:52]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2018 and 2017:

- added (2019-12-19):
[0001375365-19-000078:note_history:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 over 2018 |  | 2019 |  | 2018 |  | 2019 over 2018 |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- changed (2019-12-19):
[0001375365-19-000078:note_history:54]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On July 1, 2018, deferred revenue totaled $143.5 million after recognizing the cumulative effect of initially applying ASC 606. Of that amount, $14.1 million and $39.8 million was recognized as revenue during the three and nine months ended March 31, 2019, respectively.
  (was, 2019-12-19, similarity 0.9638):
[0001375365-19-000077:note_history:54]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On July 1, 2018, deferred revenue totaled $143.5 million after recognizing the cumulative effect of initially applying ASC 606. Of that amount, $13.9 million and $25.7 million was recognized as revenue during the three and six months ended December 31, 2018, respectively.

- changed (2019-12-19):
[0001375365-19-000078:note_history:55]
Deferred revenue increased during the nine months ended March 31, 2019 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.
  (was, 2019-12-19, similarity 0.8894):
[0001375365-19-000077:note_history:55]
Deferred revenue increased during the six months ended December 31, 2018 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

- changed (2019-12-19):
[0001375365-19-000078:note_history:56]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2019 was approximately $193.3 million. The Company expects to recognize approximately 45% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2019-12-19, similarity 0.9928):
[0001375365-19-000077:note_history:56]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2018 was approximately $181.8 million. The Company expects to recognize approximately 43% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2019-12-19):
[0001375365-19-000077:note_history:57]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

- removed (2019-12-19):
[0001375365-19-000077:note_history:58]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2018 |  | 2017 |  | % |  | 2018 |  | 2017 |  | % |
| Indirect sales channel | 40.8 | % |  | 41.5 | % |  | (0.7 | )% |  | 37.5 | % |  | 44.2 | % |  | (6.7 | )% |
| Direct customers and OEMs | 59.2 | % |  | 58.5 | % |  | 0.7 | % |  | 62.5 | % |  | 55.8 | % |  | 6.7 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |
