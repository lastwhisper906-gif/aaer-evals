# SMCI 8-K — 0001375365-24-000008 filed 2024-01-29

## item codes, every 8-K on or before 2024-02-02

- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2024-02-02

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-24-000008:8k_2_02:1]
EX-99.1
2
exhibit991_20231231.htm
EX-99.1

[0001375365-24-000008:8k_2_02:2]
Document

[0001375365-24-000008:8k_2_02:3]
Exhibit 99.1

[0001375365-24-000008:8k_2_02:4]
Supermicro Announces Second Quarter Fiscal Year 2024 Financial Results

[0001375365-24-000008:8k_2_02:5]
SAN JOSE, Calif. -- January 29, 2024 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a Total IT Solution Provider for AI, Cloud, Storage and 5G/Edge, today announced financial results for its second quarter of fiscal year 2024 ended December 31, 2023.

[0001375365-24-000008:8k_2_02:6]
Second Quarter Fiscal Year 2024 Highlights

[0001375365-24-000008:8k_2_02:7]
•Net sales of $3.66 billion versus $2.12 billion in the first quarter of fiscal year 2024 and $1.80 billion in the same quarter of last year.

[0001375365-24-000008:8k_2_02:8]
•Gross margin of 15.4% versus 16.7% in the first quarter of fiscal year 2024 and 18.7% in the same quarter of last year.

[0001375365-24-000008:8k_2_02:9]
•Net income of $296 million versus $157 million in the first quarter of fiscal year 2024 and $176 million in the same quarter of last year.

[0001375365-24-000008:8k_2_02:10]
•Diluted net income per common share of $5.10 versus $2.75 in the first quarter of fiscal year 2024 and $3.14 in the same quarter of last year.

[0001375365-24-000008:8k_2_02:11]
•Non-GAAP diluted net income per common share of $5.59 versus $3.43 in the first quarter of fiscal year 2024 and $3.26 in the same quarter of last year.

[0001375365-24-000008:8k_2_02:12]
•Cash flow used in operations for the second quarter of fiscal year 2024 of $595 million and capital expenditures of $15 million.

[0001375365-24-000008:8k_2_02:13]
Non-GAAP gross margin for the second quarter of fiscal year 2024 was 15.5% which adds back stock-based compensation expenses of $4 million. Non-GAAP diluted net income per common share for the second quarter of fiscal year 2024 was $5.59, with adjustments for stock-based compensation expenses of $43 million, net of the related tax effects of $10 million.

[0001375365-24-000008:8k_2_02:14]
As of December 31, 2023, total cash and cash equivalents was $726 million and total bank debt was $376 million.

[0001375365-24-000008:8k_2_02:15]
“We continued to demonstrate our market leadership in fiscal Q2 2024, reporting record revenue results of $3.66B, year-over-year growth of 103%,” said Charles Liang, President and CEO of Supermicro. “While we continue to win new partners, our current end customers continue to demand more Supermicro’s optimized AI computer platforms and rack-scale Total IT Solutions. As our innovative solutions continue to gain market share, we are raising our fiscal year 2024 revenue outlook to $14.3 billion to $14.7 billion.”

[0001375365-24-000008:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-24-000008:8k_2_02:17]
For the third quarter of fiscal year 2024 ending March 31, 2024, the Company expects net sales of $3.7 billion to $4.1 billion, GAAP net income per diluted share of $4.79 to $5.64 and non-GAAP net income per diluted share of $5.20 to $6.01. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 13.8% and 15.8%, respectively, and a fully diluted share count of 60.1 million shares for GAAP and fully diluted share count of 61.0 million shares for non-GAAP. The outlook for third quarter of fiscal year 2024 GAAP net income per diluted share includes approximately $28 million in expected stock-based compensation, net of related tax effects of $14 million that are excluded from non-GAAP net income per diluted share.

[0001375365-24-000008:8k_2_02:18]
For fiscal year 2024 ending June 30, 2024, the Company is raising its guidance for revenues from a range of $10 billion to $11 billion to a range of $14.3 billion to $14.7 billion.

[0001375365-24-000008:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-24-000008:8k_2_02:20]
Supermicro will present a live audio webcast of a conference call to review its second quarter of fiscal year 2024 on Monday, January 29, 2024, at 5:00 p.m. ET / 2:00 p.m. PT.

[0001375365-24-000008:8k_2_02:21]
The webcast will be available at https://ir.supermicro.com.

[0001375365-24-000008:8k_2_02:22]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-24-000008:8k_2_02:23]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-24-000008:8k_2_02:24]
Use of Non-GAAP Financial Measures

[0001375365-24-000008:8k_2_02:25]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses and litigation recovery adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of GAAP gross margin to non-GAAP gross margin and from GAAP diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-24-000008:8k_2_02:26]
About Super Micro Computer, Inc.

[0001375365-24-000008:8k_2_02:27]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-24-000008:8k_2_02:28]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-24-000008:8k_2_02:29]
Investor Relations Contact

[0001375365-24-000008:8k_2_02:30]
Nicole Noutsios

[0001375365-24-000008:8k_2_02:31]
email: ir@supermicro.com

[0001375365-24-000008:8k_2_02:32]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000008:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-24-000008:8k_2_02:34]
(in thousands)

[0001375365-24-000008:8k_2_02:35]
(unaudited)

[0001375365-24-000008:8k_2_02:36]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 725,660 |  |  | $ | 440,459 |  |
| Accounts receivable, net of allowance for credit losses | 1,502,971 |  |  | 1,148,259 |  |
| Inventories | 2,466,997 |  |  | 1,445,564 |  |
| Prepaid expenses and other current assets | 146,727 |  |  | 145,144 |  |
| Total current assets | 4,842,355 |  |  | 3,179,426 |  |
| Property, plant and equipment, net | 297,102 |  |  | 290,240 |  |
| Deferred income taxes, net | 218,274 |  |  | 162,654 |  |
| Other assets | 47,269 |  |  | 42,409 |  |
| Total assets | $ | 5,405,000 |  |  | $ | 3,674,729 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,261,533 |  |  | $ | 776,831 |  |
| Accrued liabilities | 214,462 |  |  | 163,865 |  |
| Income taxes payable | 46,453 |  |  | 129,166 |  |
| Short-term debt | 276,307 |  |  | 170,123 |  |
| Deferred revenue | 193,334 |  |  | 134,667 |  |
| Total current liabilities | 1,992,089 |  |  | 1,374,652 |  |
| Deferred revenue, non-current | 190,342 |  |  | 169,781 |  |
| Long-term debt | 99,322 |  |  | 120,179 |  |
| Other long-term liabilities | 46,173 |  |  | 37,947 |  |
| Total liabilities | 2,327,926 |  |  | 1,702,559 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 1,190,276 |  |  | 538,352 |  |
| Accumulated other comprehensive income | 657 |  |  | 639 |  |
| Retained earnings | 1,885,977 |  |  | 1,433,014 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 3,076,910 |  |  | 1,972,005 |  |
| Noncontrolling interest | 164 |  |  | 165 |  |
| Total stockholders’ equity | 3,077,074 |  |  | 1,972,170 |  |
| Total liabilities and stockholders’ equity | $ | 5,405,000 |  |  | $ | 3,674,729 |  |

[0001375365-24-000008:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000008:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-24-000008:8k_2_02:39]
(in thousands, except per share amounts)

[0001375365-24-000008:8k_2_02:40]
(unaudited)

[0001375365-24-000008:8k_2_02:41]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |
| Cost of sales | 3,100,602 |  |  | 1,465,773 |  |  | 4,866,583 |  |  | 2,970,368 |  |
| Gross profit | 564,322 |  |  | 337,422 |  |  | 918,013 |  |  | 684,957 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 108,824 |  |  | 70,700 |  |  | 219,851 |  |  | 144,943 |  |
| Sales and marketing | 46,854 |  |  | 28,445 |  |  | 84,084 |  |  | 57,808 |  |
| General and administrative | 37,180 |  |  | 23,095 |  |  | 70,104 |  |  | 46,901 |  |
| Total operating expenses | 192,858 |  |  | 122,240 |  |  | 374,039 |  |  | 249,652 |  |
| Income from operations | 371,464 |  |  | 215,182 |  |  | 543,974 |  |  | 435,305 |  |
| Other (expense) income, net | (7,886) |  |  | (6,335) |  |  | (1,273) |  |  | 1,719 |  |
| Interest expense | (8,131) |  |  | (1,756) |  |  | (9,994) |  |  | (5,694) |  |
| Income before income tax provision | 355,447 |  |  | 207,091 |  |  | 532,707 |  |  | 431,330 |  |
| Income tax provision | (61,503) |  |  | (29,573) |  |  | (81,718) |  |  | (68,507) |  |
| Share of income (loss) from equity investee, net of taxes | 2,024 |  |  | (1,351) |  |  | 1,974 |  |  | (2,240) |  |
| Net income | $ | 295,968 |  |  | $ | 176,167 |  |  | $ | 452,963 |  |  | $ | 360,583 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 5.47 |  |  | $ | 3.31 |  |  | $ | 8.45 |  |  | $ | 6.84 |  |
| Diluted | $ | 5.10 |  |  | $ | 3.14 |  |  | $ | 7.86 |  |  | $ | 6.51 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 54,135 |  |  | 53,160 |  |  | 53,614 |  |  | 52,726 |  |
| Diluted | 58,078 |  |  | 56,144 |  |  | 57,632 |  |  | 55,427 |  |

[0001375365-24-000008:8k_2_02:42]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-24-000008:8k_2_02:43]
|  | Three Months EndedDecember 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of sales | $ | 3,555 |  |  | $ | 1,486 |  |  | $ | 9,459 |  |  | $ | 2,370 |  |
| Research and development | 25,439 |  |  | 9,334 |  |  | 61,149 |  |  | 15,452 |  |
| Sales and marketing | 4,340 |  |  | 1,448 |  |  | 10,005 |  |  | 2,257 |  |
| General and administrative | 9,727 |  |  | 4,713 |  |  | 19,827 |  |  | 7,916 |  |
| Stock-based compensation expense | $ | 43,061 |  |  | $ | 16,981 |  |  | $ | 100,440 |  |  | $ | 27,995 |  |

[0001375365-24-000008:8k_2_02:44]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000008:8k_2_02:45]
SELECTED CASH FLOW INFORMATION

[0001375365-24-000008:8k_2_02:46]
(in thousands)

[0001375365-24-000008:8k_2_02:47]
(unaudited)

[0001375365-24-000008:8k_2_02:48]
|  | Six Months EndedDecember 31, |
|  | 2023 |  | 2022 |
| Net cash (used in) provided by operating activities | $ | (324,620) |  |  | $ | 474,674 |  |
| Net cash used in investing activities | (22,535) |  |  | (20,631) |  |
| Net cash provided by (used in) financing activities | 632,194 |  |  | (415,821) |  |
| Effect of exchange rate fluctuations on cash | 170 |  |  | (1,693) |  |
| Net increase in cash, cash equivalents and restricted cash | 285,209 |  |  | 36,529 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 440,960 |  |  | 268,559 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 726,169 |  |  | $ | 305,088 |  |

[0001375365-24-000008:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000008:8k_2_02:50]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-24-000008:8k_2_02:51]
(in thousands, except per share amounts)

[0001375365-24-000008:8k_2_02:52]
(unaudited)

[0001375365-24-000008:8k_2_02:53]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2023 |  |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| GAAP GROSS PROFIT | $ | 564,322 |  |  |  | $ | 337,422 |  |  | $ | 918,013 |  |  | $ | 684,957 |  |
| Stock-based compensation | 3,555 |  |  |  | 1,486 |  |  | 9,459 |  |  | 2,370 |  |
| NON-GAAP GROSS PROFIT | $ | 567,877 |  |  |  | $ | 338,908 |  |  | $ | 927,472 |  |  | $ | 687,327 |  |
| GAAP GROSS MARGIN | 15.4 | % |  |  | 18.7 | % |  | 15.9 | % |  | 18.7 | % |
| Stock-based compensation | 0.1 | % |  |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| NON-GAAP GROSS MARGIN | 15.5 | % |  |  | 18.8 | % |  | 16.0 | % |  | 18.8 | % |
| GAAP OPERATING EXPENSE | $ | 192,858 |  |  |  | $ | 122,240 |  |  | $ | 374,039 |  |  | $ | 249,652 |  |
| Stock-based compensation | (39,506) |  |  |  | (15,495) |  |  | (90,981) |  |  | (25,625) |  |
| Litigation recovery | — |  |  |  | 2,230 |  |  | — |  |  | 2,230 |  |
| NON-GAAP OPERATING EXPENSE | $ | 153,352 |  |  |  | $ | 108,975 |  |  | $ | 283,058 |  |  | $ | 226,257 |  |
| GAAP INCOME FROM OPERATIONS | $ | 371,464 |  |  |  | $ | 215,182 |  |  | $ | 543,974 |  |  | $ | 435,305 |  |
| Stock-based compensation | 43,061 |  |  |  | 16,981 |  |  | 100,440 |  |  | 27,995 |  |
| Litigation recovery | — |  |  |  | (2,230) |  |  | — |  |  | (2,230) |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 414,525 |  |  |  | $ | 229,933 |  |  | $ | 644,414 |  |  | $ | 461,070 |  |
| GAAP OPERATING MARGIN | 10.1 | % |  |  | 11.9 | % |  | 9.4 | % |  | 11.9 | % |
| Stock-based compensation | 1.2 | % |  |  | 1.0 | % |  | 1.7 | % |  | 0.8 | % |
| Litigation recovery | — | % |  |  | (0.1) | % |  | — | % |  | (0.1) | % |
| NON-GAAP OPERATING MARGIN | 11.3 | % |  |  | 12.8 | % |  | 11.1 | % |  | 12.6 | % |
| GAAP TAX EXPENSE | $ | 61,503 |  |  |  | $ | 29,573 |  |  | $ | 81,718 |  |  | $ | 68,507 |  |
| Adjustments to tax provision | 9,569 |  |  |  | 4,300 |  |  | 25,618 |  |  | 7,530 |  |
| NON-GAAP TAX EXPENSE | $ | 71,072 |  |  |  | $ | 33,873 |  |  | $ | 107,336 |  |  | $ | 76,037 |  |
| GAAP NET INCOME | $ | 295,968 |  |  |  | $ | 176,167 |  |  | $ | 452,963 |  |  | $ | 360,583 |  |
| Stock-based compensation | 43,061 |  |  |  | 16,981 |  |  | 100,440 |  |  | 27,995 |  |
| Litigation recovery | — |  |  |  | (2,230) |  |  | — |  |  | (2,230) |  |
| Adjustments to tax provision | (9,569) |  |  |  | (4,300) |  |  | (25,618) |  |  | (7,530) |  |
| NON-GAAP NET INCOME | $ | 329,460 |  |  |  | $ | 186,618 |  |  | $ | 527,785 |  |  | $ | 378,818 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 5.47 |  |  |  | $ | 3.31 |  |  | $ | 8.45 |  |  | $ | 6.84 |  |
| Impact of Non-GAAP adjustments | 0.62 |  |  |  | 0.20 |  |  | 1.39 |  |  | 0.34 |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 6.09 |  |  |  | $ | 3.51 |  |  | $ | 9.84 |  |  | $ | 7.18 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 5.10 |  |  |  | $ | 3.14 |  |  | $ | 7.86 |  |  | $ | 6.51 |  |
| Impact of Non-GAAP adjustments | 0.49 |  |  |  | 0.12 |  |  | 1.18 |  |  | 0.18 |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 5.59 |  |  |  | $ | 3.26 |  |  | $ | 9.04 |  |  | $ | 6.69 |  |

[0001375365-24-000008:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000008:8k_2_02:55]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-24-000008:8k_2_02:56]
(in thousands, except per share amounts)

[0001375365-24-000008:8k_2_02:57]
(unaudited)

[0001375365-24-000008:8k_2_02:58]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2023 |  |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 54,135 |  |  |  | 53,160 |  |  | 53,614 |  |  | 52,726 |  |
| BASIC – NON-GAAP | 54,135 |  |  |  | 53,160 |  |  | 53,614 |  |  | 52,726 |  |
| DILUTED – GAAP | 58,078 |  |  |  | 56,144 |  |  | 57,632 |  |  | 55,427 |  |
| DILUTED – NON-GAAP | 58,962 |  |  |  | 57,318 |  |  | 58,404 |  |  | 56,641 |  |

[0001375365-24-000008:8k_2_02:59]
Non-GAAP diluted net income per common share for the first quarter of fiscal year 2024 was $3.43, with adjustments for stock-based compensation expenses of $41 million, net of the related tax effects of $16 million.
