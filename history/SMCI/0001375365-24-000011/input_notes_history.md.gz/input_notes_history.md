# SMCI note change history — 0001375365-23-000041 → 0001375365-24-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:1]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2023 and any prior periods.
  (was, 2023-11-03, similarity 0.9893):
[0001375365-23-000041:note_history:1]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2023 and any prior periods.

- changed (2024-02-02):
[0001375365-24-000011:note_history:2]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2023, these remaining noncancelable commitments were $1.9 billion, including $87.4 million for related parties.
  (was, 2023-11-03, similarity 0.6083):
[0001375365-23-000041:note_history:2]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2023, these remaining noncancelable commitments were $1.4 billion, including $66.4 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.
  (was, 2023-11-03, similarity 0.7142):
[0001375365-23-000041:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.

- changed (2024-02-02):
[0001375365-24-000011:note_history:4]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 68.1% and 7.3% of total purchases for the three months ended December 31, 2023, and the same two suppliers accounted for 17.6% and 14.1% of total purchases for the three months ended December 31, 2022. Two suppliers accounted for 62.9% and 8.6% of total purchases for the six months ended December 31, 2023, and the same two suppliers accounted for 22.3% and 15.3% of total purchases for the six months ended December 31, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 68.1% and 62.9% of total purchases for the three and six months ended December 31, 2023, respectively, is as a result of the purchase of key components to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 3.6% and 6.7% of total cost of sales for the three months ended December 31, 2023 and 2022, respectively, and a combined 4.6% and 6.6% of total cost of sales for the six months ended December 31, 2023 and 2022, respectively.
  (was, 2023-11-03, similarity 0.6718):
[0001375365-23-000041:note_history:4]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 55.1% and 10.3% of total purchases for the three months ended September 30, 2023, and the same two suppliers accounted for 25.7% and 16.1% of total purchases for the three months ended September 30, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 55.1% of total purchases for the three months ended September 30, 2023 is as a result of the purchase of GPUs to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 6.4% of total cost of sales for both the three months ended September 30, 2023 and 2022.

- added (2024-02-02):
[0001375365-24-000011:note_history:5]
Four customers accounted for 26.7%, 16.3%, 13.0% and 11.3% of accounts receivable, net as of December 31, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.

- added (2024-02-02):
[0001375365-24-000011:note_history:6]
Two customers accounted for 25.5% and 10.4% of the net sales for the three months ended December 31, 2023 and one customer accounted for 25.3% of the net sales for the six months ended December 31, 2023. No single customer accounted for 10% or more of the net sales for the three months ended December 31, 2022, and one customer accounted for 15.8% of the net sales for the six months ended December 31, 2022.

- added (2024-02-02):
[0001375365-24-000011:note_history:7]
Accounting Pronouncements Not Yet Adopted

- added (2024-02-02):
[0001375365-24-000011:note_history:8]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

- added (2024-02-02):
[0001375365-24-000011:note_history:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning July 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

- removed (2024-02-02):
[0001375365-23-000041:note_history:10]
Three customers accounted for 15.7%, 14.5% and 10.3% of accounts receivable, net as of September 30, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.
One customer accounted for 25.0% of the net sales for the three months ended September 30, 2023. One customer accounted for 21.9% of the net sales for the three months ended September 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:11]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands):
  (was, 2023-11-03, similarity 0.9829):
[0001375365-23-000041:note_history:11]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:12]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 20,000 |  |  | — |  |
| Cathay Bank Line of Credit | 131,583 |  |  | 131,583 |  |
| 2023 CTBC Credit Lines | 36,873 |  |  | — |  |
| HSBC Bank Credit Facility | 29,704 |  |  | — |  |
| Mega Bank Credit Facility | 15,526 |  |  | — |  |
| Total line of credit | 233,686 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 22,911 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,579 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,991 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 28,463 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,419 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 35,580 |  |  | 38,668 |  |
| Total term loans | 141,943 |  |  | 158,719 |  |
| Total debt | 375,629 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 276,307 |  |  | 170,123 |  |
| Debt, non-current | $ | 99,322 |  |  | $ | 120,179 |  |
  (was, 2023-11-03, similarity 0.9127):
[0001375365-23-000041:note_history:12]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2021 CTBC Credit Lines | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | — |  |  | — |  |
| Total line of credit | — |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 23,892 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,424 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 4,183 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 29,756 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,782 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,195 |  |  | 38,668 |  |
| Total term loans | 146,232 |  |  | 158,719 |  |
| Total debt | 146,232 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 40,843 |  |  | 170,123 |  |
| Debt, non-current | $ | 105,389 |  |  | $ | 120,179 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:13]
Available borrowings and interest rates as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2023-11-03, similarity 0.9818):
[0001375365-23-000041:note_history:13]
Available borrowings and interest rates as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

- changed (2024-02-02):
[0001375365-24-000011:note_history:14]
|  | December 31, 2023 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | — |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 417 |  |  | 7.36% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2023 CTBC Credit Line | $ | 68,127 |  |  | 1.96% - 6.52% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.38% |  | $ | 20,000 |  |  | 6.58% |
| HSBC Bank Credit Facility | $ | 20,296 |  |  | 1.90% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 4,474 |  |  | 1.90% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.55% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.20% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.40% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.75% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.75% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.40% - 1.60% |  | $ | — |  |  | 1.40% - 1.60% |
  (was, 2023-11-03, similarity 0.7611):
[0001375365-23-000041:note_history:14]
|  | September 30, 2023 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.80% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.50% |  | $ | 417 |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  | — |  | $ | 105,000 |  | 3.33% |
| 2023 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.51% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | 50,000 |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 20,000 |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | — |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.75% |  | $ | 7,734 |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.40% - 1.60% |

- changed (2024-02-02):
[0001375365-24-000011:note_history:15]
The Company entered into new agreements during the six months ended December 31, 2023 with the following terms:
  (was, 2023-11-03, similarity 0.813):
[0001375365-23-000041:note_history:15]
The Company entered into a new General Credit Agreement with CTBC Bank during the three months ended  September 30, 2023 with the following terms:

- added (2024-02-02):
[0001375365-24-000011:note_history:16]
As of December 31, 2023, the outstanding borrowings under the 2023 CTBC Bank Credit Lines were $36.9 million. The interest rate for these loans were 1.96% - 6.52% per annum as of December 31, 2023.

- added (2024-02-02):
[0001375365-24-000011:note_history:17]
HSBC Bank

- added (2024-02-02):
[0001375365-24-000011:note_history:18]
2023 HSBC Bank Credit Lines

- added (2024-02-02):
[0001375365-24-000011:note_history:19]
On December 7, 2023, the Company's Taiwan subsidiary entered into a new Facility Letter with the Taiwan affiliate of HSBC Bank. The New Facility Letter is substantially identical to the prior Facility Letter entered into with HSBC Bank on February 7, 2023. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”, and together with the NTD Revolver, the "HSBC Bank Credit Lines"). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date.

- added (2024-02-02):
[0001375365-24-000011:note_history:20]
Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash coverage.

- added (2024-02-02):
[0001375365-24-000011:note_history:21]
As of December 31, 2023, the outstanding borrowings under HSBC Bank Credit Lines were $29.7 million. The interest rates for these loans were 1.90% - 6.37% per annum as of December 31, 2023.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:22]
Short-term and long-term debt obligations as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands):
  (was, 2023-11-03, similarity 0.9785):
[0001375365-23-000041:note_history:22]
Short-term and long-term debt obligations as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:23]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 20,000 |  |  | — |  |
| Cathay Bank Line of Credit | 131,583 |  |  | 131,583 |  |
| 2023 CTBC Credit Lines | 36,873 |  |  | — |  |
| HSBC Bank Credit Facility | 29,704 |  |  | — |  |
| Mega Bank Credit Facility | 15,526 |  |  | — |  |
| Total line of credit | 233,686 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 22,911 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,579 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,991 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 28,463 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,419 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 35,580 |  |  | 38,668 |  |
| Total term loans | 141,943 |  |  | 158,719 |  |
| Total debt | 375,629 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 276,307 |  |  | 170,123 |  |
| Debt, non-current | $ | 99,322 |  |  | $ | 120,179 |  |
  (was, 2023-11-03, similarity 0.9127):
[0001375365-23-000041:note_history:23]
|  | September 30, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2021 CTBC Credit Lines | — |  |  | — |  |
| HSBC Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | — |  |  | — |  |
| Total line of credit | — |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 23,892 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,424 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 4,183 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 29,756 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,782 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 37,195 |  |  | 38,668 |  |
| Total term loans | 146,232 |  |  | 158,719 |  |
| Total debt | 146,232 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 40,843 |  |  | 170,123 |  |
| Debt, non-current | $ | 105,389 |  |  | $ | 120,179 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:24]
Available borrowings and interest rates as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2023-11-03, similarity 0.9818):
[0001375365-23-000041:note_history:24]
Available borrowings and interest rates as of September 30, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

- changed (2024-02-02):
[0001375365-24-000011:note_history:25]
|  | December 31, 2023 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | — |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 417 |  |  | 7.36% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2023 CTBC Credit Line | $ | 68,127 |  |  | 1.96% - 6.52% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.38% |  | $ | 20,000 |  |  | 6.58% |
| HSBC Bank Credit Facility | $ | 20,296 |  |  | 1.90% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 4,474 |  |  | 1.90% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.55% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.20% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.40% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.75% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.75% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.40% - 1.60% |  | $ | — |  |  | 1.40% - 1.60% |
  (was, 2023-11-03, similarity 0.7611):
[0001375365-23-000041:note_history:25]
|  | September 30, 2023 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.80% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.50% |  | $ | 417 |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  | — |  | $ | 105,000 |  | 3.33% |
| 2023 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.51% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | 50,000 |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 20,000 |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | — |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.75% |  | $ | 7,734 |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.40% - 1.60% |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:26]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.
  (was, 2023-11-03, similarity 0.9213):
[0001375365-23-000041:note_history:26]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- added (2024-02-02):
[0001375365-24-000011:note_history:27]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 87.2% and 95.5% of the chassis included in the products sold by the Company during the three months ended December 31, 2023 and 2022, respectively, and 86.3% and 91.8% of the chassis included in the products sold by the Company during the six months ended December 31, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2024-02-02):
[0001375365-24-000011:note_history:28]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on December 31, 2023 were $49.1 million and $37.5 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2023-11-03, similarity 0.997):
[0001375365-23-000041:note_history:28]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on September 30, 2023 were $49.5 million and $27.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2024-02-02):
[0001375365-24-000011:note_history:29]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on December 31, 2023 were $121.6 million and $49.9 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2023-11-03, similarity 0.9957):
[0001375365-23-000041:note_history:29]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on September 30, 2023 were $138.2 million and $38.8 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2024-02-02):
[0001375365-24-000011:note_history:30]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of December 31, 2023 and June 30, 2023.
  (was, 2023-11-03, similarity 0.9828):
[0001375365-23-000041:note_history:30]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of September 30, 2023 and June 30, 2023.

- changed (2024-02-02):
[0001375365-24-000011:note_history:31]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2023. No impairment charge was recorded for the three and six months ended December 31, 2023 or 2022.
  (was, 2023-11-03, similarity 0.9697):
[0001375365-23-000041:note_history:31]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2023. No impairment charge was recorded for the three months ended September 30, 2023 or 2022.

- added (2024-02-02):
[0001375365-24-000011:note_history:32]
The Company sold products worth $11.4 million and $6.0 million to the Corporate Venture during the three months ended December 31, 2023 and 2022, respectively, and $12.2 million and $17.3 million to the Corporate Venture during the six months ended December 31, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $3.5 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of December 31, 2023 and June 30, 2023, respectively.

- changed (2024-02-02):
[0001375365-24-000011:note_history:33]
The Company had the following balances related to transactions with its related parties as of December 31, 2023 and June 30, 2023 (in thousands):
  (was, 2023-11-03, similarity 0.9815):
[0001375365-23-000041:note_history:33]
The Company had the following balances related to transactions with its related parties as of September 30, 2023 and June 30, 2023 (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:34]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  |  |  | December 31, 2023 |  | June 30, 2023 |
| Accounts receivable | $ | 2 |  |  | $ | 2 |  |  | $ | 289 |  |  | $ | 3,528 |  |  | $ | 3,568 |  |  | $ | 1,943 |  |  |  |  | $ | 3,859 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,270 |  |  | $ | 2,841 |  |  | $ | 32,023 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 34,293 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 46,649 |  |  | $ | 35,711 |  |  | $ | 55,051 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 101,700 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 1,074 |  |  | $ | 1,230 |  |  | $ | 17,435 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,509 |  |  | $ | 14,017 |  |
  (was, 2023-11-03, similarity 0.6646):
[0001375365-23-000041:note_history:34]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 |  |  | September 30, 2023 | June 30, 2023 |
| Accounts receivable | $ | 4 |  | $ | 2 |  | $ | 1,092 |  | $ | 3,528 |  | $ | 239 |  | $ | 1,943 |  |  |  | $ | 1,335 |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,283 |  | $ | 2,841 |  | $ | 22,622 |  | $ | 24,891 |  | $ | — |  | $ | — |  |  |  | $ | 24,905 |  | $ | 27,732 |  |
| Accounts payable | $ | 44,476 |  | $ | 35,711 |  | $ | 47,639 |  | $ | 53,423 |  | $ | — |  | $ | — |  |  |  | $ | 92,115 |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 485 |  | $ | 1,230 |  | $ | 16,019 |  | $ | 12,787 |  | $ | — |  | $ | — |  |  |  | $ | 16,504 |  | $ | 14,017 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:35]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2023 and 2022, are as follows (in thousands):
  (was, 2023-11-03, similarity 0.9833):
[0001375365-23-000041:note_history:35]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:36]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 4 |  |  | $ | 2 |  |  | $ | 4,392 |  |  | $ | 14,113 |  |  | $ | 11,385 |  |  | $ | 5,958 |  |  |  |  | $ | 15,781 |  |  | $ | 20,073 |  |
| Purchases - inventory | $ | 50,586 |  |  | $ | 46,715 |  |  | $ | 61,859 |  |  | $ | 52,028 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 112,445 |  |  | $ | 98,743 |  |
| Purchases - other miscellaneous items | $ | 3,456 |  |  | $ | 2,763 |  |  | $ | 332 |  |  | $ | 279 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 3,788 |  |  | $ | 3,042 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:37]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):
  (was, 2023-11-03, similarity 0.902):
[0001375365-23-000041:note_history:37]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:38]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 6 |  |  | $ | 3 |  |  | $ | 20,998 |  |  | $ | 27,872 |  |  | $ | 12,173 |  |  | $ | 17,251 |  |  |  |  | $ | 33,177 |  |  | $ | 45,126 |  |
| Purchases - inventory | $ | 97,199 |  |  | $ | 94,562 |  |  | $ | 128,353 |  |  | $ | 100,717 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 225,552 |  |  | $ | 195,279 |  |
| Purchases - other miscellaneous items | $ | 8,215 |  |  | $ | 7,526 |  |  | $ | 749 |  |  | $ | 537 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 8,964 |  |  | $ | 8,063 |  |

- added (2024-02-02):
[0001375365-24-000011:note_history:39]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:40]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Changes in accounts receivable | $ | — |  |  | $ | — |  |  | $ | 3,239 |  |  | $ | 137 |  |  | $ | (1,625) |  |  | $ | 3,041 |  |  |  |  | $ | 1,614 |  |  | $ | 3,178 |  |
| Changes in other receivable | $ | 571 |  |  | $ | 1,364 |  |  | $ | (7,132) |  |  | $ | (24,289) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (6,561) |  |  | $ | (22,925) |  |
| Changes in accounts payable | $ | 10,938 |  |  | $ | (3,589) |  |  | $ | 1,628 |  |  | $ | 4,340 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 12,566 |  |  | $ | 751 |  |
| Changes in accrued liabilities | $ | (156) |  |  | $ | (2,009) |  |  | $ | 4,648 |  |  | $ | 2,860 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,492 |  |  | $ | 851 |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | (168) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (152) |  |  | $ | (168) |  |
| Purchases of property, plant and equipment | $ | 4,460 |  |  | $ | 4,366 |  |  | $ | 68 |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,528 |  |  | $ | 4,514 |  |
| Unpaid property, plant and equipment | $ | 2,570 |  |  | $ | 1,764 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 2,577 |  |  | $ | 1,764 |  |

- removed (2024-02-02):
[0001375365-23-000041:note_history:41]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 85.5% and 88.4% of the chassis included in the products sold by the Company during the three months ended September 30, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2024-02-02):
[0001375365-23-000041:note_history:42]
The Company sold products worth $0.8 million and $11.3 million to the Corporate Venture during the three months ended September 30, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.2 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of September 30, 2023 and June 30, 2023, respectively.

- removed (2024-02-02):
[0001375365-23-000041:note_history:43]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 16,606 |  | $ | 13,760 |  | $ | 788 |  | $ | 11,293 |  |  |  | $ | 17,396 |  | $ | 25,055 |  |
| Purchases - inventory | $ | 46,614 |  | $ | 47,847 |  | $ | 66,493 |  | $ | 48,689 |  | $ | — |  | $ | — |  |  |  | 113,107 |  | 96,536 |  |
| Purchases - other miscellaneous items | $ | 4,759 |  | $ | 4,763 |  | $ | 417 |  | $ | 258 |  | $ | — |  | $ | — |  |  |  | $ | 5,176 |  | $ | 5,021 |  |

- removed (2024-02-02):
[0001375365-23-000041:note_history:44]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Changes in accounts receivable | $ | (2) |  | $ | — |  | $ | 2,436 |  | $ | (478) |  | $ | 1,704 |  | $ | (1,373) |  |  |  | $ | 4,138 |  | $ | (1,851) |  |
| Changes in other receivable | $ | 558 |  | $ | 1,276 |  | $ | 2,269 |  | $ | (11,415) |  | $ | — |  | $ | — |  |  |  | $ | 2,827 |  | $ | (10,139) |  |
| Changes in accounts payable | $ | 8,765 |  | $ | 664 |  | $ | (5,784) |  | $ | 6,010 |  | $ | — |  | $ | — |  |  |  | $ | 2,981 |  | $ | 6,674 |  |
| Changes in accrued liabilities | $ | (745) |  | $ | (1,532) |  | $ | 3,232 |  | $ | 11,117 |  | $ | — |  | $ | — |  |  |  | $ | 2,487 |  | $ | 9,585 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (80) |  | $ | (105) |  | $ | — |  | $ | — |  |  |  | $ | (80) |  | $ | (105) |  |
| Purchases of property, plant and equipment | $ | 782 |  | $ | 583 |  | $ | 44 |  | $ | 146 |  | $ | — |  | $ | — |  |  |  | $ | 826 |  | $ | 729 |  |
| Unpaid property, plant and equipment | $ | 3,672 |  | $ | 3,782 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 3,672 |  | $ | 3,782 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:45]
The Company had the following balances related to transactions with its related parties as of December 31, 2023 and June 30, 2023 (in thousands):
  (was, 2023-11-03, similarity 0.9815):
[0001375365-23-000041:note_history:45]
The Company had the following balances related to transactions with its related parties as of September 30, 2023 and June 30, 2023 (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:46]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  |  |  | December 31, 2023 |  | June 30, 2023 |
| Accounts receivable | $ | 2 |  |  | $ | 2 |  |  | $ | 289 |  |  | $ | 3,528 |  |  | $ | 3,568 |  |  | $ | 1,943 |  |  |  |  | $ | 3,859 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,270 |  |  | $ | 2,841 |  |  | $ | 32,023 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 34,293 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 46,649 |  |  | $ | 35,711 |  |  | $ | 55,051 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 101,700 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 1,074 |  |  | $ | 1,230 |  |  | $ | 17,435 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,509 |  |  | $ | 14,017 |  |
  (was, 2023-11-03, similarity 0.6646):
[0001375365-23-000041:note_history:46]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 | September 30, 2023 | June 30, 2023 |  |  | September 30, 2023 | June 30, 2023 |
| Accounts receivable | $ | 4 |  | $ | 2 |  | $ | 1,092 |  | $ | 3,528 |  | $ | 239 |  | $ | 1,943 |  |  |  | $ | 1,335 |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,283 |  | $ | 2,841 |  | $ | 22,622 |  | $ | 24,891 |  | $ | — |  | $ | — |  |  |  | $ | 24,905 |  | $ | 27,732 |  |
| Accounts payable | $ | 44,476 |  | $ | 35,711 |  | $ | 47,639 |  | $ | 53,423 |  | $ | — |  | $ | — |  |  |  | $ | 92,115 |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 485 |  | $ | 1,230 |  | $ | 16,019 |  | $ | 12,787 |  | $ | — |  | $ | — |  |  |  | $ | 16,504 |  | $ | 14,017 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:47]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2023 and 2022, are as follows (in thousands):
  (was, 2023-11-03, similarity 0.9833):
[0001375365-23-000041:note_history:47]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:48]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 4 |  |  | $ | 2 |  |  | $ | 4,392 |  |  | $ | 14,113 |  |  | $ | 11,385 |  |  | $ | 5,958 |  |  |  |  | $ | 15,781 |  |  | $ | 20,073 |  |
| Purchases - inventory | $ | 50,586 |  |  | $ | 46,715 |  |  | $ | 61,859 |  |  | $ | 52,028 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 112,445 |  |  | $ | 98,743 |  |
| Purchases - other miscellaneous items | $ | 3,456 |  |  | $ | 2,763 |  |  | $ | 332 |  |  | $ | 279 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 3,788 |  |  | $ | 3,042 |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:49]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):
  (was, 2023-11-03, similarity 0.902):
[0001375365-23-000041:note_history:49]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:50]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 6 |  |  | $ | 3 |  |  | $ | 20,998 |  |  | $ | 27,872 |  |  | $ | 12,173 |  |  | $ | 17,251 |  |  |  |  | $ | 33,177 |  |  | $ | 45,126 |  |
| Purchases - inventory | $ | 97,199 |  |  | $ | 94,562 |  |  | $ | 128,353 |  |  | $ | 100,717 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 225,552 |  |  | $ | 195,279 |  |
| Purchases - other miscellaneous items | $ | 8,215 |  |  | $ | 7,526 |  |  | $ | 749 |  |  | $ | 537 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 8,964 |  |  | $ | 8,063 |  |

- added (2024-02-02):
[0001375365-24-000011:note_history:51]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- added (2024-02-02):
[0001375365-24-000011:note_history:52]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Changes in accounts receivable | $ | — |  |  | $ | — |  |  | $ | 3,239 |  |  | $ | 137 |  |  | $ | (1,625) |  |  | $ | 3,041 |  |  |  |  | $ | 1,614 |  |  | $ | 3,178 |  |
| Changes in other receivable | $ | 571 |  |  | $ | 1,364 |  |  | $ | (7,132) |  |  | $ | (24,289) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (6,561) |  |  | $ | (22,925) |  |
| Changes in accounts payable | $ | 10,938 |  |  | $ | (3,589) |  |  | $ | 1,628 |  |  | $ | 4,340 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 12,566 |  |  | $ | 751 |  |
| Changes in accrued liabilities | $ | (156) |  |  | $ | (2,009) |  |  | $ | 4,648 |  |  | $ | 2,860 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,492 |  |  | $ | 851 |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | (168) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (152) |  |  | $ | (168) |  |
| Purchases of property, plant and equipment | $ | 4,460 |  |  | $ | 4,366 |  |  | $ | 68 |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,528 |  |  | $ | 4,514 |  |
| Unpaid property, plant and equipment | $ | 2,570 |  |  | $ | 1,764 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 2,577 |  |  | $ | 1,764 |  |

- removed (2024-02-02):
[0001375365-23-000041:note_history:53]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 16,606 |  | $ | 13,760 |  | $ | 788 |  | $ | 11,293 |  |  |  | $ | 17,396 |  | $ | 25,055 |  |
| Purchases - inventory | $ | 46,614 |  | $ | 47,847 |  | $ | 66,493 |  | $ | 48,689 |  | $ | — |  | $ | — |  |  |  | 113,107 |  | 96,536 |  |
| Purchases - other miscellaneous items | $ | 4,759 |  | $ | 4,763 |  | $ | 417 |  | $ | 258 |  | $ | — |  | $ | — |  |  |  | $ | 5,176 |  | $ | 5,021 |  |

- removed (2024-02-02):
[0001375365-23-000041:note_history:54]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |  | Three months ended September 30, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |  |  | 2023 | 2022 |
| Changes in accounts receivable | $ | (2) |  | $ | — |  | $ | 2,436 |  | $ | (478) |  | $ | 1,704 |  | $ | (1,373) |  |  |  | $ | 4,138 |  | $ | (1,851) |  |
| Changes in other receivable | $ | 558 |  | $ | 1,276 |  | $ | 2,269 |  | $ | (11,415) |  | $ | — |  | $ | — |  |  |  | $ | 2,827 |  | $ | (10,139) |  |
| Changes in accounts payable | $ | 8,765 |  | $ | 664 |  | $ | (5,784) |  | $ | 6,010 |  | $ | — |  | $ | — |  |  |  | $ | 2,981 |  | $ | 6,674 |  |
| Changes in accrued liabilities | $ | (745) |  | $ | (1,532) |  | $ | 3,232 |  | $ | 11,117 |  | $ | — |  | $ | — |  |  |  | $ | 2,487 |  | $ | 9,585 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (80) |  | $ | (105) |  | $ | — |  | $ | — |  |  |  | $ | (80) |  | $ | (105) |  |
| Purchases of property, plant and equipment | $ | 782 |  | $ | 583 |  | $ | 44 |  | $ | 146 |  | $ | — |  | $ | — |  |  |  | $ | 826 |  | $ | 729 |  |
| Unpaid property, plant and equipment | $ | 3,672 |  | $ | 3,782 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 3,672 |  | $ | 3,782 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:55]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 3,435,562 |  |  | $ | 1,660,931 |  |  | $ | 5,402,170 |  |  | $ | 3,373,987 |  |
| Subsystems and accessories | 229,362 |  |  | 142,264 |  |  | 382,426 |  |  | 281,338 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |
  (was, 2023-11-03, similarity 0.7316):
[0001375365-23-000041:note_history:55]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Server and storage systems | $ | 1,966,608 |  |  | $ | 1,713,056 |  |  |  |  |  |
| Subsystems and accessories | 153,064 |  |  | 139,074 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:56]
The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):
  (was, 2023-11-03, similarity 0.9486):
[0001375365-23-000041:note_history:56]
The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:57]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 2,605,585 |  |  | $ | 1,091,391 |  |  | $ | 4,225,099 |  |  | $ | 2,386,895 |  |
| Asia | 656,220 |  |  | 330,711 |  |  | 881,688 |  |  | 600,735 |  |
| Europe | 288,448 |  |  | 312,533 |  |  | 479,296 |  |  | 547,607 |  |
| Other | 114,671 |  |  | 68,560 |  |  | 198,513 |  |  | 120,088 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |
  (was, 2023-11-03, similarity 0.7323):
[0001375365-23-000041:note_history:57]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 1,619,514 |  |  | $ | 1,295,504 |  |  |  |  |  |
| Asia | 225,468 |  |  | 270,024 |  |  |  |  |  |
| Europe | 190,848 |  |  | 235,074 |  |  |  |  |  |
| Other | 83,842 |  |  | 51,528 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0001375365-24-000011:note_history:58]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 3,435,562 |  |  | $ | 1,660,931 |  |  | $ | 5,402,170 |  |  | $ | 3,373,987 |  |
| Subsystems and accessories | 229,362 |  |  | 142,264 |  |  | 382,426 |  |  | 281,338 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |
  (was, 2023-11-03, similarity 0.7316):
[0001375365-23-000041:note_history:58]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Server and storage systems | $ | 1,966,608 |  |  | $ | 1,713,056 |  |  |  |  |  |
| Subsystems and accessories | 153,064 |  |  | 139,074 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:59]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):
  (was, 2023-11-03, similarity 0.9122):
[0001375365-23-000041:note_history:59]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2023 and 2022, of net sales by geographic region (in thousands):

- changed (2024-02-02):
[0001375365-24-000011:note_history:60]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 2,605,585 |  |  | $ | 1,091,391 |  |  | $ | 4,225,099 |  |  | $ | 2,386,895 |  |
| Asia | 656,220 |  |  | 330,711 |  |  | 881,688 |  |  | 600,735 |  |
| Europe | 288,448 |  |  | 312,533 |  |  | 479,296 |  |  | 547,607 |  |
| Other | 114,671 |  |  | 68,560 |  |  | 198,513 |  |  | 120,088 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |
  (was, 2023-11-03, similarity 0.7323):
[0001375365-23-000041:note_history:60]
|  | Three Months Ended September 30, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| United States | $ | 1,619,514 |  |  | $ | 1,295,504 |  |  |  |  |  |
| Asia | 225,468 |  |  | 270,024 |  |  |  |  |  |
| Europe | 190,848 |  |  | 235,074 |  |  |  |  |  |
| Other | 83,842 |  |  | 51,528 |  |  |  |  |  |
| Total | $ | 2,119,672 |  |  | $ | 1,852,130 |  |  |  |  |  |

- changed (2024-02-02):
[0001375365-24-000011:note_history:61]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.
  (was, 2023-11-03, similarity 0.9565):
[0001375365-23-000041:note_history:61]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three months ended September 30, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $43.7 million.

- changed (2024-02-02):
[0001375365-24-000011:note_history:62]
Deferred revenue increased $79.2 million as of December 31, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $44.3 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.
  (was, 2023-11-03, similarity 0.9916):
[0001375365-23-000041:note_history:62]
Deferred revenue increased $36.1 million as of September 30, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $21.1 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

- changed (2024-02-02):
[0001375365-24-000011:note_history:63]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2023 was approximately $383.6 million. The Company expects to recognize approximately 50% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2023-11-03, similarity 0.9963):
[0001375365-23-000041:note_history:63]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2023 was approximately $340.5 million. The Company expects to recognize approximately 49% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-02-02):
[0001375365-24-000011:note_history:64]
Subsequent Events
On January 26, 2024, the Company entered into an agreement to purchase real estate for an aggregate price of $80.0 million, subject to certain adjustments to be determined at closing. The transaction is expected to close during the third quarter of fiscal 2024. The Company plans to acquire this property using its own cash.

- added (2024-02-02):
[0001375365-24-000011:note_history:65]
On January 31, 2024, the Company entered into a lease for approximately 260,000 square feet of space in San Jose, California for a term of 79 months. The Company currently intends to use such premises for additional warehouse space. The lease also provides that the Company is required to rent an additional approximate 198,000 square feet of space in the same building after such space becomes available for the remainder of the term stated above. Aggregate payment under the lease for both the primary space and additional space is approximately $0.6 million per month, subject to annual increase.
