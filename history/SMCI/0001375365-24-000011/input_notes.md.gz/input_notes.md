# SMCI notes — 0001375365-24-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-24-000011:notes:1]
[same as prior period, unchanged from 0001375365-23-000041:notes:1]

[0001375365-24-000011:notes:2]
[same as prior period, unchanged from 0001375365-23-000041:notes:2]

[0001375365-24-000011:notes:3]
[same as prior period, unchanged from 0001375365-23-000041:notes:3]

[0001375365-24-000011:notes:4]
[same as prior period, unchanged from 0001375365-23-000041:notes:4]

[0001375365-24-000011:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.

[0001375365-24-000011:notes:6]
[same as prior period, unchanged from 0001375365-23-000041:notes:6]

[0001375365-24-000011:notes:7]
[same as prior period, unchanged from 0001375365-23-000041:notes:7]

[0001375365-24-000011:notes:8]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 68.1% and 7.3% of total purchases for the three months ended December 31, 2023, and the same two suppliers accounted for 17.6% and 14.1% of total purchases for the three months ended December 31, 2022. Two suppliers accounted for 62.9% and 8.6% of total purchases for the six months ended December 31, 2023, and the same two suppliers accounted for 22.3% and 15.3% of total purchases for the six months ended December 31, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 68.1% and 62.9% of total purchases for the three and six months ended December 31, 2023, respectively, is as a result of the purchase of key components to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 3.6% and 6.7% of total cost of sales for the three months ended December 31, 2023 and 2022, respectively, and a combined 4.6% and 6.6% of total cost of sales for the six months ended December 31, 2023 and 2022, respectively.

[0001375365-24-000011:notes:9]
[same as prior period, unchanged from 0001375365-23-000041:notes:9]

[0001375365-24-000011:notes:10]
[same as prior period, unchanged from 0001375365-23-000041:notes:10]

[0001375365-24-000011:notes:11]
Four customers accounted for 26.7%, 16.3%, 13.0% and 11.3% of accounts receivable, net as of December 31, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.

[0001375365-24-000011:notes:12]
Two customers accounted for 25.5% and 10.4% of the net sales for the three months ended December 31, 2023 and one customer accounted for 25.3% of the net sales for the six months ended December 31, 2023. No single customer accounted for 10% or more of the net sales for the three months ended December 31, 2022, and one customer accounted for 15.8% of the net sales for the six months ended December 31, 2022.

[0001375365-24-000011:notes:13]
Accounting Pronouncements Not Yet Adopted

[0001375365-24-000011:notes:14]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

[0001375365-24-000011:notes:15]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning July 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-24-000011:notes:16]
[same as prior period, unchanged from 0001375365-23-000041:notes:12]

[0001375365-24-000011:notes:17]
[same as prior period, unchanged from 0001375365-23-000041:notes:13]

[0001375365-24-000011:notes:18]
[same as prior period, unchanged from 0001375365-23-000041:notes:14]

[0001375365-24-000011:notes:19]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 3,435,562 |  |  | $ | 1,660,931 |  |  | $ | 5,402,170 |  |  | $ | 3,373,987 |  |
| Subsystems and accessories | 229,362 |  |  | 142,264 |  |  | 382,426 |  |  | 281,338 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |

[0001375365-24-000011:notes:20]
[same as prior period, unchanged from 0001375365-23-000041:notes:16]

[0001375365-24-000011:notes:21]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):

[0001375365-24-000011:notes:22]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 2,605,585 |  |  | $ | 1,091,391 |  |  | $ | 4,225,099 |  |  | $ | 2,386,895 |  |
| Asia | 656,220 |  |  | 330,711 |  |  | 881,688 |  |  | 600,735 |  |
| Europe | 288,448 |  |  | 312,533 |  |  | 479,296 |  |  | 547,607 |  |
| Other | 114,671 |  |  | 68,560 |  |  | 198,513 |  |  | 120,088 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |

[0001375365-24-000011:notes:23]
[same as prior period, unchanged from 0001375365-23-000041:notes:19]

[0001375365-24-000011:notes:24]
[same as prior period, unchanged from 0001375365-23-000041:notes:20]

[0001375365-24-000011:notes:25]
[same as prior period, unchanged from 0001375365-23-000041:notes:21]

[0001375365-24-000011:notes:26]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.

[0001375365-24-000011:notes:27]
Deferred revenue increased $79.2 million as of December 31, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $44.3 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-24-000011:notes:28]
[same as prior period, unchanged from 0001375365-23-000041:notes:24]

[0001375365-24-000011:notes:29]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2023 was approximately $383.6 million. The Company expects to recognize approximately 50% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-24-000011:notes:30]
[same as prior period, unchanged from 0001375365-23-000041:notes:26]

[0001375365-24-000011:notes:31]
[same as prior period, unchanged from 0001375365-23-000041:notes:27]

[0001375365-24-000011:notes:32]
[same as prior period, unchanged from 0001375365-23-000041:notes:28]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-24-000011:notes:33]
The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-24-000011:notes:34]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2023 and 2022 (in thousands, except per share amounts):

[0001375365-24-000011:notes:35]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 295,968 |  |  | $ | 176,167 |  |  | $ | 452,963 |  |  | $ | 360,583 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 54,135 |  |  | 53,160 |  |  | 53,614 |  |  | 52,726 |  |
| Effect of dilutive securities | 3,943 |  |  | 2,984 |  |  | 4,017 |  |  | 2,701 |  |
| Weighted-average diluted shares | 58,078 |  |  | 56,144 |  |  | 57,632 |  |  | 55,427 |  |
| Basic net income per common share | $ | 5.47 |  |  | $ | 3.31 |  |  | $ | 8.45 |  |  | $ | 6.84 |  |
| Diluted net income per common share | $ | 5.10 |  |  | $ | 3.14 |  |  | $ | 7.86 |  |  | $ | 6.51 |  |

[0001375365-24-000011:notes:36]
For the three and six months ended December 31, 2023 and 2022, the Company had stock options and restricted stock units ("RSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 584,855 and 211,729 for the three months ended December 31, 2023 and 2022, respectively, and 461,292 and 259,562 for the six months ended December 31, 2023 and 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-24-000011:notes:37]
[same as prior period, unchanged from 0001375365-23-000041:notes:33]

[0001375365-24-000011:notes:38]
[same as prior period, unchanged from 0001375365-23-000041:notes:34]

[0001375365-24-000011:notes:39]
|  | December 31, 2023 |  | June 30, 2023 |
| Cash and cash equivalents | $ | 725,660 |  |  | $ | 440,459 |  |
| Restricted cash included in other assets | 509 |  |  | 501 |  |
| Total cash, cash equivalents and restricted cash | $ | 726,169 |  |  | $ | 440,960 |  |

[0001375365-24-000011:notes:40]
[same as prior period, unchanged from 0001375365-23-000041:notes:36]

[0001375365-24-000011:notes:41]
|  | December 31, 2023 |  | June 30, 2023 |
| Finished goods | $ | 1,566,278 |  |  | $ | 1,045,177 |  |
| Work in process | 516,331 |  |  | 71,874 |  |
| Purchased parts and raw materials | 384,388 |  |  | 328,513 |  |
| Total inventories | $ | 2,466,997 |  |  | $ | 1,445,564 |  |

[0001375365-24-000011:notes:42]
[same as prior period, unchanged from 0001375365-23-000041:notes:38]

[0001375365-24-000011:notes:43]
|  | December 31, 2023 |  | June 30, 2023 |
| Buildings | $ | 143,496 |  |  | $ | 143,496 |  |
| Machinery and equipment | 138,256 |  |  | 130,151 |  |
| Land | 90,754 |  |  | 86,642 |  |
| Building and leasehold improvements | 61,708 |  |  | 59,634 |  |
| Furniture and fixtures | 38,820 |  |  | 36,303 |  |
| Software | 23,823 |  |  | 23,098 |  |
| Building construction in progress | 1,941 |  |  | 303 |  |
|  | 498,798 |  |  | 479,627 |  |
| Accumulated depreciation and amortization | (201,696) |  |  | (189,387) |  |
| Property, plant and equipment, net | $ | 297,102 |  |  | $ | 290,240 |  |

[0001375365-24-000011:notes:44]
[same as prior period, unchanged from 0001375365-23-000041:notes:40]

[0001375365-24-000011:notes:45]
|  | December 31, 2023 |  | June 30, 2023 |
| Accrued payroll and related expenses | $ | 64,237 |  |  | $ | 53,439 |  |
| Customer deposits | 35,965 |  |  | 16,577 |  |
| Contract manufacturers liabilities | 24,565 |  |  | 23,634 |  |
| Accrued cooperative marketing expenses | 12,153 |  |  | 9,744 |  |
| Accrued warranty costs | 9,554 |  |  | 9,079 |  |
| Operating lease liability | 8,940 |  |  | 7,292 |  |
| Accrued professional fees | 756 |  |  | 2,363 |  |
| Other | 58,292 |  |  | 41,737 |  |
| Total accrued liabilities | $ | 214,462 |  |  | $ | 163,865 |  |

[0001375365-24-000011:notes:46]
[same as prior period, unchanged from 0001375365-23-000041:notes:42]

[0001375365-24-000011:notes:47]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Balance, beginning of the period | $ | 15,629 |  |  | $ | 12,703 |  |  | $ | 14,859 |  |  | $ | 12,136 |  |
| Provision for warranty | 10,515 |  |  | 8,933 |  |  | 23,044 |  |  | 17,550 |  |
| Costs utilized | (9,587) |  |  | (8,553) |  |  | (21,391) |  |  | (17,026) |  |
| Change in estimated liability for pre-existing warranties | 59 |  |  | 193 |  |  | 104 |  |  | 616 |  |
| Balance, end of the period | 16,616 |  |  | 13,276 |  |  | 16,616 |  |  | 13,276 |  |
| Current portion | 9,554 |  |  | 8,668 |  |  | 9,554 |  |  | 8,668 |  |
| Non-current portion | $ | 7,062 |  |  | $ | 4,608 |  |  | $ | 7,062 |  |  | $ | 4,608 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-24-000011:notes:48]
Fair Value Disclosure
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-24-000011:notes:49]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of December 31, 2023 and June 30, 2023. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-24-000011:notes:50]
[same as prior period, unchanged from 0001375365-23-000041:notes:45]

[0001375365-24-000011:notes:51]
The following table sets forth the Company’s financial instruments as of December 31, 2023 and June 30, 2023, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-24-000011:notes:52]
| December 31, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 284 |  |  | $ | — |  |  | $ | — |  |  | $ | 284 |  |
| Certificates of deposit (2) | — |  |  | 465 |  |  | — |  |  | 465 |  |
| Investment in marketable equity security | 4,176 |  |  | — |  |  | — |  |  | 4,176 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 4,460 |  |  | $ | 465 |  |  | $ | 1,843 |  |  | $ | 6,768 |  |
| June 30, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,823 |  |
| Certificates of deposit (2) | — |  |  | 462 |  |  | — |  |  | 462 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 20,823 |  |  | $ | 462 |  |  | $ | 1,843 |  |  | $ | 23,128 |  |

[0001375365-24-000011:notes:53]
(1) $0.1 million and $20.6 million in money market funds are included cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2023 and June 30, 2023, respectively.

[0001375365-24-000011:notes:54]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.1 million and $0.1 million in certificates of deposit are included in prepaid expenses and other assets, and $0.2 million and $0.2 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2023 and June 30, 2023, respectively.

[0001375365-24-000011:notes:55]
The carrying amounts reported in the condensed consolidated balance sheets for cash and cash equivalents, accounts receivable, other assets, accounts payable and accrued liabilities approximate their fair values. The investment in marketable equity security is carried at fair value using values available on a public exchange and is based on a Level 1 input. The unrealized gains and losses of the investment is included in earnings. The condensed consolidated statement of operations for the three and six months ended December 31, 2023, includes an unrealized gain of $0.3 million and a loss of $0.8 million, respectively, which have been recorded in Other income, net.

[0001375365-24-000011:notes:56]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three and six months ended December 31, 2023, the credit losses related to the Company’s investments were not material.

[0001375365-24-000011:notes:57]
There was immaterial movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and six months ended December 31, 2023 and 2022.

[0001375365-24-000011:notes:58]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and six months ended December 31, 2023 and 2022.

[0001375365-24-000011:notes:59]
The following is a summary of the Company’s investment in an auction rate security as of December 31, 2023 and June 30, 2023 (in thousands):

[0001375365-24-000011:notes:60]
[same as prior period, unchanged from 0001375365-23-000041:notes:55]

[0001375365-24-000011:notes:61]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and six months ended December 31, 2023 and 2022.

[0001375365-24-000011:notes:62]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of December 31, 2023 and June 30, 2023, total debt of $375.6 million and $290.3 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-24-000011:notes:63]
[same as prior period, unchanged from 0001375365-23-000041:notes:58]

[0001375365-24-000011:notes:64]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $0.1 million and $1.7 million as of December 31, 2023 and June 30, 2023, respectively. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three and six months ended December 31, 2023, the Company performed a qualitative assessment and identified impairment indicators. The Company recorded a $0.2 million and $1.8 million impairment during the three and six months ended December 31, 2023, respectively, in Other income, net on the condensed consolidated statement of operations. The Company did not have any impairment to the carrying values of the non-marketable equity securities during the three and six months ended December 31, 2022.


## us-gaap:DebtDisclosureTextBlock

[0001375365-24-000011:notes:65]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands):

[0001375365-24-000011:notes:66]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 20,000 |  |  | — |  |
| Cathay Bank Line of Credit | 131,583 |  |  | 131,583 |  |
| 2023 CTBC Credit Lines | 36,873 |  |  | — |  |
| HSBC Bank Credit Facility | 29,704 |  |  | — |  |
| Mega Bank Credit Facility | 15,526 |  |  | — |  |
| Total line of credit | 233,686 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 22,911 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,579 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,991 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 28,463 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,419 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 35,580 |  |  | 38,668 |  |
| Total term loans | 141,943 |  |  | 158,719 |  |
| Total debt | 375,629 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 276,307 |  |  | 170,123 |  |
| Debt, non-current | $ | 99,322 |  |  | $ | 120,179 |  |

[0001375365-24-000011:notes:67]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-24-000011:notes:68]
Available borrowings and interest rates as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

[0001375365-24-000011:notes:69]
|  | December 31, 2023 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | — |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 417 |  |  | 7.36% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2023 CTBC Credit Line | $ | 68,127 |  |  | 1.96% - 6.52% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.38% |  | $ | 20,000 |  |  | 6.58% |
| HSBC Bank Credit Facility | $ | 20,296 |  |  | 1.90% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 4,474 |  |  | 1.90% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.55% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.20% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.40% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.75% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.75% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.40% - 1.60% |  | $ | — |  |  | 1.40% - 1.60% |

[0001375365-24-000011:notes:70]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 7. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023 for a more complete description of the Company's credit facilities.

[0001375365-24-000011:notes:71]
The Company entered into new agreements during the six months ended December 31, 2023 with the following terms:

[0001375365-24-000011:notes:72]
CTBC Bank

[0001375365-24-000011:notes:73]
2023 CTBC Bank Credit Lines

[0001375365-24-000011:notes:74]
On September 28, 2023 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank, which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

[0001375365-24-000011:notes:75]
Interest rates under each of the individual New CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line are secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor for each of the individual New CTBC Credit Lines is one year. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of its Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the New CTBC Credit Lines. The New CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable upon the occurrence of an event of default.

[0001375365-24-000011:notes:76]
The Company's Taiwan subsidiary intends to use borrowings under the New CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices) and to finance additional improvements to the Company’s Bade Manufacturing Facility located in Taiwan.

[0001375365-24-000011:notes:77]
As of December 31, 2023, the outstanding borrowings under the 2023 CTBC Bank Credit Lines were $36.9 million. The interest rate for these loans were 1.96% - 6.52% per annum as of December 31, 2023.

[0001375365-24-000011:notes:78]
HSBC Bank

[0001375365-24-000011:notes:79]
2023 HSBC Bank Credit Lines

[0001375365-24-000011:notes:80]
On December 7, 2023, the Company's Taiwan subsidiary entered into a new Facility Letter with the Taiwan affiliate of HSBC Bank. The New Facility Letter is substantially identical to the prior Facility Letter entered into with HSBC Bank on February 7, 2023. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”, and together with the NTD Revolver, the "HSBC Bank Credit Lines"). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date.

[0001375365-24-000011:notes:81]
Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash coverage.

[0001375365-24-000011:notes:82]
As of December 31, 2023, the outstanding borrowings under HSBC Bank Credit Lines were $29.7 million. The interest rates for these loans were 1.90% - 6.37% per annum as of December 31, 2023.

[0001375365-24-000011:notes:83]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-24-000011:notes:84]
Fiscal Year                                                                                                                                                                                                Principal Payments

[0001375365-24-000011:notes:85]
| Remainder of 2024 |  | $ | 254,997 |  |
| 2025 |  | 42,621 |  |
| 2026 |  | 42,621 |  |
| 2027 |  | 18,517 |  |
| 2028 |  | 6,246 |  |
| 2029 and thereafter |  | 10,627 |  |
| Total short-term and long-term debt |  | $ | 375,629 |  |

[0001375365-24-000011:notes:86]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-24-000011:notes:87]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2023 and 2022 were as follows (in thousands):

[0001375365-24-000011:notes:88]
|  | Three Months EndedDecember 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease expense (including expense for lease agreements with related parties of $139 and $140 for the three months ended December 31, 2023 and 2022, respectively, and $277 and $284 for the six months ended December 31, 2023 and 2022, respectively) | $ | 2,354 |  |  | $ | 2,115 |  |  | $ | 4,539 |  |  | $ | 4,225 |  |
| Cash payments for operating leases (including payments to related parties of $129 and $127 for the three months ended December 31, 2023 and 2022, respectively, and $257 and $257 for the six months ended December 31, 2023 and 2022, respectively) | $ | 2,204 |  |  | $ | 2,025 |  |  | $ | 4,287 |  |  | $ | 4,063 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 572 |  |  | $ | 274 |  |  | $ | 9,749 |  |  | $ | 1,024 |  |

[0001375365-24-000011:notes:89]
During the three and six months ended December 31, 2023 and 2022, the Company’s costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three and six months ended December 31, 2023 were $0.5 million and $0.9 million, respectively. Non-lease variable payments expensed in the three and six months ended December 31, 2022 were $0.4 million and $0.9 million, respectively.

[0001375365-24-000011:notes:90]
As of December 31, 2023, the weighted average remaining lease term for operating leases was 3.1 years and the weighted average discount rate was 4.2%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of December 31, 2023 were as follows (in thousands):

[0001375365-24-000011:notes:91]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2024 |  | $ | 4,839 |  |
| 2025 |  | 9,436 |  |
| 2026 |  | 5,600 |  |
| 2027 |  | 3,885 |  |
| 2028 |  | 2,827 |  |
| 2029 and beyond |  | 429 |  |
| Total future lease payments |  | 27,016 |  |
| Less: Imputed interest |  | (1,991) |  |
| Present value of operating lease liabilities |  | $ | 25,025 |  |

[0001375365-24-000011:notes:92]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 8, “Related Party Transactions,” for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-24-000011:notes:93]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-24-000011:notes:94]
Dealings with Ablecom

[0001375365-24-000011:notes:95]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-24-000011:notes:96]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 87.2% and 95.5% of the chassis included in the products sold by the Company during the three months ended December 31, 2023 and 2022, respectively, and 86.3% and 91.8% of the chassis included in the products sold by the Company during the six months ended December 31, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-24-000011:notes:97]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-24-000011:notes:98]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on December 31, 2023 were $49.1 million and $37.5 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-24-000011:notes:99]
Dealings with Compuware

[0001375365-24-000011:notes:100]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company’s products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company’s standard price for its purchases.

[0001375365-24-000011:notes:101]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-24-000011:notes:102]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-24-000011:notes:103]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-24-000011:notes:104]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on December 31, 2023 were $121.6 million and $49.9 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-24-000011:notes:105]
Dealings with Investment in a Corporate Venture

[0001375365-24-000011:notes:106]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-24-000011:notes:107]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of December 31, 2023 and June 30, 2023.

[0001375365-24-000011:notes:108]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2023. No impairment charge was recorded for the three and six months ended December 31, 2023 or 2022.

[0001375365-24-000011:notes:109]
The Company sold products worth $11.4 million and $6.0 million to the Corporate Venture during the three months ended December 31, 2023 and 2022, respectively, and $12.2 million and $17.3 million to the Corporate Venture during the six months ended December 31, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $3.5 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of December 31, 2023 and June 30, 2023, respectively.

[0001375365-24-000011:notes:110]
The Company had the following balances related to transactions with its related parties as of December 31, 2023 and June 30, 2023 (in thousands):

[0001375365-24-000011:notes:111]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  |  |  | December 31, 2023 |  | June 30, 2023 |
| Accounts receivable | $ | 2 |  |  | $ | 2 |  |  | $ | 289 |  |  | $ | 3,528 |  |  | $ | 3,568 |  |  | $ | 1,943 |  |  |  |  | $ | 3,859 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,270 |  |  | $ | 2,841 |  |  | $ | 32,023 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 34,293 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 46,649 |  |  | $ | 35,711 |  |  | $ | 55,051 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 101,700 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 1,074 |  |  | $ | 1,230 |  |  | $ | 17,435 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,509 |  |  | $ | 14,017 |  |

[0001375365-24-000011:notes:112]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-24-000011:notes:113]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2023 and 2022, are as follows (in thousands):

[0001375365-24-000011:notes:114]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 4 |  |  | $ | 2 |  |  | $ | 4,392 |  |  | $ | 14,113 |  |  | $ | 11,385 |  |  | $ | 5,958 |  |  |  |  | $ | 15,781 |  |  | $ | 20,073 |  |
| Purchases - inventory | $ | 50,586 |  |  | $ | 46,715 |  |  | $ | 61,859 |  |  | $ | 52,028 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 112,445 |  |  | $ | 98,743 |  |
| Purchases - other miscellaneous items | $ | 3,456 |  |  | $ | 2,763 |  |  | $ | 332 |  |  | $ | 279 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 3,788 |  |  | $ | 3,042 |  |

[0001375365-24-000011:notes:115]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

[0001375365-24-000011:notes:116]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 6 |  |  | $ | 3 |  |  | $ | 20,998 |  |  | $ | 27,872 |  |  | $ | 12,173 |  |  | $ | 17,251 |  |  |  |  | $ | 33,177 |  |  | $ | 45,126 |  |
| Purchases - inventory | $ | 97,199 |  |  | $ | 94,562 |  |  | $ | 128,353 |  |  | $ | 100,717 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 225,552 |  |  | $ | 195,279 |  |
| Purchases - other miscellaneous items | $ | 8,215 |  |  | $ | 7,526 |  |  | $ | 749 |  |  | $ | 537 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 8,964 |  |  | $ | 8,063 |  |

[0001375365-24-000011:notes:117]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

[0001375365-24-000011:notes:118]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Changes in accounts receivable | $ | — |  |  | $ | — |  |  | $ | 3,239 |  |  | $ | 137 |  |  | $ | (1,625) |  |  | $ | 3,041 |  |  |  |  | $ | 1,614 |  |  | $ | 3,178 |  |
| Changes in other receivable | $ | 571 |  |  | $ | 1,364 |  |  | $ | (7,132) |  |  | $ | (24,289) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (6,561) |  |  | $ | (22,925) |  |
| Changes in accounts payable | $ | 10,938 |  |  | $ | (3,589) |  |  | $ | 1,628 |  |  | $ | 4,340 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 12,566 |  |  | $ | 751 |  |
| Changes in accrued liabilities | $ | (156) |  |  | $ | (2,009) |  |  | $ | 4,648 |  |  | $ | 2,860 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,492 |  |  | $ | 851 |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | (168) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (152) |  |  | $ | (168) |  |
| Purchases of property, plant and equipment | $ | 4,460 |  |  | $ | 4,366 |  |  | $ | 68 |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,528 |  |  | $ | 4,514 |  |
| Unpaid property, plant and equipment | $ | 2,570 |  |  | $ | 1,764 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 2,577 |  |  | $ | 1,764 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-24-000011:notes:119]
[same as prior period, unchanged from 0001375365-23-000041:notes:106]

[0001375365-24-000011:notes:120]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remained reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-24-000011:notes:121]
On January 22, 2024, the stockholders of the Company approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 1,500,000 shares.

[0001375365-24-000011:notes:122]
[same as prior period, unchanged from 0001375365-23-000041:notes:108]

[0001375365-24-000011:notes:123]
As of December 31, 2023, the Company had 483,780 authorized shares available for future issuance under the 2020 Plan.

[0001375365-24-000011:notes:124]
Offering of Common Stock

[0001375365-24-000011:notes:125]
On December 5, 2023, the Company completed a public offering of 2,415,805 shares of the Company's common stock at $262.00 per share, with 2,315,105 shares sold by the Company and 100,700 shares sold by selling stockholders.

[0001375365-24-000011:notes:126]
The Company received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Company did not receive any proceeds from the sale of the shares of common stock by the selling stockholders.

[0001375365-24-000011:notes:127]
[same as prior period, unchanged from 0001375365-23-000041:notes:110]

[0001375365-24-000011:notes:128]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company’s Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. Under the common stock repurchase program, shares may be purchased from time to time in open market transactions, block trades, through plans established under the Securities Exchange Act Rule 10b5-1, or otherwise. The number of shares purchased and the timing of such purchases are based on working capital requirements, market and general business conditions, and other factors, including alternative investment opportunities.

[0001375365-24-000011:notes:129]
No shares were repurchased under the share repurchase program during the three and six months ended December 31, 2023. As of December 31, 2023, $50.0 million was available for additional repurchases of common stock. The share repurchase program was effective until January 31, 2024, at which time the remaining unutilized portion of such program expired.

[0001375365-24-000011:notes:130]
[same as prior period, unchanged from 0001375365-23-000041:notes:113]

[0001375365-24-000011:notes:131]
The Company’s fair value of RSUs is based on the closing market price of the Company’s common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-24-000011:notes:132]
[same as prior period, unchanged from 0001375365-23-000041:notes:115]

[0001375365-24-000011:notes:133]
[same as prior period, unchanged from 0001375365-23-000041:notes:116]

[0001375365-24-000011:notes:134]
[same as prior period, unchanged from 0001375365-23-000041:notes:117]

[0001375365-24-000011:notes:135]
[same as prior period, unchanged from 0001375365-23-000041:notes:118]

[0001375365-24-000011:notes:136]
The fair value of stock option grants for the three and six months ended December 31, 2023 and 2022 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-24-000011:notes:137]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Risk-free interest rate | 4.78% |  | 4.16% - 4.25% |  | 4.15% - 4.78% |  | 2.81% - 4.25% |
| Expected term | 5.99 years |  | 6.07 years |  | 3.00 years - 5.99 years |  | 6.07 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 58.89% |  | 51.64% - 51.68% |  | 56.87% - 58.89% |  | 50.62% - 51.68% |
| Weighted-average fair value | $156.09 |  | $36.37 |  | $179.16 |  | $34.60 |

[0001375365-24-000011:notes:138]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2023 and 2022 (in thousands):

[0001375365-24-000011:notes:139]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of sales | $ | 3,555 |  |  | $ | 1,486 |  |  | $ | 9,459 |  |  | $ | 2,370 |  |
| Research and development | 25,439 |  |  | 9,334 |  |  | 61,149 |  |  | 15,452 |  |
| Sales and marketing | 4,340 |  |  | 1,448 |  |  | 10,005 |  |  | 2,257 |  |
| General and administrative | 9,727 |  |  | 4,713 |  |  | 19,827 |  |  | 7,916 |  |
| Stock-based compensation expense before taxes | 43,061 |  |  | 16,981 |  |  | 100,440 |  |  | 27,995 |  |
| Income tax impact | (9,569) |  |  | (3,381) |  |  | (25,434) |  |  | (4,720) |  |
| Stock-based compensation expense, net | $ | 33,492 |  |  | $ | 13,600 |  |  | $ | 75,006 |  |  | $ | 23,275 |  |

[0001375365-24-000011:notes:140]
As of December 31, 2023, $73.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.26 years and $237.0 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.65 years. As described below, there is no unrecognized compensation cost related to the 2021 CEO Performance Stock Option as of December 31, 2023. Additionally, $27.4 million of unrecognized compensation cost related to the 2023 CEO Performance Stock Option is expected to be recognized over a period of 1.75 years.

[0001375365-24-000011:notes:141]
[same as prior period, unchanged from 0001375365-23-000041:notes:124]

[0001375365-24-000011:notes:142]
2021 CEO Performance Award

[0001375365-24-000011:notes:143]
[same as prior period, unchanged from 0001375365-23-000041:notes:125]

[0001375365-24-000011:notes:144]
The achievement status of the operational and stock price milestones as of December 31, 2023 was as follows:

[0001375365-24-000011:notes:145]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Achieved |  | $75 |  | Achieved (3) |  |  |
| $6.8 |  | Achieved |  | $95 |  | Achieved (4) |  |  |
| $8.0 |  | Achieved (5) |  | $120 |  | Achieved (6) |  |  |

[0001375365-24-000011:notes:146]
[same as prior period, unchanged from 0001375365-23-000041:notes:128]

[0001375365-24-000011:notes:147]
[same as prior period, unchanged from 0001375365-23-000041:notes:129]

[0001375365-24-000011:notes:148]
[same as prior period, unchanged from 0001375365-23-000041:notes:130]

[0001375365-24-000011:notes:149]
[same as prior period, unchanged from 0001375365-23-000041:notes:131]

[0001375365-24-000011:notes:150]
(5)Revenue reported for the four quarters ended December 31, 2023 was $9.3 billion. Achievement of the $8.0 billion revenue goal has not yet been certified by the Company’s Compensation Committee.

[0001375365-24-000011:notes:151]
(6)On June 19, 2023, the Compensation Committee certified achievement of the $120 stock price milestone based upon the 60 trading day average stock price from March 6, 2023 through May 30, 2023.

[0001375365-24-000011:notes:152]
During the three and six months ended December 31, 2023, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.5 million and $0.7 million, respectively. During the three and six months ended December 31, 2022, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $1.9 million and $3.2 million, respectively. As of December 31, 2023 and June 30, 2023, the Company had $0.0 million and $0.7 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-24-000011:notes:153]
2023 CEO Performance Award

[0001375365-24-000011:notes:154]
In November 2023, the Compensation Committee approved the grant of a stock option award for 500,000 shares of common stock to the Company’s CEO (the “2023 CEO Performance Stock Option”). The 2023 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2023 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $450.00 per share for the first tranche and increases up to $1,100.00 per share thereafter (based on a 60 trading day average stock price), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $450.00 per share, prior to November 14, 2026, the Company’s CEO must hold shares that he acquires until November 14, 2026, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-24-000011:notes:155]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |
| $13.0 |  | Probable |  | $450 |  | Not met |
| $15.0 |  | Not Probable |  | $600 |  | Not met |
| $17.0 |  | Not Probable |  | $750 |  | Not met |
| $19.0 |  | Not Probable |  | $900 |  | Not met |
| $21.0 |  | Not Probable |  | $1,100 |  | Not met |

[0001375365-24-000011:notes:156]
During the three and six months ended December 31, 2023, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $2.5 million. As of December 31, 2023 , the Company had $27.4 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of December 31, 2023 is expected to be recognized over a period of 1.75 years.

[0001375365-24-000011:notes:157]
On the respective grant dates of each of the 2021 CEO Performance Award and the 2023 CEO Performance Award, a Monte Carlo simulation was used to determine for each tranche of each award (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the respective grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-24-000011:notes:158]
The following table summarizes stock option activity during the six months ended December 31, 2023 under all plans:

[0001375365-24-000011:notes:159]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2023 |  | 3,302,533 |  |  | $ | 40.47 |  |  |  |  |  |
| Granted |  | 844,242 |  |  | $ | 393.40 |  |  |  |  |  |
| Exercised |  | (341,409) |  |  | $ | 28.68 |  |  |  |  |  |
| Forfeited/Cancelled |  | (7,127) |  |  | $ | 60.76 |  |  |  |  |  |
| Balance as of December 31, 2023 |  | 3,798,239 |  |  | $ | 119.94 |  |  | 7.00 |  |  |
| Options vested and exercisable at December 31, 2023 |  | 2,044,524 |  |  | $ | 36.57 |  |  | 5.36 |  |  |

[0001375365-24-000011:notes:160]
RSU Activity

[0001375365-24-000011:notes:161]
The following table summarizes RSU activity during the six months ended December 31, 2023 under all plans:

[0001375365-24-000011:notes:162]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2023 | 2,042,986 |  |  | $ | 55.94 |  |  |  |  |  |  |
| Granted | 724,048 |  |  | $ | 309.00 |  |  |  |  |  |  |
| Released | (511,022) |  |  | $ | 96.34 |  |  |  |  |  |  |
| Forfeited | (45,329) |  |  | $ | 91.53 |  |  |  |  |  |  |
| Balance as of December 31, 2023 | 2,210,683 |  |  | $ | 128.75 |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-24-000011:notes:163]
Income Taxes
The Company recorded a provision for income taxes of $61.5 million and $81.7 million for the three and six months ended December 31, 2023, respectively, and $29.6 million and $68.5 million for the three and six months ended December 31, 2022, respectively. The effective tax rate was 17.3% and 15.3% for the three and six months ended December 31, 2023, respectively, and 14.3% and 15.9% for the three and six months ended December 31, 2022, respectively. The effective tax rate for the three months ended December 31, 2023 is higher than that for the three months ended December 31, 2022, primarily due to a 2% increase caused by a reduction of foreign derived intangible income which is subject to lower income tax rate than a statutory tax rate of 21%. In addition, there was a 1% increase caused by more non tax deductible stock-based compensation for officers over one million dollars threshold. The effective tax rate for the six months ended December 31, 2023 is lower than that for the six months ended December 31, 2022, primarily due to an increase in the tax deduction for stock-based compensation in the six months ended December 31, 2023.

[0001375365-24-000011:notes:164]
[same as prior period, unchanged from 0001375365-23-000041:notes:141]

[0001375365-24-000011:notes:165]
[same as prior period, unchanged from 0001375365-23-000041:notes:142]

[0001375365-24-000011:notes:166]
[same as prior period, unchanged from 0001375365-23-000041:notes:143]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-24-000011:notes:167]
Commitments and Contingencies
Legal proceedings and indemnifications

[0001375365-24-000011:notes:168]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2023 and any prior periods.

[0001375365-24-000011:notes:169]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-24-000011:notes:170]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-24-000011:notes:171]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2023, these remaining noncancelable commitments were $1.9 billion, including $87.4 million for related parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-24-000011:notes:172]
Segment Reporting
The Company operates in one operating segment that develops and provides high-performance server and storage solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-24-000011:notes:173]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-24-000011:notes:174]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Long-lived assets: |  |  |  |
| United States | $ | 183,896 |  |  | $ | 183,485 |  |
| Asia | 110,676 |  |  | 104,094 |  |
| Europe | 2,530 |  |  | 2,661 |  |
|  | $ | 297,102 |  |  | $ | 290,240 |  |

[0001375365-24-000011:notes:175]
[same as prior period, unchanged from 0001375365-23-000041:notes:151]


## us-gaap:SubsequentEventsTextBlock

[0001375365-24-000011:notes:176]
Subsequent Events
On January 26, 2024, the Company entered into an agreement to purchase real estate for an aggregate price of $80.0 million, subject to certain adjustments to be determined at closing. The transaction is expected to close during the third quarter of fiscal 2024. The Company plans to acquire this property using its own cash.

[0001375365-24-000011:notes:177]
On January 31, 2024, the Company entered into a lease for approximately 260,000 square feet of space in San Jose, California for a term of 79 months. The Company currently intends to use such premises for additional warehouse space. The lease also provides that the Company is required to rent an additional approximate 198,000 square feet of space in the same building after such space becomes available for the remainder of the term stated above. Aggregate payment under the lease for both the primary space and additional space is approximately $0.6 million per month, subject to annual increase.
