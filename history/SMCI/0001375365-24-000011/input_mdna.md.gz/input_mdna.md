# SMCI MD&A — 0001375365-24-000011


## mdna

[0001375365-24-000011:mdna:1]
[same as prior period, unchanged from 0001375365-23-000041:mdna:1]

[0001375365-24-000011:mdna:2]
[same as prior period, unchanged from 0001375365-23-000041:mdna:2]

[0001375365-24-000011:mdna:3]
[same as prior period, unchanged from 0001375365-23-000041:mdna:3]

[0001375365-24-000011:mdna:4]
[same as prior period, unchanged from 0001375365-23-000041:mdna:4]

[0001375365-24-000011:mdna:5]
[same as prior period, unchanged from 0001375365-23-000041:mdna:5]

[0001375365-24-000011:mdna:6]
[same as prior period, unchanged from 0001375365-23-000041:mdna:6]

[0001375365-24-000011:mdna:7]
The following is a summary of our financial highlights of the second quarter of fiscal year 2024:

[0001375365-24-000011:mdna:8]
•Net sales increased by 103.2% in the three months ended December 31, 2023 as compared to the three months ended December 31, 2022.

[0001375365-24-000011:mdna:9]
•Gross margin decreased to 15.4% in the three months ended December 31, 2023 from 18.7% in the three months ended December 31, 2022.

[0001375365-24-000011:mdna:10]
•Operating expenses increased by 57.8% as compared to the three months ended December 31, 2022 and were equal to 5.3% and 6.7% of net sales in the three months ended December 31, 2023 and 2022, respectively.

[0001375365-24-000011:mdna:11]
•Effective tax rate increased to 17.3% in the three months ended December 31, 2023 from 14.3% in the three months ended December 31, 2022.

[0001375365-24-000011:mdna:12]
SMCI | Q2 2024 Form 10-Q | 32

[0001375365-24-000011:mdna:13]
[same as prior period, unchanged from 0001375365-23-000041:mdna:13]

[0001375365-24-000011:mdna:14]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses.  We evaluate our estimates on an on-going basis based on a) historical experience and b) assumptions we believe to be reasonable under the circumstances and are not readily apparent from other sources, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Because these estimates can vary depending on the situation, actual results may differ from these estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-24-000011:mdna:15]
[same as prior period, unchanged from 0001375365-23-000041:mdna:15]

[0001375365-24-000011:mdna:16]
[same as prior period, unchanged from 0001375365-23-000041:mdna:16]

[0001375365-24-000011:mdna:17]
[same as prior period, unchanged from 0001375365-23-000041:mdna:17]

[0001375365-24-000011:mdna:18]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.6 | % |  | 81.3 | % |  | 84.1 | % |  | 81.3 | % |
| Gross profit | 15.4 | % |  | 18.7 | % |  | 15.9 | % |  | 18.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 3.0 | % |  | 3.9 | % |  | 3.8 | % |  | 4.0 | % |
| Sales and marketing | 1.3 | % |  | 1.6 | % |  | 1.5 | % |  | 1.6 | % |
| General and administrative | 1.0 | % |  | 1.2 | % |  | 1.2 | % |  | 1.2 | % |
| Total operating expenses | 5.3 | % |  | 6.7 | % |  | 6.5 | % |  | 6.8 | % |
| Income from operations | 10.1 | % |  | 12.0 | % |  | 9.4 | % |  | 11.9 | % |
| Other (expense) income, net | (0.2) | % |  | (0.4) | % |  | 0.0 | % |  | 0.1 | % |
| Interest expense | (0.2) | % |  | (0.1) | % |  | (0.2) | % |  | (0.2) | % |
| Income before income tax provision | 9.7 | % |  | 11.5 | % |  | 9.2 | % |  | 11.8 | % |
| Income tax provision | (1.7) | % |  | (1.6) | % |  | (1.4) | % |  | (1.9) | % |
| Share of income (loss) from equity investee, net of taxes | 0.1 | % |  | (0.1) | % |  | 0.0 | % |  | (0.1) | % |
| Net income | 8.1 | % |  | 9.8 | % |  | 7.8 | % |  | 9.8 | % |

[0001375365-24-000011:mdna:19]
[same as prior period, unchanged from 0001375365-23-000041:mdna:19]

[0001375365-24-000011:mdna:20]
[same as prior period, unchanged from 0001375365-23-000041:mdna:20]

[0001375365-24-000011:mdna:21]
[same as prior period, unchanged from 0001375365-23-000041:mdna:21]

[0001375365-24-000011:mdna:22]
SMCI | Q2 2024 Form 10-Q | 33

[0001375365-24-000011:mdna:23]
The following table presents net sales by product type for the three and six months ended December 31, 2023 and 2022 (dollars in millions):

[0001375365-24-000011:mdna:24]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Server and storage systems | $ | 3,435.6 |  |  | $ | 1,660.9 |  |  | $ | 1,774.7 |  |  | 106.9 | % |  | $ | 5,402.2 |  |  | $ | 3,374.0 |  |  | $ | 2,028.2 |  |  | 60.1 | % |
| Percentage of total net sales | 93.7 | % |  | 92.1 | % |  |  |  |  |  | 93.4 | % |  | 92.3 | % |  |  |  |  |
| Subsystems and accessories | $ | 229.3 |  |  | $ | 142.3 |  |  | $ | 87.0 |  |  | 61.1 | % |  | $ | 382.4 |  |  | $ | 281.3 |  |  | $ | 101.1 |  |  | 35.9 | % |
| Percentage of total net sales | 6.3 | % |  | 7.9 | % |  |  |  |  |  | 6.6 | % |  | 7.7 | % |  |  |  |  |
| Total net sales | $ | 3,664.9 |  |  | $ | 1,803.2 |  |  | $ | 1,861.7 |  |  | 103.2 | % |  | $ | 5,784.6 |  |  | $ | 3,655.3 |  |  | $ | 2,129.3 |  |  | 58.3 | % |

[0001375365-24-000011:mdna:25]
[same as prior period, unchanged from 0001375365-23-000041:mdna:25]

[0001375365-24-000011:mdna:26]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:27]
[same as prior period, unchanged from 0001375365-23-000041:mdna:26]

[0001375365-24-000011:mdna:28]
The period-over-period increase in net sales for our subsystems and accessories is primarily due to increased demand of accessories sold to data center customers as more accessories and spares were purchased in conjunction with the strong sales of full systems and servers.

[0001375365-24-000011:mdna:29]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:30]
The period-over-period increase in net sales of our server and storage systems was primarily due to the strong demand from customers for GPU, high performance computing (“HPC"), and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling price ("ASP").

[0001375365-24-000011:mdna:31]
The period-over-period increase in net sales for our subsystems and accessories is primarily due to increased demand of accessories sold to data center customers as more accessories and spares were purchased in conjunction with the strong sales of full systems and servers.

[0001375365-24-000011:mdna:32]
The following table presents net sales by geographic region for the three and six months ended December 31, 2023 and 2022 (dollars in millions):

[0001375365-24-000011:mdna:33]
|  | Three Months Ended December 31, |  | Change |  | Change |  | Six Months Ended December 31, |  | Change |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| United States | $ | 2,605.6 |  |  | $ | 1,091.4 |  |  | $ | 1,514.2 |  |  | 138.7 | % |  | $ | 4,225.1 |  |  | $ | 2,386.9 |  |  | $ | 1,838.2 |  |  | 77.0 | % |
| Percentage of total net sales | 71.1 | % |  | 60.5 | % |  |  |  |  |  | 73.0 | % |  | 65.3 | % |  |  |  |  |
| Asia | $ | 656.2 |  |  | $ | 330.7 |  |  | $ | 325.5 |  |  | 98.4 | % |  | $ | 881.7 |  |  | $ | 600.7 |  |  | $ | 281.0 |  |  | 46.8 | % |
| Percentage of total net sales | 17.9 | % |  | 18.4 | % |  |  |  |  |  | 15.2 | % |  | 16.4 | % |  |  |  |  |
| Europe | $ | 288.4 |  |  | $ | 312.5 |  |  | $ | (24.1) |  |  | (7.7) | % |  | $ | 479.3 |  |  | $ | 547.6 |  |  | $ | (68.3) |  |  | (12.5) | % |
| Percentage of total net sales | 7.9 | % |  | 17.3 | % |  |  |  |  |  | 8.3 | % |  | 15.0 | % |  |  |  |  |
| Others | $ | 114.7 |  |  | $ | 68.6 |  |  | $ | 46.1 |  |  | 67.2 | % |  | $ | 198.5 |  |  | $ | 120.1 |  |  | $ | 78.4 |  |  | 65.3 | % |
| Percentage of total net sales | 3.1 | % |  | 3.8 | % |  |  |  |  |  | 3.5 | % |  | 3.3 | % |  |  |  |  |
| Total net sales | $ | 3,664.9 |  |  | $ | 1,803.2 |  |  |  |  |  |  | $ | 5,784.6 |  |  | $ | 3,655.3 |  |  |  |  |  |

[0001375365-24-000011:mdna:34]
SMCI | Q2 2024 Form 10-Q | 34

[0001375365-24-000011:mdna:35]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:36]
The period-over-period increase in overall net sales is the result of higher ASPs, especially for large enterprise and data center customers. United States sales experienced significant growth due to increased demand from data center customers for GPU, HPC, and rack-scale solutions. The period-over-period increase of net sales in Asia and other regions is mainly due to an increase in net sales in Taiwan, Singapore, Canada and South Africa. The period-over-period decrease in sales in Europe is mainly due to decreases in net sales in Germany, United Kingdom, and France.

[0001375365-24-000011:mdna:37]
Two customers accounted for 25.5% and 10.4% of the net sales for the three months ended December 31, 2023. We had no customers with net sales over 10% for the three months ended December 31, 2022, however, we expect to continue to have customers exceeding 10% of net sales in future quarters.

[0001375365-24-000011:mdna:38]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:39]
The period-over-period increase in overall net sales is the result of higher ASPs, especially for large enterprise and data center customers. United States sales experienced significant growth due to increased demand from data center customers for GPU, HPC, and rack-scale solutions. The period-over-period increase of net sales in Asia and other regions is mainly due to an increase in net sales in Taiwan, Canada and South Africa. The period-over-period decrease in sales in Europe is mainly due to decreases in net sales in Germany, United Kingdom, and France.

[0001375365-24-000011:mdna:40]
One customer accounted for 25.3% of the net sales for the six months ended December 31, 2023. The same customer accounted for 15.8% of net sales for the six months ended December 31, 2022. We expect to continue to have customers exceeding 10% of net sales in future quarters.

[0001375365-24-000011:mdna:41]
[same as prior period, unchanged from 0001375365-23-000041:mdna:33]

[0001375365-24-000011:mdna:42]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges. The primary factors that impact our cost of sales are the mix of products sold, changes in the cost of components, changes in logistic costs, changes in salary and benefits and overhead costs related to production as well as economies of scale gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in our costs are not matched by corresponding changes in our ASPs. Our cost of sales as a percentage of net sales is also impacted by the timing and extent to which we add to, and are able to efficiently utilize, our manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions. Certain materials used in the manufacturing of our products are available from a limited number of suppliers and we expect that this trend will continue in the future.

[0001375365-24-000011:mdna:43]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing generally performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of certain components, particularly power supplies.

[0001375365-24-000011:mdna:44]
Cost of sales and gross margin for the three and six months ended December 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-24-000011:mdna:45]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Cost of sales | $ | 3,100.6 |  |  | $ | 1,465.8 |  |  | $ | 1,634.8 |  |  | 111.5 | % |  | $ | 4,866.6 |  |  | $ | 2,970.4 |  |  | $ | 1,896.2 |  |  | 63.8 | % |
| Gross profit | $ | 564.3 |  |  | $ | 337.4 |  |  | $ | 226.9 |  |  | 67.2 | % |  | $ | 918.0 |  |  | $ | 685.0 |  |  | $ | 233.0 |  |  | 34.0 | % |
| Gross margin | 15.4 | % |  | 18.7 | % |  |  |  | (3.3) | % |  | 15.9 | % |  | 18.7 | % |  |  |  | (2.8) | % |

[0001375365-24-000011:mdna:46]
SMCI | Q2 2024 Form 10-Q | 35

[0001375365-24-000011:mdna:47]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:48]
The period-over-period increase in cost of sales was primarily attributed to an increase in sales volume, which resulted in an increase of $1,639.1 million in costs of materials and contract manufacturing expenses, and a $3.1 million increase in overhead costs, partially offset by a $7.4 million decrease in inventory reserve charges.

[0001375365-24-000011:mdna:49]
The period-over-period decrease in the gross margin percentage was primarily due to product and customer mix, partially offset by lower cost of goods sold from manufacturing efficiency and other factors.

[0001375365-24-000011:mdna:50]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:51]
The period-over-period increase in cost of sales was primarily attributed to an increase in sales volume, which resulted in an increase of $1,918.6 million in costs of materials and contract manufacturing expenses, and a $0.9 million increase in overhead costs, partially offset by a $12.7 million decrease in inventory reserve charges and a $10.6 million decrease in freight costs due to an improved supply chain.

[0001375365-24-000011:mdna:52]
The period-over-period decrease in the gross margin percentage was primarily due to product and customer mix, partially offset by lower cost of goods sold from manufacturing efficiency and other factors.

[0001375365-24-000011:mdna:53]
[same as prior period, unchanged from 0001375365-23-000041:mdna:41]

[0001375365-24-000011:mdna:54]
[same as prior period, unchanged from 0001375365-23-000041:mdna:42]

[0001375365-24-000011:mdna:55]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses for our sales and marketing personnel, cost for trade shows, independent sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These reimbursed costs offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-24-000011:mdna:56]
[same as prior period, unchanged from 0001375365-23-000041:mdna:46]

[0001375365-24-000011:mdna:57]
SMCI | Q2 2024 Form 10-Q | 36

[0001375365-24-000011:mdna:58]
Operating expenses for the three and six months ended December 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-24-000011:mdna:59]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Research and development | $ | 108.8 |  |  | $ | 70.7 |  |  | $ | 38.1 |  |  | 53.9 | % |  | $ | 219.8 |  |  | $ | 145.0 |  |  | $ | 74.8 |  |  | 51.6 | % |
| Percentage of total net sales | 3.0 | % |  | 3.9 | % |  |  |  |  |  | 3.8 | % |  | 4.0 | % |  |  |  |  |
| Sales and marketing | $ | 46.9 |  |  | $ | 28.4 |  |  | $ | 18.5 |  |  | 65.1 | % |  | $ | 84.1 |  |  | $ | 57.8 |  |  | $ | 26.3 |  |  | 45.5 | % |
| Percentage of total net sales | 1.3 | % |  | 1.6 | % |  |  |  |  |  | 1.5 | % |  | 1.6 | % |  |  |  |  |
| General and administrative | $ | 37.2 |  |  | $ | 23.1 |  |  | $ | 14.1 |  |  | 61.0 | % |  | $ | 70.1 |  |  | $ | 46.9 |  |  | $ | 23.2 |  |  | 49.5 | % |
| Percentage of total net sales | 1.0 | % |  | 1.2 | % |  |  |  |  |  | 1.2 | % |  | 1.2 | % |  |  |  |  |
| Total operating expenses | $ | 192.9 |  |  | $ | 122.2 |  |  | $ | 70.7 |  |  | 57.9 | % |  | $ | 374.0 |  |  | $ | 249.7 |  |  | $ | 124.3 |  |  | 49.8 | % |
| Percentage of total net sales | 5.3 | % |  | 6.7 | % |  |  |  |  |  | 6.5 | % |  | 6.8 | % |  |  |  |  |

[0001375365-24-000011:mdna:60]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:61]
Research and development expenses. The period-over-period increase in research and development expenses was primarily driven by a $33.5 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards as we expanded our workforce and invested in key talent, a $1.0 million increase in product development costs to support the development of next generation products and technologies and a $3.6 million decrease in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-24-000011:mdna:62]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily driven by a $14.9 million increase in compensation expenses due to salary increases, higher headcount and cost of equity awards, a $5.5 million increase in advertising and other expenses and a $1.9 million decrease in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000011:mdna:63]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to a $7.8 million increase in compensation expenses associated with higher headcount and the cost of equity awards and a $6.3 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000011:mdna:64]
SMCI | Q2 2024 Form 10-Q | 37

[0001375365-24-000011:mdna:65]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:66]
Research and development expenses. The period-over-period increase in research and development expenses was primarily driven by a $72.4 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards as we expanded our workforce and invested in key talent, a $1.9 million increase in product development costs to support the development of next generation products and technologies and a $0.5 million decrease in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-24-000011:mdna:67]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily driven by a $24.0 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards, a $3.5 million increase in advertising and other expenses and a $1.2 million decrease in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000011:mdna:68]
General and administrative expenses. The period-over-period increase in general and administrative expenses was primarily due to a $16.4 million increase in compensation expenses associated with higher headcount and the cost of equity awards and a $3.8 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000011:mdna:69]
Interest Expense and Other Expense, Net

[0001375365-24-000011:mdna:70]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-24-000011:mdna:71]
[same as prior period, unchanged from 0001375365-23-000041:mdna:54]

[0001375365-24-000011:mdna:72]
Interest expense and other income (expense), net for the three and six months ended December 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-24-000011:mdna:73]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Other (expense) income, net | $ | (7.9) |  |  | $ | (6.3) |  |  | $ | (1.6) |  |  | 25.4 | % |  | $ | (1.3) |  |  | $ | 1.7 |  |  | $ | (3.0) |  |  | (176.5) | % |
| Interest expense | (8.1) |  |  | (1.8) |  |  | (6.3) |  |  | 350.0 | % |  | (10.0) |  |  | (5.7) |  |  | (4.3) |  |  | 75.4 | % |
| Interest expense and other expense, net | $ | (16.0) |  |  | $ | (8.1) |  |  | $ | (7.9) |  |  | 97.5 | % |  | $ | (11.3) |  |  | $ | (4.0) |  |  | $ | (7.3) |  |  | 182.5 | % |

[0001375365-24-000011:mdna:74]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:75]
The increase of $7.9 million in interest expense and other expense, net was primarily attributable to an increase in interest expense of $6.3 million due to an increase in outstanding loan balances and a $1.6 million increase in other expense driven by increase in foreign exchange losses of $3.0 million due to weakening of US dollars offset by a $1.4 million increase in interest and other income.

[0001375365-24-000011:mdna:76]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:77]
The increase of $7.3 million in interest expense and other expense, net was primarily attributable to an increase in interest expense of $4.3 million due to an increase in outstanding loan balances and a $3.0 million increase in other expense driven by investment impairment and increase in foreign exchange losses of $6.0 million due to weakening of US dollars offset by an increase of $3.0 million in interest and other income.

[0001375365-24-000011:mdna:78]
SMCI | Q2 2024 Form 10-Q | 38

[0001375365-24-000011:mdna:79]
[same as prior period, unchanged from 0001375365-23-000041:mdna:59]

[0001375365-24-000011:mdna:80]
[same as prior period, unchanged from 0001375365-23-000041:mdna:60]

[0001375365-24-000011:mdna:81]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-24-000011:mdna:82]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Income tax provision | $ | 61.5 |  |  | $ | 29.6 |  |  | $ | 31.9 |  |  | 107.8 | % |  | $ | 81.7 |  |  | $ | 68.5 |  |  | $ | 13.2 |  |  | 19.3 | % |
| Percentage of total net sales | 1.7 | % |  | 1.6 | % |  |  |  |  |  | 1.4 | % |  | 1.9 | % |  |  |  |  |
| Effective tax rate | 17.3 | % |  | 14.3 | % |  |  |  |  |  | 15.3 | % |  | 15.9 | % |  |  |  |  |

[0001375365-24-000011:mdna:83]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:84]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The income tax provision and effective tax rate for the three months ended December 31, 2023 is higher than that for the three months ended December 31, 2022, primarily due to a 2% increase caused by a reduction of foreign derived intangible income which is subject to lower income tax rate than a statutory tax rate of 21%. In addition, there was a 1% increase caused by more non tax deductible stock-based compensation for officers over one million dollars threshold.

[0001375365-24-000011:mdna:85]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:86]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The income tax provision for the six months ended December 31, 2023 is higher than that for the six months ended December 31, 2022, primarily due to a significant increase in annual forecasted taxable income. The effective tax rate for the six months ended December 31, 2023 is lower than that for the six months ended December 31, 2022, primarily due to an increase in the tax deduction for stock compensation.

[0001375365-24-000011:mdna:87]
Share of Income (Loss) from Equity Investee, Net of Taxes

[0001375365-24-000011:mdna:88]
Share of income (loss) from equity investee, net of taxes represents our share of income (loss) from the Corporate Venture in which we have 30% ownership.

[0001375365-24-000011:mdna:89]
Share of income (loss) from equity investee, net of taxes for the three and six months ended December 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-24-000011:mdna:90]
|  | Three Months EndedDecember 31, |  | Change | Six Months EndedDecember 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 2.0 |  |  | $ | (1.4) |  |  | $ | 3.4 |  |  | n/m (1) |  | $ | 2.0 |  |  | $ | (2.2) |  |  | $ | 4.2 |  |  | n/m (1) |
| Percentage of total net sales | 0.1 | % |  | (0.1) | % |  |  |  |  |  | — | % |  | (0.1) | % |  |  |  |  |

[0001375365-24-000011:mdna:91]
[same as prior period, unchanged from 0001375365-23-000041:mdna:68]

[0001375365-24-000011:mdna:92]
SMCI | Q2 2024 Form 10-Q | 39

[0001375365-24-000011:mdna:93]
Comparison of Three Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:94]
The period-over-period increase of $3.4 million in share of income from equity investee, net of taxes was primarily due to a net income recognized by the Corporate Venture.

[0001375365-24-000011:mdna:95]
Comparison of Six Months Ended December 31, 2023 and 2022

[0001375365-24-000011:mdna:96]
The period-over-period increase of $4.2 million in share of income from equity investee, net of taxes was primarily due to a net income recognized by the Corporate Venture.

[0001375365-24-000011:mdna:97]
[same as prior period, unchanged from 0001375365-23-000041:mdna:71]

[0001375365-24-000011:mdna:98]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities and selling our common stock. Our recent drivers of liquidity changes have included an increase in the need for working capital due to higher levels of inventory required by growing revenues and to a lesser extent, longer supply chain lead times on certain key components. Our cash and cash equivalents were $725.7 million and $440.5 million as of December 31, 2023 and June 30, 2023, respectively. Our cash and cash equivalents in foreign locations were $193.8 million and $192.3 million as of December 31, 2023 and June 30, 2023, respectively.

[0001375365-24-000011:mdna:99]
[same as prior period, unchanged from 0001375365-23-000041:mdna:73]

[0001375365-24-000011:mdna:100]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the filing of this Quarterly Report on Form 10-Q. On December 7, 2023, our Taiwan subsidiary entered into a new Facility Letter with the Taiwan affiliate of HSBC Bank. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million and an export/seller facility with a sub-limit of $50 million. We continue to evaluate financing options that may be required to support the growth of our business, if it occurs more rapidly than anticipated.

[0001375365-24-000011:mdna:101]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program was effective until January 31, 2024. We repurchased 1,553,350 shares of common stock for $150 million during the fiscal year ended June 30, 2023 under this program and had $50.0 million of remaining availability as of December 31, 2023 and at the time the program expired on January 31, 2024.

[0001375365-24-000011:mdna:102]
On December 5, 2023, the Company completed a public offering of 2,415,805 shares of the Company's common stock at $262.00 per share, with 2,315,105 shares sold by the Company and 100,700 shares sold by selling stockholders.

[0001375365-24-000011:mdna:103]
We received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by us. We did not receive any proceeds from the sale of the shares of common stock by the selling stockholders. We intend to utilize the proceeds to support our operations, including working capital needs, manufacturing capacity expansion and increased R&D investments.

[0001375365-24-000011:mdna:104]
SMCI | Q2 2024 Form 10-Q | 40

[0001375365-24-000011:mdna:105]
[same as prior period, unchanged from 0001375365-23-000041:mdna:76]

[0001375365-24-000011:mdna:106]
|  | Six Months EndedDecember 31, |  | Change |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (324.6) |  |  | $ | 474.7 |  |  | $ | (799.3) |  |  |  |  |
| Net cash used in investing activities | $ | (22.5) |  |  | $ | (20.6) |  |  | $ | (1.9) |  |  |  |  |
| Net cash provided by (used in) financing activities | $ | 632.2 |  |  | $ | (415.8) |  |  | $ | 1,048.0 |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 285.2 |  |  | $ | 36.5 |  |  | $ | 248.7 |  |  |  |  |

[0001375365-24-000011:mdna:107]
[same as prior period, unchanged from 0001375365-23-000041:mdna:78]

[0001375365-24-000011:mdna:108]
Net cash provided by operating activities decreased by $799.3 million for the six months ended December 31, 2023 as compared to the six months ended December 31, 2022. The decrease was primarily due to an increase in net cash required for net working capital of $945.1 million to manufacture products in order to meet customer demand and support expected business growth and a $19.0 million decrease in non-cash items. These decreases are partially offset by increase in net income of $92.4 million and stock-based compensation expense of $72.4 million. The key changes in net working capital of $945.1 million includes an increase in inventory of $1,145.2 million, and an increase in accounts receivable of $422.7 million offset by an increase in accounts payable of $570.5 million.

[0001375365-24-000011:mdna:109]
[same as prior period, unchanged from 0001375365-23-000041:mdna:80]

[0001375365-24-000011:mdna:110]
Net cash used in investing activities increased by $1.9 million for the six months ended December 31, 2023 as compared to the six months ended December 31, 2022 primarily due to an increase in investment of $5.2 million made in the six months ended December 31, 2023 offset by a decrease of $3.3 million in purchases of property, plant and equipment.

[0001375365-24-000011:mdna:111]
[same as prior period, unchanged from 0001375365-23-000041:mdna:83]

[0001375365-24-000011:mdna:112]
Net cash provided by financing activities increased by $1,048.0 million for the six months ended December 31, 2023 as compared to the six months ended December 31, 2022 primarily due to proceeds from our offering of common stock, net of issuance costs of $582.8 million and an increase of $501.3 million in proceeds from borrowings, net of repayment.

[0001375365-24-000011:mdna:113]
[same as prior period, unchanged from 0001375365-23-000041:mdna:85]

[0001375365-24-000011:mdna:114]
[same as prior period, unchanged from 0001375365-23-000041:mdna:86]

[0001375365-24-000011:mdna:115]
[same as prior period, unchanged from 0001375365-23-000041:mdna:87]

[0001375365-24-000011:mdna:116]
We anticipate our capital expenditures for the remainder of fiscal year 2024 will be in range of $170.0 million to $180.0 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. During the second quarter of fiscal year 2023, we entered into a letter of understanding to acquire land in Malaysia to expand our manufacturing operations. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. We obtained early access to such land prior to the acquisition, and we anticipate additional capital expenditures for the remainder of fiscal year 2024 of $28.0 million (included in the above range) for such initiative. In addition, in January 2024, we entered into a purchase and sale agreement (the “Purchase Agreement’) to purchase real estate comprising approximately 19.72 acres of land and 293,906 square feet of buildings and improvements located in proximity to the Company’s headquarters space in San Jose, California “as is” for an aggregate purchase price of $80.0 million, subject to certain adjustments to be determined at closing. Under the Purchase Agreement, we made a deposit of $10.0 million which is non-refundable except in limited circumstances. The transaction, currently expected to close in February 2024, is subject to customary closing conditions. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-24-000011:mdna:117]
SMCI | Q2 2024 Form 10-Q | 41

[0001375365-24-000011:mdna:118]
[same as prior period, unchanged from 0001375365-23-000041:mdna:89]

[0001375365-24-000011:mdna:119]
[same as prior period, unchanged from 0001375365-23-000041:mdna:90]

[0001375365-24-000011:mdna:120]
[same as prior period, unchanged from 0001375365-23-000041:mdna:91]

[0001375365-24-000011:mdna:121]
SMCI | Q2 2024 Form 10-Q | 42
