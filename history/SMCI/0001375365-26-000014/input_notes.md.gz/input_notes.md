# SMCI notes — 0001375365-26-000014


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-26-000014:notes:1]
[same as prior period, unchanged from 0001375365-26-000007:notes:1]

[0001375365-26-000014:notes:2]
[same as prior period, unchanged from 0001375365-26-000007:notes:2]

[0001375365-26-000014:notes:3]
[same as prior period, unchanged from 0001375365-26-000007:notes:3]

[0001375365-26-000014:notes:4]
[same as prior period, unchanged from 0001375365-26-000007:notes:4]

[0001375365-26-000014:notes:5]
[same as prior period, unchanged from 0001375365-26-000007:notes:5]

[0001375365-26-000014:notes:6]
[same as prior period, unchanged from 0001375365-26-000007:notes:6]

[0001375365-26-000014:notes:7]
[same as prior period, unchanged from 0001375365-26-000007:notes:7]

[0001375365-26-000014:notes:8]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by us are shipped from our facilities or drop shipped from our vendors. We may use distributors or channel partners to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-26-000014:notes:9]
[same as prior period, unchanged from 0001375365-26-000007:notes:9]

[0001375365-26-000014:notes:10]
[same as prior period, unchanged from 0001375365-26-000007:notes:10]

[0001375365-26-000014:notes:11]
[same as prior period, unchanged from 0001375365-26-000007:notes:11]

[0001375365-26-000014:notes:12]
[same as prior period, unchanged from 0001375365-26-000007:notes:12]

[0001375365-26-000014:notes:13]
[same as prior period, unchanged from 0001375365-26-000007:notes:13]

[0001375365-26-000014:notes:14]
[same as prior period, unchanged from 0001375365-26-000007:notes:14]

[0001375365-26-000014:notes:15]
[same as prior period, unchanged from 0001375365-26-000007:notes:15]

[0001375365-26-000014:notes:16]
[same as prior period, unchanged from 0001375365-26-000007:notes:16]

[0001375365-26-000014:notes:17]
[same as prior period, unchanged from 0001375365-26-000007:notes:17]

[0001375365-26-000014:notes:18]
[same as prior period, unchanged from 0001375365-26-000007:notes:18]

[0001375365-26-000014:notes:19]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

[0001375365-26-000014:notes:20]
[same as prior period, unchanged from 0001375365-26-000007:notes:21]

[0001375365-26-000014:notes:21]
|  | March 31, 2026 |  | June 30, 2025 |
| Percentage of accounts receivable: |  |  |  |
| Customer A | 32.2% |  | * |
| Customer B | 16.8% |  | 33.4% |
| Customer C | 13.2% |  | 13.6% |
| Customer D | 12.9% |  | * |

[0001375365-26-000014:notes:22]
^The customer references of A-D above may represent different customers than those reported in a previous period.

[0001375365-26-000014:notes:23]
[same as prior period, unchanged from 0001375365-26-000007:notes:24]

[0001375365-26-000014:notes:24]
[same as prior period, unchanged from 0001375365-26-000007:notes:30]

[0001375365-26-000014:notes:25]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the FASB’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the FASB’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.

[0001375365-26-000014:notes:26]
[same as prior period, unchanged from 0001375365-26-000007:notes:32]

[0001375365-26-000014:notes:27]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.

[0001375365-26-000014:notes:28]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements other than additional disclosures.

[0001375365-26-000014:notes:29]
In May 2025, the FASB issued ASU 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810): Determining the Accounting Acquirer in the Acquisition of a Variable Interest Entity, which revises current guidance for determining the accounting acquirer for a transaction effected primarily by exchanging equity interests in which the legal acquiree is a variable interest entity that meets the definition of a business. The amendments require that an entity consider the same factors that are currently required for determining which entity is the accounting acquirer in other acquisition transactions. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000014:notes:30]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments–Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides all entities with a practical expedient and entities other than public business entities with an accounting policy election when applying the guidance in Topic 326, Financial Instruments–Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. The ASU is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2026. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000014:notes:31]
In November 2025, the FASB issued ASU 2025-08, Financial Instruments–Credit Losses (Topic 326): Purchased Loans, which expands the population of acquired financial assets subject to the gross-up approach in Topic 326. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000014:notes:32]
In December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270): Narrow-scope Improvements. This update makes targeted, narrow-scope improvements to the interim reporting guidance in Topic 270 to clarify application and improve consistency in practice. The amendments do not change the underlying principles of interim reporting. The ASU is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for interim reporting periods beginning in our fiscal year beginning July 1, 2028. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.

[0001375365-26-000014:notes:33]
In December 2025, the FASB issued ASU 2025-12, Codification Improvements, which includes 33 technical corrections, clarifications, and minor refinements across multiple ASC Topics intended to improve consistency and usability of U.S. GAAP. Transition is applied on an issue-by-issue basis: the EPS clarification (ASC 260, Issue 4) is applied retrospectively to all prior periods presented, while all other amendments may be applied prospectively or retrospectively, with appropriate disclosures about the nature/reason for the change (and additional disclosures if applied retrospectively). The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.

[0001375365-26-000014:notes:34]
[same as prior period, unchanged from 0001375365-26-000007:notes:40]

[0001375365-26-000014:notes:35]
Certain prior period amounts have been reclassified to conform to the current period presentation. Such reclassifications did not result in net changes to condensed consolidated balance sheets, statements of operations, or statements of cash flows.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001375365-26-000014:notes:36]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Percentage of total net sales: |  |  |  |  |  |  |  |
| Customer A | 27.0% |  | * |  | 38.5% |  | 15.1% |
| Customer B | * |  | 22.5% |  | * |  | 23.5% |
| Customer C | * |  | 14.1% |  | * |  | * |
| Customer D | 10.3% |  | * |  | * |  | 13.5% |

[0001375365-26-000014:notes:37]
^The customer references of A-D above may represent different customers than those reported in a previous period.
*Below 10%


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-26-000014:notes:38]
[same as prior period, unchanged from 0001375365-26-000007:notes:44]

[0001375365-26-000014:notes:39]
[same as prior period, unchanged from 0001375365-26-000007:notes:45]

[0001375365-26-000014:notes:40]
[same as prior period, unchanged from 0001375365-26-000007:notes:46]

[0001375365-26-000014:notes:41]
Additionally, the CODM reviews significant segment expenses including the inventory valuation adjustment write-downs, recorded to cost of sales, which is separately disclosed in Note 6, “Balance Sheet Components”, and stock-based compensation, which is separately disclosed in Note 12, “Stock-based Compensation and Stockholders’ Equity” in the notes to the condensed consolidated financial statements.

[0001375365-26-000014:notes:42]
[same as prior period, unchanged from 0001375365-26-000007:notes:48]

[0001375365-26-000014:notes:43]
[same as prior period, unchanged from 0001375365-26-000007:notes:49]

[0001375365-26-000014:notes:44]
Total revenue recognized from all services and software for the three months ended March 31, 2026 and 2025 was $140.5 million and $71.8 million, respectively. Of this, revenue related to services recognized on an over time basis during the contract term was $104.4 million and $57.2 million for the three months ended March 31, 2026 and 2025, respectively.

[0001375365-26-000014:notes:45]
Total revenue recognized from all service and software for the nine months ended March 31, 2026 and 2025 was $368.5 million and $244.5 million, respectively. Of this, revenue related to services recognized on an over time basis during the contract term was $280.4 million and $161.8 million for the nine months ended March 31, 2026 and 2025, respectively.

[0001375365-26-000014:notes:46]
[same as prior period, unchanged from 0001375365-26-000007:notes:52]

[0001375365-26-000014:notes:47]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2026 |  | % of Total |  | 2025 |  | % of Total |  | 2026 |  | % of Total |  | 2025 |  | % of Total |
| United States | $ | 7,033,882 |  |  | 68.7 | % |  | $ | 2,768,181 |  |  | 60.2 | % |  | $ | 19,797,305 |  |  | 70.8 | % |  | $ | 10,856,490 |  |  | 67.0 | % |
| Other (1) | 3,209,132 |  |  | 31.3 | % |  | 1,831,732 |  |  | 39.8 | % |  | 8,145,990 |  |  | 29.2 | % |  | 5,358,641 |  |  | 33.0 | % |
| Total | $ | 10,243,014 |  |  | 100.0 | % |  | $ | 4,599,913 |  |  | 100.0 | % |  | $ | 27,943,295 |  |  | 100.0 | % |  | $ | 16,215,131 |  |  | 100.0 | % |

[0001375365-26-000014:notes:48]
[same as prior period, unchanged from 0001375365-26-000007:notes:54]

[0001375365-26-000014:notes:49]
[same as prior period, unchanged from 0001375365-26-000007:notes:55]

[0001375365-26-000014:notes:50]
[same as prior period, unchanged from 0001375365-26-000007:notes:56]

[0001375365-26-000014:notes:51]
[same as prior period, unchanged from 0001375365-26-000007:notes:57]

[0001375365-26-000014:notes:52]
[same as prior period, unchanged from 0001375365-26-000007:notes:58]

[0001375365-26-000014:notes:53]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede our satisfaction of the associated performance obligations. Our deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2026, which was included in the opening deferred revenue balance as of June 30, 2025 of $731.4 million, was $57.0 million and $302.8 million, respectively. Revenue recognized during the three and nine months ended March 31, 2025, which was included in the opening deferred revenue balance as of June 30, 2024 of $416.4 million, was $38.5 million and $154.0 million, respectively.

[0001375365-26-000014:notes:54]
[same as prior period, unchanged from 0001375365-26-000007:notes:60]

[0001375365-26-000014:notes:55]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. We apply the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. The remaining performance obligations excluded from this disclosure primarily relate to short-term backlog contracts expected to be fulfilled within one year, including on-site services, integration services, extended warranty services, and for product where control has not been transferred. The value of the transaction price allocated to the remaining performance obligations as of March 31, 2026 was approximately $2,135.6 million. We expect to recognize approximately 69% of such value in the next 12 months, and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-26-000014:notes:56]
[same as prior period, unchanged from 0001375365-26-000007:notes:62]

[0001375365-26-000014:notes:57]
[same as prior period, unchanged from 0001375365-26-000007:notes:63]

[0001375365-26-000014:notes:58]
[same as prior period, unchanged from 0001375365-26-000007:notes:64]

[0001375365-26-000014:notes:59]
[same as prior period, unchanged from 0001375365-26-000007:notes:65]

[0001375365-26-000014:notes:60]
The following table sets forth our financial instruments as of March 31, 2026 and June 30, 2025, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-26-000014:notes:61]
|  | As of March 31, 2026 |  | As of June 30, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 19 |  |  | $ | — |  |  | $ | — |  |  | $ | 19 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |
| Certificates of deposit | — |  |  | 47,494 |  |  | — |  |  | 47,494 |  |  | — |  |  | 519 |  |  | — |  |  | 519 |  |
| Marketable equity security | 14,709 |  |  | — |  |  | — |  |  | 14,709 |  |  | 6,239 |  |  | — |  |  | — |  |  | 6,239 |  |
| Available-for-Sale Investment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Auction rate security (2) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,750 |  |  | 1,750 |  |
| Total assets | $ | 14,728 |  |  | $ | 47,494 |  |  | $ | — |  |  | $ | 62,222 |  |  | $ | 6,283 |  |  | $ | 519 |  |  | $ | 1,750 |  |  | $ | 8,552 |  |

[0001375365-26-000014:notes:62]
(1) All of the money market funds are included in cash and cash equivalents in the condensed consolidated balance sheets as of March 31, 2026 and June 30, 2025, respectively.

[0001375365-26-000014:notes:63]
(2) The fair value of our auction rate security was immaterial as of March 31, 2026.

[0001375365-26-000014:notes:64]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in prepaid expenses and other current assets in the condensed consolidated balance sheets. The unrealized gains and losses of the investment are included in other income (expense), net in our condensed consolidated statements of operations. For the three and nine months ended March 31, 2026, an unrealized loss of $0.5 million and an unrealized gain of $8.5 million, respectively, were recorded in other income (expense), net in the condensed consolidated statements of operations. For the three and nine months ended March 31, 2025, an unrealized loss of $1.3 million and an unrealized loss of $0.2 million, respectively, were recorded in other income (expense), net in the condensed consolidated statements of operations.

[0001375365-26-000014:notes:65]
On a quarterly basis, we also evaluate the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, current economic conditions, and reasonable economic forecasts that affect collectability. For the three and nine months ended March 31, 2026 and 2025, the credit losses related to our investments were not material.

[0001375365-26-000014:notes:66]
There were no transfers between Level 1, Level 2, or Level 3 financial instruments during the three and nine months ended March 31, 2026 and 2025.

[0001375365-26-000014:notes:67]
[same as prior period, unchanged from 0001375365-26-000007:notes:73]

[0001375365-26-000014:notes:68]
Accounts receivable, accounts payable, and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments. We estimate the fair value of outstanding debt, including our 3.50% Convertible Senior Notes due 2029 (“2029 Convertible Notes”), 2.25% Convertible Senior Notes due 2028 (“2028 Convertible Notes”), and 0.00% Convertible Senior Notes due 2030 (“2030 Convertible Notes”), for disclosure purposes on a recurring basis. Non-current accounts receivable, included in other assets in the condensed consolidated balance sheets, are carried at amortized cost, and bear interest at rates that approximate current market rates for similar credit. We believe the carrying amounts approximate fair value because there have been no significant changes in market rates or credit risk.

[0001375365-26-000014:notes:69]
As of March 31, 2026 and June 30, 2025, our total lines of credit and term loans of $4,113.7 million and $112.5 million, respectively, are reported at amortized cost. The carrying value of our outstanding lines of credit and term loans approximates fair value because the borrowings primarily bear interest at variable rates based on current market rates or have short-term maturities. These fair value measurements are classified within Level 2 of the fair value hierarchy based on observable market inputs.

[0001375365-26-000014:notes:70]
The estimated fair values as of March 31, 2026 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,381.7 million, $601.9 million, and $1,684.3 million, respectively. The estimated fair values as of June 30, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,801.9 million, $818.5 million, and $2,576.6 million. The estimated fair values of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes was determined based on level 2 inputs of quoted market prices.


## smci:NonMarketableEquityInvestmentsTextBlock

[0001375365-26-000014:notes:71]
[same as prior period, unchanged from 0001375365-26-000007:notes:77]

[0001375365-26-000014:notes:72]
[same as prior period, unchanged from 0001375365-26-000007:notes:78]

[0001375365-26-000014:notes:73]
|  | March 31, 2026 |  | June 30, 2025 |
| Non-marketable equity securities: |  |  |  |
| Opening gross investment balance (as of July 1, 2025 and July 1, 2024) | $ | 122,217 |  |  | $ | 66,217 |  |
| Investments made during the period | 42,000 |  |  | 56,000 |  |
| Cumulative impairment adjustments | (23,600) |  |  | (11,600) |  |
| Total carrying value - before the adjustments under equity method | 140,617 |  |  | 110,617 |  |
| Securities under equity method - cumulative adjustment | (1,027) |  |  | — |  |
| Total carrying value (as of March 31, 2026 and June 30, 2025) | $ | 139,590 |  |  | $ | 110,617 |  |

[0001375365-26-000014:notes:74]
Our non-marketable equity securities include $92.5 million invested in an unrelated party (the “Sub-licensee”) to which we have subleased the entire space in Vernon, California. The Sub-licensee does not meet the criteria of a related party. Additionally, the Sub-licensee has been a customer of ours, and we concluded that equity investment agreements and sub-licensing agreements are separate from revenue contracts as all transactions have been recorded at the respective fair values. Please refer to Note 10, “Leases” for further discussion.

[0001375365-26-000014:notes:75]
During the nine months ended March 31, 2026, we recognized an impairment loss of $12.0 million. No impairment loss was recorded during the three months ended March 31, 2026.


## us-gaap:EarningsPerShareTextBlock

[0001375365-26-000014:notes:76]
[same as prior period, unchanged from 0001375365-26-000007:notes:82]

[0001375365-26-000014:notes:77]
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2026 and 2025 (in thousands, except per share amounts):

[0001375365-26-000014:notes:78]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 483,387 |  |  | $ | 108,777 |  |  | $ | 1,052,236 |  |  | $ | 853,700 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | — |  |  | 16,472 |  |  | 1,777 |  |
| Net income - diluted | $ | 501,275 |  |  | $ | 108,777 |  |  | $ | 1,068,708 |  |  | $ | 855,477 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 600,205 |  |  | 595,041 |  |  | 597,928 |  |  | 592,349 |  |
| Effect of dilutive convertible notes | 73,803 |  |  | — |  |  | 53,130 |  |  | 1,673 |  |
| Effect of dilutive securities | 18,181 |  |  | 26,768 |  |  | 22,540 |  |  | 31,250 |  |
| Weighted-average shares outstanding - diluted | 692,189 |  |  | 621,809 |  |  | 673,598 |  |  | 625,272 |  |
| Net income per common share - basic | $ | 0.81 |  |  | $ | 0.18 |  |  | $ | 1.76 |  |  | $ | 1.44 |  |
| Net income per common share - diluted | $ | 0.72 |  |  | $ | 0.17 |  |  | $ | 1.59 |  |  | $ | 1.37 |  |
| Anti-dilutive shares excluded from diluted net income per share: |  |  |  |  |  |  |  |
| Stock-based awards | 28,653 |  |  | 16,245 |  |  | 20,203 |  |  | 9,278 |  |
| Convertible notes | — |  |  | 32,138 |  |  | 20,673 |  |  | 20,673 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-26-000014:notes:79]
[same as prior period, unchanged from 0001375365-26-000007:notes:85]

[0001375365-26-000014:notes:80]
[same as prior period, unchanged from 0001375365-26-000007:notes:86]

[0001375365-26-000014:notes:81]
[same as prior period, unchanged from 0001375365-26-000007:notes:87]

[0001375365-26-000014:notes:82]
|  | March 31, 2026 |  | June 30, 2025 |
| Cash and cash equivalents | $ | 1,290,324 |  |  | $ | 5,169,911 |  |
| Restricted cash included in prepaid expenses and other current assets and other assets | 49,642 |  |  | 2,390 |  |
| Total cash, cash equivalents and restricted cash | $ | 1,339,966 |  |  | $ | 5,172,301 |  |

[0001375365-26-000014:notes:83]
[same as prior period, unchanged from 0001375365-26-000007:notes:89]

[0001375365-26-000014:notes:84]
|  | March 31, 2026 |  | June 30, 2025 |
| Finished goods | $ | 8,154,074 |  |  | $ | 3,465,352 |  |
| Work in process | 1,991,524 |  |  | 674,613 |  |
| Purchased parts and raw materials | 957,778 |  |  | 540,410 |  |
| Total inventories | $ | 11,103,376 |  |  | $ | 4,680,375 |  |

[0001375365-26-000014:notes:85]
During the three months ended March 31, 2026 and 2025, we recorded write down adjustments for excess and obsolete inventory and lower of cost and net realizable value adjustments to cost of sales totaling $70.2 million and $125.1 million, respectively, and recorded adjustments totaling $239.3 million and $159.0 million, respectively, during the nine months ended March 31, 2026 and 2025.

[0001375365-26-000014:notes:86]
[same as prior period, unchanged from 0001375365-26-000007:notes:92]

[0001375365-26-000014:notes:87]
|  | March 31, 2026 |  | June 30, 2025 |
| Land | $ | 193,417 |  |  | $ | 162,848 |  |
| Buildings | 186,860 |  |  | 182,466 |  |
| Machinery and equipment | 141,458 |  |  | 111,331 |  |
| Building and leasehold improvements | 136,018 |  |  | 121,665 |  |
| Construction in progress | 55,705 |  |  | 1,038 |  |
| Furniture and fixtures | 42,607 |  |  | 36,268 |  |
| Software | 7,419 |  |  | 7,117 |  |
| Property, plant, and equipment, gross | 763,484 |  |  | 622,733 |  |
| Accumulated depreciation and amortization | (155,825) |  |  | (118,245) |  |
| Property, plant, and equipment, net | $ | 607,659 |  |  | $ | 504,488 |  |

[0001375365-26-000014:notes:88]
Depreciation expense for the three months ended March 31, 2026 and 2025 was $13.5 million and $10.9 million, respectively, and for the nine months ended March 31, 2026 and 2025 was $38.4 million and $29.4 million, respectively.

[0001375365-26-000014:notes:89]
[same as prior period, unchanged from 0001375365-26-000007:notes:95]

[0001375365-26-000014:notes:90]
|  | March 31, 2026 |  | June 30, 2025 |
| Operating lease ROU asset | $ | 361,437 |  |  | $ | 293,692 |  |
| Long-term investments | 139,593 |  |  | 112,367 |  |
| Tariff receivable* | 64,539 |  |  | — |  |
| Non-current accounts receivable | 23,194 |  |  | 166,405 |  |
| Deferred service costs, non-current | 11,164 |  |  | 10,713 |  |
| Deposits | 3,896 |  |  | 4,980 |  |
| Restricted cash, non-current | 2,642 |  |  | 2,390 |  |
| Other | 36,904 |  |  | 14,324 |  |
| Total other assets | $ | 643,369 |  |  | $ | 604,871 |  |

[0001375365-26-000014:notes:91]
*Represents receivables related to the Company’s claims under Section 232 of the Trade Expansion Act of 1962. Refer to Note 14 for additional disclosures related to the Supreme Court decision related to tariff under the International Emergency Economic Powers Act (IEEPA).

[0001375365-26-000014:notes:92]
[same as prior period, unchanged from 0001375365-26-000007:notes:97]

[0001375365-26-000014:notes:93]
|  | March 31, 2026 |  | June 30, 2025 |
| Customer deposits | $ | 203,570 |  |  | $ | 260,131 |  |
| Customer-related liabilities | 139,084 |  | 32,858 |  |
| Accrued payroll and related expenses | 122,983 |  | 82,156 |  |
| Import tax and tariff liabilities | 56,323 |  | 20,883 |  |
| Accrued cooperative marketing expenses | 51,939 |  | 26,775 |  |
| Input tax payable | 45,493 |  | 39,161 |  |
| Accrued interest - lines of credit and term loans | 35,606 |  | 146 |  |
| Accrued withholding tax | 38,653 |  | 6 |  |
| Operating lease liability | 32,703 |  | 21,189 |  |
| Accrued warranty costs | 15,363 |  | 9,753 |  |
| Accrued professional fees | 11,694 |  | 8,098 |  |
| Accrued interest - convertible notes | 8,356 |  | 27,701 |  |
| Other | 68,240 |  | 36,780 |  |
| Total accrued liabilities | $ | 830,007 |  |  | $ | 565,637 |  |

[0001375365-26-000014:notes:94]
[same as prior period, unchanged from 0001375365-26-000007:notes:99]

[0001375365-26-000014:notes:95]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Balance, beginning of the period | $ | 23,012 |  |  | $ | 18,288 |  |  | $ | 16,954 |  |  | $ | 17,815 |  |
| Provision for warranty | 17,043 |  |  | 25,253 |  |  | 88,258 |  |  | 53,949 |  |
| Costs utilized | (16,895) |  |  | (24,277) |  |  | (82,430) |  |  | (51,131) |  |
| Change in estimated liability for pre-existing warranties | 607 |  |  | (337) |  |  | 985 |  |  | (1,706) |  |
| Balance, end of the period | $ | 23,767 |  |  | $ | 18,927 |  |  | $ | 23,767 |  |  | $ | 18,927 |  |
| Current portion | $ | 15,363 |  |  | $ | 10,740 |  |  | $ | 15,363 |  |  | $ | 10,740 |  |
| Non-current portion | $ | 8,404 |  |  | $ | 8,187 |  |  | $ | 8,404 |  |  | $ | 8,187 |  |

[0001375365-26-000014:notes:96]
[same as prior period, unchanged from 0001375365-26-000007:notes:101]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0001375365-26-000014:notes:97]
Note 7.                 Receivables Purchase Agreement

[0001375365-26-000014:notes:98]
On July 16, 2025, we entered into a Receivables Purchase Agreement (as amended, supplemented or otherwise modified from time to time, the “Receivables Purchase Agreement”), by and among, us, as seller and guarantor, MUFG Bank, Ltd. (“MUFG”), Crédit Agricole Corporate and Investment Bank, and certain other entities from time to time party thereto as purchasers (the “Purchasers”), and MUFG as administrative agent (in such capacity, the “Administrative Agent”).

[0001375365-26-000014:notes:99]
Pursuant to the Receivables Purchase Agreement, we may, subject to the terms and conditions set out therein, sell certain of our accounts receivable and related rights to the Purchasers (the “Purchased Receivables”). The Receivables Purchase Agreement provides for an uncommitted facility with an initial aggregate facility limit of $1,790.0 million. The Purchasers may elect in their sole direction to purchase eligible accounts receivable offered by us under the Receivables Purchase Agreement at the applicable purchase discount. The purchase price for any Purchased Receivable will be the net invoice amount of the Purchased Receivable, minus the applicable discount, which is set at Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Receivables Purchase Agreement) plus a specified discount assigned to each account debtor in the range of 1.15% - 2.80%, and calculated on the basis of a specified discount period. In the event the purchase of such Purchased Receivables is not characterized as a sale, we will be deemed to have granted a security interest in such Purchased Receivables and the proceeds thereof in favor of the Purchasers.

[0001375365-26-000014:notes:100]
Trade receivables sold and discount on trade receivables sold under this program were as follows (in thousands):

[0001375365-26-000014:notes:101]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  |  |  | 2026 |  |  |
| Trade receivables sold | $ | 831,674 |  |  |  |  | $ | 831,674 |  |  |  |
| Discount on trade receivables (1) | $ | 5,737 |  |  |  |  | $ | 5,737 |  |  |  |

[0001375365-26-000014:notes:102]
(1) Included in general and administrative expenses in the condensed consolidated statements of operations.

[0001375365-26-000014:notes:103]
Trade receivables sold under the Receivables Purchase Agreement and subject to servicing by us that remained outstanding and uncollected, and collected as of March 31, 2026, are as follows (in thousands):

[0001375365-26-000014:notes:104]
|  | March 31, 2026 |  |  |  |  |  |
| Outstanding and uncollected | $ | 123,628 |  |  |  |  |  |  |
| Outstanding and collected (1) | $ | 4,191 |  |  |  |  |  |  |

[0001375365-26-000014:notes:105]
(1) Amount collected but not yet remitted to purchasers as of March 31, 2026 is classified in accrued liabilities on the condensed consolidated balance sheet.


## us-gaap:DebtDisclosureTextBlock

[0001375365-26-000014:notes:106]
Note 8.                 Lines of Credit, Revolving Credit Facilities, and Term Loans

[0001375365-26-000014:notes:107]
Short-term and long-term loan obligations with respect to lines of credit and term loans as of March 31, 2026 and June 30, 2025 consisted of the following (in thousands):

[0001375365-26-000014:notes:108]
|  | March 31, |  | June 30, |
|  | 2026 |  | 2025 |
| Lines of credit: |  |  |  |
| CTBC Credit Lines | $ | 181,305 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 25,005 |  |  | — |  |
| E.SUN Bank Credit Lines | 50,000 |  |  | 30,000 |  |
| Mega Bank Credit Lines | 30,000 |  |  | — |  |
| First Bank Credit Lines | 19,935 |  |  | — |  |
| JP Morgan Revolving Credit Facility | 2,000,000 |  |  | — |  |
| CTBC Revolving Credit Facilities | 1,762,970 |  |  | — |  |
| Total lines of credit | 4,069,215 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 4,562 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 22,343 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 603 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 5,005 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 5,760 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 6,256 |  |  | 17,098 |  |
| Total term loans | 44,529 |  |  | 82,475 |  |
| Total lines of credit and term loans | $ | 4,113,744 |  |  | $ | 112,475 |  |
| Lines of credit and term loans, current | $ | 2,095,069 |  |  | $ | 75,060 |  |
| Lines of credit and term loans, non-current | $ | 2,018,675 |  |  | $ | 37,415 |  |

[0001375365-26-000014:notes:109]
Activities under Lines of Credit, Revolving Credit Facilities, and Term Loans

[0001375365-26-000014:notes:110]
Available borrowings and interest rates as of March 31, 2026 and June 30, 2025 consisted of the following (in thousands except for percentages):

[0001375365-26-000014:notes:111]
|  | March 31, 2026 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Lines of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 3,695 |  |  | 2.26% - 4.62% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 1,714 |  |  | 1.88% - 4.40% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 10,000 |  |  | 2.02% - 4.67% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 3,744 |  |  | 2.23% - 4.48% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 65 |  |  | 2.03% - 4.49% |  | $ | — |  |  | n/a |
| JP Morgan Revolving Credit Facility | $ | — |  |  | 3.67% - 3.67% |  | $ | — |  |  | n/a |
| CTBC Revolving Credit Facilities | $ | — |  |  | 2.86% - 5.11% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |

[0001375365-26-000014:notes:112]
See Note 7, “Lines of Credit and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.

[0001375365-26-000014:notes:113]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-26-000014:notes:114]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2026 |  | $ | 291,545 |  |
| 2027 |  | 1,805,882 |  |
| 2028 |  | 6,039 |  |
| 2029 |  | 5,362 |  |
| 2030 |  | 4,916 |  |
| 2031 and thereafter |  | 2,000,000 |
| Total lines of credit and term loans |  | $ | 4,113,744 |  |

[0001375365-26-000014:notes:115]
As of March 31, 2026, we were in compliance with all the covenants for the lines of credit and term loans on our condensed consolidated balance sheets.

[0001375365-26-000014:notes:116]
We entered into new agreements, or extensions of previous agreements, during the nine months ended March 31, 2026, with the following terms:

[0001375365-26-000014:notes:117]
CTBC Bank Credit Lines

[0001375365-26-000014:notes:118]
2025 CTBC Facility Letter

[0001375365-26-000014:notes:119]
On February 13, 2026, our Taiwan subsidiary received a facility extension letter to extend the maturity date, originally set to expire on February 28, 2026, to March 31, 2027.

[0001375365-26-000014:notes:120]
As of March 31, 2026, the outstanding borrowings under the 2025 CTBC Bank Credit Lines was $181.3 million.

[0001375365-26-000014:notes:121]
Mega Bank

[0001375365-26-000014:notes:122]
Mega Bank Credit Facilities

[0001375365-26-000014:notes:123]
On February 4, 2026, our Taiwan subsidiary renewed the facility from Mega Bank. The renewed facility continues to provide up to $50.0 million including sub-item of NTD 600.0 million in total credit capacity. The maturity date is January 8, 2027.

[0001375365-26-000014:notes:124]
As of March 31, 2026, the outstanding borrowings under this facility was $30.0 million.

[0001375365-26-000014:notes:125]
First Bank

[0001375365-26-000014:notes:126]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. Subsequently on February 26, 2026, we renewed the Credit Agreement and the new maturity date is March 9, 2027.

[0001375365-26-000014:notes:127]
As of March 31, 2026, the outstanding borrowings under the First Bank credit line was $19.9 million.

[0001375365-26-000014:notes:128]
JP Morgan Revolving Credit Facility

[0001375365-26-000014:notes:129]
On December 29, 2025, we entered into a credit agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., (“JP Morgan”) as administrative agent and collateral agent, and a syndicate of lenders, which provides for a revolving credit facility of up to $2,000.0 million (the “Revolving Credit Facility”), including a $200.0 million letter of credit sub-limit and a $150.0 million same-day borrowing sub-limit, with an option to increase total commitments by up to $1,000.0 million subject to certain conditions. Borrowings under the Revolving Credit Facility may be used for working capital and other general corporate purposes. The upfront fees totaling $9.8 million incurred in connection with the credit agreement were capitalized as deferred cost and recorded as a non-current asset included within other assets on the condensed consolidated balance sheet as of issuance of the credit facility. These deferred financing costs are being amortized to interest expense over the term of the Revolving Credit Facility and not material.

[0001375365-26-000014:notes:130]
As of March 31, 2026, we had $2,000.0 million outstanding under the Revolving Credit Facility.

[0001375365-26-000014:notes:131]
Borrowings under the Revolving Credit Facility bear interest, at our option, at either an alternate base rate (“ABR”) or a term rate, in each case plus an applicable margin. The applicable margin varies based on (i) during a non-investment grade period, our leverage ratio (ranging from 1.25% to 2.00% for term rate loans and 0.25% to 1.00% for ABR loans), or (ii) during an investment grade period, our corporate family rating (ranging from 1.13% to 1.38% for term rate loans and 0.13% to 0.38% for ABR loans). We also pay a quarterly commitment fee on unused commitments ranging from 0.15% to 0.30% during a non-investment grade period (or 0.12% to 0.15% during an investment grade period). Investment grade period refers to the period beginning on the date (no earlier than September 30, 2026) when we attain an investment grade corporate family rating from at least two of Moody’s (Baa3 or higher), S&P (BBB- or higher), and Fitch (BBB- or higher), in each case with a stable or better outlook, and delivers an officer’s certificate to the administrative agent confirming such ratings, and continuing until the occurrence of a subsequent non-investment grade trigger event. The Revolving Credit Facility matures on December 29, 2030.

[0001375365-26-000014:notes:132]
During any non-investment grade period, the Revolving Credit Facility is guaranteed by us and certain qualifying domestic subsidiaries (subject to customary exclusions) and is secured by a first-priority lien on substantially all assets of the applicable loan parties (subject to customary exclusions). The Credit Agreement includes customary restrictive covenants (some of which are not applicable during an investment grade period), including limitations on indebtedness, investments, and restricted payments, and a maximum total net leverage ratio covenant of 4.00:1.00 for the first four full fiscal quarters after inception, stepping down to 3.50:1.00 for the next four full fiscal quarters, and 3.00:1.00 thereafter. The Credit Agreement contains customary events of default (including change of control), which upon occurrence may result in the acceleration of amounts outstanding and termination of lender commitments.

[0001375365-26-000014:notes:133]
CTBC Revolving Credit Facilities

[0001375365-26-000014:notes:134]
On January 21, 2026, we entered into a facilities agreement (the “Credit Agreement”) with a group of lenders led by CTBC Bank Co., Ltd., along with Credit Agricole Corporate and Investment Bank, Taipei Branch and E.Sun Commercial Bank, Ltd. as mandated lead arrangers and bookrunners (with CTBC Bank Co., Ltd. also acting as administrative agent under the Credit Agreement). The agreement provides for two revolving credit facilities totaling $710.0 million (the “CTBC Revolving Credit Facilities”), comprised of Facility A1 ($350.0 million) and Facility A2 ($360.0 million), with an option to increase total commitments to up to $2,000.0 million, subject to certain conditions. On January 30, 2026, we entered into an increased facilities letter under the Credit Agreement, providing for additional revolving credit facilities in an aggregate amount of $1,055.0 million. As a result, the total lender commitments under the Credit Agreement increased to $1,765.0 million.

[0001375365-26-000014:notes:135]
The proceeds of the CTBC Revolving Credit Facilities may be applied to procure certain components and/or raw materials, subject to specified invoice and purchase order documentation and related timing requirements. We may request loans under the CTBC Revolving Credit Facilities at any time until and including the date falling one month prior to the maturity date. We intend to use the proceeds under the Credit Agreement for general corporate purposes, including to fund working capital for growth and business expansion, subject to the foregoing conditions.

[0001375365-26-000014:notes:136]
Borrowings under Facility A1 denominated in USD accrue interest at the US dollar offered rate of the Taipei Forex Trading Center (“TAIFX3”) (subject to a zero floor) plus a margin of 1.0% per annum, and borrowings under Facility A2 denominated in USD accrue interest at Term SOFR (subject to a zero floor) plus a margin of 1.2% per annum. Borrowings under Facility A1 and Facility A2 denominated in NTD accrue interest at the Taipei Interbank Offered Rate (“TAIBOR”) (subject to a zero floor) plus a margin of 1.0% per annum; provided that the interest rate applicable to any loan denominated in NTD will never be less than 1.7%. We pay a commitment fee on unused and available commitments under the CTBC Revolving Credit Facilities on each day of the availability period that the daily average utilization amount of the CTBC Revolving Credit Facilities is less than 50% of total commitments at a rate of 0.15% per annum, payable quarterly in arrears. A 0.10% fee is payable if the maturity of the CTBC Revolving Credit Facilities is extended. Each prepayment of a loan under the CTBC Revolving Credit Facilities on a date other than the last day of the applicable interest period and any cancellation of commitments under the CTBC Revolving Credit Facilities is subject to a fee of 0.15% of the relevant prepaid amount and/or cancelled amount.

[0001375365-26-000014:notes:137]
The CTBC Revolving Credit Facilities mature on the first anniversary of the date of initial utilization; if no utilization is made within six months following the signing date of the Credit Agreement, the date of initial utilization will be deemed to be the first day following the completion of such six-month period. We may extend the maturity of the CTBC Revolving Credit Facilities on no more than two occasions, in each case by an additional year. The Credit Agreement is governed by the laws of Taiwan, and disputes are subject to the non-exclusive jurisdiction of the courts of Taiwan. The upfront fees totaling $13.7 million incurred in connection with the credit agreement were capitalized as deferred cost and recorded as a current asset included within prepaid expenses and other current assets on the condensed consolidated balance sheet as of issuance of the credit facilities. These deferred financing costs are being amortized to interest expense over the term of the Revolving Credit Facility and not material.

[0001375365-26-000014:notes:138]
As of March 31, 2026, we had $1,763.0 million outstanding under the CTBC Revolving Credit Facilities.

[0001375365-26-000014:notes:139]
Note 9.                 Convertible Notes

[0001375365-26-000014:notes:140]
The following table summarizes our convertible notes as of March 31, 2026:

[0001375365-26-000014:notes:141]
|  | Issuance Date |  | Principal (in millions) |  | Coupon Interest |  | Maturity |  | Conversion price |  | Carrying Value (in millions) |  | Effective Interest Rate |
| 2028 Convertible Notes | 2/20/2025 |  | $ | 700.0 |  |  | 2.25 | % |  | 7/15/2028 |  | $ | 61.06 |  |  | $ | 688.9 |  |  | 2.97 | % |
| 2029 Convertible Notes | 2/27/2024 |  | $ | 1,725.0 |  |  | 3.50 | % |  | 3/1/2029 |  | $ | 83.44 |  |  | $ | 1,707.8 |  |  | 3.86 | % |
| 2030 Convertible Notes | 6/23/2025 |  | $ | 2,300.0 |  |  | 0.00 | % |  | 6/15/2030 |  | $ | 55.20 |  |  | $ | 2,262.7 |  |  | 0.39 | % |

[0001375365-26-000014:notes:142]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of March 31, 2026.

[0001375365-26-000014:notes:143]
2029 Convertible Notes

[0001375365-26-000014:notes:144]
We issued $1,725.0 million of 0.00% Convertible Senior Notes due 2029 (“Original 2029 Notes”) in February 2024. On February 20, 2025, we executed privately negotiated subscription and supplemental indenture agreements to amend the Original 2029 Notes (the “2029 Amendments”). Key changes included (i) establishing a 3.50% annual coupon, payable semi-annually on March 1 and September 1 beginning September 2025, and (ii) adjusting the conversion rate to 11.9842 shares per $1,000 principal amount, equivalent to a conversion price of approximately $83.44 per share. All other material terms remained substantially unchanged.

[0001375365-26-000014:notes:145]
The amendment was accounted for as an extinguishment of the original debt and issuance of new debt under Accounting Standards Codification (“ASC”) 470-50, resulting in a $30.3 million extinguishment loss recorded in other income (expense), net, during the quarter ended March 31, 2025. Debt issuance costs are amortized to interest expense using the effective interest method.

[0001375365-26-000014:notes:146]
Holders may convert their notes upon the occurrence of certain conditions, including: (1) if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) if the trading price of the notes is below 98% of the product of the stock price and conversion rate; (3) upon certain corporate events or distributions; (4) if we call the notes for redemption; or (5) at any time from and after September 1, 2028 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, at our option beginning March 1, 2027 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-26-000014:notes:147]
As of March 31, 2026 and June 30, 2025, unamortized issuance costs are $17.2 million and $21.3 million, respectively. The interest expense for the three months ended March 31, 2026 and 2025 totaled $16.5 million and $8.2 million, respectively, including $1.4 million and $0.8 million, respectively, from the amortization of debt issuance costs. Interest expense for the nine months ended March 31, 2026 and 2025 totaled $49.4 million and $8.2 million, respectively, including $4.1 million and $0.8 million, respectively, from the amortization of debt issuance costs.

[0001375365-26-000014:notes:148]
In connection with the issuance, we entered into 2029 Capped Call Transactions with certain financial institutions to reduce potential dilution upon conversion or offset cash payments exceeding principal. The capped calls were initially structured with a $134.14 strike price and $195.10 cap price and were amended in February 2025 to reflect the updated conversion rate. The amended cap price is $94.17 per share. These instruments are equity-classified under ASC 815-40, and no incremental value was recorded upon amendment.

[0001375365-26-000014:notes:149]
2028 Convertible Notes

[0001375365-26-000014:notes:150]
On February 20, 2025, we issued $700.0 million aggregate principal amount of 2028 Convertible Notes under an indenture with U.S. Bank Trust Company, N.A., as trustee. The notes were issued concurrently with the amended 2029 Convertible Notes and are convertible, at our election, into cash, shares of common stock, or a combination of both. The initial conversion rate is 16.3784 shares per $1,000 principal amount, equivalent to a conversion price of approximately $61.06 per share.

[0001375365-26-000014:notes:151]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2028 Convertible Notes Indenture; (4) if we call the 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-26-000014:notes:152]
Interest accrues from February 20, 2025, and is payable semi-annually on January 15 and July 15, beginning July 15, 2025. The notes mature on July 15, 2028, unless earlier converted, redeemed, or repurchased. Redemption may occur on or after March 1, 2026, if the stock price exceeds 150% of the conversion price for a specified period.

[0001375365-26-000014:notes:153]
The notes include customary provisions for conversion, redemption, and repurchase following a fundamental change. Upon such an event, holders may require us to repurchase all or part of their notes for cash equal to 100% of principal plus accrued interest, and the conversion rate may be increased for holders converting in connection with a qualifying corporate event or redemption.

[0001375365-26-000014:notes:154]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of March 31, 2026 and June 30, 2025, unamortized issuance costs are $11.1 million and $14.6 million, respectively. Interest expense for the three months ended March 31, 2026 and 2025 totaled $5.1 million and $1.8 million, respectively, including $1.2 million and $0.5 million, respectively, from the amortization of debt issuance costs. Interest expense for the nine months ended March 31, 2026 and 2025 totaled $15.3 million and $1.8 million, respectively, including $3.5 million and $0.5 million, respectively, from the amortization of debt issuance costs.

[0001375365-26-000014:notes:155]
2030 Convertible Notes

[0001375365-26-000014:notes:156]
On June 23, 2025, we issued $2,300 million aggregate principal amount of 2030 Convertible Notes, including the $300.0 million overallotment option. Net proceeds were approximately $2,256.0 million after issuance costs.

[0001375365-26-000014:notes:157]
The 2030 Convertible Notes are convertible at an initial rate of 18.1154 shares per $1,000 principal amount, equivalent to a conversion price of approximately $55.20 per share. Conversion prior to December 17, 2029 is permitted only if specified conditions are met (similar to those of the 2028 Convertible Notes and the 2029 Convertible Notes). After that date, the notes become convertible at any time up to two trading days before maturity.

[0001375365-26-000014:notes:158]
Holders may convert their 2030 Convertible Notes upon the occurrence of certain conditions, including: (1) during any calendar quarter commencing after the calendar quarter ending on September 30, 2025, if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon certain corporate events or distributions on our common stock, as described in the Indenture; (4) if we call the notes for redemption; or (5) at any time from and after December 17, 2029 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, beginning June 15, 2028 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-26-000014:notes:159]
As of March 31, 2026 and June 30, 2025, unamortized issuance costs are $37.3 million and $43.9 million, respectively. Interest expense for the three and nine months ended March 31, 2026 totaled $2.2 million and $6.6 million, respectively, all of which are amortization of debt issuance costs.

[0001375365-26-000014:notes:160]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date. These instruments are equity-classified under ASC 815-40.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-26-000014:notes:161]
Note 10.                 Leases

[0001375365-26-000014:notes:162]
We lease offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2026 and 2025 were as follows (in thousands):

[0001375365-26-000014:notes:163]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Operating lease expense (including expense for lease agreements with related parties of $292 and $208 for the three months ended March 31, 2026 and 2025, respectively, and $758 and $538 for the nine months ended March 31, 2026 and 2025, respectively) | $ | 15,098 |  |  | $ | 5,712 |  |  | $ | 43,117 |  |  | $ | 12,685 |  |
| Cash payments for operating leases (including payments to related parties of $297 and $202 for the three months ended March 31, 2026 and 2025, respectively, and $788 and $508 for the nine months ended March 31, 2026 and 2025, respectively) | $ | 13,663 |  |  | $ | 5,380 |  |  | $ | 36,012 |  |  | $ | 11,959 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 834 |  |  | $ | 110,145 |  |  | $ | 94,907 |  |  | $ | 128,617 |  |

[0001375365-26-000014:notes:164]
During the three and nine months ended March 31, 2026 and 2025, our costs related to short-term lease arrangements were immaterial. Variable lease payments expensed in the three and nine months ended March 31, 2026 and 2025 were immaterial.

[0001375365-26-000014:notes:165]
[same as prior period, unchanged from 0001375365-26-000007:notes:150]

[0001375365-26-000014:notes:166]
|  | March 31, 2026 |  | June 30, 2025 |
| Other assets | $ | 361,437 |  |  | $ | 293,692 |  |
| Accrued liabilities | $ | 32,703 |  |  | $ | 21,189 |  |
| Other long-term liabilities | 345,352 |  |  | 280,368 |  |
| Total lease liabilities | $ | 378,055 |  |  | $ | 301,557 |  |
| Weighted average remaining lease term | 8.6 years |  | 9.1 years |
| Weighted average discount rate (1) | 5.8 | % |  | 5.8 | % |

[0001375365-26-000014:notes:167]
[same as prior period, unchanged from 0001375365-26-000007:notes:152]

[0001375365-26-000014:notes:168]
In June 2024, we entered into a lease agreement for a 21 megawatt (“MW”) data center co-location space located in Vernon, California (the “Data Center Space”) that will expire on September 30, 2035. We do not have an option to extend (or to terminate) the lease. The lease agreement consists of three tranches, with the first tranche of 6 MW having commenced on January 24, 2025, the second tranche of 9 MW commenced on May 12, 2025, and the third tranche of 6 MW commenced on August 15, 2025. As of March 31, 2026, the ROU assets and lease liabilities related to all three tranches totaled $284.0 million and $294.9 million, respectively. Variable lease payments not dependent on a rate or index associated with our leases are recognized when the event, activity, or circumstance in the lease agreement on which those payments are assessed as probable. Variable lease payments are presented as operating expenses in the condensed consolidated statements of operations.

[0001375365-26-000014:notes:169]
Simultaneously, we entered into a Sublicense agreement, the term of which coincides with our Data Center Space lease. We accounted for the lease as an operating lease and the Sublicense as a sublease under Accounting Standards Codification Topic 842, Leases. The Sublicense did not relieve our original obligation under the Data Center Space lease, and therefore we did not adjust the operating lease ROU asset and related liability. Sublicense income is recognized on a straight-line basis and the rental income is included in other income (expense), net on the condensed consolidated statements of operations.

[0001375365-26-000014:notes:170]
Rental income is included in other income (expense), net on the condensed consolidated statements of operations (in thousands):

[0001375365-26-000014:notes:171]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Sublease income | $ | 10,524 |  |  | $ | 1,300 |  |  | $ | 29,181 |  |  | $ | 1,300 |  |

[0001375365-26-000014:notes:172]
As of March 31, 2026, the future total minimum Sublicense receipts expected to be received are as follows (in thousands):

[0001375365-26-000014:notes:173]
| Fiscal Year: |  | Future minimum Sublicense receipts |
| Remainder of 2026 |  | $ | 9,492 |  |
| 2027 |  | 38,348 |  |
| 2028 |  | 39,499 |  |
| 2029 |  | 40,684 |  |
| 2030 |  | 41,904 |  |
| 2031 and beyond |  | 241,533 |  |
| Total Sublicense receipts - Lessor |  | $ | 411,460 |  |

[0001375365-26-000014:notes:174]
Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of March 31, 2026 are as follows (in thousands):

[0001375365-26-000014:notes:175]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2026 |  | $ | 14,123 |  |
| 2027 |  | 55,980 |  |
| 2028 |  | 55,498 |  |
| 2029 |  | 55,890 |  |
| 2030 |  | 57,437 |  |
| 2031 and beyond |  | 251,685 |  |
| Total future lease payments |  | 490,613 |  |
| Less: Imputed interest |  | (112,558) |  |
| Present value of operating lease liabilities |  | $ | 378,055 |  |
| Current portion |  | $ | 32,703 |  |
| Long-term portion |  | $ | 345,352 |  |

[0001375365-26-000014:notes:176]
Related party leases

[0001375365-26-000014:notes:177]
We have entered into lease agreements with related parties. See Note 11, “Related Party Transactions” for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-26-000014:notes:178]
Note 11.               Related Party Transactions

[0001375365-26-000014:notes:179]
We have a variety of business relationships with Ablecom Technology Inc (“Ablecom”) and Compuware Technology Inc (“Compuware”), both of which are Taiwan-based corporations. Ablecom is a major contract manufacturer for us and its Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of March 31, 2026, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2026. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the board of directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s board of directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s board of directors and is an equity holder of Compuware. Compuware is also a major contract manufacturer for us and a distributor of our products in limited geographic regions. Neither Charles Liang nor Sara Liu own any capital stock of Compuware.

[0001375365-26-000014:notes:180]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of March 31, 2026 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was $0.0 million and approximately $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid in full.

[0001375365-26-000014:notes:181]
Dealings with Ablecom

[0001375365-26-000014:notes:182]
We have entered into a series of agreements with Ablecom, including, but not limited to, multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-26-000014:notes:183]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 94.0% and 95.0% of the chassis purchased by us during the three months ended March 31, 2026 and 2025, respectively, and 95.5% and 95.2% of the chassis purchased by us during the nine months ended March 31, 2026 and 2025, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-26-000014:notes:184]
During the third quarter ended March 31, 2026, we entered into an arrangement for Ablecom to resell certain products, to an end customer in Japan. The transaction was entered into in the ordinary course of business, and the related terms and conditions were consistent with those negotiated with other third-party resellers for similar transactions.

[0001375365-26-000014:notes:185]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and we provide certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to us. For the components purchased from us, Ablecom sells the components back to us at a price equal to the price at which we sold the components to Ablecom. There is no revenue recognized by us from these transactions. We and Ablecom frequently review and negotiate the prices of the chassis we purchase from Ablecom. In addition to inventory purchases, we also incur other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-26-000014:notes:186]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on March 31, 2026 and June 30, 2025 were $49.3 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-26-000014:notes:187]
Dealings with Compuware

[0001375365-26-000014:notes:188]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, Australia, Malaysia, and U.S. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

[0001375365-26-000014:notes:189]
We have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We extended a $200.0 million trade credit line on November 19, 2025, with a net 90 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-26-000014:notes:190]
Under these agreements, we outsource a portion of our design activities, a significant part of our power supplies manufacturing and an immaterial portion of other components to Compuware. Compuware manufactured approximately 92.4% and 93.7% of the power supplies purchased by us during the three months ended March 31, 2026 and 2025, respectively, and 94.0% and 94.8% of the power supplies purchased by us during the nine months ended March 31, 2026 and 2025, respectively. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to our specifications and further agree to build the tools needed to manufacture the products. We pay Compuware for the design and engineering services and further agrees to pay Compuware for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from third parties and uses these materials to manufacture the products and then sell those products to us. We and Compuware frequently review and negotiate the prices of the power supplies we purchase from Compuware.

[0001375365-26-000014:notes:191]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for us. We sell to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to us at a purchase price equal to the price at which we sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by us from these transactions. We and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products we purchase from Compuware. In addition to the inventory purchases, we also incur costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-26-000014:notes:192]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on March 31, 2026 and June 30, 2025 were $179.3 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-26-000014:notes:193]
Dealings with Leadtek Research Inc.

[0001375365-26-000014:notes:194]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). As of December 31, 2025, this interest came down to approximately 29%. Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. We engaged in transactions whereby we sold servers worth $0.4 million and $0.2 million to Leadtek during the three months ended March 31, 2026 and 2025, respectively, and $1.2 million and $0.5 million to Leadtek during the nine months ended March 31, 2026 and 2025, respectively. We did not purchase any graphic cards from Leadtek during the three months ended March 31, 2026 and 2025, respectively. We purchased graphic cards worth $0.0 million and $0.5 million from Leadtek during the nine months ended March 31, 2026 and 2025, respectively.

[0001375365-26-000014:notes:195]
Dealings with Investment in a Corporate Venture

[0001375365-26-000014:notes:196]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture was 30% owned by us and 70% owned by another company in China. The agreement was signed in the third quarter of the fiscal year ended June 30, 2017, and the investment was accounted for using the equity method of accounting. The Corporate Venture was also a related party.

[0001375365-26-000014:notes:197]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025. On November 25, 2025, the Equity Transfer Agreement was signed, and the divestiture of our 30% interest was completed on December 23, 2025, and the Corporate Venture ceased to be a related party as of December 23, 2025.

[0001375365-26-000014:notes:198]
We sold products worth $4.2 million to the Corporate Venture during the three months ended March 31, 2025, and $8.1 million and $9.0 million to the Corporate Venture during the nine months ended March 31, 2026 and 2025, respectively. Our share of intra-entity profits on the products that remained unsold by the Corporate Venture had been eliminated and reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off as of December 31, 2025. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $0.0 million and less than $0.1 million receivables due from the Corporate Venture in accounts receivable, net as of March 31, 2026 and June 30, 2025, respectively.

[0001375365-26-000014:notes:199]
Other transactions

[0001375365-26-000014:notes:200]
For the three months ended March 31, 2026, we had no sales to and immaterial purchases from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. For the three months ended March 31, 2025, we had no transactions from Green Earth Liang’s Inc. For the nine months ended March 31, 2026, we had no sales to and immaterial purchases from Green Earth Liang’s Inc. For the nine months ended March 31, 2025, we had immaterial expense reimbursement from Green Earth Liang's Inc. As of March 31, 2026 and June 30, 2025, there was no amount due to and from Green Earth.

[0001375365-26-000014:notes:201]
We had the following balances related to transactions with our related parties as of March 31, 2026 and June 30, 2025 (in thousands):

[0001375365-26-000014:notes:202]
|  | Accounts receivable |  | Other receivables (1) |  | Other assets |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| As of March 31, 2026 | $ | 1 |  |  | $ | 1,344 |  |  | $ | 59 |  |  | $ | 88,323 |  |  | $ | 689 |  |  | $ | 251 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| As of March 31, 2026 | $ | 430 |  |  | $ | 27,370 |  |  | $ | — |  |  | $ | 45,729 |  |  | $ | 641 |  |  | $ | 243 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | — |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| As of March 31, 2026 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| As of March 31, 2026 | $ | 202 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| As of March 31, 2026 | $ | 633 |  |  | $ | 28,714 |  |  | $ | 59 |  |  | $ | 134,052 |  |  | $ | 1,330 |  |  | $ | 494 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | — |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

[0001375365-26-000014:notes:203]
(1) Other receivables include receivables from vendors included in prepaid expenses and other current assets.

[0001375365-26-000014:notes:204]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-26-000014:notes:205]
(3) Other long-term liabilities include non-current portion of lease liabilities.

[0001375365-26-000014:notes:206]
Our results from transactions with our related parties for each of the three months ended March 31, 2026 and 2025, are as follows (in thousands):

[0001375365-26-000014:notes:207]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | 315 |  |  | $ | 126,145 |  |  | $ | 4,444 |  |  | $ | 1,754 |  |  | $ | — |  |  |  |
| Three months ended March 31, 2025 | $ | 3 |  |  | $ | 50,147 |  |  | $ | 7,777 |  |  | $ | 971 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | 4,181 |  |  | $ | 76,695 |  |  | $ | 6 |  |  | $ | 445 |  |  | $ | 1,104 |  |  |  |
| Three months ended March 31, 2025 | $ | 3,278 |  |  | $ | 65,372 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended March 31, 2025 | $ | 4,201 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | 383 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended March 31, 2025 | $ | 165 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |  |  |
| Three months ended March 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended March 31, 2026 | $ | 4,879 |  |  | $ | 202,840 |  |  | $ | 4,450 |  |  | $ | 2,199 |  |  | $ | 1,119 |  |  |  |
| Three months ended March 31, 2025 | $ | 7,647 |  |  | $ | 115,519 |  |  | $ | 7,777 |  |  | $ | 1,431 |  |  | $ | — |  |  |  |

[0001375365-26-000014:notes:208]
Our results from transactions with our related parties for each of the nine months ended March 31, 2026 and 2025, are as follows (in thousands):

[0001375365-26-000014:notes:209]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 403 |  |  | $ | 307,907 |  |  | $ | 7,923 |  |  | $ | 4,161 |  |  | $ | — |  |  |  |
| Nine months ended March 31, 2025 | $ | 10 |  |  | $ | 252,426 |  |  | $ | 14,908 |  |  | $ | 3,958 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 14,184 |  |  | $ | 242,055 |  |  | $ | 155 |  |  | $ | 1,138 |  |  | $ | 1,739 |  |  |  |
| Nine months ended March 31, 2025 | $ | 24,318 |  |  | $ | 238,720 |  |  | $ | 371 |  |  | $ | 1,120 |  |  | $ | — |  |  |  |
| Corporate Venture* |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 8,147 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Nine months ended March 31, 2025 | $ | 8,977 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 1,206 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Nine months ended March 31, 2025 | $ | 494 |  |  | $ | 534 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 76 |  |  |  |
| Nine months ended March 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (6) |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 23,940 |  |  | $ | 549,962 |  |  | $ | 8,078 |  |  | $ | 5,299 |  |  | $ | 1,815 |  |  |  |
| Nine months ended March 31, 2025 | $ | 33,799 |  |  | $ | 491,680 |  |  | $ | 15,279 |  |  | $ | 5,078 |  |  | $ | (6) |  |  |  |

[0001375365-26-000014:notes:210]
*The divestiture of our 30% interest was completed on December 23, 2025, after which the Corporate Venture ceased to be a related party. Accordingly, this disclosure covers only the six months ended December 31, 2025.

[0001375365-26-000014:notes:211]
Our cash flow impact from transactions with our related parties for each of the nine months ended March 31, 2026 and 2025, are as follows (in thousands):

[0001375365-26-000014:notes:212]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | — |  |  | $ | (344) |  |  | $ | 32,863 |  |  | $ | (64) |  |  | $ | 137 |  |  | $ | 9,217 |  |  | $ | 2,584 |  |
| Nine months ended March 31, 2025 | $ | — |  |  | $ | 577 |  |  | $ | (48,270) |  |  | $ | 487 |  |  | $ | 227 |  |  | $ | 10,137 |  |  | $ | 7,111 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | (145) |  |  | $ | (14,684) |  |  | $ | (28,563) |  |  | $ | 350 |  |  | $ | (251) |  |  | $ | 149 |  |  | $ | 7 |  |
| Nine months ended March 31, 2025 | $ | 48 |  |  | $ | (3,359) |  |  | $ | (1,491) |  |  | $ | 84 |  |  | $ | 502 |  |  | $ | 371 |  |  | $ | — |  |
| Corporate Venture* |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Nine months ended March 31, 2025 | $ | 4,990 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | (125) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Nine months ended March 31, 2025 | $ | 840 |  |  | $ | — |  |  | $ | (230) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nine months ended March 31, 2026 | $ | (240) |  |  | $ | (15,028) |  |  | $ | 4,300 |  |  | $ | 286 |  |  | $ | (114) |  |  | $ | 9,366 |  |  | $ | 2,591 |  |
| Nine months ended March 31, 2025 | $ | 5,878 |  |  | $ | (2,782) |  |  | $ | (49,991) |  |  | $ | 571 |  |  | $ | 729 |  |  | $ | 10,508 |  |  | $ | 7,111 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-26-000014:notes:213]
Note 12.               Stock-based Compensation and Stockholders’ Equity

[0001375365-26-000014:notes:214]
[same as prior period, unchanged from 0001375365-26-000007:notes:197]

[0001375365-26-000014:notes:215]
We have 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by our board of directors at the time of issuance of such shares. As of March 31, 2026 and June 30, 2025, there were no shares of preferred stock issued and outstanding.

[0001375365-26-000014:notes:216]
[same as prior period, unchanged from 0001375365-26-000007:notes:199]

[0001375365-26-000014:notes:217]
[same as prior period, unchanged from 0001375365-26-000007:notes:200]

[0001375365-26-000014:notes:218]
[same as prior period, unchanged from 0001375365-26-000007:notes:201]

[0001375365-26-000014:notes:219]
[same as prior period, unchanged from 0001375365-26-000007:notes:202]

[0001375365-26-000014:notes:220]
As of March 31, 2026, we had 7,654,346 authorized shares available for future issuance under the 2020 Plan.

[0001375365-26-000014:notes:221]
[same as prior period, unchanged from 0001375365-26-000007:notes:204]

[0001375365-26-000014:notes:222]
[same as prior period, unchanged from 0001375365-26-000007:notes:205]

[0001375365-26-000014:notes:223]
The weighted-average estimated fair value of employee stock options granted during the three and nine months ended March 31, 2026 was $21.70 and $33.98 per share, respectively, and three and nine months ended March 31, 2025 was $18.97 and $26.03, respectively, using the below assumptions.

[0001375365-26-000014:notes:224]
The fair value of stock option grants for the three and nine months ended March 31, 2026 and 2025 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-26-000014:notes:225]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Risk-free interest rate | 3.92% |  | 4.05% - 4.39% |  | 3.68% - 4.00% |  | 3.82% - 4.39% |
| Expected term | 5.96 years |  | 3.00 years - 5.98 years |  | 3.44 years - 5.96 years |  | 3.00 years - 5.98 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 77.64% |  | 73.06% - 95.28% |  | 76.16% - 92.16% |  | 63.67% - 95.28% |

[0001375365-26-000014:notes:226]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2026 and 2025 (in thousands):

[0001375365-26-000014:notes:227]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cost of sales | $ | 11,522 |  |  | $ | 7,060 |  |  | $ | 25,400 |  |  | $ | 17,713 |  |
| Research and development | 83,115 |  |  | 54,254 |  |  | 200,090 |  |  | 141,590 |  |
| Sales and marketing | 12,276 |  |  | 9,923 |  |  | 33,700 |  |  | 27,245 |  |
| General and administrative | 19,021 |  |  | 13,467 |  |  | 46,368 |  |  | 44,292 |  |
| Stock-based compensation expense before taxes | 125,934 |  |  | 84,704 |  |  | 305,558 |  |  | 230,840 |  |
| Income tax impact | (28,713) |  |  | (22,433) |  |  | (70,373) |  |  | (57,442) |  |
| Stock-based compensation expense, net | $ | 97,221 |  |  | $ | 62,271 |  |  | $ | 235,185 |  |  | $ | 173,398 |  |

[0001375365-26-000014:notes:228]
During the three and nine months ended March 31, 2026, there was no stock-based compensation expense capitalized to our condensed consolidated balance sheets. During the three and nine months ended March 31, 2025, stock-based compensation expense capitalized to our condensed consolidated balance sheets was $0.2 million and $0.5 million, respectively.

[0001375365-26-000014:notes:229]
[same as prior period, unchanged from 0001375365-26-000007:notes:212]

[0001375365-26-000014:notes:230]
[same as prior period, unchanged from 0001375365-26-000007:notes:213]

[0001375365-26-000014:notes:231]
[same as prior period, unchanged from 0001375365-26-000007:notes:214]

[0001375365-26-000014:notes:232]
The achievement status of the operational and stock price milestones as of March 31, 2026 was as follows:

[0001375365-26-000014:notes:233]
[same as prior period, unchanged from 0001375365-26-000007:notes:216]

[0001375365-26-000014:notes:234]
[same as prior period, unchanged from 0001375365-26-000007:notes:217]

[0001375365-26-000014:notes:235]
[same as prior period, unchanged from 0001375365-26-000007:notes:218]

[0001375365-26-000014:notes:236]
[same as prior period, unchanged from 0001375365-26-000007:notes:219]

[0001375365-26-000014:notes:237]
[same as prior period, unchanged from 0001375365-26-000007:notes:220]

[0001375365-26-000014:notes:238]
[same as prior period, unchanged from 0001375365-26-000007:notes:221]

[0001375365-26-000014:notes:239]
[same as prior period, unchanged from 0001375365-26-000007:notes:222]

[0001375365-26-000014:notes:240]
[same as prior period, unchanged from 0001375365-26-000007:notes:223]

[0001375365-26-000014:notes:241]
[same as prior period, unchanged from 0001375365-26-000007:notes:224]

[0001375365-26-000014:notes:242]
[same as prior period, unchanged from 0001375365-26-000007:notes:225]

[0001375365-26-000014:notes:243]
[same as prior period, unchanged from 0001375365-26-000007:notes:226]

[0001375365-26-000014:notes:244]
During the three and nine months ended March 31, 2026, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $0.9 million and $2.9 million, respectively. During the three and nine months ended March 31, 2025, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $0.9 million and $12.4 million, respectively. As of March 31, 2026, we had $2.6 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2026 is expected to be recognized over a period of 0.75 years.

[0001375365-26-000014:notes:245]
The following table summarizes stock option activity (including CEO Performance Stock Options) during the nine months ended March 31, 2026 under all plans:

[0001375365-26-000014:notes:246]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm (in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2025 |  | 34,848,133 |  |  | $ | 22.47 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Granted |  | 3,178,597 |  |  | $ | 49.37 |  |  | $ | 33.98 |  |  | — |  |  | $ | — |  |
| Exercised |  | (1,630,182) |  |  | $ | 8.17 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Forfeited/Cancelled |  | (975,634) |  |  | $ | 37.45 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balance as of March 31, 2026 |  | 35,420,914 |  |  | $ | 25.13 |  |  | $ | — |  |  | 6.49 |  | $ | 322,574 |  |
| Options exercisable at March 31, 2026 |  | 24,885,340 |  |  | $ | 17.48 |  |  | $ | — |  |  | 5.63 |  | $ | 309,416 |  |

[0001375365-26-000014:notes:247]
The total pretax intrinsic value of options exercised during the three and nine months ended March 31, 2026 was $10.8 million and $50.5 million, respectively. The total pretax intrinsic value of options exercised during the three and nine months ended March 31, 2025 was $46.8 million and $162.6 million, respectively.

[0001375365-26-000014:notes:248]
As of March 31, 2026, $237.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.59 years.

[0001375365-26-000014:notes:249]
[same as prior period, unchanged from 0001375365-26-000007:notes:232]

[0001375365-26-000014:notes:250]
The following table summarizes RSU activity during the nine months ended March 31, 2026 under all plans:

[0001375365-26-000014:notes:251]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2025 | 20,428,647 |  |  | $ | 34.22 |  |
| Granted | 8,120,018 |  |  | $ | 45.07 |  |
| Released | (8,117,534) |  |  | $ | 28.50 |  |
| Forfeited | (1,402,029) |  |  | $ | 40.15 |  |
| Balance as of March 31, 2026 | 19,029,102 |  |  | $ | 40.85 |  |

[0001375365-26-000014:notes:252]
As of March 31, 2026, $689.4 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.48 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-26-000014:notes:253]
Note 13.               Income Taxes

[0001375365-26-000014:notes:254]
We recorded a provision for income taxes of $126.9 million and $266.2 million for the three and nine months ended March 31, 2026, respectively, and provision of $5.8 million and $137.5 million for the three and nine months ended March 31, 2025, respectively. The effective tax rate was 20.8% and 20.2% for the three and nine months ended March 31, 2026, respectively, and 5.1% and 13.9% for the three and nine months ended March 31, 2025, respectively. The effective tax rates for the three and nine months ended March 31, 2026, were higher than that for the three and nine months ended March 31, 2025, primarily due to the significant decrease in tax deductions related to stock-based compensation and U.S. federal research tax credit, driven by a lower stock vesting price in the three and nine months ended March 31, 2026. The effective tax rates for the three and nine months ended March 31, 2026 were lower than the U.S. federal statutory rate of 21%, primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit.

[0001375365-26-000014:notes:255]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law and contains several changes to key U.S. federal income tax laws, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027. As of March 31, 2026, we have recognized the tax effects of certain OBBBA provisions. We will continue to evaluate the impact of the Act upon our future effective tax rate, tax liabilities, and cash taxes.

[0001375365-26-000014:notes:256]
[same as prior period, unchanged from 0001375365-26-000007:notes:239]

[0001375365-26-000014:notes:257]
In general, the federal statute of limitations remains open for tax years ended June 30, 2023 through 2025. Various states’ statutes of limitations remain open in general for tax years ended June 30, 2022 through 2025. Certain statutes of limitations in major foreign jurisdictions remain open for the tax years ended June 30, 2020 through 2025. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.1 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits. As of March 31, 2026, we are under examination in certain tax jurisdictions, including the United States for fiscal year ended June 30, 2024, and India for tax years ended in 2024 and 2025.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-26-000014:notes:258]
Note 14.               Commitments and Contingencies

[0001375365-26-000014:notes:259]
Litigation and claims

[0001375365-26-000014:notes:260]
On August 30, 2024, a putative class action complaint was filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147). Additional putative class action complaints were filed in the same court on October 4, 2024 (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980); on October 18, 2024 (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274); and on March 25, 2026 (Bhuva v. Super Micro Computer, Inc. et al, No. 3:26-cv-02606). Another such complaint was filed on April 8, 2026 (City of Hialeah Employees Retirement System v. Super Micro Computer, Inc. et al, No. 5:26-cv-03018), which included a former director of the company as an additional defendant. The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Court then appointed Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint on September 22, 2025. The appointment of Lead Plaintiff has been appealed to the Supreme Court of California. Company filed its Motion to Dismiss on November 21, 2025. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-26-000014:notes:261]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. The Court in the Hollin Action consolidated the five previously stayed Federal Derivative Litigation actions. The Court in the Spatz Action stayed all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery, captioned Anderson v. Liang, et al., C.A. No. 2025-0986-KSJM. On January 6, 2026, a substantially similar lawsuit was filed in the Delaware Court of Chancery, captioned Mathiyalagan v. Liang, et. al., C.A. No. 2026-0013-KSJM. On January 29, 2026, another substantially similar lawsuit was filed in Northern District of California by plaintiffs Employees’ Retirement System of the State of Rhode Island and Bucks County Employees’ Retirement System, Case No. 5:26-cv-00955-NC. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-26-000014:notes:262]
On November 19, 2024, the Company received a subpoena from the U.S. Securities and Exchange Commission Enforcement Staff in connection with an investigation entitled In the Matter of Super Micro Computer, Inc. The Company continues to produce documents in response to the subpoena. The Company received another subpoena on April 28, 2026. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-26-000014:notes:263]
Other legal proceedings and indemnifications

[0001375365-26-000014:notes:264]
In the ordinary course of our business, we periodically receive subpoenas, civil investigative demands, and other formal requests for information from various courts, regulatory bodies, and government agencies. These requests typically seek documents or information related to our customers, products, or transactions in connection with matters that do not directly name or involve us as a party or target. Our general policy is to cooperate and respond fully to such requests as required by law. We are not aware of any such matters that, individually or in the aggregate, are expected to have a material adverse effect on the Company’s financial position.

[0001375365-26-000014:notes:265]
We have entered into indemnification agreements with our current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce our exposure to such obligations.

[0001375365-26-000014:notes:266]
Other matters

[0001375365-26-000014:notes:267]
As a result of a Supreme Court ruling issued in February 2026, we may be entitled to a refund of tariffs previously paid on imported products under the IEEPA. As of March 31, 2026, we have not recognized an asset related to the potential refund. We will continue to evaluate new information and will recognize the refund when the right to receive the amount becomes realized or realizable.

[0001375365-26-000014:notes:268]
On April 7, 2026, the Company announced that it had launched an independent investigation into the allegations described in the March 19, 2026, indictment from the U.S. Attorney’s Office for the Southern District of New York concerning three individuals either employed or associated with the Company at the time in connection with an alleged conspiracy to commit export control violations. The independent investigation is being led by the Lead Independent Director of the Company’s Board and the Chair of the Board’s Audit Committee, who will report their findings and conclusions to the other four independent members of the Board.  The investigations are ongoing and no conclusion has been reached.

[0001375365-26-000014:notes:269]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2026, these remaining non-cancelable commitments were $10.1 billion, including $228.6 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell but have committed purchases from suppliers. As of March 31, 2026, we recorded $4.1 million of loss liabilities. The loss liabilities are recorded in accrued liabilities in our condensed consolidated balance sheets. There were no loss liabilities recognized as of June 30, 2025.

[0001375365-26-000014:notes:270]
Lease Commitments— See Note 10, “Leases”, for a discussion of our operating lease commitments.
