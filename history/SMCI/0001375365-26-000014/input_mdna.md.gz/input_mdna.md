# SMCI MD&A — 0001375365-26-000014


## mdna

[0001375365-26-000014:mdna:1]
[same as prior period, unchanged from 0001375365-26-000007:mdna:1]

[0001375365-26-000014:mdna:2]
[same as prior period, unchanged from 0001375365-26-000007:mdna:2]

[0001375365-26-000014:mdna:3]
[same as prior period, unchanged from 0001375365-26-000007:mdna:3]

[0001375365-26-000014:mdna:4]
[same as prior period, unchanged from 0001375365-26-000007:mdna:4]

[0001375365-26-000014:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. For the three months ended March 31, 2026 and 2025, our net income was $483.4 million and $108.8 million, respectively. For the nine months ended March 31, 2026 and 2025, our net income was $1,052.2 million and $853.7 million, respectively.

[0001375365-26-000014:mdna:6]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offerings and enhance customer service and support, particularly as we increase our focus on large enterprise and data center customers. A key component of our strategy is our Data Center Building Block Solutions (“DCBBS”), which significantly reduces data center build time and enables full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services, and ongoing maintenance. To further expand our market share, we intend to strengthen our network of sales partners and distribution channels.

[0001375365-26-000014:mdna:7]
[same as prior period, unchanged from 0001375365-26-000007:mdna:7]

[0001375365-26-000014:mdna:8]
SMCI | Q3 2026 Form 10-Q | 41

[0001375365-26-000014:mdna:9]
[same as prior period, unchanged from 0001375365-26-000007:mdna:9]

[0001375365-26-000014:mdna:10]
The growing use of AI, which requires enhanced data center capabilities, has substantially increased demand for our products. We expect this trend to continue, with further demand for data center expansion driven by the AI market. As a result, we will continue to enhance our product capabilities and expand our service offerings, including DCBBS to address the growing demand in the AI market and data center markets. We believe that our ability to tailor certain products to the unique needs of these sectors sets us apart from many competitors and positions us to capture an even greater market share going forward.

[0001375365-26-000014:mdna:11]
[same as prior period, unchanged from 0001375365-26-000007:mdna:11]

[0001375365-26-000014:mdna:12]
[same as prior period, unchanged from 0001375365-26-000007:mdna:12]

[0001375365-26-000014:mdna:13]
[same as prior period, unchanged from 0001375365-26-000007:mdna:13]

[0001375365-26-000014:mdna:14]
The following is a summary of our financial highlights for the three months ended March 31, 2026 and 2025:

[0001375365-26-000014:mdna:15]
|  |  | Three Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Net sales |  | $ | 10,243,014 |  |  | $ | 4,599,913 |  |
| Gross profit |  | $ | 1,018,680 |  |  | $ | 440,218 |  |
| Total operating expenses |  | $ | 392,812 |  |  | $ | 293,438 |  |
| Income from operations |  | $ | 625,868 |  |  | $ | 146,780 |  |
| Net income |  | $ | 483,387 |  |  | $ | 108,777 |  |
| Net income per diluted share |  | $ | 0.72 |  |  | $ | 0.17 |  |

[0001375365-26-000014:mdna:16]
•Net sales increased by 122.7% in the three months ended March 31, 2026, as compared to the three months ended March 31, 2025, primarily driven by fulfillment and shipment of orders to support our customers' data center deployment, including large design wins from a few customers, during the second and third quarters of fiscal 2026. An increase in our average selling price also contributed modestly by product mix.

[0001375365-26-000014:mdna:17]
•Gross margin remained relatively flat in the three months ended March 31, 2026, as compared to the three months ended March 31, 2025.

[0001375365-26-000014:mdna:18]
•Operating expenses increased by 33.9% in the three months ended March 31, 2026, as compared to the three months ended March 31, 2025, primarily due to higher headcount and increases in salary and stock-based compensation.

[0001375365-26-000014:mdna:19]
•Net income increased to $483.4 million in the three months ended March 31, 2026, as compared to $108.8 million in the three months ended March 31, 2025, which was primarily due to a higher increase in net sales.

[0001375365-26-000014:mdna:20]
SMCI | Q3 2026 Form 10-Q | 42

[0001375365-26-000014:mdna:21]
[same as prior period, unchanged from 0001375365-26-000007:mdna:21]

[0001375365-26-000014:mdna:22]
[same as prior period, unchanged from 0001375365-26-000007:mdna:22]

[0001375365-26-000014:mdna:23]
[same as prior period, unchanged from 0001375365-26-000007:mdna:23]

[0001375365-26-000014:mdna:24]
[same as prior period, unchanged from 0001375365-26-000007:mdna:24]

[0001375365-26-000014:mdna:25]
[same as prior period, unchanged from 0001375365-26-000007:mdna:25]

[0001375365-26-000014:mdna:26]
[same as prior period, unchanged from 0001375365-26-000007:mdna:26]

[0001375365-26-000014:mdna:27]
[same as prior period, unchanged from 0001375365-26-000007:mdna:27]

[0001375365-26-000014:mdna:28]
[same as prior period, unchanged from 0001375365-26-000007:mdna:28]

[0001375365-26-000014:mdna:29]
[same as prior period, unchanged from 0001375365-26-000007:mdna:57]

[0001375365-26-000014:mdna:30]
[same as prior period, unchanged from 0001375365-26-000007:mdna:30]

[0001375365-26-000014:mdna:31]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 2.2% and 2.1% of cost of sales on our condensed consolidated statements of operations for the three and nine months ended March 31, 2026, respectively, and 2.8% and 3.4% of cost of sales on our condensed consolidated statements of operations for the three and nine months ended March 31, 2025, respectively. For further details on our dealings with related parties, see Note 11, “Related Party Transactions” in the notes to the condensed consolidated financial statements.

[0001375365-26-000014:mdna:32]
SMCI | Q3 2026 Form 10-Q | 43

[0001375365-26-000014:mdna:33]
[same as prior period, unchanged from 0001375365-26-000007:mdna:33]

[0001375365-26-000014:mdna:34]
[same as prior period, unchanged from 0001375365-26-000007:mdna:34]

[0001375365-26-000014:mdna:35]
[same as prior period, unchanged from 0001375365-26-000007:mdna:35]

[0001375365-26-000014:mdna:36]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation, commissions and incentive bonuses, and related expenses for our sales and marketing personnel, cost for trade shows, sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses.

[0001375365-26-000014:mdna:37]
[same as prior period, unchanged from 0001375365-26-000007:mdna:37]

[0001375365-26-000014:mdna:38]
[same as prior period, unchanged from 0001375365-26-000007:mdna:38]

[0001375365-26-000014:mdna:39]
Other Income (Expense), Net, Interest Income, and Interest Expense

[0001375365-26-000014:mdna:40]
Other income (expense), net, interest income, and interest expense consists primarily of interest earned on our investments and cash balances, interest incurred on our debt, and foreign exchange gains and losses.

[0001375365-26-000014:mdna:41]
[same as prior period, unchanged from 0001375365-26-000007:mdna:41]

[0001375365-26-000014:mdna:42]
[same as prior period, unchanged from 0001375365-26-000007:mdna:42]

[0001375365-26-000014:mdna:43]
SMCI | Q3 2026 Form 10-Q | 44

[0001375365-26-000014:mdna:44]
The following table presents certain items of our condensed consolidated statements of operations for the three and nine months ended March 31, 2026 and 2025 (in millions):

[0001375365-26-000014:mdna:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net sales | $ | 10,243.0 |  |  | $ | 4,599.9 |  |  | $ | 27,943.3 |  |  | $ | 16,215.1 |  |
| Cost of sales | 9,224.3 |  |  | 4,159.7 |  |  | 25,658.7 |  |  | 14,329.3 |  |
| Gross profit | 1,018.7 |  |  | 440.2 |  |  | 2,284.6 |  |  | 1,885.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 215.7 |  |  | 162.9 |  |  | 569.7 |  |  | 453.3 |  |
| Sales and marketing | 89.5 |  |  | 60.0 |  |  | 210.5 |  |  | 208.4 |  |
| General and administrative | 87.6 |  |  | 70.5 |  |  | 222.0 |  |  | 199.5 |  |
| Total operating expenses | 392.8 |  |  | 293.4 |  |  | 1,002.2 |  |  | 861.2 |  |
| Income from operations | 625.9 |  |  | 146.8 |  |  | 1,282.4 |  |  | 1,024.6 |  |
| Other income (expense), net | 4.2 |  |  | (33.0) |  |  | 4.3 |  |  | (29.5) |  |
| Interest income | 45.4 |  |  | 14.7 |  |  | 147.8 |  |  | 31.4 |  |
| Interest expense | (64.5) |  |  | (13.4) |  |  | (114.8) |  |  | (37.3) |  |
| Income before income tax provision | 611.0 |  |  | 115.1 |  |  | 1,319.7 |  |  | 989.2 |  |
| Income tax provision | (126.9) |  |  | (5.8) |  |  | (266.2) |  |  | (137.5) |  |
| Share of (loss) income from equity investee, net of taxes | (0.7) |  |  | (0.5) |  |  | (1.3) |  |  | 2.0 |  |
| Net income | $ | 483.4 |  |  | $ | 108.8 |  |  | $ | 1,052.2 |  |  | $ | 853.7 |  |

[0001375365-26-000014:mdna:46]
The following table presents certain items of our condensed consolidated statements of operations expressed as a percentage of net sales for the three and nine months ended March 31, 2026 and 2025:

[0001375365-26-000014:mdna:47]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 90.1 | % |  | 90.4 | % |  | 91.8 | % |  | 88.4 | % |  |
| Gross profit | 9.9 | % |  | 9.6 | % |  | 8.2 | % |  | 11.6 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development | 2.1 | % |  | 3.5 | % |  | 2.0 | % |  | 2.8 | % |  |
| Sales and marketing | 0.9 | % |  | 1.3 | % |  | 0.7 | % |  | 1.3 | % |  |
| General and administrative | 0.8 | % |  | 1.6 | % |  | 0.8 | % |  | 1.2 | % |  |
| Total operating expenses | 3.8 | % |  | 6.4 | % |  | 3.5 | % |  | 5.3 | % |  |
| Income from operations | 6.1 | % |  | 3.2 | % |  | 4.7 | % |  | 6.3 | % |  |
| Other income (expense), net | — | % | * | (0.7) | % |  | — | % | * | (0.2) | % |  |
| Interest income | 0.4 | % |  | 0.3 | % |  | 0.5 | % |  | 0.2 | % |  |
| Interest expense | (0.6) | % |  | (0.3) | % |  | (0.4) | % |  | (0.2) | % |  |
| Income before income tax provision | 5.9 | % |  | 2.5 | % |  | 4.8 | % |  | 6.1 | % |  |
| Income tax provision | (1.2) | % |  | (0.1) | % |  | (1.0) | % |  | (0.8) | % |  |
| Share of (loss) income from equity investee, net of taxes | — | % | * | — | % | * | — | % | * | — | % | * |
| Net income | 4.7 | % |  | 2.4 | % |  | 3.8 | % |  | 5.3 | % |  |

[0001375365-26-000014:mdna:48]
[same as prior period, unchanged from 0001375365-26-000007:mdna:48]

[0001375365-26-000014:mdna:49]
SMCI | Q3 2026 Form 10-Q | 45

[0001375365-26-000014:mdna:50]
[same as prior period, unchanged from 0001375365-26-000007:mdna:50]

[0001375365-26-000014:mdna:51]
The following table presents net sales for the three and nine months ended March 31, 2026 and 2025 (dollars in millions):

[0001375365-26-000014:mdna:52]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2026 |  | 2025 |  | $ |  | % |  | 2026 |  | 2025 |  | $ |  | % |
| Net sales | $ | 10,243.0 |  |  | $ | 4,599.9 |  |  | $ | 5,643.1 |  |  | 122.7 | % |  | $ | 27,943.3 |  |  | $ | 16,215.1 |  |  | $ | 11,728.2 |  |  | 72.3 | % |

[0001375365-26-000014:mdna:53]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:54]
The $5,643.1 million or 122.7% increase in net sales was primarily due to fulfillment and shipment of orders to support our customers' data centers deployment, including large design wins from a few customers, during the three months ended March 31, 2026. An increase in our average selling price compared to the quarter ended March 31, 2025 also contributed modestly by product mix. This was most pronounced in increased sales for AI GPU related products of $5,158.6 million or 150.5% year-over-year, including liquid-cooled and air-cooled servers that are generally more complex and of higher average selling price.

[0001375365-26-000014:mdna:55]
Comparison of the Nine Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:56]
The $11,728.2 million or 72.3% increase in net sales was primarily due to fulfillment and shipment of orders to support our customers' data centers deployment, including large design wins from a few customers, during the nine months ended March 31, 2026. An increase in our average selling price compared to the nine months ended March 31, 2025, also contributed modestly by product mix. This was most pronounced in increased sales for AI GPU related products of $12,028.9 million or 97.8% year-over-year, including liquid-cooled and air-cooled servers that are generally more complex and of higher average selling price. This was partially offset by decreased sales across other product categories by $318.0 million, or 34.9% as we continue to focus on gaining market share from our AI GPU platforms.

[0001375365-26-000014:mdna:57]
Cost of Sales, Gross Profit, and Gross Margin

[0001375365-26-000014:mdna:58]
Cost of sales and gross margin for the three and nine months ended March 31, 2026 and 2025 were as follows (dollars in millions):

[0001375365-26-000014:mdna:59]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2026 |  | 2025 |  | $ |  | % |  | 2026 |  | 2025 |  | $ |  | % |
| Cost of sales | $ | 9,224.3 |  | $ | 4,159.7 |  | $ | 5,064.6 |  |  | 121.8 | % |  | $ | 25,658.7 |  | $ | 14,329.3 |  | $ | 11,329.4 |  |  | 79.1 | % |
| Percentage of total net sales | 90.1 | % |  | 90.4 | % |  |  |  |  |  | 91.8 | % |  | 88.4 | % |  |  |  |  |
| Gross profit | $ | 1,018.7 |  | $ | 440.2 |  | $ | 578.5 |  |  | 131.4 | % |  | $ | 2,284.6 |  | $ | 1,885.8 |  | $ | 398.8 |  |  | 21.1 | % |
| Gross margin | 9.9 | % |  | 9.6 | % |  |  |  | 0.3 | % |  | 8.2 | % |  | 11.6 | % |  |  |  | (3.4) | % |

[0001375365-26-000014:mdna:60]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:61]
The $5,064.6 million or 121.8% increase in cost of sales was primarily driven by an increase of approximately  $5,047.8 million or 121.6% in certain products including GPU servers, HPC systems, and rack-scale solutions, consistent with the higher shipment volume during the three months ended March 31, 2026, as compared to the three months ended March 31, 2025, as well as a $89.4 million or 608.0% increase in tariff expenses driven by new trade policies from the government. These increases were partially offset by a $54.9 million or 43.9% decrease in inventory write-down adjustments resulting from increase in market price for some of our products in the quarter ended March 31, 2026, and a $12.3 million or 5.5% decrease due to an increase in vendor rebates.

[0001375365-26-000014:mdna:62]
SMCI | Q3 2026 Form 10-Q | 46

[0001375365-26-000014:mdna:63]
Gross margin remained relatively flat for the three months ended March 31, 2026, as compared to the three months ended March 31, 2025.

[0001375365-26-000014:mdna:64]
Comparison of the Nine Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:65]
The $11,329.4 million or 79.1% increase in cost of sales was primarily driven by an increase of approximately  $10,636.2 million or 72.0% in certain products including GPU servers, HPC systems, and rack-scale solutions, consistent with the higher shipment volume during the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025. The remaining increases in cost of sales were driven by a $273.6 million or 891.0% increase in tariff expenses driven by new trade policies, a $79.9 million or 50.0% increase in inventory write-down adjustments resulting from excess and obsolete inventory with either insufficient demand or reduced net realizable value, and a $276.3 million or 29.2% increase due to a decrease in vendor rebates.

[0001375365-26-000014:mdna:66]
The 3.4% decrease in the gross margin was due to a change in product and customer mix, higher production and expedite costs as we began to ship new AI GPU platforms on a large scale and the increases in tariff expense and inventory write-down adjustments described above.

[0001375365-26-000014:mdna:67]
[same as prior period, unchanged from 0001375365-26-000007:mdna:67]

[0001375365-26-000014:mdna:68]
Operating expenses for the three and nine months ended March 31, 2026 and 2025 were as follows (dollars in millions):

[0001375365-26-000014:mdna:69]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2026 |  | 2025 |  | $ |  | % |  | 2026 |  | 2025 |  | $ |  | % |
| Research and development | $ | 215.7 |  | $ | 162.9 |  | $ | 52.8 |  |  | 32.4 | % |  | $ | 569.7 |  | $ | 453.3 |  | $ | 116.4 |  |  | 25.7 | % |
| Percentage of total net sales | 2.1 | % |  | 3.5 | % |  |  |  |  |  | 2.0 | % |  | 2.8 | % |  |  |  |  |
| Sales and marketing | $ | 89.5 |  | $ | 60.0 |  | $ | 29.5 |  |  | 49.2 | % |  | $ | 210.5 |  | $ | 208.4 |  | $ | 2.1 |  |  | 1.0 | % |
| Percentage of total net sales | 0.9 | % |  | 1.3 | % |  |  |  |  |  | 0.7 | % |  | 1.3 | % |  |  |  |  |
| General and administrative | $ | 87.6 |  | $ | 70.5 |  | $ | 17.1 |  |  | 24.3 | % |  | $ | 222.0 |  | $ | 199.5 |  | $ | 22.5 |  |  | 11.3 | % |
| Percentage of total net sales | 0.8 | % |  | 1.6 | % |  |  |  |  |  | 0.8 | % |  | 1.2 | % |  |  |  |  |
| Total operating expenses | $ | 392.8 |  | $ | 293.4 |  | $ | 99.4 |  |  | 33.9 | % |  | $ | 1,002.2 |  | $ | 861.2 |  | $ | 141.0 |  |  | 16.4 | % |

[0001375365-26-000014:mdna:70]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:71]
Research and development expenses. The $52.8 million or 32.4% increase in research and development expenses was primarily driven by an increase in employee-related costs of $50.9 million, or 34.6%, mainly comprised of a $28.6 million, or 52.8%, increase in stock-based compensation, a $18.2 million, or 22.1%, increase in salaries, and a $4.1 million, or 10.4% increase in benefits as we expanded our workforce and invested in key talent to support our global growth across regions.

[0001375365-26-000014:mdna:72]
Sales and marketing expenses. The $29.5 million or 49.2% increase in sales and marketing expenses was primarily driven by an increase in employee-related costs of $26.1 million, or 53.2%, mainly comprised of a $23.0 million, or 61.8%, increase in salaries, and a $2.4 million, or 24.2%, increase in stock-based compensation, similar to our research and development expenses as we expanded our workforce and invested in key talent company-wide.  Other increases include a $3.4 million, or 57.6%, increase in standard marketing and advertising activities during the three months ended March 31, 2026, as compared to the three months ended March 31, 2025.

[0001375365-26-000014:mdna:73]
SMCI | Q3 2026 Form 10-Q | 47

[0001375365-26-000014:mdna:74]
General and administrative expenses. The $17.1 million or 24.3% increase in general and administrative expenses was primarily driven by an increase in employee-related costs of $6.1 million, or 16.4%, mainly comprised of a $5.5 million, or 41.4% increase in stock-based compensation, due to the hiring of key talent and the refresh of grants. Additionally, there was a $6.0 million, or 2000.0%, increase in financial fees primarily driven by a $5.7 million, or 100.0%, increase in factoring fees for the receivables sold under the Receivables Purchase Agreement, a $2.4 million or 133.3% increase in excise and franchise tax expense directly related to the increase in sales compared to prior-year quarter which increased the related tax expense, and a $1.6 million, or 6.5%, increase in professional and service fees primarily from additional external accounting, tax, legal and advisory services to support our external reporting related activities.

[0001375365-26-000014:mdna:75]
Comparison of the Nine Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:76]
Research and development expenses. The $116.4 million or 25.7% increase in research and development expenses was primarily driven by an increase in employee-related costs of $107.9 million, or 26.6%, mainly comprised of a $58.5 million, or 41.3%, increase in stock-based compensation, a $39.4 million, or 17.0%, increase in salaries, and a $10.0 million, or 31.3% increase in benefits as we expanded our workforce and invested in key talent to support our global growth across regions.

[0001375365-26-000014:mdna:77]
Sales and marketing expenses. The $2.1 million or 1.0% increase in sales and marketing expenses was primarily driven by an increase in employee-related costs of $42.9 million, or 27.6%, mainly comprised of a $34.7 million, or 28.4%, increase in salaries, a $6.5 million, or 27.2%, increase in stock-based compensation, and a $1.7 million, or 27.4%, increase in other personnel costs, similar to our research and development expenses as we expanded our workforce and invested in key talent company-wide.  These increases were partially offset by a $28.9 million, or 111.2%, increase in marketing development funds received from certain business partners related to co-marketing and advertising events to promote products, which reduced sales and marketing expense, and a $12.2 million, or 19.1%, decrease in standard marketing and advertising activities during the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025.

[0001375365-26-000014:mdna:78]
General and administrative expenses. The $22.5 million or 11.3% increase in general and administrative expenses was primarily driven by an increase in employee-related costs of $9.5 million, or 9.2%, mainly comprised of a $7.5 million or 12.6% increase in salaries and benefits, and a $2.0 million, or 4.5% increase in stock-based compensation, due to the hiring of key talent and the refresh of grants.  Additionally, there was a $7.2 million, or 124.1% increase in excise and franchise tax expense directly related to the increase in sales compared to prior-year which increased the related tax expense, a $6.0 million, or 857.1%, increase in financial fees primarily driven by a $5.7 million, or 100.0% increase in factoring fees for the receivables sold under the Receivables Purchase Agreement, a $6.0 million, or 12.3%, increase in professional and service fees primarily from additional external accounting, tax, legal and advisory services to support our external reporting related activities, and an increase of $5.6 million or 65.1% in indirect facilities costs such as rental costs, utility costs, and depreciation costs.  These increases were partially offset by a $11.6 million or 56.9% reduction in audit and tax fees, driven by an absence of additional costs related to the delayed filing of our fiscal 2024 Form 10-K.

[0001375365-26-000014:mdna:79]
SMCI | Q3 2026 Form 10-Q | 48

[0001375365-26-000014:mdna:80]
Other Income (Expense), Net, Interest Income, and Interest Expense

[0001375365-26-000014:mdna:81]
Other income (expense), net, interest income, and interest expense for the three and nine months ended March 31, 2026 and 2025 were as follows (dollars in millions):

[0001375365-26-000014:mdna:82]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2026 |  | 2025 |  | $ |  | % |  | 2026 |  | 2025 |  | $ |  | % |
| Other income (expense), net | $ | 4.2 |  |  | $ | (33.0) |  |  | $ | 37.2 |  |  | (112.7) | % |  | $ | 4.3 |  |  | $ | (29.5) |  |  | $ | 33.8 |  |  | (114.6) | % |
| Percentage of total net sales | — | % |  | (0.7) | % |  |  |  |  |  | — | % |  | (0.2) | % |  |  |  |  |
| Interest income | 45.4 |  |  | 14.7 |  |  | 30.7 |  |  | 208.8 | % |  | 147.8 |  |  | 31.4 |  |  | 116.4 |  |  | 370.7 | % |
| Percentage of total net sales | 0.4 | % |  | 0.3 | % |  |  |  |  |  | 0.5 | % |  | 0.2 | % |  |  |  |  |
| Interest expense | (64.5) |  |  | (13.4) |  |  | (51.1) |  |  | 381.3 | % |  | (114.8) |  |  | (37.3) |  |  | (77.5) |  |  | 207.8 | % |
| Percentage of total net sales | (0.6) | % |  | (0.3) | % |  |  |  |  |  | (0.4) | % |  | (0.2) | % |  |  |  |  |
| Other income (expense), net, interest income, and interest expense | $ | (14.9) |  |  | $ | (31.7) |  |  | $ | 16.8 |  |  | (53.0) | % |  | $ | 37.3 |  |  | $ | (35.4) |  |  | $ | 72.7 |  |  | (205.4) | % |

[0001375365-26-000014:mdna:83]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:84]
The $37.2 million or 112.7% increase in other income (expense), net was primarily driven by one-time $30.3 million loss on extinguishment of our Original 2029 Convertible Notes resulting from the 2029 Convertible Notes Amendments (see Note 9, “Convertible Notes”) recorded during the three months ended March 31, 2025, as well as a $3.5 million or 1183.1% increase due to favorable foreign currency exchange rate fluctuations during the three months ended March 31, 2026.

[0001375365-26-000014:mdna:85]
The $30.7 million or 208.8% increase in interest income for the three months ended March 31, 2026, as compared to the three months ended March 31, 2025, was primarily driven by higher interest income as a result of increased cash deposits funded by the proceeds from our convertible notes issuance and financing arrangements with a customer.

[0001375365-26-000014:mdna:86]
The $51.1 million or 381.3% increase in interest expense was primarily driven by a $11.8 million or 98.6% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025, as well as $34.6 million additional interest expense related to the drawdown on our revolving credit facilities during the third quarter of fiscal 2026.

[0001375365-26-000014:mdna:87]
Comparison of the Nine Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:88]
The $33.8 million or 114.6% decrease in other income (expense), net was primarily driven by one-time $30.3 million loss on extinguishment of our Original 2029 Convertible Notes resulting from the 2029 Convertible Notes Amendments (see Note 9, “Convertible Notes”) recorded during the nine months ended March 31, 2025, as well as a $8.7 million or 4242.4% gain from mark-to-market adjustments on a marketable equity securities investment for the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025, and a $3.9 million or 93.9% increase due to favorable foreign currency exchange rate fluctuations during the nine months ended March 31, 2026. These increases were partially offset by a $13.7 million impairment loss related to our non-marketable investments during the nine months ended March 31, 2026.

[0001375365-26-000014:mdna:89]
The $116.4 million or 370.7% increase in interest income for the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025, was primarily driven by higher interest income as a result of increased cash deposits funded by the proceeds from our convertible notes issuance and financing arrangements with a customer.

[0001375365-26-000014:mdna:90]
SMCI | Q3 2026 Form 10-Q | 49

[0001375365-26-000014:mdna:91]
The $77.5 million or 207.8% increase in interest expense was primarily driven by a $56.3 million or 377.3% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025, as well as $34.6 million additional interest expense related to the drawdown on our revolving credit facilities during the third quarter of fiscal 2026. These increases were partially offset by a $10.6 million decrease in interest expense associated with our Bank of America and Cathay line of credit and term loans, which were fully repaid during the first half of fiscal 2025.

[0001375365-26-000014:mdna:92]
[same as prior period, unchanged from 0001375365-26-000007:mdna:92]

[0001375365-26-000014:mdna:93]
Income tax provision and effective tax rates for the three and nine months ended March 31, 2026 and 2025 were as follows (dollars in millions):

[0001375365-26-000014:mdna:94]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2026 |  | 2025 |  | $ |  | % |  | 2026 |  | 2025 |  | $ |  | % |
| Income tax provision | $ | (126.9) |  |  | $ | (5.8) |  | $ | (121.1) |  |  | 2,087.9 | % |  | $ | (266.2) |  | $ | (137.5) |  | $ | (128.7) |  |  | 93.6 | % |
| Percentage of total net sales | (1.2) | % |  | (0.1) | % |  |  |  |  |  | (1.0) | % |  | (0.8) | % |  |  |  |  |
| Effective tax rate | (20.8) | % |  | (5.1) | % |  |  |  |  |  | (20.2) | % |  | (13.9) | % |  |  |  |  |

[0001375365-26-000014:mdna:95]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:96]
Income tax provision increased by $121.1 million or 2,087.9% primarily due to an increase in worldwide income before income tax provision that increased tax expense by $104.1 million, a lower tax benefit from stock-based compensation of approximately $11.5 million, a lower tax benefit from U.S. federal research tax credit of $3.5 million, and other miscellaneous immaterial tax items of approximately $2.0 million. The income before income tax provision for the third quarter of fiscal 2026 was $611.0 million, which is an increase of $495.9 million or 431.0%.

[0001375365-26-000014:mdna:97]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended March 31, 2026, is higher than that for the three months ended March 31, 2025, primarily due to a significant decrease in stock-based compensation tax deduction and lower U.S. federal research tax credit because of lower stock vesting price in the three months ended March 31, 2026.

[0001375365-26-000014:mdna:98]
Comparison of the Nine Months Ended March 31, 2026 and 2025

[0001375365-26-000014:mdna:99]
Income tax provision increased by $128.7 million or 93.6% primarily due to an increase in worldwide income before income tax provision that increased tax expense by $69.4 million, a lower tax benefit from stock-based compensation of approximately $35.2 million, a lower tax benefit from U.S. federal research tax credit of $12.2 million, an increase of state tax expense by $9.6 million, and other miscellaneous immaterial tax items of approximately $2.3 million. The income before income tax provision for the nine months ended March 31, 2026 was $1,319.7 million, which is an increase of $330.5 million or 33.4%.

[0001375365-26-000014:mdna:100]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the nine months ended March 31, 2026, is higher than that for the nine months ended March 31, 2025, primarily due to a significant decrease in stock-based compensation tax deduction and lower U.S. federal research tax credit because of lower stock vesting price in the nine months ended March 31, 2026.

[0001375365-26-000014:mdna:101]
SMCI | Q3 2026 Form 10-Q | 50

[0001375365-26-000014:mdna:102]
[same as prior period, unchanged from 0001375365-26-000007:mdna:101]

[0001375365-26-000014:mdna:103]
We have financed our growth primarily with funds generated from operations, as well as utilizing borrowing facilities, selling our common stock, and issuing convertible notes. Recent drivers of liquidity changes included an increase in the need for working capital due to higher levels of inventory required to support future revenue growth, greater requests for longer payment terms from customers due to increasing system costs and to a lesser extent longer supply chain lead times on certain key components. Our cash and cash equivalents were $1.3 billion and $5.2 billion as of March 31, 2026 and June 30, 2025, respectively. Our cash and cash equivalents held in foreign locations was $617.3 million and $607.2 million as of March 31, 2026 and June 30, 2025, respectively.

[0001375365-26-000014:mdna:104]
[same as prior period, unchanged from 0001375365-26-000007:mdna:104]

[0001375365-26-000014:mdna:105]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operations and maturing debt and interest payments for the 12 months following the issuance of these condensed consolidated financial statements. We continue to assess financing options that may be necessary to support the growth of our business.

[0001375365-26-000014:mdna:106]
[same as prior period, unchanged from 0001375365-26-000007:mdna:106]

[0001375365-26-000014:mdna:107]
|  | Nine Months Ended March 31, |  | Change |  |  |  |
|  | 2026 |  | 2025 |  | $ |  |  |  |
| Net cash (used in) provided by operating activities | $ | (7,556.8) |  |  | $ | 795.9 |  |  | $ | (8,352.7) |  |  |  |  |
| Net cash used in investing activities | (175.8) |  |  | (104.5) |  |  | (71.3) |  |  |  |  |
| Net cash provided by financing activities | 3,906.8 |  |  | 174.6 |  |  | 3,732.2 |  |  |  |  |
| Effect of exchange rate fluctuations on cash | (6.6) |  |  | 0.8 |  |  | (7.4) |  |  |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (3,832.4) |  |  | $ | 866.8 |  |  | $ | (4,699.2) |  |  |  |  |

[0001375365-26-000014:mdna:108]
[same as prior period, unchanged from 0001375365-26-000007:mdna:108]

[0001375365-26-000014:mdna:109]
Net cash (used in) provided by operating activities during the nine months ended March 31, 2026 mostly consisted of $1,052.2 million net income adjusted for certain non-cash items, such as $305.6 million of stock-based compensation expense, $239.3 million of inventory valuation adjustment write-downs, $39.0 million of depreciation and amortization expense, and changes in working capital. The decrease in cash flows from operating activities during the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025, was due to an increase in inventory purchases, accounts receivables from customers, and increased  operational spending.

[0001375365-26-000014:mdna:110]
[same as prior period, unchanged from 0001375365-26-000007:mdna:110]

[0001375365-26-000014:mdna:111]
Net cash used in investing activities during the nine months ended March 31, 2026 mostly consisted of $133.8 million of purchases of property, plant, and equipment as we continued to invest in real estate, servers, data centers, and network infrastructure, as well as investments made in equity securities of $42.0 million. The increase in cash used in investing activities during the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025, was mostly due to increases in purchases of property, plant, and equipment.

[0001375365-26-000014:mdna:112]
SMCI | Q3 2026 Form 10-Q | 51

[0001375365-26-000014:mdna:113]
[same as prior period, unchanged from 0001375365-26-000007:mdna:112]

[0001375365-26-000014:mdna:114]
Net cash provided by financing activities during the nine months ended March 31, 2026 mostly consisted of net proceeds from lines of credit and term loans of $4,010.2 million, partially offset by payment for withholding taxes related to settlement of equity awards of $102.4 million. The increase in cash provided by financing activities during the nine months ended March 31, 2026, as compared to the nine months ended March 31, 2025, was mostly due to an increase in net proceeds from lines of credit and term loans.

[0001375365-26-000014:mdna:115]
[same as prior period, unchanged from 0001375365-26-000007:mdna:114]

[0001375365-26-000014:mdna:116]
Refer to Note 8, “Lines of Credit, Revolving Credit Facilities, and Term Loans”, in the notes to the condensed consolidated financial statements in this Quarterly Report for further information on our outstanding debt.

[0001375365-26-000014:mdna:117]
Refer to Note 9, “Convertible Notes”, in the notes to the condensed consolidated financial statements in this Quarterly Report for further information on the amendment of the terms of the 2029 Convertible Notes, and the issuance of the 2028 Convertible Notes and the 2030 Convertible Notes.

[0001375365-26-000014:mdna:118]
[same as prior period, unchanged from 0001375365-26-000007:mdna:118]

[0001375365-26-000014:mdna:119]
We anticipate our total capital expenditures for the fiscal year 2026 will be in range of $155.0 million to $175.0 million, primarily relating to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on net sales growth, productivity, expenses, service levels and customer retention).

[0001375365-26-000014:mdna:120]
[same as prior period, unchanged from 0001375365-26-000007:mdna:120]

[0001375365-26-000014:mdna:121]
[same as prior period, unchanged from 0001375365-26-000007:mdna:121]

[0001375365-26-000014:mdna:122]
Our estimated future obligations as of March 31, 2026, include both current and long-term obligations. For our long-term debt, as noted in Note 8, “Lines of Credit, Revolving Credit Facilities, and Term Loans” in the notes to the condensed consolidated financial statements, we have a current obligation of $2,095.1 million and a long-term obligation of $2,018.7 million. Additionally, as noted in Note 9, “Convertible Notes” in the notes to the condensed consolidated financial statements, we have a convertible debt obligation of $4,725.0 million. Under our operating leases, as noted in Note 10, “Leases” in the notes to the condensed consolidated financial statements, we have a current obligation of $32.7 million and a long-term obligation of $345.4 million. As noted in Note 14, “Commitments and Contingencies”, in the notes to the condensed consolidated financial statements, we have current obligations related to non-cancelable purchase commitments of $10.1 billion.

[0001375365-26-000014:mdna:123]
[same as prior period, unchanged from 0001375365-26-000007:mdna:123]

[0001375365-26-000014:mdna:124]
[same as prior period, unchanged from 0001375365-26-000007:mdna:124]

[0001375365-26-000014:mdna:125]
SMCI | Q3 2026 Form 10-Q | 52
