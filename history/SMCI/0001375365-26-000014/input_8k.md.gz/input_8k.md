# SMCI 8-K — 0001375365-26-000013 filed 2026-05-05

## item codes, every 8-K on or before 2026-05-11

- 2026-05-05 0001375365-26-000013 — 2.02, 9.01
- 2026-04-20 0001375365-26-000012 — 5.02, 5.07, 9.01
- 2026-03-20 0001375365-26-000011 — 5.02, 9.01
- 2026-02-03 0001375365-26-000006 — 2.02, 9.01
- 2026-01-29 0001375365-26-000005 — 1.01, 9.01
- 2026-01-26 0001375365-26-000004 — 1.01, 5.08, 8.01, 9.01
- 2026-01-02 0001375365-26-000002 — 5.02, 9.01 — amendment of 0001375365-25-000031
- 2026-01-02 0001375365-26-000001 — 1.01, 9.01
- 2025-12-29 0001375365-25-000031 — 5.02, 9.01
- 2025-11-04 0001375365-25-000029 — 2.02, 9.01
- 2025-10-23 0001628280-25-045989 — 2.02, 9.01
- 2025-08-05 0001375365-25-000023 — 2.02, 9.01
- 2025-07-21 0001375365-25-000022 — 1.01, 2.03, 9.01
- 2025-06-27 0001375365-25-000020 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-06-23 0001375365-25-000018 — 8.01, 9.01
- 2025-06-06 0001375365-25-000016 — 5.02, 5.07, 9.01
- 2025-05-06 0001375365-25-000013 — 2.02, 9.01
- 2025-04-29 0001375365-25-000012 — 2.02, 9.01
- 2025-03-31 0001375365-25-000008 — 5.02, 7.01, 9.01
- 2025-02-26 0001375365-25-000007 — 3.01, 5.08, 8.01, 9.01
- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2026-05-11

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-26-000013:8k_2_02:1]
EX-99.1
2
exhibit991_20260331.htm
EX-99.1

[0001375365-26-000013:8k_2_02:2]
Document

[0001375365-26-000013:8k_2_02:3]
Exhibit 99.1

[0001375365-26-000013:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2026 Financial Results

[0001375365-26-000013:8k_2_02:5]
SAN JOSE, Calif. -- May 5, 2026 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced unaudited financial results for its third quarter of fiscal year 2026 ended March 31, 2026.

[0001375365-26-000013:8k_2_02:6]
Third Quarter Fiscal Year 2026 Highlights

[0001375365-26-000013:8k_2_02:7]
•Net sales of $10.2 billion versus $12.7 billion in Q2'26 and $4.6 billion in Q3'25.

[0001375365-26-000013:8k_2_02:8]
•Gross margin of 9.9% versus 6.3% in Q2'26 and 9.6% in Q3'25.

[0001375365-26-000013:8k_2_02:9]
•Net income of $483 million versus $401 million in Q2'26 and $109 million in Q3'25.

[0001375365-26-000013:8k_2_02:10]
•Diluted net income per common share of $0.72 versus $0.60 in Q2'26 and $0.17 in Q3'25.

[0001375365-26-000013:8k_2_02:11]
•Non-GAAP gross margin of 10.1% versus 9.7% in Q3'25.

[0001375365-26-000013:8k_2_02:12]
•Non-GAAP diluted net income per common share of $0.84 versus $0.31 in Q3'25.

[0001375365-26-000013:8k_2_02:13]
•Cash flow used in operations for Q3'26 of $6.6 billion and capital expenditures and investments of $97 million.

[0001375365-26-000013:8k_2_02:14]
“Supermicro's transformation into a total datacenter infrastructure provider is accelerating," said Charles Liang, Founder, President and CEO of Supermicro. "Our margin recovery and the rapid growth of our DCBBS business demonstrate that our business remains robust. With the addition of our new US manufacturing facilities in Silicon Valley, we are exceptionally well-positioned to meet the massive demand for various AI and enterprise verticals.”

[0001375365-26-000013:8k_2_02:15]
As of March 31, 2026, total cash and cash equivalents was $1.3 billion and total bank debt and convertible notes were $8.8 billion.

[0001375365-26-000013:8k_2_02:16]
Business Outlook

[0001375365-26-000013:8k_2_02:17]
The Company expects net sales in the range of $11.0 billion and $12.5 billion for the fourth quarter of fiscal year 2026 ending June 30, 2026, GAAP net income per diluted share of $0.53 to $0.67 and non-GAAP net income per diluted share of $0.65 to $0.79. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 19.4% and 20.4%, respectively, and a fully diluted share count of 695 million shares for GAAP and fully diluted share count of 712 million shares for non-GAAP. The outlook for the fourth quarter of fiscal year 2026 GAAP net income per diluted share includes approximately $95 million in expected stock-based compensation, net of related tax effects of $30 million that are excluded from non-GAAP net income per diluted share.

[0001375365-26-000013:8k_2_02:18]
For fiscal year 2026, the Company expects net sales in the range of $38.9 billion to $40.4 billion.

[0001375365-26-000013:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-26-000013:8k_2_02:20]
Supermicro will present a live audio webcast of our conference call to review its third quarter of fiscal year 2026 financial results on Tuesday, May 5, 2026, at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-26-000013:8k_2_02:21]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-26-000013:8k_2_02:22]
Forward Looking Statements and Other Disclosures

[0001375365-26-000013:8k_2_02:23]
Financial Information Is Preliminary and May Be Subject to Change

[0001375365-26-000013:8k_2_02:24]
The unaudited interim financial information presented in this press release is preliminary. The final financial results reported for this period may also differ from the results reported in this release.

[0001375365-26-000013:8k_2_02:25]
The financial results presented reflect the Company's preliminary estimated unaudited financial results, based upon information available to the Company as of the date of this press release. The Company has provided preliminary estimates of financial results primarily because its financial closing procedures for the quarter ended March 31, 2026 are not yet complete. The data are not a comprehensive statement of the Company's results for such periods, and the actual results may differ materially from these preliminary estimated data. The Company's actual results remain subject to the completion of management’s and its audit committee’s review and other financial closing processes as well as the completion and preparation of its financial data for such periods. The Company's independent registered public accounting firm has not audited, reviewed, compiled or performed any procedures with respect to such preliminary data. During the course of the preparation of the Company's financial statements and related notes and the completion of the review for such periods, additional adjustments to the preliminary estimated financial information presented here may be identified, and its final results

[0001375365-26-000013:8k_2_02:26]
for these periods may vary from these preliminary estimates. This preliminary estimated data should not be considered a substitute for the financial statements to be prepared in accordance with accounting principles generally accepted in the United States and to be filed with the Securities and Exchange Commission once available.

[0001375365-26-000013:8k_2_02:27]
About Super Micro Computer, Inc.

[0001375365-26-000013:8k_2_02:28]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G/Edge IT Infrastructure. We are a Total IT Solutions provider with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-26-000013:8k_2_02:29]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-26-000013:8k_2_02:30]
All other brands, names, and trademarks are the property of their respective owners.

[0001375365-26-000013:8k_2_02:31]
Investor Relations Contact:

[0001375365-26-000013:8k_2_02:32]
Nicole Noutsios

[0001375365-26-000013:8k_2_02:33]
Stratos Advisors

[0001375365-26-000013:8k_2_02:34]
email: ir@supermicro.com

[0001375365-26-000013:8k_2_02:35]
Source: Super Micro Computer, Inc.

[0001375365-26-000013:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-26-000013:8k_2_02:38]
(in thousands)

[0001375365-26-000013:8k_2_02:39]
(unaudited)

[0001375365-26-000013:8k_2_02:40]
|  | March 31, |  | June 30, |
|  | 2026 |  | 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,290,324 |  |  | $ | 5,169,911 |  |
| Accounts receivable, net of allowance for credit losses | 8,413,396 |  |  | 2,203,942 |  |
| Inventories | 11,103,376 |  |  | 4,680,375 |  |
| Prepaid expenses and other current assets | 761,190 |  |  | 247,426 |  |
| Total current assets | 21,568,286 |  |  | 12,301,654 |  |
| Property, plant, and equipment, net | 607,659 |  |  | 504,488 |  |
| Deferred income taxes, net | 632,715 |  |  | 607,416 |  |
| Other assets | 643,369 |  |  | 604,871 |  |
| Total assets | $ | 23,452,029 |  |  | $ | 14,018,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 3,686,991 |  |  | $ | 1,281,977 |  |
| Accrued liabilities | 830,007 |  |  | 565,637 |  |
| Income taxes payable | 38,333 |  |  | 53,381 |  |
| Lines of credit and current portion of term loans | 2,095,069 |  |  | 75,060 |  |
| Deferred revenue | 1,472,235 |  |  | 368,737 |  |
| Total current liabilities | 8,122,635 |  |  | 2,344,792 |  |
| Deferred revenue, non-current | 663,410 |  |  | 362,645 |  |
| Term loans, non-current | 2,018,675 |  |  | 37,415 |  |
| Convertible notes | 4,659,357 |  |  | 4,645,178 |  |
| Other long-term liabilities | 412,361 |  |  | 326,528 |  |
| Total liabilities | 15,876,438 |  |  | 7,716,558 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 3,087,963 |  |  | 2,866,449 |  |
| Accumulated other comprehensive income | 692 |  |  | 705 |  |
| Retained earnings | 4,486,775 |  |  | 3,434,539 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 7,575,430 |  |  | 6,301,693 |  |
| Non-controlling interest | 161 |  |  | 178 |  |
| Total stockholders’ equity | 7,575,591 |  |  | 6,301,871 |  |
| Total liabilities and stockholders’ equity | $ | 23,452,029 |  |  | $ | 14,018,429 |  |

[0001375365-26-000013:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-26-000013:8k_2_02:43]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:44]
(unaudited)

[0001375365-26-000013:8k_2_02:45]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net sales | $ | 10,243,014 |  |  | $ | 4,599,913 |  |  | $ | 27,943,295 |  |  | $ | 16,215,131 |  |
| Cost of sales | 9,224,334 |  |  | 4,159,695 |  |  | 25,658,675 |  |  | 14,329,311 |  |
| Gross profit | 1,018,680 |  |  | 440,218 |  |  | 2,284,620 |  |  | 1,885,820 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 215,659 |  |  | 162,857 |  |  | 569,734 |  |  | 453,329 |  |
| Sales and marketing | 89,510 |  |  | 59,978 |  |  | 210,516 |  |  | 208,400 |  |
| General and administrative | 87,643 |  |  | 70,603 |  |  | 221,948 |  |  | 199,488 |  |
| Total operating expenses | 392,812 |  |  | 293,438 |  |  | 1,002,198 |  |  | 861,217 |  |
| Income from operations | 625,868 |  |  | 146,780 |  |  | 1,282,422 |  |  | 1,024,603 |  |
| Other income (expense), net | 4,147 |  |  | (32,967) |  |  | 4,243 |  |  | (29,558) |  |
| Interest income | 45,437 |  | 14,654 |  | 147,835 |  | 31,437 |
| Interest expense | (64,483) |  |  | (13,402) |  |  | (114,772) |  |  | (37,291) |  |
| Income before income tax provision | 610,969 |  |  | 115,065 |  |  | 1,319,728 |  |  | 989,191 |  |
| Income tax provision | (126,887) |  |  | (5,843) |  |  | (266,199) |  |  | (137,544) |  |
| Share of (loss) income from equity investee, net of taxes | (695) |  |  | (445) |  |  | (1,293) |  |  | 2,053 |  |
| Net income | $ | 483,387 |  |  | $ | 108,777 |  |  | $ | 1,052,236 |  |  | $ | 853,700 |  |
| Net income per common share (A): |  |  |  |  |  |  |  |
| Basic | $ | 0.81 |  |  | $ | 0.18 |  |  | $ | 1.76 |  |  | $ | 1.44 |  |
| Diluted | $ | 0.72 |  |  | $ | 0.17 |  |  | $ | 1.59 |  |  | $ | 1.37 |  |
| Weighted-average shares used in the calculation of net income per common share (A): |  |  |  |  |  |  |  |
| Basic | 600,205 |  |  | 595,041 |  |  | 597,928 |  |  | 592,349 |  |
| Diluted | 692,189 |  |  | 621,809 |  |  | 673,598 |  |  | 625,272 |  |

[0001375365-26-000013:8k_2_02:46]
(A) Reflects a ten-for-one stock split on September 30, 2024.

[0001375365-26-000013:8k_2_02:47]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-26-000013:8k_2_02:48]
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |
| Cost of sales |  | $ | 11,522 |  |  | $ | 7,060 |  |  | $ | 25,400 |  |  | $ | 17,713 |  |  |  |
| Research and development |  | 83,115 |  |  | 54,254 |  |  | 200,090 |  |  | 141,590 |  |  |  |
| Sales and marketing |  | 12,276 |  |  | 9,923 |  |  | 33,700 |  |  | 27,245 |  |  |  |
| General and administrative |  | 19,021 |  |  | 13,467 |  |  | 46,368 |  |  | 44,292 |  |  |  |
| Stock-based compensation expense, before taxes |  | $ | 125,934 |  |  | $ | 84,704 |  |  | $ | 305,558 |  |  | $ | 230,840 |  |  |  |

[0001375365-26-000013:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-26-000013:8k_2_02:51]
(in thousands)

[0001375365-26-000013:8k_2_02:52]
(unaudited)

[0001375365-26-000013:8k_2_02:53]
|  | Nine Months Ended March 31, |
|  | 2026 |  | 2025 |  |
| OPERATING ACTIVITIES: |  |  |  |  |
| Net income | $ | 1,052,236 |  |  | $ | 853,700 |  |  |
| Reconciliation of net income to net cash (used in) provided by operating activities: |  |  |  |  |
| Depreciation and amortization | 38,959 |  |  | 29,467 |  |  |
| Amortization of right-of-use (“ROU”) assets | 26,997 |  |  | 10,241 |  |  |
| Amortization of debt discount and issuance costs | 17,162 |  |  | 6,367 |  |  |
| Inventory valuation adjustment write-down | 239,255 |  |  | 159,050 |  |  |
| Stock-based compensation expense | 305,558 |  |  | 230,840 |  |  |
| Impairment loss | 13,747 |  |  | — |  |  |
| Share of loss (income) from equity investee | 1,293 |  |  | (2,053) |  |  |
| Unrealized foreign currency exchange (gain) loss | (4,428) |  |  | 2,742 |  |  |
| Loss on extinguishment of convertible notes | — |  |  | 30,251 |  |  |
| Deferred income taxes, net | (30,920) |  |  | (134,401) |  |  |
| Other non-cash income, net | (8,302) |  |  | (790) |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net | (6,209,831) |  |  | 94,782 |  |  |
| Inventories | (6,669,560) |  |  | 298,847 |  |  |
| Prepaid expenses and other assets | (381,738) |  |  | (284,356) |  |  |
| Accounts payable | 2,406,930 |  |  | (811,690) |  |  |
| Accrued liabilities | 232,916 |  |  | 52,714 |  |  |
| Income taxes payable | (11,576) |  |  | 5,365 |  |  |
| Deferred revenue | 1,404,262 |  |  | 249,421 |  |  |
| Other long-term liabilities | 20,193 |  |  | 5,414 |  |  |
| Net cash (used in) provided by operating activities | (7,556,847) |  |  | 795,911 |  |  |
| INVESTING ACTIVITIES: |  |  |  |  |
| Purchases of property, plant, and equipment | (133,769) |  |  | (104,536) |  |  |
| Investment in equity securities | (42,000) |  |  | — |  |  |
| Net cash used in investing activities | (175,769) |  |  | (104,536) |  |  |
| FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from lines of credit and term loans | 4,235,265 |  |  | 1,357,991 |  |  |
| Repayment of lines of credit and term loans | (225,068) |  |  | (1,731,366) |  |  |
| Payment of debt issuance costs | (23,483) |  |  | — |  |  |
| Proceeds from exercise of stock options | 18,347 |  |  | 14,452 |  |  |
| Payment for withholding taxes related to settlement of equity awards | (102,391) |  |  | (118,960) |  |  |
| Debt issuance costs in connection with amended 2029 Convertibles Notes | — |  |  | (31,217) |  |  |
| Proceeds from issuance of 2028 Convertible Notes, net of issuance costs | — |  |  | 683,696 |  |  |
| Proceeds related to Receivables Purchase Agreement, net | 4,191 |  |  | — |  |  |
| Other | (26) |  |  | 22 |  |  |
| Net cash provided by financing activities | 3,906,835 |  |  | 174,618 |  |  |
| Effect of exchange rate fluctuations on cash | (6,554) |  |  | 826 |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | (3,832,335) |  |  | 866,819 |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 5,172,301 |  |  | 1,670,273 |  |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 1,339,966 |  |  | $ | 2,537,092 |  |  |

[0001375365-26-000013:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-26-000013:8k_2_02:56]
(in thousands)

[0001375365-26-000013:8k_2_02:57]
(unaudited)

[0001375365-26-000013:8k_2_02:58]
| Supplemental disclosure of cash flow information: |  |  |  |  |
| Cash paid for interest | $ | 81,293 |  |  | $ | 24,046 |  |  |
| Cash paid for taxes, net of refunds | $ | 270,394 |  |  | $ | 270,392 |  |  |
| Non-cash investing and financing activities: |  |  |  |  |
| Unpaid property, plant, and equipment purchases | $ | 16,778 |  |  | $ | 18,283 |  |  |
| ROU assets obtained in exchange for operating lease commitments | $ | 94,907 |  |  | $ | 128,617 |  |  |
| Transfer of inventory to property, plant, and equipment, net | $ | 7,304 |  |  | $ | 4,889 |  |  |

[0001375365-26-000013:8k_2_02:59]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:60]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000013:8k_2_02:61]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:62]
(unaudited)

[0001375365-26-000013:8k_2_02:63]
Use of Non-GAAP Financial Measures

[0001375365-26-000013:8k_2_02:64]
To supplement its condensed consolidated financial results presented in accordance with United States Generally Accepted Accounting Principles (“GAAP”), the Company uses non-GAAP measures that are adjusted for certain items from the most directly comparable GAAP measures. The specific non-GAAP measures presented below are: gross profit, gross margin; operating expenses; net income; net income per common share; diluted net income; diluted net income per common share, adjusted earnings before interest, taxes, depreciation, and amortization, (“Adjusted EBITDA”); and effective tax rate. Management believes these non-GAAP measures provide useful information to investors by offering a consistent basis for comparing the Company's performance across periods, excluding items that are not reflective of our core operating results. These non-GAAP measures are not prepared in accordance with GAAP or intended to be a replacement for GAAP financial data; and therefore, should be reviewed together with the GAAP measures and are not intended to serve as a substitute for results under GAAP, and may be different from non-GAAP measures used by other companies.

[0001375365-26-000013:8k_2_02:65]
We exclude the following adjustments from our non-GAAP financial measures:

[0001375365-26-000013:8k_2_02:66]
Non-GAAP Adjustments

[0001375365-26-000013:8k_2_02:67]
•Stock-based compensation: Stock-based compensation relates primarily to our equity incentive awards. Stock-based compensation is a non-cash expense that is dependent on market forces that are difficult to predict. We believe that this adjustment for stock-based compensation provides investors with a basis to measure the company's core performance, including compared with the performance of other companies, without the period-to-period variability created by stock-based compensation.

[0001375365-26-000013:8k_2_02:68]
•Adjusted EBITDA adjustments: When calculating Adjusted EBITDA, in addition to the adjustments described above, we exclude the impact of Interest expense, Income tax (provision) benefit, and Depreciation and amortization during the period.

[0001375365-26-000013:8k_2_02:69]
Pursuant to the requirements of SEC Regulation G, please see the tables below for the reconciliations of GAAP to Non-GAAP measures. These should be read together with the preceding financial statements prepared in accordance with GAAP.

[0001375365-26-000013:8k_2_02:70]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:71]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000013:8k_2_02:72]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:73]
(unaudited)

[0001375365-26-000013:8k_2_02:74]
Reconciliation of GAAP Net Income to Adjusted EBITDA:

[0001375365-26-000013:8k_2_02:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP Net Income | $ | 483,387 |  |  | $ | 108,777 |  |  | $ | 1,052,236 |  |  | $ | 853,700 |  |
| Interest expense | 64,483 |  |  | 13,402 |  |  | 114,772 |  |  | 37,291 |  |
| Income tax provision | 126,887 |  |  | 5,843 |  |  | 266,199 |  |  | 137,544 |  |
| Depreciation and amortization | 13,605 |  |  | 10,910 |  |  | 38,959 |  |  | 29,467 |  |
| Stock-based compensation | 125,934 |  |  | 84,704 |  |  | 305,558 |  |  | 230,840 |  |
| Loss on extinguishment of convertible notes | — |  |  | 30,251 |  |  | — |  |  | 30,251 |  |
| Adjusted EBITDA | $ | 814,296 |  |  | $ | 253,887 |  |  | $ | 1,777,724 |  |  | $ | 1,319,093 |  |
| Adjusted EBITDA % of net sales | 7.9 | % |  | 5.5 | % |  | 6.4 | % |  | 8.1 | % |

[0001375365-26-000013:8k_2_02:76]
Reconciliation of GAAP to Non-GAAP Gross Margin:

[0001375365-26-000013:8k_2_02:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP Gross Profit | $ | 1,018,680 |  |  | $ | 440,218 |  |  | $ | 2,284,620 |  |  | $ | 1,885,820 |  |
| Stock-based compensation | 11,522 |  |  | 7,060 |  |  | 25,400 |  |  | 17,713 |  |
| Non-GAAP Gross Profit | $ | 1,030,202 |  |  | $ | 447,278 |  |  | $ | 2,310,020 |  |  | $ | 1,903,533 |  |
| GAAP gross margin (%) | 9.9 | % |  | 9.6 | % |  | 8.2 | % |  | 11.6 | % |
| Stock-based compensation (%) | 0.2 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP gross margin (%) | 10.1 | % |  | 9.7 | % |  | 8.3 | % |  | 11.7 | % |

[0001375365-26-000013:8k_2_02:78]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:79]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000013:8k_2_02:80]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:81]
(unaudited)

[0001375365-26-000013:8k_2_02:82]
Reconciliation of GAAP to Non-GAAP Operating Expenses:

[0001375365-26-000013:8k_2_02:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP Operating Expenses | $ | 392,812 |  |  | $ | 293,438 |  |  | $ | 1,002,198 |  |  | $ | 861,217 |  |
| Adjustments to operating expenses |  |  |  |  |  |  |  |
| GAAP R&D operating expenses | 215,659 |  |  | 162,857 |  |  | 569,734 |  |  | 453,329 |  |
| Stock-based compensation | (83,115) |  |  | (54,254) |  |  | (200,090) |  |  | (141,590) |  |
| Non-GAAP R&D operating expenses | 132,544 |  |  | 108,603 |  |  | 369,644 |  |  | 311,739 |  |
| GAAP S&M operating expenses | 89,510 |  |  | 59,978 |  |  | 210,516 |  |  | 208,400 |  |
| Stock-based compensation | (12,276) |  |  | (9,923) |  |  | (33,700) |  |  | (27,245) |  |
| Non-GAAP S&M operating expenses | 77,234 |  |  | 50,055 |  |  | 176,816 |  |  | 181,155 |  |
| GAAP G&A operating expenses | 87,643 |  |  | 70,603 |  |  | 221,948 |  |  | 199,488 |  |
| Stock-based compensation | (19,021) |  |  | (13,467) |  |  | (46,368) |  |  | (44,292) |  |
| Non-GAAP G&A operating expenses | 68,622 |  |  | 57,136 |  |  | 175,580 |  |  | 155,196 |  |
| Non-GAAP Operating Expenses | $ | 278,400 |  |  | $ | 215,794 |  |  | $ | 722,040 |  |  | $ | 648,090 |  |

[0001375365-26-000013:8k_2_02:84]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:85]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000013:8k_2_02:86]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:87]
(unaudited)

[0001375365-26-000013:8k_2_02:88]
Reconciliation of GAAP to Non-GAAP Net Income:

[0001375365-26-000013:8k_2_02:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP Net Income - basic | $ | 483,387 |  |  | $ | 108,777 |  |  | $ | 1,052,236 |  |  | $ | 853,700 |  |
| Adjustments related to stock-based compensation: |  |  |  |  |  |  |  |
| Cost of sales | 11,522 |  |  | 7,060 |  |  | 25,400 |  |  | 17,713 |  |
| Operating expenses | 114,412 |  |  | 77,644 |  |  | 280,158 |  |  | 213,127 |  |
| Total adjustments to GAAP income from operations | 125,934 |  |  | 84,704 |  |  | 305,558 |  |  | 230,840 |  |
| Other expense | — |  |  | 30,251 |  |  | — |  |  | 30,251 |  |
| Total adjustments to GAAP Other expense | — |  |  | 30,251 |  |  | — |  |  | 30,251 |  |
| Total adjustments to GAAP income before income tax provision | 125,934 |  |  | 114,955 |  |  | 305,558 |  |  | 261,091 |  |
| Income tax effect of non-GAAP adjustments | (28,713) |  |  | (29,706) |  |  | (70,373) |  |  | (64,715) |  |
| Non-GAAP net income - basic | $ | 580,608 |  |  | $ | 194,026 |  |  | $ | 1,287,421 |  |  | $ | 1,050,076 |  |
| GAAP net income - basic | $ | 483,387 |  |  | $ | 108,777 |  |  | $ | 1,052,236 |  |  | $ | 853,700 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | — |  |  | 16,472 |  |  | 1,777 |  |
| GAAP net income - diluted | $ | 501,275 |  |  | $ | 108,777 |  |  | $ | 1,068,708 |  |  | $ | 855,477 |  |
| Non-GAAP net income - basic | $ | 580,608 |  |  | $ | 194,026 |  |  | $ | 1,287,421 |  |  | $ | 1,050,076 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | — |  |  | 16,472 |  |  | 1,777 |  |
| Non-GAAP net income - diluted | $ | 598,496 |  |  | $ | 194,026 |  |  | $ | 1,303,893 |  |  | $ | 1,051,853 |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic - GAAP | 600,205 |  |  | 595,041 |  |  | 597,928 |  |  | 592,349 |  |
| Basic - Non-GAAP | 600,205 |  |  | 595,041 |  |  | 597,928 |  |  | 592,349 |  |
| Diluted - GAAP | 692,189 |  |  | 621,809 |  |  | 673,598 |  |  | 625,272 |  |
| Non-GAAP adjustment | 16,961 |  |  | 14,108 |  |  | 14,896 |  |  | 11,645 |  |
| Diluted - Non-GAAP | 709,150 |  |  | 635,917 |  |  | 688,494 |  |  | 636,917 |  |

[0001375365-26-000013:8k_2_02:90]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000013:8k_2_02:91]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000013:8k_2_02:92]
(in thousands, except per share amounts)

[0001375365-26-000013:8k_2_02:93]
(unaudited)

[0001375365-26-000013:8k_2_02:94]
Reconciliation of GAAP to Non-GAAP EPS:

[0001375365-26-000013:8k_2_02:95]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP Net Income per common share - basic | $ | 0.81 |  |  | $ | 0.18 |  |  | $ | 1.76 |  |  | $ | 1.44 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |
| Stock-based compensation | 0.21 |  |  | 0.14 |  |  | 0.51 |  |  | 0.39 |  |
| Loss on extinguishment of convertible notes - basic | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Income tax | (0.05) |  |  | (0.04) |  |  | (0.12) |  |  | (0.11) |  |
| Non-GAAP Net Income per common share - basic | $ | 0.97 |  |  | $ | 0.33 |  |  | $ | 2.15 |  |  | $ | 1.77 |  |
| GAAP net income per common share - diluted | $ | 0.72 |  |  | $ | 0.17 |  |  | $ | 1.59 |  |  | $ | 1.37 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |
| Stock-based compensation | 0.16 |  |  | 0.14 |  |  | 0.40 |  |  | 0.33 |  |
| Loss on extinguishment of convertible notes - diluted | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Income tax | (0.04) |  |  | (0.05) |  |  | (0.10) |  |  | (0.10) |  |
| Non-GAAP Net Income per common share – diluted | $ | 0.84 |  |  | $ | 0.31 |  |  | $ | 1.89 |  |  | $ | 1.65 |  |

[0001375365-26-000013:8k_2_02:96]
GAAP to Non-GAAP Effective Tax Rate:

[0001375365-26-000013:8k_2_02:97]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| GAAP effective tax rate | 20.8 | % |  | 5.1 | % |  | 20.2 | % |  | 13.9 | % |
| Total adjustments to GAAP provision to income tax | 0.3 | % |  | 10.4 | % |  | 0.5 | % |  | 2.3 | % |
| Non-GAAP effective tax rate | 21.1 | % |  | 15.5 | % |  | 20.7 | % |  | 16.2 | % |
