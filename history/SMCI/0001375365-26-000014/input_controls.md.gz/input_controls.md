# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001375365-26-000014:item_4_controls:1]
Item 4.   Controls and Procedures

[0001375365-26-000014:item_4_controls:2]
Attached as exhibits to this Quarterly Report on Form 10-Q are certifications of our Chief Executive Officer and Chief Financial Officer, which are required in accordance with Rule 13a-14 of the Exchange Act. This “Controls and Procedures” section includes information concerning the internal controls and controls evaluation referred to in the certifications.

[0001375365-26-000014:item_4_controls:3]
(a) Management’s Evaluation of Disclosure Controls and Procedures

[0001375365-26-000014:item_4_controls:4]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for evaluating the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of March 31, 2026. Our disclosure controls and procedures are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file under the Exchange Act is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure and is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that their objectives are met. Because of the inherent limitations in all control systems, no evaluation of disclosure controls and procedures can provide absolute assurance that all disclosure control issues, if any, have been detected. Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of March 31, 2026 due to the material weaknesses in our internal control over financial reporting, described below, that were previously identified in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 filed on August 28,  2025. Notwithstanding the identified material weaknesses, management believes and has concluded that the condensed consolidated financial statements included in this Quarterly Report fairly present, in all material respects, our financial condition, results of operations, and cash flows for the periods presented in conformity with U.S. GAAP.

[0001375365-26-000014:item_4_controls:5]
(b) Material Weakness in Internal Control over Financial Reporting

[0001375365-26-000014:item_4_controls:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our management, including our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of June 30, 2025. In making this assessment, our management used the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”).

[0001375365-26-000014:item_4_controls:7]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected in a timely basis.

[0001375365-26-000014:item_4_controls:8]
As previously reported in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025, the following material weaknesses in internal control over financial reporting first identified in our Annual Report on Form 10-K for the fiscal year ended June 30, 2024 filed on February 25, 2025, remain unremediated as of March 31, 2026:

[0001375365-26-000014:item_4_controls:9]
(i) information technology general controls ("ITGC") for certain systems that support our financial reporting process were not appropriately identified, designed or implemented; (ii) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (iii) controls over the completeness and accuracy of information we produce, impacting multiple financial statement areas were not properly implemented or documented; and (iv) we did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new related party transactions.

[0001375365-26-000014:item_4_controls:10]
The above material weaknesses could have increased the risk of unauthorized access to certain information technology systems that support our financial reporting processes, manipulation of data that we use to produce our financial statements, and/or lack of complete and accurate information, which could lead to financial misstatements and affect our ability to report our information on a timely basis.

[0001375365-26-000014:item_4_controls:11]
SMCI | Q3 2026 Form 10-Q | 54

[0001375365-26-000014:item_4_controls:12]
Notwithstanding the material weaknesses in internal control over financial reporting described above, management believes and has concluded that the condensed consolidated financial statements included in this Quarterly Report fairly present, in all material respects, our financial condition, results of operations, and cash flows for the periods presented in conformity with U.S. GAAP.

[0001375365-26-000014:item_4_controls:13]
(c) Inherent Limitations on Effectiveness of Controls

[0001375365-26-000014:item_4_controls:14]
Because of inherent limitations, internal control over financial reporting may not prevent or detect misstatements and projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-26-000014:item_4_controls:15]
(d) Remediation Plan and Status

[0001375365-26-000014:item_4_controls:16]
We have identified and implemented specific actions intended to improve the effectiveness of our internal control over financial reporting and disclosure controls and procedures and will continue to do so until the remediation of the material weaknesses identified above is complete, and we are able to conclude that both our internal control over financial reporting and our disclosure controls and procedures are effective. During the quarter and nine months ended March 31, 2026, we made significant progress related to our remediation efforts and began to implement additional changes designed to improve our internal controls over financial reporting and to remediate the material weaknesses, including, but not limited to:

[0001375365-26-000014:item_4_controls:17]
•Continued to successfully monitor and make enhancements as appropriate to the design and effectiveness of our Enterprise Resource Planning (“ERP”) system security role structure and segregation of duties (“SOD”) rulesets, to eliminate or minimize SOD conflicts related issues that collectively contributed to the material weakness. Our security ruleset redesign has significantly simplified our security design, and we believe a combination of the reset and our continuous detective and monitoring procedures will likely successfully remediate the SOD-related material weakness subject to the completion of operating effectiveness testing during fiscal year 2026;

[0001375365-26-000014:item_4_controls:18]
•Over the last few months starting in the quarter ended September 30, 2025 and in particular in the quarter ended March 31, 2026, we have continued to evaluate and review our overall IT architecture, including the composition, appropriateness and upgrades required to our IT organization and applications, to ensure that all applications and systems that are key to the completeness and accuracy of our financial reporting processes were appropriately identified to be part of the population over which we design and maintain ITGCs. During the quarter ended March 2026, we have continued to implement steps towards optimizing our overall IT framework, standardization of processes across infrastructure and security, including establishing stronger governance policies and protocols, user access and change management restrictions. We also continue to make targeted improvements to our Information Technology Service Management (“ITSM”) tool thereby enhancing change management practices, which incorporate more preventative controls, to be supplemented by a continuous monitoring review. We believe these actions will likely allow us to successfully remediate the material weakness we previously identified relating to the deficiencies noted in the design and implementation of ITGC controls for systems that support our financial reporting processes, subject to the completion of operating effectiveness testing during fiscal year 2026; and

[0001375365-26-000014:item_4_controls:19]
•Continuing to enhance our accounting policies and related information provided by entity (“IPE”) documentation, and, as part of the financial reporting process, implementing the use of supplementary checklists as well as conducting additional reviews and evaluations of transactions to improve the accuracy and reliability of our financial information.  We have implemented preventive controls either by way of access restrictions or automated processes to eliminate segregation of duties related risks in some of our processes, thereby enabling us to remediate the deficiencies resulting from manual update permissions that were in place before these enhancements were completed. We also have designed and implemented additional control procedures, including a more comprehensive review of transactions as part of our close process, to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including but not limited to the timely identification and disclosure of new related party transactions, leases among other areas, subject to the completion of operating effectiveness testing during fiscal year 2026.

[0001375365-26-000014:item_4_controls:20]
SMCI | Q3 2026 Form 10-Q | 55

[0001375365-26-000014:item_4_controls:21]
Implementing and maintaining an effective financial reporting system is a continuous effort that requires us to anticipate and react to changes in our business and in the economic and regulatory environments, and to expend significant resources to maintain a financial reporting system that is adequate to satisfy our reporting obligations. As we continue to evaluate and take actions to improve our internal control over financial reporting, we may take additional actions to address control deficiencies or modify certain of the remediation measures described above.

[0001375365-26-000014:item_4_controls:22]
While we have made significant progress to enhance our internal control over financial reporting, we are still in the process of implementing certain additional processes, procedures and controls. We will require additional time to complete implementation, to complete testing and to assess and ensure the long-term sustainability of these procedures. We believe the above actions will be effective in remediating the material weaknesses described above, and we will continue to devote significant time and attention to these remedial efforts. However, the material weaknesses cannot be considered remediated until the applicable remedial controls operate for a sufficient period of time and management has concluded after completion of appropriate testing that these controls are operating effectively.

[0001375365-26-000014:item_4_controls:23]
(e) Changes in Internal Control over Financial Reporting

[0001375365-26-000014:item_4_controls:24]
There were no changes in our internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act, during the quarter ended March 31, 2026 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-26-000014:item_4_controls:25]
However, as noted above, we will continue implementing changes to our internal control over financial reporting to address the material weaknesses described above.
