# SMCI MD&A — 0001375365-23-000028


## mdna

[0001375365-23-000028:mdna:1]
[same as prior period, unchanged from 0001375365-23-000012:mdna:1]

[0001375365-23-000028:mdna:2]
[same as prior period, unchanged from 0001375365-23-000012:mdna:2]

[0001375365-23-000028:mdna:3]
[same as prior period, unchanged from 0001375365-23-000012:mdna:3]

[0001375365-23-000028:mdna:4]
We are a Silicon Valley-based provider of accelerated compute platforms that are application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence (“AI”), 5G and edge computing. Our Total IT Solutions include complete servers, storage systems, modular blade servers, blades, workstations, full rack scale solutions, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-23-000028:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended March 31, 2023 increased to $85.8 million from $77.0 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We also believe that we must continue to expand our software and customer service and support offerings, particularly as we increasingly focus on artificial intelligence/machine learning (“AI”/“ML”) applications and larger enterprise customers. Additionally, we intend to continue to focus on developing our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor, central processing units (“CPU”) and graphics processing units (“GPU”) and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessor, GPU, memory and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-23-000028:mdna:6]
SMCI | Q3 2023 Form 10-Q | 33

[0001375365-23-000028:mdna:7]
[same as prior period, unchanged from 0001375365-23-000012:mdna:7]

[0001375365-23-000028:mdna:8]
The following is a summary of our financial highlights of the third quarter of fiscal year 2023:

[0001375365-23-000028:mdna:9]
•Net sales decreased by 5.3% in the three months ended March 31, 2023 as compared to the three months ended March 31, 2022.

[0001375365-23-000028:mdna:10]
•Gross margin increased to 17.6% in the three months ended March 31, 2023 from 15.5% in the three months ended March 31, 2022.

[0001375365-23-000028:mdna:11]
•Operating expenses increased by 5.2% as compared to the three months ended March 31, 2022 and were equal to 9.9% and 8.9% of net sales in the three months ended March 31, 2023 and 2022, respectively.

[0001375365-23-000028:mdna:12]
•Effective tax rate decreased to 11.1% in the three months ended March 31, 2023 from 17.4% in the three months ended March 31, 2022.

[0001375365-23-000028:mdna:13]
[same as prior period, unchanged from 0001375365-23-000012:mdna:13]

[0001375365-23-000028:mdna:14]
[same as prior period, unchanged from 0001375365-23-000012:mdna:14]

[0001375365-23-000028:mdna:15]
[same as prior period, unchanged from 0001375365-23-000012:mdna:15]

[0001375365-23-000028:mdna:16]
SMCI | Q3 2023 Form 10-Q | 34

[0001375365-23-000028:mdna:17]
[same as prior period, unchanged from 0001375365-23-000012:mdna:17]

[0001375365-23-000028:mdna:18]
[same as prior period, unchanged from 0001375365-23-000012:mdna:18]

[0001375365-23-000028:mdna:19]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 82.4 | % |  | 84.5 | % |  | 81.5 | % |  | 85.6 | % |
| Gross profit | 17.6 | % |  | 15.5 | % |  | 18.5 | % |  | 14.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6.0 | % |  | 5.2 | % |  | 4.5 | % |  | 5.7 | % |
| Sales and marketing | 2.0 | % |  | 1.6 | % |  | 1.7 | % |  | 1.9 | % |
| General and administrative | 1.9 | % |  | 2.0 | % |  | 1.5 | % |  | 2.1 | % |
| Total operating expenses | 9.9 | % |  | 8.9 | % |  | 7.7 | % |  | 9.6 | % |
| Income from operations | 7.7 | % |  | 6.6 | % |  | 10.8 | % |  | 4.8 | % |
| Other income, net | — | % |  | 0.3 | % |  | — | % |  | 0.1 | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 7.6 | % |  | 6.9 | % |  | 10.7 | % |  | 4.8 | % |
| Income tax provision | (0.8) | % |  | (1.2) | % |  | (1.6) | % |  | (0.8) | % |
| Share of income (loss) from equity investee, net of taxes | (0.1) | % |  | — | % |  | (0.1) | % |  | — | % |
| Net income | 6.7 | % |  | 5.7 | % |  | 9.0 | % |  | 4.1 | % |

[0001375365-23-000028:mdna:20]
[same as prior period, unchanged from 0001375365-23-000012:mdna:20]

[0001375365-23-000028:mdna:21]
[same as prior period, unchanged from 0001375365-23-000012:mdna:21]

[0001375365-23-000028:mdna:22]
[same as prior period, unchanged from 0001375365-23-000012:mdna:22]

[0001375365-23-000028:mdna:23]
SMCI | Q3 2023 Form 10-Q | 35

[0001375365-23-000028:mdna:24]
The following table presents net sales by product type for the three and nine months ended March 31, 2023 and 2022 (dollars in millions):

[0001375365-23-000028:mdna:25]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Server and storage systems | $ | 1,163.7 |  |  | $ | 1,145.9 |  |  | $ | 17.8 |  |  | 1.6 | % |  | $ | 4,537.7 |  |  | $ | 2,981.8 |  |  | $ | 1,555.9 |  |  | 52.2 | % |
| Percentage of total net sales | 90.7 | % |  | 84.5 | % |  |  |  |  |  | 91.9 | % |  | 83.7 | % |  |  |  |  |
| Subsystems and accessories | $ | 119.6 |  |  | $ | 209.6 |  |  | $ | (90.0) |  |  | (42.9) | % |  | $ | 400.9 |  |  | $ | 578.9 |  |  | $ | (178.0) |  |  | (30.7) | % |
| Percentage of total net sales | 9.3 | % |  | 15.5 | % |  |  |  |  |  | 8.1 | % |  | 16.3 | % |  |  |  |  |
| Total net sales | $ | 1,283.3 |  |  | $ | 1,355.5 |  |  | $ | (72.2) |  |  | (5.3) | % |  | $ | 4,938.6 |  |  | $ | 3,560.7 |  |  | $ | 1,377.9 |  |  | 38.7 | % |

[0001375365-23-000028:mdna:26]
[same as prior period, unchanged from 0001375365-23-000012:mdna:26]

[0001375365-23-000028:mdna:27]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:28]
The period-over-period increase in net sales of our server and storage systems was due to a 33.1% increase in the average selling price as a result of product mix such as demand for high-performance GPU based server and storage systems.

[0001375365-23-000028:mdna:29]
The period-over-period decrease in net sales for our subsystems and accessories of 42.9% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling them as part of subsystems and accessories.

[0001375365-23-000028:mdna:30]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:31]
The period-over-period increase in net sales of our server and storage systems was due to both a 10.5% increase in the number of servers sold and a 38.9% increase in the average selling price. The increase in the number of servers sold was primarily due to increased demand for our products, including GPU systems.

[0001375365-23-000028:mdna:32]
The period-over-period decrease in net sales for our subsystems and accessories of 30.7% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling the constrained components as part of subsystems and accessories.

[0001375365-23-000028:mdna:33]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2023 and 2022 (dollars in millions):

[0001375365-23-000028:mdna:34]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| United States | $ | 785.5 |  |  | $ | 762.4 |  |  | $ | 23.1 |  |  | 3.0 | % |  | $ | 3,172.5 |  |  | $ | 1,961.6 |  |  | $ | 1,210.9 |  |  | 61.7 | % |
| Percentage of total net sales | 61.2 | % |  | 56.2 | % |  |  |  |  |  | 64.2 | % |  | 55.1 | % |  |  |  |  |
| Asia | $ | 214.4 |  |  | $ | 310.0 |  |  | $ | (95.6) |  |  | (30.8) | % |  | $ | 815.1 |  |  | $ | 857.1 |  |  | $ | (42.0) |  |  | (4.9) | % |
| Percentage of total net sales | 16.7 | % |  | 22.9 | % |  |  |  |  |  | 16.5 | % |  | 24.1 | % |  |  |  |  |
| Europe | $ | 228.5 |  |  | $ | 205.4 |  |  | $ | 23.1 |  |  | 11.2 | % |  | $ | 776.1 |  |  | $ | 600.6 |  |  | $ | 175.5 |  |  | 29.2 | % |
| Percentage of total net sales | 17.8 | % |  | 15.2 | % |  |  |  |  |  | 15.7 | % |  | 16.8 | % |  |  |  |  |
| Others | $ | 54.9 |  |  | $ | 77.7 |  |  | $ | (22.8) |  |  | (29.3) | % |  | $ | 174.9 |  |  | $ | 141.3 |  |  | $ | 33.6 |  |  | 23.8 | % |
| Percentage of total net sales | 4.3 | % |  | 5.7 | % |  |  |  |  |  | 3.6 | % |  | 4.0 | % |  |  |  |  |
| Total net sales | $ | 1,283.3 |  |  | $ | 1,355.5 |  |  |  |  |  |  | $ | 4,938.6 |  |  | $ | 3,560.6 |  |  |  |  |  |

[0001375365-23-000028:mdna:35]
SMCI | Q3 2023 Form 10-Q | 36

[0001375365-23-000028:mdna:36]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:37]
The period-over-period decrease in overall net sales is primarily due to lower sales in Asia region, including China, Taiwan and Korea, partially offset by higher sales in the United States where the increase is primarily due to both high demand and the higher prices for our GPU based server and storage systems. Net sales also increased in Europe, which is primarily driven by increased shipments to Germany, Netherlands, and UK.

[0001375365-23-000028:mdna:38]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:39]
The period-over-period increase in overall net sales is the result of increased selling prices led primarily by higher priced GPU based products and increased quantity of overall product shipments. The increase in the United States is primarily due to higher sales driven by high demand for GPU based server and storage systems. The increase of net sales in Europe was primarily due to increases in net sales in Netherlands, UK and Germany. The decrease of net sales in Asia was primarily due to decreases in net sales in China, Taiwan and Korea partially offset by an increase in net sales in Singapore and Japan.

[0001375365-23-000028:mdna:40]
[same as prior period, unchanged from 0001375365-23-000012:mdna:40]

[0001375365-23-000028:mdna:41]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production as well as efficiencies or leverage gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in average selling prices are not matched by corresponding changes in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions.

[0001375365-23-000028:mdna:42]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-23-000028:mdna:43]
Cost of sales and gross margin for the three and nine months ended March 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000028:mdna:44]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Cost of sales | $ | 1,056.9 |  |  | $ | 1,144.7 |  |  | $ | (87.8) |  |  | (7.7) | % |  | $ | 4,027.3 |  |  | $ | 3,048.0 |  |  | $ | 979.3 |  |  | 32.1 | % |
| Gross profit | $ | 226.4 |  |  | $ | 210.8 |  |  | $ | 15.6 |  |  | 7.4 | % |  | $ | 911.3 |  |  | $ | 512.7 |  |  | $ | 398.6 |  |  | 77.7 | % |
| Gross margin | 17.6 | % |  | 15.5 | % |  |  |  | 2.1 | % |  | 18.5 | % |  | 14.4 | % |  |  |  | 4.1 | % |

[0001375365-23-000028:mdna:45]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:46]
The period-over-period decrease in cost of sales was primarily attributed to a decrease of $78.6 million in costs of materials, key component costs and contract manufacturing expenses, a $18.5 million decrease in freight costs, a $4.2 million decrease in inventory charges, all partially offset by a $13.5 million increase in overhead costs.

[0001375365-23-000028:mdna:47]
The period-over-period increase in the gross margin percentage was primarily due to a higher average selling price and a reduction in the cost of freight and certain key components. These key components included memory, solid-state drives, motherboards and other components.

[0001375365-23-000028:mdna:48]
SMCI | Q3 2023 Form 10-Q | 37

[0001375365-23-000028:mdna:49]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:50]
The period-over-period increase in cost of sales was primarily attributed to an increase of $938.2 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales, a $55.0 million increase in overhead costs, a $17.8 million increase in inventory charges offset by a $31.7 million decrease in freight costs.

[0001375365-23-000028:mdna:51]
The period-over-period increase in the gross margin percentage was primarily due to a reduction in the cost of freight and certain key components as well as efficiencies or leverage gained from higher production volume in our facilities. These key components included memory, hard disk drives, solid-state drives, motherboards and other components.

[0001375365-23-000028:mdna:52]
[same as prior period, unchanged from 0001375365-23-000012:mdna:52]

[0001375365-23-000028:mdna:53]
[same as prior period, unchanged from 0001375365-23-000012:mdna:53]

[0001375365-23-000028:mdna:54]
[same as prior period, unchanged from 0001375365-23-000012:mdna:54]

[0001375365-23-000028:mdna:55]
[same as prior period, unchanged from 0001375365-23-000012:mdna:55]

[0001375365-23-000028:mdna:56]
Operating expenses for the three and nine months ended March 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000028:mdna:57]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Research and development | $ | 77.5 |  |  | $ | 70.9 |  |  | $ | 6.6 |  |  | 9.3 | % |  | $ | 222.4 |  |  | $ | 201.5 |  |  | $ | 20.9 |  |  | 10.4 | % |
| Percentage of total net sales | 6.0 | % |  | 5.2 | % |  |  |  |  |  | 4.5 | % |  | 5.7 | % |  |  |  |  |
| Sales and marketing | $ | 25.3 |  |  | $ | 22.4 |  |  | $ | 2.9 |  |  | 12.9 | % |  | $ | 83.1 |  |  | $ | 65.9 |  |  | $ | 17.2 |  |  | 26.1 | % |
| Percentage of total net sales | 2.0 | % |  | 1.6 | % |  |  |  |  |  | 1.7 | % |  | 1.9 | % |  |  |  |  |
| General and administrative | $ | 24.5 |  |  | $ | 27.8 |  |  | $ | (3.3) |  |  | (11.9) | % |  | $ | 71.4 |  |  | $ | 75.3 |  |  | $ | (3.9) |  |  | (5.2) | % |
| Percentage of total net sales | 1.8 | % |  | 2.0 | % |  |  |  |  |  | 1.3 | % |  | 2.1 | % |  |  |  |  |
| Total operating expenses | $ | 127.3 |  |  | $ | 121.0 |  |  | $ | 6.3 |  |  | 5.2 | % |  | $ | 376.9 |  |  | $ | 342.7 |  |  | $ | 34.2 |  |  | 10.0 | % |
| Percentage of total net sales | 9.9 | % |  | 8.9 | % |  |  |  |  |  | 7.6 | % |  | 9.6 | % |  |  |  |  |

[0001375365-23-000028:mdna:58]
SMCI | Q3 2023 Form 10-Q | 38

[0001375365-23-000028:mdna:59]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:60]
Research and development expenses. The period-over-period increase in research and development expenses was due to a $11.4 million increase in personnel expenses primarily due to increase in headcount partially offset by a $3.4 million higher research and development credits provided from certain suppliers and customers for our development efforts and a $1.4 million decrease in product development costs.

[0001375365-23-000028:mdna:61]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was due to a $3.5 million increase in personnel expenses primarily due to an increase in headcount partially offset by a $0.6 million lower advertising and other expenses.

[0001375365-23-000028:mdna:62]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a $2.3 million decrease in legal and litigation settlement expenses and a decrease of $1.0 million in personnel related expenses and other expenses.

[0001375365-23-000028:mdna:63]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:64]
Research and development expenses. The period-over-period increase in research and development expenses was due to a $31.7 million increase in personnel expenses primarily due to increase in headcount and equity awards offset by a $10.8 million higher research and development credits from certain suppliers and customers towards our development efforts.

[0001375365-23-000028:mdna:65]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $15.7 million increase in personnel expenses due to an increase in headcount and equity awards and an increase of a $1.5 million in advertising and other expenses.

[0001375365-23-000028:mdna:66]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a $4.4 million decrease in legal and litigation settlement expenses partially offset by an increase of $0.5 million in personnel expenses and other expenses.

[0001375365-23-000028:mdna:67]
[same as prior period, unchanged from 0001375365-23-000012:mdna:67]

[0001375365-23-000028:mdna:68]
[same as prior period, unchanged from 0001375365-23-000012:mdna:68]

[0001375365-23-000028:mdna:69]
[same as prior period, unchanged from 0001375365-23-000012:mdna:69]

[0001375365-23-000028:mdna:70]
Interest expense and other (expense) income, net for the three and nine months ended March 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000028:mdna:71]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Other (expense) income, net | $ | (0.1) |  |  | $ | 4.7 |  |  | $ | (4.8) |  |  | (102.1) | % |  | $ | 1.6 |  |  | $ | 4.1 |  |  | $ | (2.5) |  |  | (61.0) | % |
| Interest expense | (1.3) |  |  | (1.5) |  |  | 0.2 |  |  | (13.3) | % |  | (6.9) |  |  | (3.5) |  |  | (3.4) |  |  | 97.1 | % |
| Interest expense and other (expense) income, net | $ | (1.4) |  |  | $ | 3.2 |  |  | $ | (4.6) |  |  | (143.8) | % |  | $ | (5.3) |  |  | $ | 0.6 |  |  | $ | (5.9) |  |  | (983.3) | % |

[0001375365-23-000028:mdna:72]
SMCI | Q3 2023 Form 10-Q | 39

[0001375365-23-000028:mdna:73]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:74]
The change of $4.6 million in interest expense and other expense, net was primarily attributable to a $4.8 million increase in foreign exchange loss due to unfavorable currency fluctuations and a $0.2 million decrease in interest expense due to decrease in loan balances.

[0001375365-23-000028:mdna:75]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:76]
The change of $5.9 million in interest expense and other (expense) income, net was primarily attributable to a $2.5 million increase in foreign exchange loss due to unfavorable currency fluctuations and a $3.4 million increase in interest expense due to an increase in interest rates on outstanding balances.

[0001375365-23-000028:mdna:77]
[same as prior period, unchanged from 0001375365-23-000012:mdna:77]

[0001375365-23-000028:mdna:78]
[same as prior period, unchanged from 0001375365-23-000012:mdna:78]

[0001375365-23-000028:mdna:79]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000028:mdna:80]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Income tax provision | $ | 10.9 |  |  | $ | 16.2 |  |  | $ | (5.3) |  |  | (32.7) | % |  | $ | 79.4 |  |  | $ | 27.1 |  |  | $ | 52.3 |  |  | 193.0 | % |
| Percentage of total net sales | 0.8 | % |  | 1.2 | % |  |  |  |  |  | 1.6 | % |  | 0.8 | % |  |  |  |  |
| Effective tax rate | 11.1 | % |  | 17.4 | % |  |  |  |  |  | 15.0 | % |  | 15.9 | % |  |  |  |  |

[0001375365-23-000028:mdna:81]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:82]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended March 31, 2023, is lower than that for the three months ended March 31, 2022, primarily due to a significant increase in tax-deductible stock compensation expense in the three months ended March 31, 2023.

[0001375365-23-000028:mdna:83]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:84]
The income tax provision increased for the nine months ended March 31, 2023, compared to the nine months ended March 31, 2022, while the effective tax rate for the same period is lower than that of last year. The primary reason for the higher income tax provision is the significant increase in income before tax for the nine months ended March 31, 2023, compared to the nine months ended March 31, 2022. The income tax rate was lower due to higher deductible stock compensation expense for the nine months ended March 31, 2023 compared to the nine months ended March 31, 2022.

[0001375365-23-000028:mdna:85]
[same as prior period, unchanged from 0001375365-23-000012:mdna:85]

[0001375365-23-000028:mdna:86]
[same as prior period, unchanged from 0001375365-23-000012:mdna:86]

[0001375365-23-000028:mdna:87]
SMCI | Q3 2023 Form 10-Q | 40

[0001375365-23-000028:mdna:88]
Share of (loss) income from equity investee, net of taxes for the three and nine months ended March 31, 2023 and 2022 are as follows (dollars in millions):

[0001375365-23-000028:mdna:89]
|  | Three Months EndedMarch 31, |  | Change | Nine Months EndedMarch 31, |  | Change |
|  | 2023 |  | 2022 |  | $ |  | % |  | 2023 |  | 2022 |  | $ |  | % |
| Share of (loss) income from equity investee, net of taxes | $ | (1.0) |  |  | $ | 0.3 |  |  | $ | (1.3) |  |  | n/m (1) |  | $ | (3.3) |  |  | $ | 0.9 |  |  | $ | (4.2) |  |  | n/m (1) |
| Percentage of total net sales | (0.1) | % |  | 0.02 | % |  |  |  |  |  | (0.1) | % |  | 0.02 | % |  |  |  |  |

[0001375365-23-000028:mdna:90]
[same as prior period, unchanged from 0001375365-23-000012:mdna:90]

[0001375365-23-000028:mdna:91]
Comparison of Three Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:92]
The period-over-period decrease of $1.3 million in share of (loss) income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-23-000028:mdna:93]
Comparison of Nine Months Ended March 31, 2023 and 2022

[0001375365-23-000028:mdna:94]
The period-over-period decrease of $4.2 million in share of (loss) income from equity investee, net of taxes was primarily due to less net income recognized by the Corporate Venture.

[0001375365-23-000028:mdna:95]
[same as prior period, unchanged from 0001375365-23-000012:mdna:95]

[0001375365-23-000028:mdna:96]
We have financed our growth primarily with funds generated from increased profits from operations, in addition to utilizing borrowing facilities. We draw on our credit facilities to fund working capital requirements due to the higher level of inventories and accounts receivable based on increasing sales as well as to finance the acquisition of property, plant and equipment. We also receive funds from the exercise of employee stock options. Our cash and cash equivalents were $362.8 million and $267.4 million as of March 31, 2023 and June 30, 2022, respectively. Our cash in foreign locations was $210.7 million and $169.5 million as of March 31, 2023 and June 30, 2022, respectively.

[0001375365-23-000028:mdna:97]
[same as prior period, unchanged from 0001375365-23-000012:mdna:97]

[0001375365-23-000028:mdna:98]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the filing of this Quarterly Report on Form 10-Q. In August 2022, we entered into a new general credit agreement with E.SUN Bank. This New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US$30.0 million in loans that will support the growth of our Taiwan business. On February 7, 2023, we also entered into a new Facility Letter (the “New Facility Letter”) with the Taiwan affiliate of HSBC Bank. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD300 million and an export/seller facility with a sub-limit of $50 million.

[0001375365-23-000028:mdna:99]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. We repurchased 1,553,350 shares of common stock for $150 million during the three months ended March 31, 2023 under this program and had $50.0 million of remaining availability as of March 31, 2023.

[0001375365-23-000028:mdna:100]
SMCI | Q3 2023 Form 10-Q | 41

[0001375365-23-000028:mdna:101]
[same as prior period, unchanged from 0001375365-23-000012:mdna:101]

[0001375365-23-000028:mdna:102]
|  | Nine Months EndedMarch 31, |  | Change |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 672.9 |  |  | $ | (415.7) |  |  | $ | 1,088.6 |  |  |  |  |
| Net cash (used in) investing activities | $ | (28.6) |  |  | $ | (35.3) |  |  | $ | 6.7 |  |  |  |  |
| Net cash (used in) provided by financing activities | $ | (547.3) |  |  | $ | 466.4 |  |  | $ | (1,013.7) |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 94.7 |  |  | $ | 15.1 |  |  | $ | 79.6 |  |  |  |  |

[0001375365-23-000028:mdna:103]
[same as prior period, unchanged from 0001375365-23-000012:mdna:103]

[0001375365-23-000028:mdna:104]
Net cash provided by operating activities increased by $1,088.6 million for the nine months ended March 31, 2023 as compared to the nine months ended March 31, 2022. The increase was primarily due to an increase in net income of $302.1 million, an increase of $383.0 million from the collection of accounts receivables from higher sales, an increase of $535.2 million related to lower levels of inventory needed from an improved supply chain, offset by a decrease of $101.7 million in other working capital items and a decrease of $30.0 million in various non-cash items in the nine months ended March 31, 2023.

[0001375365-23-000028:mdna:105]
[same as prior period, unchanged from 0001375365-23-000012:mdna:105]

[0001375365-23-000028:mdna:106]
Net cash used in investing activities decreased by $6.7 million for the nine months ended March 31, 2023 as compared to the nine months ended March 31, 2022 primarily due to decrease in purchases of property, plant and equipment in the nine months ended March 31, 2023.

[0001375365-23-000028:mdna:107]
[same as prior period, unchanged from 0001375365-23-000012:mdna:107]

[0001375365-23-000028:mdna:108]
Net cash used in financing activities for the nine months ended March 31, 2023 was $547.3 million while net cash provided by financing activities for the nine months ended March 31, 2022 was $466.4 million. The change in cash flows from financing activities of $1,013.7 million was primarily due to a decrease of $773.7 million in proceeds from borrowings, an increase of $89.7 million in repayment of debt and stock repurchases of $146.5 million.

[0001375365-23-000028:mdna:109]
[same as prior period, unchanged from 0001375365-23-000012:mdna:109]

[0001375365-23-000028:mdna:110]
[same as prior period, unchanged from 0001375365-23-000012:mdna:110]

[0001375365-23-000028:mdna:111]
[same as prior period, unchanged from 0001375365-23-000012:mdna:111]

[0001375365-23-000028:mdna:112]
We anticipate our capital expenditures for the remainder of fiscal year 2023 will be in range of $11 million to $14 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We evaluated an expansion of our manufacturing into Malaysia, and during the second quarter of fiscal year 2023 entered into a letter of understanding to acquire land in Malaysia. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. We are obtaining early access to such land prior to acquisition, and we anticipate additional future capital expenditures for the remainder of fiscal year 2023 of $6 million (included in the above range) for such initiative. In addition, we will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-23-000028:mdna:113]
[same as prior period, unchanged from 0001375365-23-000012:mdna:113]

[0001375365-23-000028:mdna:114]
SMCI | Q3 2023 Form 10-Q | 42

[0001375365-23-000028:mdna:115]
[same as prior period, unchanged from 0001375365-23-000012:mdna:115]

[0001375365-23-000028:mdna:116]
[same as prior period, unchanged from 0001375365-23-000012:mdna:116]

[0001375365-23-000028:mdna:117]
SMCI | Q3 2023 Form 10-Q | 43
