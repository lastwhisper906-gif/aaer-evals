# SMCI notes — 0001375365-23-000028


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-23-000028:notes:1]
[same as prior period, unchanged from 0001375365-23-000012:notes:1]

[0001375365-23-000028:notes:2]
[same as prior period, unchanged from 0001375365-23-000012:notes:2]

[0001375365-23-000028:notes:3]
[same as prior period, unchanged from 0001375365-23-000012:notes:3]

[0001375365-23-000028:notes:4]
[same as prior period, unchanged from 0001375365-23-000012:notes:4]

[0001375365-23-000028:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2023.

[0001375365-23-000028:notes:6]
[same as prior period, unchanged from 0001375365-23-000012:notes:6]

[0001375365-23-000028:notes:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 16.9% and 26.9% of total purchases for the three months ended March 31, 2023, and the same two suppliers accounted for 13.0% and 19.4% of total purchases for the three months ended March 31, 2022. Two suppliers accounted for 15.8% and 23.6% of total purchases for the nine months ended March 31, 2023, and the same two suppliers accounted for 18.0% and 11.4% of total purchases for the nine months ended March 31, 2022. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 8.3% and 8.2% of total cost of sales for the three months ended March 31, 2023 and 2022, respectively, and a combined 7.0% and 9.0% of total cost of sales for the nine months ended March 31, 2023 and 2022, respectively.

[0001375365-23-000028:notes:8]
[same as prior period, unchanged from 0001375365-23-000012:notes:8]

[0001375365-23-000028:notes:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. One customer accounted for 10.7% of the net sales for the three months ended March 31, 2023, and one customer accounted for 11.8% of the net sales for the nine months ended March 31, 2023. One customer accounted for 10.2% of the net sales for the three months ended March 31, 2022 and no single customer accounted for 10% or more of the net sales for the nine months ended March 31, 2022. One customer accounted for 21.0% of the Company's accounts receivable, net as of March 31, 2023. One customer accounted for 21.7% of the Company's accounts receivable, net as of June 30, 2022.

[0001375365-23-000028:notes:10]
Treasury Stock

[0001375365-23-000028:notes:11]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-23-000028:notes:12]
[same as prior period, unchanged from 0001375365-23-000012:notes:10]

[0001375365-23-000028:notes:13]
[same as prior period, unchanged from 0001375365-23-000012:notes:11]

[0001375365-23-000028:notes:14]
[same as prior period, unchanged from 0001375365-23-000012:notes:12]

[0001375365-23-000028:notes:15]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendments in this update do not apply to contract modifications made after December 31, 2022, new hedging relationships entered into after December 31, 2022, and existing hedging relationships evaluated for effectiveness in periods after December 31, 2022, except for hedging relationships existing as of December 31, 2022 that apply certain optional expedients in which the accounting effects are recorded through the end of the hedging relationship. The amendment was effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. In December 2022, FASB issued an Accounting Standards Update (ASU) for the deferral of the sunset date of Topic 848 and amendments to the definition of secured overnight financing rate (“SOFR"). The ASU defers the sunset date of Topic 848 to December 31, 2024. The Company has loans and lines of credit with various financial institutions. Benchmark interest rates are used to calculate the interest on borrowings under the Chang Hwa Bank, CTBC, HSBC, ESUN and Mega Bank Credit Facilities. LIBOR was used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 to provide for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and update provisions relating to payments and LIBOR replacement mechanics to SOFR. As these amendments had other contemporaneous changes to the facility, including the amount of borrowings permitted under the facility and not just directly related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of the adoption of this guidance and does not expect it to have a material impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-23-000028:notes:16]
[same as prior period, unchanged from 0001375365-23-000012:notes:14]

[0001375365-23-000028:notes:17]
[same as prior period, unchanged from 0001375365-23-000012:notes:15]

[0001375365-23-000028:notes:18]
[same as prior period, unchanged from 0001375365-23-000012:notes:16]

[0001375365-23-000028:notes:19]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 1,163,723 |  |  | $ | 1,145,869 |  |  | $ | 4,537,710 |  |  | $ | 2,981,777 |  |
| Subsystems and accessories | 119,573 |  |  | 209,621 |  |  | 400,911 |  |  | 578,862 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |

[0001375365-23-000028:notes:20]
[same as prior period, unchanged from 0001375365-23-000012:notes:18]

[0001375365-23-000028:notes:21]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2023 and 2022, of net sales by geographic region (in thousands):

[0001375365-23-000028:notes:22]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 785,548 |  |  | $ | 762,418 |  |  | $ | 3,172,444 |  |  | $ | 1,961,573 |  |
| Asia | 214,363 |  |  | 309,972 |  |  | 815,098 |  |  | 857,165 |  |
| Europe | 228,531 |  |  | 205,444 |  |  | 776,138 |  |  | 600,589 |  |
| Other | 54,854 |  |  | 77,656 |  |  | 174,941 |  |  | 141,312 |  |
| Total | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |

[0001375365-23-000028:notes:23]
[same as prior period, unchanged from 0001375365-23-000012:notes:21]

[0001375365-23-000028:notes:24]
[same as prior period, unchanged from 0001375365-23-000012:notes:22]

[0001375365-23-000028:notes:25]
[same as prior period, unchanged from 0001375365-23-000012:notes:23]

[0001375365-23-000028:notes:26]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2023, which was included in the deferred revenue balance as of June 30, 2022, of $233.8 million, was $25.2 million and $86.2 million, respectively.

[0001375365-23-000028:notes:27]
Deferred revenue increased $76.1 million as of March 31, 2023 as compared to the fiscal year ended June 30, 2022 was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $2.4 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-23-000028:notes:28]
[same as prior period, unchanged from 0001375365-23-000012:notes:26]

[0001375365-23-000028:notes:29]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2023 was $309.9 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-23-000028:notes:30]
[same as prior period, unchanged from 0001375365-23-000012:notes:28]

[0001375365-23-000028:notes:31]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses paid to Company employees. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

[0001375365-23-000028:notes:32]
[same as prior period, unchanged from 0001375365-23-000012:notes:30]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-23-000028:notes:33]
The following is a summary for the three and nine months ended March 31, 2023 and 2022, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-23-000028:notes:34]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2023 and 2022 (in thousands, except per share amounts):

[0001375365-23-000028:notes:35]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 85,846 |  |  | $ | 76,972 |  |  | $ | 446,429 |  |  | $ | 144,341 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 53,280 |  |  | 51,708 |  |  | 53,011 |  |  | 51,269 |  |
| Effect of dilutive securities | 2,953 |  |  | 2,078 |  |  | 2,785 |  |  | 2,132 |  |
| Weighted-average diluted shares | 56,233 |  |  | 53,786 |  |  | 55,796 |  |  | 53,401 |  |
| Basic net income per common share | $ | 1.61 |  |  | $ | 1.49 |  |  | $ | 8.42 |  |  | $ | 2.82 |  |
| Diluted net income per common share | $ | 1.53 |  |  | $ | 1.43 |  |  | $ | 8.00 |  |  | $ | 2.70 |  |

[0001375365-23-000028:notes:36]
For the three and nine months ended March 31, 2023 and 2022, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 187,358 and 452,611 for the three months ended March 31, 2023 and 2022, respectively, and 235,494 and 452,182 for the nine months ended March 31, 2023 and 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-23-000028:notes:37]
[same as prior period, unchanged from 0001375365-23-000012:notes:35]

[0001375365-23-000028:notes:38]
[same as prior period, unchanged from 0001375365-23-000012:notes:36]

[0001375365-23-000028:notes:39]
|  | March 31, 2023 |  | June 30, 2022 |
| Finished goods | $ | 1,075,482 |  |  | $ | 1,025,555 |  |
| Work in process | 159,994 |  |  | 209,576 |  |
| Purchased parts and raw materials | 304,943 |  |  | 310,475 |  |
| Total inventories | $ | 1,540,419 |  |  | $ | 1,545,606 |  |

[0001375365-23-000028:notes:40]
During the three and nine months ended March 31, 2023, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $6.0 million and $31.4 million, respectively, and $10.2 million and $13.9 million, for the three and nine months ended March 31, 2022, respectively. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.

[0001375365-23-000028:notes:41]
[same as prior period, unchanged from 0001375365-23-000012:notes:39]

[0001375365-23-000028:notes:42]
|  | March 31, 2023 |  | June 30, 2022 |
| Other receivables (1) | $ | 110,712 |  |  | $ | 138,054 |  |
| Prepaid expenses | 8,724 |  | 5,632 |
| Deferred service costs | 6,476 |  | 5,562 |
| Prepaid income tax | 1,522 |  |  | 2,352 |
| Restricted cash | — |  |  | 251 |  |
| Other | 12,466 |  |  | 6,948 |  |
| Total prepaid expenses and other current assets | $ | 139,900 |  |  | $ | 158,799 |  |

[0001375365-23-000028:notes:43]
(1) Other receivables are receivables from contract manufacturers based on certain buy-sell arrangements of $81.0 million and $98.9 million as of March 31, 2023 and June 30, 2022, respectively.

[0001375365-23-000028:notes:44]
[same as prior period, unchanged from 0001375365-23-000012:notes:42]

[0001375365-23-000028:notes:45]
|  | March 31, 2023 |  | June 30, 2022 |
| Cash and cash equivalents | $ | 362,801 |  |  | $ | 267,397 |  |
| Restricted cash included in prepaid expenses and other current assets | — |  |  | 251 |  |
| Restricted cash included in other assets | 499 |  |  | 911 |  |
| Total cash, cash equivalents and restricted cash | $ | 363,300 |  |  | $ | 268,559 |  |

[0001375365-23-000028:notes:46]
[same as prior period, unchanged from 0001375365-23-000012:notes:44]

[0001375365-23-000028:notes:47]
|  | March 31, 2023 |  | June 30, 2022 |
| Buildings | $ | 143,496 |  |  | $ | 143,509 |  |
| Machinery and equipment | 128,465 |  |  | 113,665 |  |
| Land | 86,279 |  |  | 84,616 |  |
| Building and leasehold improvements | 52,295 |  |  | 45,169 |  |
| Furniture and fixtures | 42,318 |  |  | 43,282 |  |
| Software | 23,975 |  |  | 23,186 |  |
| Building construction in progress | 303 |  |  | 303 |  |
|  | 477,131 |  |  | 453,730 |  |
| Accumulated depreciation and amortization | (187,093) |  |  | (167,758) |  |
| Property, plant and equipment, net | $ | 290,038 |  |  | $ | 285,972 |  |

[0001375365-23-000028:notes:48]
[same as prior period, unchanged from 0001375365-23-000012:notes:46]

[0001375365-23-000028:notes:49]
|  | March 31, 2023 |  | June 30, 2022 |
| Operating lease right-of-use asset | $ | 19,514 |  |  | $ | 23,679 |  |
| Deferred service costs, non-current | 9,315 |  |  | 6,316 |  |
| Investment in equity investee | 2,494 |  | 5,329 |  |
| Prepaid expense, non-current | 1,908 |  |  | 2,011 |  |
| Deposits | 1,729 |  | 1,069 |  |
| Investment in auction rate security | 1,590 |  |  | 1,590 |  |
| Restricted cash, non-current | 499 |  |  | 911 |  |
| Other | 1,784 |  |  | 1,956 |  |
| Total other assets | $ | 38,833 |  |  | $ | 42,861 |  |

[0001375365-23-000028:notes:50]
[same as prior period, unchanged from 0001375365-23-000012:notes:48]

[0001375365-23-000028:notes:51]
|  | March 31, 2023 |  | June 30, 2022 |
| Accrued payroll and related expenses | $ | 34,058 |  |  | $ | 57,736 |  |
| Contract manufacturers liabilities | 30,013 |  |  | 41,125 |  |
| Customer deposits | 18,152 |  |  | 30,421 |  |
| Accrued warranty costs | 9,704 |  | 9,073 |  |
| Accrued cooperative marketing expenses | 9,000 |  |  | 8,757 |  |
| Operating lease liability | 7,143 |  |  | 7,139 |  |
| Accrued professional fees | 1,867 |  |  | 4,281 |  |
| Accrued legal liabilities (Note 11) | — |  |  | 18,250 |  |
| Other | 45,287 |  |  | 35,637 |  |
| Total accrued liabilities | $ | 155,224 |  |  | $ | 212,419 |  |

[0001375365-23-000028:notes:52]
[same as prior period, unchanged from 0001375365-23-000012:notes:50]

[0001375365-23-000028:notes:53]
In March 2020, the Board of Directors (the “Board”) approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments would be earned when specified market and performance conditions are achieved.

[0001375365-23-000028:notes:54]
The Chief Executive Officer’s total cash bonus opportunity was $8.1 million, divided into two equal tranches. Each tranche would be earned if the average closing price for the Company’s common stock reached specified targets. The Board retained the flexibility to reduce the amount payable under the first tranche (but not the second tranche) based on performance goals. Both price targets were reached during the fiscal year ended June 30, 2021, and the second tranche total of $4.0 million was paid in full. As of June 30, 2021, the Company also expected it would likely pay the first tranche in full, and therefore recorded an expense of $3.6 million since March 2020 relating to the first tranche.

[0001375365-23-000028:notes:55]
In September 2021, after the Company had closed its books for the year ended June 30, 2021, the Board decided to exercise its discretion to reduce the amount to be paid to the Chief Executive Officer for the first tranche to $2.0 million, which was paid in the quarter ended December 31, 2021. As a result of the Board’s decision to reduce the amount to be paid under the first tranche, the Company adjusted the $3.6 million expense previously recorded for the first tranche to the new amount of $2.0 million, which resulted in the Company recognizing a $1.6 million benefit from this adjustment during the quarter ended September 30, 2021. This performance award to the Chief Executive Officer was concluded in the year ended June 30, 2022. As such, there is no further transaction thereafter. There was no expense or benefit recognized during the three and nine months ended March 31, 2023. The benefit recognized during the three and nine months ended March 31, 2022 was none and $1.6 million, respectively.

[0001375365-23-000028:notes:56]
[same as prior period, unchanged from 0001375365-23-000012:notes:54]

[0001375365-23-000028:notes:57]
|  | March 31, 2023 |  | June 30, 2022 |
| Accrued unrecognized tax benefits including related interests and penalties, non-current | $ | 18,865 |  |  | $ | 18,866 |  |
| Operating lease liability, non-current | 12,668 |  | 16,661 |
| Accrued warranty costs, non-current | 5,268 |  |  | 3,064 |  |
| Other | 439 |  |  | 549 |  |
| Total other long-term liabilities | $ | 37,240 |  |  | $ | 39,140 |  |

[0001375365-23-000028:notes:58]
[same as prior period, unchanged from 0001375365-23-000012:notes:56]

[0001375365-23-000028:notes:59]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Balance, beginning of the period | $ | 13,276 |  |  | $ | 11,583 |  |  | $ | 12,136 |  |  | $ | 12,863 |  |
| Provision for warranty | 9,419 |  |  | 7,514 |  |  | 26,969 |  |  | 19,956 |  |
| Costs utilized | (8,100) |  |  | (7,797) |  |  | (25,126) |  |  | (21,717) |  |
| Change in estimated liability for pre-existing warranties | 377 |  |  | 695 |  |  | 993 |  |  | 893 |  |
| Balance, end of the period | 14,972 |  |  | 11,995 |  |  | 14,972 |  |  | 11,995 |  |
| Current portion | 9,704 |  |  | 9,322 |  |  | 9,704 |  |  | 9,322 |  |
| Non-current portion | $ | 5,268 |  |  | $ | 2,673 |  |  | $ | 5,268 |  |  | $ | 2,673 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-23-000028:notes:60]
Fair Value DisclosureThe financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2023 and June 30, 2022. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-23-000028:notes:61]
[same as prior period, unchanged from 0001375365-23-000012:notes:59]

[0001375365-23-000028:notes:62]
The following table sets forth the Company’s financial instruments as of March 31, 2023 and June 30, 2022, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-23-000028:notes:63]
| March 31, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,605 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,605 |  |
| Certificates of deposit (2) | — |  |  | 466 |  |  | — |  |  | 466 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,605 |  |  | $ | 466 |  |  | $ | 1,590 |  |  | $ | 22,661 |  |
| June 30, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,220 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,220 |  |
| Certificates of deposit (2) | — |  |  | 832 |  |  | — |  |  | 832 |  |
| Auction rate security | — |  |  | — |  |  | 1,590 |  |  | 1,590 |  |
| Total assets measured at fair value | $ | 20,220 |  |  | $ | 832 |  |  | $ | 1,590 |  |  | $ | 22,642 |  |

[0001375365-23-000028:notes:64]
(1) $20.5 million and $20.0 million in money market funds are included cash and cash equivalents and $0.1 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2023 and June 30, 2022, respectively.

[0001375365-23-000028:notes:65]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.1 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.2 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2023 and June 30, 2022, respectively.

[0001375365-23-000028:notes:66]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. Based on this assessment during the three and nine months ended March 31, 2023, there were no indications that the Company’s investments had credit losses.

[0001375365-23-000028:notes:67]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2023 and 2022.

[0001375365-23-000028:notes:68]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and nine months ended March 31, 2023 and 2022.

[0001375365-23-000028:notes:69]
The following is a summary of the Company’s investment in an auction rate security as of March 31, 2023 and June 30, 2022 (in thousands):

[0001375365-23-000028:notes:70]
[same as prior period, unchanged from 0001375365-23-000012:notes:68]

[0001375365-23-000028:notes:71]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and nine months ended March 31, 2023 and 2022.

[0001375365-23-000028:notes:72]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2023 and June 30, 2022, total debt of $187.2 million and $596.8 million, respectively, was reported at amortized cost. This outstanding debt was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-23-000028:notes:73]
[same as prior period, unchanged from 0001375365-23-000012:notes:71]

[0001375365-23-000028:notes:74]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $1.2 million as of March 31, 2023 and June 30, 2022. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three and nine months ended March 31, 2023 and 2022, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three and nine months ended March 31, 2023 and 2022.


## us-gaap:DebtDisclosureTextBlock

[0001375365-23-000028:notes:75]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands):

[0001375365-23-000028:notes:76]
|  | March 31, |  | June 30, |
|  | 2023 |  | 2022 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | 20,000 |  |  | $ | 268,245 |  |
| 2022 Bank of America Credit Facility | — |  |  | 9,500 |  |
| Cathay Bank Line of Credit | — |  |  | 30,000 |  |
| 2021 CTBC Credit Lines | — |  |  | 84,800 |  |
| HSBC Bank Credit Facility | — |  |  | 30,000 |  |
| 2021 E.SUN Bank Credit Facility | — |  |  | 7,800 |  |
| Mega Bank Credit Facility | — |  |  | 3,500 |  |
| Total line of credit | 20,000 |  |  | 433,845 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 29,405 |  |  | 33,643 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,390 |  |  | 40,372 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 5,189 |  |  | 5,468 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 36,764 |  |  | 43,064 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 17,069 |  |  | — |  |
| Mega Bank Credit Facility, due September 15, 2026 | 39,390 |  |  | 40,372 |  |
| Total term loans | 167,207 |  |  | 162,919 |  |
| Total debt | 187,207 |  |  | 596,764 |  |
| Short-term debt and current portion of long-term debt | 53,972 |  |  | 449,146 |  |
| Debt, non-current | $ | 133,235 |  |  | $ | 147,618 |  |

[0001375365-23-000028:notes:77]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-23-000028:notes:78]
Available borrowings and interest rates as of March 31, 2023 and June 30, 2022 consisted of the following (in thousands except for percentages):

[0001375365-23-000028:notes:79]
|  | March 31, 2023 |  | June 30, 2022 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 330,000 |  | 6.04% |  | $ | 81,755 |  | 2.53% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 3.36% |  | $ | 10,500 |  | 1.85% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 6.87% |  | $ | 102,000 |  | 4.00% |
| 2021 CTBC Credit Lines | $ | — |  | — |  | $ | 20,200 |  | 1.80% - 2.52% |
| 2022 CTBC Credit Line | $ | 105,000 |  | 3.33% |  | $ | — |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  | 6.23% |  | $ | 20,000 |  | 3.50% |
| HSBC Bank Credit Facility | $ | 50,000 |  | 4.50% |  | $ | — |  | 1.95% - 2.20% |
| 2021 E.SUN Bank Credit Facility | $ | — |  | — |  | $ | 22,200 |  | 1.80% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  | 4.18% |  | $ | — |  | — |
| Mega Bank Credit Facility | $ | 20,000 |  | 2.55% |  | $ | 16,500 |  | 1.85% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.55% |  | $ | — |  | 1.18% |
| CTBC Bank term loan, due June 4, 2030 | $ | — |  | 1.20% |  | $ | — |  | 0.83% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  | 1.40% |  | $ | 6,308 |  | 1.03% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | 5,250 |  | 1.75% |  | $ | 10,766 |  | 1.37% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  | 1.75% |  | $ | — |  | — |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  | 1.40% - 1.60% |  | $ | — |  | 1.02% - 1.22% |

[0001375365-23-000028:notes:80]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 9. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022 for a more complete description of the Company's credit facilities.

[0001375365-23-000028:notes:81]
The Company entered into new agreements during the nine months ended March 31, 2023 with the following terms:

[0001375365-23-000028:notes:82]
E.SUN Bank

[0001375365-23-000028:notes:83]
2022 E.SUN Bank Credit Facility

[0001375365-23-000028:notes:84]
On August 9, 2022 (the “New E.SUN Bank Effective Date”), the Company through Super Micro Computer Inc., Taiwan, a Taiwan corporation and wholly-owned subsidiary of the Company (the “Taiwan Subsidiary”), entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “New E.SUN Bank Credit Facility”). The New E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1.8 billion ($61.0 million U.S. dollar equivalent) and (ii) US $30.0 million. Other terms of the New E.SUN Bank Credit Facility are substantially identical to the prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the New E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as TAIFX) plus a fixed margin and is subject to occasional adjustment. The New E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan Subsidiary has an overdue liability at another financial organization. The Company is not a guarantor of the New E.SUN Bank Credit Facility.

[0001375365-23-000028:notes:85]
Terms for specific drawdown instruments issued under the New E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. Under a Notification and Confirmation entered into on the New E.SUN Bank Effective Date, the Taiwan Subsidiary and E.SUN Bank have agreed to both a Medium Term Credit Loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”) and a drawdown of US $30.0 million under the New E.SUN Bank Credit Facility for an import loan with a tenor of 120 days (the “Import O/A Loan”). With respect to the Medium Term Loan, the interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan Subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Taiwan Subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. The current Medium Term Loan and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion. With respect to the Import O/A Loan, the period of use is between April 28, 2022 and April 28, 2023. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and the principal is repayable on the due date. Neither the Medium Term Loan nor Import O/A loan are secured. As of March 31, 2023, the amount outstanding under the Medium Term Loan was denominated in NTD and remeasured into US dollars of $53.8 million. The interest rate as of March 31, 2023 was 1.75% per annum. As of March 31, 2023 and June 30, 2022, the amounts outstanding under the Import O/A Loan were $0.0 million and $7.8 million, respectively. The interest rate as of March 31, 2023 and June 30, 2022 was 4.18% and 1.81% per annum, respectively. As of March 31, 2023, the amount available for future borrowing under the Import O/A Loan was $30.0 million.

[0001375365-23-000028:notes:86]
CTBC Bank

[0001375365-23-000028:notes:87]
2022 CTBC Credit Line

[0001375365-23-000028:notes:88]
Pursuant to banking practices in Taiwan to confirm loan agreements annually, on October 3, 2022, the Company through the Taiwan Subsidiary entered into an Agreement for Individually Negotiated Terms and Conditions with CTBC Bank Co., Ltd. (“CTBC Bank”) (such credit line, the “2022 CTBC Credit Line”) related to the prior 2021 CTBC credit lines (the “2021 CTBC Credit Lines”). The terms of the 2022 CTBC Credit Line remain substantially similar to the 2021 CTBC Credit Line, except the 2022 CTBC Credit Line made certain minor amendments to the monthly interest payment date. The total borrowing cap under the whole arrangement is $105.0 million and NTD 1,550.0 million ($55.4 million U.S. dollar equivalent).

[0001375365-23-000028:notes:89]
The Company, through the Taiwan Subsidiary, was party to that certain credit agreement, dated May 6, 2020, with CTBC Bank, which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent). As of March 31, 2023 and June 30, 2022, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.4 million and $40.4 million, respectively. The interest rates for these loans were 1.20% per annum as of March 31, 2023 and 0.83% as of June 30, 2022.

[0001375365-23-000028:notes:90]
The 2021 Credit Lines permitted borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the previously-existing ten-year, non-revolving term loan facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”). As of March 31, 2023 and June 30, 2022, under the 2021 CTBC Machine Loan, the amounts outstanding were $5.2 million and $5.5 million, respectively. The interest rates for these loans were 1.40% per annum as of March 31, 2023 and 1.03% as of June 30, 2022. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. As of March 31, 2023 and June 30, 2022, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were none and $84.8 million, respectively. The interest rates for these loans was 3.33% per annum as of March 31, 2023 and ranged from 1.80% to 2.52% as of June 30, 2022.

[0001375365-23-000028:notes:91]
As of March 31, 2023, the amount available for future borrowing under the 2022 CTBC Credit Line was $105 million. As of March 31, 2023, the net book value of land and building located in Bade, Taiwan, collateralizing the 2022 CTBC Credit Line was $75.4 million. The Company was in compliance with all financial covenants under 2022 CTBC Credit Line as of March 31, 2023.

[0001375365-23-000028:notes:92]
HSBC Bank

[0001375365-23-000028:notes:93]
HSBC Bank Credit Facility

[0001375365-23-000028:notes:94]
On February 7, 2023, the Company through the Taiwan subsidiary, entered into a new facility letter (the “New Facility Letter”) with the Taiwan affiliate of HSBC Bank which expanded the prior $30 million facility letter entered into with HSBC Bank on January 7, 2022. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date. Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash cover. As of March 31, 2023 and June 30, 2022, the outstanding borrowings under the HSBC Credit Facility were $0.0 million and $30.0 million, respectively. The interest rates for these loans were 4.50% per annum as of March 31, 2023 and ranged from 1.95% to 2.20% as of June 30, 2022.

[0001375365-23-000028:notes:95]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

[0001375365-23-000028:notes:96]
Fiscal Year                                                                                                                                                                                              Principal Payments

[0001375365-23-000028:notes:97]
| Remainder of 2023 |  | $ | 25,526 |  |
| 2024 |  | 39,260 |  |
| 2025 |  | 43,253 |  |
| 2026 |  | 43,253 |  |
| 2027 |  | 18,791 |  |
| 2028 and thereafter |  | 17,124 |  |
| Total short-term and long-term debt |  | $ | 187,207 |  |

[0001375365-23-000028:notes:98]
The Company is in compliance with all the covenants for the outstanding debt.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-23-000028:notes:99]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2023 and 2022 were as follows (in thousands):

[0001375365-23-000028:notes:100]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease expense (including expense for lease agreements with related parties of $139 and $422 for the three and nine months ended March 31, 2023, respectively, and $143 and $568 for the three and nine months ended March 31, 2022, respectively) | $ | 2,129 |  |  | $ | 2,017 |  |  | $ | 6,354 |  |  | $ | 6,183 |  |
| Cash payments for operating leases (including payments to related parties of $134 and $391 for the three and nine months ended March 31, 2023, respectively, and $141 and $631 for the three and nine months ended March 31, 2022, respectively) | $ | 2,146 |  |  | $ | 1,854 |  |  | $ | 6,209 |  |  | $ | 6,067 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 655 |  |  | $ | 3,730 |  |  | $ | 1,679 |  |  | $ | 11,108 |  |

[0001375365-23-000028:notes:101]
During the three and nine months ended March 31, 2023 and 2022, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three and nine months ended March 31, 2023 were $0.5 million and $1.3 million, respectively. Non-lease variable payments expensed in the three and nine months ended March 31, 2022 were $0.2 million and $0.7 million, respectively.

[0001375365-23-000028:notes:102]
As of March 31, 2023, the weighted average remaining lease term for operating leases was 3.2 years and the weighted average discount rate was 3.0%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of March 31, 2023 were as follows (in thousands):

[0001375365-23-000028:notes:103]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2023 |  | $ | 2,222 |  |
| 2024 |  | 7,272 |  |
| 2025 |  | 6,627 |  |
| 2026 |  | 2,683 |  |
| 2027 |  | 1,566 |  |
| 2028 and beyond |  | 536 |  |
| Total future lease payments |  | 20,906 |  |
| Less: Imputed interest |  | (1,095) |  |
| Present value of operating lease liabilities |  | $ | 19,811 |  |

[0001375365-23-000028:notes:104]
As of March 31, 2023, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-23-000028:notes:105]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 8, "Related Party Transactions," for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-23-000028:notes:106]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-23-000028:notes:107]
Dealings with Ablecom

[0001375365-23-000028:notes:108]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-23-000028:notes:109]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.3% and 88.8% of the chassis included in the products sold by the Company during the three months ended March 31, 2023 and 2022, respectively, and 93.0% and 82.5% of the chassis included in the products sold by the Company during the nine months ended March 31, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-23-000028:notes:110]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-23-000028:notes:111]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on March 31, 2023 were $23.4 million and $23.6 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2022 were $39.5 million and $36.0 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-23-000028:notes:112]
Dealings with Compuware

[0001375365-23-000028:notes:113]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-23-000028:notes:114]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-23-000028:notes:115]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-23-000028:notes:116]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-23-000028:notes:117]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on March 31, 2023 were $154.3 million and $59.7 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2022 were $213.3 million and $44.3 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-23-000028:notes:118]
Dealings with Investment in a Corporate Venture

[0001375365-23-000028:notes:119]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-23-000028:notes:120]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of March 31, 2023 and June 30, 2022, the Company had no unamortized deferred gain balance in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-23-000028:notes:121]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of March 31, 2023. No impairment charge was recorded for the three and nine months ended March 31, 2023 or 2022.

[0001375365-23-000028:notes:122]
The Company sold products worth $6.4 million and $43.7 million to the Corporate Venture during the three months ended March 31, 2023 and 2022, respectively, and sold products worth $23.6 million and $97.3 million to the Corporate Venture during the nine months ended March 31, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2023 and June 30, 2022 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $1.9 million and $8.0 million due from the Corporate Venture in accounts receivable, net as of March 31, 2023 and June 30, 2022, respectively.

[0001375365-23-000028:notes:123]
The Company had the following balances related to transactions with its related parties as of March 31, 2023 and June 30, 2022 (in thousands):

[0001375365-23-000028:notes:124]
|  | Ablecom | Compuware | Corporate Venture |  | Total |
|  | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 | March 31, 2023 | June 30, 2022 |  |  | March 31, 2023 | June 30, 2022 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 111 |  | $ | 404 |  | $ | 1,918 |  | $ | 7,992 |  |  |  | $ | 2,031 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 4,189 |  | $ | 4,816 |  | $ | 28,796 |  | $ | 19,596 |  | $ | — |  | $ | — |  |  |  | $ | 32,985 |  | $ | 24,412 |  |
| Accounts payable | $ | 28,369 |  | $ | 42,463 |  | $ | 47,744 |  | $ | 44,892 |  | $ | — |  | $ | — |  |  |  | $ | 76,113 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | 1,797 |  | $ | 3,531 |  | $ | 16,555 |  | $ | 15,145 |  | $ | — |  | $ | — |  |  |  | $ | 18,352 |  | $ | 18,676 |  |

[0001375365-23-000028:notes:125]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-23-000028:notes:126]
The Company's results from transactions with its related parties for each of the three months ended March 31, 2023 and 2022, are as follows (in thousands):

[0001375365-23-000028:notes:127]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, | Three months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 2 |  | $ | 2 |  | $ | 2,826 |  | $ | 3,928 |  | $ | 6,360 |  | $ | 43,739 |  | $ | — |  | $ | — |  | $ | 9,188 |  | $ | 47,669 |  |
| Purchases - inventory | $ | 33,637 |  | $ | 49,472 |  | $ | 54,095 |  | $ | 43,989 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,018 |  | $ | 87,732 |  | $ | 95,479 |  |
| Purchases - other miscellaneous items | $ | 2,329 |  | $ | 1,687 |  | $ | 541 |  | $ | 404 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,870 |  | $ | 2,091 |  |

[0001375365-23-000028:notes:128]
(1) MPS ceased to be a related party in the quarter ended September 30, 2022.

[0001375365-23-000028:notes:129]
The Company's results from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

[0001375365-23-000028:notes:130]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Net sales | $ | 6 |  | $ | 12 |  | $ | 30,699 |  | $ | 22,932 |  | $ | 23,611 |  | $ | 97,262 |  | $ | — |  | $ | — |  | $ | 54,316 |  | $ | 120,206 |  |
| Purchases - inventory | $ | 128,198 |  | $ | 147,780 |  | $ | 154,812 |  | $ | 126,039 |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,074 |  | $ | 283,010 |  | $ | 279,893 |  |
| Purchases - other miscellaneous items | $ | 9,855 |  | $ | 6,671 |  | $ | 1,078 |  | $ | 1,090 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 10,933 |  | $ | 7,761 |  |

[0001375365-23-000028:notes:131]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2023 and 2022, are as follows (in thousands):

[0001375365-23-000028:notes:132]
|  | Ablecom | Compuware | Corporate Venture | MPS (1) | Total |
|  | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, | Nine months ended March 31, |
|  | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 | 2023 | 2022 |
| Changes in accounts receivable | $ | — |  | $ | 1 |  | $ | 293 |  | $ | (182) |  | $ | 6,074 |  | $ | (25,224) |  | $ | — |  | $ | — |  | $ | 6,367 |  | $ | (25,405) |  |
| Changes in other receivable | $ | 627 |  | $ | 3,159 |  | $ | (9,200) |  | $ | (8,933) |  | $ | — |  | $ | — |  | $ | — |  | $ | 48 |  | $ | (8,573) |  | $ | (5,726) |  |
| Changes in accounts payable | $ | (14,094) |  | $ | 814 |  | $ | 2,852 |  | $ | 16,356 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (11,242) |  | $ | 17,170 |  |
| Changes in accrued liabilities | $ | (1,734) |  | $ | (2,060) |  | $ | 1,410 |  | $ | (153) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | (324) |  | $ | (3,213) |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (241) |  | $ | 596 |  |
| Purchases of property, plant and equipment | $ | 6,129 |  | $ | 2,365 |  | $ | 196 |  | $ | 140 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 6,325 |  | $ | 2,505 |  |
| Unpaid property, plant and equipment | $ | 1,369 |  | $ | 681 |  | $ | 22 |  | $ | 48 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,391 |  | $ | 729 |  |

[0001375365-23-000028:notes:133]
Tripartite Agreement

[0001375365-23-000028:notes:134]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land. Ablecom has advised that its underlying agreements to acquire land from the third-party landowners in proximity to the Company’s campus in Bade, Taiwan have been terminated, and during the quarter ended December 31, 2022, the Agreement was terminated.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-23-000028:notes:135]
[same as prior period, unchanged from 0001375365-23-000012:notes:130]

[0001375365-23-000028:notes:136]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "Original 2020 Plan"). The maximum number of shares available under the Original 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan (as amended and restated, the “2020 Plan”) which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-23-000028:notes:137]
[same as prior period, unchanged from 0001375365-23-000012:notes:132]

[0001375365-23-000028:notes:138]
As of March 31, 2023, the Company had 2,438,619 authorized shares available for future issuance under the 2020 Plan.

[0001375365-23-000028:notes:139]
Common Stock Repurchase and Retirement

[0001375365-23-000028:notes:140]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company's Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. Under the common stock repurchase program, shares may be purchased from time to time in open market transactions, block trades, through plans established under the Securities Exchange Act Rule 10b5-1, or otherwise. The number of shares purchased and the timing of such purchases are based on working capital requirements, market and general business conditions, and other factors, including alternative investment opportunities.

[0001375365-23-000028:notes:141]
During the nine months ended March 31, 2023, the Company repurchased and retired 1,553,350 shares of common stock for an aggregated $150.0 million. As of March 31, 2023, $50.0 million was available for additional repurchases of common stock.

[0001375365-23-000028:notes:142]
[same as prior period, unchanged from 0001375365-23-000012:notes:136]

[0001375365-23-000028:notes:143]
[same as prior period, unchanged from 0001375365-23-000012:notes:137]

[0001375365-23-000028:notes:144]
[same as prior period, unchanged from 0001375365-23-000012:notes:138]

[0001375365-23-000028:notes:145]
[same as prior period, unchanged from 0001375365-23-000012:notes:139]

[0001375365-23-000028:notes:146]
[same as prior period, unchanged from 0001375365-23-000012:notes:140]

[0001375365-23-000028:notes:147]
[same as prior period, unchanged from 0001375365-23-000012:notes:141]

[0001375365-23-000028:notes:148]
The fair value of stock option grants for the three and nine months ended March 31, 2023 and 2022 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-23-000028:notes:149]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Risk-free interest rate | 3.52% |  | 1.65% |  | 2.81% - 4.25% |  | 0.81% - 1.65% |
| Expected term | 6.07 years |  | 6.09 years |  | 6.07 years |  | 6.09 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 51.61% |  | 49.99% |  | 50.62% - 51.68% |  | 49.69% - 49.99% |
| Weighted-average fair value | $41.50 |  | $19.31 |  | $35.06 |  | $18.09 |

[0001375365-23-000028:notes:150]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2023 and 2022 (in thousands):

[0001375365-23-000028:notes:151]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of sales | $ | 1,215 |  |  | $ | 460 |  |  | $ | 3,585 |  |  | $ | 1,378 |  |
| Research and development | 8,097 |  |  | 4,141 |  |  | 23,549 |  |  | 12,124 |  |
| Sales and marketing | 1,214 |  |  | 504 |  |  | 3,471 |  |  | 1,517 |  |
| General and administrative | 3,126 |  |  | 2,636 |  |  | 11,042 |  |  | 8,913 |  |
| Stock-based compensation expense before taxes | 13,652 |  |  | 7,741 |  |  | 41,647 |  |  | 23,932 |  |
| Income tax impact | (3,444) |  |  | (2,431) |  |  | (8,165) |  |  | (8,077) |  |
| Stock-based compensation expense, net | $ | 10,208 |  |  | $ | 5,310 |  |  | $ | 33,482 |  |  | $ | 15,855 |  |

[0001375365-23-000028:notes:152]
As of March 31, 2023, $19.0 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.84 years and $82.5 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.70 years. Additionally, as described below, $1.8 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 1.25 years.

[0001375365-23-000028:notes:153]
[same as prior period, unchanged from 0001375365-23-000012:notes:147]

[0001375365-23-000028:notes:154]
[same as prior period, unchanged from 0001375365-23-000012:notes:148]

[0001375365-23-000028:notes:155]
The achievement status of the operational and stock price milestones as of March 31, 2023 was as follows:

[0001375365-23-000028:notes:156]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Achieved |  | $75 |  | Achieved (3) |  |  |
| $6.8 |  | Probable |  | $95 |  | Not yet achieved (4) |  |  |
| $8.0 |  | Probable |  | $120 |  | Not yet achieved |  |  |

[0001375365-23-000028:notes:157]
[same as prior period, unchanged from 0001375365-23-000012:notes:151]

[0001375365-23-000028:notes:158]
[same as prior period, unchanged from 0001375365-23-000012:notes:152]

[0001375365-23-000028:notes:159]
(3)The vesting of the third tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company's Compensation Committee in January 2023.

[0001375365-23-000028:notes:160]
(4)The $95 stock price milestone was achieved subsequent to March 31, 2023, and was certified by the Company’s Compensation Committee in April 2023.

[0001375365-23-000028:notes:161]
[same as prior period, unchanged from 0001375365-23-000012:notes:154]

[0001375365-23-000028:notes:162]
During the three and nine months ended March 31, 2023, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.5 million and $3.8 million, respectively. During the three and nine months ended March 31, 2022, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $1.5 million and $5.3 million, respectively. As of March 31, 2023 and June 30, 2022, the Company had $1.8 million and $5.6 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2023 is expected to be recognized over a period of more than 1.25 years.

[0001375365-23-000028:notes:163]
The following table summarizes stock option activity during the nine months ended March 31, 2023 under all plans:

[0001375365-23-000028:notes:164]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2022 |  | 4,311,416 |  |  | $ | 29.99 |  |  |  |  |  |
| Granted |  | 336,082 |  |  | $ | 66.25 |  |  |  |  |  |
| Exercised |  | (1,205,727) |  |  | $ | 20.59 |  |  |  |  |  |
| Forfeited/Cancelled |  | (21,568) |  |  | $ | 30.18 |  |  |  |  |  |
| Balance as of March 31, 2023 |  | 3,420,203 |  |  | $ | 36.87 |  |  | 6.32 |  |  |
| Options vested and exercisable at March 31, 2023 |  | 2,136,763 |  |  | $ | 30.76 |  |  | 5.01 |  |  |

[0001375365-23-000028:notes:165]
[same as prior period, unchanged from 0001375365-23-000012:notes:158]

[0001375365-23-000028:notes:166]
The following table summarizes RSU and PRSU activity during the nine months ended March 31, 2023 under all plans:

[0001375365-23-000028:notes:167]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2022 | 1,879,073 |  |  | $ | 33.72 |  |  |  |  |  |  |
| Granted | 954,920 |  |  | $ | 66.17 |  |  |  |  |  |  |
| Released | (759,893) |  |  | $ | 38.34 |  |  |  |  |  |  |
| Forfeited | (104,028) |  |  | $ | 41.65 |  |  |  |  |  |  |
| Balance as of March 31, 2023 | 1,970,072 |  |  | $ | 47.25 |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-23-000028:notes:168]
Income Taxes
The Company recorded a provision for income taxes of $10.9 million and $79.4 million for the three and nine months ended March 31, 2023, respectively, and $16.2 million and $27.1 million for the three and nine months ended March 31, 2022, respectively. The effective tax rate was 11.1% and 15.0% for the three and nine months ended March 31, 2023, respectively, and 17.4% and 15.9% for the three and nine months ended March 31, 2022, respectively. The effective tax rate for the three months ended March 31, 2023 is lower than that for the three months ended March 31, 2022, primarily due to an increase in the tax deduction for stock compensation in the three months ended March 31, 2023. The effective tax rate for the nine months ended March 31, 2023 is lower than that for the nine months ended March 31, 2022, primarily due to a significant increase in tax deductible stock compensation expense in the third quarter of fiscal year 2023.

[0001375365-23-000028:notes:169]
[same as prior period, unchanged from 0001375365-23-000012:notes:162]

[0001375365-23-000028:notes:170]
As of March 31, 2023, the Company had gross unrecognized tax benefits of $41.3 million, of which, $23.5 million if recognized, would affect the Company's effective tax rate. During the nine months ended March 31, 2023, there was a $2.4 million increase in gross unrecognized tax benefits. The Company's policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2023, the Company had accrued $3.4 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-23-000028:notes:171]
[same as prior period, unchanged from 0001375365-23-000012:notes:164]

[0001375365-23-000028:notes:172]
[same as prior period, unchanged from 0001375365-23-000012:notes:165]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-23-000028:notes:173]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 5, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. On March 11, 2022, the Company, together with the individual defendants, agreed in principle with plaintiff’s counsel to settle the action. On April 8, 2022, the parties entered into a stipulation of settlement, pursuant to which and subject to Court approval, plaintiff will dismiss with prejudice and release on behalf of a class of shareholders all claims against defendants, including the Company, in exchange for payment of $18,250,000, of which sum $2,000,000 will be funded by the Company. On May 25, 2022, the Court vacated the hearing on preliminary approval of the proposed settlement scheduled for June 2, 2022, stating that the unopposed motion was suitable for disposition without oral argument. All settlement funds have been transferred into an account controlled by the settlement’s escrow agent. No settlement funds will be distributed until the Court grants final approval. On November 8, 2022, the Court granted preliminary approval and calendared a hearing on March 2, 2023 for final approval, which the Court continued to May 4, 2023. At the May 4, 2023 hearing, the Court indicated that it planned to grant final approval in a subsequent order, which will fully resolve the action.

[0001375365-23-000028:notes:174]
Other legal proceedings and indemnifications

[0001375365-23-000028:notes:175]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2023 and any prior periods.

[0001375365-23-000028:notes:176]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-23-000028:notes:177]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-23-000028:notes:178]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2023, these remaining noncancelable commitments were $932.8 million, including $83.3 million for related parties.
Lease Commitments - See Part I, Item 1, Note 7, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-23-000028:notes:179]
[same as prior period, unchanged from 0001375365-23-000012:notes:173]

[0001375365-23-000028:notes:180]
[same as prior period, unchanged from 0001375365-23-000012:notes:174]

[0001375365-23-000028:notes:181]
|  | March 31, |  | June 30, |
|  | 2023 |  | 2022 |
| Long-lived assets: |  |  |  |
| United States | $ | 181,913 |  |  | $ | 180,846 |  |
| Asia | 105,368 |  |  | 102,241 |  |
| Europe | 2,757 |  |  | 2,885 |  |
|  | $ | 290,038 |  |  | $ | 285,972 |  |

[0001375365-23-000028:notes:182]
[same as prior period, unchanged from 0001375365-23-000012:notes:176]
