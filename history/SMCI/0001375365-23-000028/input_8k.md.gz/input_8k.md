# SMCI 8-K — 0001375365-23-000027 filed 2023-05-02

## item codes, every 8-K on or before 2023-05-05

- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2023-05-05

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-23-000027:8k_2_02:1]
EX-99.1
2
exhibit991_20230331.htm
EX-99.1

[0001375365-23-000027:8k_2_02:2]
Document

[0001375365-23-000027:8k_2_02:3]
Exhibit 99.1

[0001375365-23-000027:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2023 Financial Results

[0001375365-23-000027:8k_2_02:5]
SAN JOSE, Calif. -- May 2, 2023 (BUSINESS WIRE) -- Supermicro (Nasdaq: SMCI), a Total IT Solution Provider for Cloud, AI/ML, Storage, and 5G/Edge, today announced financial results for its third quarter of fiscal year 2023 ended March 31, 2023.

[0001375365-23-000027:8k_2_02:6]
Third Quarter Fiscal Year 2023 Highlights

[0001375365-23-000027:8k_2_02:7]
•Net sales of $1.28 billion versus $1.80 billion in the second quarter of fiscal year 2023 and $1.36 billion in the same quarter of last year.

[0001375365-23-000027:8k_2_02:8]
•Gross margin of 17.6% versus 18.7% in the second quarter of fiscal year 2023 and 15.5% in the same quarter of last year.

[0001375365-23-000027:8k_2_02:9]
•Net income of $86 million versus $176 million in the second quarter of fiscal year 2023 and $77 million in the same quarter of last year.

[0001375365-23-000027:8k_2_02:10]
•Diluted net income per common share of $1.53 versus $3.14 in the second quarter of fiscal year 2023 and $1.43 in the same quarter of last year.

[0001375365-23-000027:8k_2_02:11]
•Non-GAAP diluted net income per common share of $1.63 versus $3.26 in the second quarter of fiscal year 2023 and $1.55 in the same quarter of last year.

[0001375365-23-000027:8k_2_02:12]
•Cash flow provided by operations for the third quarter of fiscal year 2023 of $198 million and capital expenditures of $8 million.

[0001375365-23-000027:8k_2_02:13]
Non-GAAP gross margin for the third quarter of fiscal year 2023 was 17.7% which adds back stock-based compensation expenses of $1 million. Non-GAAP diluted net income per common share for the third quarter of fiscal year 2023 was $1.63, with adjustments for stock-based compensation expenses of $14 million and $2 million litigation expense recovery, net of the related tax effects of $4 million.

[0001375365-23-000027:8k_2_02:14]
As of  March 31, 2023, total cash and cash equivalents was $363 million and total bank debt was $187 million.

[0001375365-23-000027:8k_2_02:15]
“Supermicro continues to see record levels of engagements in our new generation product lines, especially for AI applications" said Charles Liang, President and CEO of Supermicro. "We secured several new and large design wins and are deploying some of the world’s most leading GPU clusters. With the recent new key components supply chain challenges mostly in the rear-view mirror and production normalizing, we expect to gain share and expand scale as we emerge as the true leader for rack-scale Total IT Solutions.”

[0001375365-23-000027:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-23-000027:8k_2_02:17]
For the fourth quarter of fiscal year 2023 ending June 30, 2023, the Company expects net sales of $1.7 billion to $1.9 billion, GAAP net income per diluted share of $2.13 to $2.65 and non-GAAP net income per diluted share of $2.21 to $2.71. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 14.7% and 15.7%, respectively, and a fully diluted share count of 56 million shares for GAAP and fully diluted share count of 57 million shares for non-GAAP. The outlook for Q4 of fiscal year 2023 GAAP net income per diluted share includes approximately $7 million in expected stock-based compensation and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-23-000027:8k_2_02:18]
For fiscal year 2023 ending June 30, 2023, the Company maintains its guidance for net sales from a range of $6.6 billion to $6.8 billion, GAAP net income per diluted share from a range of $10.14 to $10.66, and non-GAAP net income per diluted share from a range of $10.50 to $11.00. The Company’s projections for annual GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 14.9% and 16.0%, respectively, and a fully diluted share count of 56 million shares for GAAP and fully diluted share count of 57 million shares for non-GAAP. The outlook for fiscal year 2023 GAAP net income per diluted share includes approximately $33 million in expected stock-based compensation and other expenses, net of related tax effects that are excluded from non-GAAP net income per diluted share.

[0001375365-23-000027:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-23-000027:8k_2_02:20]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its third quarter of fiscal year 2023.

[0001375365-23-000027:8k_2_02:21]
Those wishing to access the live webcast may use the following link:

[0001375365-23-000027:8k_2_02:22]
https://events.q4inc.com/attendee/104078846

[0001375365-23-000027:8k_2_02:23]
The conference call can be accessed by registering online at:

[0001375365-23-000027:8k_2_02:24]
https://conferencingportals.com/event/fIceWmPv

[0001375365-23-000027:8k_2_02:25]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-23-000027:8k_2_02:26]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-23-000027:8k_2_02:27]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-23-000027:8k_2_02:28]
Use of Non-GAAP Financial Measures

[0001375365-23-000027:8k_2_02:29]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, litigation settlement costs, special performance bonuses and litigation expense (recovery), adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of GAAP gross margin to non-GAAP gross margin and from GAAP diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-23-000027:8k_2_02:30]
About Super Micro Computer, Inc.

[0001375365-23-000027:8k_2_02:31]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-23-000027:8k_2_02:32]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-23-000027:8k_2_02:33]
Investor Relations Contact

[0001375365-23-000027:8k_2_02:34]
Nicole Noutsios

[0001375365-23-000027:8k_2_02:35]
email: ir@supermicro.com

[0001375365-23-000027:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000027:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-23-000027:8k_2_02:38]
(in thousands)

[0001375365-23-000027:8k_2_02:39]
(unaudited)

[0001375365-23-000027:8k_2_02:40]
|  | March 31, |  | June 30, |
|  | 2023 |  | 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 362,801 |  |  | $ | 267,397 |  |
| Accounts receivable, net of allowance for credit losses | 672,055 |  |  | 834,513 |  |
| Inventories | 1,540,419 |  |  | 1,545,606 |  |
| Prepaid expenses and other current assets | 139,900 |  |  | 158,799 |  |
| Total current assets | 2,715,175 |  |  | 2,806,315 |  |
| Property, plant and equipment, net | 290,038 |  |  | 285,972 |  |
| Deferred income taxes, net | 148,558 |  |  | 69,929 |  |
| Other assets | 38,833 |  |  | 42,861 |  |
| Total assets | $ | 3,192,604 |  |  | $ | 3,205,077 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 641,839 |  |  | $ | 655,403 |  |
| Accrued liabilities | 155,224 |  |  | 212,419 |  |
| Income taxes payable | 92,598 |  |  | 41,743 |  |
| Short-term debt | 53,972 |  |  | 449,146 |  |
| Deferred revenue | 148,747 |  |  | 111,313 |  |
| Total current liabilities | 1,092,380 |  |  | 1,470,024 |  |
| Deferred revenue, non-current | 161,176 |  |  | 122,548 |  |
| Long-term debt | 133,235 |  |  | 147,618 |  |
| Other long-term liabilities | 37,240 |  |  | 39,140 |  |
| Total liabilities | 1,424,031 |  |  | 1,779,330 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 528,279 |  |  | 481,741 |  |
| Accumulated other comprehensive income | 683 |  |  | 911 |  |
| Retained earnings | 1,239,445 |  |  | 942,923 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,768,407 |  |  | 1,425,575 |  |
| Noncontrolling interest | 166 |  |  | 172 |  |
| Total stockholders’ equity | 1,768,573 |  |  | 1,425,747 |  |
| Total liabilities and stockholders’ equity | $ | 3,192,604 |  |  | $ | 3,205,077 |  |

[0001375365-23-000027:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000027:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-23-000027:8k_2_02:43]
(in thousands except per share amounts)

[0001375365-23-000027:8k_2_02:44]
(unaudited)

[0001375365-23-000027:8k_2_02:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,283,296 |  |  | $ | 1,355,490 |  |  | $ | 4,938,621 |  |  | $ | 3,560,639 |  |
| Cost of sales | 1,056,937 |  |  | 1,144,715 |  |  | 4,027,305 |  |  | 3,047,982 |  |
| Gross profit | 226,359 |  |  | 210,775 |  |  | 911,316 |  |  | 512,657 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 77,515 |  |  | 70,869 |  |  | 222,458 |  |  | 201,483 |  |
| Sales and marketing | 25,312 |  |  | 22,356 |  |  | 83,120 |  |  | 65,940 |  |
| General and administrative | 24,450 |  |  | 27,773 |  |  | 71,351 |  |  | 75,280 |  |
| Total operating expenses | 127,277 |  |  | 120,998 |  |  | 376,929 |  |  | 342,703 |  |
| Income from operations | 99,082 |  |  | 89,777 |  |  | 534,387 |  |  | 169,954 |  |
| Other (expense) income, net | (78) |  |  | 4,663 |  |  | 1,641 |  |  | 4,106 |  |
| Interest expense | (1,288) |  |  | (1,531) |  |  | (6,982) |  |  | (3,485) |  |
| Income before income tax provision | 97,716 |  |  | 92,909 |  |  | 529,046 |  |  | 170,575 |  |
| Income tax (provision) | (10,857) |  |  | (16,192) |  |  | (79,364) |  |  | (27,116) |  |
| Share of (loss) income from equity investee, net of taxes | (1,013) |  |  | 255 |  |  | (3,253) |  |  | 882 |  |
| Net income | $ | 85,846 |  |  | $ | 76,972 |  |  | $ | 446,429 |  |  | $ | 144,341 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.61 |  |  | $ | 1.49 |  |  | $ | 8.42 |  |  | $ | 2.82 |  |
| Diluted | $ | 1.53 |  |  | $ | 1.43 |  |  | $ | 8.00 |  |  | $ | 2.70 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 53,280 |  |  | 51,708 |  |  | 53,011 |  |  | 51,269 |  |
| Diluted | 56,233 |  |  | 53,786 |  |  | 55,796 |  |  | 53,401 |  |

[0001375365-23-000027:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-23-000027:8k_2_02:47]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of sales | $ | 1,215 |  |  | $ | 460 |  |  | $ | 3,585 |  |  | $ | 1,378 |  |
| Research and development | 8,097 |  |  | 4,141 |  |  | 23,549 |  |  | 12,124 |  |
| Sales and marketing | 1,214 |  |  | 504 |  |  | 3,471 |  |  | 1,517 |  |
| General and administrative | 3,126 |  |  | 2,636 |  |  | 11,042 |  |  | 8,913 |  |
| Stock-based compensation expense | $ | 13,652 |  |  | $ | 7,741 |  |  | $ | 41,647 |  |  | $ | 23,932 |  |

[0001375365-23-000027:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000027:8k_2_02:49]
SELECTED CASH FLOW INFORMATION

[0001375365-23-000027:8k_2_02:50]
(in thousands)

[0001375365-23-000027:8k_2_02:51]
(unaudited)

[0001375365-23-000027:8k_2_02:52]
|  | Nine Months EndedMarch 31, |
|  | 2023 |  | 2022 |
| Net cash provided by (used in) operating activities | $ | 672,919 |  |  | $ | (415,658) |  |
| Net cash (used in) investing activities | (28,618) |  |  | (35,257) |  |
| Net cash (used in) provided by financing activities | (547,291) |  |  | 466,365 |  |
| Effect of exchange rate fluctuations on cash | (2,269) |  |  | (304) |  |
| Net increase in cash, cash equivalents and restricted cash | 94,741 |  |  | 15,146 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 268,559 |  |  | 233,449 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 363,300 |  |  | $ | 248,595 |  |

[0001375365-23-000027:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000027:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000027:8k_2_02:55]
(in thousands except per share amounts)

[0001375365-23-000027:8k_2_02:56]
(unaudited)

[0001375365-23-000027:8k_2_02:57]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP GROSS PROFIT | $ | 226,359 |  |  | $ | 210,775 |  |  | $ | 911,316 |  |  | $ | 512,657 |  |
| Stock-based compensation | 1,215 |  |  | 460 |  |  | 3,585 |  |  | 1,378 |  |
| Other expenses | — |  |  | — |  |  | — |  |  | 295 |  |
| NON-GAAP GROSS PROFIT | $ | 227,574 |  |  | $ | 211,235 |  |  | $ | 914,901 |  |  | $ | 514,330 |  |
| GAAP GROSS MARGIN | 17.6 | % |  | 15.5 | % |  | 18.5 | % |  | 14.4 | % |
| Stock-based compensation | 0.1 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Other expenses | — | % |  | — | % |  | — | % |  | 0.0 | % |
| NON-GAAP GROSS MARGIN | 17.7 | % |  | 15.6 | % |  | 18.6 | % |  | 14.5 | % |
| GAAP OPERATING EXPENSE | $ | 127,277 |  |  | $ | 120,998 |  |  | $ | 376,929 |  |  | $ | 342,703 |  |
| Stock-based compensation | (12,437) |  |  | (7,281) |  |  | (38,062) |  |  | (22,554) |  |
| Litigation settlement costs | — |  |  | (2,000) |  |  | — |  |  | (2,000) |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | (158) |  |
| Litigation recovery (expense) | 1,540 |  |  | (2,210) |  |  | 3,770 |  |  | (4,133) |  |
| NON-GAAP OPERATING EXPENSE | $ | 116,380 |  |  | $ | 109,507 |  |  | $ | 342,637 |  |  | $ | 313,858 |  |
| GAAP INCOME FROM OPERATIONS | $ | 99,082 |  |  | $ | 89,777 |  |  | $ | 534,387 |  |  | $ | 169,954 |  |
| Stock-based compensation | 13,652 |  |  | 7,741 |  |  | 41,647 |  |  | 23,932 |  |
| Litigation settlement costs | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |
| Litigation (recovery) expense | (1,540) |  |  | 2,210 |  |  | (3,770) |  |  | 4,133 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 111,194 |  |  | $ | 101,728 |  |  | $ | 572,264 |  |  | $ | 200,472 |  |
| GAAP OPERATING MARGIN | 7.7 | % |  | 6.6 | % |  | 10.8 | % |  | 4.8 | % |
| Stock-based compensation | 1.1 | % |  | 0.6 | % |  | 0.8 | % |  | 0.7 | % |
| Litigation settlement costs | — | % |  | 0.1 | % |  | — | % |  | 0.1 | % |
| Special performance bonuses | — | % |  | — | % |  | — | % |  | 0.0 | % |
| Litigation (recovery) expense | (0.1) | % |  | 0.2 | % |  | (0.1) | % |  | 0.1 | % |
| NON-GAAP OPERATING MARGIN | 8.7 | % |  | 7.5 | % |  | 11.5 | % |  | 5.7 | % |
| GAAP TAX EXPENSE | $ | 10,857 |  |  | $ | 16,192 |  |  | $ | 79,364 |  |  | $ | 27,116 |  |
| Adjustments to tax provision | 4,433 |  |  | 3,415 |  |  | 11,963 |  |  | $ | 9,584 |  |
| NON-GAAP TAX EXPENSE | $ | 15,290 |  |  | $ | 19,607 |  |  | $ | 91,327 |  |  | $ | 36,700 |  |
| GAAP NET INCOME | $ | 85,846 |  |  | $ | 76,972 |  |  | $ | 446,429 |  |  | $ | 144,341 |  |
| Stock-based compensation | 13,652 |  |  | 7,741 |  |  | 41,647 |  |  | 23,932 |  |
| Litigation settlement costs | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |
| Litigation (recovery) expense | (1,540) |  |  | 2,210 |  |  | (3,770) |  |  | 4,133 |  |
| Adjustments to tax provision | (4,433) |  |  | (3,415) |  |  | (11,963) |  |  | (9,584) |  |
| NON-GAAP NET INCOME | $ | 93,525 |  |  | $ | 85,508 |  |  | $ | 472,343 |  |  | $ | 165,275 |  |

[0001375365-23-000027:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000027:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000027:8k_2_02:60]
(in thousands except per share amounts)

[0001375365-23-000027:8k_2_02:61]
(unaudited)

[0001375365-23-000027:8k_2_02:62]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 1.61 |  |  | $ | 1.49 |  |  | $ | 8.42 |  |  | $ | 2.82 |  |
| Impact of Non-GAAP adjustments | 0.15 |  |  | 0.16 |  |  | 0.49 |  |  | 0.40 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 1.76 |  |  | $ | 1.65 |  |  | $ | 8.91 |  |  | $ | 3.22 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 1.53 |  |  | $ | 1.43 |  |  | $ | 8.00 |  |  | $ | 2.70 |  |
| Impact of Non-GAAP adjustments | 0.10 |  |  | 0.12 |  |  | 0.29 |  |  | 0.31 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 1.63 |  |  | $ | 1.55 |  |  | $ | 8.29 |  |  | $ | 3.01 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 53,280 |  |  | 51,708 |  |  | 53,011 |  |  | 51,269 |  |
| BASIC – NON-GAAP | 53,280 |  |  | 51.708 |  |  | 53,011 |  |  | 51,269 |  |
| DILUTED – GAAP | 56,233 |  |  | 53,786 |  |  | 55,796 |  |  | 53,401 |  |
| DILUTED – NON-GAAP | 57,315 |  |  | 55.194 |  |  | 56,966 |  |  | 54.831 |  |

[0001375365-23-000027:8k_2_02:63]
Non-GAAP diluted net income per common share for the second quarter of fiscal year 2023 ended December 31, 2022 was $3.26, with adjustments for stock-based compensation expenses of $17 million and $2 million litigation expense recovery, net of the related tax effects of $4 million.
