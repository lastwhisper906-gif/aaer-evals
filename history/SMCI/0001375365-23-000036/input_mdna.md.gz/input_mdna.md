# SMCI MD&A — 0001375365-23-000036


## mdna

[0001375365-23-000036:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-23-000036:mdna:2]
Overview

[0001375365-23-000036:mdna:3]
We are a Silicon Valley-based provider of accelerated compute platforms that are application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, AI, 5G and edge computing. Our Total IT Solutions include complete servers, storage systems, modular blade servers, blades, workstations, full rack-scale solutions, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-23-000036:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2023, 2022 and 2021, our net income was $640.0 million, $285.2 million and $111.9 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the product introduction cycles of Intel Corporation, NVIDIA Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-23-000036:mdna:5]
COVID-19 Pandemic Impact

[0001375365-23-000036:mdna:6]
Our business and financial outlook have experienced, and may continue to face, challenges due to adverse macroeconomic conditions and uncertainties. These factors encompass labor shortages, disruptions in the supply chain, inflation, higher interest rates, and fluctuations in capital markets. The global business landscape encountered widespread disruption as a consequence of the COVID-19 pandemic, which commenced in early 2020. The extent of its direct or indirect impact on general market conditions, as well as our business, results of operations, cash flows, and financial condition, is contingent upon uncertain future developments, including the emergence of new variants.

[0001375365-23-000036:mdna:7]
We remain committed to continuously assessing the nature and extent of the impact of general macroeconomic conditions and the ongoing COVID-19 pandemic on our business. For a more comprehensive discussion, please refer to the "Risk Factors" included in Part I, Item 1A of this Annual Report on Form 10-K.

[0001375365-23-000036:mdna:8]
Financial Highlights

[0001375365-23-000036:mdna:9]
The following is a summary of financial highlights of fiscal years 2023 and 2022:

[0001375365-23-000036:mdna:10]
•Net sales increased by 37.1% in fiscal year 2023 as compared to fiscal year 2022.

[0001375365-23-000036:mdna:11]
•Gross margin increased to 18.0% in fiscal year 2023 from 15.4% in fiscal year 2022, primarily due to product and customer mix and decreased logistic costs.

[0001375365-23-000036:mdna:12]
•Operating expenses increased by 12.3% in fiscal year 2023 as compared to fiscal year 2022, primarily due to the increase in personnel expenses as a result of salary increases, equity grants and a higher headcount.

[0001375365-23-000036:mdna:13]
SMCI | 2023 Form 10-K | 37

[0001375365-23-000036:mdna:14]
•Net income increased to $640.0 million in fiscal year 2023 as compared to $285.2 million in fiscal year 2022, which was primarily due to the higher net sales and lower operating expenses as a percentage of revenues in fiscal year 2023 as compared to fiscal year 2022.

[0001375365-23-000036:mdna:15]
•Our cash and cash equivalents were $440.5 million and $267.4 million at the end of fiscal years 2023 and 2022, respectively. In fiscal year 2023, we generated net cash of $172.4 million, comprised of $663.6 million provided by operating activities primarily due to increased net income, $448.3 million used in financing activities primarily due to repayment of debt and stock repurchase, and $39.5 million cash used in investing activities primarily due to $36.8 million in purchases of property and equipment.

[0001375365-23-000036:mdna:16]
Critical Accounting Policies and Estimates

[0001375365-23-000036:mdna:17]
General

[0001375365-23-000036:mdna:18]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis based on a) historical experience, b) assumptions we believe to be reasonable under the circumstances and are not readily apparent from other sources, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows. These estimates and judgements have not fluctuated significantly for the fiscal year ended June 30, 2023 compared to prior fiscal years.

[0001375365-23-000036:mdna:19]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-23-000036:mdna:20]
Revenue Recognition

[0001375365-23-000036:mdna:21]
The most critical accounting policy estimate and judgments required in applying ASC 606, Revenue Recognition of Contracts from Customers, and our revenue recognition policy relate to the determination of the transaction price, distinct performance obligations and the evaluation of the standalone selling price (the “SSP”) for each performance obligation.

[0001375365-23-000036:mdna:22]
We generate revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services. Many of our customer contracts include multiple performance obligations. Judgment is required in determining whether each performance obligation within a customer contract is distinct. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.

[0001375365-23-000036:mdna:23]
As part of determining the transaction price in contracts with customers, we may be required to estimate variable consideration when determining the amount of revenue to recognize. We estimate reserves for future sales returns based on a review of our history of actual returns. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. We also estimate the costs of customer and distributor programs and incentive offerings such as price protection, customer rebates, as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-23-000036:mdna:24]
SMCI | 2023 Form 10-K | 38

[0001375365-23-000036:mdna:25]
We allocate the transaction price for each customer contract to each performance obligation based on the relative SSP for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the respective performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgement. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we apply judgment to estimate the SSP. For substantially all performance obligations, we are able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-23-000036:mdna:26]
Inventories

[0001375365-23-000036:mdna:27]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-23-000036:mdna:28]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold. We determine the volume-based rebates to be recognized in the cost of sales on a first-in, first-out basis.

[0001375365-23-000036:mdna:29]
Income Taxes

[0001375365-23-000036:mdna:30]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or when loss or credit carryforwards are utilized. In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001375365-23-000036:mdna:31]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and reflect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-23-000036:mdna:32]
SMCI | 2023 Form 10-K | 39

[0001375365-23-000036:mdna:33]
Stock-Based Compensation

[0001375365-23-000036:mdna:34]
We measure and recognize compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. We base initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-23-000036:mdna:35]
The fair value of RSUs and PRSUs is based on the closing market price of our common stock on the date of grant. We estimate the fair value of stock options granted using a Black-Scholes option pricing model. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the historical volatility of our common stock. The assumptions used to determine the fair value of the option awards represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. Our use of the Black-Scholes option-pricing model requires the input of highly subjective assumptions. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.

[0001375365-23-000036:mdna:36]
Results of Operations

[0001375365-23-000036:mdna:37]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of revenue.

[0001375365-23-000036:mdna:38]
|  | Years Ended June 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 82.0 | % |  | 84.6 | % |  | 85.0 | % |
| Gross profit | 18.0 | % |  | 15.4 | % |  | 15.0 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 4.3 | % |  | 5.2 | % |  | 6.3 | % |
| Sales and marketing | 1.6 | % |  | 1.7 | % |  | 2.4 | % |
| General and administrative | 1.4 | % |  | 2.0 | % |  | 2.8 | % |
| Total operating expenses | 7.3 | % |  | 8.9 | % |  | 11.5 | % |
| Income from operations | 10.7 | % |  | 6.5 | % |  | 3.5 | % |
| Other income (expense), net | 0.1 | % |  | 0.2 | % |  | (0.1) | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 10.7 | % |  | 6.6 | % |  | 3.3 | % |
| Income tax provision | (1.6) | % |  | (1.0) | % |  | (0.2) | % |
| Share of (loss) income from equity investee, net of taxes | (0.1) | % |  | — | % |  | — | % |
| Net income | 9.0 | % |  | 5.6 | % |  | 3.1 | % |

[0001375365-23-000036:mdna:39]
SMCI | 2023 Form 10-K | 40

[0001375365-23-000036:mdna:40]
Net Sales

[0001375365-23-000036:mdna:41]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-23-000036:mdna:42]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPU/GPU, memory and storage.

[0001375365-23-000036:mdna:43]
The following table presents net sales by product type for fiscal years 2023, 2022 and 2021 (dollars in millions):

[0001375365-23-000036:mdna:44]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 6,569.8 |  |  | $ | 4,463.8 |  |  | $ | 2,790.3 |  |  | $ | 2,106.0 |  |  | 47.2 | % |  | $ | 1,673.5 |  |  | 60.0 | % |
| Percentage of total net sales | 92.2 | % |  | 85.9 | % |  | 78.4 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 553.7 |  |  | 732.3 |  |  | 767.1 |  |  | (178.6) |  |  | (24.4) | % |  | (34.8) |  |  | (4.5) | % |
| Percentage of total net sales | 7.8 | % |  | 14.1 | % |  | 21.6 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 7,123.5 |  |  | $ | 5,196.1 |  |  | $ | 3,557.4 |  |  | $ | 1,927.4 |  |  | 37.1 | % |  | $ | 1,638.7 |  |  | 46.1 | % |

[0001375365-23-000036:mdna:45]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:46]
During fiscal year 2023 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to the strong demands from such customers for GPU, high performance computing (“HPC”), and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling prices. The year-over-year decrease in net sales of subsystems and accessories was primarily due to our emphasis on selling full systems and servers. Our services and software revenue, included in server and storage systems revenue, increased by $28.0 million year-over-year.

[0001375365-23-000036:mdna:47]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:48]
During fiscal year 2022 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to an increase of average selling prices per compute node by approximately 32% as well as an increase of approximately 23% in the number of units of compute nodes sold. The year-over-year decrease in net sales of subsystems and accessories was primarily due to our emphasis on selling full systems and servers. Our services and software revenue, included in server and storage systems revenue, increased by $2.5 million year-over-year.

[0001375365-23-000036:mdna:49]
SMCI | 2023 Form 10-K | 41

[0001375365-23-000036:mdna:50]
The following table presents percentages of net sales by geographic region for fiscal years 2023, 2022 and 2021 (dollars in millions):

[0001375365-23-000036:mdna:51]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| United States | $ | 4,834.1 |  |  | $ | 3,035.5 |  |  | $ | 2,107.9 |  |  | $ | 1,798.6 |  |  | 59.3 | % |  | $ | 927.6 |  |  | 44.0 | % |
| Percentage of total net sales | 67.9 | % |  | 58.4 | % |  | 59.3 | % |  |  |  |  |  |  |  |  |
| Asia | 1,050.8 |  |  | 1,139.9 |  |  | 699.7 |  |  | (89.1) |  |  | (7.8) | % |  | 440.2 |  |  | 62.9 | % |
| Percentage of total net sales | 14.7 | % |  | 21.9 | % |  | 19.7 | % |  |  |  |  |  |  |  |  |
| Europe | 1,003.1 |  |  | 825.2 |  |  | 614.8 |  |  | 177.9 |  |  | 21.6 | % |  | 210.4 |  |  | 34.2 | % |
| Percentage of total net sales | 14.1 | % |  | 15.9 | % |  | 17.3 | % |  |  |  |  |  |  |  |  |
| Others | 235.5 |  |  | 195.5 |  |  | 135.0 |  |  | 40.0 |  |  | 20.5 | % |  | 60.5 |  |  | 44.8 | % |
| Percentage of total net sales | 3.3 | % |  | 3.7 | % |  | 3.7 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 7,123.5 |  |  | $ | 5,196.1 |  |  | $ | 3,557.4 |  |  | $ | 1,927.4 |  |  | 37.1 | % |  | $ | 1,638.7 |  |  | 46.1 | % |

[0001375365-23-000036:mdna:52]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:53]
The year-over-year increase in overall net sales is the result of increased selling prices and units shipped of product  sold especially to large enterprise and datacenter customers. The United States experienced the highest percentage growth among all regions. This is due to increased demand from datacenter customers in the United States for GPU, high performance computing (“HPC”), and rack-scale solutions. The year-over-year decrease in Asia is mainly due to economic slowdown in China and Japan during fiscal year 2023 which heavily reduced the sales activities in that region.

[0001375365-23-000036:mdna:54]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:55]
The year-over-year increase in overall net sales is the result of increased selling prices and quantities of product shipments. Asia experienced the highest percentage growth among all regions. China, Japan and Korea exceeded the overall regional average of growth, which was the primary driver of the increases in net sales in Asia. Russia experienced a year over year decrease due to the conflict in that region, which decrease had an immaterial impact on our overall performance.

[0001375365-23-000036:mdna:56]
Cost of Sales and Gross Margin

[0001375365-23-000036:mdna:57]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production as well as economies of scale gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in average selling prices are not matched by corresponding changes in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions.

[0001375365-23-000036:mdna:58]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party, to optimize modular designs for our chassis and certain other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware combined represented 6.6%, 8.3% and 7.8% of our cost of sales for fiscal years 2023, 2022 and 2021, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 9, “Related Party Transactions.”

[0001375365-23-000036:mdna:59]
SMCI | 2023 Form 10-K | 42

[0001375365-23-000036:mdna:60]
Cost of sales and gross margin for fiscal years 2023, 2022 and 2021, are as follows (dollars in millions):

[0001375365-23-000036:mdna:61]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 5,840.5 |  |  | $ | 4,396.1 |  |  | $ | 3,022.9 |  |  | $ | 1,444.4 |  |  | 32.9 | % |  | $ | 1,373.2 |  |  | 45.4 | % |
| Gross profit | 1,283.0 |  |  | 800.0 |  |  | 534.5 |  |  | 483.0 |  |  | 60.4 | % |  | 265.5 |  |  | 49.7 | % |
| Gross margin | 18.0 | % |  | 15.4 | % |  | 15.0 | % |  |  |  | 2.6 | % |  |  |  | 0.4 | % |

[0001375365-23-000036:mdna:62]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:63]
The year-over-year increase in cost of sales was primarily attributed to an increase of $1,379.6 million in costs of materials and contract manufacturing expenses primarily related to the increased shipments of our products and solutions, a $59.2 million increase in overhead costs which includes labor costs attributed to increase of operation activities, a $36.6 million increase in inventory reserves, and a $13.6 million increase in other cost of sales partially offset by a $44.6 million decrease in freight charges due to a reduced need to expedite shipments due to disruptions in the supply chain caused by the COVID-19 pandemic.

[0001375365-23-000036:mdna:64]
The year-over-year increase in the gross margin percentage was primarily due to favorable product and customer mix and lower other cost of goods sold as a percentage of sales, based on higher volumes.

[0001375365-23-000036:mdna:65]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:66]
The year-over-year increase in cost of sales was primarily attributed to an increase of $1,262.6 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $54.9 million increase in freight charges, a $23.6 million increase in overhead costs, a $18.9 million increase due to lower cost recovery of cost paid in prior periods, a $8.3 million increase in excess and obsolete inventory charges and a $4.9 million increase in other cost of sales.

[0001375365-23-000036:mdna:67]
The year-over-year increase in the gross margin percentage was primarily due to sales prices increases, product and customer mix and higher capitalization of manufacturing overhead due to higher inventory levels, offset by higher costs from freight, overhead, other cost of sales, excess and obsolete inventory charges, and lower recovery of costs from prior periods.  Since the start of the COVID-19 pandemic, we have experienced an increase in costs of sales, logistics costs as well as direct labor costs as we incentivized our employees. This increase in costs negatively impacts our gross margin, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-23-000036:mdna:68]
Operating Expenses

[0001375365-23-000036:mdna:69]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering ("NRE") funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-23-000036:mdna:70]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-23-000036:mdna:71]
SMCI | 2023 Form 10-K | 43

[0001375365-23-000036:mdna:72]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-23-000036:mdna:73]
Operating expenses for fiscal years 2023, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000036:mdna:74]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 307.3 |  |  | $ | 272.3 |  |  | $ | 224.4 |  |  | $ | 35.0 |  |  | 12.9 | % |  | $ | 47.9 |  |  | 21.3 | % |
| Percentage of total net sales | 4.3 | % |  | 5.2 | % |  | 6.3 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 115.0 |  |  | 90.1 |  |  | 85.7 |  |  | 24.9 |  |  | 27.6 | % |  | 4.4 |  |  | 5.1 | % |
| Percentage of total net sales | 1.6 | % |  | 1.7 | % |  | 2.4 | % |  |  |  |  |  |  |  |  |
| General and administrative | 99.6 |  |  | 102.4 |  |  | 100.5 |  |  | (2.8) |  |  | (2.7) | % |  | 1.9 |  |  | 1.9 | % |
| Percentage of total net sales | 1.4 | % |  | 2.0 | % |  | 2.8 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 521.9 |  |  | $ | 464.8 |  |  | $ | 410.6 |  |  | 57.1 |  |  | 12.3 | % |  | 54.2 |  |  | 13.2 | % |

[0001375365-23-000036:mdna:75]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:76]
The year-over-year increase in research and development expenses was primarily driven by a $43.5 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards as we expanded our workforce and invested in key talent, and a $2.6 million increase in product development costs to support the development of next generation products and technologies, offset by a $11.1 million increase in research and development credits received from certain suppliers and customers.

[0001375365-23-000036:mdna:77]
The year-over-year increase in sales and marketing expenses was primarily driven by a $23.8 million increase in compensation expenses due to salary increases, higher headcount and the cost of equity awards and a $4.6 million increase in travel and trade show expenses to drive new sales opportunities for our products and customer support, offset by a $3.5 million increase in marketing development funds received.

[0001375365-23-000036:mdna:78]
The year-over-year decrease in general and administrative expenses was primarily due to a $5.2 million decrease in professional fees and other, a $2.0 million decrease in litigation settlement expenses relating to a derivative lawsuit, partially offset by an increase of $4.4 million in compensation expenses associated with the cost of equity awards.

[0001375365-23-000036:mdna:79]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:80]
The year-over-year increase in research and development expenses was primarily due to a $40.8 million increase in personnel expenses due to salary increases and a higher headcount, $3.7 million lower research and development credits from certain suppliers and customers towards our development efforts and a $3.4 million increase in product development costs.

[0001375365-23-000036:mdna:81]
The year-over-year increase in sales and marketing expenses was primarily due to a $9.6 million increase in personnel expenses due to salary increases and a higher headcount, offset by a $5.7 million increase in marketing development funds received and a $0.5 million increase in advertising and other expenses.

[0001375365-23-000036:mdna:82]
The year-over-year increase in general and administrative expenses was primarily due to a $4.1 million increase in legal and litigation settlement expenses and $6.6 million increase in personnel and other expenses due to salary increases and a higher headcount offset by decrease of $1.5 million in professional fees driven by lower expenses incurred to remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of our previously issued financial statements and a $7.3 million decrease in expense from special performance awards.

[0001375365-23-000036:mdna:83]
Interest and Other Income (Expense), Net

[0001375365-23-000036:mdna:84]
Other income (expense), net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-23-000036:mdna:85]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-23-000036:mdna:86]
SMCI | 2023 Form 10-K | 44

[0001375365-23-000036:mdna:87]
Interest and other income (expense), net for fiscal years 2023, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000036:mdna:88]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Other income (expense), net | $ | 3.6 |  |  | $ | 8.1 |  |  | $ | (2.8) |  |  | $ | (4.5) |  |  | (55.6) | % |  | $ | 10.9 |  |  | (389.3) | % |
| Interest expense | (10.5) |  |  | (6.4) |  |  | (2.5) |  |  | (4.1) |  |  | 64.1 | % |  | (3.9) |  |  | 156.0 | % |
| Interest and other income (expense), net | $ | (6.9) |  |  | $ | 1.7 |  |  | $ | (5.3) |  |  | $ | (8.6) |  |  | (505.9) | % |  | $ | 7.0 |  |  | (132.1) | % |

[0001375365-23-000036:mdna:89]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:90]
The change of $8.6 million in interest and other income (expense), net was primarily attributable to a $4.5 million decrease in foreign exchange gain due to unfavorable currency fluctuations primarily related to our borrowing facilities in Taiwan and a $4.1 million increase in interest expense due to increase in interest rates on our outstanding loan balances.

[0001375365-23-000036:mdna:91]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:92]
The change of $7.0 million in interest and other income (expense), net was primarily attributable to a $10.9 million increase in foreign exchange gain due to favorable currency fluctuations primarily related to our borrowing facilities in Taiwan offset by a $3.9 million increase in interest expense due to increase in loan balances and interest rates.

[0001375365-23-000036:mdna:93]
Provision for Income Taxes

[0001375365-23-000036:mdna:94]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock-based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 11, “Income Taxes” to the consolidated financial statements in this Annual Report.

[0001375365-23-000036:mdna:95]
Provision for income taxes and effective tax rates for fiscal years 2023, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000036:mdna:96]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 110.7 |  |  | $ | 52.9 |  |  | $ | 6.9 |  |  | $ | 57.8 |  |  | 109.3 | % |  | $ | 46.0 |  |  | 666.7 | % |
| Percentage of total net sales | 1.6 | % |  | 1.0 | % |  | 0.2 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 14.7 | % |  | 15.7 | % |  | 5.8 | % |  |  |  |  |  |  |  |  |

[0001375365-23-000036:mdna:97]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:98]
The year-over-year decrease in the effective tax rate is attributable to higher tax deductions from disqualified disposition of stock-based compensation, an increase in the R&D tax credit, and an increase in foreign-derived income. As a result of these favorable elements which were partially offset by certain unfavorable items including an increase in state taxes, the total effective tax rate decreased by 1%, declining from 15.7% in the fiscal year ended June 30, 2022, to 14.7% in the fiscal year ended June 30, 2023.

[0001375365-23-000036:mdna:99]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:100]
The year-over-year increase in the effective tax rate was primarily due to a significant increase in revenue and income before tax. Total effective tax rate increased by 9.5% from 5.8% for the fiscal year ended June 30, 2021 to 15.7% for the fiscal year ended June 30, 2022. This increase was driven by a 15.4% increase in the overall effective tax rate. R&D credit reduced the effective tax rate by 3.5% and foreign derived income reduced the effective tax rate by 1.4%.

[0001375365-23-000036:mdna:101]
Share of Income (Loss) from Equity Investee, Net of Taxes

[0001375365-23-000036:mdna:102]
Share of income from equity investee, net of taxes represents our share of income (loss) from the Corporate Venture in which we have a 30% ownership.

[0001375365-23-000036:mdna:103]
SMCI | 2023 Form 10-K | 45

[0001375365-23-000036:mdna:104]
Share of income (loss) from equity investee, net of taxes for fiscal years 2023, 2022 and 2021 are as follows (dollars in millions):

[0001375365-23-000036:mdna:105]
|  | Years Ended June 30, |  | 2023 over 2022 Change |  | 2022 over 2021 Change |
|  | 2023 |  | 2022 |  | 2021 |  | $ |  | % |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | (3.6) |  |  | $ | 1.2 |  |  | $ | 0.2 |  |  | $ | (4.8) |  |  | (400.0) | % |  | $ | 1.0 |  |  | (500.0) | % |
| Percentage of total net sales | — | % |  | — | % |  | — | % |  |  |  |  |  |  |  |  |

[0001375365-23-000036:mdna:106]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-23-000036:mdna:107]
The period-over-period decrease of $4.8 million in share of income from equity investee, net of taxes was primarily due to lower net income recognized by the Corporate Venture.

[0001375365-23-000036:mdna:108]
Fiscal Year 2022 Compared with Fiscal Year 2021

[0001375365-23-000036:mdna:109]
The period-over-period increase of $1.0 million in share of income from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-23-000036:mdna:110]
Liquidity and Capital Resources

[0001375365-23-000036:mdna:111]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to an increase in the need for working capital due to longer supply chain manufacturing and delivery times as well as the financing of real property acquisitions and funds received from the exercise of employee stock options. Our cash and cash equivalents were $440.5 million and $267.4 million as of June 30, 2023 and 2022, respectively. Our cash in foreign locations was $192.3 million and $169.5 million as of June 30, 2023 and 2022, respectively.

[0001375365-23-000036:mdna:112]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-23-000036:mdna:113]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these consolidated financial statements. On June 17, 2023, the Company through the Taiwan subsidiary, entered into a Notification and Confirmation pursuant to which the Taiwan subsidiary and E.SUN Bank agreed to drawdowns of up to US$30 million for an import o/a financing loan with a tenor of 120 days (the “2023 Import O/A Loan”). We continue to evaluate financing options that may be required to support the growth of our business, if it occurs more rapidly than anticipated.

[0001375365-23-000036:mdna:114]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved the Prior Repurchase Program, which permitted us to repurchase up to an aggregate of $200.0 million of our common stock at market prices. The program was effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. We had $150.0 million of remaining availability under the Prior Repurchase Program as of June 30, 2022, and such program subsequently expired on July 31, 2022.

[0001375365-23-000036:mdna:115]
On August 3, 2022, after the expiration of the Prior Share Repurchase Program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program is effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurs first. We repurchased 1,553,350 shares of common stock for $150 million during the fiscal year ended June 30, 2023 under this program and had $50.0 million of remaining availability as of June 30, 2023.

[0001375365-23-000036:mdna:116]
SMCI | 2023 Form 10-K | 46

[0001375365-23-000036:mdna:117]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-23-000036:mdna:118]
|  | Years Ended June 30, |  | 2023 over 2022 |  | 2022 over 2021 |  |  |
|  | 2023 |  | 2022 |  | 2021 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 663.6 |  |  | $ | (440.8) |  |  | $ | 123.0 |  |  | $ | 1,104.4 |  |  | $ | (563.8) |  |  |  |
| Net cash used in investing activities | $ | (39.5) |  |  | $ | (46.3) |  |  | $ | (58.0) |  |  | $ | 6.8 |  |  | $ | 11.7 |  |  |  |
| Net cash (used in) provided by financing activities | $ | (448.3) |  |  | $ | 522.9 |  |  | $ | (44.4) |  |  | $ | (971.2) |  |  | $ | 567.3 |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 172.4 |  |  | $ | 35.1 |  |  | $ | 21.1 |  |  | $ | 137.3 |  |  | $ | 14.0 |  |  |  |

[0001375365-23-000036:mdna:119]
Operating Activities

[0001375365-23-000036:mdna:120]
Net cash provided by operating activities increased by $1,104.4 million for fiscal year 2023 as compared to fiscal year 2022. The increase was primarily due to an increase in net cash provided from net working capital of $796.7 million, a $354.8 million increase in net income due to the increase in sales of our products and solutions, a $21.6 million increase in stock-based compensation expense as a result of an increase in the cost of equity awards, a $11.1 million decrease in unrealized gain due to currency fluctuation, and a $6.4 million increase in other non-cash items. These changes are offset by an increase of $86.2 million in deferred income taxes primarily due to increase in capitalized research and development costs.

[0001375365-23-000036:mdna:121]
Net cash provided by operating activities decreased by $563.8 million for fiscal year 2022 as compared to fiscal year 2021. The decrease was primarily due to an increase in net cash required for net working capital of $739.6 million to meet customer demand, support expected business growth and mitigate supply chain risk as a result of the COVID-19 pandemic environment and a $16.2 million decrease in unrealized gain and loss. These decreases are partially offset by increases in provision for excess and obsolete inventories of $8.3 million, depreciation and amortization expense of $4.3 million, stock-based compensation expense of $4.3 million and net income of $173.3 million. Since the beginning of the COVID-19 pandemic and the accompanying supply chain disruptions our management decided to increase our holdings of all components of our inventory (finished goods, work in process and purchased parts and raw materials). This decision reflected our belief that we had opportunities to increase our net sales if we could mitigate the risk of being unable to satisfy customer demand because of these supply chain disruptions, including longer lead times. We expect disruption of the supply chain and longer lead times to continue for the foreseeable future and therefore expect to continue to carry larger amounts of inventory than we would if the supply chain were functioning more normally and predictably.

[0001375365-23-000036:mdna:122]
Investing Activities

[0001375365-23-000036:mdna:123]
Net cash used in investing activities was $39.5 million, $46.3 million and $58.0 million for fiscal years 2023, 2022 and 2021, respectively, as we invested in our Green Computing Park in San Jose to expand our manufacturing capacity and office, expanded our Bade Facility in Taiwan and made purchases of property, plant and equipment.

[0001375365-23-000036:mdna:124]
Financing Activities

[0001375365-23-000036:mdna:125]
Net cash used in financing activities increased by $971.2 million for fiscal year 2023 as compared to fiscal year 2022 primarily due to repurchases of our common stock for $150.0 million reflecting our commitment to return value to our shareholders and repayment of net borrowings of $813.2 million. Net cash used in financing activities increased by $567.3 million for fiscal year 2022 as compared to fiscal year 2021 primarily due to an increase of $446.2 million in proceeds from borrowings net of repayment, offset by a $130.0 million decrease in stock repurchases.

[0001375365-23-000036:mdna:126]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-23-000036:mdna:127]
Refer to Part II, Item 8, Note 7, “Short-term and Long-term Debt” in our notes to consolidated financial statements in this Annual Report on Form 10-K for further information on our outstanding debt.

[0001375365-23-000036:mdna:128]
SMCI | 2023 Form 10-K | 47

[0001375365-23-000036:mdna:129]
Capital Expenditure Requirements

[0001375365-23-000036:mdna:130]
We anticipate our capital expenditures in fiscal year 2024 will be in range of $105.0 million to $115.0 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. During the second quarter of fiscal year 2023, we entered into a letter of understanding to acquire land in Malaysia to expand our manufacturing operations. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. We are obtaining early access to such land prior to the acquisition, and we anticipate additional capital expenditures in fiscal year 2024 of $75.0 million (included in the above range) for such initiative. In addition, we will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-23-000036:mdna:131]
We intend to continue to focus our capital expenditures in fiscal year 2024 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our office facilities and our IT system infrastructure.

[0001375365-23-000036:mdna:132]
Contractual Obligations

[0001375365-23-000036:mdna:133]
Our estimated future obligations as of June 30, 2023, include both current and long term obligations. For our long-term debt as noted in Part II, Item 8, Note 7, “Short-term and Long-term Debt”, we have a current obligation of $170.1 million and a long-term obligation of $120.2 million. Under our operating leases as noted in Part II, Item 8, Note 8, "Leases", we have a current obligation of $7.8 million and a long-term obligation of $12.2 million. As noted in Part II, Item 8, Note 12, "Commitments and Contingencies", we have current obligations related to noncancelable purchase commitments of $2.3 billion.

[0001375365-23-000036:mdna:134]
We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of

[0001375365-23-000036:mdna:135]
when the related tax settlements will become due. See Part II, Item 8, Note 11, “Income Taxes” to the consolidated financial statements in this Annual Report for a discussion of income taxes.

[0001375365-23-000036:mdna:136]
Recent Accounting Pronouncements

[0001375365-23-000036:mdna:137]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report.

[0001375365-23-000036:mdna:138]
SMCI | 2023 Form 10-K | 48
