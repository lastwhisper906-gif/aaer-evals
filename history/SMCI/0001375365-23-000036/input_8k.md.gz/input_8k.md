# SMCI 8-K — 0001375365-23-000034 filed 2023-08-08

## item codes, every 8-K on or before 2023-08-28

- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2023-08-28

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-23-000034:8k_2_02:1]
EX-99.1
2
exhibit991_20230630.htm
EX-99.1

[0001375365-23-000034:8k_2_02:2]
Document

[0001375365-23-000034:8k_2_02:3]
Exhibit 99.1

[0001375365-23-000034:8k_2_02:4]
Supermicro Announces Fourth Quarter and Full Year Fiscal Year 2023

[0001375365-23-000034:8k_2_02:5]
Financial Results

[0001375365-23-000034:8k_2_02:6]
SAN JOSE, Calif. -- August 8, 2023 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a Total IT Solution Provider for Cloud, AI/ML, Storage, and 5G/Edge, today announced fourth quarter and full-year financial results for fiscal year 2023 ended June 30, 2023.

[0001375365-23-000034:8k_2_02:7]
Fourth Quarter of Fiscal Year 2023 Highlights

[0001375365-23-000034:8k_2_02:8]
•Net sales of $2.18 billion versus $1.28 billion in the third quarter of fiscal year 2023 and $1.64 billion in the same quarter of last year.

[0001375365-23-000034:8k_2_02:9]
•Gross margin of 17.0% versus 17.6% in the third quarter of fiscal year 2023 and 17.6% in the same quarter of last year.

[0001375365-23-000034:8k_2_02:10]
•Net income of $194 million versus $86 million in the third quarter of fiscal year 2023 and $141 million in the same quarter of last year.

[0001375365-23-000034:8k_2_02:11]
•Diluted net income per common share of $3.43 versus $1.53 in the third quarter of fiscal year 2023 and $2.60 in the same quarter of last year.

[0001375365-23-000034:8k_2_02:12]
•Non-GAAP diluted net income per common share of $3.51 versus $1.63 in the third quarter of fiscal year 2023 and $2.62 in the same quarter of last year.

[0001375365-23-000034:8k_2_02:13]
•Cash flow used in operations for the fourth quarter of fiscal year 2023 of $9 million and capital expenditures of $8 million.

[0001375365-23-000034:8k_2_02:14]
Non-GAAP gross margin for the fourth quarter of fiscal year 2023 was 17.1%, which adds back stock-based compensation expense of $1 million. Non-GAAP diluted net income per common share for the fourth quarter of fiscal year 2023 was $3.51, with adjustments for stock-based compensation expenses of $13 million, net of the related tax effects of $5 million.

[0001375365-23-000034:8k_2_02:15]
As of June 30, 2023, total cash and cash equivalents was $440 million and bank debt was $290 million.

[0001375365-23-000034:8k_2_02:16]
“Supermicro’s record revenue and 37% year-over-year growth for fiscal year 2023 validates our global leadership position in AI accelerated compute platforms,” said Charles Liang, President and CEO of Supermicro. “We continue to see unprecedented demand for AI and other advanced applications requiring optimized rack-scale solutions. We are in a great position to continue our growth momentum given our record new design wins, customers, and backlog for our best-in-class rack-scale Total AI & IT Solutions.”

[0001375365-23-000034:8k_2_02:17]
Fiscal Year 2023 Summary

[0001375365-23-000034:8k_2_02:18]
Net sales for the fiscal year ended June 30, 2023, were $7.12 billion versus $5.20 billion for the fiscal year ended June 30, 2022. Net income for fiscal year 2023 was $640 million, or $11.43 per diluted share, versus $285 million, or $5.32 per diluted share, for fiscal year 2022. Non-GAAP net income for fiscal year 2023 was $673 million, or $11.81 per diluted share, versus $311 million, or $5.65 per diluted share, for fiscal year 2022. Non-GAAP net income for fiscal year 2023 adds back stock-based compensation expense of $54 million and litigation recovery of $4 million, net of the related tax effects of $17 million.

[0001375365-23-000034:8k_2_02:19]
Business Outlook and Management Commentary

[0001375365-23-000034:8k_2_02:20]
For the first quarter of fiscal year 2024 ending September 30, 2023, the Company expects net sales of $1.90 billion to $2.20 billion, GAAP net income per diluted share of $2.02 to $2.80 and non-GAAP net income per diluted share of $2.75 to $3.50. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 14.7% and 15.4%, respectively, and a fully diluted share count of 56 million shares for GAAP and fully diluted share count of 57 million shares for non-GAAP. The outlook for Q1 of fiscal year 2024 GAAP net income per diluted share includes approximately $44 million in expected stock-based compensation expense and other expenses, net of related tax effects of $9 million, which are excluded from non-GAAP net income per diluted share.

[0001375365-23-000034:8k_2_02:21]
For fiscal year 2024 ending June 30, 2024, the Company expects net sales of $9.5 billion to $10.5 billion.

[0001375365-23-000034:8k_2_02:22]
Conference Call and Webcast Information

[0001375365-23-000034:8k_2_02:23]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its fourth quarter and full-year fiscal 2023 financial results. Those wishing to access the live webcast may use the following link:

[0001375365-23-000034:8k_2_02:24]
https://events.q4inc.com/attendee/910502687

[0001375365-23-000034:8k_2_02:25]
The conference call can be accessed by registering online at:

[0001375365-23-000034:8k_2_02:26]
https://conferencingportals.com/event/AcFjVwZF

[0001375365-23-000034:8k_2_02:27]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-23-000034:8k_2_02:28]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-23-000034:8k_2_02:29]
Cautionary Statement Regarding Forward-Looking Statements

[0001375365-23-000034:8k_2_02:30]
Use of Non-GAAP Financial Measures

[0001375365-23-000034:8k_2_02:31]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, litigation settlement costs, special performance bonuses and litigation expense (recovery), adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of GAAP gross margin to non-GAAP gross margin and from GAAP diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-23-000034:8k_2_02:32]
About Super Micro Computer, Inc.

[0001375365-23-000034:8k_2_02:33]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming into a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power, and chassis products. The products are designed and manufactured in-house (in US, Taiwan, and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-23-000034:8k_2_02:34]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-23-000034:8k_2_02:35]
Investor Relations Contact:

[0001375365-23-000034:8k_2_02:36]
Nicole Noutsios

[0001375365-23-000034:8k_2_02:37]
email: ir@supermicro.com

[0001375365-23-000034:8k_2_02:38]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000034:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-23-000034:8k_2_02:40]
(in thousands)

[0001375365-23-000034:8k_2_02:41]
(unaudited)

[0001375365-23-000034:8k_2_02:42]
|  | June 30, |  | June 30, |
|  | 2023 |  | 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 440,459 |  |  | $ | 267,397 |  |
| Accounts receivable, net of allowance for credit losses | 1,148,259 |  |  | 834,513 |
| Inventories | 1,445,564 |  |  | 1,545,606 |
| Prepaid expenses and other current assets | 145,144 |  |  | 158,799 |  |
| Total current assets | 3,179,426 |  |  | 2,806,315 |  |
| Property, plant and equipment, net | 290,240 |  |  | 285,972 |
| Deferred income taxes, net | 162,654 |  |  | 69,929 |  |
| Other assets | 42,409 |  |  | 42,861 |  |
| Total assets | $ | 3,674,729 |  |  | $ | 3,205,077 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 776,831 |  |  | $ | 655,403 |  |
| Accrued liabilities | 163,865 |  |  | 212,419 |  |
| Income taxes payable | 129,166 |  |  | 41,743 |  |
| Short-term debt | 170,123 |  |  | 449,146 |  |
| Deferred revenue | 134,667 |  |  | 111,313 |  |
| Total current liabilities | 1,374,652 |  |  | 1,470,024 |  |
| Deferred revenue, non-current | 169,781 |  |  | 122,548 |  |
| Long-term debt | 120,179 |  |  | 147,618 |  |
| Other long-term liabilities | 37,947 |  |  | 39,140 |  |
| Total liabilities | 1,702,559 |  |  | 1,779,330 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid in capital | 538,352 |  |  | 481,741 |  |
| Accumulated other comprehensive income | 639 |  |  | 911 |  |
| Retained earnings | 1,433,014 |  |  | 942,923 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,972,005 |  |  | 1,425,575 |  |
| Noncontrolling interest | 165 |  |  | 172 |  |
| Total stockholders’ equity | 1,972,170 |  |  | 1,425,747 |  |
| Total liabilities and stockholders’ equity | $ | 3,674,729 |  |  | $ | 3,205,077 |  |

[0001375365-23-000034:8k_2_02:43]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000034:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-23-000034:8k_2_02:45]
(in thousands, except per share amounts)

[0001375365-23-000034:8k_2_02:46]
(unaudited)

[0001375365-23-000034:8k_2_02:47]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 2,184,861 |  |  | $ | 1,635,460 |  |  | $ | 7,123,482 |  |  | $ | 5,196,099 |  |
| Cost of sales | 1,813,165 |  |  | 1,348,116 |  |  | 5,840,470 |  |  | 4,396,098 |  |
| Gross profit | 371,696 |  |  | 287,344 |  |  | 1,283,012 |  |  | 800,001 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 84,802 |  |  | 70,790 |  |  | 307,260 |  |  | 272,273 |  |
| Sales and marketing | 31,905 |  |  | 24,186 |  |  | 115,025 |  |  | 90,126 |  |
| General and administrative | 28,234 |  |  | 27,155 |  |  | 99,585 |  |  | 102,435 |  |
| Total operating expenses | 144,941 |  |  | 122,131 |  |  | 521,870 |  |  | 464,834 |  |
| Income from operations | 226,755 |  |  | 165,213 |  |  | 761,142 |  |  | 335,167 |  |
| Other income, net | 2,005 |  |  | 3,973 |  |  | 3,646 |  |  | 8,079 |  |
| Interest expense | (3,509) |  |  | (2,928) |  |  | (10,491) |  |  | (6,413) |  |
| Income before income tax | 225,251 |  |  | 166,258 |  |  | 754,297 |  |  | 336,833 |  |
| Income tax provision | (31,302) |  |  | (25,760) |  |  | (110,666) |  |  | (52,876) |  |
| Share of (loss) income from equity investee, net of taxes | (380) |  |  | 324 |  |  | (3,633) |  |  | 1,206 |  |
| Net income | $ | 193,569 |  |  | $ | 140,822 |  |  | $ | 639,998 |  |  | $ | 285,163 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 3.67 |  |  | $ | 2.70 |  |  | $ | 12.09 |  |  | $ | 5.54 |  |
| Diluted | $ | 3.43 |  |  | $ | 2.60 |  |  | $ | 11.43 |  |  | $ | 5.32 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 52,679 |  |  | 52,111 |  |  | 52,925 |  |  | 51,478 |  |
| Diluted | 56,505 |  |  | 54,260 |  |  | 55,970 |  |  | 53,615 |  |

[0001375365-23-000034:8k_2_02:48]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-23-000034:8k_2_02:49]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of sales | $ | 989 |  |  | $ | 498 |  |  | $ | 4,574 |  |  | $ | 1,876 |  |
| Research and development | 7,187 |  | 4,447 |  | 30,736 |  |  | 16,571 |  |
| Sales and marketing | 1,128 |  | 541 |  | 4,599 |  |  | 2,058 |  |
| General and administrative | 3,482 |  | 3,398 |  | 14,524 |  |  | 12,311 |  |
| Stock-based compensation expense | $ | 12,786 |  |  | $ | 8,884 |  |  | $ | 54,433 |  |  | $ | 32,816 |  |

[0001375365-23-000034:8k_2_02:50]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000034:8k_2_02:51]
SELECTED CASH FLOW INFORMATION

[0001375365-23-000034:8k_2_02:52]
(in thousands)

[0001375365-23-000034:8k_2_02:53]
(unaudited)

[0001375365-23-000034:8k_2_02:54]
|  | Years Ended June 30, |
|  | 2023 |  | 2022 |
| Net cash provided by (used in) operating activities | $ | 663,580 |  |  | $ | (440,801) |  |
| Net cash used in investing activities | (39,486) |  |  | (46,282) |  |
| Net cash (used in) provided by financing activities | (448,293) |  |  | 522,871 |  |
| Effect of exchange rate fluctuations on cash | (3,400) |  |  | (678) |  |
| Net increase in cash, cash equivalents and restricted cash | 172,401 |  |  | 35,110 |  |
| Cash, cash equivalents and restricted cash at the beginning of the year | 268,559 |  |  | 233,449 |  |
| Cash, cash equivalents and restricted cash at the end of the year | $ | 440,960 |  |  | $ | 268,559 |  |

[0001375365-23-000034:8k_2_02:55]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000034:8k_2_02:56]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000034:8k_2_02:57]
(in thousands, except per share amounts)

[0001375365-23-000034:8k_2_02:58]
(unaudited)

[0001375365-23-000034:8k_2_02:59]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| GAAP GROSS PROFIT | $ | 371,696 |  |  | $ | 287,344 |  |  | $ | 1,283,012 |  |  | $ | 800,001 |  |  |
| Stock-based compensation | 989 |  |  | 498 |  |  | 4,574 |  |  | 1,876 |  |  |
| Other expenses | — |  |  | — |  |  | — |  |  | 295 |  |  |
| NON-GAAP GROSS PROFIT | $ | 372,685 |  |  | $ | 287,842 |  |  | $ | 1,287,586 |  |  | $ | 802,172 |  |  |
| GAAP GROSS MARGIN | 17.0 | % |  | 17.6 | % |  | 18.0 | % |  | 15.4 | % |  |
| Stock-based compensation | 0.1 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  |
| Other expenses | — | % |  | — | % |  | — | % |  | 0.0 | % |  |
| NON-GAAP GROSS MARGIN | 17.1 | % |  | 17.6 | % |  | 18.1 | % |  | 15.4 | % |  |
| GAAP OPERATING EXPENSES | $ | 144,941 |  |  | $ | 122,131 |  |  | $ | 521,870 |  |  | $ | 464,834 |  |  |
| Stock-based compensation | (11,797) |  |  | (8,386) |  |  | (49,859) |  |  | (30,940) |  |  |
| Litigation settlement costs | — |  |  | — |  |  | — |  |  | (2,000) |  |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | (158) |  |  |
| Litigation (expense) recovery | — |  |  | (234) |  |  | 3,770 |  |  | (4,367) |  |  |
| NON-GAAP OPERATING EXPENSES | $ | 133,144 |  |  | $ | 113,511 |  |  | $ | 475,781 |  |  | $ | 427,369 |  |  |
| GAAP INCOME FROM OPERATIONS | $ | 226,755 |  |  | $ | 165,213 |  |  | $ | 761,142 |  |  | $ | 335,167 |  |  |
| Stock-based compensation | 12,786 |  |  | 8,884 |  |  | 54,433 |  |  | 32,816 |  |  |
| Litigation settlement costs | — |  |  | — |  |  | — |  |  | 2,000 |  |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |  |
| Litigation expense (recovery) | — |  |  | 234 |  |  | (3,770) |  |  | 4,367 |  |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 239,541 |  |  | $ | 174,331 |  |  | $ | 811,805 |  |  | $ | 374,803 |  |  |
| GAAP OPERATING MARGIN | 10.4 | % |  | 10.1 | % |  | 10.7 | % |  | 6.5 | % |  |
| Stock-based compensation | 0.6 | % |  | 0.6 | % |  | 0.8 | % |  | 0.6 | % |  |
| Litigation settlement costs | — | % |  | — | % |  | — | % |  | 0.0 | % |  |
| Special performance bonuses | — | % |  | — | % |  | — | % |  | 0.0 | % |  |
| Litigation expense (recovery) | — | % |  | 0.0 | % |  | (0.1) | % |  | 0.1 | % |  |
| NON-GAAP OPERATING MARGIN | 11.0 | % |  | 10.7 | % |  | 11.4 | % |  | 7.2 | % |  |
| GAAP TAX EXPENSE | $ | 31,302 |  |  | $ | 25,760 |  |  | $ | 110,666 |  |  | $ | 52,876 |  |  |
| Adjustments to tax provision | 5,304 |  |  | 4,137 |  |  | 17,267 |  |  | 13,721 |  |  |
| NON-GAAP TAX EXPENSE | $ | 36,606 |  |  | $ | 29,897 |  |  | $ | 127,933 |  |  | $ | 66,597 |  |  |
| GAAP NET INCOME | $ | 193,569 |  |  | $ | 140,822 |  |  | $ | 639,998 |  |  | $ | 285,163 |  |  |

[0001375365-23-000034:8k_2_02:60]
SUPER MICRO COMPUTER, INC.

[0001375365-23-000034:8k_2_02:61]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-23-000034:8k_2_02:62]
(in thousands, except per share amounts)

[0001375365-23-000034:8k_2_02:63]
(unaudited)

[0001375365-23-000034:8k_2_02:64]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Stock-based compensation | 12,786 |  |  | 8,884 |  |  | 54,433 |  |  | 32,816 |  |  |
| Litigation settlement costs | — |  |  | — |  |  | — |  |  | 2,000 |  |  |
| Special performance bonuses | — |  |  | — |  |  | — |  |  | 453 |  |  |
| Litigation expense (recovery) | — |  |  | 234 |  |  | (3,770) |  |  | 4,367 |  |  |
| Adjustments to tax provision | (5,304) |  |  | (4,137) |  |  | (17,267) |  |  | (13,721) |  |  |
| NON-GAAP NET INCOME | $ | 201,051 |  |  | $ | 145,803 |  |  | $ | 673,394 |  |  | $ | 311,078 |  |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.67 |  |  | $ | 2.70 |  |  | $ | 12.09 |  |  | $ | 5.54 |  |  |
| Impact of NON-GAAP adjustments | 0.15 |  |  | 0.10 |  |  | 0.63 |  |  | 0.50 |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 3.82 |  |  | $ | 2.80 |  |  | $ | 12.72 |  |  | $ | 6.04 |  |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.43 |  |  | $ | 2.60 |  |  | $ | 11.43 |  |  | $ | 5.32 |  |  |
| Impact of NON-GAAP adjustments | 0.08 |  |  | 0.02 |  |  | 0.38 |  |  | 0.33 |  |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 3.51 |  |  | $ | 2.62 |  |  | $ | 11.81 |  |  | $ | 5.65 |  |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 52,679 |  |  | 52,111 |  |  | 52,925 |  |  | 51,478 |  |  |
| BASIC – NON-GAAP | 52,679 |  |  | 52,111 |  |  | 52,925 |  |  | 51,478 |  |  |
| DILUTED – GAAP | 56,505 |  |  | 54,260 |  |  | 55,970 |  |  | 53,615 |  |  |
| DILUTED – NON-GAAP | 57,222 |  |  | 55,611 |  |  | 57,027 |  |  | 55,025 |  |  |

[0001375365-23-000034:8k_2_02:65]
Non-GAAP diluted net income per common share for the third quarter of fiscal year 2023 was $1.63, with adjustments for stock-based compensation expenses of $14 million and $2 million litigation expense recovery, net of the related tax effects of $4 million.
