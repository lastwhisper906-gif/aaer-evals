# SMCI 8-K — 0001628280-15-002702 filed 2015-04-21

## item codes, every 8-K on or before 2015-05-07

- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2015-05-07

- none on or before 2015-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-002702:8k_2_02:1]
EX-99.1
2
exhibit991q32015.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-15-002702:8k_2_02:2]
Exhibit 991 Q32015

[0001628280-15-002702:8k_2_02:3]
Exhibit 99.1

[0001628280-15-002702:8k_2_02:4]
Super Micro Computer, Inc. Announces 3rd Quarter 2015 Financial Results

[0001628280-15-002702:8k_2_02:5]
SAN JOSE, Calif., April 21, 2015 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a leader in application optimized, high performance server solutions, today announced third quarter of fiscal 2015 financial results for the quarter ended March 31, 2015.

[0001628280-15-002702:8k_2_02:6]
Fiscal 3rd Quarter Highlights

[0001628280-15-002702:8k_2_02:7]
| • | Quarterly net sales of $471.2 million, down 6.3% from the second quarter of fiscal year 2015 and up 26.1% from the same quarter of last year. |

[0001628280-15-002702:8k_2_02:8]
| • | GAAP net income of $23.1 million, down 26.2% from the second quarter of fiscal year 2015 and up 39.1% from the same quarter of last year. |

[0001628280-15-002702:8k_2_02:9]
| • | GAAP gross margin of 16.3%, down from 16.8% in the second quarter of fiscal year 2015 and up from 15.3% in the same quarter of last year. |

[0001628280-15-002702:8k_2_02:10]
| • | Server solutions accounted for 64.1% of net sales compared with 60.1% in the second quarter of fiscal year 2015 and 50.1% in the same quarter of last year. |

[0001628280-15-002702:8k_2_02:11]
Net sales for the third quarter ended March 31, 2015 totaled $471.2 million, down 6.3% from $503.0 million in the second quarter of fiscal year 2015. One customer accounted for more than 10% of net sales during the quarter ended March 31, 2015.

[0001628280-15-002702:8k_2_02:12]
GAAP net income for the third quarter of fiscal year 2015 was $23.1 million or $0.44 per diluted share, an increase of 39.1% from the net income of $16.6 million, or $0.35 per diluted share in the same period a year ago. Included in net income for the quarter is $3.6 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the third quarter was $24.9 million, or $0.47 per diluted share, compared to non-GAAP net income of $17.8 million, or $0.37 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income decreased from the second quarter of fiscal year 2015 by $8.6 million or $0.18 per diluted share.

[0001628280-15-002702:8k_2_02:13]
GAAP gross margin for the third quarter was 16.3% compared to 15.3% in the same period a year ago. Non-GAAP gross margin for the third quarter was 16.3% compared to 15.4% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the second quarter of fiscal year 2015 were both 16.8%.

[0001628280-15-002702:8k_2_02:14]
The Company's cash and cash equivalents and short and long term investments at March 31, 2015 were $112.0 million compared to $99.6 million at June 30, 2014. Free cash flow for the nine months ended March 31, 2015 was $(15.6) million, primarily due to the development and construction of improvements on the Company's property, which is still in progress, offset in part by an increase in the Company's cash provided by operating activities.

[0001628280-15-002702:8k_2_02:15]
Business Outlook & Management Commentary

[0001628280-15-002702:8k_2_02:16]
The Company expects net sales of $510 million to $560 million for the fourth quarter of fiscal year 2015 ending June 30, 2015. The Company expects non-GAAP earnings per diluted share of approximately $0.53 to $0.62 for the fourth quarter.

[0001628280-15-002702:8k_2_02:17]
“Supermicro again delivered industry leading growth in the third quarter with 26.1% year over year growth in a seasonally affected quarter. We continued our strong pace of growth in our server and storage solutions business contributing 64.1% of total revenue and with 53.9% of revenues coming from the OEM and Direct customers. Storage, GPU/Xeon Phi, and our Twin family solutions continue to grow strongly year over year, “ said Charles Liang, Chairman and CEO.  “As we approach the final quarter of this fiscal year we are excited about our opportunities to improve our strong growth trend. Our offerings for Storage, HPC, Enterprise, Datacenter, Cloud and Service are well positioned with the latest technologies to enable Supermicro to win market share.”

[0001628280-15-002702:8k_2_02:18]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-15-002702:8k_2_02:19]
Conference Call Information

[0001628280-15-002702:8k_2_02:20]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-539-3678 (International callers dial 1-719-325-2495) 10 minutes prior. A recording of the conference will be available until 11:59 pm ET on Tuesday, May 5, 2015 by dialing 1-877-870-5176 (international callers dial 1-858-384-5517) and entering replay PIN 7827500. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-15-002702:8k_2_02:21]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-15-002702:8k_2_02:22]
forward-looking statements may relate, among other things, to our expected financial and operating results, our ability to build and grow Super Micro Computer, the benefits of our products and our ability to achieve our goals, plans and objectives. Such forward-looking statements do not constitute guarantees of future performance and are subject to a variety of risks and uncertainties that could cause our actual results to differ materially from those anticipated. These include, but are not limited to: our dependence on continued growth in the markets for X86, blade servers and embedded applications, increased competition, difficulties of predicting timing, introduction and customer acceptance of new products, poor product sales, difficulties in establishing and maintaining successful relationships with our distributors and vendors, shortages or price fluctuations in our supply chain, our ability to protect our intellectual property rights, our ability to control the rate of expansion domestically and internationally, difficulty managing rapid growth and general political, economic and market conditions and events. Additional factors that could cause actual results to differ materially from those projected or suggested in any forward-looking statements are contained in our filings with the Securities and Exchange Commission, including those factors discussed under the caption "Risk Factors" in such filings.

[0001628280-15-002702:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-15-002702:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-15-002702:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-15-002702:8k_2_02:26]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-15-002702:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-15-002702:8k_2_02:28]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001628280-15-002702:8k_2_02:29]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | March 31, |  | June 30, |
|  |  |  |  | 2015 |  | 2014 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 109,245 |  |  | $ | 96,872 |  |
|  | Accounts receivable, net | 221,561 |  |  | 212,738 |  |
|  | Inventory |  | 430,382 |  |  | 315,837 |  |
|  | Deferred income taxes – current | 21,296 |  |  | 16,842 |  |
|  | Prepaid income taxes | 7,291 |  |  | 5,555 |  |
|  | Prepaid expenses and other current assets | 5,477 |  |  | 6,237 |  |
|  |  | Total current assets | 795,252 |  |  | 654,081 |  |
| Long-term investments | 2,647 |  |  | 2,647 |  |
| Property, plant and equipment, net | 153,332 |  |  | 130,589 |  |
| Deferred income taxes – noncurrent |  | 5,887 |  |  | 6,154 |  |
| Other assets |  |  | 3,843 |  |  | 2,854 |  |
|  |  | Total assets | $ | 960,961 |  |  | $ | 796,325 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 261,603 |  |  | $ | 219,354 |  |
|  | Accrued liabilities |  | 44,391 |  |  | 37,564 |  |
|  | Income taxes payable |  | 8,337 |  |  | 11,414 |  |
|  | Short-term debt and current portion of long-term debt | 44,836 |  |  | 42,554 |  |
|  |  | Total current liabilities | 359,167 |  |  | 310,886 |  |
| Long term debt-net of current portion | 1,633 |  |  | 3,733 |  |
| Other long-term liabilities | 14,408 |  |  | 12,475 |  |
|  |  | Total liabilities | 375,208 |  |  | 327,094 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 240,436 |  |  | 199,062 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (74 | ) |  | (63 | ) |
|  | Retained earnings |  | 347,248 |  |  | 272,087 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 585,580 |  |  | 469,056 |  |
|  | Noncontrolling interest | 173 |  |  | 175 |  |
|  |  | Total liabilities and stockholders' equity | $ | 960,961 |  |  | $ | 796,325 |  |

[0001628280-15-002702:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 471,225 |  |  | $ | 373,755 |  |  | $ | 1,417,561 |  |  | $ | 1,039,133 |  |
| Cost of sales | 394,405 |  |  | 316,491 |  |  | 1,187,096 |  |  | 879,985 |  |
| Gross profit | 76,820 |  |  | 57,264 |  |  | 230,465 |  |  | 159,148 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 25,542 |  |  | 20,570 |  |  | 72,516 |  |  | 61,234 |  |
| Sales and marketing | 12,496 |  |  | 9,416 |  |  | 34,656 |  |  | 27,257 |  |
| General and administrative | 7,334 |  |  | 5,806 |  |  | 17,334 |  |  | 16,938 |  |
| Total operating expenses | 45,372 |  |  | 35,792 |  |  | 124,506 |  |  | 105,429 |  |
| Income from operations | 31,448 |  |  | 21,472 |  |  | 105,959 |  |  | 53,719 |  |
| Interest and other income, net | 21 |  |  | 10 |  |  | 92 |  |  | 73 |  |
| Interest expense | (277 | ) |  | (156 | ) |  | (656 | ) |  | (535 | ) |
| Income before income tax provision | 31,192 |  |  | 21,326 |  |  | 105,395 |  |  | 53,257 |  |
| Income tax provision | 8,136 |  |  | 4,752 |  |  | 30,234 |  |  | 15,649 |  |
| Net income | $ | 23,056 |  |  | $ | 16,574 |  |  | $ | 75,161 |  |  | $ | 37,608 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.49 |  |  | $ | 0.38 |  |  | $ | 1.63 |  |  | $ | 0.87 |  |
| Diluted | $ | 0.44 |  |  | $ | 0.35 |  |  | $ | 1.47 |  |  | $ | 0.82 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 46,824 |  |  | 43,992 |  |  | 46,138 |  |  | 43,128 |  |
| Diluted (b) | 52,008 |  |  | 47,424 |  |  | 51,102 |  |  | 45,857 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 222 |  |  | $ | 246 |  |  | $ | 651 |  |  | $ | 726 |  |
| Research and development | 2,255 |  |  | 1,723 |  |  | 6,148 |  |  | 4,993 |  |
| Sales and marketing | 369 |  |  | 306 |  |  | 1,148 |  |  | 925 |  |
| General and administrative | 720 |  |  | 531 |  |  | 1,780 |  |  | 1,539 |  |

[0001628280-15-002702:8k_2_02:31]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 75,161 |  |  | $ | 37,608 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 5,930 |  |  | 4,590 |  |
| Stock-based compensation expense | 9,727 |  |  | 8,183 |  |
| Excess tax benefits from stock-based compensation | (7,229 | ) |  | (2,719 | ) |
| Allowance for doubtful accounts | 194 |  |  | 1,384 |  |
| Provision for inventory | 4,462 |  |  | 2,427 |  |
| Exchange gain | (595 | ) |  | (334 | ) |
| Deferred income taxes, net | (4,197 | ) |  | (3,847 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (9,017 | ) |  | (34,072 | ) |
| Inventory | (119,007 | ) |  | (43,346 | ) |
| Prepaid expenses and other assets | 675 |  |  | 1,417 |  |
| Accounts payable | 38,712 |  |  | 32,492 |  |
| Income taxes payable, net | 5,814 |  |  | 9,879 |  |
| Accrued liabilities | 6,748 |  |  | (1,767 | ) |
| Other long-term liabilities | 1,686 |  |  | 579 |  |
| Net cash provided by operating activities | 9,064 |  |  | 12,474 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (24,637 | ) |  | (36,779 | ) |
| Investment in a privately held company | (661 | ) |  | — |  |
| Restricted cash | (418 | ) |  | 401 |  |
| Net cash used in investing activities | (25,716 | ) |  | (36,378 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 36,400 |  |  | 17,354 |  |
| Repayment of debt | (35,300 | ) |  | (5,620 | ) |
| Proceeds from exercise of stock options | 21,071 |  |  | 19,154 |  |
| Excess tax benefits from stock-based compensation | 7,229 |  |  | 2,719 |  |
| Payment of obligations under capital leases | (96 | ) |  | (26 | ) |
| Advances (payments) under receivable financing arrangements | 669 |  |  | (8 | ) |
| Minimum tax withholding paid on behalf of an officer for restricted stock awards | — |  |  | (651 | ) |
| Net cash provided by financing activities | 29,973 |  |  | 32,922 |  |
| Effect of exchange rate fluctuations on cash | (948 | ) |  | (342 | ) |
| Net increase in cash and cash equivalents | 12,373 |  |  | 8,676 |  |
| Cash and cash equivalents at beginning of period | 96,872 |  |  | 93,038 |  |
| Cash and cash equivalents at end of period | 109,245 |  |  | 101,714 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 649 |  |  | 533 |  |
| Cash paid for taxes, net of refunds | 27,455 |  |  | 8,940 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 428 |  |  | 175 |  |
| Accrued costs for property, plant and equipment purchases | 12,511 |  |  | 2,055 |  |

[0001628280-15-002702:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP GROSS PROFIT | $ | 76,820 |  |  | $ | 57,264 |  |  | $ | 230,465 |  |  | $ | 159,148 |  |
|  | Add back stock-based compensation (c) | 222 |  |  | 246 |  |  | 651 |  |  | 726 |  |
| Non-GAAP GROSS PROFIT | $ | 77,042 |  |  | $ | 57,510 |  |  | $ | 231,116 |  |  | $ | 159,874 |  |
| GAAP GROSS MARGIN | 16.3 | % |  | 15.3 | % |  | 16.3 | % |  | 15.3 | % |
|  | Add back stock-based compensation (c) | 0.0 | % |  | 0.1 | % |  | 0.0 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 16.3 | % |  | 15.4 | % |  | 16.3 | % |  | 15.4 | % |
| GAAP INCOME FROM OPERATIONS | $ | 31,448 |  |  | $ | 21,472 |  |  | $ | 105,959 |  |  | $ | 53,719 |  |
|  | Add back stock-based compensation (c) | 3,566 |  |  | 2,806 |  |  | 9,727 |  |  | 8,183 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 35,014 |  |  | $ | 24,278 |  |  | $ | 115,686 |  |  | $ | 61,902 |  |
| GAAP NET INCOME | $ | 23,056 |  |  | $ | 16,574 |  |  | $ | 75,161 |  |  | $ | 37,608 |  |
|  | Add back stock-based compensation (c) | 3,566 |  |  | 2,806 |  |  | 9,727 |  |  | 8,183 |  |
|  | Add back adjustments to tax provision (d) | (1,697 | ) |  | (1,619 | ) |  | (3,274 | ) |  | (2,272 | ) |
| Non-GAAP NET INCOME | $ | 24,925 |  |  | $ | 17,761 |  |  | $ | 81,614 |  |  | $ | 43,519 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.49 |  |  | $ | 0.38 |  |  | $ | 1.63 |  |  | $ | 0.87 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.04 |  |  | 0.02 |  |  | 0.14 |  |  | 0.14 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.53 |  |  | $ | 0.40 |  |  | $ | 1.77 |  |  | $ | 1.01 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.44 |  |  | $ | 0.35 |  |  | $ | 1.47 |  |  | $ | 0.82 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.03 |  |  | 0.02 |  |  | 0.11 |  |  | 0.12 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.47 |  |  | $ | 0.37 |  |  | $ | 1.58 |  |  | $ | 0.94 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP (g) | 46,824 |  |  | 43,992 |  |  | 46,138 |  |  | 43,128 |  |
|  | BASIC - Non-GAAP (h) | 46,824 |  |  | 43,996 |  |  | 46,138 |  |  | 43,167 |  |
|  | DILUTED – GAAP (g) | 52,008 |  |  | 47,424 |  |  | 51,102 |  |  | 45,857 |  |
|  | DILUTED - Non-GAAP (h) | 52,680 |  |  | 48,103 |  |  | 51,670 |  |  | 46,403 |  |

[0001628280-15-002702:8k_2_02:33]
(a) Approximately $1,000 and $34,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:34]
(b) Approximately $1,000 and $32,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:35]
(c) Amortization of ASC Topic 718 stock-based compensation for the three and nine months ended March 31, 2015 and 2014.

[0001628280-15-002702:8k_2_02:36]
(d) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 28.3% and 29.1% for the three and nine months ended March 31, 2015, respectively, and 26.4% and 29.2%  for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:37]
(e) Approximately $1,000 and $39,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:38]
(f) Approximately $1,000 and $36,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:39]
(g) 3,500 and 38,784 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:40]
(h) 3,500 and 38,784 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-002702:8k_2_02:41]
SOURCE: Super Micro Computer, Inc.

[0001628280-15-002702:8k_2_02:42]
Super Micro Computer, Inc.

[0001628280-15-002702:8k_2_02:43]
Howard Hideshima, 408-503-8000

[0001628280-15-002702:8k_2_02:44]
SVP, Chief Financial Officer

[0001628280-15-002702:8k_2_02:45]
ir@supermicro.com

[0001628280-15-002702:8k_2_02:46]
or

[0001628280-15-002702:8k_2_02:47]
Perry G. Hayes

[0001628280-15-002702:8k_2_02:48]
SVP, Investor Relations

[0001628280-15-002702:8k_2_02:49]
ir@supermicro.com

[0001628280-15-002702:8k_2_02:50]
SMCI-F
