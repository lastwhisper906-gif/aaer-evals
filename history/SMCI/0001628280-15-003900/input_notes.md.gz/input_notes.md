# SMCI notes — 0001628280-15-003900


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-003900:notes:1]
Commitments and Contingencies

[0001628280-15-003900:notes:2]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any such pending matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-15-003900:notes:3]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of March 31, 2015, these remaining non-cancellable commitments were $491,188,000 compared to $211,090,000 as of June 30, 2014.

[0001628280-15-003900:notes:4]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $237,389,000 as of March 31, 2015, an increase from $45,210,000 as of June 30, 2014 and will be paid through January 2017. The Company entered into amendments to its existing purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company negotiates the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-15-003900:notes:5]
[same as prior period, unchanged from 0001628280-15-000533:notes:5]

[0001628280-15-003900:notes:6]
[same as prior period, unchanged from 0001628280-15-000533:notes:6]

[0001628280-15-003900:notes:7]
[same as prior period, unchanged from 0001628280-15-000533:notes:7]

[0001628280-15-003900:notes:8]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2015 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2015.

[0001628280-15-003900:notes:9]
[same as prior period, unchanged from 0001628280-15-000533:notes:9]


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-003900:notes:10]
Short-term and Long-term Obligations

[0001628280-15-003900:notes:11]
Short-term and long-term obligations as of March 31, 2015 and June 30, 2014 consisted of the following (in thousands):

[0001628280-15-003900:notes:12]
|  | March 31, 2015 |  | June 30, 2014 |
| Line of credit: |  |  |  |
| Bank of America | $ | 11,199 |  |  | $ | 17,699 |  |
| CTBC Bank | 9,700 |  |  | — |  |
| Total line of credit | 20,899 |  |  | 17,699 |  |
| Building term loans: |  |  |  |
| Bank of America | 4,433 |  |  | 6,533 |  |
| CTBC Bank | 21,137 |  |  | 22,055 |  |
| Total building term loans | 25,570 |  |  | 28,588 |  |
| Total debt | 46,469 |  |  | 46,287 |  |
| Current portion | (44,836 | ) |  | (42,554 | ) |
| Long-term portion | $ | 1,633 |  |  | $ | 3,733 |  |

[0001628280-15-003900:notes:13]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-15-003900:notes:14]
Bank of America

[0001628280-15-003900:notes:15]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to November 15, 2015.

[0001628280-15-003900:notes:16]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.17% at March 31, 2015. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-003900:notes:17]
As of March 31, 2015 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan was $4,433,000 and $6,533,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $11,199,000 and $17,699,000 as of March 31, 2015 and June 30, 2014, respectively. The interest rates for these loans ranged from 0.82% to 1.67% per annum at March 31, 2015 and 1.19%  to 1.65% per annum at June 30, 2014. As of March 31, 2015, the unused revolving line of credit with Bank of America was $28,801,000.

[0001628280-15-003900:notes:18]
In April 2015, the Company drew an additional $10,000,000 from Bank of America line of credit with an interest rate at 1.43% per annum to support the Company's growth and expansion of its business.

[0001628280-15-003900:notes:19]
CTBC Bank

[0001628280-15-003900:notes:20]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollar or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollar or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which is adjusted monthly.

[0001628280-15-003900:notes:21]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

[0001628280-15-003900:notes:22]
In December 2014, the Company entered into a second amendment to the existing credit agreement with CTBC Bank to extend the maturity date to November 30, 2015. The amendment provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $31,453,000 U.S. dollar equivalents.

[0001628280-15-003900:notes:23]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,137,000 and $22,055,000 at March 31, 2015 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9,700,000 and $0 at March 31, 2015 and June 30, 2014, respectively. The interest rate for these loans were ranged from 0.81% to 1.15% at March 31, 2015 and 1.15% per annum at June 30, 2014. At March 31, 2015, NT$37,118,000 or $1,189,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-003900:notes:24]
Covenant Compliance

[0001628280-15-003900:notes:25]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-003900:notes:26]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001628280-15-003900:notes:27]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001628280-15-003900:notes:28]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001628280-15-003900:notes:29]
As of March 31, 2015 and June 30, 2014, total assets of $916,396,000 and $751,396,000, respectively, collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan.  As of March 31, 2015 and June 30, 2014, total assets collateralizing the term loan with Bank of America were $17,411,000 and $17,584,000, respectively. As of March 31, 2015, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001628280-15-003900:notes:30]
As of March 31, 2015 and June 30, 2014, the land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,154,000 and $27,345,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-15-003900:notes:31]
[same as prior period, unchanged from 0001628280-15-000533:notes:31]

[0001628280-15-003900:notes:32]
[same as prior period, unchanged from 0001628280-15-000533:notes:32]

[0001628280-15-003900:notes:33]
The authorized number of shares that may be issued under the Company's 2006 Equity Incentive Plan (the "2006 Plan") automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant and options and restricted stock units vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. The 2006 Plan is the successor equity incentive plan to the Company's 1998 Stock Option Plan. As of March 31, 2015, the Company had 626,715 authorized shares available for future issuance under the 2006 Plan.

[0001628280-15-003900:notes:34]
[same as prior period, unchanged from 0001628280-15-000533:notes:34]

[0001628280-15-003900:notes:35]
Valuation and amortization method—The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing formula and a single option award approach. The fair value of restricted stock units is based on the closing market price of the Company's common stock on the date of grant. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-15-003900:notes:36]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and the exercise factors for the stock options granted prior to June 30, 2011. For stock options and restricted stock units granted after June 30, 2011, the expected term is based on a combination of the Company's peer group and the Company's historical experience.

[0001628280-15-003900:notes:37]
[same as prior period, unchanged from 0001628280-15-000533:notes:37]

[0001628280-15-003900:notes:38]
[same as prior period, unchanged from 0001628280-15-000533:notes:38]

[0001628280-15-003900:notes:39]
[same as prior period, unchanged from 0001628280-15-000533:notes:39]

[0001628280-15-003900:notes:40]
[same as prior period, unchanged from 0001628280-15-000533:notes:40]

[0001628280-15-003900:notes:41]
The fair value of stock option grants for the three and nine months ended March 31, 2015 and 2014 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-15-003900:notes:42]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Risk-free interest rate | 1.35% - 1.58% |  |  | 1.69% - 1.81% |  |  | 1.35% - 1.76% |  |  | 1.53% - 1.81% |  |
| Expected life | 5.40 years |  |  | 5.58 years |  |  | 5.40 - 5.44 years |  |  | 5.49 - 5.58 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 47.60% - 48.26% |  |  | 43.48% - 44.66% |  |  | 46.93% - 49.31% |  |  | 43.48% - 50.07% |  |
| Weighted-average fair value | $ | 15.92 |  |  | $ | 7.70 |  |  | $ | 12.59 |  |  | $ | 6.67 |  |

[0001628280-15-003900:notes:43]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2015 and 2014 (in thousands):

[0001628280-15-003900:notes:44]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 222 |  |  | $ | 246 |  |  | $ | 651 |  |  | $ | 726 |  |
| Research and development | 2,255 |  |  | 1,723 |  |  | 6,148 |  |  | 4,993 |  |
| Sales and marketing | 369 |  |  | 306 |  |  | 1,148 |  |  | 925 |  |
| General and administrative | 720 |  |  | 531 |  |  | 1,780 |  |  | 1,539 |  |
| Stock-based compensation expense before taxes | 3,566 |  |  | 2,806 |  |  | 9,727 |  |  | 8,183 |  |
| Income tax impact | (1,355 | ) |  | (1,477 | ) |  | (2,747 | ) |  | (2,146 | ) |
| Stock-based compensation expense, net | $ | 2,211 |  |  | $ | 1,329 |  |  | $ | 6,980 |  |  | $ | 6,037 |  |

[0001628280-15-003900:notes:45]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $10,576,000 and $4,533,000 of excess tax benefits recorded in additional paid-in capital in the nine months ended March 31, 2015 and 2014, respectively. The Company had excess tax benefits that are classified as cash from financing activities of $7,229,000 and $2,719,000 in the nine months ended March 31, 2015 and 2014, respectively, for options issued since July 1, 2006.

[0001628280-15-003900:notes:46]
As of March 31, 2015, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted since July 1, 2006 to employees and non-employee directors was $28,958,000, which will be recognized over a remaining weighted-average vesting period of approximately 2.39 years.

[0001628280-15-003900:notes:47]
[same as prior period, unchanged from 0001628280-15-000533:notes:46]

[0001628280-15-003900:notes:48]
The following table summarizes stock option activity during the nine months ended March 31, 2015 under all stock option plans:

[0001628280-15-003900:notes:49]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 (7,558,631 shares exercisable at weighted average exercise price of $11.05 per share) |  | 10,905,602 |  |  | $ | 12.24 |  |  |  |  |  |
| Granted |  | 1,058,760 |  |  | $ | 27.99 |  |  |  |  |  |
| Exercised |  | (1,942,366 | ) |  | $ | 10.85 |  |  |  |  |  |
| Forfeited |  | (153,960 | ) |  | $ | 18.94 |  |  |  |  |  |
| Balance as of March 31, 2015 |  | 9,868,036 |  |  | $ | 14.10 |  |  | 6.13 |  | $ | 189,102 |  |
| Options vested and expected to vest at March 31, 2015 |  | 9,658,434 |  |  | $ | 13.91 |  |  | 6.07 |  | $ | 186,852 |  |
| Options vested and exercisable at March 31, 2015 |  | 6,988,101 |  |  | $ | 11.97 |  |  | 5.11 |  | $ | 148,459 |  |

[0001628280-15-003900:notes:50]
The total pretax intrinsic value of options exercised was $22,231,000 and $44,301,000 during the three and nine months ended March 31, 2015, respectively, and $14,746,000 and $19,961,000 for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:notes:51]
Restricted Stock Unit Activity

[0001628280-15-003900:notes:52]
In January 2015, the Company began to grant restricted stock units to employees. The Company grants restricted stock units to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. Restricted stock units are share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting and settlement.

[0001628280-15-003900:notes:53]
The following table summarizes restricted stock unit activity during the nine months ended March 31, 2015 under the 2006 Plan:

[0001628280-15-003900:notes:54]
|  |  | Restricted Stock UnitsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2014 |  | — |  |  | $ | — |  |  |  |
| Granted |  | 233,930 |  |  | $ | 35.07 |  |  |  |
| Vested |  | — |  |  | $ | — |  |  |  |
| Forfeited |  | (51,050 | ) |  | $ | 35.07 |  |  |  |
| Balance as of March 31, 2015 |  | 182,880 |  |  | $ | 35.07 |  |  | $ | 6,073 |  |

[0001628280-15-003900:notes:55]
[same as prior period, unchanged from 0001628280-15-000533:notes:50]

[0001628280-15-003900:notes:56]
The Company had no restricted stock award activity for the three and nine months ended March 31, 2015 and the three months ended March 31, 2014. The total pretax intrinsic value of restricted stock awards vested was $2,337,000 for the nine months ended March 31, 2014. In the nine months ended March 31, 2014, upon vesting, 179,641 shares of restricted stock awards were partially net share-settled such that the Company withheld 50,000 shares with value equivalent to an officer's minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock awards on their vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities were $651,000 in the nine months ended March 31, 2014 and are reflected as a financing activity within the consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. There are no unvested restricted stock awards at March 31, 2015.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-15-003900:notes:57]
[same as prior period, unchanged from 0001628280-15-000533:notes:52]

[0001628280-15-003900:notes:58]
The Company’s restricted share awards subject to repurchase and settled in shares of common stock upon vesting have the nonforfeitable right to receive dividends on an equal basis with common stock and therefore are considered participating securities that must be included in the calculation of net income per share using the two-class method. Under the two-class method, basic and diluted net income per common share is determined by calculating net income per share for common stock and participating securities based on participation rights in undistributed earnings. Diluted net income per common share is calculated by adjusting outstanding shares, assuming any dilutive effects of stock incentive awards calculated using the treasury stock method. Under the treasury stock method, an increase in the fair market value of our common stock results in a greater dilutive effect from outstanding stock options and restricted stock units. Additionally, the exercise of employee stock options and the vesting of restricted stock units results in a further dilutive effect on net income per share.


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-003900:notes:59]
[same as prior period, unchanged from 0001628280-15-000533:notes:54]

[0001628280-15-003900:notes:60]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Basic net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 23,056 |  |  | $ | 16,574 |  |  | $ | 75,161 |  |  | $ | 37,608 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (1 | ) |  | — |  |  | (34 | ) |
| Net income attributable to common shares—basic | $ | 23,056 |  |  | $ | 16,573 |  |  | $ | 75,161 |  |  | $ | 37,574 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,824 |  |  | 43,992 |  |  | 46,138 |  |  | 43,128 |  |
| Basic net income per common share | $ | 0.49 |  |  | $ | 0.38 |  |  | $ | 1.63 |  |  | $ | 0.87 |  |
| Diluted net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 23,056 |  |  | $ | 16,574 |  |  | $ | 75,161 |  |  | $ | 37,608 |  |
| Less: Undistributed earnings allocated to participating securities | — |  |  | (1 | ) |  | — |  |  | (32 | ) |
| Net income attributable to common shares—diluted | $ | 23,056 |  |  | $ | 16,573 |  |  | $ | 75,161 |  |  | $ | 37,576 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 46,824 |  |  | 43,992 |  |  | 46,138 |  |  | 43,128 |  |
| Dilutive effect of options to purchase common stock | 5,184 |  |  | 3,432 |  |  | 4,964 |  |  | 2,729 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 52,008 |  |  | 47,424 |  |  | 51,102 |  |  | 45,857 |  |
| Diluted net income per common share | $ | 0.44 |  |  | $ | 0.35 |  |  | $ | 1.47 |  |  | $ | 0.82 |  |

[0001628280-15-003900:notes:61]
For the three and nine months ended March 31, 2015 and 2014, the Company had stock options and restricted stock units outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The shares of anti-dilutive common share equivalents resulting from outstanding equity awards were 175,000 and 627,000 for the three and nine months ended March 31, 2015, respectively, and 2,142,000 and 3,892,000 for the three and nine months ended March 31, 2014, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-15-003900:notes:62]
The following table sets forth the Company’s cash equivalents and long-term investments as of March 31, 2015 and June 30, 2014 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-15-003900:notes:63]
| March 31, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Auction rate securities | — |  |  | — |  |  | 2,647 |  |  | 2,647 |  |
| Total | $ | 311 |  |  | $ | — |  |  | $ | 2,647 |  |  | $ | 2,958 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-15-003900:notes:64]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2015 and 2014 (in thousands):

[0001628280-15-003900:notes:65]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Balance as of beginning of period | $ | 2,647 |  |  | $ | 2,637 |  |  | $ | 2,647 |  |  | $ | 2,637 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |  | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |  | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 2,647 |  |  | $ | 2,637 |  |  | $ | 2,647 |  |  | $ | 2,637 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-003900:notes:66]
[same as prior period, unchanged from 0001628280-15-000533:notes:61]

[0001628280-15-003900:notes:67]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of March 31, 2015 and June 30, 2014. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001628280-15-003900:notes:68]
The above table excludes $108,705,000 and $96,324,000 of cash and $1,126,000 and $746,000 of certificates of deposit held by the Company as of March 31, 2015 and June 30, 2014, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and nine months ended March 31, 2015 and 2014.

[0001628280-15-003900:notes:69]
The following is a summary of the Company’s long-term investments as of March 31, 2015 and June 30, 2014 (in thousands):

[0001628280-15-003900:notes:70]
|  | March 31, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |
|  | June 30, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (103 | ) |  | $ | 2,647 |  |

[0001628280-15-003900:notes:71]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2015 and June 30, 2014, short-term and long-term debt of $46,469,000 and $46,287,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as they are not actively traded and are valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-003900:notes:72]
[same as prior period, unchanged from 0001628280-15-000533:notes:67]

[0001628280-15-003900:notes:73]
The Company recorded provisions for income taxes of $8,136,000 and $30,234,000 for the three and nine months ended March 31, 2015, respectively, and $4,752,000 and $15,649,000 for the three and nine months ended March 31, 2014, respectively. The effective tax rate was 26.1% and 28.7% for the three and nine months ended March 31, 2015, respectively, and 22.3% and 29.4% for the three and nine months ended March 31, 2014, respectively. The effective tax rate for the three and nine months ended March 31, 2015 is estimated to be lower than the federal statutory rate primarily due to the reinstatement of the U.S. federal research and development (“R&D”) tax credit, the benefit from disqualifying dispositions of shares issued upon exercise of incentive stock options and higher income taxed by foreign jurisdictions with lower tax rates, in part offset by the impact of stock option expenses. The effective tax rates for three and nine months ended March 31, 2014 were estimated to be lower than the federal statutory rate primarily due to the benefit from disqualifying dispositions of shares issued upon exercise of incentive stock options and foreign tax credits, which are in part offset by an increase in state tax expenses.

[0001628280-15-003900:notes:74]
As of March 31, 2015, the Company had a liability for gross unrecognized tax benefits of $11,728,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three and nine months ended March 31, 2015, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2015, the Company had accrued $841,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-15-003900:notes:75]
The Company is subject to U.S. federal income tax as well as income taxes in many state and foreign jurisdictions. The statutes of limitation for U.S. federal and state income taxes remain open in general for tax years 2011 through 2014. The Company's tax returns for its most significant foreign jurisdictions remain open for examination in general for tax years 2008 through 2014. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-15-003900:notes:76]
Long-term Investments

[0001628280-15-003900:notes:77]
As of March 31, 2015 and June 30, 2014, the Company held $2,647,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at March 31, 2015 and June 30, 2014. These auction rate preferred shares have no stated maturity date.

[0001628280-15-003900:notes:78]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2015 and June 30, 2014, $2,647,000 of these auction rate securities have been classified as long-term available-for-sale investments.

[0001628280-15-003900:notes:79]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2015 and June 30, 2014. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of March 31, 2015, the discount rate, the time period until redemption and the estimated rate of return were 1.82%, 3 years and 0.41%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001628280-15-003900:notes:80]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2015 and 2014. There was a cumulative total decline of $103,000 as of March 31, 2015 and June 30, 2014. That amount has been recorded as a component of other comprehensive income. As of March 31, 2015 and June 30, 2014, the Company has recorded an accumulated unrealized loss of $62,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001628280-15-003900:notes:81]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform a periodic impairment analysis. In the three and nine months ended March 31, 2015 and 2014, there were no auction rate securities redeemed or sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-15-003900:notes:82]
Adoption of New Accounting Pronouncements

[0001628280-15-003900:notes:83]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

[0001628280-15-003900:notes:84]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The adoption of this guidance did not have a material impact on the Company's results of operations or financial position.

[0001628280-15-003900:notes:85]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-15-003900:notes:86]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The new standard is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-15-003900:notes:87]
[same as prior period, unchanged from 0001628280-15-000533:notes:83]

[0001628280-15-003900:notes:88]
[same as prior period, unchanged from 0001628280-15-000533:notes:84]

[0001628280-15-003900:notes:89]
[same as prior period, unchanged from 0001628280-15-000533:notes:85]

[0001628280-15-003900:notes:90]
[same as prior period, unchanged from 0001628280-15-000533:notes:86]

[0001628280-15-003900:notes:91]
[same as prior period, unchanged from 0001628280-15-000533:notes:87]

[0001628280-15-003900:notes:92]
[same as prior period, unchanged from 0001628280-15-000533:notes:88]

[0001628280-15-003900:notes:93]
[same as prior period, unchanged from 0001628280-15-000533:notes:89]

[0001628280-15-003900:notes:94]
[same as prior period, unchanged from 0001628280-15-000533:notes:90]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-15-003900:notes:95]
[same as prior period, unchanged from 0001628280-15-000533:notes:91]

[0001628280-15-003900:notes:96]
|  | March 31, 2015 |  | June 30, 2014 |
| Land | $ | 63,962 |  |  | $ | 63,962 |  |
| Buildings | 51,959 |  |  | 51,959 |  |
| Building and leasehold improvements | 8,281 |  |  | 7,683 |  |
| Buildings construction in progress (1) | 17,247 |  |  | 587 |  |
| Machinery and equipment | 39,736 |  |  | 34,342 |  |
| Furniture and fixtures | 7,029 |  |  | 5,892 |  |
| Purchased software | 3,811 |  |  | 3,606 |  |
| Purchased software construction in progress (2) | 7,024 |  |  | 2,548 |  |
|  | 199,049 |  |  | 170,579 |  |
| Accumulated depreciation and amortization | (45,717 | ) |  | (39,990 | ) |
| Property, plant and equipment, net | $ | 153,332 |  |  | $ | 130,589 |  |

[0001628280-15-003900:notes:97]
[same as prior period, unchanged from 0001628280-15-000533:notes:93]

[0001628280-15-003900:notes:98]
(2) The Company continues its implementation of a new enterprise resource planning, or ERP, system and has capitalized the costs of the new ERP software and certain expenses associated directly with the development of the ERP system, which is still in progress.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-15-003900:notes:99]
Related-party and Other Transactions

[0001628280-15-003900:notes:100]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.6% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 42.9% of Ablecom at March 31, 2015.

[0001628280-15-003900:notes:101]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-15-003900:notes:102]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-15-003900:notes:103]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-15-003900:notes:104]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $58,002,000 and $169,918,000, and sold products to Ablecom totaling $6,067,000 and $43,524,000 for the three and nine months ended March 31, 2015, respectively. The Company purchased products from Ablecom totaling $45,398,000 and $145,139,000 and sold products to Ablecom totaling $3,418,000 and $10,805,000 for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:notes:105]
Amounts owed to the Company by Ablecom as of March 31, 2015 and June 30, 2014, were $4,602,000 and $621,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2015 and June 30, 2014, were $51,922,000 and $48,969,000, respectively. For the three and nine months ended March 31, 2015, the Company paid Ablecom the majority of invoiced dollars between 48 and 105 days of invoice date. For the three and nine months ended March 31, 2015, the Company paid $231,000 and $4,728,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2014, the Company paid $2,187,000 and $5,923,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-15-003900:notes:106]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $88,593,000 and $64,464,000 at March 31, 2015 and June 30, 2014, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-15-003900:notes:107]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2015, $4,000 and $(3,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income  (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-15-003900:notes:108]
[same as prior period, unchanged from 0001628280-15-000533:notes:104]

[0001628280-15-003900:notes:109]
|  | March 31, 2015 |  | June 30, 2014 |
| Accrued payroll and related expenses | $ | 14,145 |  |  | $ | 11,624 |  |
| Customer deposits | 7,102 |  |  | 4,185 |  |
| Accrued warranty costs | 7,209 |  |  | 7,083 |  |
| Accrued cooperative marketing expenses | 5,428 |  |  | 4,387 |  |
| Others | 10,507 |  |  | 10,285 |  |
| Total accrued liabilities | $ | 44,391 |  |  | $ | 37,564 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-15-003900:notes:110]
[same as prior period, unchanged from 0001628280-15-000533:notes:106]

[0001628280-15-003900:notes:111]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 301,953 |  |  | 64.1 | % |  | $ | 187,282 |  |  | 50.1 | % |  | $ | 859,818 |  |  | 60.7 | % |  | $ | 504,637 |  |  | 48.6 | % |
| Subsystems and accessories | 169,272 |  |  | 35.9 | % |  | 186,473 |  |  | 49.9 | % |  | 557,743 |  |  | 39.3 | % |  | 534,496 |  |  | 51.4 | % |
| Total | $ | 471,225 |  |  | 100.0 | % |  | $ | 373,755 |  |  | 100.0 | % |  | $ | 1,417,561 |  |  | 100.0 | % |  | $ | 1,039,133 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-15-003900:notes:112]
[same as prior period, unchanged from 0001628280-15-000533:notes:108]

[0001628280-15-003900:notes:113]
[same as prior period, unchanged from 0001628280-15-000533:notes:109]

[0001628280-15-003900:notes:114]
|  | March 31, 2015 |  | June 30, 2014 |
| Finished goods | $ | 320,213 |  |  | $ | 246,803 |  |
| Work in process | 38,093 |  |  | 18,794 |  |
| Purchased parts and raw materials | 72,076 |  |  | 50,240 |  |
| Total inventory | $ | 430,382 |  |  | $ | 315,837 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-15-003900:notes:115]
[same as prior period, unchanged from 0001628280-15-000533:notes:111]

[0001628280-15-003900:notes:116]
|  | March 31, 2015 |  | June 30, 2014 |
| Prepaid royalty license | $ | 1,059 |  |  | $ | 1,246 |  |
| Restricted cash | 838 |  |  | 450 |  |
| Investment in a privately held company | 1,411 |  |  | 750 |  |
| Others | 535 |  |  | 408 |  |
| Total other assets | $ | 3,843 |  |  | $ | 2,854 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-15-003900:notes:117]
[same as prior period, unchanged from 0001628280-15-000533:notes:113]

[0001628280-15-003900:notes:118]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Balance, beginning of period | $ | 6,960 |  |  | $ | 6,822 |  |  | $ | 7,083 |  |  | $ | 6,472 |  |
| Provision for warranty | 3,968 |  |  | 3,517 |  |  | 10,928 |  |  | 10,458 |  |
| Costs charged to accrual | (3,706 | ) |  | (3,558 | ) |  | (10,476 | ) |  | (10,222 | ) |
| Change in estimated liability for pre-existing warranties | (13 | ) |  | 140 |  |  | (326 | ) |  | 213 |  |
| Balance, end of period | $ | 7,209 |  |  | $ | 6,921 |  |  | $ | 7,209 |  |  | $ | 6,921 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-15-003900:notes:119]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2015 and 2014, of net sales by geographic region (in thousands):

[0001628280-15-003900:notes:120]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 273,631 |  |  | $ | 203,638 |  |  | $ | 803,757 |  |  | $ | 558,423 |  |
| Europe | 88,259 |  |  | 81,165 |  |  | 269,404 |  |  | 237,327 |  |
| Asia | 74,772 |  |  | 78,373 |  |  | 241,785 |  |  | 215,556 |  |
| Other | 34,563 |  |  | 10,579 |  |  | 102,615 |  |  | 27,827 |  |
|  | $ | 471,225 |  |  | $ | 373,755 |  |  | $ | 1,417,561 |  |  | $ | 1,039,133 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-15-003900:notes:121]
[same as prior period, unchanged from 0001628280-15-000533:notes:117]

[0001628280-15-003900:notes:122]
|  | March 31, 2015 |  | June 30, 2014 |
| Long-lived assets: |  |  |  |
| United States | $ | 115,288 |  |  | $ | 94,119 |  |
| Asia | 37,754 |  |  | 36,123 |  |
| Europe | 290 |  |  | 347 |  |
|  | $ | 153,332 |  |  | $ | 130,589 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-003900:notes:123]
[same as prior period, unchanged from 0001628280-15-000533:notes:119]

[0001628280-15-003900:notes:124]
[same as prior period, unchanged from 0001628280-15-000533:notes:120]

[0001628280-15-003900:notes:125]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute subsystems and accessories assembled by the Company. One customer represented 13.9% and 12.5% of the Company’s total net sales in the three and nine months ended March 31, 2015, respectively, and no customer represented greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2014. No country other than the United States represents greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2015 and 2014. No customer accounted for 10% or more of the Company's accounts receivable as of March 31, 2015 and June 30, 2014.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-003900:notes:126]
[same as prior period, unchanged from 0001628280-15-000533:notes:122]

[0001628280-15-003900:notes:127]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $287,000 and $4,462,000 in the three and nine months ended March 31, 2015, respectively, and $889,000 and $2,427,000 in the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:notes:128]
Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California, one deposit to an escrow account required by the Company's worker's compensation program and bank guarantees in connection with office leases in the Netherlands. In December 2014, the Company made an investment in a privately held company of $661,000.
