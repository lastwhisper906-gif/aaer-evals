# SMCI MD&A — 0001628280-15-003900


## mdna

[0001628280-15-003900:mdna:1]
[same as prior period, unchanged from 0001628280-15-000533:mdna:1]

[0001628280-15-003900:mdna:2]
[same as prior period, unchanged from 0001628280-15-000533:mdna:2]

[0001628280-15-003900:mdna:3]
We are a global leader in high-performance, high-efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the Data Center, Cloud Computing, Enterprise IT, Big Data, HPC and Embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Net sales of optimized servers were $302.0 million and $859.8 million for the three and nine months ended March 31, 2015, respectively, and $187.3 million and $504.6 million for the three and nine months ended March 31, 2014, respectively, and net sales of subsystems and accessories were $169.3 million and $557.7 million for the three and nine months ended March 31, 2015, respectively, and $186.5 million and $534.5 million for the three and nine months ended March 31, 2014, respectively. The increase in our net sales in the three and nine months ended March 31, 2015 compared with the three and nine months ended March 31, 2014 was primarily due to an increase in sales of complete server systems such as our storage servers and Twin family of servers and to a lesser extent an increase in sales of our GPU/Xeon Phi and blade servers which offer higher density computing and more memory and hard disk drive capacity. The percentage of our net sales represented by sales of complete server systems increased to 64.1% and 60.7% in the three and nine months ended March 31, 2015, respectively, from 50.1% and 48.6% in the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales were $471.2 million and $1,417.6 million for the three and nine months ended March 31, 2015, respectively, and $373.8 million and $1,039.1 million for the three and nine months ended March 31, 2014, respectively. Our net income was $23.1 million and $75.2 million for the three and nine months ended March 31, 2015, respectively, and $16.6 million and $37.6 million for the three and nine months ended March 31, 2014, respectively. Our increase in net income in the three and nine months ended

[0001628280-15-003900:mdna:5]
March 31, 2015 was primarily attributable to an increase in our gross profit resulting primarily from higher sales and improved gross margin, partially offset by higher income tax expenses attributable to higher operating income.

[0001628280-15-003900:mdna:6]
We sell our server systems and subsystems and accessories primarily through distributors and Original Equipment Manufacturers, or OEMs, as well as through our direct sales force. We derived 46.1% and 50.3% of our net sales from products sold to distributors and derived 53.9% and 49.7% from sales to OEMs and to end customers for the three and nine months ended March 31, 2015, respectively, and 51.9% and 55.1% of our net sales from products sold to distributors, and 48.1% and 44.9% from sales to OEMs and to end customers for the three and nine months ended March 31, 2014, respectively. One of our customers accounted for 13.9% and 12.5% of our net sales in the three and nine months ended March 31, 2015, and none of our customers accounted for 10% or more of our net sales in the three and nine months ended March 31, 2014. We derived 58.1% and 56.7% of our net sales from customers in the United States for the three and nine months ended March 31, 2015, respectively, and 54.5% and 53.7% for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:mdna:7]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.4% and 5.1% of our net sales for the three and nine months ended March 31, 2015, respectively, and 5.5% and 5.9% of our net sales for the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:mdna:8]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities. During fiscal year 2015, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands to support our Asian and European customers and we have increased our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and nine months ended March 31, 2015, our purchases from Ablecom represented 14.7% and 14.3% of our cost of sales, respectively, compared to 14.4% and 16.5% of our cost of sales for the three and nine months ended March 31, 2014, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-15-003900:mdna:9]
In order to continue to increase our net sales and profits, we believe that we must continue to develop flexible and customizable server solutions and be among the first to market with new features and products. We measure our financial success based on various indicators, including growth in net sales, gross profit as a percentage of net sales, operating income as a percentage of net sales, levels of inventory, and days sales outstanding, or DSOs. In connection with these efforts, we monitor daily and weekly sales and shipment reports. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application optimized server solutions. In this regard, we work closely with microprocessor and other component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from the introduction of new microprocessors and as a result we monitor the introduction cycles of Intel, AMD and Nvidia carefully. This also impacts our research and development expenditures.

[0001628280-15-003900:mdna:10]
[same as prior period, unchanged from 0001628280-15-000533:mdna:9]

[0001628280-15-003900:mdna:11]
The following is a summary of other financial highlights of the third quarter of fiscal year 2015:

[0001628280-15-003900:mdna:12]
| • | Net cash provided by operating activities was $9.1 million and $12.5 million during the nine months ended March 31, 2015 and 2014, respectively. Our cash and cash equivalents, together with our investments, were $112.0 million at the end of the third quarter of fiscal year 2015, compared with $99.6 million at the end of fiscal year 2014. |

[0001628280-15-003900:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the third quarter of fiscal year 2015 was 46 days, compared with 42 days at the end of the fourth quarter of fiscal year 2014. |

[0001628280-15-003900:mdna:14]
| • | Our inventory balance was $430.4 million at the end of the third quarter of fiscal year 2015, compared with $315.8 million at the end of the fiscal year 2014. Days sales of inventory (“DSI”) at the end of the third quarter of fiscal year 2015 was 96 days, compared with 77 days at the end of the fourth quarter of fiscal year |

[0001628280-15-003900:mdna:15]
2014. The increase in our inventory was in anticipation of growth of our business in our seasonally strong June quarter and was also impacted by timing of deliveries as a result of the west coast port strike in February 2015.

[0001628280-15-003900:mdna:16]
| • | Our purchase commitments with contract manufacturers and suppliers were $491.2 million at the end of the third quarter of fiscal year 2015 and $211.1 million at the end of the fiscal year 2014. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $237.4 million, which have terms expiring through January 2017. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-15-003900:mdna:17]
[same as prior period, unchanged from 0001628280-15-000533:mdna:17]

[0001628280-15-003900:mdna:18]
[same as prior period, unchanged from 0001628280-15-000533:mdna:18]

[0001628280-15-003900:mdna:19]
[same as prior period, unchanged from 0001628280-15-000533:mdna:19]

[0001628280-15-003900:mdna:20]
[same as prior period, unchanged from 0001628280-15-000533:mdna:20]

[0001628280-15-003900:mdna:21]
[same as prior period, unchanged from 0001628280-15-000533:mdna:21]

[0001628280-15-003900:mdna:22]
[same as prior period, unchanged from 0001628280-15-000533:mdna:22]

[0001628280-15-003900:mdna:23]
[same as prior period, unchanged from 0001628280-15-000533:mdna:23]

[0001628280-15-003900:mdna:24]
[same as prior period, unchanged from 0001628280-15-000533:mdna:24]

[0001628280-15-003900:mdna:25]
[same as prior period, unchanged from 0001628280-15-000533:mdna:25]

[0001628280-15-003900:mdna:26]
[same as prior period, unchanged from 0001628280-15-000533:mdna:26]

[0001628280-15-003900:mdna:27]
[same as prior period, unchanged from 0001628280-15-000533:mdna:27]

[0001628280-15-003900:mdna:28]
[same as prior period, unchanged from 0001628280-15-000533:mdna:28]

[0001628280-15-003900:mdna:29]
[same as prior period, unchanged from 0001628280-15-000533:mdna:29]

[0001628280-15-003900:mdna:30]
[same as prior period, unchanged from 0001628280-15-000533:mdna:30]

[0001628280-15-003900:mdna:31]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At March 31, 2015 and June 30, 2014, we had deferred revenue of $0.5 million and $7.7 million and related deferred product costs of $0.2 million and $6.7 million, respectively, related to shipments to customers pending acceptances.

[0001628280-15-003900:mdna:32]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision for bad debt was $0.3 million and $0.2 million in the three and nine months ended March 31, 2015, respectively, and $0.3 million and $1.4 million in the three and nine months ended March 31, 2014, respectively. If a major customer's credit worthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-15-003900:mdna:33]
[same as prior period, unchanged from 0001628280-15-000533:mdna:33]

[0001628280-15-003900:mdna:34]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.2 million and $7.1 million as of March 31, 2015 and June 30, 2014, respectively. The provision for warranty reserve was $4.0 million and $10.9 million in the three and nine months ended March 31, 2015, respectively, and $3.5 million and $10.5 million in the three and nine months ended March 31, 2014, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was ($13,000) and $(0.3) million in the three and nine months ended March 31, 2015, respectively, and $0.1 million and $0.2 million in the three and nine months ended March 31, 2014, respectively. As a result of our higher cost of servicing warranty claims from higher net sales in the three months ended March 31, 2015, the provision for warranty reserve increased $0.5 million compared to the three months ended March 31, 2014. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001628280-15-003900:mdna:35]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $0.3 million and $4.5 million in the three and nine months ended March 31, 2015, respectively, and $0.9 million and $2.4 million in the three and nine months ended March 31, 2014, respectively.

[0001628280-15-003900:mdna:36]
[same as prior period, unchanged from 0001628280-15-000533:mdna:37]

[0001628280-15-003900:mdna:37]
[same as prior period, unchanged from 0001628280-15-000533:mdna:38]

[0001628280-15-003900:mdna:38]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of our Board of Directors including employee stock options and restricted stock units. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of our restricted stock units is based on the closing market price of our common stock on the date of grant. We estimated the fair value of stock options granted using a Black-Scholes option-pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option, the expected volatility of the price of our common

[0001628280-15-003900:mdna:39]
stock and the expected forfeiture rate. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-15-003900:mdna:40]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and exercise behavior for the stock options granted prior to June 30, 2011. For stock options and restricted stock units granted after June 30, 2011, expected term is based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-15-003900:mdna:41]
Compensation expense for options and restricted stock units granted to employees was $3.6 million and $9.7 million for the three and nine months ended March 31, 2015, respectively, and $2.8 million and $8.2 million for the three and nine months ended March 31, 2014, respectively.     As of March 31, 2015, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options and restricted stock units granted since July 1, 2006 to employees and non-employee members of the Board of Directors, was $29.0 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.39 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001628280-15-003900:mdna:42]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-15-003900:mdna:43]
In May 2012, we and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of March 31, 2015, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2015, $4,000, $(3,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2014 $6,000 and $(7,000), respectively, of net income (loss) attributable to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-15-003900:mdna:44]
[same as prior period, unchanged from 0001628280-15-000533:mdna:45]

[0001628280-15-003900:mdna:45]
[same as prior period, unchanged from 0001628280-15-000533:mdna:46]

[0001628280-15-003900:mdna:46]
[same as prior period, unchanged from 0001628280-15-000533:mdna:47]

[0001628280-15-003900:mdna:47]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 83.7 |  |  | 84.7 |  |  | 83.7 |  |  | 84.7 |  |
| Gross profit | 16.3 |  |  | 15.3 |  |  | 16.3 |  |  | 15.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.4 |  |  | 5.5 |  |  | 5.1 |  |  | 5.9 |  |
| Sales and marketing | 2.6 |  |  | 2.5 |  |  | 2.5 |  |  | 2.6 |  |
| General and administrative | 1.6 |  |  | 1.6 |  |  | 1.2 |  |  | 1.6 |  |
| Total operating expenses | 9.6 |  |  | 9.6 |  |  | 8.8 |  |  | 10.1 |  |
| Income from operations | 6.7 |  |  | 5.7 |  |  | 7.5 |  |  | 5.2 |  |
| Interest and other income, net | — |  |  | — |  |  | — |  |  | — |  |
| Interest expense | (0.1 | ) |  | — |  |  | (0.1 | ) |  | (0.1 | ) |
| Income before income tax provision | 6.6 |  |  | 5.7 |  |  | 7.4 |  |  | 5.1 |  |
| Income tax provision | 1.7 |  |  | 1.3 |  |  | 2.1 |  |  | 1.5 |  |
| Net income | 4.9 | % |  | 4.4 | % |  | 5.3 | % |  | 3.6 | % |

[0001628280-15-003900:mdna:48]
Comparison of Three Months Ended March 31, 2015 and 2014

[0001628280-15-003900:mdna:49]
Net sales. Net sales increased by $97.5 million, or 26.1%, to $471.2 million from $373.8 million, for the three months ended March 31, 2015 and 2014, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001628280-15-003900:mdna:50]
For the three months ended March 31, 2015, the number of server system units sold increased 6.9% to 77,000 compared to 72,000 for the three months ended March 31, 2014. The average selling price of server system units increased 50.0% to $3,900 in the three months ended March 31, 2015 compared to $2,600 in the three months ended March 31, 2014. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems such as our storage servers and Twin family of servers and to a lesser extent the increase in sales of our GPU/Xeon Phi and blade servers which offer higher density computing and more memory and hard disk drive capacity. Sales of server systems increased by $114.7 million or 61.2% from the three months ended March 31, 2014 to the three months ended March 31, 2015, primarily due to the increased sales of the products described above. Sales of server systems represented 64.1% of our net sales for the three months ended March 31, 2015 compared to 50.1% of our net sales for the three months ended March 31, 2014.

[0001628280-15-003900:mdna:51]
For the three months ended March 31, 2015 and 2014, the number of subsystems and accessories units sold was 1.0 million and 1.1 million, respectively. Sales of subsystems and accessories decreased by $17.2 million or 9.2% from the three months ended March 31, 2014 to the three months ended March 31, 2015, primarily related to a decreased volume of chassis and serverboards sold to our distributors and system integrators who are completing the final assembly themselves. Sales of subsystems and accessories represented 35.9% of our net sales for the three months ended March 31, 2015 as compared to 49.9% of our net sales for the three months ended March 31, 2014.

[0001628280-15-003900:mdna:52]
For the three months ended March 31, 2015 and 2014, we derived 46.1% and 51.9%, respectively, of our net sales from products sold to distributors and we derived 53.9% and 48.1%, respectively, from sales to OEMs and to end customers. For the three months ended March 31, 2015, customers in the United States, Europe and Asia accounted for 58.1%, 18.7% and 15.9%, of our net sales, respectively, as compared to 54.5%, 21.7% and 21.0% of our net sales, respectively, for the three months ended March 31, 2014.

[0001628280-15-003900:mdna:53]
Cost of sales. Cost of sales increased by $77.9 million, or 24.6%, to $394.4 million from $316.5 million, for the three months ended March 31, 2015 and 2014, respectively. Cost of sales as a percentage of net sales was 83.7% and 84.7% for the

[0001628280-15-003900:mdna:54]
three months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales offset partly by a decrease of $0.6 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to lower costs resulting from the increased scale of our business and an increase in the mix of complete server system sales. In the three months ended March 31, 2015, we recorded a $0.3 million expense, net of recovery, or 0.1% of net sales, related to the inventory provision as compared to $0.9 million, or 0.2% of net sales, in the three months ended March 31, 2014. The decrease in the inventory provision was primarily due to lower inventory reserves for specific products.

[0001628280-15-003900:mdna:55]
In the three months ended March 31, 2015, we recorded a $4.0 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to $3.5 million, or 0.9% of net sales, in the three months ended March 31, 2014. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the three months ended March 31, 2015. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-15-003900:mdna:56]
Research and development expenses. Research and development expenses increased by $5.0 million, or 24.2%, to $25.5 million from $20.6 million, for the three months ended March 31, 2015 and 2014, respectively. Research and development expenses were 5.4% and 5.5% of net sales for the three months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $4.5 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. The decrease as a percentage of net sales was primarily due to the increase in net sales in the three months ended March 31, 2015.

[0001628280-15-003900:mdna:57]
Research and development expenses include stock-based compensation expense of $2.3 million and $1.7 million for the three months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:58]
Sales and marketing expenses. Sales and marketing expenses increased by $3.1 million, or 32.7%, to $12.5 million from $9.4 million, for the three months ended March 31, 2015 and 2014, respectively. Sales and marketing expenses were 2.6% and 2.5% of net sales for the three months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $2.1 million in compensation and benefits resulting from growth in sales and marketing personnel and an increase of $0.7 million in advertising and marketing promotional expenses.

[0001628280-15-003900:mdna:59]
Sales and marketing expenses include stock-based compensation expense of $0.4 million and $0.3 million for the three months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:60]
General and administrative expenses. General and administrative expenses increased by $1.5 million, or 26.3%, to $7.3 million from $5.8 million, for the three months ended March 31, 2015 and 2014, respectively. General and administrative expenses were 1.6% of net sales for both the three months ended March 31, 2015 and 2014. The increase in absolute dollars was primarily due to a change of our foreign currency transaction expense from $0.1 million of gain to $0.7 million of loss and an increase of $0.6 million in compensation and benefits to support the expansion of our operations at our headquarters and operations in Taiwan.

[0001628280-15-003900:mdna:61]
General and administrative expenses include stock-based compensation expense of $0.7 million and $0.5 million for the three months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:62]
Interest and other expense, net. Interest and other expense, net, was $0.3 million and $0.1 million of expense for the three months ended March 31, 2015 and 2014, respectively, which primarily represented $0.3 million and $0.2 million of interest expense for the three months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:63]
Provision for income taxes. Provision for income taxes increased by $3.4 million, or 71.2%, to $8.1 million from $4.8 million, for the three months ended March 31, 2015 and 2014, respectively. The effective tax rate was 26.1% and 22.3% for the three months ended March 31, 2015 and 2014, respectively. The higher income tax provision for the three months ended March 31, 2015 was primarily attributable to our higher operating income. The higher effective tax rate for the three months ended March 31, 2015 was primarily due to the lower domestic production activity deduction, partially offset by the benefits from the U.S. federal R&D credits and higher income taxed by foreign jurisdictions with lower tax rates.

[0001628280-15-003900:mdna:64]
Comparison of Nine Months Ended March 31, 2015 and 2014

[0001628280-15-003900:mdna:65]
Net sales. Net sales increased by $378.4 million, or 36.4%, to $1,417.6 million from $1,039.1 million, for the nine months ended March 31, 2015 and 2014, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems as we sold more higher density server systems.

[0001628280-15-003900:mdna:66]
For the nine months ended March 31, 2015, the number of server system units sold increased 19.5% to 227,000 compared to 190,000 for the nine months ended March 31, 2014. The average selling price of server system units increased 40.7% to $3,800 in the nine months ended March 31, 2015 compared to $2,700 in the nine months ended March 31, 2014. The average selling prices of our server systems increased primarily due to an increase in average selling prices of our complete server systems such as our storage servers and Twin family of servers and to a lesser extent the increase in sales of our GPU/Xeon Phi and blade servers which offer higher density computing and more memory and hard disk drive capacity. Sales of server systems increased by $355.2 million or 70.4% from the nine months ended March 31, 2014 to the nine months ended March 31, 2015, primarily due to the increased sales of the products described above. Sales of server systems represented 60.7% of our net sales for the nine months ended March 31, 2015 compared to 48.6% of our net sales for the nine months ended March 31, 2014.

[0001628280-15-003900:mdna:67]
For the nine months ended March 31, 2015, the number of subsystems and accessories units sold increased 2.1% to 3.4 million compared to 3.3 million for the nine months ended March 31, 2014. Sales of subsystems and accessories increased by $23.2 million or 4.3% from the nine months ended March 31, 2014 to the nine months ended March 31, 2015, primarily related to an increased volume of hard disk drives and memory bundled with our server solutions sold to our distributors and system integrators who are purchasing additional accessories from us and completing the final assembly themselves. Sales of subsystems and accessories represented 39.3% of our net sales for the nine months ended March 31, 2015 as compared to 51.4% of our net sales for the nine months ended March 31, 2014.

[0001628280-15-003900:mdna:68]
For the nine months ended March 31, 2015 and 2014, we derived 50.3% and 55.1%, respectively, of our net sales from products sold to distributors and we derived 49.7% and 44.9%, respectively, from sales to OEMs and to end customers. For the nine months ended March 31, 2015, customers in the United States, Europe and Asia accounted for 56.7%, 19.0% and 17.1%, of our net sales, respectively, as compared to 53.7%, 22.8% and 20.7% of our net sales, respectively, for the nine months ended March 31, 2014.

[0001628280-15-003900:mdna:69]
Cost of sales. Cost of sales increased by $307.1 million, or 34.9%, to $1,187.1 million from $880.0 million, for the nine months ended March 31, 2015 and 2014, respectively. Cost of sales as a percentage of net sales was 83.7% and 84.7% for the nine months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales and an increase of $2.0 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to lower costs resulting from the increased scale of our business and an increase in the mix of complete server system sales. In the nine months ended March 31, 2015, we recorded a $4.5 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $2.4 million, or 0.2% of net sales, in the nine months ended March 31, 2014. The increase in the inventory provision was primarily due to higher inventory reserves for specific products.

[0001628280-15-003900:mdna:70]
In the nine months ended March 31, 2015, we recorded a $10.9 million expense, or 0.8% of net sales, related to the provision for warranty reserve as compared to $10.5 million, or 1.0% of net sales, in the nine months ended March 31, 2014. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the nine months ended March 31, 2015. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-15-003900:mdna:71]
Research and development expenses. Research and development expenses increased by $11.3 million, or 18.4%, to $72.5 million from $61.2 million, for the nine months ended March 31, 2015 and 2014, respectively. Research and development expenses were 5.1% and 5.9% of net sales for the nine months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $13.3 million in compensation and benefits resulting from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan, partially offset by $2.8 million refund of value added taxes on research and development expenses and an increase of $2.0 million in non-recurring engineering funding from certain suppliers and customers.  The decrease as a percentage of net sales was primarily due to the increase in net sales in the nine months ended March 31, 2015.

[0001628280-15-003900:mdna:72]
Research and development expenses include stock-based compensation expense of $6.1 million and $5.0 million for the nine months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:73]
Sales and marketing expenses. Sales and marketing expenses increased by $7.4 million, or 27.1%, to $34.7 million from $27.3 million, for the nine months ended March 31, 2015 and 2014, respectively. Sales and marketing expenses were 2.5% and 2.6% of net sales for the nine months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $5.8 million in compensation and benefits resulting from growth in sales and marketing personnel and an increase of $1.5 million in advertising, marketing promotional and trade show expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in the nine months ended March 31, 2015.

[0001628280-15-003900:mdna:74]
Sales and marketing expenses include stock-based compensation expense of $1.1 million and $0.9 million for the nine months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:75]
General and administrative expenses. General and administrative expenses increased by $0.4 million, or 2.3%, to $17.3 million from $16.9 million, for the nine months ended March 31, 2015 and 2014, respectively. General and administrative expenses were 1.2% and 1.6% of net sales for the nine months ended March 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $1.5 million in compensation and benefits, a decrease of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor in the prior year offset in part by a decrease of $1.2 million in bad debt expenses. The decrease as a percentage of net sales was primarily due to the increase in net sales in the nine months ended March 31, 2015.

[0001628280-15-003900:mdna:76]
General and administrative expenses include stock-based compensation expense of $1.8 million and $1.5 million for the nine months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:77]
Interest and other expense, net. Interest and other expense, net, was $0.6 million and $0.5 million of expense for the nine months ended March 31, 2015 and 2014, respectively, which primarily represented $0.7 million and $0.5 million of interest expense for the nine months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:78]
Provision for income taxes. Provision for income taxes increased by $14.6 million, or 93.2%, to $30.2 million from $15.6 million, for the nine months ended March 31, 2015 and 2014, respectively. The effective tax rate was 28.7% and 29.4% for the nine months ended March 31, 2015 and 2014, respectively. The higher income tax provision for the nine months ended March 31, 2015 was primarily attributable to our higher operating income. The effective tax rate for the nine months ended March 31, 2015 was lower primarily due to the benefit from higher foreign tax credits and higher income taxed by foreign jurisdiction with lower tax rates.

[0001628280-15-003900:mdna:79]
[same as prior period, unchanged from 0001628280-15-000533:mdna:81]

[0001628280-15-003900:mdna:80]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions and improvements. Our cash and cash equivalents and short-term investments were $109.3 million and $96.9 million as of March 31, 2015 and June 30, 2014, respectively. Our cash in foreign locations was $22.8 million and $28.3 million at March 31, 2015 and June 30, 2014, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-15-003900:mdna:81]
Operating Activities. Net cash provided by operating activities was $9.1 million and $12.5 million for the nine months ended March 31, 2015 and 2014, respectively.

[0001628280-15-003900:mdna:82]
Net cash provided by our operating activities for the nine months ended March 31, 2015 was primarily due to our net income of $75.2 million, an increase in accounts payable of $38.7 million, stock-based compensation expense of $9.7 million,  an increase in accrued liabilities of $6.7 million, an increase in net income taxes payable of $5.8 million, depreciation expense of $5.9 million and provision for lower of cost or market and excess and obsolete inventory of $4.5 million, which were partially offset by an increase in inventory of $119.0 million, an increase in accounts receivable of $9.0 million and an excess tax benefits from stock-based compensation of $7.2 million.

[0001628280-15-003900:mdna:83]
Net cash provided by our operating activities for the nine months ended March 31, 2014 was primarily due to our net income of $37.6 million, an increase in accounts payable of $32.5 million, an increase in income tax payable of $9.9 million, stock-based compensation expense of $8.2 million, and depreciation expense of $4.6 million, which were partially offset by an increase in inventory of $43.3 million and an increase in accounts receivable of $34.1 million.

[0001628280-15-003900:mdna:84]
The increase for the nine months ended March 31, 2015 in accounts receivable was primarily due to an increase in our net sales late in the quarter ended March 31, 2015. The increase for the nine months ended March 31, 2015 in inventory and accounts payable was primarily due to higher purchases in anticipation of  the growth of our business in our seasonally strong June quarter and was also impacted by the timing of deliveries as a result of the west coast port strike in February 2015. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-15-003900:mdna:85]
The increase for the nine months ended March 31, 2014 in accounts receivable was primarily due to an increase in our sales in the quarter ended March 31, 2014. The increase for the nine months ended March 31, 2014 in accounts payable was due to higher purchases and timing of payments to our vendors. The increase for the nine months ended March 31, 2014 in inventory was due to support the anticipated level of growth in net sales in fiscal year 2014.

[0001628280-15-003900:mdna:86]
Investing activities. Net cash used in our investing activities was $25.7 million and $36.4 million for the nine months ended March 31, 2015 and 2014, respectively. In the nine months ended March 31, 2015, $24.6 million was related to the purchase of property, plant and equipment, of which $13.4 million was related to the development and construction of improvements on our property in San Jose, California, which is still in progress. In the nine months ended March 31, 2014, $36.8 million was related to the purchase of property, plant and equipment, of which $30.2 million was related to the real property purchased in San Jose, California in October 2013.

[0001628280-15-003900:mdna:87]
We plan to develop five manufacturing buildings through fiscal 2016 on the real property we purchased in San Jose, California, to serve as our Green Computing Park. We anticipate total costs of approximately $26.3 million through July 2015 for this development which we plan to finance using our operating cash flows and additional borrowings from banks.

[0001628280-15-003900:mdna:88]
Financing activities. Net cash provided by our financing activities was $30.0 million and $32.9 million for the nine months ended March 31, 2015 and 2014, respectively. In the nine months ended March 31, 2015, we received $21.1 million related to the proceeds from the exercise of stock options. Further, we borrowed an additional $36.4 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $35.3 million in loans in the nine months ended March 31, 2015. In the nine months ended March 31, 2015, excess tax benefits from stock-based compensation were $7.2 million. We expect the net cash provided by financing activities will increase throughout fiscal year 2015 as we intend to obtain additional financing from banks to construct our manufacturing buildings at our Green Computing Park in San Jose, California.

[0001628280-15-003900:mdna:89]
In the nine months ended March 31, 2014, we received $19.2 million related to proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding mainly on behalf of one executive officer for his restricted stock awards of $0.7 million for the nine months ended March 31, 2014. Further, we borrowed an additional $6.8 million under the line of credit from Bank of America, borrowed $7.1 million from the CTBC Bank secured term loan, and borrowed $3.5 million of our CTBC Bank revolving line of credit and repaid $5.6 million in loans in the nine months ended March 31, 2014. In the nine months ended March 31, 2014, excess tax benefits from stock-based compensation were $2.7 million.

[0001628280-15-003900:mdna:90]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on our revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-15-003900:mdna:91]
[same as prior period, unchanged from 0001628280-15-000533:mdna:93]

[0001628280-15-003900:mdna:92]
[same as prior period, unchanged from 0001628280-15-000533:mdna:94]

[0001628280-15-003900:mdna:93]
[same as prior period, unchanged from 0001628280-15-000533:mdna:95]

[0001628280-15-003900:mdna:94]
In October 2011, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $40.0 million revolving line of credit facility through June 15, 2013 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are

[0001628280-15-003900:mdna:95]
payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit to November 15, 2015.

[0001628280-15-003900:mdna:96]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.17% at March 31, 2015. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-15-003900:mdna:97]
As of March 31, 2015 and June 30, 2014, the total outstanding borrowings under the Bank of America term loan were $4.4 million and $6.5 million, respectively. The total outstanding borrowings under the Bank of America line of credit were $11.2 million and $17.7 million as of March 31, 2015 and June 30, 2014, respectively. The interest rates for these loans ranged from 0.82% to 1.67% per annum at March 31, 2015 and 1.19% to 1.65% per annum at June 30, 2014. As of March 31, 2015, the unused revolving line of credit under Bank of America was $28.8 million.

[0001628280-15-003900:mdna:98]
In April 2015, we drew an additional $10.0 million from Bank of America line of credit with an interest rate at 1.43% per annum to support the our growth and expansion of our business.

[0001628280-15-003900:mdna:99]
[same as prior period, unchanged from 0001628280-15-000533:mdna:100]

[0001628280-15-003900:mdna:100]
[same as prior period, unchanged from 0001628280-15-000533:mdna:101]

[0001628280-15-003900:mdna:101]
In November 2013, we entered into an amendment to our existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700.0 million or $23.8 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100.0 million or $3.4 million U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500.0 million or $17.0 million U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $34.0 million U.S. dollar equivalents.

[0001628280-15-003900:mdna:102]
[same as prior period, unchanged from 0001628280-15-000533:mdna:103]

[0001628280-15-003900:mdna:103]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21.1 million and $22.1 million as of March 31, 2015 and June 30, 2014, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9.7 million and $0 at March 31, 2015 and June 30, 2014, respectively. The interest rates for these loans ranged from 0.81% to 1.15% and 1.15% per annum at March 31, 2015 and June 30, 2014, respectively. At March 31, 2015, NT$37.1 million or $1.2 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-15-003900:mdna:104]
Covenant Compliance

[0001628280-15-003900:mdna:105]
Our credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-15-003900:mdna:106]
[same as prior period, unchanged from 0001628280-15-000533:mdna:107]

[0001628280-15-003900:mdna:107]
[same as prior period, unchanged from 0001628280-15-000533:mdna:108]

[0001628280-15-003900:mdna:108]
[same as prior period, unchanged from 0001628280-15-000533:mdna:109]

[0001628280-15-003900:mdna:109]
As of March 31, 2015, our total assets of $916.4 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of March 31, 2015, total assets collateralizing the term loan with Bank of America were $17.4 million. As of March 31, 2015, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001628280-15-003900:mdna:110]
As of March 31, 2015, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.2 million. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2015.

[0001628280-15-003900:mdna:111]
[same as prior period, unchanged from 0001628280-15-000533:mdna:112]

[0001628280-15-003900:mdna:112]
For the three and nine months ended March 31, 2015, we paid our contract manufacturers within 36 to 75 days of invoice and Ablecom between 48 to 105 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of March 31, 2015 and June 30, 2014, amounts owed to Ablecom by us were approximately $51.9 million and $49.0 million, respectively.

[0001628280-15-003900:mdna:113]
[same as prior period, unchanged from 0001628280-15-000533:mdna:114]

[0001628280-15-003900:mdna:114]
As of March 31, 2015, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AAA or AA2 at March 31, 2015. These auction rate preferred shares have no stated maturity date.

[0001628280-15-003900:mdna:115]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2015, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at March 31, 2015, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three and nine months ended March 31, 2015 and 2014, there were no auction rate securities redeemed or sold.

[0001628280-15-003900:mdna:116]
[same as prior period, unchanged from 0001628280-15-000533:mdna:117]

[0001628280-15-003900:mdna:117]
The following table describes our contractual obligations as of March 31, 2015:

[0001628280-15-003900:mdna:118]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 2,689 |  |  | $ | 2,777 |  |  | $ | 1,555 |  |  | $ | 3,513 |  |  | $ | 10,534 |  |
| Capital leases, including interest | 197 |  |  | 363 |  |  | 190 |  |  | — |  |  | 750 |  |
| Long-term debt, including interest (1) | 44,893 |  |  | 1,643 |  |  | — |  |  | — |  |  | 46,536 |  |
| Purchase commitments (2) | 376,773 |  |  | 114,415 |  |  | — |  |  | — |  |  | 491,188 |  |
| Total (3) | $ | 424,552 |  |  | $ | 119,198 |  |  | $ | 1,745 |  |  | $ | 3,513 |  |  | $ | 549,008 |  |

[0001628280-15-003900:mdna:119]
[same as prior period, unchanged from 0001628280-15-000533:mdna:120]

[0001628280-15-003900:mdna:120]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at March 31, 2015. |

[0001628280-15-003900:mdna:121]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $237.4 million of hard disk drive purchase commitments at March 31, 2015, which will be paid through January 2017. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-15-003900:mdna:122]
| (3) | The table above excludes liabilities for deferred revenue, net of cost, of $6.3 million and unrecognized tax benefits and related interest and penalties accrual of $10.6 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. |

[0001628280-15-003900:mdna:123]
[same as prior period, unchanged from 0001628280-15-000533:mdna:124]

[0001628280-15-003900:mdna:124]
[same as prior period, unchanged from 0001628280-15-000533:mdna:125]

[0001628280-15-003900:mdna:125]
[same as prior period, unchanged from 0001628280-15-000533:mdna:126]

[0001628280-15-003900:mdna:126]
[same as prior period, unchanged from 0001628280-15-000533:mdna:127]

[0001628280-15-003900:mdna:127]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. The new standard is effective for us on July 1, 2018. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-15-003900:mdna:128]
In April 2015, the FASB issued new accounting guidance related to presentation of debt issue costs. The new standard requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The new standard is effective for us on July 1, 2016. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-15-003900:mdna:129]
[same as prior period, unchanged from 0001628280-15-000533:mdna:129]

[0001628280-15-003900:mdna:130]
[same as prior period, unchanged from 0001628280-15-000533:mdna:130]
