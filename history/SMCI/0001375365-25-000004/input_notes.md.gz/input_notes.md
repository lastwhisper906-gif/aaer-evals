# SMCI notes — 0001375365-25-000004


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001375365-25-000004:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001375365-25-000004:notes:2]
None


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-25-000004:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001375365-25-000004:notes:4]
Super Micro Computer, Inc. (“Super Micro Computer” or the “Company”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, Taiwan, the Netherlands, China and Japan.

[0001375365-25-000004:notes:5]
Basis of Presentation

[0001375365-25-000004:notes:6]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or similar securities of the same investee.

[0001375365-25-000004:notes:7]
During the year ended June 30, 2023, the Company acquired 100% of Gemini Open Cloud Computing Inc. ("Gemini") for $2.5 million. The purchase price was allocated to tangible and intangible assets and liabilities based on fair values and goodwill of $1.8 million, attributed to planned growth, was recorded within other assets and reviewed annually for impairment. Goodwill is not expected to be tax-deductible. Acquisition-related costs were immaterial and included in general and administrative expenses. Gemini's post-acquisition revenue and results were immaterial. Pro forma earnings and revenues are not presented as they were not material. On June 28, 2024, Gemini was merged with and into our Taiwan operations, further integrating its capabilities within our global framework.

[0001375365-25-000004:notes:8]
The Company has agreements with certain contract manufacturers that allow the Company to offset receivables and payables with those counterparties. As of June 30, 2024 the gross amount recorded within the consolidated balance sheet in Other receivable and Accounts Payable was $14.0 million and $38.3 million, respectively.

[0001375365-25-000004:notes:9]
Forward Stock Split

[0001375365-25-000004:notes:10]
On September 30, 2024, the Company completed a 10-for-1 forward split of its common stock. Trading on a split-adjusted basis commenced on October 1, 2024. All references to shares of common stock and per share amounts contained in this Annual Report have been retroactively adjusted to reflect the stock split.

[0001375365-25-000004:notes:11]
Use of Estimates

[0001375365-25-000004:notes:12]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to revenue recognition, allowances for credit losses and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ materially from those estimates. These estimates and judgments are based on historical facts and various other assumptions that the Company believes are reasonable.

[0001375365-25-000004:notes:13]
Fair Value of Financial Instruments

[0001375365-25-000004:notes:14]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-25-000004:notes:15]
•Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001375365-25-000004:notes:16]
•Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and

[0001375365-25-000004:notes:17]
•Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable.

[0001375365-25-000004:notes:18]
Accounts receivable, other assets, accounts payable and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposit and the investment in an auction rate security are carried at fair value. Short-term and long-term debt and 2029 Convertible Notes are all carried at amortized cost.

[0001375365-25-000004:notes:19]
Cash, Cash Equivalents and Restricted Cash

[0001375365-25-000004:notes:20]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months.

[0001375365-25-000004:notes:21]
Restricted cash is comprised of amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to the Company’s workers’ compensation program. These restricted cash balances have been excluded from the Company's cash and cash equivalents balance and are included in Other assets on the Company’s consolidated balance sheet.

[0001375365-25-000004:notes:22]
|  | June 30, 2024 |  | June 30, 2023 |
| Cash and cash equivalents | $ | 1,669,766 |  |  | $ | 440,459 |  |
| Restricted cash included in other assets | 507 |  |  | 501 |  |
| Total cash, cash equivalents and restricted cash | $ | 1,670,273 |  |  | $ | 440,960 |  |

[0001375365-25-000004:notes:23]
Inventories

[0001375365-25-000004:notes:24]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based upon the Company's inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-25-000004:notes:25]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-25-000004:notes:26]
Property, Plant and Equipment

[0001375365-25-000004:notes:27]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-25-000004:notes:28]
| Software | 3 to 5 years |
| Machinery and equipment | 5 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |

[0001375365-25-000004:notes:29]
Long-Lived Assets

[0001375365-25-000004:notes:30]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge for long-lived assets has been recorded in any of the periods presented.

[0001375365-25-000004:notes:31]
Revenue Recognition

[0001375365-25-000004:notes:32]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories and services.

[0001375365-25-000004:notes:33]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by the Company are shipped from the Company’s facilities or drop shipped from the Company's vendors. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-25-000004:notes:34]
The Company applies judgment in determining the transaction price as the Company may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration is estimated using either the expected value or most likely amount method, depending on which method better predicts the amount of consideration to which we may be entitled. As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs.

[0001375365-25-000004:notes:35]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-25-000004:notes:36]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation.

[0001375365-25-000004:notes:37]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, the Company allocates the transaction price for each customer contract to each performance obligation based on the relative standalone selling price ("SSP") for each performance obligation within each contract. The Company recognizes the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company applies judgment to estimate the SSP. For all performance obligations, the Company is able to establish the SSP by maximizing the use of observable inputs. The Company typically establishes an SSP range for its products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for the Company’s products and services can evolve over time due to changes in its pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for the Company’s products and services, economic and other factors.

[0001375365-25-000004:notes:38]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-25-000004:notes:39]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. The Company has elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-25-000004:notes:40]
Accounts Receivable and Allowance for Credit Losses

[0001375365-25-000004:notes:41]
The Company records amounts as accounts receivable when the Company’s right to consideration is unconditional. Accounts receivable are recorded at the invoiced amount. For certain customers, we require payment before the products or services are delivered to the customer.

[0001375365-25-000004:notes:42]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability and intent to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer creditworthiness, current economic trends, and reasonable economic forecasts that affect collectability to evaluate the adequacy of the allowance for credit losses. For further details on the Company's allowance for credit losses, see Note 4, “Accounts Receivable Allowances” in the Notes to the Consolidated Financial Statements.

[0001375365-25-000004:notes:43]
Cost of Sales

[0001375365-25-000004:notes:44]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or net realizable value and excess and obsolete inventory.

[0001375365-25-000004:notes:45]
Product Warranties

[0001375365-25-000004:notes:46]
The Company offers product warranties typically ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement. Based on historical experience, the Company accrues estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may revise its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are recorded to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2024, 2023 and 2022, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-25-000004:notes:47]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Balance, beginning of the year | $ | 14,859 |  |  | $ | 12,137 |  |  | $ | 12,863 |  |
| Provision for warranty | 52,253 |  |  | 35,407 |  |  | 28,150 |  |
| Costs utilized | (49,204) |  |  | (33,784) |  |  | (29,872) |  |
| Change in estimated liability for pre-existing warranties | (93) |  |  | 1,099 |  |  | 996 |  |
| Balance, end of the year | $ | 17,815 |  |  | $ | 14,859 |  |  | $ | 12,137 |  |
| Current portion | 10,009 |  |  | 9,079 |  |  | 9,073 |  |
| Non-current portion | $ | 7,806 |  |  | $ | 5,780 |  |  | $ | 3,064 |  |

[0001375365-25-000004:notes:48]
Research and Development

[0001375365-25-000004:notes:49]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for the Company's research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to the Company's research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts and such amounts are recorded as a reduction of research and development expenses and were $21.5 million, $20.0 million, and $8.2 million for the fiscal years ended June 30, 2024, 2023 and 2022, respectively.

[0001375365-25-000004:notes:50]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-25-000004:notes:51]
Advertising Costs

[0001375365-25-000004:notes:52]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred. Total advertising and promotional expenses were $10.7 million, $2.0 million and $0.1 million for the fiscal years ended June 30, 2024, 2023 and 2022, respectively.

[0001375365-25-000004:notes:53]
Stock-Based Compensation

[0001375365-25-000004:notes:54]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-25-000004:notes:55]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of the grant. The fair value of stock options with a market condition is estimated, at the date of grant, using the Monte Carlo Simulation model. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The risk-free interest rate is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-25-000004:notes:56]
Leases

[0001375365-25-000004:notes:57]
The Company has arrangements for the right to use its office, warehouse spaces and other premises, and equipment. The Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-25-000004:notes:58]
Operating Leases

[0001375365-25-000004:notes:59]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate that the Company would have to pay to borrow on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that have variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

[0001375365-25-000004:notes:60]
For operating leases with lease terms of more than 12 months, operating lease ROU assets are recorded in other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the consolidated balance sheet. ROU assets recorded in Other assets as of June 30, 2024 and 2023 were $34.6 million and $18.9 million, respectively. The Company's lease term includes periods covered by options to extend the lease when it is reasonably certain that it will exercise that option. The Company’s lease term includes periods covered by an option to terminate the lease when it is reasonably certain that it will not exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-25-000004:notes:61]
Finance Leases

[0001375365-25-000004:notes:62]
ROU assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-25-000004:notes:63]
Income Taxes

[0001375365-25-000004:notes:64]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-25-000004:notes:65]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

[0001375365-25-000004:notes:66]
Variable Interest Entities

[0001375365-25-000004:notes:67]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-25-000004:notes:68]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, and all contractual arrangements with these entities. Also, because of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect these related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-25-000004:notes:69]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each party contributed $0.2 million for a 50% ownership interest of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2024, 2023 and 2022, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's consolidated statements of operations.

[0001375365-25-000004:notes:70]
Foreign Currency Transactions

[0001375365-25-000004:notes:71]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, except for Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in foreign currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the foreign currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the foreign currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, are reflected in the consolidated statements of operations in other income (expense), net. Realized and unrealized foreign exchange gain for fiscal years 2024, 2023 and 2022 was $6.3 million, $0.2 million and $7.7 million, respectively.

[0001375365-25-000004:notes:72]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-25-000004:notes:73]
The Company has an investment in a privately held company that is accounted for under the equity method (the "Corporate Venture").  The functional currency of the Corporate Venture is the Chinese Yuan. Adjustments for the Company's share of the effects of foreign currency translation from local currency to U.S. dollars are recorded as increases or decreases to the carrying value of the investment and included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-25-000004:notes:74]
Net Income Per Common Share

[0001375365-25-000004:notes:75]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, unvested RSUs and PRSUs and a 0.00% Convertible Senior Notes due 2029 (the "2029 Convertible Notes"). Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-25-000004:notes:76]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs and PRSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.

[0001375365-25-000004:notes:77]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-25-000004:notes:78]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |
| Net income - basic | $ | 1,152,666 |  |  | $ | 639,998 |  |  | $ | 285,163 |  |
| Convertible Notes interest charge, net of tax | 1,480 |  |  | — |  |  | — |  |
| Net income - diluted | $ | 1,154,146 |  |  | $ | 639,998 |  |  | $ | 285,163 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 555,878 |  |  | 529,249 |  |  | 514,785 |  |
| Effect of dilutive Convertible Notes | 4,392 |  |  | — |  |  | — |  |
| Effect of dilutive securities | 41,876 |  |  | 30,455 |  |  | 21,370 |  |
| Weighted-average shares outstanding - diluted | 602,146 |  |  | 559,704 |  |  | 536,155 |  |
| Net income per common share - basic | $ | 2.07 |  |  | $ | 1.21 |  |  | $ | 0.55 |  |
| Net income per common share - diluted | $ | 1.92 |  |  | $ | 1.14 |  |  | $ | 0.53 |  |

[0001375365-25-000004:notes:79]
For the fiscal years ended June 30, 2024, 2023 and 2022, the Company had stock options, RSUs and PRSUs outstanding that could potentially dilute basic earnings per share in the future but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 2,700,010, 1,777,950, and 4,755,290 for the fiscal years ended June 30, 2024, 2023 and 2022, respectively.

[0001375365-25-000004:notes:80]
Potentially dilutive shares of common stock issuable upon conversion of the Company's outstanding 2029 Convertible Notes are determined using the if-converted method. For the fiscal year ended June 30, 2024, all such shares issuable upon conversion of the 2029 Convertible Notes, were dilutive.

[0001375365-25-000004:notes:81]
Concentration of Supplier Risk

[0001375365-25-000004:notes:82]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry.

[0001375365-25-000004:notes:83]
Two suppliers accounted for below percentage of total purchases:

[0001375365-25-000004:notes:84]
|  | June 30, 2024 | June 30, 2023 | June 30, 2022 |
| Percentage of total purchases |  |  |  |
| Supplier A | 65.4% | 30.7% | 11.4% |
| Supplier B | 6.3% | 13.5% | 18.1% |

[0001375365-25-000004:notes:85]
The increase in the concentration of the Company's total purchases from supplier A to 65.4% of total purchases for the year ended June 30, 2024 is as a result of the purchase of key components to build its solutions for the Company's customers.

[0001375365-25-000004:notes:86]
Purchases from Ablecom and Compuware, related parties of the Company as noted in Note 10, "Related Party Transactions" in the Notes to the Consolidated Financial Statements, accounted for a combined 4.3%, 6.6%, and 8.3% of total cost of sales for the fiscal years ended June 30, 2024, 2023 and 2022, respectively.

[0001375365-25-000004:notes:87]
Concentration of Credit Risk

[0001375365-25-000004:notes:88]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash and accounts receivable. The Company deposits cash with high-quality financial institutions. These deposits are guaranteed by the federal deposit insurance corporation up to an insurance limit.

[0001375365-25-000004:notes:89]
Significant customer information is as follows:

[0001375365-25-000004:notes:90]
|  | June 30, 2024 | June 30, 2023 |
| Percentage of accounts receivable |  |  |
| Customer A | 15.4% | 22.9% |
| Customer B | * | 19.3% |
| Customer G | 44.8% | * |

[0001375365-25-000004:notes:91]
*Below 10%

[0001375365-25-000004:notes:92]
These accounts receivable represent a concentration of credit risk to the Company.

[0001375365-25-000004:notes:93]
Concentration of Customer Risk

[0001375365-25-000004:notes:94]
One single customer accounted for 20% of the net sales in fiscal year 2024. No single customer accounted for 10% or more of the net sales in fiscal year 2023 and 2022.

[0001375365-25-000004:notes:95]
Treasury Stock

[0001375365-25-000004:notes:96]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-25-000004:notes:97]
Accounting Pronouncements Not Yet Adopted

[0001375365-25-000004:notes:98]
In November 2023, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

[0001375365-25-000004:notes:99]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

[0001375365-25-000004:notes:100]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2026 and for the interim periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027, and for the interim period beginning July 1, 2028. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-25-000004:notes:101]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. The Company has elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.
Disaggregation of Revenue
The Company disaggregates revenue by type of product and geographical region to depict the nature, amount, and timing of revenue and cash flows. Service and software revenues, which are less than 10%, are not a significant component of total revenue and are aggregated with server and storage systems revenue.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-25-000004:notes:102]
Financial Instruments and Fair Value Measurements
The Company classifies its financial instruments, except for its investment in an auction rate security and other investments in privately held companies, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-25-000004:notes:103]
Financial Instruments Measured on a Recurring Basis

[0001375365-25-000004:notes:104]
The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents and other assets. The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents, accounts receivable, other assets, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities.

[0001375365-25-000004:notes:105]
The following table sets forth the Company’s financial instruments as of June 30, 2024 and 2023, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-25-000004:notes:106]
| June 30, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 340 |  |  | $ | — |  |  | $ | — |  |  | $ | 340 |  |
| Certificates of deposit | — |  |  | 486 |  |  | — |  |  | 486 |  |
| Investment in marketable equity security | 3,686 |  | — |  |  | — |  |  | 3,686 |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 4,026 |  |  | $ | 486 |  |  | $ | 1,829 |  |  | $ | 6,341 |  |
| June 30, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 20,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,823 |  |
| Certificates of deposit | — |  |  | 462 |  |  | — |  |  | 462 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 20,823 |  |  | $ | 462 |  |  | $ | 1,843 |  |  | $ | 23,128 |  |

[0001375365-25-000004:notes:107]
(1)  $0.1 million and $20.6 million in money market funds are included in cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in Other assets in the consolidated balance sheets as of June 30, 2024 and 2023, respectively.

[0001375365-25-000004:notes:108]
The carrying amounts of money market funds and certificates of deposit approximate their fair values due to their relatively short maturities.

[0001375365-25-000004:notes:109]
The investment in marketable equity security is carried at fair value using values available on a public exchange and is based on a Level 1 input. The unrealized gains and losses of the investment are included in earnings. During the fiscal year ended June 30, 2024, the Company invested $5.0 million in a marketable equity security recorded in Prepaid expenses and other

[0001375365-25-000004:notes:110]
current assets on the consolidated balance sheets. An unrealized loss of $1.3 million has been recorded in other income, net in the consolidated statement of operations for the fiscal year ended June 30, 2024.

[0001375365-25-000004:notes:111]
The Company’s investment in an auction rate security is classified as an available for sale security within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of June 30, 2024 and June 30, 2023. See Note 1, "Organization and Summary of Significant Accounting Policies" in the Notes to the Consolidated Financial Statements for a discussion of the Company’s policies regarding the fair value hierarchy. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and using the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of June 30, 2024.

[0001375365-25-000004:notes:112]
For the fiscal year ended June 30, 2024, 2023 and 2022, the unrealized gains and losses for the auction rate security in other comprehensive income are immaterial.

[0001375365-25-000004:notes:113]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, current economic conditions, and reasonable economic forecasts that affect collectability. For the fiscal year ended June 30, 2024 and 2023, the credit losses related to the Company’s investments were not material.

[0001375365-25-000004:notes:114]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in fiscal years 2024 and 2023.

[0001375365-25-000004:notes:115]
Financial Instruments Measured at Fair Value on a Non-Recurring Basis

[0001375365-25-000004:notes:116]
The Company's non-marketable equity securities consist of investments in privately held companies without readily determinable fair values and are classified as Level 2 in the fair value hierarchy. The Company invested $64.5 million during the fiscal year ended June 30, 2024 and an immaterial amount in the fiscal year ended June 30, 2023. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. The Company performed a qualitative assessment to identify impairment indicators and recorded an impairment of $11.6 million during the fiscal year ended June 30, 2024 and $0 during the fiscal years ended June 30, 2023 and 2022, in other income, net on the consolidated statement of operations.

[0001375365-25-000004:notes:117]
As of June 30, 2024, the Company had $54.6 million of investments in privately held companies recorded in Other assets on the consolidated balance sheets for which the measurement alternative was elected. As of June 30, 2023, the investment in privately held companies is immaterial.

[0001375365-25-000004:notes:118]
Financial Instruments Not Recorded at Fair Value

[0001375365-25-000004:notes:119]
The Company estimates the fair value of outstanding debt and 2029 Convertible Notes for disclosure purposes on a recurring basis.

[0001375365-25-000004:notes:120]
As of June 30, 2024 and 2023, total debt of $476.4 million and $290.3 million, respectively, is reported at amortized cost. The outstanding debt is categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-25-000004:notes:121]
The estimated fair value of the 2029 Convertible Notes was $1,734.6 million as of June 30, 2024. The 2029 Convertible Notes are categorized as Level 2 since their fair value is based on Level 2 inputs of quoted prices.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-25-000004:notes:122]
Revenue
    Disaggregation of Revenue

[0001375365-25-000004:notes:123]
The Company disaggregates revenue by type of product and geographical region to depict the nature, amount, and timing of revenue and cash flows. Service and software revenues, which are less than 10%, are not a significant component of total revenue and are aggregated with server and storage systems revenue.

[0001375365-25-000004:notes:124]
The following is a summary of net sales by product type (in thousands):

[0001375365-25-000004:notes:125]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 14,185,220 |  |  | $ | 6,569,814 |  |  | $ | 4,463,833 |  |
| Subsystems and accessories | 804,031 |  |  | 553,668 |  |  | 732,266 |  |
| Total | $ | 14,989,251 |  |  | $ | 7,123,482 |  |  | $ | 5,196,099 |  |

[0001375365-25-000004:notes:126]
Server and storage systems constitute an assembly and integration of subsystems and accessories, software, and related services. Subsystems and accessories are comprised of server boards, chassis and accessories.

[0001375365-25-000004:notes:127]
Revenue related to services for fiscal year June 30, 2024 was $152.1 million, which is recognized over time ratably over the contract term.

[0001375365-25-000004:notes:128]
International net sales are based on the country and geographical region to which the products were shipped. The following is a summary of net sales by geographic region (in thousands):

[0001375365-25-000004:notes:129]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 10,187,331 |  |  | $ | 4,834,061 |  |  | $ | 3,035,523 |  |
| Asia | 2,912,570 |  |  | 1,050,837 |  |  | 1,139,898 |  |
| Europe | 1,293,959 |  |  | 1,003,046 |  |  | 825,200 |  |
| Other | 595,391 |  |  | 235,538 |  |  | 195,478 |  |
| Total | $ | 14,989,251 |  |  | $ | 7,123,482 |  |  | $ | 5,196,099 |  |

[0001375365-25-000004:notes:130]
Contract Balances

[0001375365-25-000004:notes:131]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables represent the Company’s unconditional right to consideration for performance obligations that are either partially or fully completed.

[0001375365-25-000004:notes:132]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s consolidated financial statements.

[0001375365-25-000004:notes:133]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during fiscal year ended June 30, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $130.7 million. Revenue recognized during fiscal year ended June 30, 2023, which was included in the opening deferred revenue balance as of June 30, 2022, of $233.8 million, was $109.0 million.

[0001375365-25-000004:notes:134]
Deferred revenue increased $111.9 million as of June 30, 2024, as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a deferral of invoiced amounts for service contracts during the period exceeding the recognized revenue from service contracts entered into in prior periods. This was accompanied by a $9.3 million increase in non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-25-000004:notes:135]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-25-000004:notes:136]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services, that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to deferred revenue as of June 30, 2024, was approximately $416.4 million. The Company expects to recognize approximately 46% of this deferred revenue in the next 12 months, and the remainder thereafter.

[0001375365-25-000004:notes:137]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-25-000004:notes:138]
Contract acquisition costs are incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses paid to Company employees. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense contract acquisition costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the contract acquisition costs asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period when the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and services provided.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-25-000004:notes:139]
The following is a summary of net sales by geographic region (in thousands):


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-25-000004:notes:140]
Accounts Receivable Allowances

[0001375365-25-000004:notes:141]
The Company has established an allowance for credit losses. The allowance for credit losses is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2024, 2023 and 2022 consisted of the following (in thousands):

[0001375365-25-000004:notes:142]
|  | BeginningBalance |  | Charged toCost andExpenses (Recovered), net |  | Write-offs |  | EndingBalance |
| Allowance for credit losses |  |  |  |  |  |  |  |
| Year ended June 30, 2024 | $82 |  | $(9) |  | $— |  | $73 |
| Year ended June 30, 2023 | $1,753 |  | $(13) |  | $(1,659) |  | $82 |
| Year ended June 30, 2022 | $2,591 |  | $(840) |  | $2 |  | $1,753 |


## us-gaap:InventoryDisclosureTextBlock

[0001375365-25-000004:notes:143]
Inventories 
Inventories as of June 30, 2024 and 2023 consisted of the following (in thousands):

[0001375365-25-000004:notes:144]
|  | June 30, |
|  | 2024 |  | 2023 |
| Finished goods | $ | 3,312,768 |  |  | $ | 1,045,177 |  |
| Work in process | 450,993 |  |  | 71,874 |  |
| Raw materials | 569,268 |  |  | 328,513 |  |
| Total inventories | $ | 4,333,029 |  |  | $ | 1,445,564 |  |

[0001375365-25-000004:notes:145]
The amount of stock-based compensation capitalized in inventories as of June 30, 2024, 2023 and 2022 was immaterial.

[0001375365-25-000004:notes:146]
During the fiscal years ended June 30, 2024, 2023, and 2022, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $83.0 million, $30.8 million, and $15.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-25-000004:notes:147]
Property, Plant, and Equipment, net
Property, plant and equipment as of June 30, 2024 and 2023 consisted of the following (in thousands):

[0001375365-25-000004:notes:148]
|  | June 30, |
|  | 2024 |  | 2023 |
| Land | $ | 150,137 |  |  | $ | 86,642 |  |
| Buildings | 163,764 |  |  | 143,496 |  |
| Machinery and equipment | 156,496 |  |  | 130,151 |  |
| Building and leasehold improvements | 72,075 |  |  | 59,634 |  |
| Furniture and fixtures | 46,241 |  |  | 36,303 |  |
| Software | 24,363 |  |  | 23,098 |  |
| Buildings construction in progress | 14,828 |  |  | 303 |  |
|  | 627,904 |  |  | 479,627 |  |
| Accumulated depreciation and amortization | (213,896) |  |  | (189,387) |  |
| Property, plant and equipment, net | $ | 414,008 |  |  | $ | 290,240 |  |

[0001375365-25-000004:notes:149]
Depreciation and amortization expense for fiscal years 2024, 2023 and 2022 was $30.1 million, $26.9 million, and $24.8 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001375365-25-000004:notes:150]
Lines of Credit and Term Loans
Short-term and long-term loan obligations as of June 30, 2024 and 2023 consisted of the following (in thousands):

[0001375365-25-000004:notes:151]
|  | June 30, |
|  | 2024 |  | 2023 |
| Line of credit: |  |  |  |
| Cathay Bank Line of Credit | $ | — |  |  | $ | 131,583 |  |
| CTBC Credit Lines | 184,573 |  | — |
| Chang Hwa Bank Credit Lines | 9,215 |  | — |
| HSBC Bank Credit Lines | 30,000 |  | — |
| E.SUN Bank Credit Lines | 60,000 |  | — |
| Mega Bank Credit Lines | 50,000 |  | — |
| First Bank Credit Lines | 28,084 |  | — |  |
| Total line of credit | 361,872 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 17,918 |  | 26,853 |
| CTBC Term Loan Facility, due June 4, 2030 | 31,155 |  | 38,208 |
| CTBC Term Loan Facility, due August 15, 2026 | 3,079 |  | 4,721 |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 22,116 |  | 33,513 |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 12,645 |  | 16,756 |
| Mega Bank Term Loan Facility, due October 3, 2026 | 27,644 |  | 38,668 |
| Total term loans | 114,557 |  | 158,719 |
| Total lines of credit and term loans | 476,429 |  | 290,302 |
| Lines of credit and current portion of term loans | 402,346 |  | 170,123 |
| Term loans, non-current | $ | 74,083 |  |  | $ | 120,179 |  |

[0001375365-25-000004:notes:152]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-25-000004:notes:153]
Available borrowings and interest rates as of June 30, 2024 and June 30, 2023 consisted of the following (in thousands except for percentages):

[0001375365-25-000004:notes:154]
|  | June 30, 2024 |  | June 30, 2023 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  | 6.82% |  | $ | 350,000 |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  | 6.49% |  | $ | 20,000 |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  | 7.33% |  | $ | 417 |  | 7.08% |
| CTBC Credit Lines | $ | 427 |  | 2.09% - 6.13% |  | $ | 105,000 |  | 3.33% |
| Chang Hwa Bank Credit Lines | $ | 20,000 |  | 1.88% - 6.33% |  | $ | 20,000 |  | 6.58% |
| HSBC Bank Credit Lines | $ | 20,000 |  | 2.03% - 6.28% |  | $ | 50,000 |  | 4.50% |
| E.SUN Bank Credit Lines | $ | — |  | 2.02% - 6.17% |  | $ | 30,000 |  | 4.18% |
| Mega Bank Credit Lines | $ | — |  | 1.90% - 5.80% |  | $ | 20,000 |  | 2.55% |
| First Bank Credit Lines | $ | 1,916 |  | 2.03% - 6.19% |  | $ | — |  | —% |
| Yuanta Bank Credit Lines | $ | 47,610 |  | 2.32% - 6.33% |  | $ | — |  | —% |
| Term loan facilities: |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 1.68% |  | $ | — |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.33% |  | $ | — |  | 1.20% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  | 1.53% |  | $ | — |  | 1.40% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  | 1.87% |  | $ | 7,734 |  | 1.75% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  | 1.87% |  | $ | — |  | 1.75% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  | 1.52% - 1.72% |  | $ | — |  | 1.40% - 1.60% |

[0001375365-25-000004:notes:155]
Bank of America

[0001375365-25-000004:notes:156]
2018 Bank of America Credit Facility

[0001375365-25-000004:notes:157]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and change provisions relating to payments and LIBOR replacement mechanics to SOFR. The obligations bear a base interest rate plus 0.5% to 1.5% based on the SOFR availability. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Prior to that, on June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million and increase the maximum amount that the Company can request the facility be increased from $100 million to $150 million. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-25-000004:notes:158]
As of June 30, 2024 and 2023, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $0.0 million and $0.0 million, respectively. The interest rate under the 2018 Bank of America Credit Facility as of June 30, 2024 and 2023 was 6.82% and 6.57%, respectively. The balance of debt issuance costs outstanding as of June 30, 2024 and June 30, 2023 was $0.5 million and $0.7 million, respectively. As of June 30, 2024, the Company was in compliance with all covenants under the 2018 Bank of America Credit Facility, with an available borrowing capacity of $350.0 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-25-000004:notes:159]
2022 Bank of America Credit Facility

[0001375365-25-000004:notes:160]
On March 23, 2022, the Company through its Taiwan subsidiary entered into an Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch (the “2022 Bank of America Credit Facility”), for an amount not to exceed in aggregate $20.0 million. The interest rate will be quoted by Bank of America - Taipei Branch for each drawdown. As of June 30, 2024 and 2023, the Company had no outstanding borrowings under the 2022 Bank of America Credit Facility. As of June 30, 2024, the amount available for future borrowing under the 2022 Bank of America Credit Facility was $20.0 million.

[0001375365-25-000004:notes:161]
Cathay Bank

[0001375365-25-000004:notes:162]
Cathay Bank Line of Credit

[0001375365-25-000004:notes:163]
On May 19, 2022 (the “Cathay Bank Effective Date”), the Company entered into a Loan Agreement (the “Cathay Bank Loan Agreement”) with Cathay Bank pursuant to which Cathay Bank has agreed to provide a revolving line of credit of up to $132 million (the “Commitment”) for the five-year period following the Cathay Bank Effective Date. On the fifth anniversary of the Cathay Bank Effective Date, the total outstanding borrowings under the Cathay Bank Loan Agreement will automatically be converted into a five-year term loan. The interest rate under the Cathay Bank Loan Agreement is based upon either the SOFR index or prime rate index, at the Company’s quarterly election, plus a tiered spread that is based upon the average amounts deposited by the Company at Cathay Bank as a percentage of the Commitment. The spread is either 1.65% or 2.0% if the index is SOFR index, or 1.25% or 1.00% if the spread is the prime rate index with the higher spread applying in each case if an amount less than 25% of the Commitment is on deposit with Cathay Bank. Interest is payable monthly during the five-year period following the Cathay Bank Effective Date. After conversion to a term loan on the fifth anniversary of the Cathay Bank Effective Rate, interest is payable monthly based on a 20-year amortization schedule with the unpaid balance due at maturity. The Cathay Bank Loan Agreement has customary default provisions and is cross defaulted with other indebtedness to the extent such default causes a material adverse effect with respect to the Commitment. The Company is required to comply with certain covenants, including maintaining a fixed charge coverage ratio of at least 1.15:1.00. The Company is required to pay Cathay Bank an unused facility fee in the amount of 0.15% per annum of the undrawn Commitment payable quarterly in arrears. The Company is in compliance with all covenants under the Cathay Bank Loan Agreement.

[0001375365-25-000004:notes:164]
Borrowings under the Cathay Bank Loan Agreement are secured against certain of the Company’s properties located in San Jose, California (the “Collateral”). The Company has agreed to indemnify Cathay Bank with respect to certain environmental matters with respect to the Collateral. The Collateral is subject to re-appraisal every two years at the election of Cathay Bank, and Cathay Bank reserves the right to reduce the Commitment in accordance with such appraised values. As of June 30, 2024 and 2023 the outstanding borrowings under the Cathay Bank Loan Agreement were $0.0 million and $131.6 million, respectively. As of June 30, 2024, the Company's available borrowing capacity was $132.0 million under the Cathay Bank Loan Agreement and the net book value of the property collateralizing the Cathay Bank Line of Credit was $88.4 million.

[0001375365-25-000004:notes:165]
CTBC Bank

[0001375365-25-000004:notes:166]
CTBC Credit Lines

[0001375365-25-000004:notes:167]
On September 28, 2023, the Company's Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2023 CTBC Agreement”), which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

[0001375365-25-000004:notes:168]
On February 16, 2024, the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank (the “2024 CTBC Agreement”). This agreement (which changed arrangements under the 2023 CTBC Agreement), increased the aggregate total borrowings under the various individual credit arrangements with CTBC Bank from $105.0 million to $185.0 million. The credit arrangements under the 2024 CTBC Agreement now include the previous issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “New NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “New USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “New Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80.0 million available through August 31, 2024 (the “Incremental Import Line,” and, together with the New NTD Short Term Loan/Guarantee Line, the New USD Short Term Loan Line, and the New Export/Import Line, the “Increased CTBC Credit Lines”). Aggregate borrowings under all the Increased CTBC Credit Lines are subject to a cap of $185.0 million.

[0001375365-25-000004:notes:169]
Interest rates under each of the individual Increased CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the New NTD Short Term Loan/Guarantee Line and the New USD Short Term Loan Line continue to be secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor of the Incremental Import Line provides for availability until August 31, 2024, with a final drawdown date of February 28, 2025. Such Incremental Import Line, which is reviewed quarterly for cancellation by the CTBC Bank, is also subject to an average usage requirement and fee for retaining the underutilized portion of such line. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of the Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the Increased CTBC Credit Lines. The Increased CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable.

[0001375365-25-000004:notes:170]
As of June 30, 2024 and 2023, the outstanding borrowings under the CTBC Bank Credit Lines were $184.6 million and $0.0 million, respectively. The interest rate for these loans ranged from 2.09% to 6.13% per annum as of June 30, 2024.

[0001375365-25-000004:notes:171]
CTBC Term Loan Facility

[0001375365-25-000004:notes:172]
The Company, through its Taiwan subsidiary, entered into certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC”), which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to borrow up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent).

[0001375365-25-000004:notes:173]
On July 20, 2021, the Company, through its Taiwan subsidiary, entered into a general agreement for omnibus credit lines with CTBC (the “2021 CTBC Credit Facility"), which replaced the prior CTBC credit facilities, other than the 2020 CTBC Team Loan Facility, in their entirety and permit borrowings, from time to time, pursuant to a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalent) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalent) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalent) to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”).

[0001375365-25-000004:notes:174]
As of June 30, 2024 and 2023, the amounts outstanding under the 2020 CTBC Term Loan Facility were $31.2 million and $38.2 million, respectively. The interest rates for these loans were 1.33% per annum as of June 30, 2024 and 1.20% per annum as of June 30, 2023.

[0001375365-25-000004:notes:175]
As of June 30, 2024 and 2023, under the 2021 CTBC Machine Loan, the amounts outstanding were $3.1 million and $4.7 million, respectively. The interest rates for these loans were 1.53% per annum as of June 30, 2024 and 1.40% per annum as of June 30, 2023.

[0001375365-25-000004:notes:176]
The Company was in compliance with all financial covenants under 2020 CTBC Term Loan Facility and 2021 CTBC Machine Loan as of June 30, 2024.

[0001375365-25-000004:notes:177]
As of June 30, 2024, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Line and Term Loan Facility was $72.9 million.

[0001375365-25-000004:notes:178]
Chang Hwa Bank

[0001375365-25-000004:notes:179]
Chang Hwa Bank Credit Lines

[0001375365-25-000004:notes:180]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company, through its Taiwan subsidiary, entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”). The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are set forth in the Import O/A Loan Contract and Export O/A Loan Contract, which were entered into on the Chang Hwa Bank Effective Date None of these Loan Contracts are secured and there are no financial covenants. The Company is not a guarantor under the Chang Hwa Bank Credit Facility.

[0001375365-25-000004:notes:181]
On May 13, 2022, Chang Hwa Bank notified that it increased the borrowing capacity limit by $20.0 million.

[0001375365-25-000004:notes:182]
On April 26, 2024 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “New Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the Chang Hwa Bank Credit Facility, except the credit limit thereunder was updated to include, in addition to US$20 million from the Chang Hwa Bank Credit Facility, an additional credit limit of NTD300 million (together, the “CHB Credit Lines”). The Company is not a guarantor of the New Credit Facility.

[0001375365-25-000004:notes:183]
Terms for specific drawdown instruments issued under the New Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of US$20 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to US$20 million for an import loan (the “Import O/A Loan”), with the interest rate thereunder is based on TAIFX plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to US$20 million for an export loan (the “Export O/A Loan”). with the interest rate thereunder is based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD300 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified 1-year time savings deposit rate, subject to a floor of 1.4%.

[0001375365-25-000004:notes:184]
None of the Import O/A Loan, Export O/A Loan, or General Working Capital Loan are secured and there are no financial covenants. Under the New Credit Facility, the Bank has the right to demand collateral for debts owed.

[0001375365-25-000004:notes:185]
As of June 30, 2024, the outstanding borrowings under CHB Credit Lines were $9.2 million. The interest rate was 1.88% per annum as of June 30, 2024. As of June 30, 2024, the amount available for future borrowing under the CHB Credit Lines was $20.0 million.

[0001375365-25-000004:notes:186]
As of June 30, 2024 and 2023, the total outstanding borrowings under the Chang Hwa Bank Term Loan Facility were denominated in NTD and remeasured into U.S. dollars at $17.9 million and $26.9 million, respectively. The interest rate under the Chang Hwa Bank Credit Facility as of June 30, 2024 and 2023 was 1.68% per annum and 1.55% per annum, respectively.

[0001375365-25-000004:notes:187]
E.SUN Bank

[0001375365-25-000004:notes:188]
E.SUN Bank Credit Lines

[0001375365-25-000004:notes:189]
On June 17, 2023, the Company through the Taiwan subsidiary, entered into a Notification and Confirmation pursuant to which the Taiwan subsidiary and E.SUN Bank agreed to drawdowns of up to US$30 million for an import o/a financing loan with a tenor of 120 days (the “2023 Import O/A Loan”). The period of use is between May 16, 2023 and May 16, 2024. The interest rate thereunder is based on TAIFX3 plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and the principal is repayable on the due date. The 2023 Import O/A Loan is not secured. Such Notification and Confirmation replaced the Notification and Confirmation entered into on the 2022 E.SUN Bank Effective Date related to the 2022 Import O/A Loan.

[0001375365-25-000004:notes:190]
On April 19, 2024, the Company’s Taiwan subsidiary entered into a Notification and Confirmation of Credit Conditions with E.SUN Bank. Pursuant to the Notification and Confirmation, our Taiwan subsidiary and E.SUN Bank agreed to the following:

[0001375365-25-000004:notes:191]
(i) A comprehensive credit facility of up to US$60 million (the “Import and Export Trade Facility). The Import and Export Trade Facility is comprised of both an Import O/A Financing Loan and an Export O/A Financing Loan (the “O/A Loan") which share the US$60 million limit. The interest rate for the O/A Loan is based on TAIFX3 plus a fixed margin, which may be negotiated, and is subject to adjustment under certain circumstances (including in the event that certain thresholds with respect to remittances and average deposits are not met by specified time periods). The loan period tenor for drawdowns under the O/A Loan is 120 days.

[0001375365-25-000004:notes:192]
(ii) A Short Term loan of up to NT$800 million (the “Short Term Loan”) ($25.0 million U.S. dollar equivalent).  The interest rate for the Short Term Loan is based upon E.SUN Bank’s one-month time savings deposit rate index plus a fixed margin, may be negotiated, is subject to adjustment under certain circumstances (including in the event that certain thresholds with respect to remittances and average deposits are not met by specified time periods), and may not be lower than 1.9%. The loan period tenor for drawdowns under the Short Term Loan is 180 days.

[0001375365-25-000004:notes:193]
ESUN Bank credit lines with a period of use from March 14, 2024 through March 14, 2025 may be drawn on a revolving basis. The first drawdown is required to be made by March 14, 2025. Neither the O/A Loan nor Short Term Loan are secured, and the Company is not a guarantor. The total outstanding balance of facilities (i) and (ii) shall not exceed US$60 million.

[0001375365-25-000004:notes:194]
As of June 30, 2024 and 2023, the amounts outstanding under the ESUN Bank credit lines were $60.0 million and $0.0 million, respectively. The interest rate for the fiscal year ended June 30, 2024 was 6.17% per annum.  As of June 30, 2024, the amount available for future borrowing under the Import O/A Loan was $0.0 million.

[0001375365-25-000004:notes:195]
E.SUN Bank Term Loan Facility

[0001375365-25-000004:notes:196]
On September 13, 2021 (the “Old E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permitted borrowings of up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent).

[0001375365-25-000004:notes:197]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, were to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the Old E.SUN Bank Effective Date for a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”). As of June 30, 2024 and 2023, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $22.1 million and $33.5 million, respectively.

[0001375365-25-000004:notes:198]
On August 9, 2022 (the “2022 E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary, entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “2022 E.SUN Bank Credit Facility”). The 2022 E.SUN Bank Credit Facility permits borrowings of up to NTD 680.0 million ($23.0 million U.S. dollar equivalent) and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1.8 billion ($61.0 million U.S. dollar equivalent). The Company is not a guarantor of the New E.SUN Bank Credit Facility.

[0001375365-25-000004:notes:199]
Terms for specific drawdown instruments issued under the 2022 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in a Notifications and Confirmation. Under a Notification and Confirmation entered into on the 2022 E.SUN Bank Effective Date, the Taiwan subsidiary and E.SUN Bank have agreed to a Medium Term Credit Loan of NTD 680.0 million ($23.0 million U.S. dollar equivalent) with a tenor of five years (the “Medium Term Loan”). With respect to the Medium Term Loan, the interest rate thereunder is based upon a floating annual rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis. Principal is amortized evenly on a monthly basis, with principal payments subject to a one year grace period prior to the commencement of repayment. The Medium Term Loan will be used by the Taiwan subsidiary to support its manufacturing activities (such as purchase of materials and components) (“Use of Proceeds”). Drawdowns may be in amounts of up to 80% of permitted Use of Proceeds expenses. The Taiwan subsidiary is subject to various financial covenants in connection with the Medium Term Loan, including a current ratio, net debt to equity ratio, and interest coverage ratio. As of June 30, 2024 and 2023, the amount outstanding under the Term Loan was denominated in NTD and remeasured into US dollars of $12.6 million and $16.8 million, respectively.

[0001375365-25-000004:notes:200]
The interest rates for the Term Loan were 1.87% per annum as of June 30, 2024 and 1.75% per annum as of June 30, 2023.

[0001375365-25-000004:notes:201]
The Company was in compliance with all financial covenants under 2021 E.SUN Bank Credit Facility and 2022 E.SUN Bank Credit Facility as of June 30, 2024.

[0001375365-25-000004:notes:202]
HSBC Bank

[0001375365-25-000004:notes:203]
HSBC Bank Credit Lines

[0001375365-25-000004:notes:204]
On January 7, 2022 (the “HSBC Bank Effective Date”), the Company, through its Taiwan subsidiary, entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with a Taiwan affiliate of HSBC Bank (“HSBC Bank”). HSBC Bank agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. The Company is not a guarantor of the Loan Agreement and interest payments are due on a monthly basis, and principal is repayable on the due date.

[0001375365-25-000004:notes:205]
On February 7, 2023, the Company through the Taiwan subsidiary, entered into a new facility letter with the Taiwan affiliate of HSBC Bank which expanded the prior $30 million facility letter entered into with HSBC Bank on January 7, 2022. The New Facility Letter permits borrowings up to a combined aggregate limit of $50.0 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date. Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash cover.

[0001375365-25-000004:notes:206]
On December 7, 2023, the Company's Taiwan subsidiary entered into a new facility letter (the “New Facility Letter”)

[0001375365-25-000004:notes:207]
with the Taiwan affiliate of HSBC Bank. The New Facility Letter permits borrowings up to a combined aggregate limit of $50.0 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300.0 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50.0 million (the “Export/Seller Facility”, and together with the NTD Revolver, the "HSBC Bank Credit Lines"). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date.

[0001375365-25-000004:notes:208]
Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash coverage.

[0001375365-25-000004:notes:209]
As of June 30, 2024 and 2023, the outstanding borrowings under HSBC Bank Credit Lines were $30.0 million and $0.0 million, respectively. The interest rates for these loans were 6.28% and 4.50% per annum as of June 30, 2024 and 2023.  As of June 30, 2024, the amount available for future borrowing under the HSBC Bank Credit Lines was $20.0 million.

[0001375365-25-000004:notes:210]
Mega Bank

[0001375365-25-000004:notes:211]
Mega Bank Credit Facilities

[0001375365-25-000004:notes:212]
On April 25, 2022, the Company through its Taiwan subsidiary, entered into a $20.0 million (or foreign currency equivalent) (the “2022 Credit Limit”) Omnibus Credit Authorization Agreement (the “2022 Omnibus Credit Authorization Agreement”) with Mega Bank. The 2022 Omnibus Credit Authorization Agreement permits individual credit authorizations subject to specified drawdown conditions up to the 2022 Credit Limit (on a revolving basis) to be used as loans for the purchase of materials or supplies.

[0001375365-25-000004:notes:213]
On June 17, 2023, the Company through its Taiwan subsidiary, entered into a new Omnibus Credit Authorization Agreement (the “2023 Omnibus Authorization Agreement) and a Credit Authorization Approval Notice (the “2023 Credit Authorization Approval Notice”) with Mega Bank with the same 2022 Credit Limit which replaced the 2022 Omnibus Credit Authorization Agreement. Pursuant to such 2023 Credit Authorization Approval Notice, the associated Mega Bank branch permits the Taiwan subsidiary to make drawdowns up to the Credit Limit for short-term loans for material purchases and operating revolving needs with a tenor not to exceed 120 days for material purchases and 180 days on a revolving basis. Interest on material purchases drawdown denominated in US dollar is based upon TAIFX OFFER for either three or six months and operating revolving drawdown denominated in New Taiwan dollar is based upon TAIBOR OFFER for either three or six

[0001375365-25-000004:notes:214]
months, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to the bank’s right of set off. Amounts borrowed are otherwise unsecured. The Company is not a guarantor under the 2023 Credit Authorization Approval Notice.

[0001375365-25-000004:notes:215]
On April 17, 2024 Company through its Taiwan subsidiary entered into an Omnibus Credit Authorization Agreement (the “New Omnibus Credit Authorization Agreement”) with Mega International Commercial Bank (“Mega Bank”), which was substantially similar to the 2023 Omnibus Authorization Agreement, except the credit limit thereunder was increased from US$20 million (or foreign currency equivalent) to US$50 million (or foreign currency equivalent) (the “Mega Bank Credit Limit”). During the loan period, the Company’s Taiwan subsidiary is required to maintain certain specified deposit balances with Mega Bank and the Company is required to maintain 100% direct or indirect share ownership of its Taiwan subsidiary.

[0001375365-25-000004:notes:216]
Pursuant to the Omnibus Credit Authorization Agreement, the Company's Taiwan subsidiary entered into a Credit Authorization Agreement dated April 17, 2024 with Mega Bank (the “Credit Authorization Agreement”) which set forth additional terms of the individual credit authorizations. The Company's Taiwan subsidiary also received a Credit Authorization Approval Notice (the “Approval Notice”) from an associated branch of Mega Bank. Pursuant to such Approval Notice, the associated Mega Bank branch permits the Company's Taiwan subsidiary to make drawdowns up to the Mega Bank Credit Limit for short-term loans for material purchases and operating revolver with a tenor not to exceed 120 days. The Approval Notice also includes a sub-item credit limit of NTD1.2 billion as short-term loans for turnover. Interest on drawdowns denominated in US dollars is based upon TAIFX OFFER for 3 or 6 months, interest on drawdowns denominated in NTD is based upon TAIBOR for 3 or 6 months, and interest on drawdowns denominated in other currencies is based upon Mega Bank’s cost of borrowing plus a specified premium, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to Mega Bank’s right of set off. Amounts borrowed are otherwise unsecured. The Company is not a guarantor under the Approval Notice.

[0001375365-25-000004:notes:217]
As of June 30, 2024 and 2023, the outstanding borrowings under Mega Bank credit lines were $50.0 million and $0.0 million, respectively. The interest rates for these loans were 5.80% per annum as of June 30, 2024.

[0001375365-25-000004:notes:218]
Mega Bank Term Loan Facilities

[0001375365-25-000004:notes:219]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega Bank. The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. The first drawdown date was on October 4, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable.

[0001375365-25-000004:notes:220]
As of June 30, 2024 and 2023, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars at $27.6 million and $38.7 million, respectively. The interest rates ranged from 1.52% to 1.72% per annum as of June 30, 2024, and ranged 1.40% to 1.60% per annum as of June 30, 2023.

[0001375365-25-000004:notes:221]
Yuanta Bank

[0001375365-25-000004:notes:222]
Yuanta Bank Credit Lines

[0001375365-25-000004:notes:223]
On May 23, 2024, the Company’s Taiwan subsidiary entered into an Omnibus Credit Agreement and an additional agreement with Yuanta Commercial Bank Co., Ltd., securing credit lines up to NTD1.55 billion ($47.8 million U.S. dollar equivalent) . The agreement allows for revolving borrowings, including: (i) Working Capital Loans up to NTD1.55 billion, (ii) Overseas Purchase Loans up to US$50 million, and (iii) Export Loans up to US$50 million.

[0001375365-25-000004:notes:224]
Per the Credit Approval Letter from Yuanta Bank dated February 20, 2024: (i) Working Capital Loans have a drawdown limit of five months, with interest payable monthly, based on Yuanta Bank’s base rate plus a premium, subject to negotiation; (ii) Overseas Purchase Loans and Export Loans have drawdown limits of 150 days, with interest rates based on Yuanta Bank’s base rate or TAIFX3 plus a premium, also negotiable.

[0001375365-25-000004:notes:225]
Interest rates are subject to adjustment under certain conditions, such as insufficient deposit balances with Yuanta Bank. Borrowings are unsecured but subject to Yuanta Bank’s right of set-off. The Company is not a guarantor.

[0001375365-25-000004:notes:226]
As of June 30, 2024, there were no outstanding borrowings.

[0001375365-25-000004:notes:227]
First Bank

[0001375365-25-000004:notes:228]
First Bank Credit Lines

[0001375365-25-000004:notes:229]
On April 26, 2024, the Company's Taiwan subsidiary entered into a Credit Agreement and a Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”), providing a foreign currency working capital loan of up to US$30 million on a revolving basis (the “First Bank Loan”). The loan terms, outlined in a Facility Letter from First Bank dated February 20, 2024, set the contract period from February 17, 2024, to February 17, 2025, with interest rates based on TAIFX or base rate plus a premium, depending on the currency.

[0001375365-25-000004:notes:230]
The loan is unsecured but subject to First Bank’s right of set-off, with the possibility of requiring collateral at the bank’s discretion. First Bank retains the right to reduce the facility amount, shorten the repayment term, or call the loan in full under certain conditions, such as missed interest or principal payments, failure to meet obligations to other financial institutions, or material legal violations by the Subsidiary. The Company itself is not a guarantor under either the Credit Agreement or the Foreign Currency Agreement.

[0001375365-25-000004:notes:231]
As of June 30, 2024, outstanding borrowings under the First Bank Credit Lines were $28.1 million with an interest rate of 6.19% per annum.

[0001375365-25-000004:notes:232]
Principal payments on short-term and long-term debt obligations are due as follows (in thousands):

[0001375365-25-000004:notes:233]
| Fiscal Year: | Principal Payments |
| 2025 | $ | 402,346 |  |
| 2026 | 40,475 |  |
| 2027 | 17,584 |  |
| 2028 | 5,931 |  |
| 2029 | 5,266 |  |
| 2030 and thereafter | 4,827 |  |
| Total short-term and long-term debt | $ | 476,429 |  |

[0001375365-25-000004:notes:234]
As of June 30, 2024, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 7.
Convertible Notes 
2029 Convertible Notes

[0001375365-25-000004:notes:235]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The 2029 Convertible Notes will mature on March 1, 2029, unless earlier converted, redeemed or repurchased. On February 20, 2025, the Company executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented amendments to the 2029 Convertible Notes. Refer to Note 16, “Subsequent Events” in the Notes to the Consolidated Financial Statements below.

[0001375365-25-000004:notes:236]
The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. Because the Company did not file its Annual Report on Form 10-K for the fiscal year ended June 30, 2024 in a timely manner, it elected to accrue special interest on the 2029 Convertible Notes and accrued additional interest on the 2029 Convertible Notes in accordance with the indenture governing the 2029 Convertible Notes (the “2029 Convertible Notes Indenture”). Refer to Note 16, “Subsequent Events,” below. The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 7.455 shares of common stock per $1,000 principal amount of 2029 Convertible Notes, which is equivalent to an initial conversion price of approximately $134.14 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest and additional interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture and have accrued on the 2029 Convertible Notes subsequent to June 30, 2024 as described above. The debt issuance costs are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

[0001375365-25-000004:notes:237]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2024, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date.

[0001375365-25-000004:notes:238]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000004:notes:239]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

[0001375365-25-000004:notes:240]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. The 2029 Convertible Notes were not eligible for conversion as of June 30, 2024. No sinking fund is provided for the 2029 Convertible Notes.

[0001375365-25-000004:notes:241]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of June 30, 2024, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

[0001375365-25-000004:notes:242]
The Company accounted for the issuance of the 2029 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000004:notes:243]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $27.3 million, was $1,697.7 million as of June 30, 2024. Interest expense related to the amortization of debt issuance costs was $1.9 million for the year ended June 30, 2024. The effective interest rate is 0.34%.

[0001375365-25-000004:notes:244]
Capped Calls

[0001375365-25-000004:notes:245]
In connection with the issuance of the 2029 Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. In connection with the amendment of the 2029 Convertible Notes, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to Note 16, “Subsequent Events,” below.

[0001375365-25-000004:notes:246]
The Capped Call Transactions initially have an initial strike price of $134.14 per share, subject to certain adjustments, which corresponds to the initial conversion price of the 2029 Convertible Notes. The cap price of the Capped Call Transactions was initially $195.10 per share of common stock subject to certain adjustments under the terms of the Capped Call Transactions.

[0001375365-25-000004:notes:247]
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The 2029 Convertible Notes and the Capped Call Transactions have been integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.

[0001375365-25-000004:notes:248]
Refer to Note 16, "Subsequent Events" in the Notes to the Consolidated Financial Statements for additional information.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001375365-25-000004:notes:249]
Short-term and long-term loan obligations as of June 30, 2024 and 2023 consisted of the following (in thousands):


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-25-000004:notes:250]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized, and supplemental cash flow information related to operating leases for the years ended June 30, 2024 and 2023 were as follows (in thousands):

[0001375365-25-000004:notes:251]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |
| Operating lease expense (including expense for lease agreements with related parties of $450 and $561 for the years ended June 30, 2024 and 2023, respectively) | $ | 9,983 |  |  | $ | 8,299 |  |
| Cash payments for operating leases (including payments to related parties of $406 and $524 for the years ended June 30, 2024 and 2023, respectively) | $ | 9,343 |  |  | $ | 8,275 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 32,581 |  |  | $ | 3,197 |  |

[0001375365-25-000004:notes:252]
During the years ended June 30, 2024 and 2023, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the years ended June 30, 2024, 2023 and 2022 were $2.3 million, $1.8 million and $1.1 million, respectively.

[0001375365-25-000004:notes:253]
As of June 30, 2024, the weighted average remaining lease term for operating leases was 4.7 years and the weighted average discount rate was 5.1%. As of June 30, 2023, the weighted average remaining lease term for operating leases was 3.0 years and the weighted average discount rate was 3.1%. The short-term portion of the lease liability is included in accrued liabilities and the long-term portion of the lease liability is included in other long-term liabilities on the consolidated balance sheets. Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of June 30, 2024, were as follows (in thousands):

[0001375365-25-000004:notes:254]
| Fiscal Year: |  | Maturities of operating leases(1) |
| 2025 |  | $ | 10,660 |  |
| 2026 |  | 7,932 |  |
| 2027 |  | 6,274 |  |
| 2028 |  | 5,039 |  |
| 2029 |  | 4,543 |
| 2030 and beyond |  | 6,156 |  |
| Total future lease payments |  | 40,604 |  |
| Less: Imputed interest |  | (5,222) |  |
| Present value of operating lease liabilities |  | 35,382 |  |
| Less: Current portion |  | (9,248) |  |
| Long-term portion of operating lease liabilities |  | $ | 26,134 |  |

[0001375365-25-000004:notes:255]
(1) The table does not include amounts pertaining to leases that have not yet commenced.

[0001375365-25-000004:notes:256]
Lease executed but not commenced

[0001375365-25-000004:notes:257]
In June 2024, the Company entered into a lease agreement for a 21 megawatt data center co-location space located in Vernon, California (the “Data Center Space”) that will expire on August 31, 2035. As this lease has not yet commenced, it is not reflected in the Consolidated Balance Sheets or in the table above. Concurrently, the Company sublicensed this space to an unrelated party (the “Sublicensee”) for the same term expiring on August 31, 2035, which also has not yet commenced. Pursuant to the sublicense, the Company will sublicense the Data Center Space lease to the Sublicensee, and the Sublicensee will assume all rights and obligations with respect to the Data Center Space lease. The Company expects to account for the lease as an operating lease and the sublicense as a sublease under ASC 842. The future undiscounted fixed non-cancelable payment obligation pertaining to the data center lease is approximately $411.8 million and future minimum sublicense receipts are approximately $436.5 million.

[0001375365-25-000004:notes:258]
The Company holds an equity investment of $42.5 million in the sublicensee, which is classified under investments in privately held companies and recorded in Other assets on the consolidated balance sheets. The sublicensee does not meet the criteria of a related party. Additionally, the sublicensee has been a customer of the Company, and the Company concluded that equity investment agreements and sub-licensing agreement are separate from revenue contracts as all transactions have been recorded at the respective fair values.

[0001375365-25-000004:notes:259]
Related party leases

[0001375365-25-000004:notes:260]
The Company has entered into lease agreements with related parties. See Note 10, "Related Party Transactions" in the Notes to the Consolidated Financial Statements for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-25-000004:notes:261]
Related Party Transactions
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of June 30, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-25-000004:notes:262]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on NASDAQ in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.4 million.

[0001375365-25-000004:notes:263]
Dealings with Ablecom

[0001375365-25-000004:notes:264]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-25-000004:notes:265]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 93.6%, 91.9% and 88.2% of the chassis included in the products sold by the Company during fiscal years 2024, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-25-000004:notes:266]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. There is no revenue recognized by the Company from these transactions. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-25-000004:notes:267]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000004:notes:268]
Dealings with Compuware

[0001375365-25-000004:notes:269]
The Company appointed Compuware as a non-exclusive authorized distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility of installing the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-25-000004:notes:270]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. The Company has extended a $65.0 million trade credit line with a net 60 days payment terms to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000004:notes:271]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-25-000004:notes:272]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by the Company from these transactions. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-25-000004:notes:273]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-25-000004:notes:274]
Dealings with Leadtek Research Inc.

[0001375365-25-000004:notes:275]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. Since the closing of the Leadtek Investment, the Company engaged in transactions whereby it sold $1.4 million of servers to Leadtek and purchased $2.1 million of graphics cards from Leadtek.

[0001375365-25-000004:notes:276]
Dealings with Investment in a Corporate Venture

[0001375365-25-000004:notes:277]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-25-000004:notes:278]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $4.6 million and $2.0 million as of June 30, 2024 and 2023, respectively, recorded in Other assets on the consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of June 30, 2024 and 2023. No impairment charge was recorded for the fiscal years ended June 30, 2024, 2023 and 2022.

[0001375365-25-000004:notes:279]
The Company sold products worth $21.8 million, $24.2 million, and $121.0 million to the Corporate Venture in the fiscal years 2024, 2023 and 2022, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of June 30, 2024 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company's investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $5.1 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of June 30, 2024 and 2023, respectively.

[0001375365-25-000004:notes:280]
Other Transactions

[0001375365-25-000004:notes:281]
For the fiscal year ended June 30, 2024, the Company had immaterial sales to and purchases from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. As of June 30, 2024, the amounts due to and from Green Earth are immaterial.

[0001375365-25-000004:notes:282]
For the fiscal year ended June 30, 2024, the Company had immaterial sales of products indirectly to Aeon Lighting Technology Inc. (“Aeon Lighting”) through a system integrator. Aeon Lighting is a company which is owned more than 10% by James Liang, a brother of the Company’s Chief Executive Officer. James Liang is also a director of Aeon Lighting and serves as the Chief Executive Officer of such entity. As of June 30, 2024, the amount due from Aeon Lighting is immaterial.

[0001375365-25-000004:notes:283]
The Company had the following balances related to transactions with its related parties as of the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands):

[0001375365-25-000004:notes:284]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | Leadtek | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, | Years Ended June 30, |
|  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 | 2024 | 2023 | 2022 |
| Accounts receivable | $ | 1 |  | $ | 2 |  | $ | 2 |  |  | $ | 142 |  | $ | 3,528 |  | $ | 404 |  |  | $ | 5,075 |  | $ | 1,943 |  | $ | 7,992 |  |  | $ | 976 |  | $ | — |  | $ | — |  | $ | 6,194 |  | $ | 5,473 |  | $ | 8,398 |  |
| Other receivable (1) | $ | 1,927 |  | $ | 2,841 |  | $ | 4,816 |  |  | $ | 10,012 |  | $ | 24,891 |  | $ | 19,596 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | 11,939 |  | $ | 27,732 |  | $ | 24,412 |  |
| Accounts payable | $ | 98,629 |  | $ | 35,711 |  | $ | 42,463 |  |  | $ | 66,436 |  | $ | 53,423 |  | $ | 44,892 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 230 |  | $ | — |  | $ | — |  | $ | 165,295 |  | $ | 89,134 |  | $ | 87,355 |  |
| Accrued liabilities (2) | $ | — |  | $ | 1,230 |  | $ | 3,531 |  |  | $ | 170 |  | $ | 12,787 |  | $ | 15,145 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | 170 |  | $ | 14,017 |  | $ | 18,676 |  |

[0001375365-25-000004:notes:285]
(1)Other receivables include receivables from vendors included in prepaid and other current assets.

[0001375365-25-000004:notes:286]
(2)Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-25-000004:notes:287]
The Company's results from transactions with its related parties for each of the fiscal years ended June 30, 2024, 2023 and 2022, are as follows (in thousands):

[0001375365-25-000004:notes:288]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | Leadtek | MPS(1) | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, | Year Ended June 30, | Years Ended June 30, |
|  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 |  |  | 2023 | 2022 | 2022 | 2024 | 2023 | 2022 |
| Net sales | $ | 11 |  | $ | 8 |  | $ | 15 |  |  | $ | 46,618 |  | $ | 36,286 |  | $ | 26,085 |  |  | $ | 21,806 |  | $ | 24,243 |  | $ | 120,991 |  |  | $ | 1,356 |  |  |  | $ | — |  | $ | — |  | $ | — |  | $ | 69,791 |  | $ | 60,537 |  | $ | 147,091 |  |
| Purchases - inventory | $ | 269,256 |  | $ | 167,801 |  | $ | 192,441 |  |  | $ | 280,801 |  | $ | 216,961 |  | $ | 170,300 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 2,079 |  |  |  | $ | — |  | $ | — |  | $ | 8,335 |  | $ | 552,136 |  | $ | 384,762 |  | $ | 371,076 |  |
| Purchases - other miscellaneous items | $ | 16,503 |  | $ | 12,131 |  | $ | 8,265 |  |  | $ | 1,540 |  | $ | 2,011 |  | $ | 1,455 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  |  |  | $ | — |  | $ | — |  | $ | — |  | $ | 18,043 |  | $ | 14,142 |  | $ | 9,720 |  |

[0001375365-25-000004:notes:289]
(1) The Company procures certain semiconductor products from MPS, a fabless manufacturer of high-performance analog and mixed-signal semiconductors, through its contract manufacturers for use in its products. A former member of the Board of Directors who served until May 18, 2022 also serves as an officer of MPS. As a result, MPS ceased being a related party in the quarter ended September 30, 2022.

[0001375365-25-000004:notes:290]
The Company’s cash flow impact from transactions with its related parties for the fiscal years ended June 30, 2024, 2023 and 2022, are as follows (in thousands):

[0001375365-25-000004:notes:291]
|  | Ablecom |  | Compuware |  | Corporate Venture |  | Leadtek | MPS(1) | Total |
|  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |  | Years Ended June 30, |
|  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 |  | 2024 | 2023 | 2022 | 2022 | 2024 | 2023 | 2022 |
| Changes in accounts receivable | $ | 1 |  | $ | — |  | $ | — |  |  | $ | 3,386 |  | $ | (3,124) |  | $ | (206) |  |  | $ | (3,132) |  | $ | 6,049 |  | $ | 486 |  |  | $ | (976) |  | $ | — |  | $ | — |  | $ | — |  | $ | (721) |  | $ | 2,925 |  | $ | 280 |  |
| Changes in other receivable | $ | 914 |  | $ | 1,975 |  | $ | 759 |  |  | $ | 14,879 |  | $ | (5,295) |  | $ | (1,423) |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | 89 |  | $ | 15,793 |  | $ | (3,320) |  | $ | (575) |  |
| Changes in accounts payable | $ | 62,918 |  | $ | (6,752) |  | $ | 4,311 |  |  | $ | 13,013 |  | $ | 8,531 |  | $ | 12,948 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 230 |  | $ | — |  | $ | — |  | $ | — |  | $ | 76,161 |  | $ | 1,779 |  | $ | 17,259 |  |
| Changes in accrued liabilities | $ | (1,230) |  | $ | (2,301) |  | $ | 489 |  |  | $ | (12,617) |  | $ | (2,358) |  | $ | 659 |  |  | $ | — |  | $ | — |  | $ | (1,000) |  |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (13,847) |  | $ | (4,659) |  | $ | 148 |  |
| Changes in other long-term liabilities | $ | — |  | $ | — |  | $ | — |  |  | $ | (178) |  | $ | (321) |  | $ | 499 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | (178) |  | $ | (321) |  | $ | 499 |  |
| Purchases of property, plant and equipment | $ | 10,428 |  | $ | 7,498 |  | $ | 4,678 |  |  | $ | 197 |  | $ | 346 |  | $ | 140 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 10,625 |  | $ | 7,844 |  | $ | 4,818 |  |
| Unpaid property, plant and equipment | $ | 2,339 |  | $ | 777 |  | $ | 583 |  |  | $ | — |  | $ | 33 |  | $ | 106 |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,339 |  | $ | 810 |  | $ | 689 |  |

[0001375365-25-000004:notes:292]
(1)The Company procures certain semiconductor products from MPS, a fabless manufacturer of high-performance analog and mixed-signal semiconductors, through its contract manufacturers for use in its products. A former member of the Board of Directors who served until May 18, 2022 also serves as an officer of MPS. As a result, MPS ceased being a related party in the quarter ended September 30, 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-25-000004:notes:293]
Stock-based Compensation and Stockholders’ Equity
Preferred Stock

[0001375365-25-000004:notes:294]
The Company has 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by the Company’s Board of Directors at the time of issuance of such shares. As of June 30, 2024 and 2023, there were no shares of preferred stock issued and outstanding.

[0001375365-25-000004:notes:295]
Common Stock

[0001375365-25-000004:notes:296]
The Company may issue up to 1,000,000,000 shares of common stock, $0.001 par value per share. The holders of our Company's common stock are entitled to one vote for each share held of record on all matters submitted to a vote of stockholders.

[0001375365-25-000004:notes:297]
Equity Incentive Plan

[0001375365-25-000004:notes:298]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 50,000,000 plus 10,450,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 72,460,000 shares of common stock remained reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 20,000,000 shares.

[0001375365-25-000004:notes:299]
On January 22, 2024, the stockholders of the Company approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 15,000,000 shares.

[0001375365-25-000004:notes:300]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-25-000004:notes:301]
As of June 30, 2024, the Company had 12,669,100 authorized shares available for future issuance under the 2020 Plan.

[0001375365-25-000004:notes:302]
Offerings of Common Stock

[0001375365-25-000004:notes:303]
On December 5, 2023, the Company completed a public offering of 24,158,050 shares of the Company's common stock at $26.20 per share, with 23,151,050 shares sold by the Company and 1,007,000 shares sold by selling stockholders.

[0001375365-25-000004:notes:304]
The Company received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Company did not receive any proceeds from the sale of the shares of common stock by the selling stockholders.

[0001375365-25-000004:notes:305]
On March 22, 2024, the Company completed a public offering of 20,000,000 shares of the Company's common stock at $87.50 per share. The Company received net proceeds of $1,731.5 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.

[0001375365-25-000004:notes:306]
Common Stock Repurchase and Retirement

[0001375365-25-000004:notes:307]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of the Company's Board approved a new share repurchase program to repurchase shares of the Company’s common stock for up to $200 million at prevailing prices in the open market. The share repurchase program was effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurred first. Under the common stock repurchase program, shares may be purchased from time to time in open market transactions, block trades, through plans established under the Securities Exchange Act Rule 10b5-1, or otherwise. The number of shares purchased and the timing of such purchases are based on working capital requirements, market and general business conditions, and other factors, including alternative investment opportunities.

[0001375365-25-000004:notes:308]
No shares were repurchased under the share repurchase program during the fiscal year ended June 30, 2024. The share repurchase program was effective until January 31, 2024, at which time the remaining unutilized portion of such program expired.

[0001375365-25-000004:notes:309]
Determining Fair Value

[0001375365-25-000004:notes:310]
The fair value of the Company's RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-25-000004:notes:311]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience.

[0001375365-25-000004:notes:312]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-25-000004:notes:313]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-25-000004:notes:314]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-25-000004:notes:315]
The fair value of stock option grants for the fiscal years ended June 30, 2024, 2023 and 2022 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-25-000004:notes:316]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Risk-free interest rate | 4.01% - 4.78% |  | 2.81% - 4.25% |  | 0.81% - 3.02% |
| Expected term | 3.00 years - 5.99 years |  | 6.07 years |  | 6.09 years |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 56.87% - 64.55% |  | 50.62% - 53.47% |  | 49.69% - 50.13% |
| Weighted-average fair value of options | $ | 28.58 |  |  | $ | 6.21 |  |  | $ | 2.03 |  |

[0001375365-25-000004:notes:317]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands):

[0001375365-25-000004:notes:318]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Cost of sales | $ | 15,864 |  |  | $ | 4,574 |  |  | $ | 1,876 |  |
| Research and development | 114,895 |  |  | 30,736 |  |  | 16,571 |  |
| Sales and marketing | 21,195 |  |  | 4,599 |  |  | 2,058 |  |
| General and administrative | 79,553 |  |  | 14,524 |  |  | 12,311 |  |
| Stock-based compensation expense before taxes | 231,507 |  |  | 54,433 |  |  | 32,816 |  |
| Income tax impact | (92,810) |  |  | (18,106) |  |  | (12,220) |  |
| Stock-based compensation expense, net | $ | 138,697 |  |  | $ | 36,327 |  |  | $ | 20,596 |  |

[0001375365-25-000004:notes:319]
As of June 30, 2024, $165.7 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.21 years and $460.2 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.70 years. Additionally, as described below, $18.9 million of unrecognized compensation cost related to the 2023 CEO Performance Stock Option is expected to be recognized over a period of 2.5 years.

[0001375365-25-000004:notes:320]
Stock Option Activity

[0001375365-25-000004:notes:321]
2021 CEO Performance Award

[0001375365-25-000004:notes:322]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 10,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). As of June 30, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000004:notes:323]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |
| $4.0 |  | Achieved |  | $4.50 |  | Achieved (1) |
| $4.8 |  | Achieved |  | $6.00 |  | Achieved (2) |
| $5.8 |  | Achieved |  | $7.50 |  | Achieved (3) |
| $6.8 |  | Achieved |  | $9.50 |  | Achieved (4) |
| $8.0 |  | Achieved |  | $12.00 |  | Achieved (5) |

[0001375365-25-000004:notes:324]
(1)The vesting of the first tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option, representing one-fifth of such award, was certified by the Company’s Compensation Committee in August 2022.

[0001375365-25-000004:notes:325]
(2)The vesting of the second tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in October 2022.

[0001375365-25-000004:notes:326]
(3)The vesting of the third tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in January 2023.

[0001375365-25-000004:notes:327]
(4)The vesting of the fourth tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in September 2023.

[0001375365-25-000004:notes:328]
(5)The vesting of the fifth tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in February 2024.

[0001375365-25-000004:notes:329]
During the fiscal year ended June 30, 2024, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.7 million. As of June 30, 2024 and 2023, the Company had $0.0 million and $0.7 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-25-000004:notes:330]
2023 CEO Performance Award

[0001375365-25-000004:notes:331]
In November 2023, the Compensation Committee approved the grant of a stock option award for 5,000,000 shares of common stock to the Company’s CEO (the “2023 CEO Performance Stock Option”). The 2023 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2023 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $110.00 per share thereafter (based on a 60 trading day average stock price), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to November 14, 2026, the Company’s CEO must hold shares that he acquires until November 14, 2026, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-25-000004:notes:332]
The achievement status of the operational and stock price milestones as of June 30, 2024 was as follows:

[0001375365-25-000004:notes:333]
| Annualized Revenue Milestone (in billions)(1) |  | Achievement Status |  | Stock Price Milestone(1) |  | Achievement Status |
| $13.0 |  | Probable |  | $45 |  | Achieved (2) |
| $15.0 |  | Probable |  | $60 |  | Achieved (3) |
| $17.0 |  | Probable |  | $75 |  | Achieved (4) |
| $19.0 |  | Probable |  | $90 |  | Achieved (5) |
| $21.0 |  | Probable |  | $110 |  | Not yet achieved |

[0001375365-25-000004:notes:334]
(1)Under the terms of the 2023 CEO Performance Stock Option, the annualized revenue milestones and stock price milestones set forth in the table above must be achieved by December 31, 2028 and March 31, 2029, respectively.

[0001375365-25-000004:notes:335]
(2)On March 2, 2024, the Compensation Committee certified achievement of the $45 stock price milestone based upon the 60 trading day average stock price from November 29, 2023 through February 26, 2024.

[0001375365-25-000004:notes:336]
(3)On April 1, 2024, the Compensation Committee certified achievement of the $60 stock price milestone based upon the 60 trading day average stock price from December 15, 2023 through March 13, 2024.

[0001375365-25-000004:notes:337]
(4)On April 1, 2024, the Compensation Committee certified achievement of the $75 stock price milestone based upon the 60 trading day average stock price from January 4, 2024 through April 1, 2024.

[0001375365-25-000004:notes:338]
(5)On May 5, 2024, the Compensation Committee certified achievement of the $90 stock price milestone based upon the 60 trading day average stock price from January 31, 2024 through April 25, 2024.

[0001375365-25-000004:notes:339]
During the fiscal year ended June 30, 2024, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $49.1 million. As of June 30, 2024, the Company had $18.9 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of June 30, 2024 is expected to be recognized over a period of 2.5 years.

[0001375365-25-000004:notes:340]
On the respective grant dates of each of the 2021 CEO Performance Award and the 2023 CEO Performance Award, a Monte Carlo simulation was used to determine for each tranche of each award (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine, using a Monte Carlo simulation, whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the respective grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-25-000004:notes:341]
The following table summarizes stock option activity during the fiscal year ended June 30, 2024 under all plans:

[0001375365-25-000004:notes:342]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2023 |  | 33,025,330 |  |  | $ | 4.05 |  |  |  |  |  |  |  |
| Granted |  | 11,322,940 |  |  | $ | 46.13 |  |  | $ | 21.30 |  |  |  |  |  |
| Exercised |  | (8,725,220) |  |  | $ | 3.40 |  |  |  |  |  |  |  |
| Forfeited/Cancelled |  | (179,500) |  |  | $ | 21.56 |  |  |  |  |  |  |  |
| Balance as of June 30, 2024 |  | 35,443,550 |  |  | $ | 17.57 |  |  |  |  | 6.98 |  | $ | 2,281,435 |  |
| Options vested and expected to vest as of June 30, 2024 |  | 35,443,550 |  |  | $ | 17.57 |  |  |  |  |  |  |  |
| Options exercisable as of June 30, 2024 |  | 19,456,290 |  |  | $ | 4.39 |  |  |  |  | 5.51 |  | $ | 1,508,661 |  |

[0001375365-25-000004:notes:343]
For the fiscal year ended June 30, 2024, the tax benefit from options exercised was $77.9 million. The total pretax intrinsic value of options exercised during the fiscal year ended June 30, 2024, 2023 and 2022 was $475.0 million, $110.1 million and $29.6 million, respectively. Additional information regarding options outstanding as of June 30, 2024, is as follows:

[0001375365-25-000004:notes:344]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $1.30 - $2.70 |  | 4,523,280 |  |  | 3.58 |  | $ | 2.35 |  |  | 4,415,740 |  |  | $ | 2.35 |  |
| $2.85 - $3.85 |  | 4,116,660 |  |  | 4.13 |  | $ | 3.53 |  |  | 3,184,880 |  |  | $ | 3.48 |  |
| $3.92 - $4.24 |  | 1,637,240 |  |  | 7.56 |  | $ | 4.07 |  |  | 667,810 |  |  | $ | 4.06 |  |
| $4.50 - $4.50 |  | 10,000,000 |  |  | 6.67 |  | $ | 4.50 |  |  | 10,000,000 |  |  | $ | 4.50 |  |
| $5.22 - $9.33 |  | 3,942,070 |  |  | 7.93 |  | $ | 7.41 |  |  | 874,370 |  |  | $ | 7.09 |  |
| $13.72 - $33.76 |  | 3,369,540 |  |  | 8.85 |  | $ | 30.68 |  |  | 294,740 |  |  | $ | 29.86 |  |
| $45.00 - $45.00 |  | 5,000,000 |  |  | 9.38 |  | $ | 45.00 |  |  | — |  |  | $ | — |  |
| $45.74 - $69.80 |  | 1,087,630 |  |  | 9.57 |  | $ | 49.07 |  |  | 18,750 |  |  | $ | 69.80 |  |
| $76.19 - $76.19 |  | 1,650,370 |  |  | 9.33 |  | $ | 76.19 |  |  | — |  |  | $ | — |  |
| $78.27 - $78.27 |  | 116,760 |  |  | 9.84 |  | $ | 78.27 |  |  | — |  |  | $ | — |  |
| $1.30 - $78.27 |  | 35,443,550 |  |  | 6.98 |  | $ | 17.57 |  |  | 19,456,290 |  |  | $ | 4.39 |  |

[0001375365-25-000004:notes:345]
RSU and PRSU Activity

[0001375365-25-000004:notes:346]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vested in two tranches and included service and performance conditions. Each tranche had 150,000 RSUs that vested in May 2021 and November 2021 based on service conditions only. Additional units could have been earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would also have vested in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units were also to vest in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019. An additional 29,390 units were earned for fiscal year 2021 that vested on November 10, 2021.

[0001375365-25-000004:notes:347]
The following table summarizes RSUs and PRSUs activity during the fiscal year ended June 30, 2024 under all plans:

[0001375365-25-000004:notes:348]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2023 |  | 20,429,860 |  |  | $ | 5.59 |  |  |  |  |  |  |
| Granted |  | 12,079,880 |  |  | $ | 43.33 |  |  |  |  |  |  |
| Released |  | (10,340,470) |  |  | $ | 10.17 |  |  |  |  |  |  |
| Forfeited |  | (896,280) |  |  | $ | 19.89 |  |  |  |  |  |  |
| Balance as of June 30, 2024 |  | 21,272,990 |  |  | $ | 24.19 |  |  |  |  |  |  |

[0001375365-25-000004:notes:349]
Total fair value of RSU vested as of the respective vesting dates for the fiscal years ended June 30, 2024, 2023 and 2022 was approximately $105.2 million, $37.6 million, and $18.8 million, respectively. There are no PRSUs outstanding or activities as of and for the year ended June 30, 2024.

[0001375365-25-000004:notes:350]
The total pretax intrinsic value of RSUs and PRSUs vested was $563.0 million, $95.0 million and $33.1 million for the fiscal years ended June 30, 2024, 2023 and 2022, respectively. In fiscal years 2024, 2023 and 2022, the Company withheld 3,142,910, 3,047,520 and 2,324,610 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes from the vesting and release of 10,340,470, 9,936,350 and 7,636,410 RSUs and PRSUs, respectively, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to tax authorities were $174.4 million, $28.2 million and $10.1 million for the fiscal years ended June 30, 2024, 2023 and 2022, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2020 Plan, shares withheld in connection with net-share settlements are not added back to the 2020 Plan.


## smci:SummaryOfOperationalAndStockPriceMilestonesTableTextBlock

[0001375365-25-000004:notes:351]
As of June 30, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-25-000004:notes:352]
Income Taxes
The components of income before income tax provision for the fiscal years ended June 30, 2024, 2023 and 2022 are as follows (in thousands):

[0001375365-25-000004:notes:353]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 1,110,906 |  |  | $ | 632,237 |  |  | $ | 250,513 |  |
| Foreign | 103,233 |  |  | 122,060 |  |  | 86,320 |  |
| Income before income tax provision | $ | 1,214,139 |  |  | $ | 754,297 |  |  | $ | 336,833 |  |

[0001375365-25-000004:notes:354]
The income tax provision for the fiscal years ended June 30, 2024, 2023 and 2022, consists of the following (in thousands):

[0001375365-25-000004:notes:355]
|  | Years Ended June 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | 173,838 |  |  | $ | 149,217 |  |  | $ | 34,711 |  |
| State | 20,969 |  |  | 23,096 |  |  | 4,327 |  |
| Foreign | 36,986 |  |  | 31,063 |  |  | 20,495 |  |
|  | 231,793 |  |  | 203,376 |  |  | 59,533 |  |
| Deferred: |  |  |  |  |  |
| Federal | (162,286) |  |  | (80,975) |  |  | (4,030) |  |
| State | (5,405) |  |  | (9,633) |  |  | (257) |  |
| Foreign | (808) |  |  | (2,102) |  |  | (2,370) |  |
|  | (168,499) |  |  | (92,710) |  |  | (6,657) |  |
| Income tax provision | $ | 63,294 |  |  | $ | 110,666 |  |  | $ | 52,876 |  |

[0001375365-25-000004:notes:356]
The Company’s net deferred tax assets as of June 30, 2024 and 2023 consist of the following (in thousands):

[0001375365-25-000004:notes:357]
|  | June 30, |
|  | 2024 |  | 2023 |
| Capitalized research and development costs | $ | 240,489 |  |  | $ | 94,050 |  |
| Research and development credits | 56,707 |  |  | 34,722 |  |
| Deferred revenue | 35,815 |  |  | 32,376 |  |
| Convertible Notes | 31,819 |  | — |  |
| Inventory valuation | 33,255 |  |  | 23,022 |  |
| Stock-based compensation | 16,389 |  |  | 4,589 |  |
| Lease obligations | 7,274 |  |  | 3,162 |  |
| Warranty accrual | 3,737 |  |  | 3,038 |  |
| Accrued vacation and bonus | 3,668 |  |  | 5,310 |  |
| Bad debt and other reserves | 2,597 |  | 910 |
| Marketing fund accrual | 2,102 |  |  | 1,436 |  |
| Other | 4,910 |  |  | 5,978 |  |
| Total gross deferred income tax assets | 438,762 |  |  | 208,593 |  |
| Less valuation allowance | (59,841) |  |  | (36,679) |  |
| Total deferred tax assets | 378,921 |  |  | 171,914 |  |
| Right of use asset | (7,005) |  |  | (3,044) |  |
| Depreciation and amortization | (6,744) |  |  | (6,216) |  |
| Total deferred tax liabilities | (13,749) |  |  | (9,260) |  |
| Deferred income tax assets, net | $ | 365,172 |  |  | $ | 162,654 |  |

[0001375365-25-000004:notes:358]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2024, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of state research and development tax credits and unrealized capital losses that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2024, the gross excess credits of $71.8 million, or net of federal tax benefit of $56.7 million, were subject to a full valuation allowance. At June 30, 2023, the gross excess credits of $43.9 million, or net of federal tax benefit of $34.7 million, were subject to a full valuation allowance. The change in valuation allowance is $23.2 million and $3.0 million for the fiscal years ended June 30, 2024 and 2023, respectively. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2024 and 2023 was $365.2 million and $162.7 million, respectively.

[0001375365-25-000004:notes:359]
Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to Global Intangible Low-Taxed Income ("GILTI") as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into the measurement of its deferred taxes. The Company's selection of an accounting policy with respect to the GILTI tax rules is to treat GILTI tax as a current period expense under the period cost method.

[0001375365-25-000004:notes:360]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from its foreign subsidiaries. The Company previously asserted that all its foreign undistributed earnings were indefinitely reinvested. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for Netherlands. The Company may repatriate foreign earnings from Netherlands which are previously taxed income as a result of the 2017 Tax Reform Act. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-25-000004:notes:361]
The following is a reconciliation for the fiscal years ended June 30, 2024, 2023 and 2022, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-25-000004:notes:362]
|  |  | Years Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Income tax provision at statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax, net of federal tax benefit |  | 1.0 |  |  | 1.1 |  |  | 0.9 |  |
| Foreign rate differential |  | 0.2 |  |  | 0.8 |  |  | (0.3) |  |
| Research and development tax credit |  | (6.0) |  |  | (3.3) |  |  | (3.9) |  |
| Uncertain tax positions, net of (settlement) with Tax Authorities |  | 1.1 |  |  | 0.1 |  |  | 0.3 |  |
| Foreign derived intangible / Subpart F income inclusion |  | (2.2) |  |  | (1.9) |  |  | (1.4) |  |
| Stock-based compensation |  | (11.8) |  |  | (3.4) |  |  | (1.5) |  |
| Provision to return true-up |  | (0.1) |  |  | (0.1) |  |  | 0.1 |  |
| Officer Comp IRC section 162(m) limitation |  | 1.8 |  |  | 0.2 |  |  | 0.4 |  |
| Other, net |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |
| Effective tax rate |  | 5.2 | % |  | 14.7 | % |  | 15.7 | % |

[0001375365-25-000004:notes:363]
As of June 30, 2024, the Company had state research and development tax credit carryforwards of $95.9 million. The state research and development tax credits will carry forward indefinitely to offset future state income taxes.

[0001375365-25-000004:notes:364]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-25-000004:notes:365]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2021 | $ | 40,735 |  |
| Gross increases: |  |
| For current year’s tax positions | 2,392 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (4,090) |  |
| Decreases due to lapse of statute of limitations | (1,036) |  |
| Balance at June 30, 2022 | 38,001 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,632 |  |
| For prior years’ tax positions | 1,616 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (2,077) |  |
| Decreases due to lapse of statute of limitations | (1,429) |  |
| Balance at June 30, 2023 | 42,743 |  |
| Gross increases: |  |
| For current year’s tax positions | 19,577 |  |
| For prior years’ tax positions | 3,076 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (8,981) |  |
| Decreases due to lapse of statute of limitations | (2,974) |  |
| Balance at June 30, 2024 | $ | 53,441 |  |

[0001375365-25-000004:notes:366]
*Excludes interest, penalties, federal benefit of state reserves

[0001375365-25-000004:notes:367]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $28.6 million and $25.4 million as of June 30, 2024 and 2023, respectively.

[0001375365-25-000004:notes:368]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the income tax provision in the consolidated statements of operations. As of June 30, 2024 and 2023, the Company had accrued $4.4 million and $3.5 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively.

[0001375365-25-000004:notes:369]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-25-000004:notes:370]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. The federal statute of limitations remains open in general for tax years ended June 30, 2021 and after. Various states statute of limitations remains open in general for tax years ended June 30, 2020 and after. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2019 and after. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $3.2 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-25-000004:notes:371]
Commitments and Contingencies
Litigation and claims

[0001375365-25-000004:notes:372]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. On October 28, 2024, the Spatz plaintiff voluntarily dismissed the Spatz complaint without prejudice against all Defendants, ending the suit. On November 21, 2024, the Averza Court entered a Stipulation and Order extending Defendants’ time to respond to the Averza complaint until after the Court appoints a lead plaintiff, which hearing is set for March 6, 2025. A similar stipulation was entered among the parties as to the Covey Financial complaint. On January 9, 2025, the Menditto plaintiff voluntarily dismissed the Menditto complaint without prejudice against all Defendants, ending the suit. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000004:notes:373]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On November 5, 2024, the Court in the Hollin Action entered a Stipulation and Order staying all proceedings in Hollin and any related federal derivative actions, which includes the Federal Derivative Litigation. The Court in the State Court Derivative Litigation stayed all proceedings until case management conferences were held in each suit, with the first conference scheduled for April 24, 2025 in Spatz. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000004:notes:374]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. A case management judge was assigned in December 2024, but no case conference has been scheduled and no timetable for subsequent procedural steps has been set. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000004:notes:375]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication in a short seller report which was published in August 2024. The Company is cooperating with these document requests and no charges have been brought as of the date of this filing.

[0001375365-25-000004:notes:376]
Other legal proceedings and indemnifications

[0001375365-25-000004:notes:377]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of June 30, 2024, and any prior periods.

[0001375365-25-000004:notes:378]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors' and officers' liability insurance coverage to reduce its exposure to such obligations.

[0001375365-25-000004:notes:379]
Purchase Commitments - The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2024, these remaining non-cancelable commitments were $6.2 billion, including $152.3 million to related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were approximately $26.4 million of loss liabilities recognized in Accrued liabilities in the consolidated balance sheets from purchase commitments as of June 30, 2024. As of June 30, 2023, there were no material loss liabilities recorded in the consolidated balance sheets from purchase commitments.

[0001375365-25-000004:notes:380]
Lease Commitments - See Note 9, "Leases" in the Notes to the Consolidated Financial Statements for a discussion of the Company's operating lease commitments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-25-000004:notes:381]
Retirement Plans
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2024, 2023 and 2022.

[0001375365-25-000004:notes:382]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. The Company is required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by the Company. For the fiscal years ended June 30, 2024, 2023 and 2022, the Company’s matching contribution was $1.1 million, $0.9 million, and $0.8 million, respectively.

[0001375365-25-000004:notes:383]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2024, 2023 and 2022, the Company’s contribution was $4.1 million, $3.6 million and $3.4 million, respectively.

[0001375365-25-000004:notes:384]
The Company has a defined benefit pension plan under the Taiwan Labor Standards Law for certain employees of Super Micro Computer, Inc. Taiwan that provides benefits based on an employee’s length of service and average monthly salary for the six-month period prior to retirement. The Company contributes an amount equal to 2% of salaries paid each month to the pension fund (the “Fund”), which is administered by the Labor Pension Fund Supervisory Committee (the “Committee”) and deposited in the Committee’s name in the Bank of Taiwan. Before the end of each year, the Company assesses the balance in the Fund. If the amount of the balance in the Fund is inadequate to pay retirement benefits for eligible employees in the next year, the Company is required to fund the difference in one appropriation that should be made before the end of March 31 of the next year. The Fund is operated and managed by the government’s designated authorities. As such, the Company does not have any right to intervene in the investments of the Fund. For the fiscal years ended June 30, 2024, 2023 and 2022, the Company recorded a pension expense of $(0.1) million, $(0.1) million and $0.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-25-000004:notes:385]
Segment Reporting
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-25-000004:notes:386]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-25-000004:notes:387]
|  | June 30, |  |  |
|  | 2024 |  | 2023 |  |  |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 281,874 |  |  | $ | 183,485 |  |  |  |
| Taiwan | 107,878 |  |  | 101,912 |  |  |  |
| Other countries | 24,256 |  |  | 4,843 |  |  |  |
|  | $ | 414,008 |  |  | $ | 290,240 |  |  |  |

[0001375365-25-000004:notes:388]
The table above excludes other assets, goodwill and intangible assets. Operating lease assets in the United States were $29.3 million as of June 30, 2024. Operating lease assets in the United States and the Netherlands were $12.4 million and $3.0 million as of June 30, 2023, respectively. Operating lease assets in all other countries were less than 10% as of June 30, 2024 and 2023.

[0001375365-25-000004:notes:389]
For fiscal year 2024, 2023 and 2022, 68.0%, 67.9% and 58.4% of the Company’s revenues were from the United States. Other countries were individually less than 10%. The Company’s revenue by geographic region is based on where the products were shipped to for fiscal years ended 2024, 2023 and 2022.


## us-gaap:SubsequentEventsTextBlock

[0001375365-25-000004:notes:390]
Subsequent Events 
Indebtedness

[0001375365-25-000004:notes:391]
Bank of America Bridge Term Loan Facility

[0001375365-25-000004:notes:392]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders party thereto (the “Lenders”), and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend

[0001375365-25-000004:notes:393]
the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder. On November 1, 2024, the Company prepaid in full and terminated its obligations under the Bridge Term Loan Facility.

[0001375365-25-000004:notes:394]
On July 19, 2024, the Company entered into an Eighth Amendment to Loan and Security Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as administrative agent for the lenders (the “ABL Agent”), which amended the 2018 Bank of America Credit Facility to, among other things, allow for the Company’s entry into and borrowing under the Bridge Term Loan Facility. On September 27, 2024, the Company entered into a Ninth Amendment to Loan and Security Agreement, by and among the Company, the lenders party thereto, and the ABL Agent, which amended the 2018 Bank of America Credit Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the 2018 Bank of America Credit Facility from September 28, 2024 to November 27, 2024 and added a $70 million availability block to the U.S. borrowing base thereunder. On November 20, 2024, the Company prepaid in full and terminated its obligations under the 2018 Bank of America Credit Facility.

[0001375365-25-000004:notes:395]
On November 20, 2024, the Company, through its Taiwan subsidiary, terminated its obligations under the 2022 Bank of America Credit Facility with respect to the credit lines with Bank of America – Taipei Branch.

[0001375365-25-000004:notes:396]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ending September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sublimit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

[0001375365-25-000004:notes:397]
On November 14, 2024, the Company’s Taiwan subsidiary (the “Subsidiary”) entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements issued by the Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

[0001375365-25-000004:notes:398]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Company, through its Taiwan subsidiary, had entered into with the Taiwan affiliate of HSBC Bank (the “Loan Agreement”) was terminated and not renewed. The balance under this $50 million Loan Agreement had been fully repaid on September 9, 2024, and had remained undrawn since such date.

[0001375365-25-000004:notes:399]
Amendment of 2029 Convertible Notes and associated capped calls

[0001375365-25-000004:notes:400]
On February 20, 2025, the Company amended the terms of the 2029 Convertible Notes pursuant to a first supplemental indenture and a second supplemental indenture, in each case by and between the Company and U.S. Bank Trust Company, National Association as trustee. The terms of the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated initial conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes (equivalent to an initial conversion price of approximately $83.44 per share of the Company’s common stock). The conversion rate and conversion price will be subject to adjustment upon the occurrence of certain events. The remaining terms of the 2029 Convertible Notes remain substantially unchanged.

[0001375365-25-000004:notes:401]
In connection with the amendment of the terms of the 2029 Convertible Notes, the Company amended the capped call transactions entered into in connection with the initial issuance of the 2029 Convertible Notes in February 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the cap price. The cap price, after giving effect to the amendments, is initially $94.1666 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls.

[0001375365-25-000004:notes:402]
Issuance of 2028 Convertible Notes

[0001375365-25-000004:notes:403]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture, dated as of February 20, 2025 by and between the Company and U.S. Bank Trust Company, National Association, as trustee for gross proceeds of $700 million and approximately $50 million of issuance cost. The 2028 Convertible Notes were sold to investors pursuant to privately negotiated agreements. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier redeemed, repurchased or converted. The 2028 Convertible Notes have an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of the 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock, in each case subject to adjustment upon the occurrence of certain events. Prior to January 15, 2028, the 2028 Convertible Notes will be convertible only upon the satisfaction of certain conditions and during certain periods, and on and after January 15, 2028, at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date, the 2028 Convertible Notes will be convertible regardless of these conditions. The Company will settle conversions of the 2028 Convertible Notes by paying or delivering cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock at the Company’s election.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001375365-25-000004:notes:404]
Certain of the Company’s executive officers and directors have entered into trading plans pursuant to Rule 10b5-1(c) of the Securities Exchange Act of 1934, as amended. The following table summarizes the adoption of trading plans intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) during the three months ended June 30, 2024:

[0001375365-25-000004:notes:405]
| Name and Title | Adoption Date | End Date | Aggregate Number of Shares of the Company’s Common Stock to be Sold |
| Charles Liang, executive officer and director | May 22, 2024 | September 30, 2024 | 300,000 |
| Daniel Fairfax, non-employee director | May 21, 2024 | December 31, 2024 | 15,000 |


## ecd:AwardTmgMnpiDiscTextBlock

[0001375365-25-000004:notes:406]
Policies and Practices Regarding the Grant of Equity Awards

[0001375365-25-000004:notes:407]
Under our policies and practices, the approval of stock options and other equity-based awards (including any stock option grants to our NEOs and directors) is typically provided at a Compensation Committee meeting or via unanimous written consent on the part of the Compensation Committee.  While the Compensation Committee does not have predetermined fixed dates upon which grants must be made, generally, the Compensation Committee has held regular quarterly meetings (which are typically held after the completion of a fiscal quarter and shortly (usually approximately one week) before the announcement by the Company of its results for the just completed fiscal quarter (each, a “Regular Quarterly Meeting”)), and at such meeting the Committee considers the approval of stock options and other equity-based awards, including relevant terms (such as the proposed grant date).  In addition to Regular Quarterly Meetings, the Compensation Committee, generally, may consider from time to time, on an as-needed basis, grants of stock options and other equity-based awards in between Regular Quarterly Meetings at special meetings or via unanimous written consent (together, “Special Meetings”).

[0001375365-25-000004:notes:408]
Awards of stock options and other equity-based awards are typically made by the Company in the following circumstances:

[0001375365-25-000004:notes:409]
1.Biennial awards: Generally, eligible employees (including our NEOs) receive equity-based awards (which may include stock options) in connection with their commencement of service with the Company or a change in their status occurs for them to become eligible for equity-based awards.  Such awards are generally submitted to the Compensation Committee for approval at the first Regular Quarterly Meeting after the commencement of service by such employee or the change in such employee’s status occurs. Thereafter, such employee would, depending upon factors such as performance, generally be eligible to receive a refresh equity-based award (which may include stock options) at the biennial Regular Quarterly Meeting following the date the first award was made to such eligible employee (all such awards, “Biennial Awards”);

[0001375365-25-000004:notes:410]
2.Scheduled Awards: The Compensation Committee also considers various scheduled awards which generally occur on a regular recurring basis (together, “Scheduled Awards”).  Examples of such Scheduled Awards include:

[0001375365-25-000004:notes:411]
a.The grant of the equity component of director compensation in connection with annual director service (the “Annual Director Service Award”) or lead independent director service (the “Lead Independent Director Service Award”). Such awards may include the grant of stock options depending upon the election made by such director at a time when the Trading Window (as defined below) was open. See “Director Compensation” for additional discussion with respect to such equity awards for director service.

[0001375365-25-000004:notes:412]
Annual Director Service Awards will (going forward) generally be considered by the Compensation Committee for approval at the first Regular Quarterly Meeting after the commencement of a new fiscal year.

[0001375365-25-000004:notes:413]
Lead Independent Director Service Awards are generally submitted to the Compensation Committee for approval at the first Regular Quarterly Meeting following the appointment of a lead independent director for their one-year term of office.

[0001375365-25-000004:notes:414]
b.The grant of equity awards earned under the performance program for a NEO (which, to date, has not included stock options) (“Performance Award Grants”). Such awards generally have terms that were pre-approved by the Compensation Committee at the time the performance program for the named executive officer was adopted by the Compensation Committee earlier in such fiscal year, including specified deadline dates prior to which such Performance Awards Grants are to be made and after which the results used to determine performance (some of which may depend upon financial results that are published in the Annual

[0001375365-25-000004:notes:415]
Report) are calculated. Generally, the grant date of Performance Award Grants has been at a time when the Trading Window is open.

[0001375365-25-000004:notes:416]
3. Special Awards: From time to time, the Compensation Committee will consider, on an as-needed basis, grants of equity based-awards (which may include stock options). Circumstances for such awards may include, as an example, special recognition bonuses or for the hiring or retention of a high-value employee (who may or may not be an NEO). Such awards and the terms thereof (“Special Awards”) are generally submitted at Special Meetings but may also occur at Regular Quarterly Meetings.

[0001375365-25-000004:notes:417]
The Company has an Insider Trading Policy which provides for a trading window (the “Trading Window”).  Pursuant to the Insider Trading Policy, the Trading Window generally (i) opens following the closing of trading on the second full trading day following the public issuance of the Company’s earnings release for the most recent fiscal quarter and (ii) closes at the close of trading on the last day of the month preceding the last month of a fiscal quarter (i.e., the last day of August, November, February and May). Our Insider Trading Policy prohibits any of our directors, executive officers, employees or contractors from engaging in any transactions in publicly traded options, such as puts and calls, and other derivative securities, including any hedging or similar transaction, with respect to our common stock.

[0001375365-25-000004:notes:418]
The Company has generally tied the grant date of options to NEOs for their Biennial Awards to the first full trading day after the next opening of the Trading Window following the Regular Quarterly Meeting approving such grant.  Other key terms of such awards (such as exercise price) are tied to such grant date.  For example, during fiscal year 2024, each of Mr. Weigand and Mr. Clegg received their Biennial Awards that included both stock options and RSUs as a part of their refresh grants.  See “- Other Equity-Based Incentive Compensation.”  Such awards were approved at the April 23, 2024 Regular Quarterly Meeting and the Company issued its earnings release for the third quarter of fiscal year 2024 on April 30, 2024. The first full trading day after the Trading Window opened was May 3, 2024, the grant date of both the options and RSUs for such Biennial Awards was May 3, 2024, and the exercise price of the stock options associated therewith was the closing stock price on May 3, 2024.  However, for persons who are not NEOs, the grant date of stock options for their Biennial Awards is the date of the Regular Quarterly Meeting approving such grant, and other key terms of such awards (such as the exercise price of any stock options granted) are tied to such grant date.  For example, for persons who are not NEOs and also had Biennial Awards approved at the Regular Quarterly Meeting held on April 23, 2024, the grant date of their stock options and RSUs was April 23, 2024, and the exercise price of the stock options associated therewith was the closing stock price on April 23, 2024.

[0001375365-25-000004:notes:419]
Going forward, the Company generally expects to tie the grant date of stock options (if any) in connection with Annual Director Service Awards and Lead-Independent Director Service Awards to the first full trading day after the next opening of the Trading Window following the Regular Quarterly Meeting approving such grant.  Other key terms of such awards (such as the exercise price of any stock options granted) will be tied to such grant date.  For example, the Compensation Committee considered and approved grants for fiscal year 2025 director service at the Regular Quarterly Meeting held on July 30, 2024 and the Company issued its earnings release for the fourth quarter of fiscal year 2024 on August 6, 2024. Since the first full trading day after the Trading Window opened was August 9, 2024, the grant date of both the stock options and RSUs for Annual Director Service Awards was August 9, 2024, and the exercise price of the stock options associated therewith was the closing stock price on August 9, 2024.  However, for fiscal year 2024, because the new director compensation program was approved by the Board on August 24, 2023, at a time when the Trading Window was open, the Annual Director Service Awards for fiscal year 2024 Board service were both approved by the Compensation Committee and had a grant date of August 24, 2023.  Other key terms of such awards (such as exercise price) were tied to such grant date.

[0001375365-25-000004:notes:420]
Generally, given the structure of Performance Award Grants, Performance Award Grants have been considered, approved, and granted by the Compensation Committee at a time when the Trading Window has been open.

[0001375365-25-000004:notes:421]
The Company generally expects the grant date of options (if any) in connection with Special Awards to be tied to whether the Trading Window is open at the time of the Special Meeting at which such Special Award was considered and approved.  In the event the Trading Window is not open at the time of the Special Meeting, the Company generally expects such Special Award to be granted on the first full trading day after the next opening of the Trading Window following the Special Meeting approving such grant. In the event the Trading Window is open at the time of the Special Meeting, the Company generally expects such Special Award to be granted on the date of the Special Meeting. In either case, other key terms of such awards (such as exercise price) are tied to such grant date.  For example, during fiscal year 2024, Mr. Weigand received a recognition grant as a Special Award that included both stock options and RSUs. See “- Other Equity-Based Incentive Compensation.” Such awards were approved at the Regular Quarterly Meeting held on August 1, 2023, at a time when the Trading Window was closed and the Company issued its earnings release for the fourth quarter of fiscal year 2023 on August 8, 2023. The first full trading day after the Trading Window opened was August 11, 2023, so the grant date of both the stock options and RSUs for such Special Award was August 11, 2023, and the exercise price of the stock options associated therewith was the closing stock price on August 11, 2023.

[0001375365-25-000004:notes:422]
The equity grant approach discussed above is used by the Compensation Committee in order to best help ensure that grants are made only during an open window, and after the release of the Company’s material non-public information regarding its most recently completed fiscal quarter.  This grant timing is used in order to provide for a routine and regular grant practice regarding the NEOs' and directors’ equity awards, but to clearly have such awards granted after the release of such recently completed fiscal quarter information. In this sense, the Compensation Committee is mindful of the existence of material non-public information about the prior fiscal quarter but is neutral with respect to the existence (or lack thereof) of other material non-public information, when making each of the types of awards discussed.  Otherwise, the Compensation Committee does not factor any material non-public information into its design and approval of the terms of such equity awards discussed.  Including for grants made during fiscal year 2024, we do not time the disclosure of material non-public information for purposes of affecting the value of executive compensation or director compensation.

[0001375365-25-000004:notes:423]
During fiscal year 2024, except as provided in the chart below, we did not grant stock options (or similar awards) to any of our NEOs during the period beginning four business days before and ending one business day after the filing of any Company periodic report on Form 10-Q or Form 10-K, or the filing or furnishing of any Company Form 8-K that disclosed any material non-public information:

[0001375365-25-000004:notes:424]
| Name | Grant date | Number of securitiesunderlying the award | Exerciseprice of the award($/Share) | Grant date fair value of the award | Percentage change in the closing market price of the securities underlying the award between the trading day ending immediately prior to the disclosure of material nonpublic information and the trading day beginning immediately following the disclosure of material nonpublicinformation |
| (a) | (b) | (c) | (d) | (e) | (f) |
| Charles Liang | N/A | N/A | N/A | N/A | N/A |
| David Weigand | May 3, 2024 | 62,550 | $78.27 | $48.42 | 4.7% |
| Don Clegg | May 3, 2024 | 54,210 | $78.27 | $48.42 | 4.7% |
| George Kao | N/A | N/A | N/A | N/A | N/A |
