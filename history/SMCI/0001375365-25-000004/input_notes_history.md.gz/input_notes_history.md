# SMCI note change history — 0001375365-25-000005 → 0001375365-25-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:1]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been
  (was, 2025-02-25, similarity 0.6056):
[0001375365-25-000005:note_history:1]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, certain current and former directors and certain current officers of the Company were named as defendants

- changed (2025-02-25):
[0001375365-25-000006:note_history:2]
filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On November 5, 2024, the Court in the Hollin Action entered a Stipulation and Order staying all proceedings in Hollin and any related federal derivative actions, which includes the Federal Derivative Litigation. The Court in the State Court Derivative Litigation stayed all proceedings until case management conferences were held in each suit, with the first conference scheduled for April 24, 2025 in Spatz. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.
  (was, 2025-02-25, similarity 0.9036):
[0001375365-25-000005:note_history:2]
in a putative derivative lawsuit filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On November 5, 2024, the Court in the Hollin Action entered a Stipulation and Order staying all proceedings in Hollin and any related federal derivative actions, which includes the Federal Derivative Litigation. The Court in the State Court Derivative Litigation stayed all proceedings until case management conferences were held in each suit, with the first conference scheduled for April 24, 2025 in Spatz. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

- changed (2025-02-25):
[0001375365-25-000006:note_history:3]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of December 31, 2024 and any prior periods.
  (was, 2025-02-25, similarity 0.9924):
[0001375365-25-000005:note_history:3]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of September 30, 2024 and any prior periods.

- changed (2025-02-25):
[0001375365-25-000006:note_history:4]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2024, these remaining non-cancelable commitments were $2.3 billion, including $101.1 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of December 31, 2024 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.
  (was, 2025-02-25, similarity 0.9872):
[0001375365-25-000005:note_history:4]
Purchase Commitments - The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2024, these remaining non-cancelable commitments were $4.9 billion, including $136.7 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of September 30, 2024 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.

- changed (2025-02-25):
[0001375365-25-000006:note_history:5]
Lease Commitments— See Note 8, "Leases," for a discussion of the Company's operating lease commitments.
  (was, 2025-02-25, similarity 0.9854):
[0001375365-25-000005:note_history:5]
Lease Commitments - See Note 8, "Leases," for a discussion of the Company's operating lease commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:6]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2025. These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes contained in the 2024 10-K.
  (was, 2025-02-25, similarity 0.9708):
[0001375365-25-000005:note_history:6]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2025. These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes contained in the 2024 10-K.

- changed (2025-02-25):
[0001375365-25-000006:note_history:7]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 63.5% |  | 68.1% |  | 64.5% |  | 62.9% |
| Supplier B | 6.0% |  | 7.3% |  | 5.8% |  | 8.6% |
  (was, 2025-02-25, similarity 0.6763):
[0001375365-25-000005:note_history:7]
|  | September 30, 2024 | September 30, 2023 |
| Percentage of total purchases |  |  |
| Supplier A | 65.1% | 55.1% |
| Supplier B | 5.6% | 10.3% |

- changed (2025-02-25):
[0001375365-25-000006:note_history:8]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, "Related Party Transactions"), accounted for a combined 2.7% and 3.6% of total cost of sales for the three months ended December 31, 2024 and 2023, respectively, and a combined 3.7% and 4.6% of total cost of sales for the six months ended December 31, 2024 and 2023, respectively.
  (was, 2025-02-25, similarity 0.842):
[0001375365-25-000005:note_history:8]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, "Related Party Transactions"), accounted for a combined 4.6% and 6.4% of total cost of sales for the three months ended September 30, 2024 and 2023, respectively.

- changed (2025-02-25):
[0001375365-25-000006:note_history:9]
|  | December 31, 2024 | June 30, 2024 |
| Percentage of accounts receivable |  |  |
| Customer A | 16.0% | 15.4% |
| Customer G | 57.3% | 44.8% |
  (was, 2025-02-25, similarity 0.8872):
[0001375365-25-000005:note_history:9]
|  | September 30, 2024 | June 30, 2024 |
| Percentage of accounts receivable |  |  |
| Customer A | 32.7% | 15.4% |
| Customer B | 34.6% | * |
| Customer G | * | 44.8% |

- added (2025-02-25):
[0001375365-25-000006:note_history:10]
Customer A accounted for 27.1%, and customer G accounted for 30.6% of the net sales for the three months ended December 31, 2024 and customer A accounted for 23.9%, customer G accounted for 21.0% and customer B accounted for 14.9% of the net sales for the six months ended December 31, 2024. Customer A accounted for 25.5% and customer D accounted for 10.4% of the net sales for the three months ended December 31, 2023 and customer A accounted for 25.3% of the net sales for the six months ended December 31, 2023. Other customers were individually below 10% of the net sales for the three and six months ended December 31, 2024 and 2023.

- removed (2025-02-25):
[0001375365-25-000005:note_history:11]
The increase in the concentration of the Company's total purchases from supplier A to 65.1% of total purchases for the three months ended September 30, 2024, is a result of the purchase of key components to build its solutions for the Company's customers.

- removed (2025-02-25):
[0001375365-25-000005:note_history:12]
*Below 10%

- removed (2025-02-25):
[0001375365-25-000005:note_history:13]
Customer A accounted for 20.8%, customer B accounted for 28.7% and customer G accounted for 11.9% of the net sales for the three months ended September 30, 2024. Customer A accounted for 25.0% of the net sales for the three months ended September 30, 2023. Other customers were individually below 10% of the net sales for the three months ended September 30, 2024 and 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:14]
Lines of Credit and Term Loans
Short-term and long-term loan obligations as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands):
  (was, 2025-02-25, similarity 0.9831):
[0001375365-25-000005:note_history:14]
Lines of Credit and Term Loans
Short-term and long-term loan obligations as of September 30, 2024 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:15]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 90,467 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | 24,374 |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 114,841 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 13,964 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 28,291 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,350 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 17,062 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 10,562 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 21,327 |  |  | 27,644 |  |
| Total term loans | 93,556 |  |  | 114,557 |  |
| Total lines of credit and term loans | 208,397 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 154,988 |  |  | 402,346 |  |
| Term loans, non-current | $ | 53,409 |  |  | $ | 74,083 |  |
  (was, 2025-02-25, similarity 0.8392):
[0001375365-25-000005:note_history:15]
|  | September 30, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 68,253 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | 9,470 |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | 50,000 |  |  | 50,000 |  |
| First Bank Credit Lines | 28,084 |  |  | 28,084 |  |
| Yuanta Bank Credit Lines | 47,000 |  |  | — |  |
| Total line of credit | 202,807 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Bank of America Term Loan | 249,407 |  |  | — |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 16,440 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 30,664 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,799 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 20,202 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 11,969 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 25,253 |  |  | 27,644 |  |
| Total term loans | 356,734 |  |  | 114,557 |  |
| Total lines of credit and term loans | 559,541 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 493,808 |  |  | 402,346 |  |
| Term loans, non-current | $ | 65,733 |  |  | $ | 74,083 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:16]
Available borrowings and interest rates as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):
  (was, 2025-02-25, similarity 0.9818):
[0001375365-25-000005:note_history:16]
Available borrowings and interest rates as of September 30, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-02-25):
[0001375365-25-000006:note_history:17]
|  | December 31, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 94,533 |  |  | 2.15% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,140 |  |  | 1.88% - 5.30% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 35,626 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 30,000 |  |  | 2.03% - 5.26% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 47,224 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |
  (was, 2025-02-25, similarity 0.8943):
[0001375365-25-000005:note_history:17]
|  | September 30, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 280,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  |  | 6.49% |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | 132,000 |  |  | 7.16% |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 116,747 |  |  | 2.15% - 6.03% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 20,000 |  |  | 1.88% - 5.70% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | 50,000 |  |  | 2.03% - 6.25% |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 60,000 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | — |  |  | 1.90% - 5.56% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 1,916 |  |  | 2.03% - 6.19% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 1,927 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | 250,000 |  |  | 6.63% |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.68% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 1.52% - 1.72% |  | $ | — |  |  | 1.52% - 1.72% |

- changed (2025-02-25):
[0001375365-25-000006:note_history:18]
The Company entered into new agreements during the six months ended December 31, 2024 with the following terms:
  (was, 2025-02-25, similarity 0.9395):
[0001375365-25-000005:note_history:18]
The Company entered into new agreements during the three months ended September 30, 2024 with the following terms:

- added (2025-02-25):
[0001375365-25-000006:note_history:19]
On November 1, 2024, the Company prepaid in full and terminated its obligations under the Term Loan Agreement.

- added (2025-02-25):
[0001375365-25-000006:note_history:20]
On November 20, 2024, the Company prepaid in full and terminated its obligations under the ABL Agreement.

- added (2025-02-25):
[0001375365-25-000006:note_history:21]
2022 Bank of America Credit Facility

- added (2025-02-25):
[0001375365-25-000006:note_history:22]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the "Taiwan Subsidiary"), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

- added (2025-02-25):
[0001375365-25-000006:note_history:23]
Cathay Bank

- added (2025-02-25):
[0001375365-25-000006:note_history:24]
Cathay Bank Line of Credit

- added (2025-02-25):
[0001375365-25-000006:note_history:25]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the "Cathay Bank Loan Agreement"), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sublimit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

- added (2025-02-25):
[0001375365-25-000006:note_history:26]
E.SUN Bank

- added (2025-02-25):
[0001375365-25-000006:note_history:27]
E.SUN Bank Term Loan Facilities and Credit Lines

- added (2025-02-25):
[0001375365-25-000006:note_history:28]
On November 14, 2024, the Taiwan Subsidiary entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements issued by the Taiwan Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

- added (2025-02-25):
[0001375365-25-000006:note_history:29]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Taiwan Subsidiary had entered into with the Taiwan affiliate of HSBC Bank (the “HSBC Loan Agreement”) was terminated and not renewed. The balance of $50 million under the HSBC Loan Agreement was fully repaid on September 9, 2024, and the loan had remained undrawn since such date.

- changed (2025-02-25):
[0001375365-25-000006:note_history:30]
Principal payments on lines of credit and term loans are due as follows (in thousands):
  (was, 2025-02-25, similarity 0.7122):
[0001375365-25-000005:note_history:30]
Principal payments on short-term and long-term debt obligations are due as follows as of September 30, 2024 (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:31]
As of December 31, 2024, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6.
Convertible Notes 
2029 Convertible Notes
  (was, 2025-02-25, similarity 0.9864):
[0001375365-25-000005:note_history:31]
As of September 30, 2024, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6.
Convertible Notes 
2029 Convertible Notes

- changed (2025-02-25):
[0001375365-25-000006:note_history:32]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 2029 Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The 2029 Convertible Notes will mature on March 1, 2029, unless earlier converted, redeemed or repurchased. On February 20, 2025, the Company executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented amendments to the 2029 Convertible Notes. Refer to Note 14. "Subsequent Events", in the notes to the condensed consolidated financial statements below.
  (was, 2025-02-25, similarity 0.9944):
[0001375365-25-000005:note_history:32]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of the 2029 Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The 2029 Convertible Notes will mature on March 1, 2029, unless earlier converted, redeemed or repurchased. On February 20, 2025, the Company executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented amendments to the 2029 Convertible Notes. Refer to Note 14, “Subsequent Events,” in the notes to the condensed consolidated financial statements below.

- changed (2025-02-25):
[0001375365-25-000006:note_history:33]
The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. Because the Company did not file its Annual Report on Form 10-K for the fiscal year ended June 30, 2024 in a timely manner, it elected to accrue special interest on the 2029 Convertible Notes and accrued additional interest on the 2029 Convertible Notes in accordance with the indenture governing the 2029 Convertible Notes (the "2029 Convertible Notes Indenture"). As of December 31, 2024, such accrued and unpaid interest under the 2029 Convertible Notes was $2.2 million. The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 7.455 shares of common stock per $1,000 principal amount of 2029 Convertible Notes, which is equivalent to an initial conversion price of approximately $134.14 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest and additional interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture and have accrued on the 2029 Convertible Notes subsequent to June 30, 2024 as described above. The debt issuance costs are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.
  (was, 2025-02-25, similarity 0.9273):
[0001375365-25-000005:note_history:33]
The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. Because the Company did not file its Annual Report on Form 10-K for the fiscal year ended June 30, 2024 in a timely manner, it elected to accrue special interest on the 2029 Convertible Notes and accrued additional interest on the 2029 Convertible Notes in accordance with the indenture governing the 2029 Convertible Notes (the “2029 Convertible Notes Indenture”). Interest expense recognized was $2.2 million for the three months ended September 30, 2024. The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 7.455 shares of common stock per $1,000 principal amount of 2029 Convertible Notes, which is equivalent to an initial conversion price of approximately $134.14 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest and additional interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture and have accrued on the 2029 Convertible Notes subsequent to June 30, 2024 as described above. The debt issuance costs are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

- changed (2025-02-25):
[0001375365-25-000006:note_history:34]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. The 2029 Convertible Notes were not eligible for conversion as of December 31, 2024. No sinking fund is provided for the 2029 Convertible Notes.
  (was, 2025-02-25, similarity 0.9914):
[0001375365-25-000005:note_history:34]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. The 2029 Convertible Notes were not eligible for conversion as of September 30, 2024. No sinking fund is provided for the 2029 Convertible Notes.

- changed (2025-02-25):
[0001375365-25-000006:note_history:35]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of December 31, 2024, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.
  (was, 2025-02-25, similarity 0.9964):
[0001375365-25-000005:note_history:35]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of September 30, 2024, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

- changed (2025-02-25):
[0001375365-25-000006:note_history:36]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $24.4 million, was $1,700.6 million as of December 31, 2024. Interest expense related to the amortization of debt issuance costs was $1.5 million for the quarter ended December 31, 2024. The effective interest rate is 0.34%.
  (was, 2025-02-25, similarity 0.9753):
[0001375365-25-000005:note_history:36]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $25.8 million, was $1,699.2 million as of September 30, 2024. Interest expense related to the amortization of debt issuance costs was $1.5 million for the quarter ended September 30, 2024. The effective interest rate is 0.34%.

- changed (2025-02-25):
[0001375365-25-000006:note_history:37]
In connection with the issuance of the 2029 Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. In connection with the amendment of the 2029 Convertible Notes, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to Note 14. "Subsequent Events", below.
  (was, 2025-02-25, similarity 0.9976):
[0001375365-25-000005:note_history:37]
In connection with the issuance of the 2029 Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. In connection with the amendment of the 2029 Convertible Notes, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to Note 14, “Subsequent Events,” below.

- added (2025-02-25):
[0001375365-25-000006:note_history:38]
The Capped Call Transactions initially have a strike price of $134.14 per share, subject to certain adjustments, which corresponds to the initial conversion price of the 2029 Convertible Notes. The cap price of the Capped Call Transactions was initially $195.10 per share of common stock subject to certain adjustments under the terms of the Capped Call Transactions.

- added (2025-02-25):
[0001375365-25-000006:note_history:39]
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The 2029 Convertible Notes and the Capped Call Transactions have been integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.

- removed (2025-02-25):
[0001375365-25-000005:note_history:40]
On September 9, 2024, the Company repaid the balance of $50 million under the Loan Agreement entered into by Super Micro Computer, Inc. Taiwan (“Taiwan Subsidiary”), a wholly-owned subsidiary of the Company, and the Taiwan affiliate of HSBC Bank, and the loan had remained undrawn since such date.

- removed (2025-02-25):
[0001375365-25-000005:note_history:41]
The Capped Call Transactions initially have a strike price of $134.14 per share, subject to certain adjustments, which corresponds to the initial conversion price of the 2029 Convertible Notes. The cap price of the Capped Call Transactions was initially $195.10 per share of common stock subject to certain adjustments under the terms of the Capped Call Transactions.
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The 2029 Convertible Notes and the Capped Call Transactions have been integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:42]
Short-term and long-term loan obligations as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands):
  (was, 2025-02-25, similarity 0.9785):
[0001375365-25-000005:note_history:42]
Short-term and long-term loan obligations as of September 30, 2024 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:43]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 90,467 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | 24,374 |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 114,841 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 13,964 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 28,291 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,350 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 17,062 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 10,562 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 21,327 |  |  | 27,644 |  |
| Total term loans | 93,556 |  |  | 114,557 |  |
| Total lines of credit and term loans | 208,397 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 154,988 |  |  | 402,346 |  |
| Term loans, non-current | $ | 53,409 |  |  | $ | 74,083 |  |
  (was, 2025-02-25, similarity 0.8392):
[0001375365-25-000005:note_history:43]
|  | September 30, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 68,253 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | 9,470 |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | 50,000 |  |  | 50,000 |  |
| First Bank Credit Lines | 28,084 |  |  | 28,084 |  |
| Yuanta Bank Credit Lines | 47,000 |  |  | — |  |
| Total line of credit | 202,807 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Bank of America Term Loan | 249,407 |  |  | — |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 16,440 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 30,664 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,799 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 20,202 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 11,969 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 25,253 |  |  | 27,644 |  |
| Total term loans | 356,734 |  |  | 114,557 |  |
| Total lines of credit and term loans | 559,541 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 493,808 |  |  | 402,346 |  |
| Term loans, non-current | $ | 65,733 |  |  | $ | 74,083 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:44]
Available borrowings and interest rates as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):
  (was, 2025-02-25, similarity 0.9818):
[0001375365-25-000005:note_history:44]
Available borrowings and interest rates as of September 30, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-02-25):
[0001375365-25-000006:note_history:45]
|  | December 31, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 94,533 |  |  | 2.15% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,140 |  |  | 1.88% - 5.30% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 35,626 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 30,000 |  |  | 2.03% - 5.26% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 47,224 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |
  (was, 2025-02-25, similarity 0.8943):
[0001375365-25-000005:note_history:45]
|  | September 30, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 280,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  |  | 6.49% |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | 132,000 |  |  | 7.16% |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 116,747 |  |  | 2.15% - 6.03% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 20,000 |  |  | 1.88% - 5.70% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | 50,000 |  |  | 2.03% - 6.25% |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 60,000 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | — |  |  | 1.90% - 5.56% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 1,916 |  |  | 2.03% - 6.19% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 1,927 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | 250,000 |  |  | 6.63% |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.68% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 1.52% - 1.72% |  | $ | — |  |  | 1.52% - 1.72% |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:46]
Principal payments on lines of credit and term loans are due as follows (in thousands):
  (was, 2025-02-25, similarity 0.7122):
[0001375365-25-000005:note_history:46]
Principal payments on short-term and long-term debt obligations are due as follows as of September 30, 2024 (in thousands):


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:47]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.
  (was, 2025-02-25, similarity 0.9976):
[0001375365-25-000005:note_history:47]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

- changed (2025-02-25):
[0001375365-25-000006:note_history:48]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on NASDAQ in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of December 31, 2024 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.6 million and $16.4 million, respectively.
  (was, 2025-02-25, similarity 0.9957):
[0001375365-25-000005:note_history:48]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on NASDAQ in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of September 30, 2024 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.5 million and $16.4 million respectively.

- added (2025-02-25):
[0001375365-25-000006:note_history:49]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.1% and 87.2% of the chassis included in the products sold by the Company during the three months ended December 31, 2024 and 2023, respectively, and 96.5% and 86.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2025-02-25):
[0001375365-25-000006:note_history:50]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on December 31, 2024 were $25.9 million and $34.1 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.
  (was, 2025-02-25, similarity 0.9975):
[0001375365-25-000005:note_history:50]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on September 30, 2024 were $24.8 million and $48.4 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

- changed (2025-02-25):
[0001375365-25-000006:note_history:51]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on December 31, 2024 were $113.5 million and $66.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2025-02-25, similarity 0.9957):
[0001375365-25-000005:note_history:51]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on September 30, 2024 were $117.2 million and $88.3 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2025-02-25):
[0001375365-25-000006:note_history:52]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended December 31, 2024, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and purchased $0.1 million of graphics cards from Leadtek. During the six months ended December 31, 2024, the Company engaged in transactions in which it sold $0.3 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.
  (was, 2025-02-25, similarity 0.9013):
[0001375365-25-000005:note_history:52]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended September 30, 2024, the Company engaged in transactions in which it sold $0.1 million of servers to Leadtek and purchased $0.4 million of graphics cards from Leadtek.

- changed (2025-02-25):
[0001375365-25-000006:note_history:53]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.3 million and $4.6 million as of December 31, 2024 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of December 31, 2024 and June 30, 2024. No impairment charge was recorded for the three and six months ended December 31, 2024 and 2023.
  (was, 2025-02-25, similarity 0.9579):
[0001375365-25-000005:note_history:53]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $5.0 million and $4.6 million as of September 30, 2024 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of September 30, 2024 and June 30, 2024. No impairment charge was recorded for the three months ended September 30, 2024 and 2023.

- added (2025-02-25):
[0001375365-25-000006:note_history:54]
The Company sold products worth $0.0 million and $11.4 million to the Corporate Venture during the three months ended December 31, 2024 and 2023, respectively, and $4.8 million and $12.2 million to the Corporate Venture during the six months ended December 31, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2024 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.0 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2024 and June 30, 2024, respectively.

- added (2025-02-25):
[0001375365-25-000006:note_history:55]
For the three months ended December 31, 2024, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the six months ended December 31, 2024, the Company had immaterial chargebacks from Green Earth. As of December 31, 2024, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth are immaterial.

- changed (2025-02-25):
[0001375365-25-000006:note_history:56]
The Company had the following balances related to transactions with its related parties as of December 31, 2024 and June 30, 2024 (in thousands):
  (was, 2025-02-25, similarity 0.9815):
[0001375365-25-000005:note_history:56]
The Company had the following balances related to transactions with its related parties as of September 30, 2024 and June 30, 2024 (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:57]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  |  |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 34 |  |  | $ | 142 |  |  | $ | (2) |  |  | $ | 5,075 |  |  |  |  | $ | 134 |  |  | $ | 976 |  |  | $ | 168 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,597 |  |  | $ | 1,927 |  |  | $ | 15,753 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 17,350 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 52,754 |  |  | $ | 98,629 |  |  | $ | 56,697 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 230 |  |  | $ | 109,535 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 294 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 170 |  |
  (was, 2025-02-25, similarity 0.8537):
[0001375365-25-000005:note_history:57]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | September 30, 2024 |  | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 | September 30, 2024 | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 7,037 |  |  | $ | 142 |  |  | $ | 933 |  |  | $ | 5,075 |  | $ | 19 |  | $ | 976 |  |  | $ | 7,991 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 2,393 |  |  | $ | 1,927 |  |  | $ | 12,681 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 15,074 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 128,628 |  |  | $ | 98,629 |  |  | $ | 73,220 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  | $ | 171 |  | $ | 230 |  |  | $ | 202,019 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 300 |  |  | $ | — |  |  | $ | 100 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 400 |  |  | $ | 170 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:58]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2024 and 2023, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9833):
[0001375365-25-000005:note_history:58]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2024 and 2023, are as follows (in thousands):

- added (2025-02-25):
[0001375365-25-000006:note_history:59]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, | Three months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 5 |  |  | $ | 4 |  |  | $ | 11,065 |  |  | $ | 4,392 |  |  | $ | (51) |  |  | $ | 11,385 |  |  |  |  | $ | 258 |  |  | $ | — |  | $ | 11,277 |  |  | $ | 15,781 |  |
| Purchases - inventory | $ | 64,773 |  |  | $ | 50,586 |  |  | $ | 71,230 |  |  | $ | 61,859 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 106 |  |  | $ | — |  | $ | 136,109 |  |  | $ | 112,445 |  |
| Purchases - other miscellaneous items | $ | 3,764 |  |  | $ | 3,456 |  |  | $ | 294 |  |  | $ | 332 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 4,058 |  |  | $ | 3,788 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:60]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.902):
[0001375365-25-000005:note_history:60]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2024 and 2023, are as follows (in thousands):

- added (2025-02-25):
[0001375365-25-000006:note_history:61]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21,040 |  |  | $ | 20,998 |  |  | $ | 4,776 |  |  | $ | 12,173 |  |  |  |  | $ | 329 |  |  | $ | — |  | $ | 26,152 |  |  | $ | 33,177 |  |
| Purchases - inventory | $ | 202,279 |  |  | $ | 97,199 |  |  | $ | 173,348 |  |  | $ | 128,353 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  | 376,161 |  |  | 225,552 |  |
| Purchases - other miscellaneous items | $ | 10,118 |  |  | $ | 8,215 |  |  | $ | 1,031 |  |  | $ | 749 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 11,149 |  |  | $ | 8,964 |  |

- added (2025-02-25):
[0001375365-25-000006:note_history:62]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:63]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 108 |  |  | $ | 3,239 |  |  | $ | 5,077 |  |  | $ | (1,625) |  |  |  |  | $ | 842 |  |  | $ | — |  | $ | 6,026 |  |  | $ | 1,614 |  |
| Changes in other receivable | $ | 330 |  |  | $ | 571 |  |  | $ | (5,741) |  |  | $ | (7,132) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | (5,411) |  |  | $ | (6,561) |  |
| Changes in accounts payable | $ | (45,875) |  |  | $ | 10,938 |  |  | $ | (9,739) |  |  | $ | 1,628 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 146 |  |  | $ | — |  | $ | (55,468) |  |  | $ | 12,566 |  |
| Changes in accrued liabilities | $ | 294 |  |  | $ | (156) |  |  | $ | (146) |  |  | $ | 4,648 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 148 |  |  | $ | 4,492 |  |
| Changes in other long-term liabilities | $ | 154 |  |  | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 154 |  |  | $ | (152) |  |
| Purchases of property, plant and equipment | $ | 6,525 |  |  | $ | 4,460 |  |  | $ | 357 |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 6,882 |  |  | $ | 4,528 |  |
| Unpaid property, plant and equipment | $ | 2,946 |  |  | $ | 2,570 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 2,960 |  |  | $ | 2,577 |  |
  (was, 2025-02-25, similarity 0.6028):
[0001375365-25-000005:note_history:63]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | Three months ended September 30, |  | Three months ended September 30, |  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 | 2024 | 2023 |  | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (2) |  |  | $ | (2) |  |  | $ | (6,895) |  |  | $ | 2,436 |  |  | $ | 4,142 |  |  | $ | 1,704 |  | $ | 958 |  | $ | — |  |  | $ | (1,797) |  |  | $ | 4,138 |  |
| Changes in other receivable | $ | (466) |  |  | $ | 558 |  |  | $ | (2,669) |  |  | $ | 2,269 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | (3,135) |  |  | $ | 2,827 |  |
| Changes in accounts payable | $ | 29,999 |  |  | $ | 8,765 |  |  | $ | 6,784 |  |  | $ | (5,784) |  |  | $ | — |  |  | $ | — |  | $ | (59) |  | $ | — |  |  | $ | 36,724 |  |  | $ | 2,981 |  |
| Changes in accrued liabilities | $ | 300 |  |  | $ | (745) |  |  | $ | (70) |  |  | $ | 3,232 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 230 |  |  | $ | 2,487 |  |
| Changes in other long-term liabilities | $ | 237 |  |  | $ | — |  |  | $ | — |  |  | $ | (80) |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 237 |  |  | $ | (80) |  |
| Purchases of property, plant and equipment | $ | 2,925 |  |  | $ | 782 |  |  | $ | 204 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 3,129 |  |  | $ | 826 |  |
| Unpaid property, plant and equipment | $ | 3,906 |  |  | $ | 3,672 |  |  | $ | 153 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 4,059 |  |  | $ | 3,672 |  |

- removed (2025-02-25):
[0001375365-25-000005:note_history:64]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.8% and 85.5% of the chassis included in the products sold by the Company during the three months ended September 30, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2025-02-25):
[0001375365-25-000005:note_history:65]
The Company sold products worth $4.8 million and $0.8 million to the Corporate Venture during the three months ended September 30, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2024 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.9 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2024 and June 30, 2024, respectively.

- removed (2025-02-25):
[0001375365-25-000005:note_history:66]
For the three months ended September 30, 2024, the Company had immaterial chargebacks from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. As of September 30, 2024, the amounts due from Green Earth are immaterial. As of June 30, 2024, the amounts due to and from Green Earth are immaterial.

- removed (2025-02-25):
[0001375365-25-000005:note_history:67]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | Three months ended September 30, |  | Three months ended September 30, |  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 2 |  |  | $ | 2 |  |  | $ | 9,975 |  |  | $ | 16,606 |  |  | $ | 4,827 |  |  | $ | 788 |  | $ | 71 |  |  | $ | — |  |  | $ | 14,875 |  |  | $ | 17,396 |  |
| Purchases - inventory | $ | 137,507 |  |  | $ | 46,614 |  |  | $ | 102,117 |  |  | $ | 66,493 |  |  | $ | — |  |  | $ | — |  | $ | 427 |  |  | $ | — |  |  | $ | 240,051 |  |  | $ | 113,107 |  |
| Purchases - other miscellaneous items | $ | 6,354 |  |  | $ | 4,759 |  |  | $ | 737 |  |  | $ | 417 |  |  | $ | — |  |  | $ | — |  | $ | — |  |  | $ | — |  |  | $ | 7,091 |  |  | $ | 5,176 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:68]
The Company had the following balances related to transactions with its related parties as of December 31, 2024 and June 30, 2024 (in thousands):
  (was, 2025-02-25, similarity 0.9815):
[0001375365-25-000005:note_history:68]
The Company had the following balances related to transactions with its related parties as of September 30, 2024 and June 30, 2024 (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:69]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  |  |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 34 |  |  | $ | 142 |  |  | $ | (2) |  |  | $ | 5,075 |  |  |  |  | $ | 134 |  |  | $ | 976 |  |  | $ | 168 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,597 |  |  | $ | 1,927 |  |  | $ | 15,753 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 17,350 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 52,754 |  |  | $ | 98,629 |  |  | $ | 56,697 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 230 |  |  | $ | 109,535 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 294 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 170 |  |
  (was, 2025-02-25, similarity 0.8537):
[0001375365-25-000005:note_history:69]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | September 30, 2024 |  | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 | September 30, 2024 | June 30, 2024 |  | September 30, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 7,037 |  |  | $ | 142 |  |  | $ | 933 |  |  | $ | 5,075 |  | $ | 19 |  | $ | 976 |  |  | $ | 7,991 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 2,393 |  |  | $ | 1,927 |  |  | $ | 12,681 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 15,074 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 128,628 |  |  | $ | 98,629 |  |  | $ | 73,220 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  | $ | 171 |  | $ | 230 |  |  | $ | 202,019 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 300 |  |  | $ | — |  |  | $ | 100 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 400 |  |  | $ | 170 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:70]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2024 and 2023, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9833):
[0001375365-25-000005:note_history:70]
The Company’s results from transactions with its related parties for each of the three months ended September 30, 2024 and 2023, are as follows (in thousands):

- added (2025-02-25):
[0001375365-25-000006:note_history:71]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, | Three months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 5 |  |  | $ | 4 |  |  | $ | 11,065 |  |  | $ | 4,392 |  |  | $ | (51) |  |  | $ | 11,385 |  |  |  |  | $ | 258 |  |  | $ | — |  | $ | 11,277 |  |  | $ | 15,781 |  |
| Purchases - inventory | $ | 64,773 |  |  | $ | 50,586 |  |  | $ | 71,230 |  |  | $ | 61,859 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 106 |  |  | $ | — |  | $ | 136,109 |  |  | $ | 112,445 |  |
| Purchases - other miscellaneous items | $ | 3,764 |  |  | $ | 3,456 |  |  | $ | 294 |  |  | $ | 332 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 4,058 |  |  | $ | 3,788 |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:72]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.902):
[0001375365-25-000005:note_history:72]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2024 and 2023, are as follows (in thousands):

- added (2025-02-25):
[0001375365-25-000006:note_history:73]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21,040 |  |  | $ | 20,998 |  |  | $ | 4,776 |  |  | $ | 12,173 |  |  |  |  | $ | 329 |  |  | $ | — |  | $ | 26,152 |  |  | $ | 33,177 |  |
| Purchases - inventory | $ | 202,279 |  |  | $ | 97,199 |  |  | $ | 173,348 |  |  | $ | 128,353 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  | 376,161 |  |  | 225,552 |  |
| Purchases - other miscellaneous items | $ | 10,118 |  |  | $ | 8,215 |  |  | $ | 1,031 |  |  | $ | 749 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 11,149 |  |  | $ | 8,964 |  |

- added (2025-02-25):
[0001375365-25-000006:note_history:74]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:75]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 108 |  |  | $ | 3,239 |  |  | $ | 5,077 |  |  | $ | (1,625) |  |  |  |  | $ | 842 |  |  | $ | — |  | $ | 6,026 |  |  | $ | 1,614 |  |
| Changes in other receivable | $ | 330 |  |  | $ | 571 |  |  | $ | (5,741) |  |  | $ | (7,132) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | (5,411) |  |  | $ | (6,561) |  |
| Changes in accounts payable | $ | (45,875) |  |  | $ | 10,938 |  |  | $ | (9,739) |  |  | $ | 1,628 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 146 |  |  | $ | — |  | $ | (55,468) |  |  | $ | 12,566 |  |
| Changes in accrued liabilities | $ | 294 |  |  | $ | (156) |  |  | $ | (146) |  |  | $ | 4,648 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 148 |  |  | $ | 4,492 |  |
| Changes in other long-term liabilities | $ | 154 |  |  | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 154 |  |  | $ | (152) |  |
| Purchases of property, plant and equipment | $ | 6,525 |  |  | $ | 4,460 |  |  | $ | 357 |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 6,882 |  |  | $ | 4,528 |  |
| Unpaid property, plant and equipment | $ | 2,946 |  |  | $ | 2,570 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 2,960 |  |  | $ | 2,577 |  |
  (was, 2025-02-25, similarity 0.6028):
[0001375365-25-000005:note_history:75]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | Three months ended September 30, |  | Three months ended September 30, |  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 | 2024 | 2023 |  | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (2) |  |  | $ | (2) |  |  | $ | (6,895) |  |  | $ | 2,436 |  |  | $ | 4,142 |  |  | $ | 1,704 |  | $ | 958 |  | $ | — |  |  | $ | (1,797) |  |  | $ | 4,138 |  |
| Changes in other receivable | $ | (466) |  |  | $ | 558 |  |  | $ | (2,669) |  |  | $ | 2,269 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | (3,135) |  |  | $ | 2,827 |  |
| Changes in accounts payable | $ | 29,999 |  |  | $ | 8,765 |  |  | $ | 6,784 |  |  | $ | (5,784) |  |  | $ | — |  |  | $ | — |  | $ | (59) |  | $ | — |  |  | $ | 36,724 |  |  | $ | 2,981 |  |
| Changes in accrued liabilities | $ | 300 |  |  | $ | (745) |  |  | $ | (70) |  |  | $ | 3,232 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 230 |  |  | $ | 2,487 |  |
| Changes in other long-term liabilities | $ | 237 |  |  | $ | — |  |  | $ | — |  |  | $ | (80) |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 237 |  |  | $ | (80) |  |
| Purchases of property, plant and equipment | $ | 2,925 |  |  | $ | 782 |  |  | $ | 204 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 3,129 |  |  | $ | 826 |  |
| Unpaid property, plant and equipment | $ | 3,906 |  |  | $ | 3,672 |  |  | $ | 153 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 4,059 |  |  | $ | 3,672 |  |

- removed (2025-02-25):
[0001375365-25-000005:note_history:76]
|  | Ablecom |  | Compuware |  | Corporate Venture | Leadtek |  | Total |
|  | Three months ended September 30, |  | Three months ended September 30, |  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 2 |  |  | $ | 2 |  |  | $ | 9,975 |  |  | $ | 16,606 |  |  | $ | 4,827 |  |  | $ | 788 |  | $ | 71 |  |  | $ | — |  |  | $ | 14,875 |  |  | $ | 17,396 |  |
| Purchases - inventory | $ | 137,507 |  |  | $ | 46,614 |  |  | $ | 102,117 |  |  | $ | 66,493 |  |  | $ | — |  |  | $ | — |  | $ | 427 |  |  | $ | — |  |  | $ | 240,051 |  |  | $ | 113,107 |  |
| Purchases - other miscellaneous items | $ | 6,354 |  |  | $ | 4,759 |  |  | $ | 737 |  |  | $ | 417 |  |  | $ | — |  |  | $ | — |  | $ | — |  |  | $ | — |  |  | $ | 7,091 |  |  | $ | 5,176 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:77]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 5,487,150 |  |  | $ | 3,435,562 |  |  | $ | 11,234,931 |  |  | $ | 5,402,170 |  |
| Subsystems and accessories | 190,812 |  |  | 229,362 |  |  | 380,287 |  |  | 382,426 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |
  (was, 2025-02-25, similarity 0.7316):
[0001375365-25-000005:note_history:77]
|  | Three Months Ended September 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Server and storage systems | $ | 5,747,781 |  |  | $ | 1,966,608 |  |  |  |  |  |
| Subsystems and accessories | 189,475 |  |  | 153,064 |  |  |  |  |  |
| Total | $ | 5,937,256 |  |  | $ | 2,119,672 |  |  |  |  |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:78]
The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):
  (was, 2025-02-25, similarity 0.9486):
[0001375365-25-000005:note_history:78]
The following is a summary for the three months ended September 30, 2024 and 2023, of net sales by geographic region (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:79]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 3,846,960 |  |  | $ | 2,605,585 |  |  | $ | 8,088,309 |  |  | $ | 4,225,099 |  |
| Asia | 768,246 |  |  | 656,220 |  |  | 1,722,820 |  |  | 881,688 |  |
| Europe | 933,772 |  |  | 288,448 |  |  | 1,579,614 |  |  | 479,296 |  |
| Other | 128,984 |  |  | 114,671 |  |  | 224,475 |  |  | 198,513 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |
  (was, 2025-02-25, similarity 0.7323):
[0001375365-25-000005:note_history:79]
|  | Three Months Ended September 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 4,241,349 |  |  | $ | 1,619,514 |  |  |  |  |  |
| Asia | 954,574 |  |  | 225,468 |  |  |  |  |  |
| Europe | 645,842 |  |  | 190,848 |  |  |  |  |  |
| Other | 95,491 |  |  | 83,842 |  |  |  |  |  |
| Total | $ | 5,937,256 |  |  | $ | 2,119,672 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-25):
[0001375365-25-000006:note_history:80]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 5,487,150 |  |  | $ | 3,435,562 |  |  | $ | 11,234,931 |  |  | $ | 5,402,170 |  |
| Subsystems and accessories | 190,812 |  |  | 229,362 |  |  | 380,287 |  |  | 382,426 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |
  (was, 2025-02-25, similarity 0.7316):
[0001375365-25-000005:note_history:80]
|  | Three Months Ended September 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Server and storage systems | $ | 5,747,781 |  |  | $ | 1,966,608 |  |  |  |  |  |
| Subsystems and accessories | 189,475 |  |  | 153,064 |  |  |  |  |  |
| Total | $ | 5,937,256 |  |  | $ | 2,119,672 |  |  |  |  |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:81]
Revenue related to services for the three months ended December 31, 2024 and 2023 was $54.4 million, and $37.2 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the six months ended December 31, 2024 and 2023 was $104.6 million and $72.4 million, respectively, which is recognized over time ratably over the contract term.
  (was, 2025-02-25, similarity 0.6654):
[0001375365-25-000005:note_history:81]
Revenue related to services for the three months ended September 30, 2024 and 2023 was $50.1 million and $35.1 million, respectively, which is recognized over time ratably over the contract term.

- changed (2025-02-25):
[0001375365-25-000006:note_history:82]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):
  (was, 2025-02-25, similarity 0.9122):
[0001375365-25-000005:note_history:82]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2024 and 2023, of net sales by geographic region (in thousands):

- changed (2025-02-25):
[0001375365-25-000006:note_history:83]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 3,846,960 |  |  | $ | 2,605,585 |  |  | $ | 8,088,309 |  |  | $ | 4,225,099 |  |
| Asia | 768,246 |  |  | 656,220 |  |  | 1,722,820 |  |  | 881,688 |  |
| Europe | 933,772 |  |  | 288,448 |  |  | 1,579,614 |  |  | 479,296 |  |
| Other | 128,984 |  |  | 114,671 |  |  | 224,475 |  |  | 198,513 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |
  (was, 2025-02-25, similarity 0.7323):
[0001375365-25-000005:note_history:83]
|  | Three Months Ended September 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| United States | $ | 4,241,349 |  |  | $ | 1,619,514 |  |  |  |  |  |
| Asia | 954,574 |  |  | 225,468 |  |  |  |  |  |
| Europe | 645,842 |  |  | 190,848 |  |  |  |  |  |
| Other | 95,491 |  |  | 83,842 |  |  |  |  |  |
| Total | $ | 5,937,256 |  |  | $ | 2,119,672 |  |  |  |  |  |

- changed (2025-02-25):
[0001375365-25-000006:note_history:84]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $47.3 million and $115.5 million, respectively. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.
  (was, 2025-02-25, similarity 0.7873):
[0001375365-25-000005:note_history:84]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three months ended September 30, 2024, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $68.2 million. Revenue recognized during the three months ended September 30, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $43.7 million.

- added (2025-02-25):
[0001375365-25-000006:note_history:85]
Deferred revenue increased $182.3 million as of December 31, 2024 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods.

- added (2025-02-25):
[0001375365-25-000006:note_history:86]
Transaction Price Allocated to the Remaining Performance Obligations
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to deferred revenue as of December 31, 2024 was approximately $598.7 million. The Company expects to recognize approximately 52%

- removed (2025-02-25):
[0001375365-25-000005:note_history:87]
Deferred revenue increased $141.8 million as of September 30, 2024 as compared to June 30, 2024. This increase was mainly due to a $81.6 million increase in non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months. This was accompanied by a $39.9 million increase in deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods.

- removed (2025-02-25):
[0001375365-25-000005:note_history:88]
Transaction Price Allocated to the Remaining Performance Obligations

- removed (2025-02-25):
[0001375365-25-000005:note_history:89]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to deferred revenue as of September 30, 2024 was approximately $558.2 million. The Company expects to recognize approximately 55% of this deferred revenue in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-02-25):
[0001375365-25-000006:note_history:90]
Subsequent Events

- removed (2025-02-25):
[0001375365-25-000005:note_history:91]
Subsequent Events
Cathay Bank Line of Credit

- removed (2025-02-25):
[0001375365-25-000005:note_history:92]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ending September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sublimit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

- removed (2025-02-25):
[0001375365-25-000005:note_history:93]
Bank of America Bridge Term Loan Facility

- removed (2025-02-25):
[0001375365-25-000005:note_history:94]
On November 1, 2024, the Company prepaid in full and terminated its obligations under the Term Loan Credit Agreement, dated as of July 19, 2024, by and among the Company, the lenders party thereto, and Bank of America, N.A., as the administrative agent, as amended or otherwise modified.

- removed (2025-02-25):
[0001375365-25-000005:note_history:95]
E.SUN Bank Term Loan Facilities and Credit Lines

- removed (2025-02-25):
[0001375365-25-000005:note_history:96]
On November 14, 2024, the Company’s Taiwan subsidiary (the “Subsidiary”) entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements

- removed (2025-02-25):
[0001375365-25-000005:note_history:97]
issued by the Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

- removed (2025-02-25):
[0001375365-25-000005:note_history:98]
2018 Bank of America Credit Facility

- removed (2025-02-25):
[0001375365-25-000005:note_history:99]
On November 20, 2024, the Company prepaid in full and terminated its obligations under the 2018 Bank of America Credit Facility.

- removed (2025-02-25):
[0001375365-25-000005:note_history:100]
2022 Bank of America Credit Facility

- removed (2025-02-25):
[0001375365-25-000005:note_history:101]
On November 20, 2024, the Company, through its Taiwan subsidiary, terminated its obligations under the 2022 Bank of America Credit Facility with respect to the credit lines with Bank of America – Taipei Branch.

- removed (2025-02-25):
[0001375365-25-000005:note_history:102]
HSBC Bank Credit Lines

- removed (2025-02-25):
[0001375365-25-000005:note_history:103]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Company, through its Taiwan subsidiary, had entered into with the Taiwan affiliate of HSBC Bank (the “Loan Agreement”) was terminated and not renewed. The balance under this $50 million Loan Agreement had been fully repaid on September 9, 2024, and had remained undrawn since such date.
