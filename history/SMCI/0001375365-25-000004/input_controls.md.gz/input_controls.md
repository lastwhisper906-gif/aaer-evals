# SMCI 10-K controls and the auditor's report


## auditors_report

[0001375365-25-000004:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001375365-25-000004:auditors_report:2]
Stockholders and Board of Directors

[0001375365-25-000004:auditors_report:3]
Super Micro Computer, Inc.

[0001375365-25-000004:auditors_report:4]
San Jose, California

[0001375365-25-000004:auditors_report:5]
Opinion on the Consolidated Financial Statements

[0001375365-25-000004:auditors_report:6]
We have audited the accompanying consolidated balance sheet of Super Micro Computer, Inc. (the “Company”) as of June 30, 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for the year then ended, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at June 30, 2024, and the results of its operations and its cash flows for the year then ended, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-25-000004:auditors_report:7]
We also have audited the adjustments to the 2023 and 2022 consolidated financial statements to retrospectively apply the stock split, as discussed in Note 1. In our opinion, such adjustments are appropriate and have been properly applied. We were not engaged to audit, review, or apply any procedures to the 2023 and 2022 consolidated financial statements of the Company other than with respect to the adjustments and, accordingly, we do not express an opinion or any other form of assurance on the 2023 and 2022 consolidated financial statements taken as a whole.

[0001375365-25-000004:auditors_report:8]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the Company's internal control over financial reporting as of June 30, 2024, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) and our report dated February 25, 2025 expressed an adverse opinion thereon.

[0001375365-25-000004:auditors_report:9]
Basis for Opinion

[0001375365-25-000004:auditors_report:10]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000004:auditors_report:11]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud.

[0001375365-25-000004:auditors_report:12]
Our audit included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-25-000004:auditors_report:13]
Critical Audit Matters

[0001375365-25-000004:auditors_report:14]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001375365-25-000004:auditors_report:15]
SMCI | 2024 Form 10-K | 64

[0001375365-25-000004:auditors_report:16]
Valuation of Inventories

[0001375365-25-000004:auditors_report:17]
As described in Notes 1 and 5 to the consolidated financial statements, the Company’s consolidated inventories balance, which is stated at lower of cost, using weighted average cost method, or net realizable value, was $4.33 billion as of June 30, 2024. The Company evaluates inventories for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based on the Company’s review of inventory quantities on hand as compared with inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors.

[0001375365-25-000004:auditors_report:18]
We identified the valuation of inventories as a critical audit matter. Auditing the valuation of inventories, which includes write-down percentages applied to the different inventory categories for the adjustments for excess and obsolescence, involved especially challenging and subjective auditor judgments due to the nature and extent of effort required to address this matter.

[0001375365-25-000004:auditors_report:19]
The primary procedures we performed to address this critical audit matter included:

[0001375365-25-000004:auditors_report:20]
•Inquiring of various personnel in the Company including but not limited to finance and operations personnel about the expected product lifecycles and product development plans to understand and evaluate the Company’s methodology for determining inventory that is excess or obsolete and the key assumptions and judgments made as part of the process, including the write-down percentages used to write down the valuation of inventory.

[0001375365-25-000004:auditors_report:21]
•Assessing management’s estimate of write-down percentages by recalculating inventory turns and historical write-down percentages across multiple fiscal periods and comparing it with the write-down percentages used by management to evaluate management’s ability to accurately estimate excess and obsolete inventory.

[0001375365-25-000004:auditors_report:22]
•Testing the completeness and accuracy of the underlying data utilized in management’s excess and obsolescence analysis, including the classification of inventory by aging category.

[0001375365-25-000004:auditors_report:23]
•Assessing the existence of contradictory evidence based on reading the Company’s press releases and industry reports, as well as our observations and inquiries as to changes within the business.

[0001375365-25-000004:auditors_report:24]
Revenue Recognition from Contracts with Customers

[0001375365-25-000004:auditors_report:25]
As described in Notes 1 and 3 to the consolidated financial statements, the Company’s total revenue was $14.99 billion for the year ended June 30, 2024.  The Company recognizes revenue upon transfer of control of promised goods or services in a contract. Transfer of control generally occurs at the point of shipment or upon delivery to the customer.

[0001375365-25-000004:auditors_report:26]
We identified the auditing of revenue recognition from contracts with customers as a critical audit matter because it involved especially challenging auditor judgment due to the high degree of auditor effort required in performing audit procedures.

[0001375365-25-000004:auditors_report:27]
The primary procedures we performed to address this critical audit matter included:

[0001375365-25-000004:auditors_report:28]
•Evaluating revenue transactions on a sample basis by obtaining and inspecting source documents, such as purchase orders, contracts, invoices, proof of shipment or proof of delivery, and proof of subsequent cash receipts.

[0001375365-25-000004:auditors_report:29]
•Inspecting a sample of credit memos and the related invoice to assess whether they were recorded in the appropriate period.

[0001375365-25-000004:auditors_report:30]
•Evaluating the completeness and accuracy of information produced by the entity.

[0001375365-25-000004:auditors_report:31]
•Evaluating the completeness and accuracy of the terms and conditions in certain customer contracts, including confirming the terms and conditions of contracts.

[0001375365-25-000004:auditors_report:32]
/s/ BDO USA, P.C.

[0001375365-25-000004:auditors_report:33]
We have served as the Company's auditor since 2024.

[0001375365-25-000004:auditors_report:34]
San Jose, California

[0001375365-25-000004:auditors_report:35]
February 25, 2025

[0001375365-25-000004:auditors_report:36]
SMCI | 2024 Form 10-K | 65

[0001375365-25-000004:auditors_report:37]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-25-000004:auditors_report:38]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-25-000004:auditors_report:39]
Opinion on the Financial Statements

[0001375365-25-000004:auditors_report:40]
We have audited, before the effects of the adjustments to retrospectively apply the stock split discussed in Note 1 to the consolidated financial statements, the consolidated balance sheet of Super Micro Computer, Inc. and subsidiaries (the "Company") as of June 30, 2023, the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows, for the years ended June 30, 2023 and 2022, and the related notes  (collectively referred to as the "financial statements") (the June 30, 2023 and 2022 financial statements before the effects of the retrospective adjustments discussed in Note 1 to the financial statements are not presented herein). In our opinion, the 2023 and 2022 financial statements, before the effects of the adjustments to retrospectively apply the stock split discussed in Note 1 to the financial statements, present fairly, in all material respects, the financial position of the Company as of June 30, 2023, and the results of its operations and its cash flows for the years ended June 30, 2023 and 2022, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-25-000004:auditors_report:41]
We were not engaged to audit, review, or apply any procedures to the adjustments to retrospectively apply the stock split discussed in Note 1 to the financial statements, and accordingly, we do not express an opinion or any other form of assurance about whether such retrospective adjustments are appropriate and have been properly applied. Those retrospective adjustments were audited by the successor auditor.

[0001375365-25-000004:auditors_report:42]
Basis for Opinion

[0001375365-25-000004:auditors_report:43]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000004:auditors_report:44]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001375365-25-000004:auditors_report:45]
/s/ DELOITTE & TOUCHE LLP

[0001375365-25-000004:auditors_report:46]
San Jose, California

[0001375365-25-000004:auditors_report:47]
August 25, 2023

[0001375365-25-000004:auditors_report:48]
We began serving as the Company’s auditor in 2003. In 2023, we became the predecessor auditor.

[0001375365-25-000004:auditors_report:49]
SMCI | 2024 Form 10-K | 66

[0001375365-25-000004:auditors_report:50]
SUPER MICRO COMPUTER, INC.


## item_9a

[0001375365-25-000004:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-25-000004:item_9a:2]
Attached as exhibits to this Form 10-K are certifications of our Chief Executive Officer and Chief Financial Officer, which are required in accordance with Rule 13a-14 of the Exchange Act. This “Controls and Procedures” section includes information concerning the internal controls and controls evaluation referred to in the certifications.

[0001375365-25-000004:item_9a:3]
Management’s Evaluation of Disclosure Controls and Procedures

[0001375365-25-000004:item_9a:4]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for evaluating the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the period covered by this report. Our disclosure controls and procedures are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Exchange Act is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure and is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC. Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of June 30, 2024 due to the material weaknesses in our internal control over financial reporting described below. Notwithstanding the identified material weaknesses, management believes and has concluded that the consolidated financial statements included in this Annual Report fairly present, in all material respects, our financial condition, results of operations and cash flows for the periods presented in conformity with GAAP.

[0001375365-25-000004:item_9a:5]
SMCI | 2024 Form 10-K | 121

[0001375365-25-000004:item_9a:6]
Management’s Report on Internal Control over Financial Reporting

[0001375365-25-000004:item_9a:7]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over our financial reporting, as such term is defined under Exchange Act Rules 13a-15(f) and 15d-15(f), to provide reasonable assurance to management regarding the preparation and fair presentation of published financial statements. In evaluating the effectiveness of our internal control over financial reporting as of June 30, 2024, management used the framework set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control-Integrated Framework (2013).

[0001375365-25-000004:item_9a:8]
Based on such evaluation, in connection with preparing the consolidated financial statements included in Part II, Item 8, “Financial Statements and Supplementary Data” of this Annual Report on Form 10-K, management identified certain material weaknesses in our internal control over financial reporting. A material weakness is a deficiency, or a combination of deficiencies in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim consolidated financial statements will not be prevented or detected on a timely basis. The identified material weaknesses pertain to: (i) information technology general controls for certain IT systems that support the Company's financial reporting process were not appropriately identified, designed or implemented; (ii) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (iii) controls and documentation thereof, over the review and approval of manual journal entries were not properly designed and appropriately implemented to prevent unauthorized access to post journal entries; (iv) controls over the completeness and accuracy of information produced by the entity impacting multiple financial statement areas were not properly documented; and (v) management did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new leasing arrangements and new related party transactions.

[0001375365-25-000004:item_9a:9]
The above material weaknesses could have increased the risk of unauthorized access to certain information technology systems that support our financial reporting processes, manipulation of data that we use to produce our financial statements, and/or lack of complete and accurate information, which could lead to financial misstatements and affect our ability to report our information on a timely basis.

[0001375365-25-000004:item_9a:10]
We have concluded that our internal control over financial reporting was not effective as of June 30, 2024 due to the existence of material weaknesses in such controls as described above. As of the date hereof, we have not remediated any of those material weaknesses.

[0001375365-25-000004:item_9a:11]
Inherent Limitations on Effectiveness of Controls

[0001375365-25-000004:item_9a:12]
Because of inherent limitations, internal control over financial reporting may not prevent or detect misstatements and projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-25-000004:item_9a:13]
Our independent registered public accounting firm, BDO USA, P.C., has audited the Company's consolidated financial statements as of June 30, 2024, and for the fiscal year then ended, included in this Annual Report which is contained in Item 8, “Financial Statements and Supplementary Data” and also as part of its audit, has issued an attestation report on our internal control over financial reporting, which is contained below.

[0001375365-25-000004:item_9a:14]
Remediation Plan and Status

[0001375365-25-000004:item_9a:15]
Our management is committed to remediating the material weaknesses that we have identified and fostering continuous improvement in our internal controls. We are evaluating the material weaknesses described above and designing plans to remediate these weaknesses and enhancing our internal control environment. These plans include:

[0001375365-25-000004:item_9a:16]
•hiring additional qualified technical accounting, financial reporting, and internal audit personnel with public company experience; expanding other non-finance teams that are responsible for control execution in order to provide additional capacity and expertise, particularly as our revenue continues to increase;

[0001375365-25-000004:item_9a:17]
•continuing to conduct more training sessions for our accounting and finance staff focused on sufficiently documenting our internal control over the completeness and accuracy of the information we use to support our financial reporting;

[0001375365-25-000004:item_9a:18]
SMCI | 2024 Form 10-K | 122

[0001375365-25-000004:item_9a:19]
•reviewing the organization of our IT group with the goal of ensuring the organization can fully support the internal control needs of our company;

[0001375365-25-000004:item_9a:20]
•designing additional monitoring controls over manual journal entries, and actions of people with overlapping duties; and monitoring controls over access and change management for the IT systems to which this material weakness relates; and

[0001375365-25-000004:item_9a:21]
•upgrading our IT systems to include features that will scale, automate and strengthen our internal controls.

[0001375365-25-000004:item_9a:22]
We are committed to a strong internal control environment and to remediating these material weaknesses as soon as possible. We will determine that our material weaknesses have been fully remediated only after we have (i) implemented and tested the necessary changes and (ii) observed the remediated controls operate for a sufficient period of time for us to determine that such controls are operating effectively. We may also conclude that additional measures or costs are required to remediate the material weaknesses in our internal control over financial reporting. We will monitor and report the effectiveness of our remediation plan and refine our remediation plan as appropriate.

[0001375365-25-000004:item_9a:23]
Changes in Internal Control over Financial Reporting

[0001375365-25-000004:item_9a:24]
Except for the material weaknesses identified above, there was no change in the Company’s internal control over financial reporting that occurred during the quarter ended June 30, 2024 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-25-000004:item_9a:25]
SMCI | 2024 Form 10-K | 123

[0001375365-25-000004:item_9a:26]
Report of Independent Registered Public Accounting Firm

[0001375365-25-000004:item_9a:27]
Stockholders and Board of Directors

[0001375365-25-000004:item_9a:28]
Super Micro Computer, Inc.

[0001375365-25-000004:item_9a:29]
San Jose, California

[0001375365-25-000004:item_9a:30]
Opinion on Internal Control over Financial Reporting

[0001375365-25-000004:item_9a:31]
We have audited Super Micro Computer, Inc.’s (the “Company’s”) internal control over financial reporting as of June 30, 2024, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (the “COSO criteria”). In our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of June 30, 2024, based on the COSO criteria.

[0001375365-25-000004:item_9a:32]
We do not express an opinion or any other form of assurance on management’s statements referring to any corrective actions taken by the Company after the date of management’s assessment.

[0001375365-25-000004:item_9a:33]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the consolidated balance sheet of the Company as of June 30, 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for the year then ended, and the related notes (collectively referred to as “the consolidated financial statements”) and our report dated February 25, 2025 expressed an unqualified opinion thereon.

[0001375365-25-000004:item_9a:34]
Basis for Opinion

[0001375365-25-000004:item_9a:35]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Item 9A, Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000004:item_9a:36]
We conducted our audit of internal control over financial reporting in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audit also included performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-25-000004:item_9a:37]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company’s annual or interim financial statements will not be prevented or detected on a timely basis. Material weaknesses were identified and described in management's assessment regarding the following: (1) information technology general controls (“ITGCs”) for certain IT systems that support the Company's financial reporting process were not appropriately identified, designed or implemented; (2) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (3) controls and documentation thereof, over the review and approval of manual journal entries were not properly designed and appropriately implemented to prevent unauthorized access to post journal entries; (4) controls over the completeness and accuracy of information produced by the entity impacting multiple financial statement areas were not properly documented; and (5) management did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new leasing arrangements and new related party transactions.

[0001375365-25-000004:item_9a:38]
These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements, and this report does not affect our report dated February 25, 2025 on those consolidated financial statements.

[0001375365-25-000004:item_9a:39]
SMCI | 2024 Form 10-K | 124

[0001375365-25-000004:item_9a:40]
Definition and Limitations of Internal Control over Financial Reporting

[0001375365-25-000004:item_9a:41]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-25-000004:item_9a:42]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-25-000004:item_9a:43]
/s/ BDO USA, P.C.

[0001375365-25-000004:item_9a:44]
San Jose, California

[0001375365-25-000004:item_9a:45]
February 25, 2025

[0001375365-25-000004:item_9a:46]
SMCI | 2024 Form 10-K | 125
