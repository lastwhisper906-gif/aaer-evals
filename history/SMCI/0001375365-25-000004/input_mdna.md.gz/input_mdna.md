# SMCI MD&A — 0001375365-25-000004


## mdna

[0001375365-25-000004:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-25-000004:mdna:2]
Overview

[0001375365-25-000004:mdna:3]
We are a Silicon Valley-based provider of Rack Scale Total Solutions built from our extensive portfolio of server and storage systems. Our systems are application-optimized high performance and high-efficiency server and storage systems developed for a variety of markets, including the cloud service provider market, the enterprise market, the OEM appliance and large data center market, and the emerging 5G/Telco/Edge/IOT market. Our Total IT Solutions include direct liquid-cooled and air-cooled rack-scale solutions, complete servers, storage systems, modular blade servers, blades, workstations, networking devices, server sub-systems, server management and security software. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-25-000004:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2024, 2023 and 2022, our net income was $1.15 billion, $640.0 million and $285.2 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products and deliver Total IT Solutions that combine server, storage, networking and software that is integrated, validated and delivered at the rack and cluster (multi-rack) level. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise and large data center customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin, operating margin, and growth in net income per common share. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new GPUs, microprocessors and storage technologies. As a result, we monitor the product introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-25-000004:mdna:5]
Artificial Intelligence and Data Centers

[0001375365-25-000004:mdna:6]
The increased use of AI, which has required increased datacenter capabilities, has substantially increased demand for our products in the recent past. We expect that the AI market, and thus the need for additional datacenter capabilities and liquid cooling, will continue to strengthen, and we will continue to enhance our product capabilities and breadth of our service offerings to meet the demand of the AI market and datacenters. We believe that time to market, quality and optimized design of our AI products meet the unique needs of the AI market, which differentiates us from many of our competitors and will lead us to secure an even greater market share going forward.

[0001375365-25-000004:mdna:7]
Macroeconomic Factors

[0001375365-25-000004:mdna:8]
Our business and financial outlook have experienced, and may continue to face, challenges due to adverse macroeconomic conditions and uncertainties. These factors encompass labor shortages, disruptions in the supply chain, inflation, higher interest rates, and fluctuations in capital markets.

[0001375365-25-000004:mdna:9]
Financial Highlights

[0001375365-25-000004:mdna:10]
The following is a summary of financial highlights of fiscal years 2024 and 2023:

[0001375365-25-000004:mdna:11]
•Net sales increased by 110.4% in fiscal year 2024 as compared to fiscal year 2023.

[0001375365-25-000004:mdna:12]
•Gross margin declined to 13.8% in fiscal year 2024 from 18.0% in fiscal year 2023, primarily due to our strategy to offer competitive pricing to gain market share, change in product and customer mix, and higher manufacturing related expenses.

[0001375365-25-000004:mdna:13]
SMCI | 2024 Form 10-K | 49

[0001375365-25-000004:mdna:14]
•Operating expenses increased by 63.0% in fiscal year 2024 as compared to fiscal year 2023, primarily due to higher headcount including salary increases and stock-based compensation.

[0001375365-25-000004:mdna:15]
•Net income increased to $1,152.7 million in fiscal year 2024 as compared to $640.0 million in fiscal year 2023, which was primarily due to the higher net sales, partially offset by lower gross margin and higher operating expenses in fiscal year 2024 as compared to fiscal year 2023.

[0001375365-25-000004:mdna:16]
•Our cash and cash equivalents were $1,669.8 million and $440.5 million at the end of fiscal years 2024 and 2023, respectively. In fiscal year 2024, net increase in cash, cash equivalents and restricted cash of $1,229.3 million, comprised of $3,911.7 million provided by financing activities primarily due to proceeds from our offerings of common stock and sale of our 2029 Convertible Notes offset by $2,486.0 million used in operating activities primarily due to cash required for working capital, and $194.2 million cash used in investing activities primarily due to $124.3 million in purchases of property and equipment.

[0001375365-25-000004:mdna:17]
Critical Accounting Estimates

[0001375365-25-000004:mdna:18]
General

[0001375365-25-000004:mdna:19]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis based on a) historical experience, and b) assumptions we believe to be reasonable under the circumstances and are not readily apparent from other sources, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows. These estimates have not fluctuated significantly for fiscal year 2024 compared to prior fiscal years.

[0001375365-25-000004:mdna:20]
A summary of significant accounting policies is included in Note 1, “Organization and Summary of Significant Accounting Policies” in the Notes to the Consolidated Financial Statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-25-000004:mdna:21]
Revenue Recognition

[0001375365-25-000004:mdna:22]
We generate revenue from the sale of server and storage systems, including systems and related services, subsystems and accessories.

[0001375365-25-000004:mdna:23]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. As part of determining the transaction price in contracts with customers, we estimate reserves for future sales returns based on a review of our history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs.

[0001375365-25-000004:mdna:24]
SMCI | 2024 Form 10-K | 50

[0001375365-25-000004:mdna:25]
We allocate the transaction price of each customer contract to each performance obligation based on the relative standalone selling price ("SSP") for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the respective performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we apply judgment to estimate the SSP. For substantially all of the performance obligations, we are able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-25-000004:mdna:26]
Revenue is recognized either over time or at a point in time, depending on when control of the underlying products or services are transferred to the customer, which may require judgment. Revenue is recognized at a point in time for products. Revenue is recognized over time for services provided.

[0001375365-25-000004:mdna:27]
Inventories

[0001375365-25-000004:mdna:28]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of raw materials (principally electronic components), work in process (principally products being assembled) and finished goods (principally finished products and products ready for sale). We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-25-000004:mdna:29]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-25-000004:mdna:30]
Income Taxes

[0001375365-25-000004:mdna:31]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or when loss or credit carryforwards are utilized. In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001375365-25-000004:mdna:32]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and reflect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-25-000004:mdna:33]
SMCI | 2024 Form 10-K | 51

[0001375365-25-000004:mdna:34]
Stock-Based Compensation

[0001375365-25-000004:mdna:35]
We measure and recognize compensation expenses for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. We base initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-25-000004:mdna:36]
The fair value of RSUs and PRSUs is based on the closing market price of our common stock on the date of the grant. The fair value of stock options with a market condition is estimated, at the date of grant, using the Monte Carlo Simulation model. We estimate the fair value of stock options granted using a Black-Scholes option pricing model. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the historical volatility of our common stock. The assumptions used to determine the fair value of the option awards represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. Our use of the Black-Scholes option-pricing model requires the input of highly subjective assumptions. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.

[0001375365-25-000004:mdna:37]
Results of Operations

[0001375365-25-000004:mdna:38]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of net sales.

[0001375365-25-000004:mdna:39]
|  | Years Ended June 30, |  |
|  | 2024 |  | 2023 |  | 2022 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 86.2 | % |  | 82.0 | % |  | 84.6 | % |  |
| Gross profit | 13.8 | % |  | 18.0 | % |  | 15.4 | % |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development | 3.1 | % |  | 4.3 | % |  | 5.2 | % |  |
| Sales and marketing | 1.3 | % |  | 1.6 | % |  | 1.7 | % |  |
| General and administrative | 1.3 | % |  | 1.4 | % |  | 2.0 | % |  |
| Total operating expenses | 5.7 | % |  | 7.3 | % |  | 8.9 | % |  |
| Income from operations | 8.1 | % |  | 10.7 | % |  | 6.5 | % |  |
| Other income, net | 0.1 | % |  | 0.1 | % |  | 0.2 | % |  |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  |
| Income before income tax provision | 8.1 | % |  | 10.7 | % |  | 6.6 | % |  |
| Income tax provision | (0.4) | % |  | (1.6) | % |  | (1.0) | % |  |
| Share of income (loss) from equity investee, net of taxes | — | % | * | (0.1) | % |  | — | % | * |
| Net income | 7.7 | % |  | 9.0 | % |  | 5.6 | % |  |

[0001375365-25-000004:mdna:40]
* Represents an amount less than 0.1%.

[0001375365-25-000004:mdna:41]
SMCI | 2024 Form 10-K | 52

[0001375365-25-000004:mdna:42]
Net Sales

[0001375365-25-000004:mdna:43]
Net sales primarily consist of sales of our server and storage solutions, including systems and related services, subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of servers and racks sold and the average selling prices per server or rack. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the speed, functionality and performance of key components such as CPUs, GPUs, SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-25-000004:mdna:44]
As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as CPUs, GPUs, SSDs and memory.

[0001375365-25-000004:mdna:45]
The percentage of our net sales represented by sales of server and storage systems increased to 94.6% in fiscal year 2024 compared to 92.2% in fiscal year 2023 and 85.9% in fiscal year 2022, and the percentage of our net sales represented by sales of subsystems and accessories was 5.4% in fiscal year 2024, 7.8% in fiscal year 2023 and 14.1% in fiscal year 2022. During fiscal year 2024 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales for our subsystems and accessories is primarily due to increased demand for accessories sold to data center customers as more accessories and spares were purchased in conjunction with the increased volume of full systems and servers.

[0001375365-25-000004:mdna:46]
The following table presents net sales by product type for fiscal years 2024, 2023 and 2022 (dollars in millions):

[0001375365-25-000004:mdna:47]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 14,185.2 |  |  | $ | 6,569.8 |  |  | $ | 4,463.8 |  |  | $ | 7,615.4 |  |  | 115.9 | % |  | $ | 2,106.0 |  |  | 47.2 | % |
| Percentage of total net sales | 94.6 | % |  | 92.2 | % |  | 85.9 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 804.0 |  |  | 553.7 |  |  | 732.3 |  |  | 250.3 |  |  | 45.2 | % |  | (178.6) |  |  | (24.4) | % |
| Percentage of total net sales | 5.4 | % |  | 7.8 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 14,989.2 |  |  | $ | 7,123.5 |  |  | $ | 5,196.1 |  |  | $ | 7,865.7 |  |  | 110.4 | % |  | $ | 1,927.4 |  |  | 37.1 | % |

[0001375365-25-000004:mdna:48]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:49]
During fiscal year 2024 we experienced increased net sales from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to the strong demand for GPU based rack-scale solutions, including liquid-cooled and air-cooled servers which are generally more complex and of higher value, resulting in an increase of average selling prices ("ASP"). The year-over-year increase in net sales for our subsystems and accessories is primarily due to increased demand of accessories sold to our larger enterprise and data center customers as more accessories and spares were purchased in conjunction with the increased volume of full systems and servers. Our services and software net sales, included in server and storage systems net sales, increased by $53.8 million year-over-year.

[0001375365-25-000004:mdna:50]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:51]
During fiscal year 2023 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to the strong demands from such customers for GPU, HPC, and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling prices. The year-over-year decrease in net sales of subsystems and accessories was primarily due to our emphasis on selling full systems and servers. Our services and software revenue, included in server and storage systems revenue, increased by $28.0 million year-over-year.

[0001375365-25-000004:mdna:52]
SMCI | 2024 Form 10-K | 53

[0001375365-25-000004:mdna:53]
The following table presents percentages of net sales by geographic region for fiscal years 2024, 2023 and 2022 (dollars in millions):

[0001375365-25-000004:mdna:54]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| United States | $ | 10,187.2 |  |  | $ | 4,834.1 |  |  | $ | 3,035.5 |  |  | $ | 5,353.1 |  |  | 110.7 | % |  | $ | 1,798.6 |  |  | 59.3 | % |
| Percentage of total net sales | 68.0 | % |  | 67.9 | % |  | 58.4 | % |  |  |  |  |  |  |  |  |
| Asia | 2,912.6 |  |  | 1,050.8 |  |  | 1,139.9 |  |  | 1,861.8 |  |  | 177.2 | % |  | (89.1) |  |  | (7.8) | % |
| Percentage of total net sales | 19.4 | % |  | 14.7 | % |  | 21.9 | % |  |  |  |  |  |  |  |  |
| Europe | 1,294.0 |  |  | 1,003.1 |  |  | 825.2 |  |  | 290.9 |  |  | 29.0 | % |  | 177.9 |  |  | 21.6 | % |
| Percentage of total net sales | 8.6 | % |  | 14.1 | % |  | 15.9 | % |  |  |  |  |  |  |  |  |
| Others | 595.4 |  |  | 235.5 |  |  | 195.5 |  |  | 359.9 |  |  | 152.8 | % |  | 40.0 |  |  | 20.5 | % |
| Percentage of total net sales | 4.0 | % |  | 3.3 | % |  | 3.7 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 14,989.2 |  |  | $ | 7,123.5 |  |  | $ | 5,196.1 |  |  | $ | 7,865.7 |  |  | 110.4 | % |  | $ | 1,927.4 |  |  | 37.1 | % |

[0001375365-25-000004:mdna:55]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:56]
The year-over-year increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States. The year-over-year increase of net sales in the regions outside the United States is mainly due to an increase in net sales in Singapore, Taiwan, South Africa and Germany, including the increase in demand from customers for GPU servers in those countries.

[0001375365-25-000004:mdna:57]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:58]
The year-over-year increase in overall net sales is the result of increased selling prices and units shipped of product sold especially to large enterprise and datacenter customers. The United States experienced the highest percentage growth among all regions. This is due to increased demand from datacenter customers in the United States for GPU, HPC, and rack-scale solutions. The year-over-year decrease in Asia is mainly due to economic slowdown in China and Japan during fiscal year 2023 which heavily reduced the sales activities in that region.

[0001375365-25-000004:mdna:59]
Cost of Sales, Gross Profit and Gross Margin

[0001375365-25-000004:mdna:60]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of components and materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges. The primary factors that impact our cost of sales are the volume and mix of products sold, changes in the cost of components, changes in logistic costs, changes in salary and benefits and overhead costs related to production as well as economies of scale gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in our costs are not matched by corresponding changes in our ASPs. Our cost of sales as a percentage of net sales is also impacted by the timing and extent to which we add to, and are able to efficiently utilize, our manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions. We expect inventory levels to continue to increase to support the future growth of our business. Certain materials used in the manufacturing of our products are available from a limited number of suppliers and we expect that this trend will continue in the future.

[0001375365-25-000004:mdna:61]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 4.3%, 6.6% and 8.3% of our cost of sales for fiscal years 2024, 2023 and 2022, respectively. For further details on our dealings with related parties, see Note 10, “Related Party Transactions” in the Notes to the Consolidated Financial Statements.

[0001375365-25-000004:mdna:62]
SMCI | 2024 Form 10-K | 54

[0001375365-25-000004:mdna:63]
Cost of sales and gross margin for fiscal years 2024, 2023 and 2022 are as follows (dollars in millions):

[0001375365-25-000004:mdna:64]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 12,927.8 |  |  | $ | 5,840.5 |  |  | $ | 4,396.1 |  |  | $ | 7,087.3 |  |  | 121.3 | % |  | $ | 1,444.4 |  |  | 32.9 | % |
| Gross profit | 2,061.4 |  |  | 1,283.0 |  |  | 800.0 |  |  | 778.4 |  |  | 60.7 | % |  | 483.0 |  |  | 60.4 | % |
| Gross margin | 13.8 | % |  | 18.0 | % |  | 15.4 | % |  |  |  | (4.2) | % |  |  |  | 2.6 | % |

[0001375365-25-000004:mdna:65]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:66]
The year-over-year increase in cost of sales was primarily attributed to an increase of $7,006.7 million in costs of components, materials and contract manufacturing expenses primarily related to the increase in shipments of GPU servers, HPC, and rack scale solutions which have higher costs, a $52.3 million increase in inventory write-down adjustments, a $19.6 million increase in overhead costs which includes labor costs attributed to increase of operation activities and a $8.7 million increase in freight charges.

[0001375365-25-000004:mdna:67]
The year-over-year decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-25-000004:mdna:68]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:69]
The year-over-year increase in cost of sales was primarily attributed to an increase of $1,379.6 million in costs of components, materials and contract manufacturing expenses primarily related to the increased shipments of our products, a $59.2 million increase in overhead costs which includes labor costs attributed to increase of operation activities, a $36.6 million increase in inventory reserves, and a $13.6 million increase in other cost of sales partially offset by a $44.6 million decrease in freight charges due to a reduced need to expedite shipments caused by disruptions in the supply chain caused by the COVID-19 pandemic.

[0001375365-25-000004:mdna:70]
The year-over-year increase in the gross margin percentage was primarily due to favorable product and customer mix and lower other cost of goods sold as a percentage of sales, based on higher volumes.

[0001375365-25-000004:mdna:71]
Operating Expenses

[0001375365-25-000004:mdna:72]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-25-000004:mdna:73]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for tradeshows, sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-25-000004:mdna:74]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, corporate governance and compliance, outside legal, audit, tax fees, insurance and credit losses on accounts receivable.

[0001375365-25-000004:mdna:75]
Operating expenses for fiscal years 2024, 2023 and 2022 are as follows (dollars in millions):

[0001375365-25-000004:mdna:76]
SMCI | 2024 Form 10-K | 55

[0001375365-25-000004:mdna:77]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 463.5 |  |  | $ | 307.3 |  |  | $ | 272.3 |  |  | $ | 156.2 |  |  | 50.8 | % |  | $ | 35.0 |  |  | 12.9 | % |
| Percentage of total net sales | 3.1 | % |  | 4.3 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 189.7 |  |  | 115.0 |  |  | 90.1 |  |  | 74.7 |  |  | 65.0 | % |  | 24.9 |  |  | 27.6 | % |
| Percentage of total net sales | 1.3 | % |  | 1.6 | % |  | 1.7 | % |  |  |  |  |  |  |  |  |
| General and administrative | 197.4 |  |  | 99.6 |  |  | 102.4 |  |  | 97.8 |  |  | 98.2 | % |  | (2.8) |  |  | (2.7) | % |
| Percentage of total net sales | 1.3 | % |  | 1.4 | % |  | 2.0 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 850.6 |  |  | $ | 521.9 |  |  | $ | 464.8 |  |  | $ | 328.7 |  |  | 63.0 | % |  | $ | 57.1 |  |  | 12.3 | % |

[0001375365-25-000004:mdna:78]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:79]
Research and development expenses. The year-over-year increase in research and development expenses was driven by a $140.4 million increase in employee related costs primarily due to stock-based compensation increases of $84.2 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $17.1 million increase in product development costs to support next generation products and technologies, offset by a $1.3 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-25-000004:mdna:80]
Sales and marketing expenses. The year-over-year increase in sales and marketing expenses was driven by a $64.8 million increase in employee related costs primarily due to stock-based compensation increases of $16.6 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $10.6 million increase in advertising and other expenses offset by a $0.7 million increase in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000004:mdna:81]
General and administrative expenses. The year-over-year increase in general and administrative expenses was driven by a $74.4 million increase in employee related costs primarily due to stock-based compensation increases of $65.0 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, and a $23.4 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000004:mdna:82]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:83]
Research and development expenses. The year-over-year increase in research and development expenses was driven by a $43.5 million increase in employee related costs primarily due to stock-based compensation increases, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $2.6 million increase in product development costs to support the development of next generation products and technologies, offset by a $11.1 million increase in research and development credits received from certain suppliers and customers.

[0001375365-25-000004:mdna:84]
Sales and marketing expenses. The year-over-year increase in sales and marketing expenses was driven by a $23.8 million increase in employee related costs primarily due to stock-based compensation increases, salary increases and higher headcount as we expanded our workforce and invested in key talent and a $4.6 million increase in travel and trade show expenses to drive new sales opportunities for our products and customer support, offset by a $3.5 million increase in marketing development funds received.

[0001375365-25-000004:mdna:85]
General and administrative expenses. The year-over-year decrease in general and administrative expenses was primarily due to a $5.2 million decrease in professional fees and other, a $2.0 million decrease in litigation settlement expenses relating to a derivative lawsuit, partially offset by an increase of $4.4 million in compensation expenses associated with the cost of equity awards.

[0001375365-25-000004:mdna:86]
Interest Expense and Other Income, Net

[0001375365-25-000004:mdna:87]
Other income, net consists primarily of interest earned on our investment and cash deposits and foreign exchange gains and losses.

[0001375365-25-000004:mdna:88]
SMCI | 2024 Form 10-K | 56

[0001375365-25-000004:mdna:89]
Interest expense represents interest expense on our term loans and lines of credit and amortization of the 2029 Convertible Notes issuance costs.

[0001375365-25-000004:mdna:90]
Interest expense and other income, net for fiscal years 2024, 2023 and 2022 are as follows (dollars in millions):

[0001375365-25-000004:mdna:91]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Other income, net | $ | 22.7 |  |  | $ | 3.6 |  |  | $ | 8.1 |  |  | $ | 19.1 |  |  | 530.6 | % |  | $ | (4.5) |  |  | (55.6) | % |
| Interest expense | (19.4) |  |  | (10.5) |  |  | (6.4) |  |  | (8.9) |  |  | 84.8 | % |  | (4.1) |  |  | 64.1 | % |
| Interest expense and other income (expense), net | $ | 3.3 |  |  | $ | (6.9) |  |  | $ | 1.7 |  |  | $ | 10.2 |  |  | (147.8) | % |  | $ | (8.6) |  |  | (505.9) | % |

[0001375365-25-000004:mdna:92]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:93]
The increase in Other income, net of $19.1 million was driven by an increase of $26.1 million in interest income due to higher balances held in interest-bearing deposit accounts during the year, and an increase in foreign currency exchange gain of $6.1 million due to a strong US dollar, offset by a $13.1 million investment and impairment loss in equity securities. The increase in interest expense of $8.9 million was due to higher borrowing and higher interest rates on our outstanding line of credit and term loan balances.

[0001375365-25-000004:mdna:94]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:95]
The change of $8.6 million in interest and other income (expense), net was primarily attributable to a $4.5 million decrease in foreign exchange gain due to unfavorable currency fluctuations primarily related to our borrowing facilities in Taiwan and a $4.1 million increase in interest expense due to an increase in interest rates on our outstanding loan balances.

[0001375365-25-000004:mdna:96]
Provision for Income Taxes

[0001375365-25-000004:mdna:97]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock-based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Note 12, “Income Taxes” in the Notes to the Consolidated Financial Statements in this Annual Report.

[0001375365-25-000004:mdna:98]
Provision for income taxes and effective tax rates for fiscal years 2024, 2023 and 2022 are as follows (dollars in millions):

[0001375365-25-000004:mdna:99]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 63.3 |  |  | $ | 110.7 |  |  | $ | 52.9 |  |  | $ | (47.4) |  |  | (42.8) | % |  | $ | 57.8 |  |  | 109.3 | % |
| Percentage of total net sales | 0.4 | % |  | 1.6 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |
| Effective tax rate | 5.2 | % |  | 14.7 | % |  | 15.7 | % |  |  |  |  |  |  |  |  |

[0001375365-25-000004:mdna:100]
SMCI | 2024 Form 10-K | 57

[0001375365-25-000004:mdna:101]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:102]
The year-over-year decrease in the effective tax rate is attributable to higher tax deductions from stock-based compensation, an increase in the R&D tax credit. As a result of these favorable elements which were partially offset by certain unfavorable items including an increase in IRC section 162(m) officers' compensation tax add back, the total effective tax rate decreased by 9.5%, from 14.7% in fiscal year 2023, to 5.2% in fiscal year 2024.

[0001375365-25-000004:mdna:103]
The Organization for Economic Co-operation and Development (the “OECD”) has announced an Inclusive Framework on Base Erosion and Profit Shifting including Pillar Two Model Rules for a new 15% global minimum tax applicable to large multinational corporations. Certain jurisdictions, including many countries in which we operate, have enacted Pillar Two legislation that will start to become effective for our fiscal year 2025. The OECD, and its member countries, continue to release new guidance and legislation on Pillar Two and we continue to evaluate the impact on our financial position of the global implementation of these rules. Based on enacted laws, Pillar Two is not expected to materially impact our effective tax rate or cash flows in the next fiscal year. We continue to evaluate the impact of proposed and enacted legislative changes on our effective tax rate and cash flows as new guidance becomes available. New legislation or guidance could change our current assessment.

[0001375365-25-000004:mdna:104]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:105]
The year-over-year decrease in the effective tax rate is attributable to higher tax deductions from disqualified disposition of stock-based compensation of $20.8 million, an increase in the R&D tax credit of $11.5 million, and a $4.1 million increase in foreign-derived income. As a result of these favorable elements which were partially offset by certain unfavorable items including an increase in state taxes, the total effective tax rate decreased by 1%, from 15.7% in fiscal year 2022, to 14.7% in fiscal year 2023.

[0001375365-25-000004:mdna:106]
Share of Income (Loss) from Equity Investee, Net of Taxes

[0001375365-25-000004:mdna:107]
Share of income (loss) from equity investee, net of taxes represents our share of income (loss) from the Corporate Venture in which we have a 30% ownership.

[0001375365-25-000004:mdna:108]
Share of income (loss) from equity investee, net of taxes for fiscal years 2024, 2023 and 2022 are as follows (dollars in millions):

[0001375365-25-000004:mdna:109]
|  | Years Ended June 30, |  | 2024 over 2023 Change |  | 2023 over 2022 Change |
|  | 2024 |  | 2023 |  | 2022 |  | $ |  | % |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 1.8 |  |  | $ | (3.6) |  |  | $ | 1.2 |  |  | $ | 5.4 |  |  | (150.0) | % |  | $ | (4.8) |  |  | (400.0) | % |
| Percentage of total net sales | — | % | * | (0.1) | % |  | — | % | * |  |  |  |  |  |  |  |

[0001375365-25-000004:mdna:110]
* Represents an amount less than 0.1%.

[0001375365-25-000004:mdna:111]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000004:mdna:112]
The period-over-period increase of $5.4 million in share of income from equity investee, net of taxes was primarily due to improvement in profitability from increased sales of the Corporate Venture.

[0001375365-25-000004:mdna:113]
Fiscal Year 2023 Compared with Fiscal Year 2022

[0001375365-25-000004:mdna:114]
The period-over-period decrease of $4.8 million in share of income from equity investee, net of taxes was primarily due to lower net income recognized by the Corporate Venture.

[0001375365-25-000004:mdna:115]
SMCI | 2024 Form 10-K | 58

[0001375365-25-000004:mdna:116]
Liquidity and Capital Resources

[0001375365-25-000004:mdna:117]
We have financed our growth primarily with funds generated from operations, utilizing borrowing facilities, selling our common stock, and issuing convertible notes. Our recent drivers of liquidity changes have included an increase in the need for working capital due to higher levels of inventory required by growing revenues and to a lesser extent longer supply chain lead times on certain key components. Our cash and cash equivalents were $1,669.8 million and $440.5 million as of June 30, 2024 and 2023, respectively. Our cash and cash equivalents in foreign locations was $337.3 million and $192.3 million as of June 30, 2024 and 2023, respectively.

[0001375365-25-000004:mdna:118]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-25-000004:mdna:119]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these consolidated financial statements. Throughout the past fiscal year, we have strategically enhanced our liquidity by securing and expanding several of our credit facilities. These include obtaining a $50 million facility with HSBC Bank on December 7, 2023, increasing our CTBC Bank credit lines from $105 million to $185 million on February 16, 2024, renewing a $50 million credit agreement with Mega Bank on April 17, 2024, and establishing a $60 million Import and Export Trade Facility with E.SUN Bank on April 19, 2024. Additionally, on April 26, 2024, we entered into new credit facilities with Chang Hwa Bank for $20 million and NTD 300 million, as well as a $30 million loan agreement with First Commercial Bank. On November 20, 2024, we prepaid in full and terminated the 2018 Bank of America Credit Facility, the Cathay Bank Credit Agreement and the Bridge Term Loan Facility. We continue to evaluate financing options that may be required to support the growth of our business.

[0001375365-25-000004:mdna:120]
On December 5, 2023, we completed a public offering of 24,158,050 shares of common stock at $26.20 per share, with 23,151,050 shares sold by us and 1,007,000 shares sold by selling stockholders.

[0001375365-25-000004:mdna:121]
We received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by us. We did not receive any proceeds from the sale of the shares of common stock by the selling stockholders. We intend to utilize the proceeds to support our operations, including working capital needs, manufacturing capacity expansion and increased R&D investments.

[0001375365-25-000004:mdna:122]
On February 27, 2024, we issued $1,725.0 million aggregate principal amount of 2029 Convertible Notes in a private offering. The 2029 Convertible Notes are senior unsecured obligations and will mature on March 1, 2029. They may be repurchased, redeemed, or converted in accordance with their terms before that date. The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. The net proceeds from the issuance of the 2029 Convertible Notes were $1,553.7 million, net of debt issuance costs of $29.2 million and related capped call transactions of $142.1 million. The 2029 Convertible Notes and capped call transactions are discussed further in Note 8, “Convertible Notes" in the Notes to the Consolidated Financial Statements. As of June 30, 2024, we believe that none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met.

[0001375365-25-000004:mdna:123]
On March 22, 2024, we completed a public offering of 20,000,000 shares of our common stock at $87.50 per share. We received net proceeds of approximately $1.73 billion after deducting underwriting discounts and commissions and offering expenses payable by us.

[0001375365-25-000004:mdna:124]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-25-000004:mdna:125]
|  | Years Ended June 30, |  | 2024 over 2023 |  | 2023 over 2022 |  |  |
|  | 2024 |  | 2023 |  | 2022 |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (2,486.0) |  |  | $ | 663.6 |  |  | $ | (440.8) |  |  | $ | (3,149.6) |  |  | $ | 1,104.4 |  |  |  |
| Net cash used in investing activities | $ | (194.2) |  |  | $ | (39.5) |  |  | $ | (46.3) |  |  | $ | (154.7) |  |  | $ | 6.8 |  |  |  |
| Net cash provided by (used in) financing activities | $ | 3,911.7 |  |  | $ | (448.3) |  |  | $ | 522.9 |  |  | $ | 4,360.0 |  |  | $ | (971.2) |  |  |  |
| Effect of exchange rate fluctuations on cash | $ | (2.2) |  |  | $ | (3.4) |  |  | $ | (0.7) |  |  | $ | 1.2 |  |  | $ | (2.7) |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 1,229.3 |  |  | $ | 172.4 |  |  | $ | 35.1 |  |  | $ | 1,056.9 |  |  | $ | 137.3 |  |  |  |

[0001375365-25-000004:mdna:126]
SMCI | 2024 Form 10-K | 59

[0001375365-25-000004:mdna:127]
Operating Activities

[0001375365-25-000004:mdna:128]
Net cash used in operating activities increased by $3,149.6 million for fiscal year 2024 as compared to fiscal year 2023. The increase was primarily due to an increase in working capital required for customer demand and business growth. The key changes in net working capital of $3,779.5 million include increases in inventory of $3,000.0 million and accounts receivable of $1,277.3 million driven by customer demand, offset by an increase in accounts payable of $552.1 million due to increase in inventory and timing of purchases and payments to vendors. The net cash used in operating activities was partially offset by a $117.2 million increase in non-cash items, including stock-based compensation expense of $177.1 million, and an increase in net income of $512.7 million.

[0001375365-25-000004:mdna:129]
Net cash provided by operating activities increased by $1,104.4 million for fiscal year 2023 as compared to fiscal year 2022. The increase was primarily due to an increase in net cash provided from net working capital of $796.7 million, a $354.8 million increase in net income due to the increase in sales of our products and solutions, a $21.6 million increase in stock-based compensation expense as a result of an increase in the cost of equity awards, a $11.1 million decrease in unrealized gain due to currency fluctuation, and a $6.4 million increase in other non-cash items. These changes are offset by an increase of $86.2 million in deferred income taxes primarily due to an increase in capitalized research and development costs.

[0001375365-25-000004:mdna:130]
Investing Activities

[0001375365-25-000004:mdna:131]
Net cash used in investing activities increased by $154.7 million for fiscal years 2024 as compared to fiscal year 2023 primarily due to an increase in property, plant and equipment of $87.5 million, and an increase in investments in equity securities of early stage companies of $67.3 million. Increase in property, plant and equipment is primarily related to the acquisition of previously leased real estate in San Jose, California, for $80 million.

[0001375365-25-000004:mdna:132]
Net cash used in investing activities was $39.5 million and $46.3 million for fiscal years 2023 and 2022, respectively, as we invested in our Green Computing Park in San Jose to expand our manufacturing capacity and office space, expanded our Bade Facility in Taiwan and made purchases of property, plant and equipment.

[0001375365-25-000004:mdna:133]
Financing Activities

[0001375365-25-000004:mdna:134]
Net cash provided by financing activities increased by $4,360.0 million for fiscal year 2024 as compared to fiscal year 2023. The increase was primarily due to proceeds of $2,314.0 million from our offerings of common stock, net of issuance costs, $1,695.8 million of proceeds from the sale of our 2029 Convertible Notes, net of debt issuance costs, an increase of $489.5 million in proceeds from borrowings, net of repayment, and stock repurchases of $150.0 million in the fiscal year 2023, offset by $142.1 million cost of entering into capped call transactions related to our 2029 Convertible Notes and a higher withholding tax payment for equity compensation related activities of $146.2 million in the fiscal year 2024.

[0001375365-25-000004:mdna:135]
Net cash used in financing activities increased by $971.2 million for fiscal year 2023 as compared to fiscal year 2022 primarily due to repurchases of our common stock for $150.0 million reflecting our commitment to return value to our shareholders and repayment of net borrowings of $813.2 million.

[0001375365-25-000004:mdna:136]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-25-000004:mdna:137]
Refer to Note 7, “Lines of Credit and Term Loans” in the Notes to the Consolidated Financial Statements in this Annual Report for further information on our outstanding debt.

[0001375365-25-000004:mdna:138]
On February 11, 2025, we announced that we had entered into privately negotiated agreements with certain holders of the 2029 Convertible Notes to (i) purchase $700.0 million aggregate principal amount of newly issued 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”), and (ii) amend certain terms of and obtain waivers with respect to the 2029 Convertible Notes. On February 20, 2025, we executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented the amendments to the 2029 Convertible Notes and we executed an indenture related to the 2028 Convertible Notes and issued the 2028 Convertible Notes pursuant to the terms of such indenture. Refer to Note 16, “Subsequent Events,” in the Notes to the Consolidated Financial Statements in this Annual Report for further information on the issuance of the 2028 Convertible Notes and the amendment of the terms of the 2029 Convertible Notes.

[0001375365-25-000004:mdna:139]
SMCI | 2024 Form 10-K | 60

[0001375365-25-000004:mdna:140]
Capital Expenditure Requirements

[0001375365-25-000004:mdna:141]
We anticipate our capital expenditures for the fiscal year 2025 will be in range of $140.0 million to $150.0 million, relating primarily to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments including a major upgrade of our ERP system and automating certain key internal controls, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on net sales growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-25-000004:mdna:142]
We intend to continue to focus our capital expenditures in fiscal year 2025 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our office facilities and our IT system infrastructure.

[0001375365-25-000004:mdna:143]
Contractual Obligations

[0001375365-25-000004:mdna:144]
Our estimated future obligations as of June 30, 2024, include both current and long-term obligations. For our long-term debt as noted in Note 7, “Lines of Credit and Term Loans” in the Notes to the Consolidated Financial Statements, we have a current obligation of $402.3 million and a long-term obligation of $74.1 million. Additionally, as noted in Note 8, “Convertible Notes” in the Notes to the Consolidated Financial Statements, we have a convertible debt obligation of $1,725.0 million. Under our operating leases as noted in Note 9, "Leases", in the Notes to the Consolidated Financial Statements we have a current obligation of $9.3 million and a long-term obligation of $26.1 million. In June 2024, we executed a data center lease agreement and concurrently sublicensed it to another unrelated party (the “Sublicensee”) which is not reflected in the Consolidated Balance Sheets as the lease has not commenced. The future undiscounted fixed non-cancelable payment obligations pertaining to the data center lease is approximately $411.8 million. As noted in Note 13, "Commitments and Contingencies" in the Notes to the Consolidated Financial Statements, we have current obligations related to non-cancelable purchase commitments of $6.2 billion.

[0001375365-25-000004:mdna:145]
We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of

[0001375365-25-000004:mdna:146]
when the related tax settlements will become due. See Note 12, “Income Taxes” in the Notes to the Consolidated Financial Statements in this Annual Report for a discussion of income taxes.

[0001375365-25-000004:mdna:147]
Recent Accounting Pronouncements

[0001375365-25-000004:mdna:148]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Note 1, “Organization and Summary of Significant Accounting Policies” in the Notes to the Consolidated Financial Statements in this Annual Report.

[0001375365-25-000004:mdna:149]
SMCI | 2024 Form 10-K | 61
