# SMCI 8-K — 0001375365-21-000029 filed 2021-05-04

## item codes, every 8-K on or before 2021-05-07

- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2021-05-07

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-21-000029:8k_2_02:1]
EX-99.1
2
exhibit991_20210331.htm
EX-99.1

[0001375365-21-000029:8k_2_02:2]
Document

[0001375365-21-000029:8k_2_02:3]
Exhibit 99.1

[0001375365-21-000029:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2021 Financial Results

[0001375365-21-000029:8k_2_02:5]
SAN JOSE, Calif. -- May 4, 2021 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced financial results for its third quarter of fiscal year 2021 ended March 31, 2021.

[0001375365-21-000029:8k_2_02:6]
Third Quarter Fiscal Year 2021 Highlights

[0001375365-21-000029:8k_2_02:7]
•Net sales of $896 million versus $830 million in the second quarter of fiscal year 2021 and $772 million in the same quarter of last year.

[0001375365-21-000029:8k_2_02:8]
•Gross margin of 13.7% versus 16.4% in the second quarter of fiscal year 2021 and 17.3% in the same quarter of last year.

[0001375365-21-000029:8k_2_02:9]
•Net income of $18 million versus $28 million in the second quarter of fiscal year 2021 and $16 million in the same quarter of last year.

[0001375365-21-000029:8k_2_02:10]
•Diluted net income per common share of $0.35 versus $0.52 in the second quarter of fiscal year 2021 and $0.29 in the same quarter of last year.

[0001375365-21-000029:8k_2_02:11]
•Non-GAAP diluted net income per common share of $0.50 versus $0.63 in the second quarter of fiscal year 2021 and $0.84 in the same quarter of last year.

[0001375365-21-000029:8k_2_02:12]
•Cash flow used in operations of $124 million and capital expenditures of $19 million.

[0001375365-21-000029:8k_2_02:13]
Non-GAAP gross margin for the third quarter of fiscal year 2021 was 13.8%, which adds back stock-based compensation expenses of $0.4 million. Non-GAAP diluted net income per common share for the third quarter of fiscal year 2021 was $0.50, which adds back stock-based compensation expenses of $7.5 million, special performance bonuses of $2.5 million, and controls remediation expense of $1.2 million, net of the related tax effects.

[0001375365-21-000029:8k_2_02:14]
As of March 31, 2021, total cash, cash equivalents and restricted cash was $179 million and total bank debt was $85 million.

[0001375365-21-000029:8k_2_02:15]
“We are pleased to report Q3 revenue above the high end of our guidance range and deliver year-over-year growth of 16%, our strongest revenue growth rate in more than two years driven by high profile customer engagements. Notably, we strongly bucked seasonal trends in the March quarter." said Charles Liang, Chairman and CEO. "But we are not yet satisfied and aim to

[0001375365-21-000029:8k_2_02:16]
accelerate our growth with our robust pipeline of new products leveraging innovations from our key partners AMD, Intel, and NVIDIA. We are well positioned to capitalize on our numerous growth opportunities as we begin to benefit from our capacity expansion in Taiwan and the US.”

[0001375365-21-000029:8k_2_02:17]
Fourth Quarter Fiscal Year 2021 Guidance

[0001375365-21-000029:8k_2_02:18]
The Company expects net sales of $980 million to $1.08 billion, diluted net income per common share of $0.56 to $0.77 and non-GAAP diluted net income per common share of $0.70 to $0.90 for the fourth quarter of fiscal year 2021 ending June 30, 2021. The Company’s projections for GAAP and non-GAAP diluted net income per common share both assume a tax rate of approximately 13% and a fully diluted share count of 54 million shares. The outlook for Q4 of fiscal year 2021 GAAP diluted net income per common share includes approximately $7 million in expected stock-based compensation expense and $2 million in other expenses, net of tax effects, that are excluded from non-GAAP diluted net income per common share.

[0001375365-21-000029:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-21-000029:8k_2_02:20]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its third quarter of 2021. Those wishing to access the live webcast may use the following link:

[0001375365-21-000029:8k_2_02:21]
https://event.on24.com/wcc/r/3081432/CECE06854537FC85B1C7606DDC8651FC

[0001375365-21-000029:8k_2_02:22]
The conference call can be accessed by registering online at:

[0001375365-21-000029:8k_2_02:23]
http://www.directeventreg.com/registration/event/4869958

[0001375365-21-000029:8k_2_02:24]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-21-000029:8k_2_02:25]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-21-000029:8k_2_02:26]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-21-000029:8k_2_02:27]
Use of Non-GAAP Financial Measures

[0001375365-21-000029:8k_2_02:28]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, controls remediation expenses, legal settlement costs and other non-recurring expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-21-000029:8k_2_02:29]
About Super Micro Computer, Inc.

[0001375365-21-000029:8k_2_02:30]
Supermicro (Nasdaq:SMCI), the leading innovator in high-performance, high-efficiency server and storage technology is a premier provider of advanced server Building Block Solutions® for Enterprise Data Center, Cloud Computing, Artificial Intelligence, and Edge Computing Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-21-000029:8k_2_02:31]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-21-000029:8k_2_02:32]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-21-000029:8k_2_02:33]
Investor Relations Contact

[0001375365-21-000029:8k_2_02:34]
Nicole Noutsios

[0001375365-21-000029:8k_2_02:35]
email: ir@supermicro.com

[0001375365-21-000029:8k_2_02:36]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000029:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-21-000029:8k_2_02:38]
(in thousands)

[0001375365-21-000029:8k_2_02:39]
(unaudited)

[0001375365-21-000029:8k_2_02:40]
|  | March 31, |  | June 30, |
|  | 2021 |  | 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 177,894 |  |  | $ | 210,533 |  |
| Accounts receivable, net of allowances | 407,365 |  |  | 403,745 |  |
| Inventories | 903,903 |  |  | 851,498 |  |
| Prepaid expenses and other current assets | 150,488 |  |  | 126,985 |  |
| Total current assets | 1,639,650 |  |  | 1,592,761 |  |
| Investment in equity investee | 3,637 |  |  | 2,703 |  |
| Property, plant and equipment, net | 265,566 |  |  | 233,785 |  |
| Deferred income taxes, net | 57,624 |  |  | 54,898 |  |
| Other assets | 32,363 |  |  | 34,499 |  |
| Total assets | $ | 1,998,840 |  |  | $ | 1,918,646 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 465,012 |  |  | $ | 417,673 |  |
| Accrued liabilities | 153,742 |  |  | 155,401 |  |
| Income taxes payable | 9,616 |  |  | 4,700 |  |
| Short-term debt | 57,503 |  |  | 23,704 |  |
| Deferred revenue | 96,123 |  |  | 106,157 |  |
| Total current liabilities | 781,996 |  |  | 707,635 |  |
| Deferred revenue, non-current | 93,920 |  |  | 97,612 |  |
| Long-term debt, net of debt issuance costs | 27,867 |  |  | 5,697 |  |
| Other long-term liabilities | 41,109 |  |  | 41,995 |  |
| Total liabilities | 944,892 |  |  | 852,939 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 425,489 |  |  | 389,972 |  |
| Treasury stock | — |  |  | (20,491) |  |
| Accumulated other comprehensive gain (loss) | 362 |  |  | (152) |  |
| Retained earnings | 627,929 |  |  | 696,211 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,053,780 |  |  | 1,065,540 |  |
| Noncontrolling interest | 168 |  |  | 167 |  |
| Total stockholders’ equity | 1,053,948 |  |  | 1,065,707 |  |
| Total liabilities and stockholders’ equity | $ | 1,998,840 |  |  | $ | 1,918,646 |  |

[0001375365-21-000029:8k_2_02:41]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000029:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-21-000029:8k_2_02:43]
(in thousands, except share and per share amounts)

[0001375365-21-000029:8k_2_02:44]
(unaudited)

[0001375365-21-000029:8k_2_02:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 895,881 |  |  | $ | 772,408 |  |  | $ | 2,488,437 |  |  | $ | 2,443,155 |  |
| Cost of sales | 772,864 |  |  | 639,048 |  |  | 2,099,410 |  |  | 2,040,462 |  |
| Gross profit | 123,017 |  |  | 133,360 |  |  | 389,027 |  |  | 402,693 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 57,912 |  |  | 49,586 |  |  | 165,439 |  |  | 154,730 |  |
| Sales and marketing | 21,826 |  |  | 21,886 |  |  | 62,858 |  |  | 64,057 |  |
| General and administrative | 26,224 |  |  | 46,342 |  |  | 75,864 |  |  | 107,680 |  |
| Total operating expenses | 105,962 |  |  | 117,814 |  |  | 304,161 |  |  | 326,467 |  |
| Income from operations | 17,055 |  |  | 15,546 |  |  | 84,866 |  |  | 76,226 |  |
| Other income (expense), net | 2,017 |  |  | 937 |  |  | (1,363) |  |  | 2,110 |  |
| Interest expense | (607) |  |  | (518) |  |  | (1,850) |  |  | (1,630) |  |
| Income before income tax provision | 18,465 |  |  | 15,965 |  |  | 81,653 |  |  | 76,706 |  |
| Income tax provision | 227 |  |  | 899 |  |  | (8,541) |  |  | (9,782) |  |
| Share of loss from equity investee, net of taxes | (264) |  |  | (1,057) |  |  | (409) |  |  | (1,066) |  |
| Net income | $ | 18,428 |  |  | $ | 15,807 |  |  | $ | 72,703 |  |  | $ | 65,858 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.36 |  |  | $ | 0.31 |  |  | $ | 1.41 |  |  | $ | 1.30 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 1.35 |  |  | $ | 1.26 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 50,553 |  |  | 51,526 |  |  | 51,465 |  |  | 50,591 |  |
| Diluted | 53,218 |  |  | 53,693 |  |  | 53,747 |  |  | 52,399 |  |

[0001375365-21-000029:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-21-000029:8k_2_02:47]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of sales | $ | 402 |  |  | $ | 370 |  |  | $ | 1,312 |  |  | $ | 1,149 |  |
| Research and development | 3,328 |  |  | 3,043 |  |  | 10,369 |  |  | 9,299 |  |
| Sales and marketing | 503 |  |  | 417 |  |  | 1,517 |  |  | 1,276 |  |
| General and administrative | 3,261 |  |  | 975 |  |  | 7,919 |  |  | 3,099 |  |
| Stock-based compensation expense | $ | 7,494 |  |  | $ | 4,805 |  |  | $ | 21,117 |  |  | $ | 14,823 |  |

[0001375365-21-000029:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000029:8k_2_02:49]
SELECTED CASH FLOW INFORMATION

[0001375365-21-000029:8k_2_02:50]
(in thousands)

[0001375365-21-000029:8k_2_02:51]
(unaudited)

[0001375365-21-000029:8k_2_02:52]
|  | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |
| Net cash provided by operating activities | $ | 59,392 |  |  | $ | 65,716 |  |
| Net cash used in investing activities | (44,627) |  |  | (34,136) |  |
| Net cash (used in) provided by financing activities | (48,445) |  |  | 25,381 |  |
| Effect of exchange rate fluctuations on cash | 362 |  |  | 163 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | (33,318) |  |  | 57,124 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 212,390 |  |  | 262,140 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 179,072 |  |  | $ | 319,264 |  |

[0001375365-21-000029:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000029:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000029:8k_2_02:55]
(in thousands, except share and per share amounts)

[0001375365-21-000029:8k_2_02:56]
(unaudited)

[0001375365-21-000029:8k_2_02:57]
|  | Three Months Ended March 31, | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |  |  | 2021 |  | 2020 |
| GAAP GROSS PROFIT | $ | 123,017 |  |  | $ | 133,360 |  |  |  | $ | 389,027 |  |  | $ | 402,693 |  |
| Stock-based compensation | 402 |  |  | 370 |  |  |  | 1,312 |  |  | 1,149 |  |
| Special performance bonuses | — |  |  | 2,871 |  |  |  | — |  |  | 2,871 |  |
| Other expenses | — |  |  | — |  |  |  | 20 |  |  | — |  |
| NON-GAAP GROSS PROFIT | $ | 123,419 |  |  | $ | 136,601 |  |  |  | $ | 390,359 |  |  | $ | 406,713 |  |
| GAAP GROSS MARGIN | 13.7 | % |  | 17.3 | % |  |  | 15.6 | % |  | 16.5 | % |
| Stock-based compensation expenses | 0.1 | % |  | — | % |  |  | 0.1 | % |  | — | % |
| Special performance bonuses | — | % |  | 0.4 | % |  |  | — | % |  | 0.1 | % |
| Other expenses | — | % |  | — | % |  |  | — | % |  | — | % |
| NON-GAAP GROSS MARGIN | 13.8 | % |  | 17.7 | % |  |  | 15.7 | % |  | 16.6 | % |
| GAAP OPERATING EXPENSE | $ | 105,962 |  |  | $ | 117,814 |  |  |  | $ | 304,161 |  |  | $ | 326,467 |  |
| Stock-based compensation | (7,092) |  |  | (4,435) |  |  |  | (19,805) |  |  | (13,674) |  |
| Legal settlement costs | — |  |  | (17,500) |  |  |  | — |  |  | (17,500) |  |
| Executive SEC settlement | — |  |  | — |  |  |  | 2,122 |  |  | — |  |
| Special performance bonuses | (2,508) |  |  | (7,458) |  |  |  | (5,129) |  |  | (7,458) |  |
| Other expenses | — |  |  | — |  |  |  | (221) |  |  | — |  |
| Controls remediation | (1,239) |  |  | (1,440) |  |  |  | (1,239) |  |  | (12,859) |  |
| NON-GAAP OPERATING EXPENSE | $ | 95,123 |  |  | $ | 86,981 |  |  |  | $ | 279,889 |  |  | $ | 274,976 |  |
| GAAP INCOME FROM OPERATIONS | $ | 17,055 |  |  | $ | 15,546 |  |  |  | $ | 84,866 |  |  | $ | 76,226 |  |
| Stock-based compensation | 7,494 |  |  | 4,805 |  |  |  | 21,117 |  |  | 14,823 |  |
| Legal settlement costs | — |  |  | 17,500 |  |  |  | — |  |  | 17,500 |  |
| Executive SEC settlement | — |  |  | — |  |  |  | (2,122) |  |  | — |  |
| Special performance bonuses | 2,508 |  |  | 10,329 |  |  |  | 5,129 |  |  | 10,329 |  |
| Other expenses | — |  |  | — |  |  |  | 241 |  |  | — |  |
| Controls remediation | 1,239 |  |  | 1,440 |  |  |  | 1,239 |  |  | 12,859 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 28,296 |  |  | $ | 49,620 |  |  |  | $ | 110,470 |  |  | $ | 131,737 |  |
| GAAP TAX EXPENSE | $ | (227) |  |  | $ | (899) |  |  |  | $ | 8,541 |  |  | $ | 9,782 |  |
| Adjustments to tax provision | 2,473 |  |  | 3,812 |  |  |  | 5,633 |  |  | 8,868 |  |
| NON-GAAP TAX EXPENSE | $ | 2,246 |  |  | $ | 2,913 |  |  |  | $ | 14,174 |  |  | $ | 18,650 |  |
| GAAP NET INCOME | $ | 18,428 |  |  | $ | 15,807 |  |  |  | $ | 72,703 |  |  | $ | 65,858 |  |
| Stock-based compensation | 7,494 |  |  | 4,805 |  |  |  | 21,117 |  |  | 14,823 |  |
| Legal settlement costs | — |  |  | 17,500 |  |  |  | — |  |  | 17,500 |  |
| Executive SEC settlement | — |  |  | — |  |  |  | (2,122) |  |  | — |  |
| Special performance bonuses | 2,508 |  |  | 10,329 |  |  |  | 5,129 |  |  | 10,329 |  |
| Other expenses | — |  |  | — |  |  |  | 241 |  |  | — |  |
| Controls remediation | 1,239 |  |  | 1,440 |  |  |  | 1,239 |  |  | 12,859 |  |
| Adjustments to tax provision | (2,473) |  |  | (3,812) |  |  |  | (5,633) |  |  | (8,868) |  |
| NON-GAAP NET INCOME | $ | 27,196 |  |  | $ | 46,069 |  |  |  | $ | 92,674 |  |  | $ | 112,501 |  |

[0001375365-21-000029:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000029:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000029:8k_2_02:60]
(in thousands, except share and per share amounts)

[0001375365-21-000029:8k_2_02:61]
(unaudited)

[0001375365-21-000029:8k_2_02:62]
|  | Three Months Ended March 31, | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |  |  | 2021 |  | 2020 |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.36 |  |  | $ | 0.31 |  |  |  | $ | 1.41 |  |  | $ | 1.30 |  |
| Impact of Non-GAAP adjustments | 0.18 |  |  | 0.58 |  |  |  | 0.39 |  |  | 0.92 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.54 |  |  | $ | 0.89 |  |  |  | $ | 1.80 |  |  | $ | 2.22 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.35 |  |  | $ | 0.29 |  |  |  | $ | 1.35 |  |  | $ | 1.26 |  |
| Impact of Non-GAAP adjustments | 0.15 |  |  | 0.55 |  |  |  | 0.33 |  |  | 0.83 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.50 |  |  | $ | 0.84 |  |  |  | $ | 1.68 |  |  | $ | 2.09 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 50,553 |  |  | 51,526 |  |  |  | 51,465 |  |  | 50,591 |  |
| BASIC - NON-GAAP | 50,553 |  |  | 51,526 |  |  |  | 51,465 |  |  | 50,591 |  |
| DILUTED – GAAP | 53,218 |  |  | 53,693 |  |  |  | 53,747 |  |  | 52,399 |  |
| DILUTED - NON-GAAP | 54,525 |  |  | 55,050 |  |  |  | 55,185 |  |  | 53,913 |  |
