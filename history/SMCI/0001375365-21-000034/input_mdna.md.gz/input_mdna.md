# SMCI MD&A — 0001375365-21-000034


## mdna

[0001375365-21-000034:mdna:1]
[same as prior period, unchanged from 0001375365-21-000011:mdna:1]

[0001375365-21-000034:mdna:2]
[same as prior period, unchanged from 0001375365-21-000011:mdna:2]

[0001375365-21-000034:mdna:3]
[same as prior period, unchanged from 0001375365-21-000011:mdna:3]

[0001375365-21-000034:mdna:4]
[same as prior period, unchanged from 0001375365-21-000011:mdna:4]

[0001375365-21-000034:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended March 31, 2021 increased to $18.4 million from $15.8 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-21-000034:mdna:6]
[same as prior period, unchanged from 0001375365-21-000011:mdna:6]

[0001375365-21-000034:mdna:7]
[same as prior period, unchanged from 0001375365-21-000011:mdna:7]

[0001375365-21-000034:mdna:8]
[same as prior period, unchanged from 0001375365-21-000011:mdna:8]

[0001375365-21-000034:mdna:9]
We have actively managed our supply chain for potential shortage risk by building inventories of critical components required for our motherboards and other system printed circuit boards in response to the early outbreak of COVID-19 in China. Since that time, we have continued to add to our inventories of key components such as CPUs, memory, SSDs and GPUs such that customer orders can be fulfilled as they are received.

[0001375365-21-000034:mdna:10]
[same as prior period, unchanged from 0001375365-21-000011:mdna:10]

[0001375365-21-000034:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In May 2020, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2021. In June 2020, we entered into a ten-year, non-revolving term loan facility with China Trust and Bank Corp ("CTBC Bank") to obtain financing for use in the expansion and renovation of the our Bade Manufacturing Facility located in Taiwan. In December 2020, our Taiwan subsidiary entered into a general credit agreement with E.SUN Bank in Taiwan. This general credit agreement provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30 million. The term of this general credit agreement is through September 18, 2021.  See “- Liquidity and Capital Resources – Other Factors Affecting Liquidity and Capital Resources.”

[0001375365-21-000034:mdna:12]
Our management team is focused on guiding our company through the ongoing challenges presented by COVID-19. Currently, there are positive signs with vaccine availability and reductions in infection rates; however, with the possibility of new virus strains and vaccine supply constraints, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-21-000034:mdna:13]
[same as prior period, unchanged from 0001375365-21-000011:mdna:13]

[0001375365-21-000034:mdna:14]
The following is a summary of our financial highlights of the third quarter of fiscal year 2021:

[0001375365-21-000034:mdna:15]
•Net sales increased by 16.0% in the three months ended March 31, 2021 as compared to the three months ended March 31, 2020.

[0001375365-21-000034:mdna:16]
•Gross margin decreased to 13.7% in the three months ended March 31, 2021 from 17.3% in the three months ended March 31, 2020.

[0001375365-21-000034:mdna:17]
•Operating expenses decreased by 10.1% as compared to the three months ended March 31, 2020, and were equal to 11.8% and 15.3% of net sales in the three months ended March 31, 2021 and 2020, respectively.

[0001375365-21-000034:mdna:18]
•Effective tax rate benefit decreased from 5.6% in the three months ended March 31, 2020 to 1.2% in the three months ended March 31, 2021.

[0001375365-21-000034:mdna:19]
[same as prior period, unchanged from 0001375365-21-000011:mdna:19]

[0001375365-21-000034:mdna:20]
[same as prior period, unchanged from 0001375365-21-000011:mdna:20]

[0001375365-21-000034:mdna:21]
[same as prior period, unchanged from 0001375365-21-000011:mdna:21]

[0001375365-21-000034:mdna:22]
[same as prior period, unchanged from 0001375365-21-000011:mdna:22]

[0001375365-21-000034:mdna:23]
[same as prior period, unchanged from 0001375365-21-000011:mdna:23]

[0001375365-21-000034:mdna:24]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 86.3 | % |  | 82.7 | % |  | 84.4 | % |  | 83.5 | % |
| Gross profit | 13.7 | % |  | 17.3 | % |  | 15.6 | % |  | 16.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6.5 | % |  | 6.4 | % |  | 6.6 | % |  | 6.3 | % |
| Sales and marketing | 2.4 | % |  | 2.8 | % |  | 2.5 | % |  | 2.6 | % |
| General and administrative | 2.9 | % |  | 6.0 | % |  | 3.0 | % |  | 4.5 | % |
| Total operating expenses | 11.8 | % |  | 15.3 | % |  | 12.2 | % |  | 13.4 | % |
| Income from operations | 1.9 | % |  | 2.0 | % |  | 3.4 | % |  | 3.1 | % |
| Other (expense) income, net | 0.2 | % |  | 0.1 | % |  | (0.1) | % |  | 0.1 | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 2.1 | % |  | 2.1 | % |  | 3.3 | % |  | 3.1 | % |
| Income tax provision | — | % |  | 0.1 | % |  | (0.3) | % |  | (0.4) | % |
| Share of (loss) from equity investee, net of taxes | — | % |  | (0.1) | % |  | — | % |  | — | % |
| Net income | 2.1 | % |  | 2.0 | % |  | 2.9 | % |  | 2.7 | % |

[0001375365-21-000034:mdna:25]
[same as prior period, unchanged from 0001375365-21-000011:mdna:25]

[0001375365-21-000034:mdna:26]
[same as prior period, unchanged from 0001375365-21-000011:mdna:26]

[0001375365-21-000034:mdna:27]
[same as prior period, unchanged from 0001375365-21-000011:mdna:27]

[0001375365-21-000034:mdna:28]
The following table presents net sales by product type for the three and nine months ended March 31, 2021 and 2020 (dollars in millions):

[0001375365-21-000034:mdna:29]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Server and storage systems | $ | 693.3 |  |  | $ | 571.3 |  |  | $ | 122.0 |  |  | 21.4 | % |  | $ | 1,953.8 |  |  | $ | 1,880.0 |  |  | $ | 73.8 |  |  | 3.9 | % |
| Percentage of total net sales | 77.4 | % |  | 74.0 | % |  |  |  |  |  | 78.5 | % |  | 77.0 | % |  |  |  |  |
| Subsystems and accessories | $ | 202.5 |  |  | $ | 201.1 |  |  | $ | 1.4 |  |  | 0.7 | % |  | $ | 534.6 |  |  | $ | 563.1 |  |  | $ | (28.5) |  |  | (5.1) | % |
| Percentage of total net sales | 22.6 | % |  | 26.0 | % |  |  |  |  |  | 21.5 | % |  | 23.0 | % |  |  |  |  |
| Total net sales | $ | 895.9 |  |  | $ | 772.4 |  |  | $ | 123.5 |  |  | 16.0 | % |  | $ | 2,488.5 |  |  | $ | 2,443.1 |  |  | $ | 45.4 |  |  | 1.9 | % |

[0001375365-21-000034:mdna:30]
[same as prior period, unchanged from 0001375365-21-000011:mdna:30]

[0001375365-21-000034:mdna:31]
Comparison of Three Months Ended March  31, 2021 and 2020

[0001375365-21-000034:mdna:32]
The period-over-period increase in net sales of our server and storage systems was due to a 5.8% increase in the number of units of compute nodes sold and a 15.4% increase in the average selling price. The increase in the number of units of compute nodes shipped was primarily due to more shipments of multinode systems compared to the same period last year.

[0001375365-21-000034:mdna:33]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the average selling price.

[0001375365-21-000034:mdna:34]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:35]
The period-over-period increase in net sales of our server and storage systems was due to a 17.4% increase in the average selling price partially offset by a 11.1% decrease in the number of units of compute nodes sold. The decline in the number of units of compute nodes shipped was primarily due to fewer shipments of multinode systems compared to the same period last year.

[0001375365-21-000034:mdna:36]
[same as prior period, unchanged from 0001375365-21-000011:mdna:33]

[0001375365-21-000034:mdna:37]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2021 and 2020 (dollars in millions):

[0001375365-21-000034:mdna:38]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| United States | $ | 499.1 |  |  | $ | 422.9 |  |  | $ | 76.2 |  |  | 18.0 | % |  | $ | 1,458.2 |  |  | $ | 1,419.1 |  |  | $ | 39.1 |  |  | 2.8 | % |
| Percentage of total net sales | 55.7 | % |  | 54.8 | % |  |  |  |  |  | 58.6 | % |  | 58.1 | % |  |  |  |  |
| Asia | 207.2 |  |  | 160.5 |  |  | 46.7 |  |  | 29.1 | % |  | 495.3 |  |  | 487.8 |  |  | 7.5 |  |  | 1.5 | % |
| Percentage of total net sales | 23.1 | % |  | 20.8 | % |  |  |  |  |  | 19.9 | % |  | 20.0 | % |  |  |  |  |
| Europe | 162.3 |  |  | 158.1 |  |  | 4.2 |  |  | 2.7 | % |  | 429.2 |  |  | 433.8 |  |  | (4.6) |  |  | (1.1) | % |
| Percentage of total net sales | 18.1 | % |  | 20.5 | % |  |  |  |  |  | 17.2 | % |  | 17.8 | % |  |  |  |  |
| Others | 27.3 |  |  | 30.9 |  |  | (3.6) |  |  | (11.7) | % |  | 105.7 |  |  | 102.4 |  |  | 3.3 |  |  | 3.2 | % |
| Percentage of total net sales | 3.0 | % |  | 4.0 | % |  |  |  |  |  | 4.2 | % |  | 4.2 | % |  |  |  |  |
| Total net sales | $ | 895.9 |  |  | $ | 772.4 |  |  |  |  |  |  | $ | 2,488.4 |  |  | $ | 2,443.2 |  |  |  |  |  |

[0001375365-21-000034:mdna:39]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:40]
The period-over-period increase in net sales in the United States for the three months ended March 31, 2021 and 2020 was primarily due to higher sales driven by higher server and storage systems unit volume. The period-over-period increase in net sales in Asia was due primarily to increased sales in China, Japan and India and partially off-set by decreased sales in Singapore and Korea. The increase of net sales in Europe was primarily due to higher sales in France, Germany, the United Kingdom, and Russia, partially offset by lower sales in the Netherlands. The period-over-period decrease in net sales in other

[0001375365-21-000034:mdna:41]
countries was primarily due to decreased sales in Mexico and South Africa, partially offset by higher sales in Canada, Israel and other Middle East countries.

[0001375365-21-000034:mdna:42]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:43]
The period-over-period increase in net sales in the United States for the nine months ended March 31, 2021 and 2020 was primarily due to higher sales driven by higher server and storage systems unit volume. The period-over-period increase in net sales in Asia was due primarily to increased sales in Japan and Singapore, partially offset by decreased sales in China, Taiwan, and Korea. The decrease of net sales in Europe was primarily due to lower sales in the Netherlands, Russia and the rest of Europe, partially offset by increased sales in France and the United Kingdom. The period-over-period increase in net sales in other countries was primarily due to increased sales in Brazil, Canada and Israel and other Middle East countries, partially offset by lower sales in Mexico, South Africa and Australia.

[0001375365-21-000034:mdna:44]
[same as prior period, unchanged from 0001375365-21-000011:mdna:43]

[0001375365-21-000034:mdna:45]
[same as prior period, unchanged from 0001375365-21-000011:mdna:44]

[0001375365-21-000034:mdna:46]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-21-000034:mdna:47]
Cost of sales and gross margin for the three and nine months ended March 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000034:mdna:48]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Cost of sales | $ | 772.9 |  |  | $ | 639.0 |  |  | $ | 133.9 |  |  | 21.0 | % |  | $ | 2,099.4 |  |  | $ | 2,040.5 |  |  | $ | 58.9 |  |  | 2.9 | % |
| Gross profit | $ | 123.0 |  |  | $ | 133.4 |  |  | $ | (10.4) |  |  | (7.8) | % |  | $ | 389.0 |  |  | $ | 402.7 |  |  | $ | (13.7) |  |  | (3.4) | % |
| Gross margin | 13.7 | % |  | 17.3 | % |  |  |  | (3.6) | % |  | 15.6 | % |  | 16.5 | % |  |  |  | (0.9) | % |

[0001375365-21-000034:mdna:49]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:50]
The period-over-period increase in cost of sales was primarily attributed to an increase of $131.9 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume and a $5.5 million increase in freight charges, partially offset by a decrease of excess and obsolete inventory charges of $1.7 million and a decrease of $3.0 million in overhead costs.

[0001375365-21-000034:mdna:51]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of components purchased and higher freight costs.

[0001375365-21-000034:mdna:52]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:53]
The period-over-period increase in cost of sales was primarily attributed to an increase of $91.2 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, an increase of $6.0 million of  freight charges and a $1.3 million increase in product service costs, partially offset by a decrease of $24.8 million in overhead costs attributable primarily to a recovery of costs paid in prior periods and a decrease of excess and obsolete inventory charge of $14.0 million.

[0001375365-21-000034:mdna:54]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of components we purchased.

[0001375365-21-000034:mdna:55]
[same as prior period, unchanged from 0001375365-21-000011:mdna:54]

[0001375365-21-000034:mdna:56]
[same as prior period, unchanged from 0001375365-21-000011:mdna:55]

[0001375365-21-000034:mdna:57]
[same as prior period, unchanged from 0001375365-21-000011:mdna:56]

[0001375365-21-000034:mdna:58]
[same as prior period, unchanged from 0001375365-21-000011:mdna:57]

[0001375365-21-000034:mdna:59]
Operating expenses for the three and nine months ended March 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000034:mdna:60]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Research and development | $ | 57.9 |  |  | $ | 49.6 |  |  | $ | 8.3 |  |  | 16.7 | % |  | $ | 165.4 |  |  | $ | 154.7 |  |  | $ | 10.7 |  |  | 6.9 | % |
| Percentage of total net sales | 6.5 | % |  | 6.4 | % |  |  |  |  |  | 6.6 | % |  | 6.3 | % |  |  |  |  |
| Sales and marketing | $ | 21.8 |  |  | $ | 21.9 |  |  | $ | (0.1) |  |  | (0.5) | % |  | $ | 62.9 |  |  | $ | 64.1 |  |  | $ | (1.2) |  |  | (1.9) | % |
| Percentage of total net sales | 2.4 | % |  | 2.8 | % |  |  |  |  |  | 2.5 | % |  | 2.6 | % |  |  |  |  |
| General and administrative | $ | 26.2 |  |  | $ | 46.3 |  |  | $ | (20.1) |  |  | (43.4) | % |  | $ | 75.9 |  |  | $ | 107.7 |  |  | $ | (31.8) |  |  | (29.5) | % |
| Percentage of total net sales | 2.9 | % |  | 6.1 | % |  |  |  |  |  | 3.0 | % |  | 4.4 | % |  |  |  |  |
| Total operating expenses | $ | 106.0 |  |  | $ | 117.8 |  |  | $ | (11.8) |  |  | (10.0) | % |  | $ | 304.2 |  |  | $ | 326.5 |  |  | $ | (22.3) |  |  | (6.8) | % |
| Percentage of total net sales | 11.8 | % |  | 15.3 | % |  |  |  |  |  | 12.2 | % |  | 13.4 | % |  |  |  |  |

[0001375365-21-000034:mdna:61]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:62]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $13.2 million increase in costs mainly related to materials, supplies and equipment used in product development. During the three months ended March 31, 2020, we recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred materials, supplies and equipment costs for one canceled joint product development agreement. This increase was partially offset by a $2.8 million increase in research and development credits from certain suppliers and customers towards our development efforts and a decrease of $2.3 million in personnel expenses.

[0001375365-21-000034:mdna:63]
Sales and marketing expenses. The period-over-period sales and marketing expenses decreased primarily due to a $1.0 million decrease in personnel expenses as a result of a decrease in the number of personnel, a $0.2 million decrease in expenses related to participation in trade shows and business travel as a result in a change in our operations in response to the COVID-19

[0001375365-21-000034:mdna:64]
pandemic, partially offset by an increase of $0.7 million in advertising expenses and a $0.4 million increase in other sales and marketing expenses.

[0001375365-21-000034:mdna:65]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $19.1 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $1.7 million in bad debt provision expenses and a $1.1 million decrease in other general and administrative expenses, partially offset by an increase of $3.1 million in personnel expenses due to increased full time personnel.

[0001375365-21-000034:mdna:66]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:67]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $12.9 million in costs mainly related to materials supplies and equipment used in product development. During the three months ended March 31, 2020, we recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred materials, supplies and equipment costs for one canceled joint product development agreement.  Personnel expenses increased $7.4 million as a result of an increase in the number of personnel. These increases were partially offset by an increase of $8.5 million in research and development credits from certain suppliers and customers towards our development efforts and a decrease of $1.4 million in travel expenses as a result in a change in our operations in response to the COVID-19 pandemic.

[0001375365-21-000034:mdna:68]
Sales and marketing expenses. The period-over-period sales and marketing expenses decreased primarily due to a decrease of $2.3 million in    expenses related to participation in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic and a $0.7 million decrease in personal expenses due to decreased full time personnel, partially offset by a $0.7 million increase in facilities costs, an increase of $0.5 million in advertising expenses, and a $0.5 million increase in other sales and marketing expenses.

[0001375365-21-000034:mdna:69]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $37.2 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $3.1 million in travel expenses as a result in a change in our operations in response to the COVID-19 pandemic, a decrease of $2.2 million in bad debt provision expenses, a decrease of $1.2 million in supplies expenses, a decrease of $0.7 million in sales tax reserve and audit expenses and a $0.6 million decrease in facilities costs, partially offset by an increase of $13.5 million in compensation expense due to increased full time personnel and bonuses.

[0001375365-21-000034:mdna:70]
[same as prior period, unchanged from 0001375365-21-000011:mdna:68]

[0001375365-21-000034:mdna:71]
[same as prior period, unchanged from 0001375365-21-000011:mdna:69]

[0001375365-21-000034:mdna:72]
[same as prior period, unchanged from 0001375365-21-000011:mdna:70]

[0001375365-21-000034:mdna:73]
Interest and other (expense) income, net for the three and nine months ended March 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000034:mdna:74]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Other (expense) income, net | $ | 2.0 |  |  | $ | 0.9 |  |  | $ | 1.1 |  |  | 122.2 | % |  | $ | (1.4) |  |  | $ | 2.1 |  |  | $ | (3.5) |  |  | (166.7) | % |
| Interest expense | (0.6) |  |  | (0.5) |  |  | (0.1) |  |  | 20.0 | % |  | (1.8) |  |  | (1.6) |  |  | (0.2) |  |  | 12.5 | % |
| Interest and other (expense) income, net | $ | 1.4 |  |  | $ | 0.4 |  |  | $ | 1.0 |  |  | 250.0 | % |  | $ | (3.2) |  |  | $ | 0.5 |  |  | $ | (3.7) |  |  | (740.0) | % |

[0001375365-21-000034:mdna:75]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:76]
The change of $1.1 million in other (expense) income, net was attributable to an increase of $1.7 million in foreign exchange gain due to favorable foreign currency fluctuations, partially offset by a decrease of $0.5 million in interest income on our interest-bearing deposits due primarily to lower yields on investments.

[0001375365-21-000034:mdna:77]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:78]
The change of $3.5 million in other (expense) income, net was attributable to a decrease of $2.3 million in interest income on our interest-bearing deposits due primarily to lower yields on investments and an increase of $1.2 million in foreign exchange loss due to unfavorable foreign currency fluctuations.

[0001375365-21-000034:mdna:79]
[same as prior period, unchanged from 0001375365-21-000011:mdna:77]

[0001375365-21-000034:mdna:80]
[same as prior period, unchanged from 0001375365-21-000011:mdna:78]

[0001375365-21-000034:mdna:81]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000034:mdna:82]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Income tax (benefit) provision | $ | (0.2) |  |  | $ | (0.9) |  |  | $ | 0.7 |  |  | (77.8) | % |  | $ | 8.5 |  |  | $ | 9.8 |  |  | $ | (1.3) |  |  | (13.3) | % |
| Percentage of total net sales | — | % |  | (0.1) | % |  |  |  |  |  | 0.3 | % |  | 0.4 | % |  |  |  |  |
| Effective tax rate (benefit) | (1.2) | % |  | (5.6) | % |  |  |  |  |  | 10.5 | % |  | 12.8 | % |  |  |  |  |

[0001375365-21-000034:mdna:83]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:84]
The income tax provision and effective tax rate for the three months ended March 31, 2021 was higher than that for the three months ended March 31, 2020 due to the release of tax reserves after the settlement of a Taiwan tax audit in the prior year.

[0001375365-21-000034:mdna:85]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:86]
The income tax (benefit) provision and effective tax rate for the nine months ended March 31, 2021 was lower than that for the nine months ended March 31, 2020, primarily due to decrease in tax reserves after the settlement of a Taiwan tax audit and the SEC penalty assessment in 2020.

[0001375365-21-000034:mdna:87]
[same as prior period, unchanged from 0001375365-21-000011:mdna:85]

[0001375365-21-000034:mdna:88]
[same as prior period, unchanged from 0001375365-21-000011:mdna:86]

[0001375365-21-000034:mdna:89]
Share of (loss) from equity investee, net of taxes for the three and nine months ended March 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-21-000034:mdna:90]
|  | Three Months EndedMarch 31, |  | Change | Nine Months EndedMarch 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Share of (loss) from equity investee, net of taxes | $ | (0.3) |  |  | $ | (1.1) |  |  | $ | 0.8 |  |  | (72.7)% |  | $ | (0.4) |  |  | $ | (1.1) |  |  | $ | 0.7 |  |  | —% |
| Percentage of total net sales | — | % |  | (0.1) | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001375365-21-000034:mdna:91]
Comparison of Three Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:92]
The period-over-period decrease of $0.8 million in share of (loss) from equity investee, net of taxes was primarily due to less net loss recognized by the Corporate Venture.

[0001375365-21-000034:mdna:93]
Comparison of Nine Months Ended March 31, 2021 and 2020

[0001375365-21-000034:mdna:94]
The period-over-period decrease of $0.7 million in share of (loss) from equity investee, net of taxes was primarily due to less net loss recognized by the Corporate Venture.

[0001375365-21-000034:mdna:95]
[same as prior period, unchanged from 0001375365-21-000011:mdna:93]

[0001375365-21-000034:mdna:96]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $177.9 million and $210.5 million as of March 31, 2021 and June 30, 2020, respectively. Our cash in foreign locations was $99.0 million and $98.0 million as of March 31, 2021 and June 30, 2020, respectively.

[0001375365-21-000034:mdna:97]
[same as prior period, unchanged from 0001375365-21-000011:mdna:95]

[0001375365-21-000034:mdna:98]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses, continued remediation of the material weakness in the financial reporting, and maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements. We expect to pay a special performance bonus of approximately $8.1 million to our CEO within the next year in two equal tranches. During the quarter ended March 31, 2021, the target average closing prices for both tranches were met but no determination has been made if the specified performance condition for the first tranche is met.

[0001375365-21-000034:mdna:99]
[same as prior period, unchanged from 0001375365-21-000011:mdna:97]

[0001375365-21-000034:mdna:100]
On October 31, 2020, the Board approved a share repurchase program to repurchase up to an aggregate of $50.0 million of the Company’s common stock at market prices. The program was effective until October 31, 2021 or if earlier, until the maximum amount of common stock was repurchased. As of March 31, 2021, 1,675,746 shares of common stock were repurchased and retired for $50.0 million and the program ended.

[0001375365-21-000034:mdna:101]
On January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company’s common stock at market prices. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended March 31 2021, 1,155,000 shares of common stock were repurchased for $40.7 million.  All repurchased shares have been retired as of March 31, 2021. We repurchased 236,171 shares of our common stock for $9.3 million subsequent to March 31, 2021.

[0001375365-21-000034:mdna:102]
[same as prior period, unchanged from 0001375365-21-000011:mdna:100]

[0001375365-21-000034:mdna:103]
|  | Nine Months EndedMarch 31, |  | Change |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net cash provided by operating activities | $ | 59.4 |  |  | $ | 65.7 |  |  | $ | (6.3) |  |  |  |  |
| Net cash used in investing activities | $ | (44.6) |  |  | $ | (34.1) |  |  | $ | (10.5) |  |  |  |  |
| Net cash used in financing activities | $ | (48.4) |  |  | $ | 25.4 |  |  | $ | (73.8) |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | (33.3) |  |  | $ | 57.1 |  |  | $ | (90.4) |  |  |  |  |

[0001375365-21-000034:mdna:104]
[same as prior period, unchanged from 0001375365-21-000011:mdna:102]

[0001375365-21-000034:mdna:105]
Net cash provided by operating activities decreased by $6.3 million for the nine months ended March 31, 2021 as compared to the nine months ended March 31, 2020. The decrease was due primarily to a decrease of $13.2 million in the non-cash charges related to excess and obsolete inventories, an increase of cash used for net working capital of $4.3 million primarily driven by increased accounts receivable as a result of increased revenue and higher cash payments for inventory purchases to meet expected customer demands, and a $2.2 million decrease in the non-cash charges related to allowances for doubtful accounts. These decreases were partially offset by a $6.8 million increase in net income and a $6.3 million increase in non-cash charges related to stock-based compensation expenses.

[0001375365-21-000034:mdna:106]
[same as prior period, unchanged from 0001375365-21-000011:mdna:104]

[0001375365-21-000034:mdna:107]
Net cash used in investing activities was $44.6 million and $34.1 million for the nine months ended March 31, 2021 and 2020, respectively, as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-21-000034:mdna:108]
[same as prior period, unchanged from 0001375365-21-000011:mdna:106]

[0001375365-21-000034:mdna:109]
Net cash used by financing activities for the nine months ended March 31, 2021 was $48.4 million while net cash provided by financing activities for the nine months ended March 31, 2020 was $25.4 million. The change in cash flows from financing activities was primarily due to stock repurchases of $118.0 million, a $6.2 million increase in debt repayment, and a $2.7 million decrease in cash received from the exercise of stock options net of taxes, partially offset by a $52.2 million increase in debt proceeds from draws on our CTBC credit and term loan facilities and E.SUN credit facility.

[0001375365-21-000034:mdna:110]
[same as prior period, unchanged from 0001375365-21-000011:mdna:108]

[0001375365-21-000034:mdna:111]
2018 Bank of America Credit Facility

[0001375365-21-000034:mdna:112]
In April 2018, we entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility").  On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other things, extend the maturity to June 30, 2021, release the real property as a collateral, modify certain payments and covenants provisions, specify that LIBOR cannot be less than 1% for purposes of determining interest rates, and increase the unused line fee from 0.25% per annum to 0.375% per annum. Interest shall accrue at LIBOR plus 2.00% on outstanding borrowings less than $125.0 million and LIBOR plus 2.25% on outstanding borrowings in excess of $125.0 million. As of March 31, 2021, we had no outstanding borrowings and we had a $6.4 million letter of credit outstanding under this facility. Our available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.  In the event of default or if outstanding borrowings are in excess of $220.0 million, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. In addition, we are not permitted to pay any dividends. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-21-000034:mdna:113]
[same as prior period, unchanged from 0001375365-21-000011:mdna:111]

[0001375365-21-000034:mdna:114]
2020 CTBC Credit Facility

[0001375365-21-000034:mdna:115]
In August 2020, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans of up to $50.0 million (the "2020 CTBC Credit Facility") and expires in August 2021. As of March 31, 2021, the outstanding borrowings under the CTBC Credit Facility revolving line of credit were $18.0 million and the interest rates for these loans were from 1.03% to 1.26% per annum. The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.5 million at March 31, 2021 and the interest rates for these loans were 0.74% per annum. The amount available for future borrowing was $7.5 million as of March 31, 2021. The term loans are secured by certain of our assets, including certain property, plant, and equipment. There are no financial covenants under the 2020 CTBC Credit Facility.

[0001375365-21-000034:mdna:116]
2020 CTBC Term Loan Facility due June 4, 2030

[0001375365-21-000034:mdna:117]
In May 2020, we entered into a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of our Bade Manufacturing Facility located in Taiwan. Draw downs on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and are drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. We are required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility, including any expansion. Fees paid to the lender as debt issuance costs were immaterial. We borrowed $7.3 million in the three months ended March 31, 2021

[0001375365-21-000034:mdna:118]
with a rate of 0.45% per annum. As of March 31, 2021, the amount outstanding under the 2020 CTBC Term Loan Facility was $27.9 million and the net book value of the property serving as collateral was $38.1 million. We have financial covenants requiring our current ratio, debt service coverage ratio, and financial debt ratio, to be maintained at certain levels. As of March 31, 2021, we have been in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000034:mdna:119]
E.SUN Credit Facility

[0001375365-21-000034:mdna:120]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan.  Such Credit Facility provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. Terms for specific drawdowns are set forth in separate Notification and Confirmation of Credit Conditions negotiated with E. SUN Bank. The term of the E.SUN Credit Facility is until September 18, 2021. There are no financial covenants associated with the E.SUN Credit Facility. A Notification and Confirmation agreement was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) under the E. SUN Credit facility with a tenor of 120 days and with an interest rate calculated based on LIBOR or TAIFX plus a fixed margin. As of March 31, 2021, the amounts outstanding under the E.SUN Credit Facility were $15.0 million and the interest rates for these loans were approximately 1.0% per annum. At March 31, 2021, the amount available for future borrowing under the E.SUN Credit Facility was $15 million.

[0001375365-21-000034:mdna:121]
[same as prior period, unchanged from 0001375365-21-000011:mdna:119]

[0001375365-21-000034:mdna:122]
[same as prior period, unchanged from 0001375365-21-000011:mdna:120]

[0001375365-21-000034:mdna:123]
[same as prior period, unchanged from 0001375365-21-000011:mdna:121]

[0001375365-21-000034:mdna:124]
[same as prior period, unchanged from 0001375365-21-000011:mdna:122]

[0001375365-21-000034:mdna:125]
[same as prior period, unchanged from 0001375365-21-000011:mdna:123]
