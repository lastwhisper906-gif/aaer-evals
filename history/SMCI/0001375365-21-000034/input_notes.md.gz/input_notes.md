# SMCI notes — 0001375365-21-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-21-000034:notes:1]
[same as prior period, unchanged from 0001375365-21-000011:notes:1]

[0001375365-21-000034:notes:2]
[same as prior period, unchanged from 0001375365-21-000011:notes:2]

[0001375365-21-000034:notes:3]
[same as prior period, unchanged from 0001375365-21-000011:notes:3]

[0001375365-21-000034:notes:4]
[same as prior period, unchanged from 0001375365-21-000011:notes:4]

[0001375365-21-000034:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.

[0001375365-21-000034:notes:6]
[same as prior period, unchanged from 0001375365-21-000011:notes:6]

[0001375365-21-000034:notes:7]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-21-000034:notes:8]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of March 31, 2021 and June 30, 2020, the Company had unamortized deferred gain balance of $1.5 million and $2.0 million, respectively, in accrued liabilities and $0.0 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed

[0001375365-21-000034:notes:9]
[same as prior period, unchanged from 0001375365-21-000011:notes:9]

[0001375365-21-000034:notes:10]
[same as prior period, unchanged from 0001375365-21-000011:notes:10]

[0001375365-21-000034:notes:11]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of March 31, 2021. No impairment charge was recorded for the three and nine months ended March 31, 2021 and 2020, respectively.

[0001375365-21-000034:notes:12]
The Company sold products worth $16.8 million and $14.0 million to the Corporate Venture in the three months ended March 31, 2021 and 2020, respectively, and $36.4 million and $51.5 million for the nine months ended March 31, 2021 and 2020, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2021 and June 30, 2020 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $11.4 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of March 31, 2021 and June 30, 2020, respectively.

[0001375365-21-000034:notes:13]
[same as prior period, unchanged from 0001375365-21-000011:notes:13]

[0001375365-21-000034:notes:14]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 21.4% and 26.1% of total purchases for the three months ended March 31, 2021 and 2020, respectively, and 21.1% and 27.9% for the nine months ended March 31, 2021 and 2020, respectively. Purchases from Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 8.4% and 9.4% of total cost of sales for the three months ended March 31, 2021 and 2020, respectively, and a combined 8.5% and 9.8% for the nine months ended March 31, 2021 and 2020, respectively.

[0001375365-21-000034:notes:15]
[same as prior period, unchanged from 0001375365-21-000011:notes:15]

[0001375365-21-000034:notes:16]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2021 and 2020. No customer accounted for greater than 10% of the Company's accounts receivable, net as of March 31, 2021, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.

[0001375365-21-000034:notes:17]
[same as prior period, unchanged from 0001375365-21-000011:notes:17]

[0001375365-21-000034:notes:18]
[same as prior period, unchanged from 0001375365-21-000011:notes:18]

[0001375365-21-000034:notes:19]
[same as prior period, unchanged from 0001375365-21-000011:notes:19]

[0001375365-21-000034:notes:20]
[same as prior period, unchanged from 0001375365-21-000011:notes:20]

[0001375365-21-000034:notes:21]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three and nine months ended March 31, 2021.

[0001375365-21-000034:notes:22]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of March 31, 2021, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial. See Note 5, "Fair Value Disclosure".

[0001375365-21-000034:notes:23]
[same as prior period, unchanged from 0001375365-21-000011:notes:23]

[0001375365-21-000034:notes:24]
[same as prior period, unchanged from 0001375365-21-000011:notes:24]

[0001375365-21-000034:notes:25]
[same as prior period, unchanged from 0001375365-21-000011:notes:25]

[0001375365-21-000034:notes:26]
[same as prior period, unchanged from 0001375365-21-000011:notes:26]

[0001375365-21-000034:notes:27]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 and E.SUN Credit Facility will terminate on September 18, 2021. As both credit facilities will expire before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its condensed consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-21-000034:notes:28]
[same as prior period, unchanged from 0001375365-21-000011:notes:28]

[0001375365-21-000034:notes:29]
[same as prior period, unchanged from 0001375365-21-000011:notes:29]

[0001375365-21-000034:notes:30]
[same as prior period, unchanged from 0001375365-21-000011:notes:30]

[0001375365-21-000034:notes:31]
|  | Three Months Ended March 31, |  |  |  | Nine Months Ended March 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |  |
| Server and storage systems | $ | 693,339 |  |  |  |  | $ | 571,291 |  |  |  |  | $ | 1,953,838 |  |  |  |  | $ | 1,880,043 |  |  |  |
| Subsystems and accessories | 202,542 |  |  |  |  | 201,117 |  |  |  |  | 534,599 |  |  |  |  | 563,112 |  |  |  |
| Total | $ | 895,881 |  |  |  |  | $ | 772,408 |  |  |  |  | $ | 2,488,437 |  |  |  |  | $ | 2,443,155 |  |  |  |

[0001375365-21-000034:notes:32]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of server boards, chassis and accessories.

[0001375365-21-000034:notes:33]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2021 and 2020, of net sales by geographic region (in thousands):

[0001375365-21-000034:notes:34]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 499,061 |  |  | $ | 422,872 |  |  | $ | 1,458,249 |  |  | $ | 1,419,117 |  |
| Asia | 207,204 |  |  | 160,472 |  |  | 495,326 |  |  | 487,827 |  |
| Europe | 162,285 |  |  | 158,144 |  |  | 429,193 |  |  | 433,767 |  |
| Others | 27,331 |  |  | 30,920 |  |  | 105,669 |  |  | 102,444 |  |
|  | $ | 895,881 |  |  | $ | 772,408 |  |  | $ | 2,488,437 |  |  | $ | 2,443,155 |  |

[0001375365-21-000034:notes:35]
[same as prior period, unchanged from 0001375365-21-000011:notes:35]

[0001375365-21-000034:notes:36]
[same as prior period, unchanged from 0001375365-21-000011:notes:36]

[0001375365-21-000034:notes:37]
[same as prior period, unchanged from 0001375365-21-000011:notes:37]

[0001375365-21-000034:notes:38]
[same as prior period, unchanged from 0001375365-21-000011:notes:38]

[0001375365-21-000034:notes:39]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and nine months ended March 31, 2021, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $24.1 million and $79.6 million, respectively.

[0001375365-21-000034:notes:40]
Deferred revenue decreased $13.7 million during the nine months ended March 31, 2021 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

[0001375365-21-000034:notes:41]
[same as prior period, unchanged from 0001375365-21-000011:notes:41]

[0001375365-21-000034:notes:42]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2021 was $190.0 million. The Company expects to recognize approximately 51% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-21-000034:notes:43]
[same as prior period, unchanged from 0001375365-21-000011:notes:43]

[0001375365-21-000034:notes:44]
[same as prior period, unchanged from 0001375365-21-000011:notes:44]

[0001375365-21-000034:notes:45]
[same as prior period, unchanged from 0001375365-21-000011:notes:45]

[0001375365-21-000034:notes:46]
[same as prior period, unchanged from 0001375365-21-000011:notes:46]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-21-000034:notes:47]
The following is a summary for the three and nine months ended March 31, 2021 and 2020, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-21-000034:notes:48]
Net Income Per Common Share
    The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2021 and 2020 (in thousands, except per share amounts):

[0001375365-21-000034:notes:49]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 18,428 |  |  | $ | 15,807 |  |  | $ | 72,703 |  |  | $ | 65,858 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 50,553 |  |  | 51,526 |  |  | 51,465 |  |  | 50,591 |  |
| Effect of dilutive securities | 2,665 |  |  | 2,167 |  |  | 2,282 |  |  | 1,808 |  |
| Weighted-average diluted shares | 53,218 |  |  | 53,693 |  |  | 53,747 |  |  | 52,399 |  |
| Basic net income per common share | $ | 0.36 |  |  | $ | 0.31 |  |  | $ | 1.41 |  |  | $ | 1.30 |  |
| Diluted net income per common share | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 1.35 |  |  | $ | 1.26 |  |

[0001375365-21-000034:notes:50]
For the three and nine months ended March 31, 2021 and 2020, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 578,892 and 1,882,238 for the three months ended March 31, 2021 and 2020, respectively, and 617,807 and 2,305,538 for the nine months ended March 31, 2021 and 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-21-000034:notes:51]
[same as prior period, unchanged from 0001375365-21-000011:notes:50]

[0001375365-21-000034:notes:52]
[same as prior period, unchanged from 0001375365-21-000011:notes:51]

[0001375365-21-000034:notes:53]
|  | March 31, 2021 |  | June 30, 2020 |
| Finished goods | $ | 634,032 |  |  | $ | 656,817 |  |
| Work in process | 120,374 |  |  | 38,146 |  |
| Purchased parts and raw materials | 149,497 |  |  | 156,535 |  |
| Total inventories | $ | 903,903 |  |  | $ | 851,498 |  |

[0001375365-21-000034:notes:54]
The Company recorded a provision for excess and obsolete inventory to cost of sales totaling $2.9 million and $4.6 million in the three and nine months ended March 31, 2021 and $4.7 million and $21.6 million for the three and nine

[0001375365-21-000034:notes:55]
months ended March 31, 2020, respectively. These amounts exclude a provision (recovery) for adjusting the cost of certain inventories to net realizable value of $(0.8) million and $0.2 million for the three and nine months ended March  31, 2021, respectively, and $(0.8) million and $(3.5) million for the three and nine months ended March 31, 2020, respectively. The recovery is recognized when previously reserved inventories are sold.

[0001375365-21-000034:notes:56]
[same as prior period, unchanged from 0001375365-21-000011:notes:55]

[0001375365-21-000034:notes:57]
|  | March 31, 2021 |  | June 30, 2020 |
| Other receivables (1) | $ | 118,371 |  |  | $ | 96,669 |  |
| Prepaid income tax | 12,963 |  |  | 14,323 |  |
| Prepaid expenses | 6,612 |  |  | 7,075 |  |
| Deferred service costs | 4,764 |  |  | 4,161 |  |
| Restricted cash | 251 |  |  | 250 |  |
| Others | 7,527 |  |  | 4,507 |  |
| Total prepaid expenses and other current assets | $ | 150,488 |  |  | $ | 126,985 |  |

[0001375365-21-000034:notes:58]
[same as prior period, unchanged from 0001375365-21-000011:notes:57]

[0001375365-21-000034:notes:59]
(1) Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $73.3 million and $83.8 million as of March 31, 2021 and June 30, 2020, respectively.

[0001375365-21-000034:notes:60]
[same as prior period, unchanged from 0001375365-21-000011:notes:59]

[0001375365-21-000034:notes:61]
|  | March 31, 2021 |  | June 30, 2020 |
| Cash and cash equivalents | $ | 177,894 |  |  | $ | 210,533 |  |
| Restricted cash included in prepaid expenses and other current assets | 251 |  |  | 250 |  |
| Restricted cash included in other assets | 927 |  |  | 1,607 |  |
| Total cash, cash equivalents and restricted cash | $ | 179,072 |  |  | $ | 212,390 |  |

[0001375365-21-000034:notes:62]
[same as prior period, unchanged from 0001375365-21-000011:notes:61]

[0001375365-21-000034:notes:63]
|  | March 31, 2021 |  | June 30, 2020 |
| Buildings | $ | 86,930 |  |  | $ | 86,930 |  |
| Land | 75,265 |  |  | 75,251 |  |
| Machinery and equipment | 94,735 |  |  | 85,381 |  |
| Buildings construction in progress (1) | 80,217 |  |  | 46,311 |  |
| Building and leasehold improvements | 25,147 |  |  | 24,517 |  |
| Software | 22,855 |  |  | 20,597 |  |
| Furniture and fixtures | 22,107 |  |  | 21,544 |  |
|  | 407,256 |  |  | 360,531 |  |
| Accumulated depreciation and amortization | (141,690) |  |  | (126,746) |  |
| Property, plant and equipment, net | $ | 265,566 |  |  | $ | 233,785 |  |

[0001375365-21-000034:notes:64]
[same as prior period, unchanged from 0001375365-21-000011:notes:63]

[0001375365-21-000034:notes:65]
[same as prior period, unchanged from 0001375365-21-000011:notes:64]

[0001375365-21-000034:notes:66]
|  | March 31, 2021 |  | June 30, 2020 |
| Operating lease right-of-use asset | $ | 21,245 |  |  | $ | 23,784 |  |
| Deferred service costs, non-current | 5,531 |  |  | 4,632 |  |
| Prepaid expense, non-current | 2,007 |  |  | 1,576 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 955 |  |  | 1,201 |  |
| Restricted cash, non-current | 927 |  |  | 1,607 |  |
| Non-marketable equity securities | 128 |  |  | 128 |  |
| Total other assets | $ | 32,363 |  |  | $ | 34,499 |  |

[0001375365-21-000034:notes:67]
[same as prior period, unchanged from 0001375365-21-000011:notes:66]

[0001375365-21-000034:notes:68]
|  | March 31, 2021 |  | June 30, 2020 |
| Accrued payroll and related expenses | $ | 43,789 |  |  | $ | 33,577 |  |
| Contract manufacturing liabilities | 38,176 |  |  | 36,249 |  |
| Customer deposits | 15,744 |  |  | 9,942 |  |
| Accrued warranty costs | 10,813 |  |  | 9,984 |  |
| Operating lease liability | 6,797 |  |  | 6,310 |  |
| Accrued cooperative marketing expenses | 6,436 |  |  | 5,925 |  |
| Accrued professional fees | 2,238 |  |  | 5,661 |  |
| Accrued legal liabilities (Note 11) | — |  |  | 18,114 |  |
| Others | 29,749 |  |  | 29,639 |  |
| Total accrued liabilities | $ | 153,742 |  |  | $ | 155,401 |  |

[0001375365-21-000034:notes:69]
[same as prior period, unchanged from 0001375365-21-000011:notes:68]

[0001375365-21-000034:notes:70]
[same as prior period, unchanged from 0001375365-21-000011:notes:69]

[0001375365-21-000034:notes:71]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved. During the quarter ended March 31, 2021, the target average closing prices for both tranches were met but no determination has been made if there has been adequate progress in remediating the Company’s material weaknesses in its internal control over financial reporting. No cash payment had been made for either of the two tranches as of March 31, 2021.

[0001375365-21-000034:notes:72]
Performance bonuses for a senior executive and two members of the Board are earned based on achieving a specified target average closing price for the Company’s common stock over the specified period as determined by the Board at the grant dates and continuous services through the payment dates. A senior executive earned an aggregate cash payment of $0.1 million when the target average closing price was met in the fourth quarter of fiscal year 2020. The two members of the Board can earn

[0001375365-21-000034:notes:73]
aggregate cash payments of $0.3 million in two tranches if the target average closing price reaches $31.61 for the first tranche and $32.99 per share for the second tranche. During the quarter ended March 31, 2021, the target average closing prices for both tranches were met and the cash payment of $0.15 million for the first tranche was made to the two Board members.

[0001375365-21-000034:notes:74]
[same as prior period, unchanged from 0001375365-21-000011:notes:73]

[0001375365-21-000034:notes:75]
With the satisfaction of the target average closing price conditions in the quarter ended March 31, 2021, the Company trued up all the unpaid performance bonuses to the cash payment value. As of March 31, 2021, the full cash value of the bonuses, except the Chief Executive Officer's first tranche performance bonus, was recorded as an accrued liability on the Company's condensed consolidated balance sheet. The Company is still remediating its material weaknesses in its internal control over financial reporting, and estimates that it is probable that the performance condition will be met through the expiration date of the award. Therefore, as of March 31, 2021, the Company trued up the accrued liability for the Chief Executive Officer’s first tranche award to the expected payable amount vested through the period end and the unrecognized cash value will be recorded over the remaining service period.

[0001375365-21-000034:notes:76]
Based on the cash payment value and estimated fair value of these performance bonuses as of March 31, 2021 and June 30, 2020, the Company recorded a $7.1 million and $2.1 million liability, respectively, of which $7.1 million and $1.5 million, respectively, was recorded within accrued liabilities and $0.0 million and $0.6 million, respectively, was recorded within other long-term liabilities on the Company's condensed consolidated balance sheet. An unrecognized compensation expense of $1.1 million will be recorded over the remaining service periods of 0.43 years. The expense recognized during the three months ended March 31, 2021 and 2020 was $2.5 million and $0.2 million, and $5.1 million and $0.2 million for the nine months ended March 31, 2021 and 2020, respectively.

[0001375365-21-000034:notes:77]
[same as prior period, unchanged from 0001375365-21-000011:notes:75]

[0001375365-21-000034:notes:78]
|  | March 31, 2021 |  | June 30, 2020 |
| Operating lease liability, non-current | $ | 15,238 |  |  | $ | 18,102 |  |
| Accrued unrecognized tax benefits including related interest and penalties | 18,088 |  |  | 15,496 |  |
| Accrued warranty costs, non-current | 2,712 |  |  | 2,395 |  |
| Others | 5,071 |  |  | 6,002 |  |
| Total other long-term liabilities | $ | 41,109 |  |  | $ | 41,995 |  |

[0001375365-21-000034:notes:79]
[same as prior period, unchanged from 0001375365-21-000011:notes:77]

[0001375365-21-000034:notes:80]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Balance, beginning of the period | $ | 13,503 |  |  | $ | 11,441 |  |  | $ | 12,379 |  |  | $ | 11,034 |  |
| Provision for warranty | 6,791 |  |  | 8,521 |  |  | 22,250 |  |  | 25,627 |  |
| Costs utilized | (7,441) |  |  | (8,130) |  |  | (22,501) |  |  | (24,907) |  |
| Change in estimated liability for pre-existing warranties | 672 |  |  | (98) |  |  | 1,397 |  |  | (20) |  |
| Balance, end of the period | 13,525 |  |  | 11,734 |  |  | 13,525 |  |  | 11,734 |  |
| Current portion | 10,813 |  |  | 9,386 |  |  | 10,813 |  |  | 9,386 |  |
| Non-current portion | $ | 2,712 |  |  | $ | 2,348 |  |  | $ | 2,712 |  |  | $ | 2,348 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-21-000034:notes:81]
Fair Value Disclosure
    The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-21-000034:notes:82]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2021 and June 30, 2020. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of March 31, 2021.

[0001375365-21-000034:notes:83]
[same as prior period, unchanged from 0001375365-21-000011:notes:81]

[0001375365-21-000034:notes:84]
The following table sets forth the Company’s financial instruments as of March 31, 2021 and June 30, 2020, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-21-000034:notes:85]
| March 31, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | 151 |  |
| Certificates of deposit (2) | — |  |  | 854 |  |  | — |  |  | 854 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 151 |  |  | $ | 854 |  |  | $ | 1,571 |  |  | $ | 2,575 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| June 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,163 |  |
| Certificates of deposit (2) | — |  |  | 836 |  |  | — |  |  | 836 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,163 |  |  | $ | 836 |  |  | $ | 1,571 |  |  | $ | 3,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |

[0001375365-21-000034:notes:86]
(1) $0.0 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.2 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2021 and June 30, 2020, respectively.

[0001375365-21-000034:notes:87]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.4 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2021 and June 30, 2020, respectively.

[0001375365-21-000034:notes:88]
(3) As of March 31, 2021, the Company no longer measures performance awards liability at fair value because the Company trued up the performance awards liability to the cash payment value. As of June 30, 2020, the current portion of the performance awards liability of $1.5 million is included in accrued liabilities and the non-current portion of $0.6 million is included in other long-term liabilities in the condensed consolidated balance sheets.

[0001375365-21-000034:notes:89]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three and nine months ended March 31, 2021, the credit losses related to the Company’s investments was not significant.

[0001375365-21-000034:notes:90]
As of June 30, 2020, the Company estimated the fair value of performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of June 30, 2020 are as follows:

[0001375365-21-000034:notes:91]
[same as prior period, unchanged from 0001375365-21-000011:notes:91]

[0001375365-21-000034:notes:92]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2021 and 2020.

[0001375365-21-000034:notes:93]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and nine months ended March 31, 2021 and 2020.

[0001375365-21-000034:notes:94]
The following is a summary of the Company’s investment in an auction rate security as of March 31, 2021 and June 30, 2020 (in thousands):

[0001375365-21-000034:notes:95]
|  | March 31, 2021 and June 30, 2020 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179) |  |  | $ | 1,571 |  |

[0001375365-21-000034:notes:96]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and nine months ended March 31, 2021 and 2020.

[0001375365-21-000034:notes:97]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2021 and June 30, 2020, total debt of $85.4 million and $29.4 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.


## us-gaap:DebtDisclosureTextBlock

[0001375365-21-000034:notes:98]
Short-term and Long-term Debt
    Short-term debt obligations as of March 31, 2021 and June 30, 2020 consisted of the following (in thousands):

[0001375365-21-000034:notes:99]
|  | March 31, |  | June 30, |
|  | 2021 |  | 2020 |
| Line of credit: |  |  |  |
| CTBC Bank | $ | 18,000 |  |  | $ | — |  |
| E.SUN Bank | 15,000 |  |  | — |  |
| Total line of credit | 33,000 |  |  | — |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,503 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 27,867 |  |  | 5,697 |  |
| Total term loans | 52,370 |  |  | 29,401 |  |
| Total debt | 85,370 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 57,503 |  |  | 23,704 |  |
| Debt, Non-current | $ | 27,867 |  |  | $ | 5,697 |  |

[0001375365-21-000034:notes:100]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-21-000034:notes:101]
Bank of America

[0001375365-21-000034:notes:102]
2018 Bank of America Credit Facility

[0001375365-21-000034:notes:103]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 30, 2021 and provide that in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. The amendment was accounted for as a modification and the impact was immaterial to the condensed consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-21-000034:notes:104]
As of March 31, 2021 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2021 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.2 million and $0.6 million as of March 31, 2021 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of March 31, 2021, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-21-000034:notes:105]
CTBC Bank

[0001375365-21-000034:notes:106]
CTBC Credit Facility

[0001375365-21-000034:notes:107]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. In February 2021, CTBC Bank amended the USD interest rate to be the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

[0001375365-21-000034:notes:108]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.5 million and $23.7 million at March 31, 2021 and June 30, 2020, respectively. The interest rate for these loans were 0.74% per annum as of March 31, 2021 and 0.63% per annum as of June 30, 2020. As of March 31, 2021 and June 30, 2020, the outstanding borrowings under the CTBC Credit Facility revolving line of credit were $18.0 million and $0.0 million, respectively. The interest rates were from 1.03% to 1.26% per annum as of March 31, 2021. As of March 31, 2021, the amount available for future borrowing under the CTBC Credit Facility was $7.5 million. As of March 31, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.0 million.

[0001375365-21-000034:notes:109]
2020 CTBC Term Loan Facility due June 4, 2030

[0001375365-21-000034:notes:110]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

[0001375365-21-000034:notes:111]
As of March 31, 2021 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $27.9 million and $5.7 million, respectively. The interest rates for these loans were 0.45% per annum as of March 31, 2021 and June 30, 2020. The net book value of the property serving as collateral as of March 31, 2021 was $38.1 million. As of March 31, 2021, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000034:notes:112]
E.SUN Bank Credit Facility

[0001375365-21-000034:notes:113]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. Such Credit Facility provides for the issuance of

[0001375365-21-000034:notes:114]
loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. The term of the E.SUN Credit Facility expires on September 18, 2021.

[0001375365-21-000034:notes:115]
Generally, the interest for base rate loans made under the E.SUN Credit Facility is based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment.  Interest for adjustable loan rate loans made under the E.SUN Credit Facility is based upon an average one-year fixed rate time saving deposit rate of a selected reference bank which shall be a well-known domestic bank in Taiwan, and is subject to occasional adjustment. The E.SUN Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event such Taiwan subsidiary of the Company has an overdue liability at another financial organization. There are no financial covenants associated with the E.SUN Credit Facility.

[0001375365-21-000034:notes:116]
Terms for specific drawdown instruments issued under the E.SUN Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions negotiated with E.SUN Bank. A Notification and Confirmation of Credit Conditions agreement under the E.SUN Credit Facility was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days and with an interest rate calculated based on the higher of LIBOR plus 0.75% then divided by 0.946 or TAIFX plus 0.55% then divided by 0.946. As of March 31, 2021, the amounts outstanding under the E.SUN Credit Facility were  $15.0 million and the interest rates for these loans were approximately 1.0% per annum. At March 31, 2021, the amount available for future borrowing under the E.SUN Credit Facility was $15.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-21-000034:notes:117]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2021 and 2020 were as follows (in thousands):

[0001375365-21-000034:notes:118]
|  |  | Three Months EndedMarch 31, | Nine Months EndedMarch 31, |
|  |  | 2021 |  | 2020 | 2021 |  | 2020 |
| Operating lease expense (including expense for lease agreements with related parties of $347 and $1,040 for the three and nine months ended March 31, 2021, respectively, and $359 and $1,086 for the three and nine months ended March 31, 2020, respectively) |  | $ | 1,952 |  |  | $ | 1,605 |  | $ | 5,900 |  |  | $ | 4,909 |  |
| Cash payments for operating leases (including payments to related parties of $347 and $1,040 for the three and nine months ended March 31, 2021, respectively, and $369 and $1,106 for the three and nine months ended March 31, 2020, respectively) |  | $ | 1,994 |  |  | $ | 1,667 |  | $ | 5,951 |  |  | $ | 5,082 |  |

[0001375365-21-000034:notes:119]
During the three and nine months ended March 31, 2021 and 2020, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable payments expensed in the three and nine months ended March 31, 2021 were $0.4 million and $1.2 million, respectively. Variable payments expensed in the three months and nine months ended March 31, 2020 were $0.2 million and $0.9 million, respectively.

[0001375365-21-000034:notes:120]
As of March 31, 2021, the weighted average remaining lease term for operating leases was 4.0 years and the weighted average discount rate was 3.5%. Future minimum lease payments under noncancelable operating lease arrangements as of March 31, 2021 were as follows (in thousands):

[0001375365-21-000034:notes:121]
| Fiscal Year: |  | Minimum lease payments |
| 2021 (remainder) |  | $ | 2,010 |  |
| 2022 |  | 6,795 |  |
| 2023 |  | 5,125 |  |
| 2024 |  | 4,326 |  |
| 2025 |  | 4,367 |  |
| 2026 and beyond |  | 1,002 |  |
| Total future lease payments |  | $ | 23,625 |  |
| Less: Imputed interest |  | (1,590) |  |
| Present value of operating lease liabilities |  | $ | 22,035 |  |

[0001375365-21-000034:notes:122]
As of March 31, 2021, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-21-000034:notes:123]
The Company has entered into lease agreements with related parties.  See Note 8, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-21-000034:notes:124]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-21-000034:notes:125]
Dealings with Ablecom

[0001375365-21-000034:notes:126]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-21-000034:notes:127]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.5% and 95.1% of the chassis included in the products sold by the Company during the three months ended March 31, 2021 and 2020, respectively, and 92.5% and 95.3% of the chassis included in the products sold by the Company during the nine months ended March 31, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-21-000034:notes:128]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the

[0001375365-21-000034:notes:129]
Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-21-000034:notes:130]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $35.5 million and $23.2 million at March 31, 2021 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-21-000034:notes:131]
Dealings with Compuware

[0001375365-21-000034:notes:132]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-21-000034:notes:133]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-21-000034:notes:134]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-21-000034:notes:135]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-21-000034:notes:136]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $44.0 million and $45.7 million at March 31, 2021 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-21-000034:notes:137]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2021 and 2020, are as follows (in thousands):

[0001375365-21-000034:notes:138]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 34,924 |  |  | $ | 37,607 |  |  | $ | 85,827 |  |  | $ | 115,295 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,580 |  |  | $ | 7,503 |  |  | $ | 22,451 |  |  | $ | 19,456 |  |
| Purchases (1) | 32,340 |  |  | 24,908 |  |  | 100,911 |  |  | 91,662 |  |

[0001375365-21-000034:notes:139]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-21-000034:notes:140]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2021 and 2020.

[0001375365-21-000034:notes:141]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2021 and June 30, 2020 (in thousands):

[0001375365-21-000034:notes:142]
|  | March 31, 2021 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,620 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 32,243 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 14,486 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 36,355 |  |  | 46,518 |  |
| Other long-term liabilities (3) | — |  |  | 186 |  |

[0001375365-21-000034:notes:143]
____________________________

[0001375365-21-000034:notes:144]
(1) Other receivables include receivables from vendors.

[0001375365-21-000034:notes:145]
(2) Includes current portion of operating lease liabilities.

[0001375365-21-000034:notes:146]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-21-000034:notes:147]
See Note 1, "Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-21-000034:notes:148]
[same as prior period, unchanged from 0001375365-21-000011:notes:147]

[0001375365-21-000034:notes:149]
[same as prior period, unchanged from 0001375365-21-000011:notes:148]

[0001375365-21-000034:notes:150]
As of March 31, 2021, the Company had 3,100,300 authorized shares available for future issuance under the 2020 Plan.

[0001375365-21-000034:notes:151]
[same as prior period, unchanged from 0001375365-21-000011:notes:150]

[0001375365-21-000034:notes:152]
On August 9, 2020, the Board approved a share repurchase program to repurchase up to an aggregate of $30.0 million of the Company's common stock at market prices. The program was effective until December 31, 2020 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended September 30, 2020, 1,142,294 shares of common stock were repurchased for $30.0 million and the program ended. Repurchased shares were recorded as treasury shares in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000034:notes:153]
On December 11, 2020, the Company retired 2,475,419 shares of common stock, which were recorded as treasury stock in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000034:notes:154]
On October 31, 2020, the Board approved a share repurchase program to repurchase up to an aggregate of $50.0 million of the Company's common stock at market prices. The program was effective until October 31, 2021 or if earlier, until the maximum amount of common stock was repurchased. As of March 31, 2021, 1,675,746 shares of common stock were repurchased and retired for an aggregate $50.0 million and the program ended.

[0001375365-21-000034:notes:155]
On January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended March 31, 2021, 1,155,000 shares of common stock were repurchased for $40.7 million. All repurchased shares have been retired as of March 31, 2021.

[0001375365-21-000034:notes:156]
During the three months ended March 31, 2021, the Company repurchased and retired 1,250,539 shares of common stock for an aggregated $43.7 million. During the nine months ended March 31, 2021, the Company repurchased and retired 5,306,165 shares of common stock for an aggregated $120.7 million.

[0001375365-21-000034:notes:157]
[same as prior period, unchanged from 0001375365-21-000011:notes:154]

[0001375365-21-000034:notes:158]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-21-000034:notes:159]
[same as prior period, unchanged from 0001375365-21-000011:notes:157]

[0001375365-21-000034:notes:160]
[same as prior period, unchanged from 0001375365-21-000011:notes:158]

[0001375365-21-000034:notes:161]
[same as prior period, unchanged from 0001375365-21-000011:notes:159]

[0001375365-21-000034:notes:162]
[same as prior period, unchanged from 0001375365-21-000011:notes:160]

[0001375365-21-000034:notes:163]
The fair value of stock option grants for the three and nine months ended March 31, 2021 and 2020 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-21-000034:notes:164]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Risk-free interest rate | 0.58 | % |  | 0.53% - 1.49% |  | 0.27% - 0.58% |  | 0.53% - 1.72% |
| Expected term | 5.98 years |  | 6.27 years |  | 5.98 years |  | 6.27 years |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 50.32 | % |  | 49.61% - 50.46% |  | 50.32% - 50.43% |  | 49.61% - 50.46% |
| Weighted-average fair value | $ | 15.91 |  |  | $ | 10.15 |  |  | $ | 13.57 |  |  | $ | 9.5 |  |

[0001375365-21-000034:notes:165]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2021 and 2020 (in thousands):

[0001375365-21-000034:notes:166]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of sales | $ | 402 |  |  | $ | 370 |  |  | $ | 1,312 |  |  | $ | 1,149 |  |
| Research and development | 3,328 |  |  | 3,043 |  |  | 10,369 |  |  | 9,299 |  |
| Sales and marketing | 503 |  |  | 417 |  |  | 1,517 |  |  | 1,276 |  |
| General and administrative | 3,261 |  |  | 975 |  |  | 7,919 |  |  | 3,099 |  |
| Stock-based compensation expense before taxes | 7,494 |  |  | 4,805 |  |  | 21,117 |  |  | 14,823 |  |
| Income tax impact | (2,389) |  |  | (2,978) |  |  | (6,080) |  |  | (5,142) |  |
| Stock-based compensation expense, net | $ | 5,105 |  |  | $ | 1,827 |  |  | $ | 15,037 |  |  | $ | 9,681 |  |

[0001375365-21-000034:notes:167]
As of March 31, 2021, $7.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 4.13 years, $39.3 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.47 years and $0.3 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.36 years.

[0001375365-21-000034:notes:168]
[same as prior period, unchanged from 0001375365-21-000011:notes:166]

[0001375365-21-000034:notes:169]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 1,000,000 common stock shares to the Company’s CEO (the “2021 CEO Performance Stock Option”). The 2021 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board of Directors and (2) service through each vesting date. Each of the five vesting tranches of the 2021 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $120.00 per share thereafter (based on a 60 calendar day trailing average, counting only trading days), has been achieved, and (ii) any one of the following five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to March 2, 2024, the Company’s CEO must hold shares that he acquires until March 2, 2024, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-21-000034:notes:170]
The achievement status of the operational and stock price milestones as of March 31, 2021 was as follows:

[0001375365-21-000034:notes:171]
| Annualized Revenue Milestone |  | Achievement Status | Stock Price Milestone | Achievement Status |  |  |  |
| (in billions) |  |  |  |  |  |  |  |
| $4.0 |  | Probable | $45 | Not met |  |  |  |
| $4.8 |  | Probable | $60 | Not met |  |  |  |
| $5.8 |  | Probable | $75 | Not met |  |  |  |
| $6.8 |  | Probable | $95 | Not met |  |  |  |
| $8.0 |  | — | $120 | Not met |  |  |  |

[0001375365-21-000034:notes:172]
On the grant date, a Monte Carlo simulation was used to determine for each tranche (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine whether achievement is probable for each operational

[0001375365-21-000034:notes:173]
milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-21-000034:notes:174]
During the three and nine months ended March 31, 2021, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.3 million and $0.3 million, respectively. No compensation expense related to the 2021 CEO Performance Stock Option was recognized during the three and nine months ended March 31, 2020. As of March 31, 2021 and June 30, 2020, the Company had $11.3 million and $0, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2021 is expected to be recognized over a period of five years.

[0001375365-21-000034:notes:175]
The following table summarizes stock option activity during the nine months ended March 31, 2021 under all plans:

[0001375365-21-000034:notes:176]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  |  |  |  |
| Granted |  | 1,371,410 |  |  | $ | 40.68 |  |  |  |  |  |
| Exercised |  | (1,195,414) |  |  | $ | 17.02 |  |  |  |  |  |
| Forfeited/Cancelled |  | (39,790) |  |  | $ | 23.97 |  |  |  |  |  |
| Balance as of March 31, 2021 |  | 5,515,974 |  |  | $ | 25.16 |  |  | 5.22 |  |  |
| Options vested and exercisable at March 31, 2021 |  | 3,811,698 |  |  | $ | 20.10 |  |  | 3.36 |  |  |

[0001375365-21-000034:notes:177]
[same as prior period, unchanged from 0001375365-21-000011:notes:169]

[0001375365-21-000034:notes:178]
[same as prior period, unchanged from 0001375365-21-000011:notes:170]

[0001375365-21-000034:notes:179]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. 50% of the PRSUs vested at June 30, 2018 when performance conditions were achieved, while the remainder vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. As of March 31, 2021, the remaining 50% of the PRSUs had vested in accordance with the terms of the grant.

[0001375365-21-000034:notes:180]
[same as prior period, unchanged from 0001375365-21-000011:notes:172]

[0001375365-21-000034:notes:181]
The following table summarizes RSU and PRSU activity during the nine months ended March 31, 2021 under all plans:

[0001375365-21-000034:notes:182]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2020 | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  | (1) |  | $ | 22.29 |  |
| Granted | 969,493 |  |  | $ | 28.99 |  |  | 30,000 |  |  |  | $ | 34.27 |  |
| Released | (584,570) |  |  | $ | 20.99 |  |  | (12,000) |  |  |  | $ | 27.10 |  |
| Forfeited | (158,215) |  |  | $ | 22.88 |  |  | (30,000) |  |  |  | $ | 20.37 |  |
| Balance as of March 31, 2021 | 1,994,735 |  |  | $ | 23.91 |  |  | 30,000 |  |  |  | $ | 34.27 |  |

[0001375365-21-000034:notes:183]
[same as prior period, unchanged from 0001375365-21-000011:notes:175]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-21-000034:notes:184]
Income Taxes
    The Company recorded a benefit for income taxes of $0.2 million for the three months ended March 31, 2021, and a provision for income taxes of $8.5 million for the nine months ended March 31, 2021. The Company recorded a benefit for income taxes of $0.9 million for the three months ended March 31, 2020 and a provision of $9.8 million for the nine months ended March 31, 2020. The effective tax rate was (1.2)% and 10.5% for the three and nine months ended March 31, 2021, respectively, and (5.6)% and 12.8% for the three and nine months ended March 31, 2020, respectively. The effective tax rate for the three months ended March 31, 2021 is higher than that for the three months ended March 31, 2020, primarily due to release of uncertain tax positions after settlement of a Taiwan tax audit in the prior year. The effective tax rate for the nine months ended March 31, 2021 is lower than that for the nine months ended March 31, 2020, primarily due to Company's tax benefit arising from additional employees' exercises of stock options in the current year.

[0001375365-21-000034:notes:185]
[same as prior period, unchanged from 0001375365-21-000011:notes:177]

[0001375365-21-000034:notes:186]
[same as prior period, unchanged from 0001375365-21-000011:notes:178]

[0001375365-21-000034:notes:187]
As of March 31, 2021, the Company had gross unrecognized tax benefits of $41.1 million, of which, $27.0 million, if recognized, would affect the Company's effective tax rate. During the nine months ended March 31, 2021, there was a $1.7 million increase in gross unrecognized tax benefits, primarily due to an uncertain tax position in a foreign jurisdiction. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2021, the Company had accrued $2.6 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-21-000034:notes:188]
[same as prior period, unchanged from 0001375365-21-000011:notes:180]

[0001375365-21-000034:notes:189]
[same as prior period, unchanged from 0001375365-21-000011:notes:181]

[0001375365-21-000034:notes:190]
[same as prior period, unchanged from 0001375365-21-000011:notes:182]

[0001375365-21-000034:notes:191]
The federal statute of limitations remains open in general for tax years ended June 30, 2018 through 2020. Various states statutes of limitations remain open in general for tax years ended June 30, 2017 through 2020. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2015 through 2020. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.2 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-21-000034:notes:192]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss.  Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes.  Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales.  The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO.  Discovery has commenced, and the Court has calendared a hearing on class certification for January 22, 2022. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000034:notes:193]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.  The parties are in the process of briefing demurrers, which are set for hearing on August 24, 2021. The case is otherwise stayed for the time being. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000034:notes:194]
On November 13, 2020, Build Group Inc. (“Build Group”) filed a complaint against the Company in the Superior Court for Santa Clara County, seeking damages of approximately $2.0 million.  Build Group served the complaint on the Company on December 1, 2020.  Build Group alleged that the Company breached the construction contract between the Company and Build Group by failing to approve or reject certain requests for change orders to the scope of work covered by the construction project in a timely manner, or at all. A substantial portion of the amounts covered by the change orders at issue related to delays in the construction project.  Build Group asserted that these delays were beyond its control and that therefore it was entitled to additional payments as a result of the delays in completion of the project.  The Company believed that it had meritorious defenses to Build Group’s claims, but nonetheless negotiated a settlement with Build Group. The settlement agreement resolving this dispute was executed effective January 19, 2021. As a result, the Company did not have to respond to the complaint. Per the settlement agreement, Build Group agreed to dismiss the entire action with prejudice once the Company complied with its obligations under the settlement agreement. The Company complied with its obligations and paid $2.0 million in the quarter ended March 31, 2021. Build Group submitted the dismissal, which the court has granted that concludes the matter.

[0001375365-21-000034:notes:195]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news

[0001375365-21-000034:notes:196]
article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

[0001375365-21-000034:notes:197]
Other legal proceedings and indemnifications

[0001375365-21-000034:notes:198]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2021 and any prior periods.

[0001375365-21-000034:notes:199]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-21-000034:notes:200]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2021, these remaining noncancelable commitments were $306.4 million, including $79.5 million for related parties.

[0001375365-21-000034:notes:201]
Standby Letter of Credit— In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-21-000034:notes:202]
[same as prior period, unchanged from 0001375365-21-000011:notes:194]

[0001375365-21-000034:notes:203]
[same as prior period, unchanged from 0001375365-21-000011:notes:195]

[0001375365-21-000034:notes:204]
|  | March 31, |  | June 30, |
|  | 2021 |  | 2020 |
| Long-lived assets: |  |  |  |
| United States | $ | 180,917 |  |  | $ | 178,812 |  |
| Asia | 81,668 |  |  | 51,605 |  |
| Europe | 2,981 |  |  | 3,368 |  |
|  | $ | 265,566 |  |  | $ | 233,785 |  |

[0001375365-21-000034:notes:205]
[same as prior period, unchanged from 0001375365-21-000011:notes:197]


## us-gaap:SubsequentEventsTextBlock

[0001375365-21-000034:notes:206]
Subsequent EventOn May 5, 2021, certain current and former directors and officers were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW.  The Company was also named as a nominal defendant.  The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company's officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission.  The plaintiff seeks unspecified compensatory damages and other equitable relief.  The Company has not yet been formally served with the complaint, but the Company intends to defend the lawsuit vigorously.
