# SMCI MD&A — 0001375365-20-000011


## mdna

[0001375365-20-000011:mdna:1]
[same as prior period, unchanged from 0001375365-19-000084:mdna:1]

[0001375365-20-000011:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019 (the “2019 Comprehensive 10-K”), which includes our consolidated financial statements for the fiscal years ended June 30, 2019 and 2018.

[0001375365-20-000011:mdna:3]
Nasdaq Relisting of Our Common Stock

[0001375365-20-000011:mdna:4]
On January 14, 2020, our common stock was relisted on the NASDAQ Global Select Market under the symbol “SMCI.”

[0001375365-20-000011:mdna:5]
[same as prior period, unchanged from 0001375365-19-000084:mdna:5]

[0001375365-20-000011:mdna:6]
[same as prior period, unchanged from 0001375365-19-000084:mdna:6]

[0001375365-20-000011:mdna:7]
We commenced operations in 1993 and have been profitable every year since inception. Although our net sales for the three months ended December 31, 2019 declined from our net sales for the corresponding period in the prior year, we seek

[0001375365-20-000011:mdna:8]
to increase our sales and profits every quarter. We believe that to do so, we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the product introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-20-000011:mdna:9]
For the three months ended December 31, 2019, our industry experienced a slightly increased demand as evidenced by some improvement in demand from hyperscale datacenter customers primarily associated with the public cloud, offset by continued soft enterprise datacenter customer demand. The industry continued to see declining component prices for memory and SSDs, which offset shipment volumes leading to lower revenues in comparison to the prior year.

[0001375365-20-000011:mdna:10]
As a result, we experienced higher volume of server and storage systems purchased by our datacenter customers as compared to last year for the same period, but lower component prices led us to adjust lower our average selling prices per compute node, resulting in lower server and storage systems revenue. Gross margins improved because the prices we charged our customers on an average declined at a slower rate than the reduction in prices we paid for the components we purchased. Therefore, despite the decline in net sales, our gross margin increased. As a result, net income and earnings per share increased as compared to the comparable period in the prior fiscal year.

[0001375365-20-000011:mdna:11]
[same as prior period, unchanged from 0001375365-19-000084:mdna:10]

[0001375365-20-000011:mdna:12]
The following is a summary of our financial highlights of the second quarter of fiscal year 2020:

[0001375365-20-000011:mdna:13]
| • | Net sales decreased by 6.5% as compared to the three months ended December 31, 2018. The decrease was mainly due to a decline in average selling prices per compute node caused by lower component prices offset by an increase in the volume of server and storage systems sold. |

[0001375365-20-000011:mdna:14]
| • | Gross margin increased to 15.9% in the three months ended December 31, 2019 from 13.7% for the three months ended December 31, 2018, primarily due to a favorable geographic, customer and product mix and lower costs for key components. |

[0001375365-20-000011:mdna:15]
| • | Operating expenses increased by 8.2% as compared to the three months ended December 31, 2018, and were equal to 12.7% and 11.0% of net sales in the three months ended December 31, 2019 and 2018, respectively. |

[0001375365-20-000011:mdna:16]
| • | Effective tax rate decreased from 18.4% in the three months ended December 31, 2018 to 7.9% in the three months ended December 31, 2019. |

[0001375365-20-000011:mdna:17]
[same as prior period, unchanged from 0001375365-19-000084:mdna:16]

[0001375365-20-000011:mdna:18]
Net sales. Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact our net sales are the number of compute nodes sold, the average selling prices per node for our server and storage system sales and units shipped and the average selling price per unit for our subsystem and accessories. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs, and memory, and the prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories. A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, and due to price transparency of certain higher cost components, we must actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs, and actively adjust our procurement practices in anticipation of near term fluctuations in market prices for key components.

[0001375365-20-000011:mdna:19]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-20-000011:mdna:20]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the first quarter of fiscal year 2020 and during fiscal year 2019, we continued to expand manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of subsystems, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 10.3% and 9.3% of total cost of sales for the three months ended December 31, 2019 and 2018, respectively, and 10.0% and 9.2% for the six months ended December 31, 2019 and 2018, respectively. For further details on our dealings with related parties, see Part I, Item 1, Note 9, “Related Party Transactions.”

[0001375365-20-000011:mdna:21]
Research and development expenses. Research and development expenses consist of personnel expenses including: salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as other product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-20-000011:mdna:22]
[same as prior period, unchanged from 0001375365-19-000084:mdna:21]

[0001375365-20-000011:mdna:23]
[same as prior period, unchanged from 0001375365-19-000084:mdna:22]

[0001375365-20-000011:mdna:24]
[same as prior period, unchanged from 0001375365-19-000084:mdna:23]

[0001375365-20-000011:mdna:25]
[same as prior period, unchanged from 0001375365-19-000084:mdna:24]

[0001375365-20-000011:mdna:26]
[same as prior period, unchanged from 0001375365-19-000084:mdna:25]

[0001375365-20-000011:mdna:27]
[same as prior period, unchanged from 0001375365-19-000084:mdna:26]

[0001375365-20-000011:mdna:28]
[same as prior period, unchanged from 0001375365-19-000084:mdna:27]

[0001375365-20-000011:mdna:29]
Except for the changes to our accounting policy as a result of the adoption of the new lease accounting guidance on July 1, 2019, there have been no material change to our critical accounting policies and estimates as compared to those disclosed in our 2019 Comprehensive 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Organization and Summary of Significant Accounting Policies" in our notes to the condensed consolidated financial statements in this Quarterly Report.

[0001375365-20-000011:mdna:30]
[same as prior period, unchanged from 0001375365-19-000084:mdna:29]

[0001375365-20-000011:mdna:31]
[same as prior period, unchanged from 0001375365-19-000084:mdna:30]

[0001375365-20-000011:mdna:32]
The following table presents net sales by product type for the three and six months ended December 31, 2019 and 2018 (dollars in millions):

[0001375365-20-000011:mdna:33]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Server and storage systems | $ | 672.7 |  |  | $ | 762.6 |  |  | $ | (89.9 | ) |  | (11.8 | )% |  | $ | 1,308.7 |  |  | $ | 1,568.5 |  |  | $ | (259.8 | ) |  | (16.6 | )% |
| Percentage of total net sales | 77.2 | % |  | 81.9 | % |  |  |  |  |  | 78.3 | % |  | 82.4 | % |  |  |  |  |
| Subsystems and accessories | $ | 198.2 |  |  | $ | 168.9 |  |  | $ | 29.3 |  |  | 17.3 | % |  | $ | 362.0 |  |  | $ | 334.1 |  |  | $ | 27.9 |  |  | 8.4 | % |
| Percentage of total net sales | 22.8 | % |  | 18.1 | % |  |  |  |  |  | 21.7 | % |  | 17.6 | % |  |  |  |  |
| Total net sales | $ | 870.9 |  |  | $ | 931.5 |  |  | $ | (60.6 | ) |  | (6.5 | )% |  | $ | 1,670.7 |  |  | $ | 1,902.6 |  |  | $ | (231.9 | ) |  | (12.2 | )% |

[0001375365-20-000011:mdna:34]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:35]
The period-over-period decrease in net sales of our server and storage systems was primarily due to a decrease in average selling price per compute node by approximately 20%. The decline in average selling prices was primarily due to substantially lower costs for key components, specifically for memory and SSDs. The decrease in the average selling price was partially offset by an increase in the number of units of compute nodes shipped by approximately 10%, driven by a higher demand for our products from our datacenter customers.

[0001375365-20-000011:mdna:36]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the volume of subsystems and accessories sold by approximately 31% due to increased demand from our indirect sales channel.

[0001375365-20-000011:mdna:37]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:38]
The period-over-period decrease in net sales of our server and storage systems was primarily due to a decrease in average selling price per compute node by approximately 17%. The decline in average selling prices was primarily due to substantially lower costs for key components.

[0001375365-20-000011:mdna:39]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the volume of subsystems and accessories sold by approximately 33%, partially offset by a decrease in the average selling prices per unit by approximately 16%.

[0001375365-20-000011:mdna:40]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs customers for the three and six months ended December 31, 2019 and 2018:

[0001375365-20-000011:mdna:41]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-20-000011:mdna:42]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:43]
The period-over-period increase in net sales through our indirect sales channel as a percentage of total net sales was primarily due to increased demand from channel partners supporting large end users and the lower average selling prices for our server and storage systems, caused by lower component pricing.  This resulted in the decline of direct customer and OEM net sales as a percentage of total net sales. While the number of units of compute nodes shipped to direct customers and OEMs increased by 10%, the period-over-period decrease in net sales to our direct customers and OEMs as a percentage of total net sales was lower primarily due to a 20% drop in average selling price.

[0001375365-20-000011:mdna:44]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:45]
The period-over-period increase in net sales through our indirect sales channel as a percentage of total net sales was primarily due to increased demand from the channel and the lower average selling prices for our server and storage systems, caused by lower component pricing. This resulted in the decline of direct customer and OEM net sales as a percentage of total net sales.  The period-over-period decrease in net sales to our direct customers and OEMs as a percentage of total net sales was primarily due to 17% lower average selling price per compute node.

[0001375365-20-000011:mdna:46]
The following table presents percentages of net sales by geographic region for the three and six months ended December 31, 2019 and 2018:

[0001375365-20-000011:mdna:47]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| United States | 60.6 | % |  | 55.0 | % |  | 5.6 | % |  | 59.6 | % |  | 56.7 | % |  | 2.9 | % |
| Europe | 16.9 | % |  | 19.4 | % |  | (2.5 | )% |  | 16.5 | % |  | 18.1 | % |  | (1.6 | )% |
| Asia | 19.0 | % |  | 21.1 | % |  | (2.1 | )% |  | 19.6 | % |  | 21.2 | % |  | (1.6 | )% |
| Others | 3.5 | % |  | 4.5 | % |  | (1.0 | )% |  | 4.3 | % |  | 4.0 | % |  | 0.3 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-20-000011:mdna:48]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:49]
The period-over-period increase in net sales in the United States as a percentage of total net sales for the three months ended December 31, 2019 and 2018 was primarily due to higher sales of our server and storage systems to our direct customers and OEMs and increased sales through our indirect sales channel. The period-over-period decrease in net sales in Asia as a percentage of total net sales was due primarily to decreased sales in China and Japan partially offset by increased sales in Taiwan and Korea. The decreased percentage of net sales in Europe was primarily due to lower sales in the United Kingdom and the Netherlands, partially offset by increased sales in Germany and Russia. The period-over-period decrease in net sales in other countries as a percentage of total net sales was due to lower sales in Brazil, South Africa and Israel.

[0001375365-20-000011:mdna:50]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:51]
The period-over-period increase in net sales in the United States as a percentage of total net sales for the six months ended December 31, 2019 and 2018 was primarily due to higher sales through our indirect sales channel. The period-over-period decrease in net sales in Asia as a percentage of total net sales was due primarily to decreased sales in China, Japan and Korea, partially offset by increased sales in Taiwan. The decreased percentage of net sales in Europe was primarily due to lower sales in the Netherlands, United Kingdom and Germany, partially offset by increased sales in Russia. The period-over-period increase in net sales in other countries as a percentage of total net sales was due to increased sales in South America, primarily Mexico.

[0001375365-20-000011:mdna:52]
[same as prior period, unchanged from 0001375365-19-000084:mdna:40]

[0001375365-20-000011:mdna:53]
Cost of sales and gross margin for the three and six months ended December 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000011:mdna:54]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Cost of sales | $ | 732.5 |  |  | $ | 803.6 |  |  | $ | (71.1 | ) |  | (8.8 | )% |  | $ | 1,401.4 |  |  | $ | 1,651.5 |  |  | $ | (250.1 | ) |  | (15.1 | )% |
| Gross profit | $ | 138.4 |  |  | $ | 127.9 |  |  | $ | 10.5 |  |  | 8.2 | % |  | $ | 269.3 |  |  | $ | 251.2 |  |  | $ | 18.1 |  |  | 7.2 | % |
| Gross margin | 15.9 | % |  | 13.7 | % |  |  |  | 2.2 | % |  | 16.1 | % |  | 13.2 | % |  |  |  | 2.9 | % |

[0001375365-20-000011:mdna:55]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:56]
The period-over-period decrease in cost of sales was primarily attributable to a decrease of $76.9 million in product costs related to the decrease in the cost of key components primarily associated with server and storage systems, offset by an

[0001375365-20-000011:mdna:57]
increase of $1.4 million in personnel expenses a result of an increase in the number of personnel, an increase in overhead costs of $2.4 million attributable primarily to increased tariffs and an increase of $1.4 million in other manufacturing costs.

[0001375365-20-000011:mdna:58]
The period-over-period increase in the gross margin percentage was primarily due to lower costs for key components, as the prices we charged our customers on average declined at a slower rate than the reduction in prices we paid for the components we purchased. In addition, in the three months ended December 31, 2019, as compared with three months ended December 31, 2018, we had a lower percentage of net sales in Asia where pricing is typically lower because the market there is more competitive, which had a positive impact on our gross margin percentage.

[0001375365-20-000011:mdna:59]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:60]
The period-over-period decrease in cost of sales was primarily attributable to a decrease of $258.1 million in product costs related to the decrease in the cost of key components primarily associated with server and storage systems, offset by an increase of $2.5 million in personnel expenses a result of an increase in the number of personnel, an increase in overhead costs of $10.0 million attributable primarily to increased tariffs and an increase of $1.0 million in manufacturing costs.

[0001375365-20-000011:mdna:61]
The period-over-period increase in the gross margin percentage was primarily due to lower costs for key components, as the prices we charged our customers on average declined at a slower rate than the reduction in prices we paid for the components we purchased. In addition, in the six months ended December 31, 2019 as compared with six months ended December 31, 2018 we had a lower percentage of net sales in Asia where pricing is typically lower because the market there is more competitive, which had a positive impact on our gross margin percentage.

[0001375365-20-000011:mdna:62]
[same as prior period, unchanged from 0001375365-19-000084:mdna:45]

[0001375365-20-000011:mdna:63]
Operating expenses for the three and six months ended December 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000011:mdna:64]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Research and development | $ | 55.6 |  |  | $ | 45.9 |  |  | $ | 9.7 |  |  | 21.1 | % |  | $ | 105.2 |  |  | $ | 88.9 |  |  | $ | 16.3 |  |  | 18.3 | % |
| Percentage of total net sales | 6.4 | % |  | 4.9 | % |  |  |  |  |  | 6.3 | % |  | 4.7 | % |  |  |  |  |
| Sales and marketing | $ | 22.0 |  |  | $ | 19.7 |  |  | $ | 2.3 |  |  | 11.7 | % |  | $ | 42.2 |  |  | $ | 38.0 |  |  | $ | 4.2 |  |  | 11.1 | % |
| Percentage of total net sales | 2.5 | % |  | 2.1 | % |  |  |  |  |  | 2.5 | % |  | 2.0 | % |  |  |  |  |
| General and administrative | $ | 33.0 |  |  | $ | 36.6 |  |  | $ | (3.6 | ) |  | (9.8 | )% |  | $ | 61.3 |  |  | $ | 70.0 |  |  | $ | (8.7 | ) |  | (12.4 | )% |
| Percentage of total net sales | 3.8 | % |  | 4.0 | % |  |  |  |  |  | 3.7 | % |  | 3.7 | % |  |  |  |  |
| Total operating expenses | $ | 110.6 |  |  | $ | 102.2 |  |  | $ | 8.4 |  |  | 8.2 | % |  | $ | 208.7 |  |  | $ | 196.9 |  |  | $ | 11.8 |  |  | 6.0 | % |
| Percentage of total net sales | 12.7 | % |  | 11.0 | % |  |  |  |  |  | 12.5 | % |  | 10.4 | % |  |  |  |  |

[0001375365-20-000011:mdna:65]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:66]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $6.4 million in personnel expenses as a result of an increase in the number of personnel, an increase of $1.5 million in other product development costs, a decrease of $0.6 million in reimbursements received for certain research and development costs that we incur as part of the joint product development and an increase of $1.1 million related primarily to facilities and other research and development expenses.

[0001375365-20-000011:mdna:67]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to an increase of $2.0 million in personnel expenses as a result of an increase in the number of personnel.

[0001375365-20-000011:mdna:68]
General and administrative expenses. The period-over-period decrease in general and administrative expenses includes a decrease of $5.5 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, offset by an increase of $2.0 million in personnel expenses as a result of an increase in the number of personnel.

[0001375365-20-000011:mdna:69]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:70]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $10.7 million in personnel expenses as a result of an increase in the number of personnel, an increase of $3.1 million in parts and materials expenses, and increase of $0.8 million in facilities expenses, a decrease of $0.6 million in reimbursements received for certain research and development costs that we incur as part of the joint product development and an increase of $0.8 million related primarily to other research and development expenses.

[0001375365-20-000011:mdna:71]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to an increase of $2.7 million in personnel expenses as a result of an increase in the number of personnel, an increase of $1.0 million related to participation in trade shows and an increase of $0.9 million in expenses related to advertising and promotion activities.

[0001375365-20-000011:mdna:72]
General and administrative expenses. The period-over-period decrease in general and administrative expenses includes a decrease of $12.6 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, offset by an increase of $3.3 million in personnel expenses as a result of an increase in the number of personnel.

[0001375365-20-000011:mdna:73]
[same as prior period, unchanged from 0001375365-19-000084:mdna:51]

[0001375365-20-000011:mdna:74]
Other income (expense), net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-20-000011:mdna:75]
[same as prior period, unchanged from 0001375365-19-000084:mdna:53]

[0001375365-20-000011:mdna:76]
Interest and other income (expense), net for the three and six months ended December 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000011:mdna:77]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Other income (expense), net | $ | (0.4 | ) |  | $ | 0.6 |  |  | $ | (1.0 | ) |  | (166.7 | )% |  | $ | 1.2 |  |  | $ | 0.8 |  |  | $ | 0.4 |  |  | 50.0 | % |
| Interest expense | (0.6 | ) |  | (1.8 | ) |  | 1.2 |  |  | (66.7 | )% |  | (1.1 | ) |  | (4.2 | ) |  | 3.1 |  |  | (73.8 | )% |
| Interest and other income (expense), net | $ | (1.0 | ) |  | $ | (1.2 | ) |  | $ | 0.2 |  |  | (16.7 | )% |  | $ | 0.1 |  |  | $ | (3.4 | ) |  | $ | 3.5 |  |  | (102.9 | )% |

[0001375365-20-000011:mdna:78]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:79]
The period-over-period change in interest and other income (expense), net was due to a decrease of $1.2 million in interest expense primarily as a result of lower average outstanding debt during the three months ended December 31, 2019 as compared to three months ended December 31, 2018, which was due to repayments of our borrowings. This was offset by a change of $1.0 million in other income (expense), net attributable to an increase of $0.6 million in interest income on our interest bearing deposits offset by change of $(1.6) million related to foreign exchange losses due to unfavorable foreign currency fluctuations.

[0001375365-20-000011:mdna:80]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:81]
The period-over-period change in interest and other income (expense), net was due to a decrease of $3.1 million in interest expense primarily as a result of lower average outstanding debt during the six months ended December 31, 2019 as compared to six months ended December 31, 2018, which was due to repayments of our borrowings. This was offset by a change of $0.4 million in other income (expense), net attributable to an increase of $1.3 million in interest income on our interest bearing deposits offset by change of $(0.9) million related to foreign exchange losses due to unfavorable foreign currency fluctuations.

[0001375365-20-000011:mdna:82]
[same as prior period, unchanged from 0001375365-19-000084:mdna:57]

[0001375365-20-000011:mdna:83]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2019 and 2018 are as follows (dollars in millions):

[0001375365-20-000011:mdna:84]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |  | 2019 |  | 2018 |  | $ |  | % |
| Income tax provision | $ | 2.1 |  |  | $ | 4.5 |  |  | $ | (2.4 | ) |  | (53.3 | )% |  | $ | 10.7 |  |  | $ | 10.0 |  |  | $ | 0.7 |  |  | 7.0 | % |
| Percentage of total net sales | 0.2 | % |  | 0.5 | % |  |  |  |  |  | 0.6 | % |  | 0.5 | % |  |  |  |  |
| Effective tax rate | 7.9 | % |  | 18.4 | % |  |  |  |  |  | 17.6 | % |  | 19.8 | % |  |  |  |  |

[0001375365-20-000011:mdna:85]
Comparison of Three Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:86]
The period-over-period decrease in income tax provision and effective tax rate was primarily due to a release of unrecognized tax benefits following the settlement of a Taiwan tax audit for the three months ended December 31, 2019.

[0001375365-20-000011:mdna:87]
Comparison of Six Months Ended December 31, 2019 and 2018

[0001375365-20-000011:mdna:88]
The period-over-period decrease in effective tax rate was primarily due to a release of unrecognized tax benefits following the settlement of a Taiwan tax audit for the six months ended December 31, 2019.

[0001375365-20-000011:mdna:89]
[same as prior period, unchanged from 0001375365-19-000084:mdna:61]

[0001375365-20-000011:mdna:90]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $309.0 million and $248.2 million as of December 31, 2019 and June 30, 2019, respectively. Our cash in foreign locations was $93.5 million and $124.6 million as of December 31, 2019 and June 30, 2019, respectively.

[0001375365-20-000011:mdna:91]
[same as prior period, unchanged from 0001375365-19-000084:mdna:63]

[0001375365-20-000011:mdna:92]
We believe that our current cash, cash equivalents, credit lines and internally generated cash flows will be generally sufficient to support our operating businesses, remediation efforts, maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements. Expected uses of our cash over the short term include our continued development of resource saving products, manufacturing expansion in the United States and Taiwan and ongoing remediation of our material weaknesses in internal controls over financial reporting. Additionally, we expect to incur additional charges of $35.0 million to $40.0 million, which will be one-time in nature, in the third or fourth fiscal quarter of 2020. These one-time charges, which will likely be settled in cash, will address residual clean-up matters from our extended black-out period.

[0001375365-20-000011:mdna:93]
[same as prior period, unchanged from 0001375365-19-000084:mdna:65]

[0001375365-20-000011:mdna:94]
|  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  |
| Net cash provided by operating activities | $ | 87.2 |  |  | $ | 81.1 |  |  | $ | 6.1 |  |
| Net cash used in investing activities | $ | (23.3 | ) |  | $ | (9.3 | ) |  | $ | (14.0 | ) |
| Net cash used in financing activities | $ | (2.1 | ) |  | $ | (69.3 | ) |  | $ | 67.2 |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | 61.9 |  |  | $ | 2.4 |  |  | $ | 59.5 |  |

[0001375365-20-000011:mdna:95]
[same as prior period, unchanged from 0001375365-19-000084:mdna:67]

[0001375365-20-000011:mdna:96]
Net cash provided by operating activities increased by $6.1 million for the six months ended December 31, 2019 as compared to the six months ended December 31, 2018. The increase was due primarily to an increase in net income in the current period of $12.5 million and a reduction of non-cash charges from the change in deferred taxes, net of $7.1 million, from lower period-over-period changes in reserves and accruals, offset by increased net working capital of $10.8 million

[0001375365-20-000011:mdna:97]
resulting from a decrease in the cash collected from our customers, an increase in prepayments to tax authorities, a decrease in payments for professional fees, and a decrease in the share of loss from our equity investee of $3.2 million.

[0001375365-20-000011:mdna:98]
[same as prior period, unchanged from 0001375365-19-000084:mdna:69]

[0001375365-20-000011:mdna:99]
Net cash used in investing activities was $23.3 million and $9.3 million for the six months ended December 31, 2019 and 2018, respectively, as we continued to invest in expanding our capacity and office space, including the expansion of our Green Computing Park in San Jose.  During the six months ended December 31, 2019, we received $0.8 million from the sale of our investment in a privately held company.

[0001375365-20-000011:mdna:100]
[same as prior period, unchanged from 0001375365-19-000084:mdna:71]

[0001375365-20-000011:mdna:101]
Net cash used in financing activities decreased by $67.2 million for the six months ended December 31, 2019 as compared to the six months ended December 31, 2018 primarily due to decreased debt repayments of $66.5 million.

[0001375365-20-000011:mdna:102]
[same as prior period, unchanged from 0001375365-19-000084:mdna:73]

[0001375365-20-000011:mdna:103]
[same as prior period, unchanged from 0001375365-19-000084:mdna:74]

[0001375365-20-000011:mdna:104]
[same as prior period, unchanged from 0001375365-19-000084:mdna:75]

[0001375365-20-000011:mdna:105]
2018 Bank of America Credit Facility

[0001375365-20-000011:mdna:106]
In April 2018, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and was extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at our option and if certain conditions are satisfied, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against our line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at our option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to either repurchase our shares or pay any dividends.

[0001375365-20-000011:mdna:107]
In the fourth fiscal quarter of 2018, we paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the then-existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in our consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in our consolidated balance sheets.

[0001375365-20-000011:mdna:108]
On January 31, 2019, we paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, we entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-20-000011:mdna:109]
As of December 31, 2019, we had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2019 and June 30, 2019 were 3.75% per annum and 4.50% per annum, respectively. As of December 31, 2019, a $6.4 million letter of credit was outstanding under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were immaterial as of December 31, 2019 and June 30, 2019. As of December 31, 2019, our available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-20-000011:mdna:110]
[same as prior period, unchanged from 0001375365-19-000084:mdna:81]

[0001375365-20-000011:mdna:111]
In January 2018, we entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-20-000011:mdna:112]
In June 2019, we entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-20-000011:mdna:113]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.3 million and $22.5 million at December 31, 2019 and June 30, 2019, respectively. The interest rate for these loans were 0.91% per annum as of December 31, 2019 and 0.93% per annum as of June 30, 2019. At December 31, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $26.7 million. As of December 31, 2019, the net book value of land and building located in Bade, Taiwan collateralizing the 2019 CTBC Credit Facility term loan was $25.6 million.

[0001375365-20-000011:mdna:114]
Covenant Compliance

[0001375365-20-000011:mdna:115]
2018 Bank of America Credit Facility

[0001375365-20-000011:mdna:116]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains a financial covenant, which requires that we maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. We have been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-20-000011:mdna:117]
On September 7, 2018, Bank of America issued an extension letter to us in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, we entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, we paid a fee to extend the delivery to June 30, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, we were required to deliver our audited consolidated financial statements for the

[0001375365-20-000011:mdna:118]
fiscal year ended June 30, 2018 by December 31, 2019, and deliver our audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If we elect to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, we are required to deliver our audited financial statements by March 31, 2020.

[0001375365-20-000011:mdna:119]
On December 19, 2019, we filed with the SEC our comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, we also filed with the SEC our Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such, we complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

[0001375365-20-000011:mdna:120]
[same as prior period, unchanged from 0001375365-19-000084:mdna:91]

[0001375365-20-000011:mdna:121]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.

[0001375365-20-000011:mdna:122]
[same as prior period, unchanged from 0001375365-19-000084:mdna:93]

[0001375365-20-000011:mdna:123]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Organization and Summary of Significant Accounting Policies,” in our notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q.

[0001375365-20-000011:mdna:124]
[same as prior period, unchanged from 0001375365-19-000084:mdna:95]

[0001375365-20-000011:mdna:125]
[same as prior period, unchanged from 0001375365-19-000084:mdna:96]
