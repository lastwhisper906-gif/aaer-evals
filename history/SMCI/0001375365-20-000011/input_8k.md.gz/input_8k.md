# SMCI 8-K — 0001375365-20-000008 filed 2020-02-06

## item codes, every 8-K on or before 2020-02-07

- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2020-02-07

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-20-000008:8k_2_02:1]
EX-99.1
2
exhibit99120200206.htm
EXHIBIT 99.1

[0001375365-20-000008:8k_2_02:2]
Exhibit

[0001375365-20-000008:8k_2_02:3]
Exhibit 99.1

[0001375365-20-000008:8k_2_02:4]
Supermicro Announces Second Quarter Fiscal 2020

[0001375365-20-000008:8k_2_02:5]
Financial Results

[0001375365-20-000008:8k_2_02:6]
SAN JOSE, Calif. -- February 6, 2020 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced financial results for its fiscal second quarter ended December 31, 2019.

[0001375365-20-000008:8k_2_02:7]
Fiscal Second Quarter Highlights

[0001375365-20-000008:8k_2_02:8]
| • | Net sales of $870.9 million versus $799.8 million in the first quarter of fiscal year 2020 and $931.5 million in the same quarter of last year. |

[0001375365-20-000008:8k_2_02:9]
| • | GAAP gross margin of 15.9% versus 16.4% in the first quarter of fiscal year 2020 and 13.7% in the same quarter of last year. |

[0001375365-20-000008:8k_2_02:10]
| • | GAAP net income of $23.7 million versus $26.3 million in the first quarter of fiscal year 2020 and $18.2 million in the same quarter of last year. |

[0001375365-20-000008:8k_2_02:11]
| • | GAAP fully diluted earnings per share of $0.46 versus $0.51 in the first quarter of fiscal year 2020 and $0.36 in the same quarter of last year. |

[0001375365-20-000008:8k_2_02:12]
| • | Non-GAAP fully diluted earnings per share of $0.57 versus $0.68 in the first quarter of fiscal year 2020 and $0.66 in the same quarter of last year. |

[0001375365-20-000008:8k_2_02:13]
| • | Cash flow from operations of $81.6 million and capital expenditures of $10.8 million. |

[0001375365-20-000008:8k_2_02:14]
Non-GAAP gross margin for the fiscal second quarter of 2020 was 15.9%, which excludes stock-based compensation expenses of $0.4 million. Non-GAAP fully diluted earnings per share was $0.57, which excludes stock-based compensation expenses of $5.0 million and consulting expenses related to regaining SEC compliance and other non-recurring expenses of $3.8 million less the related tax effects of both.

[0001375365-20-000008:8k_2_02:15]
As of December 31, 2019, total cash, cash equivalents and short-term investments was $309.0 million and bank debt was $23.3 million.

[0001375365-20-000008:8k_2_02:16]
“Over the last couple of years, Supermicro has been continuing our mission of becoming a strong global leader of server and storage solutions, especially the greenest and best TCO IT solutions. We have added many new product lines and dramatically increased our operational capacity worldwide. This quarter, our revenue exceeded the upper end of our original guidance which

[0001375365-20-000008:8k_2_02:17]
marks the beginning of our business reacceleration.” said Charles Liang, Chairman and Chief Executive Officer. “We are the only server and storage solution provider with more than half of our engineering, product development and final assembly based in the USA. Our engineering and R&D strengths allow us to quickly deliver the most advanced technology with the broadest range of server and storage products in our industry. We are very excited by our product solutions targeting Artificial Intelligence, 5G / Edge, and the evolving needs of the Enterprise, which offer our company a substantial growth opportunity in a $100B market.”

[0001375365-20-000008:8k_2_02:18]
Third Quarter Fiscal 2020 Guidance

[0001375365-20-000008:8k_2_02:19]
The Company expects net sales in a range of $770 million to $830 million for the third quarter of fiscal year 2020 ending March 31, 2020. The Company expects non-GAAP earnings per diluted share of approximately $0.35 to $0.55 for the third quarter.

[0001375365-20-000008:8k_2_02:20]
The Company expects to incur additional charges of $35 million to $40 million, which will be one-time in nature, in the third or fourth fiscal quarter of 2020.  These one-time charges will address residual clean-up matters from our extended black-out period and have not been included in the above guidance.

[0001375365-20-000008:8k_2_02:21]
Cautionary Statement Regarding Forward-Looking Statements

[0001375365-20-000008:8k_2_02:22]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001375365-20-000008:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001375365-20-000008:8k_2_02:24]
Non-GAAP gross margin and fully diluted earnings per share discussed in this press release exclude as applicable stock-based compensation expenses, consulting expenses related to regaining SEC compliance and other non-recurring expenses described above, and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, the reconciliation between the Company's GAAP gross margin and non-GAAP gross margin is stock-based compensation of $0.4 million and the reconciliation between the Company’s GAAP fully diluted earnings per share and non-GAAP fully diluted earnings per share is stock-based compensation of $5.0 million, and consulting expenses related to regaining SEC compliance and other non-recurring expenses of $3.8 million less related tax effect of $2.0 million. Refer to the associated tables below for further information.

[0001375365-20-000008:8k_2_02:25]
About Super Micro Computer, Inc.

[0001375365-20-000008:8k_2_02:26]
Supermicro (Nasdaq: SMCI), the leading innovator in high-performance, high-efficiency server technology is a premier provider of advanced Server Building Block Solutions® for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-20-000008:8k_2_02:27]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-20-000008:8k_2_02:28]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-20-000008:8k_2_02:29]
Investor Relations Contacts

[0001375365-20-000008:8k_2_02:30]
Perry G. Hayes, SVP, Investor Relations

[0001375365-20-000008:8k_2_02:31]
(408) 895-6570

[0001375365-20-000008:8k_2_02:32]
James Kisner, Investor Relations

[0001375365-20-000008:8k_2_02:33]
(669) 284-1259

[0001375365-20-000008:8k_2_02:34]
email: ir@supermicro.com

[0001375365-20-000008:8k_2_02:35]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000008:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-20-000008:8k_2_02:37]
(in thousands)

[0001375365-20-000008:8k_2_02:38]
(unaudited)

[0001375365-20-000008:8k_2_02:39]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 309,038 |  |  | $ | 248,164 |  |
| Accounts receivable, net of allowances | 360,172 |  |  | 393,624 |  |
| Inventories | 704,430 |  |  | 670,188 |  |
| Prepaid expenses and other current assets | 147,055 |  |  | 109,795 |  |
| Total current assets | 1,520,695 |  |  | 1,421,771 |  |
| Investment in equity investee | 1,060 |  |  | 1,701 |  |
| Property, plant and equipment, net | 220,551 |  |  | 207,337 |  |
| Deferred income taxes, net | 42,015 |  |  | 41,126 |  |
| Other assets | 22,718 |  |  | 10,659 |  |
| Total assets | $ | 1,807,039 |  |  | $ | 1,682,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 392,537 |  |  | $ | 360,470 |  |
| Accrued liabilities | 137,365 |  |  | 114,678 |  |
| Income taxes payable | 3,529 |  |  | 13,021 |  |
| Short-term debt | 23,250 |  |  | 23,647 |  |
| Deferred revenue | 115,059 |  |  | 94,153 |  |
| Total current liabilities | 671,740 |  |  | 605,969 |  |
| Deferred revenue, non-current | 100,553 |  |  | 109,266 |  |
| Other long-term liabilities | 33,193 |  |  | 26,183 |  |
| Total liabilities | 805,486 |  |  | 741,418 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.001 par value |  |  |  |
| Authorized shares: 100,000,000 |  |  |  |
| Issued shares: 51,923,260 and 51,289,413 at December 31, 2019 and June 30, 2019, respectively | 360,060 |  |  | 349,683 |  |
| Treasury stock (at cost), 1,333,125 shares at December 31, 2019 and June 30, 2019, respectively | (20,491 | ) |  | (20,491 | ) |
| Accumulated other comprehensive loss | (135 | ) |  | (80 | ) |
| Retained earnings | 661,954 |  |  | 611,903 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,001,388 |  |  | 941,015 |  |
| Noncontrolling interest | 165 |  |  | 161 |  |
| Total stockholders’ equity | 1,001,553 |  |  | 941,176 |  |
| Total liabilities and stockholders’ equity | $ | 1,807,039 |  |  | $ | 1,682,594 |  |

[0001375365-20-000008:8k_2_02:40]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000008:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-20-000008:8k_2_02:42]
(in thousands, except share and per share amounts)

[0001375365-20-000008:8k_2_02:43]
(unaudited)

[0001375365-20-000008:8k_2_02:44]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |
| Cost of sales | 732,539 |  |  | 803,587 |  |  | 1,401,414 |  |  | 1,651,466 |  |
| Gross profit | 138,404 |  |  | 127,922 |  |  | 269,333 |  |  | 251,161 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 55,572 |  |  | 45,924 |  |  | 105,144 |  |  | 88,918 |  |
| Sales and marketing | 21,977 |  |  | 19,677 |  |  | 42,171 |  |  | 37,969 |  |
| General and administrative | 33,040 |  |  | 36,580 |  |  | 61,338 |  |  | 70,040 |  |
| Total operating expenses | 110,589 |  |  | 102,181 |  |  | 208,653 |  |  | 196,927 |  |
| Income from operations | 27,815 |  |  | 25,741 |  |  | 60,680 |  |  | 54,234 |  |
| Other (expense) income, net | (416 | ) |  | 624 |  |  | 1,173 |  |  | 793 |  |
| Interest expense | (560 | ) |  | (1,831 | ) |  | (1,112 | ) |  | (4,209 | ) |
| Income before income tax provision | 26,839 |  |  | 24,534 |  |  | 60,741 |  |  | 50,818 |  |
| Income tax provision | (2,113 | ) |  | (4,520 | ) |  | (10,681 | ) |  | (10,043 | ) |
| Share of loss from equity investee, net of taxes | (1,020 | ) |  | (1,794 | ) |  | (9 | ) |  | (3,213 | ) |
| Net income | $ | 23,706 |  |  | $ | 18,220 |  |  | $ | 50,051 |  |  | $ | 37,562 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.37 |  |  | $ | 1.00 |  |  | $ | 0.75 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.97 |  |  | $ | 0.73 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 50,181 |  |  | 49,844 |  |  | 50,129 |  |  | 49,774 |  |
| Diluted | 52,009 |  |  | 50,810 |  |  | 51,758 |  |  | 51,508 |  |

[0001375365-20-000008:8k_2_02:45]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-20-000008:8k_2_02:46]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of sales | $ | 384 |  |  | $ | 428 |  |  | $ | 779 |  |  | $ | 866 |  |
| Research and development | 3,126 |  |  | 3,212 |  |  | 6,256 |  |  | 6,708 |  |
| Sales and marketing | 423 |  |  | 436 |  |  | 859 |  |  | 941 |  |
| General and administrative | 1,031 |  |  | 1,171 |  |  | 2,124 |  |  | 2,606 |  |
| Stock-based compensation expense before taxes | $ | 4,964 |  |  | $ | 5,247 |  |  | $ | 10,018 |  |  | $ | 11,121 |  |

[0001375365-20-000008:8k_2_02:47]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000008:8k_2_02:48]
SELECTED CASH FLOW INFORMATION

[0001375365-20-000008:8k_2_02:49]
(in thousands)

[0001375365-20-000008:8k_2_02:50]
(unaudited)

[0001375365-20-000008:8k_2_02:51]
|  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |
| Net cash provided by operating activities | $ | 87,153 |  |  | $ | 81,102 |  |
| Net cash used in investing activities | (23,339 | ) |  | (9,306 | ) |
| Net cash used in financing activities | (2,076 | ) |  | (69,324 | ) |
| Effect of exchange rate fluctuations on cash | 175 |  |  | (101 | ) |
| Net increase in cash, cash equivalents and restricted cash | 61,913 |  |  | 2,371 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 262,140 |  |  | 120,382 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 324,053 |  |  | $ | 122,753 |  |

[0001375365-20-000008:8k_2_02:52]
SUPER MICRO COMPUTER, INC.

[0001375365-20-000008:8k_2_02:53]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-20-000008:8k_2_02:54]
(in thousands, except share and per share amounts)

[0001375365-20-000008:8k_2_02:55]
(unaudited)

[0001375365-20-000008:8k_2_02:56]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP GROSS PROFIT | $ | 138,404 |  |  | $ | 127,922 |  |  | $ | 269,333 |  |  | $ | 251,161 |  |
| Add back stock-based compensation | 384 |  |  | 428 |  |  | 779 |  |  | 866 |  |
| Non-GAAP GROSS PROFIT | $ | 138,788 |  |  | $ | 128,350 |  |  | $ | 270,112 |  |  | $ | 252,027 |  |
| GAAP GROSS MARGIN | 15.9 | % |  | 13.7 | % |  | 16.1 | % |  | 13.2 | % |
| Add back stock-based compensation | 0.0 | % |  | 0.1 | % |  | 0.1 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 15.9 | % |  | 13.8 | % |  | 16.2 | % |  | 13.2 | % |
| GAAP INCOME FROM OPERATIONS | $ | 27,815 |  |  | $ | 25,741 |  |  | $ | 60,680 |  |  | $ | 54,234 |  |
| Add back stock-based compensation | 4,964 |  |  | 5,247 |  |  | 10,018 |  |  | 11,121 |  |
| Add back consulting and other non-recurring expenses | 3,759 |  |  | 16,395 |  |  | 11,417 |  |  | 32,410 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 36,538 |  |  | $ | 47,383 |  |  | $ | 82,115 |  |  | $ | 97,765 |  |
| GAAP NET INCOME | $ | 23,706 |  |  | $ | 18,220 |  |  | $ | 50,051 |  |  | $ | 37,562 |  |
| Add back stock-based compensation | 4,964 |  |  | 5,247 |  |  | 10,018 |  |  | 11,121 |  |
| Add back consulting and other non-recurring expenses | 3,759 |  |  | 16,395 |  |  | 11,417 |  |  | 32,410 |  |
| Less adjustments to tax provision | (2,007 | ) |  | (5,120 | ) |  | (5,058 | ) |  | (10,299 | ) |
| Non-GAAP NET INCOME | $ | 30,422 |  |  | $ | 34,742 |  |  | $ | 66,428 |  |  | $ | 70,794 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.47 |  |  | $ | 0.37 |  |  | $ | 1.00 |  |  | $ | 0.75 |  |
| Add back stock-based compensation, consulting, and adjustments to tax provision | 0.14 |  |  | 0.33 |  |  | 0.33 |  |  | 0.67 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.61 |  |  | $ | 0.70 |  |  | $ | 1.33 |  |  | $ | 1.42 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.97 |  |  | $ | 0.73 |  |
| Add back stock-based compensation, consulting, and adjustments to tax provision | 0.11 |  |  | 0.30 |  |  | 0.28 |  |  | 0.61 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.57 |  |  | $ | 0.66 |  |  | $ | 1.25 |  |  | $ | 1.34 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 50,181 |  |  | 49,844 |  |  | 50,129 |  |  | 49,774 |  |
| BASIC - Non-GAAP | 50,181 |  |  | 49,844 |  |  | 50,129 |  |  | 49,774 |  |
| DILUTED – GAAP | 52,009 |  |  | 50,810 |  |  | 51,758 |  |  | 51,508 |  |
| DILUTED - Non-GAAP | 53,572 |  |  | 52,398 |  |  | 53,350 |  |  | 53,002 |  |
