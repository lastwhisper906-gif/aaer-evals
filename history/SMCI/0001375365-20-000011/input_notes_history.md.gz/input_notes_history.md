# SMCI note change history — 0001375365-19-000084 → 0001375365-20-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:1]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2019, these remaining noncancelable commitments were $579.2 million, including $134.0 million for related parties.
  (was, 2019-12-20, similarity 0.6362):
[0001375365-19-000084:note_history:1]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2019, these remaining noncancelable commitments were $383.4 million, including $117.8 million for related parties.

- changed (2020-02-07):
[0001375365-20-000011:note_history:2]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.
  (was, 2019-12-20, similarity 0.8326):
[0001375365-19-000084:note_history:2]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the

- removed (2020-02-07):
[0001375365-19-000084:note_history:3]
Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. Equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.
  (was, 2019-12-20, similarity 0.9986):
[0001375365-19-000084:note_history:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

- changed (2020-02-07):
[0001375365-20-000011:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.
  (was, 2019-12-20, similarity 0.7142):
[0001375365-19-000084:note_history:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

- changed (2020-02-07):
[0001375365-20-000011:note_history:6]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the
  (was, 2019-12-20, similarity 0.9878):
[0001375365-19-000084:note_history:6]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor

- changed (2020-02-07):
[0001375365-20-000011:note_history:7]
distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.
  (was, 2019-12-20, similarity 0.9733):
[0001375365-19-000084:note_history:7]
obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- added (2020-02-07):
[0001375365-20-000011:note_history:8]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- added (2020-02-07):
[0001375365-20-000011:note_history:9]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,

- added (2020-02-07):
[0001375365-20-000011:note_history:10]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

- changed (2020-02-07):
[0001375365-20-000011:note_history:11]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.
  (was, 2019-12-20, similarity 0.9987):
[0001375365-19-000084:note_history:11]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company it is classified as a finance lease. All other leases are classified as operating leases.

- changed (2020-02-07):
[0001375365-20-000011:note_history:12]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.
  (was, 2019-12-20, similarity 0.995):
[0001375365-19-000084:note_history:12]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") asset is included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

- changed (2020-02-07):
[0001375365-20-000011:note_history:13]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.
  (was, 2019-12-20, similarity 0.9801):
[0001375365-19-000084:note_history:13]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized, at lease commencement, based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments, and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amounts of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.

- changed (2020-02-07):
[0001375365-20-000011:note_history:14]
Assets under finance leases are included in property, plant and equipment, net and current, and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.
  (was, 2019-12-20, similarity 0.999):
[0001375365-19-000084:note_history:14]
Assets under finance leases are included in property, plant and equipment, net and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

- changed (2020-02-07):
[0001375365-20-000011:note_history:15]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following was true at inception: (a) the present value of minimum lease payments met or exceeded 90% of the fair value of the asset, (b) the lease term was greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contained a bargain purchase option, or (d) title to the property transferred to the Company at the end of the lease. The Company recorded an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets were depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability was accounted for using the effective interest method.
  (was, 2019-12-20, similarity 0.7647):
[0001375365-19-000084:note_history:15]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following is true at inception: (a) the present value of minimum lease payments meets or exceeds 90% of the fair value of the asset, (b) the lease term is greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contains a bargain purchase option, or (d) title to the property transfers to the Company at the end of the lease. The Company records an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets are depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability are accounted for using the effective interest method.

- added (2020-02-07):
[0001375365-20-000011:note_history:16]
Leases that were not classified as capital leases were accounted for as operating leases. Operating lease agreements that had tenant improvement allowances were evaluated for lease incentives. For leases that contained escalating rent payments, the Company recognized rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

- changed (2020-02-07):
[0001375365-20-000011:note_history:17]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary with respect to either Ablecom or Compuware as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.
  (was, 2019-12-20, similarity 0.8579):
[0001375365-19-000084:note_history:17]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

- added (2020-02-07):
[0001375365-20-000011:note_history:18]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and six months ended December 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- changed (2020-02-07):
[0001375365-20-000011:note_history:19]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of December 31, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $1.1 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $1.0 million and $1.8 million for the three months ended December 31, 2019 and 2018, respectively, and $0.0 million and $3.2 million for the six months ended December 31, 2019 and 2018, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations.
  (was, 2019-12-20, similarity 0.8692):
[0001375365-19-000084:note_history:19]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of September 30, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $2.3 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of gains (losses) of the Corporate Venture were $1.0 million and $(1.4) million for the three months ended September 30, 2019 and 2018, respectively.

- changed (2020-02-07):
[0001375365-20-000011:note_history:20]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of December 31, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.0 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2019-12-20, similarity 0.995):
[0001375365-19-000084:note_history:20]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of September 30, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2020-02-07):
[0001375365-20-000011:note_history:21]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and six months ended December 31, 2019 and 2018, respectively.
  (was, 2019-12-20, similarity 0.937):
[0001375365-19-000084:note_history:21]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three months ended September 30, 2019 and 2018, respectively.

- added (2020-02-07):
[0001375365-20-000011:note_history:22]
Additionally, the Company sold products worth $15.4 million and $12.1 million to the Corporate Venture in the three months ended December 31, 2019 and 2018, respectively, and $37.5 million and $21.5 million in the six months ended December 31, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.2 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- changed (2020-02-07):
[0001375365-20-000011:note_history:23]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.5% and 23.4% of total purchases for the three months ended December 31, 2019 and 2018, respectively, and 28.6% and 21.5% for the six months ended December 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 10.3% and 9.3% of total cost of sales for the three months ended December 31, 2019 and 2018, respectively, and 10.0% and 9.2% for the six months ended December 31, 2019 and 2018, respectively.
  (was, 2019-12-20, similarity 0.7921):
[0001375365-19-000084:note_history:23]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.7% and 19.7% of total purchases for the three months ended September 30, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 9, "Related Party Transactions," accounted for 9.7% and 9.2% of total cost of sales for the three months ended September 30, 2019 and 2018, respectively.

- changed (2020-02-07):
[0001375365-20-000011:note_history:24]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.
  (was, 2019-12-20, similarity 0.9332):
[0001375365-19-000084:note_history:24]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three months ended September 30, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

- added (2020-02-07):
[0001375365-20-000011:note_history:25]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- added (2020-02-07):
[0001375365-20-000011:note_history:26]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

- added (2020-02-07):
[0001375365-20-000011:note_history:27]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- removed (2020-02-07):
[0001375365-19-000084:note_history:28]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-02-07):
[0001375365-19-000084:note_history:29]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,

- removed (2020-02-07):
[0001375365-19-000084:note_history:30]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

- removed (2020-02-07):
[0001375365-19-000084:note_history:31]
Leases that are not classified as capital leases are accounted for as operating leases. Operating lease agreements that have tenant improvement allowances are evaluated for lease incentives. For leases that contain escalating rent payments, the Company recognizes rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

- removed (2020-02-07):
[0001375365-19-000084:note_history:32]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three months ended September 30, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- removed (2020-02-07):
[0001375365-19-000084:note_history:33]
Additionally, the Company sold products worth $22.1 million and $9.3 million to the Corporate Venture in the three months ended September 30, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.3 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- removed (2020-02-07):
[0001375365-19-000084:note_history:34]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an

- removed (2020-02-07):
[0001375365-19-000084:note_history:35]
expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- removed (2020-02-07):
[0001375365-19-000084:note_history:36]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the Concepts Statement, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:37]
Short-term debt obligations as of December 31, 2019 and June 30, 2019 consisted of the following (in thousands):
  (was, 2019-12-20, similarity 0.9756):
[0001375365-19-000084:note_history:37]
Short-term debt obligations as of September 30, 2019 and June 30, 2019 consisted of the following (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:38]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 23,250 |  |  | 22,531 |  |
| Total short-term debt | $ | 23,250 |  |  | $ | 23,647 |  |
  (was, 2019-12-20, similarity 0.9864):
[0001375365-19-000084:note_history:38]
|  | September 30, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 22,544 |  |  | 22,531 |  |
| Total short-term debt | $ | 22,544 |  |  | $ | 23,647 |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:39]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and was extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.
  (was, 2019-12-20, similarity 0.9264):
[0001375365-19-000084:note_history:39]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

- changed (2020-02-07):
[0001375365-20-000011:note_history:40]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the then-existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.
  (was, 2019-12-20, similarity 0.9969):
[0001375365-19-000084:note_history:40]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

- changed (2020-02-07):
[0001375365-20-000011:note_history:41]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.
  (was, 2019-12-20, similarity 0.745):
[0001375365-19-000084:note_history:41]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the

- added (2020-02-07):
[0001375365-20-000011:note_history:42]
As of December 31, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2019 and June 30, 2019 were 3.75% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of December 31, 2019 and June 30, 2019. As of December 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- added (2020-02-07):
[0001375365-20-000011:note_history:43]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.3 million and $22.5 million at December 31, 2019 and June 30, 2019, respectively. The interest rate for these loans were 0.91% per annum as of December 31, 2019 and 0.93% per annum as of June 30, 2019. At December 31, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $26.7 million. As of December 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.6 million.

- changed (2020-02-07):
[0001375365-20-000011:note_history:44]
On December 19, 2019, the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such, the Company complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.
  (was, 2019-12-20, similarity 0.9769):
[0001375365-19-000084:note_history:44]
On December 19, 2019 the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such the Company has complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

- removed (2020-02-07):
[0001375365-19-000084:note_history:45]
Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

- removed (2020-02-07):
[0001375365-19-000084:note_history:46]
As of September 30, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2019 and June 30, 2019 were 4.13% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were immaterial as of September 30, 2019 and June 30, 2019. As of September 30, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

- removed (2020-02-07):
[0001375365-19-000084:note_history:47]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.5 million at September 30, 2019 and June 30, 2019. The interest rate for these loans were 0.88% per annum as of September 30, 2019 and 0.93% per annum as of June 30, 2019. At September 30, 2019, the amount available for future borrowing under the CTBC Credit Facility was $27.5 million. As of September 30, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.7 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:48]
Short-term debt obligations as of December 31, 2019 and June 30, 2019 consisted of the following (in thousands):
  (was, 2019-12-20, similarity 0.9756):
[0001375365-19-000084:note_history:48]
Short-term debt obligations as of September 30, 2019 and June 30, 2019 consisted of the following (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:49]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 23,250 |  |  | 22,531 |  |
| Total short-term debt | $ | 23,250 |  |  | $ | 23,647 |  |
  (was, 2019-12-20, similarity 0.9864):
[0001375365-19-000084:note_history:49]
|  | September 30, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 22,544 |  |  | 22,531 |  |
| Total short-term debt | $ | 22,544 |  |  | $ | 23,647 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:50]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of December 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of December 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.
  (was, 2019-12-20, similarity 0.9945):
[0001375365-19-000084:note_history:50]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of September 30, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of September 30, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

- added (2020-02-07):
[0001375365-20-000011:note_history:51]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 97.5% and 94.8% of the chassis included in the products sold by the Company during the three months ended December 31, 2019 and 2018, respectively; and approximately 95.4% and 95.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2020-02-07):
[0001375365-20-000011:note_history:52]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the
  (was, 2019-12-20, similarity 0.797):
[0001375365-19-000084:note_history:52]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- added (2020-02-07):
[0001375365-20-000011:note_history:53]
components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

- changed (2020-02-07):
[0001375365-20-000011:note_history:54]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $49.4 million and $31.0 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2019-12-20, similarity 0.8602):
[0001375365-19-000084:note_history:54]
that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $41.1 million and $31.0 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2020-02-07):
[0001375365-20-000011:note_history:55]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $84.6 million and $70.6 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2019-12-20, similarity 0.9946):
[0001375365-19-000084:note_history:55]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $76.7 million and $70.6 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2020-02-07):
[0001375365-20-000011:note_history:56]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2019 and 2018, are as follows (in thousands):
  (was, 2019-12-20, similarity 0.9582):
[0001375365-19-000084:note_history:56]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2019 and 2018, are as follows (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:57]
|  | Three months ended December 31, |  | Six months ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 44,568 |  |  | $ | 36,282 |  |  | $ | 77,688 |  |  | $ | 80,918 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 6,406 |  |  | $ | 4,640 |  |  | $ | 11,953 |  |  | $ | 9,782 |  |
| Purchases (1) | 33,438 |  |  | 40,277 |  |  | 66,754 |  |  | 77,489 |  |
  (was, 2019-12-20, similarity 0.7481):
[0001375365-19-000084:note_history:57]
|  | Three months ended September, 30 |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Purchases (1) | $ | 33,120 |  |  | $ | 44,636 |  |
| Compuware |  |  |  |
| Net sales | $ | 5,547 |  |  | $ | 5,142 |  |
| Purchases (1) | 33,316 |  |  | 37,212 |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:58]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2019 and 2018.
  (was, 2019-12-20, similarity 0.9366):
[0001375365-19-000084:note_history:58]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2019 and 2018.

- changed (2020-02-07):
[0001375365-20-000011:note_history:59]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2019 and June 30, 2019 (in thousands):
  (was, 2019-12-20, similarity 0.9818):
[0001375365-19-000084:note_history:59]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2019 and June 30, 2019 (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:60]
|  | December 31, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 10,747 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 44,913 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,105 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 16,747 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 44,788 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 325 |  |  | — |  |
  (was, 2019-12-20, similarity 0.9919):
[0001375365-19-000084:note_history:60]
|  | September 30, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 8,383 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 36,417 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,374 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 19,117 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 41,048 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 398 |  |  | — |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:61]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and six months ended December 31, 2019 and 2018.
  (was, 2019-12-20, similarity 0.9514):
[0001375365-19-000084:note_history:61]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three months ended September 30, 2019 and 2018.

- removed (2020-02-07):
[0001375365-19-000084:note_history:62]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.7% and 95.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2020-02-07):
[0001375365-19-000084:note_history:63]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:64]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2019 and 2018, are as follows (in thousands):
  (was, 2019-12-20, similarity 0.9582):
[0001375365-19-000084:note_history:64]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2019 and 2018, are as follows (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:65]
|  | Three months ended December 31, |  | Six months ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 44,568 |  |  | $ | 36,282 |  |  | $ | 77,688 |  |  | $ | 80,918 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 6,406 |  |  | $ | 4,640 |  |  | $ | 11,953 |  |  | $ | 9,782 |  |
| Purchases (1) | 33,438 |  |  | 40,277 |  |  | 66,754 |  |  | 77,489 |  |
  (was, 2019-12-20, similarity 0.7481):
[0001375365-19-000084:note_history:65]
|  | Three months ended September, 30 |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Purchases (1) | $ | 33,120 |  |  | $ | 44,636 |  |
| Compuware |  |  |  |
| Net sales | $ | 5,547 |  |  | $ | 5,142 |  |
| Purchases (1) | 33,316 |  |  | 37,212 |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:66]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2019 and 2018.
  (was, 2019-12-20, similarity 0.9366):
[0001375365-19-000084:note_history:66]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2019 and 2018.

- changed (2020-02-07):
[0001375365-20-000011:note_history:67]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2019 and June 30, 2019 (in thousands):
  (was, 2019-12-20, similarity 0.9818):
[0001375365-19-000084:note_history:67]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2019 and June 30, 2019 (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:68]
|  | December 31, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 10,747 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 44,913 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,105 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 16,747 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 44,788 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 325 |  |  | — |  |
  (was, 2019-12-20, similarity 0.9919):
[0001375365-19-000084:note_history:68]
|  | September 30, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 8,383 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 36,417 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,374 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 19,117 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 41,048 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 398 |  |  | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-07):
[0001375365-20-000011:note_history:69]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 672,727 |  |  | 77.2 | % |  | $ | 762,622 |  |  | 81.9 | % |  | $ | 1,308,753 |  |  | 78.3 | % |  | $ | 1,568,538 |  |  | 82.4 | % |
| Subsystems and accessories | 198,216 |  |  | 22.8 | % |  | 168,887 |  |  | 18.1 | % |  | 361,994 |  |  | 21.7 | % |  | 334,089 |  |  | 17.6 | % |
| Total | $ | 870,943 |  |  | 100.0 | % |  | $ | 931,509 |  |  | 100.0 | % |  | $ | 1,670,747 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |

- changed (2020-02-07):
[0001375365-20-000011:note_history:70]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-20, similarity 0.9079):
[0001375365-19-000084:note_history:70]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2019 and 2018, of net sales by geographic region (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:71]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| United States | $ | 527,404 |  |  | $ | 511,913 |  |  | $ | 996,245 |  |  | $ | 1,079,528 |  |
| Europe | 147,564 |  |  | 180,976 |  |  | 275,623 |  |  | 343,536 |  |
| Asia | 165,716 |  |  | 196,308 |  |  | 327,355 |  |  | 403,176 |  |
| Others | 30,259 |  |  | 42,312 |  |  | 71,524 |  |  | 76,387 |  |
|  | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |
  (was, 2019-12-20, similarity 0.7195):
[0001375365-19-000084:note_history:71]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| United States | $ | 468,841 |  |  | $ | 567,615 |  |
| Europe | 128,059 |  |  | 162,560 |  |
| Asia | 161,639 |  |  | 206,868 |  |
| Others | 41,265 |  |  | 34,075 |  |
|  | $ | 799,804 |  |  | $ | 971,118 |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:72]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2019 and 2018:
  (was, 2019-12-20, similarity 0.9021):
[0001375365-19-000084:note_history:72]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three months ended September 30, 2019 and 2018:

- added (2020-02-07):
[0001375365-20-000011:note_history:73]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- removed (2020-02-07):
[0001375365-19-000084:note_history:74]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 636,026 |  |  | 79.5 | % |  | $ | 808,027 |  |  | 83.2 | % |
| Subsystems and accessories | 163,778 |  |  | 20.5 | % |  | 163,091 |  |  | 16.8 | % |
| Total | $ | 799,804 |  |  | 100.0 | % |  | $ | 971,118 |  |  | 100.0 | % |

- removed (2020-02-07):
[0001375365-19-000084:note_history:75]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001375365-20-000011:note_history:76]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the
  (was, 2019-12-20, similarity 0.9878):
[0001375365-19-000084:note_history:76]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor

- changed (2020-02-07):
[0001375365-20-000011:note_history:77]
distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.
  (was, 2019-12-20, similarity 0.9733):
[0001375365-19-000084:note_history:77]
obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- added (2020-02-07):
[0001375365-20-000011:note_history:78]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2020-02-07):
[0001375365-19-000084:note_history:79]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-07):
[0001375365-20-000011:note_history:80]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 672,727 |  |  | 77.2 | % |  | $ | 762,622 |  |  | 81.9 | % |  | $ | 1,308,753 |  |  | 78.3 | % |  | $ | 1,568,538 |  |  | 82.4 | % |
| Subsystems and accessories | 198,216 |  |  | 22.8 | % |  | 168,887 |  |  | 18.1 | % |  | 361,994 |  |  | 21.7 | % |  | 334,089 |  |  | 17.6 | % |
| Total | $ | 870,943 |  |  | 100.0 | % |  | $ | 931,509 |  |  | 100.0 | % |  | $ | 1,670,747 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |

- changed (2020-02-07):
[0001375365-20-000011:note_history:81]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-20, similarity 0.9079):
[0001375365-19-000084:note_history:81]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2019 and 2018, of net sales by geographic region (in thousands):

- changed (2020-02-07):
[0001375365-20-000011:note_history:82]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| United States | $ | 527,404 |  |  | $ | 511,913 |  |  | $ | 996,245 |  |  | $ | 1,079,528 |  |
| Europe | 147,564 |  |  | 180,976 |  |  | 275,623 |  |  | 343,536 |  |
| Asia | 165,716 |  |  | 196,308 |  |  | 327,355 |  |  | 403,176 |  |
| Others | 30,259 |  |  | 42,312 |  |  | 71,524 |  |  | 76,387 |  |
|  | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |
  (was, 2019-12-20, similarity 0.7195):
[0001375365-19-000084:note_history:82]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| United States | $ | 468,841 |  |  | $ | 567,615 |  |
| Europe | 128,059 |  |  | 162,560 |  |
| Asia | 161,639 |  |  | 206,868 |  |
| Others | 41,265 |  |  | 34,075 |  |
|  | $ | 799,804 |  |  | $ | 971,118 |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:83]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2019 and 2018:
  (was, 2019-12-20, similarity 0.9021):
[0001375365-19-000084:note_history:83]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three months ended September 30, 2019 and 2018:

- added (2020-02-07):
[0001375365-20-000011:note_history:84]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- changed (2020-02-07):
[0001375365-20-000011:note_history:85]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and six months ended December 31, 2019, which was included in the opening deferred revenue balance as of June 30, 2019, was $23.2 million and $48.7 million, respectively.
  (was, 2019-12-20, similarity 0.7651):
[0001375365-19-000084:note_history:85]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On June 30, 2019, deferred revenue totaled $203.4 million, of which $25.5 million was recognized as revenue during the three months ended September 30, 2019.

- added (2020-02-07):
[0001375365-20-000011:note_history:86]
Deferred revenue decreased during the six months ended December 31, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.

- changed (2020-02-07):
[0001375365-20-000011:note_history:87]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2019 was approximately $215.6 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2019-12-20, similarity 0.9961):
[0001375365-19-000084:note_history:87]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2019 was approximately $201.9 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2020-02-07):
[0001375365-19-000084:note_history:88]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 636,026 |  |  | 79.5 | % |  | $ | 808,027 |  |  | 83.2 | % |
| Subsystems and accessories | 163,778 |  |  | 20.5 | % |  | 163,091 |  |  | 16.8 | % |
| Total | $ | 799,804 |  |  | 100.0 | % |  | $ | 971,118 |  |  | 100.0 | % |

- removed (2020-02-07):
[0001375365-19-000084:note_history:89]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

- removed (2020-02-07):
[0001375365-19-000084:note_history:90]
Deferred revenue decreased during the three months ended September 30, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-02-07):
[0001375365-19-000084:note_history:91]
Subsequent Events

- removed (2020-02-07):
[0001375365-19-000084:note_history:92]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring is not expected to have a material impact to the estimated annual effective tax rate.
