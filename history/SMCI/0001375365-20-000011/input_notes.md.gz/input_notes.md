# SMCI notes — 0001375365-20-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-20-000011:notes:1]
[same as prior period, unchanged from 0001375365-19-000084:notes:1]

[0001375365-20-000011:notes:2]
[same as prior period, unchanged from 0001375365-19-000084:notes:2]

[0001375365-20-000011:notes:3]
[same as prior period, unchanged from 0001375365-19-000084:notes:3]

[0001375365-20-000011:notes:4]
[same as prior period, unchanged from 0001375365-19-000084:notes:4]

[0001375365-20-000011:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. Equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

[0001375365-20-000011:notes:6]
[same as prior period, unchanged from 0001375365-19-000084:notes:6]

[0001375365-20-000011:notes:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

[0001375365-20-000011:notes:8]
[same as prior period, unchanged from 0001375365-19-000084:notes:8]

[0001375365-20-000011:notes:9]
[same as prior period, unchanged from 0001375365-19-000084:notes:9]

[0001375365-20-000011:notes:10]
[same as prior period, unchanged from 0001375365-19-000084:notes:10]

[0001375365-20-000011:notes:11]
[same as prior period, unchanged from 0001375365-19-000084:notes:11]

[0001375365-20-000011:notes:12]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the

[0001375365-20-000011:notes:13]
distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

[0001375365-20-000011:notes:14]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-20-000011:notes:15]
[same as prior period, unchanged from 0001375365-19-000084:notes:15]

[0001375365-20-000011:notes:16]
[same as prior period, unchanged from 0001375365-19-000084:notes:16]

[0001375365-20-000011:notes:17]
[same as prior period, unchanged from 0001375365-19-000084:notes:17]

[0001375365-20-000011:notes:18]
[same as prior period, unchanged from 0001375365-19-000084:notes:18]

[0001375365-20-000011:notes:19]
[same as prior period, unchanged from 0001375365-19-000084:notes:19]

[0001375365-20-000011:notes:20]
[same as prior period, unchanged from 0001375365-19-000084:notes:20]

[0001375365-20-000011:notes:21]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties, and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated repair and replacement of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,

[0001375365-20-000011:notes:22]
[same as prior period, unchanged from 0001375365-19-000084:notes:22]

[0001375365-20-000011:notes:23]
[same as prior period, unchanged from 0001375365-19-000084:notes:23]

[0001375365-20-000011:notes:24]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-20-000011:notes:25]
[same as prior period, unchanged from 0001375365-19-000084:notes:25]

[0001375365-20-000011:notes:26]
[same as prior period, unchanged from 0001375365-19-000084:notes:26]

[0001375365-20-000011:notes:27]
[same as prior period, unchanged from 0001375365-19-000084:notes:27]

[0001375365-20-000011:notes:28]
[same as prior period, unchanged from 0001375365-19-000084:notes:28]

[0001375365-20-000011:notes:29]
[same as prior period, unchanged from 0001375365-19-000084:notes:29]

[0001375365-20-000011:notes:30]
[same as prior period, unchanged from 0001375365-19-000084:notes:30]

[0001375365-20-000011:notes:31]
[same as prior period, unchanged from 0001375365-19-000084:notes:31]

[0001375365-20-000011:notes:32]
[same as prior period, unchanged from 0001375365-19-000084:notes:32]

[0001375365-20-000011:notes:33]
[same as prior period, unchanged from 0001375365-19-000084:notes:33]

[0001375365-20-000011:notes:34]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-20-000011:notes:35]
[same as prior period, unchanged from 0001375365-19-000084:notes:35]

[0001375365-20-000011:notes:36]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-20-000011:notes:37]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.

[0001375365-20-000011:notes:38]
[same as prior period, unchanged from 0001375365-19-000084:notes:38]

[0001375365-20-000011:notes:39]
Assets under finance leases are included in property, plant and equipment, net and current, and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-20-000011:notes:40]
[same as prior period, unchanged from 0001375365-19-000084:notes:40]

[0001375365-20-000011:notes:41]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following was true at inception: (a) the present value of minimum lease payments met or exceeded 90% of the fair value of the asset, (b) the lease term was greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contained a bargain purchase option, or (d) title to the property transferred to the Company at the end of the lease. The Company recorded an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets were depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability was accounted for using the effective interest method.

[0001375365-20-000011:notes:42]
Leases that were not classified as capital leases were accounted for as operating leases. Operating lease agreements that had tenant improvement allowances were evaluated for lease incentives. For leases that contained escalating rent payments, the Company recognized rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

[0001375365-20-000011:notes:43]
[same as prior period, unchanged from 0001375365-19-000084:notes:43]

[0001375365-20-000011:notes:44]
[same as prior period, unchanged from 0001375365-19-000084:notes:44]

[0001375365-20-000011:notes:45]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary with respect to either Ablecom or Compuware as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-20-000011:notes:46]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed and operated manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and six months ended December 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

[0001375365-20-000011:notes:47]
[same as prior period, unchanged from 0001375365-19-000084:notes:47]

[0001375365-20-000011:notes:48]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party. As of December 31, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $1.1 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $1.0 million and $1.8 million for the three months ended December 31, 2019 and 2018, respectively, and $0.0 million and $3.2 million for the six months ended December 31, 2019 and 2018, respectively, and were recorded as share of loss from equity investee, net of taxes in the Company’s condensed consolidated statements of operations.

[0001375365-20-000011:notes:49]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of December 31, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.0 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-20-000011:notes:50]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and six months ended December 31, 2019 and 2018, respectively.

[0001375365-20-000011:notes:51]
Additionally, the Company sold products worth $15.4 million and $12.1 million to the Corporate Venture in the three months ended December 31, 2019 and 2018, respectively, and $37.5 million and $21.5 million in the six months ended December 31, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.2 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

[0001375365-20-000011:notes:52]
[same as prior period, unchanged from 0001375365-19-000084:notes:52]

[0001375365-20-000011:notes:53]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.5% and 23.4% of total purchases for the three months ended December 31, 2019 and 2018, respectively, and 28.6% and 21.5% for the six months ended December 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company as noted in Note 9, "Related Party Transactions," accounted for 10.3% and 9.3% of total cost of sales for the three months ended December 31, 2019 and 2018, respectively, and 10.0% and 9.2% for the six months ended December 31, 2019 and 2018, respectively.

[0001375365-20-000011:notes:54]
[same as prior period, unchanged from 0001375365-19-000084:notes:54]

[0001375365-20-000011:notes:55]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three and six months ended December 31, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

[0001375365-20-000011:notes:56]
[same as prior period, unchanged from 0001375365-19-000084:notes:56]

[0001375365-20-000011:notes:57]
[same as prior period, unchanged from 0001375365-19-000084:notes:57]

[0001375365-20-000011:notes:58]
[same as prior period, unchanged from 0001375365-19-000084:notes:58]

[0001375365-20-000011:notes:59]
[same as prior period, unchanged from 0001375365-19-000084:notes:59]

[0001375365-20-000011:notes:60]
[same as prior period, unchanged from 0001375365-19-000084:notes:60]

[0001375365-20-000011:notes:61]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-20-000011:notes:62]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

[0001375365-20-000011:notes:63]
[same as prior period, unchanged from 0001375365-19-000084:notes:64]

[0001375365-20-000011:notes:64]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-20-000011:notes:65]
[same as prior period, unchanged from 0001375365-19-000084:notes:65]

[0001375365-20-000011:notes:66]
[same as prior period, unchanged from 0001375365-19-000084:notes:66]

[0001375365-20-000011:notes:67]
[same as prior period, unchanged from 0001375365-19-000084:notes:67]

[0001375365-20-000011:notes:68]
[same as prior period, unchanged from 0001375365-19-000084:notes:68]

[0001375365-20-000011:notes:69]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 672,727 |  |  | 77.2 | % |  | $ | 762,622 |  |  | 81.9 | % |  | $ | 1,308,753 |  |  | 78.3 | % |  | $ | 1,568,538 |  |  | 82.4 | % |
| Subsystems and accessories | 198,216 |  |  | 22.8 | % |  | 168,887 |  |  | 18.1 | % |  | 361,994 |  |  | 21.7 | % |  | 334,089 |  |  | 17.6 | % |
| Total | $ | 870,943 |  |  | 100.0 | % |  | $ | 931,509 |  |  | 100.0 | % |  | $ | 1,670,747 |  |  | 100.0 | % |  | $ | 1,902,627 |  |  | 100.0 | % |

[0001375365-20-000011:notes:70]
[same as prior period, unchanged from 0001375365-19-000084:notes:70]

[0001375365-20-000011:notes:71]
[same as prior period, unchanged from 0001375365-19-000084:notes:71]

[0001375365-20-000011:notes:72]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2019 and 2018, of net sales by geographic region (in thousands):

[0001375365-20-000011:notes:73]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| United States | $ | 527,404 |  |  | $ | 511,913 |  |  | $ | 996,245 |  |  | $ | 1,079,528 |  |
| Europe | 147,564 |  |  | 180,976 |  |  | 275,623 |  |  | 343,536 |  |
| Asia | 165,716 |  |  | 196,308 |  |  | 327,355 |  |  | 403,176 |  |
| Others | 30,259 |  |  | 42,312 |  |  | 71,524 |  |  | 76,387 |  |
|  | $ | 870,943 |  |  | $ | 931,509 |  |  | $ | 1,670,747 |  |  | $ | 1,902,627 |  |

[0001375365-20-000011:notes:74]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and six months ended December 31, 2019 and 2018:

[0001375365-20-000011:notes:75]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2019 |  | 2018 |  | % |  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 51.4 | % |  | 40.8 | % |  | 10.6 | % |  | 50.7 | % |  | 37.5 | % |  | 13.2 | % |
| Direct customers and OEMs | 48.6 | % |  | 59.2 | % |  | (10.6 | )% |  | 49.3 | % |  | 62.5 | % |  | (13.2 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-20-000011:notes:76]
[same as prior period, unchanged from 0001375365-19-000084:notes:76]

[0001375365-20-000011:notes:77]
[same as prior period, unchanged from 0001375365-19-000084:notes:77]

[0001375365-20-000011:notes:78]
[same as prior period, unchanged from 0001375365-19-000084:notes:78]

[0001375365-20-000011:notes:79]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and six months ended December 31, 2019, which was included in the opening deferred revenue balance as of June 30, 2019, was $23.2 million and $48.7 million, respectively.

[0001375365-20-000011:notes:80]
Deferred revenue decreased during the six months ended December 31, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.

[0001375365-20-000011:notes:81]
[same as prior period, unchanged from 0001375365-19-000084:notes:81]

[0001375365-20-000011:notes:82]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2019 was approximately $215.6 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-20-000011:notes:83]
[same as prior period, unchanged from 0001375365-19-000084:notes:83]

[0001375365-20-000011:notes:84]
[same as prior period, unchanged from 0001375365-19-000084:notes:84]

[0001375365-20-000011:notes:85]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of the date the 2016 Plan became effective, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006 Plan"). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards have been or will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan at the time the 2016 Plan became effective, if those awards were or are forfeited at any time after the 2016 Plan became effective, became available or will become available for use under the 2016 Plan. At the time the 2016 Plan became effective, all remaining ungranted shares under the 2006 Plan were canceled. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. Under the 2016 Plan, the Company granted PRSUs to its Chief Executive Officer, 50% of which vest based on the achievement of certain performance metrics at the end of the performance period while the remainder vest in equal amounts over the following ten quarters provided he continues to be employed by the Company. As of December 31, 2019, the Company had 463,411 authorized shares available for future issuance under the 2016 Plan.

[0001375365-20-000011:notes:86]
[same as prior period, unchanged from 0001375365-19-000084:notes:87]

[0001375365-20-000011:notes:87]
[same as prior period, unchanged from 0001375365-19-000084:notes:88]

[0001375365-20-000011:notes:88]
[same as prior period, unchanged from 0001375365-19-000084:notes:89]

[0001375365-20-000011:notes:89]
[same as prior period, unchanged from 0001375365-19-000084:notes:90]

[0001375365-20-000011:notes:90]
[same as prior period, unchanged from 0001375365-19-000084:notes:91]

[0001375365-20-000011:notes:91]
[same as prior period, unchanged from 0001375365-19-000084:notes:92]

[0001375365-20-000011:notes:92]
The fair value of stock option grants for the three and six months ended December 31, 2019 and 2018 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-20-000011:notes:93]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Risk-free interest rate | 1.72 | % |  | 2.97 | % |  | 1.58% - 1.72% |  |  | 2.87% - 2.97% |  |
| Expected term | 6.27 years |  |  | 6.05 years |  |  | 6.27 years |  |  | 6.05 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 49.74 | % |  | 50.02 | % |  | 49.74% - 50.04% |  |  | 47.34% - 50.02% |  |
| Weighted-average fair value | $ | 10.30 |  |  | $ | 6.62 |  |  | $ | 9.14 |  |  | $ | 8.77 |  |

[0001375365-20-000011:notes:94]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2019 and 2018 (in thousands):

[0001375365-20-000011:notes:95]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of sales | $ | 384 |  |  | $ | 428 |  |  | $ | 779 |  |  | $ | 866 |  |
| Research and development | 3,126 |  |  | 3,212 |  |  | 6,256 |  |  | 6,708 |  |
| Sales and marketing | 423 |  |  | 436 |  |  | 859 |  |  | 941 |  |
| General and administrative | 1,031 |  |  | 1,171 |  |  | 2,124 |  |  | 2,606 |  |
| Stock-based compensation expense before taxes | 4,964 |  |  | 5,247 |  |  | 10,018 |  |  | 11,121 |  |
| Income tax impact | (1,131 | ) |  | (1,082 | ) |  | (2,283 | ) |  | (2,324 | ) |
| Stock-based compensation expense, net | $ | 3,833 |  |  | $ | 4,165 |  |  | $ | 7,735 |  |  | $ | 8,797 |  |

[0001375365-20-000011:notes:96]
As of December 31, 2019, $6.5 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.53 years, $32.6 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.81 years and $0.1 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 1.0 year.

[0001375365-20-000011:notes:97]
[same as prior period, unchanged from 0001375365-19-000084:notes:98]

[0001375365-20-000011:notes:98]
The following table summarizes stock option activity during the six months ended December 31, 2019 under all plans:

[0001375365-20-000011:notes:99]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |
| Granted |  | 160,600 |  |  | $ | 18.44 |  |  |  |
| Exercised |  | (288,985 | ) |  | $ | 14.04 |  |  |  |
| Forfeited/Cancelled |  | (358,006 | ) |  | $ | 8.69 |  |  |  |
| Balance as of December 31, 2019 |  | 6,888,244 |  |  | $ | 18.68 |  |  | 3.77 |
| Options vested and exercisable at December 31, 2019 |  | 6,152,154 |  |  | $ | 18.46 |  |  | 3.19 |

[0001375365-20-000011:notes:100]
[same as prior period, unchanged from 0001375365-19-000084:notes:101]

[0001375365-20-000011:notes:101]
In January 2015, the Company began to grant RSUs to employees. The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are typically service based share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting.

[0001375365-20-000011:notes:102]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. The first award was a one-year PRSU and the second award was a two-year PRSU. The one-year PRSUs would be earned based on the Company’s performance as it relates to a revenue growth metric and a minimum non-GAAP operating margin metric during the fiscal year ended June 30, 2018 with eligibility up to 200% of the targeted number of units based on revenue growth if the minimum non-GAAP operating margin is achieved. If the performance metrics were met, 50% of the PRSUs would vest at June 30, 2018 while the remainder would vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors determined that the Company achieved the revenue and non-GAAP operating margin metrics for the fiscal year ended June 30, 2018 at a level that entitled the Chief Executive Officer to 200% of the originally targeted number of shares subject to the one-year PRSU. 50% of the PRSUs so earned were vested as of June 30, 2018, and an additional 30% of the PRSUs vested during the six quarters ended December 31, 2019, in accordance with the terms of the grant.

[0001375365-20-000011:notes:103]
The two-year PRSUs would be earned based on the Company’s performance for the average non-GAAP operating margin metric for the two fiscal years ended June 30, 2019 with eligibility up to 100% of the targeted number of units. If the performance metrics would have been met, 50% of the PRSUs would have vested at June 30, 2019 while the remainder would have been vested in equal amounts over the following ten quarters if the Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors has

[0001375365-20-000011:notes:104]
determined that the Company did not achieve the required performance metrics for these two-year PRSUs to be earned and none of the two-year PRSUs vested.

[0001375365-20-000011:notes:105]
The following table summarizes RSUs and PRSUs activity during the six months ended December 31, 2019 under all plans:

[0001375365-20-000011:notes:106]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2019 | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Granted | 571,200 |  |  | $ | 18.91 |  |  | — |  |  |  |  |
| Released (2) | (508,979 | ) |  | $ | 20.96 |  |  | — |  |  |  |  |
| Forfeited | (86,559 | ) |  | $ | 18.49 |  |  | — |  |  |  |  |
| Balance as of December 31, 2019 | 1,848,764 |  |  | $ | 19.72 |  |  | 120,000 |  |  |  | $ | 27.10 |  |

[0001375365-20-000011:notes:107]
[same as prior period, unchanged from 0001375365-19-000084:notes:108]

[0001375365-20-000011:notes:108]
[same as prior period, unchanged from 0001375365-19-000084:notes:109]

[0001375365-20-000011:notes:109]
[same as prior period, unchanged from 0001375365-19-000084:notes:110]

[0001375365-20-000011:notes:110]
The number of shares released excludes 96,000 PRSUs that were vested but not released as of December 31, 2019, of which 6,000 PRSUs vested during the three months ended December 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0001375365-20-000011:notes:111]
[same as prior period, unchanged from 0001375365-19-000084:notes:112]

[0001375365-20-000011:notes:112]
The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2019 and 2018 (in thousands, except per share amounts):

[0001375365-20-000011:notes:113]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,706 |  |  | $ | 18,220 |  |  | $ | 50,051 |  |  | $ | 37,562 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 50,181 |  |  | 49,844 |  |  | 50,129 |  |  | 49,774 |  |
| Effect of dilutive securities | 1,828 |  |  | 966 |  |  | 1,629 |  |  | 1,734 |  |
| Weighted-average diluted shares | 52,009 |  |  | 50,810 |  |  | 51,758 |  |  | 51,508 |  |
| Basic net income per common share | $ | 0.47 |  |  | $ | 0.37 |  |  | $ | 1.00 |  |  | $ | 0.75 |  |
| Diluted net income per common share | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.97 |  |  | $ | 0.73 |  |

[0001375365-20-000011:notes:114]
For the three and six months ended December 31, 2019 and 2018, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 2,501,684 and 3,171,619 for three and six months ended December 31, 2019, respectively, and 5,785,490 and 4,385,154 for the three and six months ended December 31, 2018, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-20-000011:notes:115]
[same as prior period, unchanged from 0001375365-19-000084:notes:116]

[0001375365-20-000011:notes:116]
[same as prior period, unchanged from 0001375365-19-000084:notes:117]

[0001375365-20-000011:notes:117]
[same as prior period, unchanged from 0001375365-19-000084:notes:118]

[0001375365-20-000011:notes:118]
|  | December 31, 2019 |  | June 30, 2019 |
| Finished goods | $ | 502,062 |  |  | $ | 492,387 |  |
| Work in process | 64,113 |  |  | 43,598 |  |
| Purchased parts and raw materials | 138,255 |  |  | 134,203 |  |
| Total inventories | $ | 704,430 |  |  | $ | 670,188 |  |

[0001375365-20-000011:notes:119]
The Company recorded a provision for excess and obsolete inventory to cost of sales totaling $6.8 million and $16.9 million in the three and six months ended December 31, 2019, respectively, and $4.6 million and $12.6 million in the three and six months ended December 31, 2018, respectively. These amounts exclude a (recovery) provision for adjusting the cost of certain inventories to net realizable value of $(0.9) million and $(2.7) million for the three and six months ended December 31, 2019, respectively, and $1.5 million for the six months ended December 31, 2018. The provision for adjusting the cost of certain inventories to net realizable value for the three months ended December 31, 2018 was not material.

[0001375365-20-000011:notes:120]
[same as prior period, unchanged from 0001375365-19-000084:notes:121]

[0001375365-20-000011:notes:121]
|  | December 31, 2019 |  | June 30, 2019 |
| Receivables from vendors (1) | $ | 92,354 |  |  | $ | 83,050 |  |
| Prepaid income tax | 17,608 |  |  | 607 |  |
| Restricted cash | 12,682 |  |  | 11,673 |  |
| Prepaid expenses | 7,645 |  |  | 7,269 |  |
| Deferred service costs | 3,748 |  |  | 3,374 |  |
| Others | 13,018 |  |  | 3,822 |  |
| Total prepaid expenses and other current assets | $ | 147,055 |  |  | $ | 109,795 |  |

[0001375365-20-000011:notes:122]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $85.6 million and $82.0 million as of December 31, 2019 and June 30, 2019, respectively.

[0001375365-20-000011:notes:123]
[same as prior period, unchanged from 0001375365-19-000084:notes:124]

[0001375365-20-000011:notes:124]
|  | December 31, 2019 |  | June 30, 2019 |
| Cash and cash equivalents | $ | 309,038 |  |  | $ | 248,164 |  |
| Restricted cash included in prepaid expenses and other current assets | 12,682 |  |  | 11,673 |  |
| Restricted cash included in other assets | 2,333 |  |  | 2,303 |  |
| Total cash, cash equivalents and restricted cash | $ | 324,053 |  |  | $ | 262,140 |  |

[0001375365-20-000011:notes:125]
[same as prior period, unchanged from 0001375365-19-000084:notes:126]

[0001375365-20-000011:notes:126]
|  | December 31, 2019 |  | June 30, 2019 |
| Buildings | $ | 86,930 |  |  | $ | 86,136 |  |
| Machinery and equipment | 83,419 |  |  | 79,946 |  |
| Land | 75,223 |  |  | 74,926 |  |
| Buildings construction in progress (1) | 29,653 |  |  | 14,189 |  |
| Building and leasehold improvements | 24,293 |  |  | 22,307 |  |
| Furniture and fixtures | 20,651 |  |  | 20,193 |  |
| Software | 19,066 |  |  | 18,415 |  |
|  | 339,235 |  |  | 316,112 |  |
| Accumulated depreciation and amortization | (118,684 | ) |  | (108,775 | ) |
| Property, plant and equipment, net | $ | 220,551 |  |  | $ | 207,337 |  |

[0001375365-20-000011:notes:127]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California and new building construction in Taiwan.

[0001375365-20-000011:notes:128]
[same as prior period, unchanged from 0001375365-19-000084:notes:129]

[0001375365-20-000011:notes:129]
|  | December 31, 2019 |  | June 30, 2019 |
| Operating lease right-of-use asset | $ | 12,568 |  |  | $ | — |  |
| Deferred service costs, non-current | 3,956 |  |  | 3,572 |  |
| Restricted cash, non-current | 2,333 |  |  | 2,303 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 565 |  |  | 686 |  |
| Non-marketable equity securities | 128 |  |  | 878 |  |
| Prepaid expense, non-current | 1,597 |  |  | 1,649 |  |
| Total other assets | $ | 22,718 |  |  | $ | 10,659 |  |

[0001375365-20-000011:notes:130]
[same as prior period, unchanged from 0001375365-19-000084:notes:131]

[0001375365-20-000011:notes:131]
|  | December 31, 2019 |  | June 30, 2019 |
| Contract manufacturers liability | $ | 36,866 |  |  | $ | 25,308 |  |
| Accrued payroll and related expenses | 29,143 |  |  | 25,552 |  |
| Customer deposits | 15,714 |  |  | 11,133 |  |
| Accrued warranty costs | 8,956 |  |  | 8,661 |  |
| Accrued cooperative marketing expenses | 6,174 |  |  | 5,830 |  |
| Accrued professional fees | 5,572 |  |  | 11,756 |  |
| Operating lease liability | 4,851 |  |  | — |  |
| Others | 30,089 |  |  | 26,438 |  |
| Total accrued liabilities | $ | 137,365 |  |  | $ | 114,678 |  |

[0001375365-20-000011:notes:132]
[same as prior period, unchanged from 0001375365-19-000084:notes:133]

[0001375365-20-000011:notes:133]
|  | December 31, 2019 |  | June 30, 2019 |
| Accrued unrecognized tax benefits including related interest and penalties | $ | 20,458 |  |  | $ | 20,102 |  |
| Operating lease liability, non-current | 8,169 |  |  | — |  |
| Accrued warranty costs, non-current | 2,486 |  |  | 2,373 |  |
| Others | 2,080 |  |  | 3,708 |  |
| Total other long-term liabilities | $ | 33,193 |  |  | $ | 26,183 |  |

[0001375365-20-000011:notes:134]
[same as prior period, unchanged from 0001375365-19-000084:notes:135]

[0001375365-20-000011:notes:135]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Balance, beginning of the period | $ | 11,285 |  |  | $ | 10,245 |  |  | $ | 11,034 |  |  | $ | 9,884 |  |
| Provision for warranty | 9,401 |  |  | 5,463 |  |  | 17,106 |  |  | 11,653 |  |
| Costs utilized | (9,115 | ) |  | (5,179 | ) |  | (16,777 | ) |  | (11,737 | ) |
| Change in estimated liability for pre-existing warranties | (129 | ) |  | (95 | ) |  | 79 |  |  | 634 |  |
| Balance, end of the period | 11,442 |  |  | 10,434 |  |  | 11,442 |  |  | 10,434 |  |
| Current portion | 8,956 |  |  | 8,216 |  |  | 8,956 |  |  | 8,216 |  |
| Non-current portion | $ | 2,486 |  |  | $ | 2,218 |  |  | $ | 2,486 |  |  | $ | 2,218 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-20-000011:notes:136]
[same as prior period, unchanged from 0001375365-19-000084:notes:137]

[0001375365-20-000011:notes:137]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and other assets. The Company classifies its cash equivalents and other assets, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of December 31, 2019 and June 30, 2019. The Company used discounted cash flows to estimate the fair value of the auction rate security as of December 31, 2019 and June 30, 2019. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-20-000011:notes:138]
[same as prior period, unchanged from 0001375365-19-000084:notes:139]

[0001375365-20-000011:notes:139]
The following table sets forth the Company’s cash equivalents, certificates of deposit and investment in an auction rate security as of December 31, 2019 and June 30, 2019, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-20-000011:notes:140]
| December 31, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,161 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,161 |  |
| Certificates of deposit (2) | — |  |  | 1,312 |  |  | — |  |  | 1,312 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,161 |  |  | $ | 1,312 |  |  | $ | 1,571 |  |  | $ | 4,044 |  |
| June 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,162 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,162 |  |
| Certificates of deposit (2) | — |  |  | 1,285 |  |  | — |  |  | 1,285 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,162 |  |  | $ | 1,285 |  |  | $ | 1,571 |  |  | $ | 4,018 |  |

[0001375365-20-000011:notes:141]
(1) $0.4 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2019 and June 30, 2019, respectively.

[0001375365-20-000011:notes:142]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents and $1.1 million and $1.1 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2019 and June 30, 2019, respectively.

[0001375365-20-000011:notes:143]
The above table excludes $308.4 million and $247.6 million of cash included in cash and cash equivalents, $12.7 million and $11.7 million of restricted cash included in prepaid expenses and other current assets, and $0.4 million and $0.4 million of restricted cash, non-current included in other assets in the condensed consolidated balance sheets as of December 31, 2019 and June 30, 2019, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and six months ended December 31, 2019 and 2018.

[0001375365-20-000011:notes:144]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and six months ended December 31, 2019 and 2018.

[0001375365-20-000011:notes:145]
The following is a summary of the Company’s investment in an auction rate security as of December 31, 2019 and June 30, 2019 (in thousands):

[0001375365-20-000011:notes:146]
|  | December 31, 2019 and June 30, 2019 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-20-000011:notes:147]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of December 31, 2019 and June 30, 2019, total debt of $23.3 million and $23.6 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-20-000011:notes:148]
[same as prior period, unchanged from 0001375365-19-000084:notes:149]

[0001375365-20-000011:notes:149]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values. During the three and six months ended December 31, 2019 and 2018, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three and six months ended December 31, 2019 and 2018.

[0001375365-20-000011:notes:150]
There were no transfers of financial assets measured on a non-recurring basis between Level 1, Level 2 or Level 3 securities during the three and six months ended December 31, 2019 and 2018.


## us-gaap:DebtDisclosureTextBlock

[0001375365-20-000011:notes:151]
Short-term Debt

[0001375365-20-000011:notes:152]
Short-term debt obligations as of December 31, 2019 and June 30, 2019 consisted of the following (in thousands):

[0001375365-20-000011:notes:153]
|  | December 31, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 23,250 |  |  | 22,531 |  |
| Total short-term debt | $ | 23,250 |  |  | $ | 23,647 |  |

[0001375365-20-000011:notes:154]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-20-000011:notes:155]
Bank of America

[0001375365-20-000011:notes:156]
2018 Bank of America Credit Facility

[0001375365-20-000011:notes:157]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and was extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

[0001375365-20-000011:notes:158]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the then-existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

[0001375365-20-000011:notes:159]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-20-000011:notes:160]
As of December 31, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2019 and June 30, 2019 were 3.75% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. In October 2019, the letter of credit amount was increased from $3.2 million to $6.4 million. The balance of debt issuance costs outstanding were immaterial as of December 31, 2019 and June 30, 2019. As of December 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-20-000011:notes:161]
CTBC Bank

[0001375365-20-000011:notes:162]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-20-000011:notes:163]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-20-000011:notes:164]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $23.3 million and $22.5 million at December 31, 2019 and June 30, 2019, respectively. The interest rate for these loans were 0.91% per annum as of December 31, 2019 and 0.93% per annum as of June 30, 2019. At December 31, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $26.7 million. As of December 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.6 million.

[0001375365-20-000011:notes:165]
Covenant Compliance

[0001375365-20-000011:notes:166]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-20-000011:notes:167]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31,

[0001375365-20-000011:notes:168]
2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

[0001375365-20-000011:notes:169]
On December 19, 2019, the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such, the Company complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

[0001375365-20-000011:notes:170]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-20-000011:notes:171]
[same as prior period, unchanged from 0001375365-19-000084:notes:173]

[0001375365-20-000011:notes:172]
Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2019 were as follows (in thousands):

[0001375365-20-000011:notes:173]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2019 |  | December 31, 2019 |
| Operating lease expense (including expense for lease agreements with related parties of $362 and $727 for the three and six months ended December 31, 2019, respectively) |  | $ | 1,595 |  |  | $ | 3,304 |  |
| Cash payments for operating leases (including payments to related parties of $380 and $737 for the three and six months ended December 31, 2019, respectively) |  | $ | 1,570 |  |  | $ | 3,415 |  |
| New operating lease assets obtained in exchange for operating lease liabilities |  | $ | 437 |  |  | $ | 668 |  |

[0001375365-20-000011:notes:174]
During the three and six months ended December 31, 2019, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable payments expensed in the three months and six months ended December 31, 2019 were $0.4 million and $0.7 million, respectively.

[0001375365-20-000011:notes:175]
As of December 31, 2019, the weighted average remaining lease term for operating leases was 4.1 years and the weighted average discount rate was 3.9%. Future minimum lease payments under noncancelable operating lease arrangements as of December 31, 2019 were as follows (in thousands):

[0001375365-20-000011:notes:176]
| Fiscal Year: |  | Minimum lease payments |
| 2020 (remainder) |  | $ | 3,373 |  |
| 2021 |  | 3,890 |  |
| 2022 |  | 2,569 |  |
| 2023 |  | 1,186 |  |
| 2024 |  | 1,145 |  |
| 2025 and beyond |  | 1,952 |  |
| Total future lease payments |  | $ | 14,115 |  |
| Less: Imputed interest |  | (1,095 | ) |
| Present value of operating lease liabilities |  | $ | 13,020 |  |

[0001375365-20-000011:notes:177]
As of December 31, 2019, commitments under short-term lease arrangements were $0.3 million. As of December 31, 2019, operating and financing leases that have not yet commenced were $0.3 million.

[0001375365-20-000011:notes:178]
The Company has entered into lease agreements with related parties.  See Note 9, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-20-000011:notes:179]
Related Party Transactions

[0001375365-20-000011:notes:180]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of December 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of December 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-20-000011:notes:181]
Dealings with Ablecom

[0001375365-20-000011:notes:182]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-20-000011:notes:183]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 97.5% and 94.8% of the chassis included in the products sold by the Company during the three months ended December 31, 2019 and 2018, respectively; and approximately 95.4% and 95.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-20-000011:notes:184]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the

[0001375365-20-000011:notes:185]
components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-20-000011:notes:186]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $49.4 million and $31.0 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-20-000011:notes:187]
Dealings with Compuware

[0001375365-20-000011:notes:188]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-20-000011:notes:189]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-20-000011:notes:190]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-20-000011:notes:191]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-20-000011:notes:192]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $84.6 million and $70.6 million at December 31, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-20-000011:notes:193]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2019 and 2018, are as follows (in thousands):

[0001375365-20-000011:notes:194]
|  | Three months ended December 31, |  | Six months ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 44,568 |  |  | $ | 36,282 |  |  | $ | 77,688 |  |  | $ | 80,918 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 6,406 |  |  | $ | 4,640 |  |  | $ | 11,953 |  |  | $ | 9,782 |  |
| Purchases (1) | 33,438 |  |  | 40,277 |  |  | 66,754 |  |  | 77,489 |  |

[0001375365-20-000011:notes:195]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-20-000011:notes:196]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2019 and 2018.

[0001375365-20-000011:notes:197]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2019 and June 30, 2019 (in thousands):

[0001375365-20-000011:notes:198]
|  | December 31, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 10,747 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 44,913 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,105 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 16,747 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 44,788 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 325 |  |  | — |  |

[0001375365-20-000011:notes:199]
____________________________

[0001375365-20-000011:notes:200]
(1) Includes current portion of operating lease liabilities.

[0001375365-20-000011:notes:201]
(2) Represents non-current portion of operating lease liabilities.

[0001375365-20-000011:notes:202]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and six months ended December 31, 2019 and 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-20-000011:notes:203]
The Company recorded provisions for income taxes of $2.1 million and $10.7 million for the three and six months ended December 31, 2019, respectively, and $4.5 million and $10.0 million for the three and six months ended December 31, 2018, respectively. The effective tax rate was 7.9% and 17.6% for the three and six months ended December 31, 2019, respectively, and 18.4% and 19.8% for the three and six months ended December 31, 2018, respectively. The effective tax rate for the three and six months ended December 31, 2019 is lower than that for the three and six months ended December 31, 2018, due to the release of unrecognized tax benefits after the settlement on a Taiwan tax audit.

[0001375365-20-000011:notes:204]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring is not expected to have a material impact on the estimated annual effective tax rate.

[0001375365-20-000011:notes:205]
As of December 31, 2019, the Company had a liability for gross unrecognized tax benefits of $27.4 million, substantially all of which, if recognized, would affect the Company's effective tax rate. During the six months ended December 31, 2019, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of December 31, 2019, the Company had accrued $1.6 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-20-000011:notes:206]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for undistributed earnings related to the Company's operations in the Netherlands. The Company may repatriate certain foreign earnings from the Netherlands that have been previously taxed in the U.S. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-20-000011:notes:207]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and intends to pay the $1.6 million tax liability when it receives the tax assessment notice, which is expected to be issued in February 2020. The impact of this adjustment on the income statement has been offset by the recognition of previously unrecognized tax benefits for the three months ended December 31, 2019.

[0001375365-20-000011:notes:208]
[same as prior period, unchanged from 0001375365-19-000084:notes:210]

[0001375365-20-000011:notes:209]
The federal statute of limitations remains open in general for tax years ended June 30, 2016 through 2019. Various states statute of limitations remain open in general for tax years ended June 30, 2015 through 2019. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2013 through 2019. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months, except for the reductions arising from the lapse of the statute of limitations. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $3.2 million in the next 12 months, primarily due to the lapse of the statute of limitations and settlement with the Tax Authorities. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-20-000011:notes:210]
Commitments and Contingencies

[0001375365-20-000011:notes:211]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant.  On July 26, 2019, the Company filed a motion to dismiss the complaint, which motion remains pending with the court.  The Company believes the allegations filed are without merit, and intends to vigorously defend against the lawsuit.

[0001375365-20-000011:notes:212]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001375365-20-000011:notes:213]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-20-000011:notes:214]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2019, these remaining noncancelable commitments were $579.2 million, including $134.0 million for related parties.

[0001375365-20-000011:notes:215]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-20-000011:notes:216]
[same as prior period, unchanged from 0001375365-19-000084:notes:219]

[0001375365-20-000011:notes:217]
[same as prior period, unchanged from 0001375365-19-000084:notes:220]

[0001375365-20-000011:notes:218]
[same as prior period, unchanged from 0001375365-19-000084:notes:221]

[0001375365-20-000011:notes:219]
|  | December 31, |  | June 30, |
| Long-lived assets: | 2019 |  | 2019 |
| United States | $ | 172,476 |  |  | $ | 162,835 |  |
| Asia | 44,470 |  |  | 41,915 |  |
| Europe | 3,605 |  |  | 2,587 |  |
|  | $ | 220,551 |  |  | $ | 207,337 |  |

[0001375365-20-000011:notes:220]
[same as prior period, unchanged from 0001375365-19-000084:notes:223]
