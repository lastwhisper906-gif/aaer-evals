# SMCI MD&A — 0001628280-16-010768


## mdna

[0001628280-16-010768:mdna:1]
[same as prior period, unchanged from 0001628280-15-008828:mdna:1]

[0001628280-16-010768:mdna:2]
[same as prior period, unchanged from 0001628280-15-008828:mdna:2]

[0001628280-16-010768:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, HPC and embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Our net sales were $639.0 million and $1,158.6 million for the three and six months ended December 31, 2015, respectively, and $503.0 million and $946.3 million for the three and six months ended December 31, 2014, respectively. The increase in our net sales in the three and six months ended December 31, 2015 compared with the three and six months ended December 31, 2014 was primarily due to increased sales of our server systems optimized for OEM and cloud/internet data center computing. Net sales of optimized servers were $453.7 million and $810.0 million for the three and six months ended December 31, 2015, respectively, and $302.3 million and $557.9 million for the three and six months ended December 31, 2014, respectively, and net sales of subsystems and accessories were $185.2 million and $348.6 million for the three and six months ended December 31, 2015, respectively, and $200.8 million and $388.5 million for the three and six months ended December 31, 2014, respectively. In the three and six months ended December 31, 2015, we experienced strong growth in sales of our complete systems including ultra, storage, data center optimized servers and Twin family of servers. The percentage of our net sales represented by sales of complete server systems increased to 71.0% and 69.9% in the three and six months ended December 31, 2015 from 60.1% and 58.9% in the three and six months ended December 31, 2014, respectively.

[0001628280-16-010768:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $34.7 million and $48.4 million for the three and six months ended December 31, 2015, respectively, and $31.2 million and $52.1 million for the three and six months ended December 31, 2014, respectively. Our increase in net income in the three months ended December 31, 2015 was primarily attributable to an increase in our gross profit resulting primarily from higher sales of our server systems, partially offset by higher operating and income tax expenses. Our decrease in net income in the six months ended December 31, 2015 was primarily attributable to the recording of a $9.3 million out-of-period adjustment relating to extended warranty revenue in the three months ended September 30, 2015. This deferred revenue will be recognized through fiscal year 2019. The impact on net income from this out-of-period adjustment was $5.9 million.

[0001628280-16-010768:mdna:5]
We sell our server systems and subsystems and accessories through distributors and OEMs as well as through our direct sales force. We derived 58.1% and 56.4% of our net sales from products sold to OEMs and to end customers and 41.9% and 43.6% from products sold to distributors for the three and six months ended December 31, 2015, respectively. We derived 50.0% and 47.2% of our net sales from products sold to OEMs and to end customers and 50.0% and 52.8% from products sold to distributors for the three and six months ended December 31, 2014, respectively. Sales to SoftLayer, a division of IBM Corporation, represented 15.0% and 12.8% of our net sales in the three and six months ended December 31, 2015, and represented 15.1% and 11.9% of our net sales in the three and six months ended December 31, 2014. We derived 63.7% and 64.4% of our net sales from customers in the United States for the three and six months ended December 31, 2015, respectively, and 57.0% and 56.0% for the three and six months ended December 31, 2014, respectively.

[0001628280-16-010768:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 4.7% and 5.1% of our net sales for the three and six months ended December 31, 2015, respectively, and 5.1% and 5.0% of our net sales for the three and six months ended December 31, 2014, respectively.

[0001628280-16-010768:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2016, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and we have improved our utilization of our overseas manufacturing capacity.

[0001628280-16-010768:mdna:8]
One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and six months ended December 31, 2015, our purchases from Ablecom represented 13.4% and 13.3% of our cost of sales, respectively, compared to 13.8% and 14.1% of our cost of sales for the three and six months ended December 31, 2014, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-16-010768:mdna:9]
[same as prior period, unchanged from 0001628280-15-008828:mdna:9]

[0001628280-16-010768:mdna:10]
[same as prior period, unchanged from 0001628280-15-008828:mdna:10]

[0001628280-16-010768:mdna:11]
The following is a summary of other financial highlights of the second quarter of fiscal 2016:

[0001628280-16-010768:mdna:12]
| • | Net cash provided by (used in) operating activities was $86.9 million and $(8.7) million during the six months ended December 31, 2015 and 2014, respectively. Our cash and cash equivalents, together with our investments, were $172.6 million at the end of the second quarter of fiscal year 2016, compared with $98.1 million at the end of fiscal year 2015. The increase in our cash and cash equivalents, together with our investments at the end of the second quarter of fiscal year 2016 was primarily due to $86.9 million of cash provided by our operating activities and $1.1 million of borrowings, net of repayments offset in part by $15.2 million of purchases of property and equipment, of which $4.9 million was related to property and equipment installed at our Green Computing Park in San Jose, California, and $2.3 million was related to the implementation of a new ERP system for the U.S. headquarters and our subsidiaries. |

[0001628280-16-010768:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the second quarter of fiscal year 2016 was 44 days, compared with 43 days at the end of fiscal year 2015. |

[0001628280-16-010768:mdna:14]
| • | Our inventory balance was $486.5 million at the end of the second quarter of fiscal year 2016, compared with $463.5 million at the end of fiscal year 2015. Days sales of inventory at the end of the second quarter of fiscal year 2016 was 82 days, compared with 83 days at the end of fiscal year 2015. |

[0001628280-16-010768:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $399.1 million at the end of the second quarter of fiscal year 2016 and $378.3 million at the end of fiscal year 2015. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $160.9 million, which have terms expiring through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-16-010768:mdna:16]
[same as prior period, unchanged from 0001628280-15-008828:mdna:18]

[0001628280-16-010768:mdna:17]
[same as prior period, unchanged from 0001628280-15-008828:mdna:19]

[0001628280-16-010768:mdna:18]
[same as prior period, unchanged from 0001628280-15-008828:mdna:20]

[0001628280-16-010768:mdna:19]
[same as prior period, unchanged from 0001628280-15-008828:mdna:21]

[0001628280-16-010768:mdna:20]
[same as prior period, unchanged from 0001628280-15-008828:mdna:22]

[0001628280-16-010768:mdna:21]
[same as prior period, unchanged from 0001628280-15-008828:mdna:23]

[0001628280-16-010768:mdna:22]
[same as prior period, unchanged from 0001628280-15-008828:mdna:24]

[0001628280-16-010768:mdna:23]
[same as prior period, unchanged from 0001628280-15-008828:mdna:25]

[0001628280-16-010768:mdna:24]
[same as prior period, unchanged from 0001628280-15-008828:mdna:26]

[0001628280-16-010768:mdna:25]
[same as prior period, unchanged from 0001628280-15-008828:mdna:27]

[0001628280-16-010768:mdna:26]
[same as prior period, unchanged from 0001628280-15-008828:mdna:28]

[0001628280-16-010768:mdna:27]
[same as prior period, unchanged from 0001628280-15-008828:mdna:29]

[0001628280-16-010768:mdna:28]
[same as prior period, unchanged from 0001628280-15-008828:mdna:30]

[0001628280-16-010768:mdna:29]
Revenue recognition. We recognize revenue from sales of products when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. Our standard arrangement with our customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the stated destination. We generally do not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, we regularly review our history of actual returns for each major product line. We also communicate regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with our distributors.

[0001628280-16-010768:mdna:30]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. We have an immaterial amount of deferred revenue and costs related to shipments to customers pending acceptance as of December 31, 2015 and June 30, 2015.

[0001628280-16-010768:mdna:31]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision (recovery) for bad debt was $707,000 and $805,000 in the three and six months ended December 31, 2015, respectively, and $(33,000) and $(87,000) in the three and six months ended December 31, 2014, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-16-010768:mdna:32]
We  have an immaterial amount of service revenue relating to on-site service, extended warranty and non-warranty repairs. Revenue for on-site service, and extended warranty is recognized over the contracted service period, and revenue for non-warranty repair service is recognized upon shipment of the repaired units to customers. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001628280-16-010768:mdna:33]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product

[0001628280-16-010768:mdna:34]
repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.8 million as of December 31, 2015, compared with $7.7 million as of June 30, 2015. The provision for warranty reserve was $4.7 million and $8.5 million in the three and six months ended December 31, 2015, respectively, and $3.3 million and $7.0 million in the three and six months ended December 31, 2014, respectively. The change in estimated liability for pre-existing warranties was ($1.6) million and $(1.8) million for the three and six months ended December 31, 2015, respectively, and $(0.1) million and $(0.3) million for the three and six months ended December 31, 2014, respectively. The change in estimated liability for pre-existing warranties decreased due to our decrease in warranty claims in the three and six months ended December 31, 2015. The provision for warranty reserve increased $1.4 million and $1.6 million compared to the three and six months ended December 31, 2014, respectively, primarily due to the increase in our net sales partially offset by our decrease in warranty claims. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates accordingly.

[0001628280-16-010768:mdna:35]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months as well as historical usage and sales activity. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $2.1 million and $3.8 million in the three and six months ended December 31, 2015, respectively, and $2.5 million and $4.2 million in the three and six months ended December 31, 2014, respectively.

[0001628280-16-010768:mdna:36]
[same as prior period, unchanged from 0001628280-15-008828:mdna:38]

[0001628280-16-010768:mdna:37]
[same as prior period, unchanged from 0001628280-15-008828:mdna:39]

[0001628280-16-010768:mdna:38]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of our Board of Directors including employee stock options and restricted stock units. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. The fair value of our restricted stock units is based on the closing market price of our common stock on the date of grant. We estimated the fair value of stock options granted using a Black-Scholes option-pricing model and a single option award approach. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001628280-16-010768:mdna:39]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to

[0001628280-16-010768:mdna:40]
estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-16-010768:mdna:41]
Compensation expense for options and restricted stock units granted to employees was $4.0 million and $7.9 million for the three and six months ended December 31, 2015, respectively, and $3.2 million and $6.2 million for the three and six months ended December 31, 2014, respectively. As of December 31, 2015, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options and restricted stock units to employees and non-employee members of our Board of Directors, was $34.5 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.33 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001628280-16-010768:mdna:42]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-16-010768:mdna:43]
In May 2012, we and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of December 31, 2015, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2015, $6,000 and $4,000, respectively, of net loss attribute to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statement of operations. In the three and six months ended December 31, 2014, $10,000 and $7,000, respectively, of net loss attributable to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-16-010768:mdna:44]
[same as prior period, unchanged from 0001628280-15-008828:mdna:46]

[0001628280-16-010768:mdna:45]
[same as prior period, unchanged from 0001628280-15-008828:mdna:47]

[0001628280-16-010768:mdna:46]
The following table presents net sales by product type for the three and six months ended December 31, 2015 and 2014 (dollars in millions):

[0001628280-16-010768:mdna:47]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |  | 2015 |  | 2014 |  | $ |  | % |
| Server systems | $ | 453.7 |  |  | $ | 302.3 |  |  | $ | 151.4 |  |  | 50.1 | % |  | $ | 810.0 |  |  | $ | 557.9 |  |  | $ | 252.1 |  |  | 45.2 | % |
| Percentage of total net sales | 71.0 | % |  | 60.1 | % |  |  |  |  |  | 69.9 | % |  | 58.9 | % |  |  |  |  |
| Subsystems and accessories | 185.2 |  |  | 200.8 |  |  | (15.6 | ) |  | (7.8 | )% |  | 348.6 |  |  | 388.5 |  |  | (39.9 | ) |  | (10.3 | )% |
| Percentage of total net sales | 29.0 | % |  | 39.9 | % |  |  |  |  |  | 30.1 | % |  | 41.1 | % |  |  |  |  |
| Total net sales | $ | 639.0 |  |  | $ | 503.0 |  |  | $ | 136.0 |  |  | 27.0 | % |  | $ | 1,158.6 |  |  | $ | 946.3 |  |  | $ | 212.2 |  |  | 22.4 | % |

[0001628280-16-010768:mdna:48]
The following table presents unit sales and average selling price by product type for the three and six months ended December 31, 2015 and 2014 (units in thousands):

[0001628280-16-010768:mdna:49]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | % |  | 2015 |  | 2014 |  | % |
| Server systems: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 102 |  |  | 78 |  |  | 30.8 | % |  | 189 |  |  | 135 |  |  | 40.0 | % |
| Average selling price | $ | 4,449 |  |  | $ | 3,875 |  |  | 14.8 | % |  | $ | 4,285 |  |  | $ | 4,132 |  |  | 3.7 | % |
| Subsystems and accessories: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 1,092 |  |  | 1,155 |  |  | (5.5 | )% |  | 2,008 |  |  | 2,289 |  |  | (12.3 | )% |
| Average selling price | $ | 169 |  |  | $ | 174 |  |  | (2.9 | )% |  | $ | 173 |  |  | $ | 170 |  |  | 1.8 | % |

[0001628280-16-010768:mdna:50]
Comparison of Three Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:51]
The increase in our net sales in the three months ended December 31, 2015 compared with the three months ended December 31, 2014 was primarily due to continued increased sales of our products optimized for OEM and cloud/internet data center computing who increasingly are purchasing complete server systems from us. The year-over-year growth in net sales of our server systems in the three months ended December 31, 2015 was due primarily to an increase in unit volumes of server systems and an increase in the average selling price of our server systems. The average selling prices of our server systems increased primarily due to higher sales of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, storage, data center optimized servers and Twin family of servers.

[0001628280-16-010768:mdna:52]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in the three months ended December 31, 2015 was primarily due to lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who are purchasing accessories from us and completing the final assembly themselves.

[0001628280-16-010768:mdna:53]
Comparison of Six Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:54]
The increase in our net sales in the six months ended December 31, 2015 compared with the six months ended December 31, 2014 was primarily due to continued increased sales of our products optimized for OEM and cloud/internet data center computing who increasingly are purchasing complete server systems from us offset in part by a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three prior fiscal year period ended June 30, 2015 and deferred in the three months ended September 30, 2015. The year-over-year growth in net sales of our server systems in the six months ended December 31, 2015 was due primarily to an increase in unit volumes of server systems and to a lesser extent an increase in the average selling price of our server systems. The average selling prices of our server systems increased primarily due to higher sales of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, storage, data center optimized servers and Twin family of servers.

[0001628280-16-010768:mdna:55]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in the six months ended December 31, 2015 was primarily due to lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who are purchasing accessories from us and completing the final assembly themselves.

[0001628280-16-010768:mdna:56]
The following table presents the percentages of net sales from products sold to distributors and OEMs and to end customers for the three and six months ended December 31, 2015 and 2014:

[0001628280-16-010768:mdna:57]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | % |  | 2015 |  | 2014 |  | % |
| Distributors | 41.9 | % |  | 50.0 | % |  | (8.1 | )% |  | 43.6 | % |  | 52.8 | % |  | (9.2 | )% |
| OEMs and end customers | 58.1 | % |  | 50.0 | % |  | 8.1 | % |  | 56.4 | % |  | 47.2 | % |  | 9.2 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-010768:mdna:58]
The following table presents percentages of net sales by geographic region for the three and six months ended December 31, 2015 and 2014:

[0001628280-16-010768:mdna:59]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | % |  | 2015 |  | 2014 |  | % |
| United States | 63.7 | % |  | 57.0 | % |  | 6.7 | % |  | 64.4 | % |  | 56.0 | % |  | 8.4 | % |
| Europe | 17.9 | % |  | 18.2 | % |  | (0.3 | )% |  | 17.4 | % |  | 19.2 | % |  | (1.8 | )% |
| Asia | 13.8 | % |  | 15.6 | % |  | (1.8 | )% |  | 14.0 | % |  | 17.6 | % |  | (3.6 | )% |
| Others | 4.6 | % |  | 9.2 | % |  | (4.6 | )% |  | 4.2 | % |  | 7.2 | % |  | (3.0 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-010768:mdna:60]
[same as prior period, unchanged from 0001628280-15-008828:mdna:59]

[0001628280-16-010768:mdna:61]
Cost of sales and gross margin for the three and six months ended December 31, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-010768:mdna:62]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |  | 2015 |  | 2014 |  | $ |  | % |
| Total cost of sales | $ | 532.6 |  |  | $ | 418.6 |  |  | $ | 114.0 |  |  | 27.2 | % |  | $ | 980.0 |  |  | $ | 792.7 |  |  | $ | 187.3 |  |  | 23.6 | % |
| Total gross profit | 106.4 |  |  | 84.5 |  |  | $ | 21.9 |  |  | 25.9 | % |  | 178.6 |  |  | 153.6 |  |  | $ | 24.9 |  |  | 16.2 | % |
| Total gross margin | 16.6 | % |  | 16.8 | % |  |  |  | (0.2 | )% |  | 15.4 | % |  | 16.2 | % |  |  |  | (0.8 | )% |

[0001628280-16-010768:mdna:63]
Comparison of Three Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:64]
The quarter-over-quarter increase in absolute dollars of cost of sales in the three months ended December 31, 2015 compared to the three months ended December 31, 2014 was primarily attributable to the increase in net sales. In the three months ended December 31, 2015, we recorded a $2.1 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $2.5 million, or 0.5% of net sales, in the three months ended December 31, 2014.

[0001628280-16-010768:mdna:65]
In the three months ended December 31, 2015, we recorded a $4.7 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to a $3.3 million expense, or 0.7% of net sales, in the three months ended December 31, 2014. The increase in the provision for warranty reserve was primarily due to higher net sales partially offset by the decrease in warranty claims in the three months ended December 31, 2015. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-010768:mdna:66]
Gross margin percentage was 16.6% and 16.8% for the three months ended December 31, 2015 and 2014, respectively, as higher sales of complete server systems such as ultra and storage servers which have higher gross margin, offset by lower gross margins from sales of cloud/internet data center sales and our subsystem and accessories. In addition, with the growth of our business, we have been able to achieve greater economies of scale which has in part offset the increasing percentage of our sales represented by lower margin cloud/internet data center sales.

[0001628280-16-010768:mdna:67]
Comparison of Six Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:68]
The year-over-year increase in absolute dollars of cost of sales in the six months ended December 31, 2015 compared to the six months ended December 31, 2014 was primarily attributable to the increase in net sales. In the six months ended December 31, 2015, we recorded a $3.8 million expense, net of recovery, or 0.3% of net sales, related to the inventory provision as compared to $4.2 million, or 0.4% of net sales, in the six months ended December 31, 2014.

[0001628280-16-010768:mdna:69]
In the six months ended December 31, 2015, we recorded a $8.5 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to a $7.0 million expense, or 0.7% of net sales, in the six months ended December 31, 2014. The increase in the provision for warranty reserve was primarily due to higher net sales partially offset by the decrease in warranty claims in the six months ended December 31, 2015. If in future periods we experience or anticipate an

[0001628280-16-010768:mdna:70]
increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-010768:mdna:71]
Gross margin percentage was 15.4% and 16.2% for the six months ended December 31, 2015 and 2014, respectively. The year-over-year decrease in gross margins in the six months ended December 31, 2015 was mainly due to a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three fiscal year period ended June 30, 2015. Gross margin percentage would have been 16.1% without this out-of-period adjustment.

[0001628280-16-010768:mdna:72]
[same as prior period, unchanged from 0001628280-15-008828:mdna:66]

[0001628280-16-010768:mdna:73]
Operating expenses for the three and six months ended December 31, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-010768:mdna:74]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |  | 2015 |  | 2014 |  | $ |  | % |
| Research and development | $ | 30.3 |  |  | $ | 25.5 |  |  | $ | 4.8 |  |  | 18.8 | % |  | $ | 58.6 |  |  | $ | 47.0 |  |  | $ | 11.6 |  |  | 24.7 | % |
| Percentage of total net sales | 4.7 | % |  | 5.1 | % |  |  |  |  |  | 5.1 | % |  | 5.0 | % |  |  |  |  |
| Sales and marketing | 16.5 |  |  | 11.2 |  |  | 5.3 |  |  | 47.5 | % |  | 30.7 |  |  | 22.2 |  |  | 8.6 |  |  | 38.6 | % |
| Percentage of total net sales | 2.6 | % |  | 2.2 | % |  |  |  |  |  | 2.7 | % |  | 2.3 | % |  |  |  |  |
| General and administrative | 10.5 |  |  | 4.9 |  |  | 5.6 |  |  | 112.6 | % |  | 18.7 |  |  | 10.0 |  |  | 8.7 |  |  | 87.1 | % |
| Percentage of total net sales | 1.6 | % |  | 1.0 | % |  |  |  |  |  | 1.5 | % |  | 1.1 | % |  |  |  |  |
| Total operating expenses | $ | 57.2 |  |  | $ | 41.6 |  |  | $ | 15.7 |  |  | 37.7 | % |  | $ | 108.0 |  |  | $ | 79.1 |  |  | $ | 28.9 |  |  | 36.5 | % |
| Percentage of total net sales | 8.9 | % |  | 8.3 | % |  |  |  |  |  | 9.3 | % |  | 8.4 | % |  |  |  |  |

[0001628280-16-010768:mdna:75]
Comparison of Three Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:76]
Research and development expenses. Research and development expenses increased by $4.8 million, or 18.8% in the three months ended December 31, 2015 compared to the three months ended December 31, 2014. Research and development expenses were 4.7% and 5.1% of net sales for the three months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was driven primarily by an increase of $4.5 million in compensation and benefits including stock-based compensation expense.

[0001628280-16-010768:mdna:77]
Research and development expenses include stock-based compensation expense of $2.5 million and $2.0 million for the three months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:78]
[same as prior period, unchanged from 0001628280-15-008828:mdna:71]

[0001628280-16-010768:mdna:79]
Sales and marketing expenses. Sales and marketing expenses increased by $5.3 million, or 47.5% in the three months ended December 31, 2015 compared to the three months ended December 31, 2014. Sales and marketing expenses were 2.6% and 2.2% of net sales for the three months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $2.5 million in compensation and benefits resulting primarily from growth in sales and marketing personnel, a decrease of $1.3 million in marketing co-op funding from certain suppliers and an increase of $1.2 million in advertising, marketing promotional and trade show expenses.

[0001628280-16-010768:mdna:80]
Sales and marketing expenses include stock-based compensation expense of $0.4 million and $0.4 million for the three months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:81]
General and administrative expenses. General and administrative expenses increased by $5.6 million, or 112.6% in the three months ended December 31, 2015 compared to the three months ended December 31, 2014. General and administrative expenses were 1.6% and 1.0% of net sales for the three months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $1.9 million in compensation and benefits including stock-based

[0001628280-16-010768:mdna:82]
compensation expense, an increase of $1.3 million in foreign currency transaction loss, an increase of $1.2 million in legal, audit and accounting expenses, and an increase of $0.7 million in bad debt expense.

[0001628280-16-010768:mdna:83]
General and administrative expenses include stock-based compensation expense of $0.8 million and $0.5 million for the three months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:84]
Comparison of Six Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:85]
Research and development expenses. Research and development expenses increased by $11.6 million, or 24.7% in the six months ended December 31, 2015 compared to the six months ended December 31, 2014. Research and development expenses were 5.1% and 5.0% of net sales for the six months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was driven primarily by an increase of $9.1 million in compensation and benefits including stock-based compensation expense and a decrease of $1.9 million refund of value added taxes on research and development expenses.

[0001628280-16-010768:mdna:86]
Research and development expenses include stock-based compensation expense of $4.9 million and $3.9 million for the six months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:87]
Our compensation and benefit expense in research and development increased from annual salary increases and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. We continue to believe that investments in research and development are critical to our future growth and competitive position in the marketplace. As such, we expect to continue to spend on current and future product development efforts.

[0001628280-16-010768:mdna:88]
Sales and marketing expenses. Sales and marketing expenses increased by $8.6 million, or 38.6% in the six months ended December 31, 2015 compared to the six months ended December 31, 2014. Sales and marketing expenses were 2.7% and 2.3% of net sales for the six months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $4.3 million in compensation and benefits resulting primarily from growth in sales and marketing personnel, an increase of $2.4 million in advertising, marketing promotional and trade show expenses and a decrease of $1.1 million in marketing co-op funding from certain suppliers.

[0001628280-16-010768:mdna:89]
Sales and marketing expenses include stock-based compensation expense of $0.8 million and $0.8 million for the six months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:90]
General and administrative expenses. General and administrative expenses increased by $8.7 million, or 87.1% in the six months ended December 31, 2015 compared to the six months ended December 31, 2014. General and administrative expenses were 1.5% and 1.1% of net sales for the six months ended December 31, 2015 and 2014, respectively. The increase in absolute dollars was primarily due to an increase of $3.9 million in compensation and benefits including stock-based compensation expense, an increase of $3.1 million in legal, audit and accounting expenses and an increase of $0.9 million in bad debt expenses.

[0001628280-16-010768:mdna:91]
General and administrative expenses include stock-based compensation expense of $1.7 million and $1.1 million for the six months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:92]
[same as prior period, unchanged from 0001628280-15-008828:mdna:77]

[0001628280-16-010768:mdna:93]
Interest and other expense, net for the three and six months ended December 31, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-010768:mdna:94]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |  | 2015 |  | 2014 |  | $ |  | % |
| Interest and other income, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | N/M* |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | N/M* |  |
| Interest expense | (0.4 | ) |  | (0.2 | ) |  | (0.2 | ) |  | 118.6 | % |  | (0.7 | ) |  | (0.4 | ) |  | (0.3 | ) |  | 91.0 | % |
| Interest and other expense, net | $ | (0.4 | ) |  | $ | (0.2 | ) |  | $ | (0.2 | ) |  | 155.8 | % |  | $ | (0.6 | ) |  | $ | (0.3 | ) |  | $ | (0.3 | ) |  | 99.0 | % |

[0001628280-16-010768:mdna:95]
*Not meaningful

[0001628280-16-010768:mdna:96]
Comparison of Three Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:97]
Interest and other expense, net. Interest and other expense, net increased by $0.2 million in the three months ended December 31, 2015 compared to the three months ended December 31, 2014. The increases were primarily due to higher interest expense on debt.

[0001628280-16-010768:mdna:98]
Comparison of Six Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:99]
Interest and other expense, net. Interest and other expense, net increased by $0.3 million in the six months ended December 31, 2015 compared to the six months ended December 31, 2014. The increases were primarily due to higher interest expense on debt.

[0001628280-16-010768:mdna:100]
[same as prior period, unchanged from 0001628280-15-008828:mdna:81]

[0001628280-16-010768:mdna:101]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-010768:mdna:102]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2015 |  | 2014 |  | $ |  | % |  | 2015 |  | 2014 |  | $ |  | % |
| Provision for income taxes | $ | 14.1 |  |  | $ | 11.5 |  |  | $ | 2.6 |  |  | 22.3 | % |  | $ | 21.6 |  |  | $ | 22.1 |  |  | $ | (0.5 | ) |  | (2.4 | )% |
| Percentage of total net sales | 2.2 | % |  | 2.3 | % |  |  |  |  |  | 1.8 | % |  | 2.3 | % |  |  |  |  |
| Effective tax rate | 28.8 | % |  | 26.9 | % |  |  |  |  |  | 30.8 | % |  | 29.8 | % |  |  |  |  |

[0001628280-16-010768:mdna:103]
Comparison of Three Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:104]
Provision for income taxes. Provision for income taxes increased by $2.6 million, or 22.3% in the three months ended December 31, 2015 compared to the three months ended December 31, 2014. The effective tax rate was 28.8% and 26.9% for the three months ended December 31, 2015 and 2014, respectively. The higher income tax provision for the three months ended December 31, 2015 was primarily attributable to our higher operating income. The effective tax rate for the three months ended December 31, 2015 was higher primarily due to additional foreign tax accrual and lower benefit from disqualifying dispositions of  shares issued upon exercise of incentive stock options.

[0001628280-16-010768:mdna:105]
Comparison of Six Months Ended December 31, 2015 and 2014

[0001628280-16-010768:mdna:106]
Provision for income taxes. Provision for income taxes decreased by $0.5 million, or 2.4% in the six months ended December 31, 2015 compared to the six months ended December 31, 2014. The effective tax rate was 30.8% and 29.8% for the six months ended December 31, 2015 and 2014, respectively. The lower income tax provision for the six months ended December 31, 2015 was primarily attributable to our lower operating income. The effective tax rate for the six months ended December 31, 2015 was higher primarily due to lower year-to-date profits.

[0001628280-16-010768:mdna:107]
[same as prior period, unchanged from 0001628280-15-008828:mdna:85]

[0001628280-16-010768:mdna:108]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $170.0 million and $95.5 million as of December 31, 2015 and June 30, 2015, respectively. Our cash in foreign locations was $51.9 million and $26.3 million at December 31, 2015 and June 30, 2015, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-16-010768:mdna:109]
Operating Activities. Net cash provided by (used in) operating activities was $86.9 million and $(8.7) million for the six months ended December 31, 2015 and 2014, respectively.

[0001628280-16-010768:mdna:110]
Net cash provided by our operating activities for the six months ended December 31, 2015 was primarily due to our net income of $48.4 million, an increase in accounts payable of $20.7 million, an increase in other long-term liabilities of $18.7 million, an increase in accrued liabilities of $9.7 million, stock-based compensation expense of $7.9 million, a decrease in

[0001628280-16-010768:mdna:111]
accounts receivable of $7.6 million, depreciation expense of $6.0 million, and provision for inventory of $3.8 million, which were partially offset by an increase in inventory of $26.8 million, an increase in deferred income taxes assets of $4.4 million, and an increase in prepaid expenses and other assets of $4.3 million.

[0001628280-16-010768:mdna:112]
Net cash used in our operating activities for the six months ended December 31, 2014 was primarily due to an increase in inventory of $97.5 million and an increase in accounts receivable of $46.0 million, which were partially offset by an increase in accounts payable of $60.0 million, our net income of $52.1 million, stock-based compensation expense of $6.2 million, an increase in net income taxes payable of $5.3 million, an increase in accrued liabilities of $4.8 million, provision for lower of cost or market and excess and obsolete inventory of $4.2 million, and depreciation expense of $3.8 million.

[0001628280-16-010768:mdna:113]
The decrease for the six months ended December 31, 2015 in accounts receivable was primarily due to lower sales in the last month of the second quarter of fiscal year 2016 as compared to the last month of the fourth quarter of fiscal year 2015. The increase for the six months ended December 31, 2015 in inventory and accounts payable was primarily due to higher purchases to support the lunar new year holiday shutdown in Asia in the beginning of February 2016 and higher sales in the six months ended December 31, 2015. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-16-010768:mdna:114]
The increase for the six months ended December 31, 2014 in accounts receivable was primarily due to an increase in our net sales late in the quarter ended December 31, 2014. The increase for the six months ended December 31, 2014 in inventory and accounts payable was primarily due to higher purchases to support the transition to Intel's DP Haswell based products. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-16-010768:mdna:115]
Investing activities. Net cash used in our investing activities was $15.6 million and $11.7 million for the six months ended December 31, 2015 and 2014, respectively. In the six months ended December 31, 2015, of the net cash used in our investing activities, $15.2 million was related to the purchase of property, plant and equipment, of which $4.9 million was related to the property and equipment of manufacturing buildings at our Green Computing Park in San Jose, California, and $2.3 million was related to the implementation of a new ERP system for the U.S. headquarters and its subsidiaries. We plan to continue the development and construction of improvements to our properties through fiscal year 2017. We anticipate investing approximately $26.5 million through November 2016 to build the second manufacturing facility and remodel our office building. We plan to finance this development through our operating cash flows and additional borrowings from banks. In the six months ended December 31, 2014, $11.0 million was related to the purchase of property, plant and equipment.

[0001628280-16-010768:mdna:116]
Financing activities. Net cash provided by our financing activities was $3.3 million and $7.2 million for the six months ended December 31, 2015 and 2014, respectively. In the six months ended December 31, 2015, we borrowed an additional $14.4 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $13.3 million in loans. Further, we received $2.4 million related to the proceeds from the exercise of stock options in the six months ended December 31, 2015.

[0001628280-16-010768:mdna:117]
In the six months ended December 31, 2014, we received $12.7 million related to the proceeds from the exercise of stock options. Further, we borrowed an additional $5.2 million under our revolving line of credit from CTBC Bank and repaid $14.4 million in loans in the six months ended December 31, 2014.

[0001628280-16-010768:mdna:118]
In the six months ended December 31, 2015 and 2014, $0.4 million and $2.8 million was related to the excess tax benefits from stock-based compensation, respectively. We expect the net cash provided by financing activities will increase throughout fiscal year 2016 as we intend to obtain additional financing from banks for our working capital requirements.

[0001628280-16-010768:mdna:119]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-16-010768:mdna:120]
[same as prior period, unchanged from 0001628280-15-008828:mdna:100]

[0001628280-16-010768:mdna:121]
[same as prior period, unchanged from 0001628280-15-008828:mdna:101]

[0001628280-16-010768:mdna:122]
[same as prior period, unchanged from 0001628280-15-008828:mdna:102]

[0001628280-16-010768:mdna:123]
In June 2015, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In November 2015, we extended the revolving line of credit to mature on February 15, 2016, and we are currently negotiating with Bank of America to renew the revolving line of credit.

[0001628280-16-010768:mdna:124]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.24% at December 31, 2015. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-16-010768:mdna:125]
As of December 31, 2015 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $2.3 million and $3.7 million, respectively. The total outstanding borrowings under the Bank of America line of credit were $62.2 million and $59.7 million as of December 31, 2015 and June 30, 2015, respectively. The interest rates for these loans ranged from 0.89% to 1.74% per annum at December 31, 2015 and 0.79% to 1.68% per annum at June 30, 2015, respectively. As of December 31, 2015, the unused revolving line of credit under Bank of America was $2.8 million.

[0001628280-16-010768:mdna:126]
[same as prior period, unchanged from 0001628280-15-008828:mdna:106]

[0001628280-16-010768:mdna:127]
In November 2015, we entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) to extend the maturity date to January 31, 2016. The amendment provides for (i) a 12-month NT$700.0 million or $22.0 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1.0 billion or $30.3 million U.S. dollar equivalents. In January 2016, we further extended the revolving line of credit to mature on March 31, 2016, and we are currently negotiating with CTBC Bank to renew the credit agreement.

[0001628280-16-010768:mdna:128]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20.0 million and $21.3 million as of December 31, 2015 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9.7 million in U.S. dollars at December 31, 2015 and June 30, 2015. The interest rate for these loans were ranged from 0.79% and 1.14% at December 31, 2015 and 0.82% and 1.16% per annum at June 30, 2015. At December 31, 2015, NT$21.0 million or $0.6 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001628280-16-010768:mdna:129]
Covenant Compliance

[0001628280-16-010768:mdna:130]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-16-010768:mdna:131]
[same as prior period, unchanged from 0001628280-15-008828:mdna:111]

[0001628280-16-010768:mdna:132]
[same as prior period, unchanged from 0001628280-15-008828:mdna:112]

[0001628280-16-010768:mdna:133]
[same as prior period, unchanged from 0001628280-15-008828:mdna:113]

[0001628280-16-010768:mdna:134]
As of December 31, 2015, our total assets of $1,148.5 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of December 31, 2015, total assets collateralizing the term loan with Bank of America were $17.2 million. As of December 31, 2015, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001628280-16-010768:mdna:135]
As of December 31, 2015, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.9 million. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2015.

[0001628280-16-010768:mdna:136]
[same as prior period, unchanged from 0001628280-15-008828:mdna:116]

[0001628280-16-010768:mdna:137]
In the three and six months ended December 31, 2015, we paid our contract manufacturers within 37 to 78 days of invoice and Ablecom between 46 to 89 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of December 31, 2015 and June 30, 2015 amounts owed to Ablecom by us were approximately $59.2 million and $59.0 million, respectively.

[0001628280-16-010768:mdna:138]
[same as prior period, unchanged from 0001628280-15-008828:mdna:118]

[0001628280-16-010768:mdna:139]
As of December 31, 2015, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AA2 at December 31, 2015. These auction rate preferred shares have no stated maturity date.

[0001628280-16-010768:mdna:140]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of December 31, 2015, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at December 31, 2015, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three and six months ended December 31, 2015 and 2014, there was no auction rate securities redeemed or sold.

[0001628280-16-010768:mdna:141]
[same as prior period, unchanged from 0001628280-15-008828:mdna:121]

[0001628280-16-010768:mdna:142]
The following table describes our contractual obligations as of December 31, 2015:

[0001628280-16-010768:mdna:143]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,176 |  |  | $ | 5,977 |  |  | $ | 4,984 |  |  | $ | 2,546 |  |  | $ | 17,683 |  |
| Capital leases, including interest | 228 |  |  | 392 |  |  | 136 |  |  | — |  |  | 756 |  |
| Debt, including interest (1) | 94,252 |  |  | — |  |  | — |  |  | — |  |  | 94,252 |  |
| Purchase commitments (2) | 399,120 |  |  | — |  |  | — |  |  | — |  |  | 399,120 |  |
| Total (3) | $ | 497,776 |  |  | $ | 6,369 |  |  | $ | 5,120 |  |  | $ | 2,546 |  |  | $ | 511,811 |  |

[0001628280-16-010768:mdna:144]
[same as prior period, unchanged from 0001628280-15-008828:mdna:124]

[0001628280-16-010768:mdna:145]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at December 31, 2015. |

[0001628280-16-010768:mdna:146]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $160.9 million of hard disk drive purchase commitments at December 31, 2015, which will be paid through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-16-010768:mdna:147]
| (3) | The table above excludes liabilities for deferred service revenue of $25.0 million and unrecognized tax benefits and related interest and penalties accrual of $15.9 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes. |

[0001628280-16-010768:mdna:148]
[same as prior period, unchanged from 0001628280-15-008828:mdna:129]

[0001628280-16-010768:mdna:149]
[same as prior period, unchanged from 0001628280-15-008828:mdna:130]

[0001628280-16-010768:mdna:150]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This guidance can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for us on July 1, 2018. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-010768:mdna:151]
In April 2015, the FASB issued an amendment to the accounting guidance related to presentation of debt issuance costs. The amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The amendment clarified that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The amendment is effective for us on July 1, 2016. We are currently evaluating the effect the amendment to the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-010768:mdna:152]
In July 2015, the FASB issued an amendment to the authoritative guidance related to inventory measurement. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for us on July 1, 2017. We are currently evaluating the effect the amendment to the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-010768:mdna:153]
In November 2015, the FASB issued an amendment to the accounting guidance related to balance sheet classification of deferred taxes. The amendment requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. Early adoption is permitted as of the beginning of an interim or annual reporting period. The amendment is effective for us on July 1, 2017. We are currently evaluating the effect the amendment to the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-010768:mdna:154]
[same as prior period, unchanged from 0001628280-15-008828:mdna:134]

[0001628280-16-010768:mdna:155]
[same as prior period, unchanged from 0001628280-15-008828:mdna:135]
