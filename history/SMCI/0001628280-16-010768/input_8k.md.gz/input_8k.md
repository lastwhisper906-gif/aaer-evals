# SMCI 8-K — 0001628280-16-010494 filed 2016-01-28

## item codes, every 8-K on or before 2016-02-04

- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2016-02-04

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-010494:8k_2_02:1]
EX-99.1
2
exhibit991q2-2016.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-16-010494:8k_2_02:2]
Exhibit

[0001628280-16-010494:8k_2_02:3]
Exhibit 99.1

[0001628280-16-010494:8k_2_02:4]
Super Micro Computer, Inc. Announces 2nd Quarter 2016 Financial Results

[0001628280-16-010494:8k_2_02:5]
SAN JOSE, Calif., January 28, 2016 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced second quarter fiscal 2016 financial results for the quarter ended December 31, 2015.

[0001628280-16-010494:8k_2_02:6]
Fiscal 2nd Quarter Highlights

[0001628280-16-010494:8k_2_02:7]
| • | Quarterly net sales of $639.0 million, up 23.0% from the first quarter of fiscal year 2016 and up 27.0% from the same quarter of last year. |

[0001628280-16-010494:8k_2_02:8]
| • | GAAP net income of $34.7 million, up 153.2% from the first quarter of fiscal year 2016 and up 11.0% from the same quarter of last year. |

[0001628280-16-010494:8k_2_02:9]
| • | GAAP gross margin was 16.6%, up from 13.9% in the first quarter of fiscal year 2016 and down from 16.8% in the same quarter of last year. |

[0001628280-16-010494:8k_2_02:10]
| • | Server solutions accounted for 71.0% of net sales compared with 68.6% in the first quarter of fiscal year 2016 and 60.1% in the same quarter of last year. |

[0001628280-16-010494:8k_2_02:11]
Net sales for the second quarter ended December 31, 2015 totaled $639.0 million, up 23.0% from $519.6 million in the first quarter of fiscal year 2016. One customer accounted for 15.0% of net sales during the quarter ended December 31, 2015.

[0001628280-16-010494:8k_2_02:12]
GAAP net income for the second quarter of fiscal year 2016 was $34.7 million or $0.67 per diluted share, an increase of 11.0% from net income of $31.2 million, or $0.61 per diluted share in the same period a year ago. Included in net income for the quarter is $4.0 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the second quarter was $38.0 million, or $0.73 per diluted share, compared to non-GAAP net income of $33.5 million, or $0.65 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the first quarter of fiscal year 2016 by $21.5 million or $0.41 per diluted share.

[0001628280-16-010494:8k_2_02:13]
GAAP gross margin for the second quarter was 16.6% compared to 16.8% in the same period a year ago. Non-GAAP gross margin for the second quarter was 16.7% compared to 16.8% in the same period year ago. GAAP gross margin and Non-GAAP gross margin for the first quarter of fiscal year 2016 were both 13.9%.

[0001628280-16-010494:8k_2_02:14]
The GAAP income tax provision was $14.1 million or 28.8% of income before tax provision compared to $11.5 million or 26.9% in the same period a year ago and $7.5 million or 35.4% in the first quarter of fiscal year 2016. The effective tax rates for the second quarter of fiscal year 2016 and 2015 were lower primarily due to the reinstatement of U.S. federal research and development tax credits.

[0001628280-16-010494:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at December 31, 2015 were $172.6 million compared to $98.1 million at June 30, 2015. Free cash flow for the six months ended December 31, 2015 was $71.7 million, primarily due to an increase in the Company's cash provided by operating activities and partially offset by the cash used in the development and construction of improvements on the Company's properties.

[0001628280-16-010494:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-16-010494:8k_2_02:17]
The Company expects net sales of $530 million to $580 million for the third quarter of fiscal year 2016 ending March 31, 2016. The Company expects non-GAAP earnings per diluted share of approximately $0.43 to $0.53 for the third quarter.

[0001628280-16-010494:8k_2_02:18]
“As previously disclosed, second quarter revenue was above our initial guidance and a record quarter. Our 27% year- over-year growth came from increases in our systems and total solutions which reached 71% of total net sales. Storage solutions grew 58% year-over-year and continue as a key growth driver while cloud and internet datacenter contributed approximately 30% of net sales leveraged by Ultra architecture and other datacenter optimized products. We also saw strong growth across all geographies and especially in North America and Europe,” said Charles Liang, Chairman and Chief Executive Officer. “Supermicro has developed the broadest array of products based on the upcoming Xeon processor, codenamed Broadwell, for launch at the very end of this quarter. With the new processor launch, combined with our new ‘Simply Double’ hot-swap 48 bay 2U storage system, software defined storage as well as our industry leading NVMe solutions, Supermicro is poised to grow its customer relationships this year and is on track with its  growth projection of greater than 20% for the fiscal year 2016.”

[0001628280-16-010494:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-16-010494:8k_2_02:20]
Conference Call Information

[0001628280-16-010494:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-576-4398 (International callers dial 1-719-325-2420) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, February 11, 2016, by dialing 1-877-870-5176 (International callers dial 1-858-384-5517) and entering replay PIN 3488698. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-16-010494:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-16-010494:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-16-010494:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-16-010494:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-16-010494:8k_2_02:26]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-16-010494:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-16-010494:8k_2_02:28]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001628280-16-010494:8k_2_02:29]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | December 31, |  | June 30, |
|  |  |  |  | 2015 |  | 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 169,892 |  |  | $ | 95,442 |  |
|  | Accounts receivable, net | 314,176 |  |  | 322,594 |  |
|  | Inventory |  | 486,531 |  |  | 463,493 |  |
|  | Deferred income taxes – current | 18,287 |  |  | 17,863 |  |
|  | Prepaid income taxes | 2,209 |  |  | 7,507 |  |
|  | Prepaid expenses and other current assets | 8,553 |  |  | 7,516 |  |
|  |  | Total current assets | 999,648 |  |  | 914,415 |  |
| Long-term investments | 2,633 |  |  | 2,633 |  |
| Property, plant and equipment, net | 173,192 |  |  | 163,038 |  |
| Deferred income taxes – noncurrent |  | 8,414 |  |  | 4,497 |  |
| Other assets |  |  | 8,751 |  |  | 5,226 |  |
|  |  | Total assets | $ | 1,192,638 |  |  | $ | 1,089,809 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 321,232 |  |  | $ | 299,774 |  |
|  | Accrued liabilities |  | 56,170 |  |  | 46,743 |  |
|  | Income taxes payable |  | 8,417 |  |  | 14,111 |  |
|  | Short-term debt and current portion of long-term debt | 94,233 |  |  | 93,479 |  |
|  |  | Total current liabilities | 480,052 |  |  | 454,107 |  |
| Long term debt-net of current portion | — |  |  | 933 |  |
| Other long-term liabilities | 34,438 |  |  | 15,684 |  |
|  |  | Total liabilities | 514,490 |  |  | 470,724 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 257,776 |  |  | 247,081 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (96 | ) |  | (80 | ) |
|  | Retained earnings |  | 422,338 |  |  | 373,950 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 677,988 |  |  | 618,921 |  |
|  | Noncontrolling interest | 160 |  |  | 164 |  |
|  |  | Total stockholders' equity | 678,148 |  |  | 619,085 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,192,638 |  |  | $ | 1,089,809 |  |

[0001628280-16-010494:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 638,964 |  |  | $ | 503,014 |  |  | $ | 1,158,582 |  |  | $ | 946,336 |  |
| Cost of sales | 532,602 |  |  | 418,562 |  |  | 980,005 |  |  | 792,691 |  |
| Gross profit | 106,362 |  |  | 84,452 |  |  | 178,577 |  |  | 153,645 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 30,264 |  |  | 25,465 |  |  | 58,590 |  |  | 46,974 |  |
| Sales and marketing | 16,461 |  |  | 11,158 |  |  | 30,710 |  |  | 22,160 |  |
| General and administrative | 10,511 |  |  | 4,944 |  |  | 18,711 |  |  | 10,000 |  |
| Total operating expenses | 57,236 |  |  | 41,567 |  |  | 108,011 |  |  | 79,134 |  |
| Income from operations | 49,126 |  |  | 42,885 |  |  | 70,566 |  |  | 74,511 |  |
| Interest and other income, net | 24 |  |  | 36 |  |  | 111 |  |  | 71 |  |
| Interest expense | (400 | ) |  | (183 | ) |  | (724 | ) |  | (379 | ) |
| Income before income tax provision | 48,750 |  |  | 42,738 |  |  | 69,953 |  |  | 74,203 |  |
| Income tax provision | 14,061 |  |  | 11,496 |  |  | 21,565 |  |  | 22,098 |  |
| Net income | $ | 34,689 |  |  | $ | 31,242 |  |  | $ | 48,388 |  |  | $ | 52,105 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 1.02 |  |  | $ | 1.14 |  |
| Diluted | $ | 0.67 |  |  | $ | 0.61 |  |  | $ | 0.94 |  |  | $ | 1.03 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 47,651 |  |  | 46,131 |  |  | 47,584 |  |  | 45,802 |  |
| Diluted (b) | 51,489 |  |  | 51,091 |  |  | 51,405 |  |  | 50,567 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 258 |  |  | $ | 222 |  |  | $ | 498 |  |  | $ | 429 |  |
| Research and development | 2,472 |  |  | 1,997 |  |  | 4,874 |  |  | 3,893 |  |
| Sales and marketing | 435 |  |  | 414 |  |  | 839 |  |  | 779 |  |
| General and administrative | 841 |  |  | 548 |  |  | 1,671 |  |  | 1,060 |  |

[0001628280-16-010494:8k_2_02:31]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 48,388 |  |  | $ | 52,105 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 5,953 |  |  | 3,845 |  |
| Stock-based compensation expense | 7,882 |  |  | 6,161 |  |
| Excess tax benefits from stock-based compensation | (355 | ) |  | (2,782 | ) |
| Allowance for doubtful accounts | 805 |  |  | (87 | ) |
| Provision for inventory | 3,780 |  |  | 4,175 |  |
| Exchange gain | (1,539 | ) |  | (1,305 | ) |
| Deferred income taxes, net | (4,380 | ) |  | 121 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 7,613 |  |  | (45,959 | ) |
| Inventory | (26,818 | ) |  | (97,543 | ) |
| Prepaid expenses and other assets | (4,259 | ) |  | 793 |  |
| Accounts payable | 20,738 |  |  | 60,016 |  |
| Income taxes payable, net | 650 |  |  | 5,314 |  |
| Accrued liabilities | 9,715 |  |  | 4,795 |  |
| Other long-term liabilities | 18,749 |  |  | 1,664 |  |
| Net cash provided by (used in) operating activities | 86,922 |  |  | (8,687 | ) |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (15,235 | ) |  | (11,031 | ) |
| Investment in a privately held company | — |  |  | (661 | ) |
| Restricted cash | (404 | ) |  | (1 | ) |
| Net cash used in investing activities | (15,639 | ) |  | (11,693 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 14,400 |  |  | 5,200 |  |
| Repayment of debt | (13,300 | ) |  | (14,400 | ) |
| Proceeds from exercise of stock options | 2,439 |  |  | 12,745 |  |
| Excess tax benefits from stock-based compensation | 355 |  |  | 2,782 |  |
| Payment of obligations under capital leases | (86 | ) |  | (58 | ) |
| Advances (payments) under receivable financing arrangements | (18 | ) |  | 918 |  |
| Minimum tax withholding paid on behalf of employees for restricted stock awards | (504 | ) |  | — |  |
| Net cash provided by financing activities | 3,286 |  |  | 7,187 |  |
| Effect of exchange rate fluctuations on cash | (119 | ) |  | (478 | ) |
| Net increase (decrease) in cash and cash equivalents | 74,450 |  |  | (13,671 | ) |
| Cash and cash equivalents at beginning of period | 95,442 |  |  | 96,872 |  |
| Cash and cash equivalents at end of period | 169,892 |  |  | 83,201 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 693 |  |  | 382 |  |
| Cash paid for taxes, net of refunds | 19,636 |  |  | 15,464 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 127 |  |  | 336 |  |
| Accrued costs for property, plant and equipment purchases | 5,366 |  |  | 7,874 |  |

[0001628280-16-010494:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP GROSS PROFIT | $ | 106,362 |  |  | $ | 84,452 |  |  | $ | 178,577 |  |  | $ | 153,645 |  |
|  | Add back stock-based compensation (a) | 258 |  |  | 222 |  |  | 498 |  |  | 429 |  |
| Non-GAAP GROSS PROFIT | $ | 106,620 |  |  | $ | 84,674 |  |  | $ | 179,075 |  |  | $ | 154,074 |  |
| GAAP GROSS MARGIN | 16.6 | % |  | 16.8 | % |  | 15.4 | % |  | 16.2 | % |
|  | Add back stock-based compensation (a) | 0.1 | % |  | 0.0 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 16.7 | % |  | 16.8 | % |  | 15.5 | % |  | 16.3 | % |
| GAAP INCOME FROM OPERATIONS | $ | 49,126 |  |  | $ | 42,885 |  |  | $ | 70,566 |  |  | $ | 74,511 |  |
|  | Add back stock-based compensation (a) | 4,006 |  |  | 3,181 |  |  | 7,882 |  |  | 6,161 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 53,132 |  |  | $ | 46,066 |  |  | $ | 78,448 |  |  | $ | 80,672 |  |
| GAAP NET INCOME | $ | 34,689 |  |  | $ | 31,242 |  |  | $ | 48,388 |  |  | $ | 52,105 |  |
|  | Add back stock-based compensation (a) | 4,006 |  |  | 3,181 |  |  | 7,882 |  |  | 6,161 |  |
|  | Add back adjustments to tax provision (b) | (704 | ) |  | (919 | ) |  | (1,787 | ) |  | (1,577 | ) |
| Non-GAAP NET INCOME | $ | 37,991 |  |  | $ | 33,504 |  |  | $ | 54,483 |  |  | $ | 56,689 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 1.02 |  |  | $ | 1.14 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.07 |  |  | 0.05 |  |  | 0.12 |  |  | 0.10 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.80 |  |  | $ | 0.73 |  |  | $ | 1.14 |  |  | $ | 1.24 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.67 |  |  | $ | 0.61 |  |  | $ | 0.94 |  |  | $ | 1.03 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.06 |  |  | 0.04 |  |  | 0.10 |  |  | 0.08 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.73 |  |  | $ | 0.65 |  |  | $ | 1.04 |  |  | $ | 1.11 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP | 47,651 |  |  | 46,131 |  |  | 47,584 |  |  | 45,802 |  |
|  | BASIC - Non-GAAP | 47,651 |  |  | 46,131 |  |  | 47,584 |  |  | 45,802 |  |
|  | DILUTED – GAAP | 51,489 |  |  | 51,091 |  |  | 51,405 |  |  | 50,567 |  |
|  | DILUTED - Non-GAAP | 52,113 |  |  | 51,645 |  |  | 52,166 |  |  | 51,131 |  |

[0001628280-16-010494:8k_2_02:33]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three and six months ended December 31, 2015 and 2014.

[0001628280-16-010494:8k_2_02:34]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 28.0% and 30.0% for the three and six months ended December 31, 2015, respectively, and 27.0% and 29.5% for the three and six months ended December 31, 2014, respectively.

[0001628280-16-010494:8k_2_02:35]
SOURCE: Super Micro Computer, Inc.

[0001628280-16-010494:8k_2_02:36]
Super Micro Computer, Inc.

[0001628280-16-010494:8k_2_02:37]
Howard Hideshima, 408-503-8000

[0001628280-16-010494:8k_2_02:38]
SVP, Chief Financial Officer

[0001628280-16-010494:8k_2_02:39]
ir@supermicro.com

[0001628280-16-010494:8k_2_02:40]
or

[0001628280-16-010494:8k_2_02:41]
Perry G. Hayes

[0001628280-16-010494:8k_2_02:42]
SVP, Investor Relations

[0001628280-16-010494:8k_2_02:43]
ir@supermicro.com

[0001628280-16-010494:8k_2_02:44]
SMCI-F
