# SMCI note change history — 0001375365-19-000078 → 0001375365-19-000084


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-12-20):
[0001375365-19-000084:note_history:1]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant.  On July 26, 2019, the Company filed a motion to dismiss the complaint, which motion remains pending with the court.  The Company believes the allegations filed are without merit, and intends to vigorously defend against the lawsuit.

- changed (2019-12-20):
[0001375365-19-000084:note_history:2]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.
  (was, 2019-12-19, similarity 0.6363):
[0001375365-19-000078:note_history:2]
Litigation and Claims— In February 2018, the Company became a party to legal proceedings whereby complainants have alleged that it has violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions. In July 2019, the Company filed a motion to dismiss which remains pending. See Note 12, "Subsequent Events" for further details. From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

- changed (2019-12-20):
[0001375365-19-000084:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2019, these remaining noncancelable commitments were $383.4 million, including $117.8 million for related parties.
  (was, 2019-12-19, similarity 0.848):
[0001375365-19-000078:note_history:3]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2019, these remaining noncancelable commitments were $262.8 million, including $95.6 million for related parties.

- changed (2019-12-20):
[0001375365-19-000084:note_history:4]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the
  (was, 2019-12-19, similarity 0.8326):
[0001375365-19-000078:note_history:4]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.

- added (2019-12-20):
[0001375365-19-000084:note_history:5]
Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.
  (was, 2019-12-19, similarity 0.9476):
[0001375365-19-000078:note_history:6]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee. Prior to July 1, 2018, investments for which the Company was not able to exercise significant influence over the investee were accounted for under the cost method.

- changed (2019-12-20):
[0001375365-19-000084:note_history:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.
  (was, 2019-12-19, similarity 0.7174):
[0001375365-19-000078:note_history:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2019.

- added (2019-12-20):
[0001375365-19-000084:note_history:8]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

- added (2019-12-20):
[0001375365-19-000084:note_history:9]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor

- added (2019-12-20):
[0001375365-19-000084:note_history:10]
obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- added (2019-12-20):
[0001375365-19-000084:note_history:11]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- added (2019-12-20):
[0001375365-19-000084:note_history:12]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- added (2019-12-20):
[0001375365-19-000084:note_history:13]
Contracts with multiple promised goods and services. Certain of the Company’s contracts contain multiple promised goods and services.  Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

- added (2019-12-20):
[0001375365-19-000084:note_history:14]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

- added (2019-12-20):
[0001375365-19-000084:note_history:15]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- added (2019-12-20):
[0001375365-19-000084:note_history:16]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

- changed (2019-12-20):
[0001375365-19-000084:note_history:17]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,
  (was, 2019-12-19, similarity 0.8658):
[0001375365-19-000078:note_history:17]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, under recently adopted guidance, Revenue from Contracts with Customers, (“ASC 606”), these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

- added (2019-12-20):
[0001375365-19-000084:note_history:18]
changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

- changed (2019-12-20):
[0001375365-19-000084:note_history:19]
The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.
  (was, 2019-12-19, similarity 0.9916):
[0001375365-19-000078:note_history:19]
The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the implied and historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

- added (2019-12-20):
[0001375365-19-000084:note_history:20]
Leases

- added (2019-12-20):
[0001375365-19-000084:note_history:21]
Recognition of leases for periods after the Company’s adoption of the new leasing standard as of July 1, 2019

- added (2019-12-20):
[0001375365-19-000084:note_history:22]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company it is classified as a finance lease. All other leases are classified as operating leases.

- added (2019-12-20):
[0001375365-19-000084:note_history:23]
Operating Leases

- added (2019-12-20):
[0001375365-19-000084:note_history:24]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") asset is included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

- added (2019-12-20):
[0001375365-19-000084:note_history:25]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized, at lease commencement, based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments, and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amounts of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.

- added (2019-12-20):
[0001375365-19-000084:note_history:26]
Finance Leases

- added (2019-12-20):
[0001375365-19-000084:note_history:27]
Assets under finance leases are included in property, plant and equipment, net and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

- added (2019-12-20):
[0001375365-19-000084:note_history:28]
Recognition of leases for periods prior to the Company’s adoption of the new leasing standard as of July 1, 2019

- added (2019-12-20):
[0001375365-19-000084:note_history:29]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following is true at inception: (a) the present value of minimum lease payments meets or exceeds 90% of the fair value of the asset, (b) the lease term is greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contains a bargain purchase option, or (d) title to the property transfers to the Company at the end of the lease. The Company records an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets are depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability are accounted for using the effective interest method.

- added (2019-12-20):
[0001375365-19-000084:note_history:30]
Leases that are not classified as capital leases are accounted for as operating leases. Operating lease agreements that have tenant improvement allowances are evaluated for lease incentives. For leases that contain escalating rent payments, the Company recognizes rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

- changed (2019-12-20):
[0001375365-19-000084:note_history:31]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three months ended September 30, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.
  (was, 2019-12-19, similarity 0.9767):
[0001375365-19-000078:note_history:31]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three and nine months ended March 31, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

- changed (2019-12-20):
[0001375365-19-000084:note_history:32]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of September 30, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $2.3 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of gains (losses) of the Corporate Venture were $1.0 million and $(1.4) million for the three months ended September 30, 2019 and 2018, respectively.
  (was, 2019-12-19, similarity 0.6313):
[0001375365-19-000078:note_history:32]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of March 31, 2019 and June 30, 2018, the Company's equity investment in the Corporate Venture was $1.4 million and $2.4 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of losses of the Corporate Venture were $0.4 million and $0.7 million for the three months ended March 31, 2019 and 2018, respectively, and $3.6 million and $2.5 million for the nine months ended March 31, 2019 and 2018, respectively.

- changed (2019-12-20):
[0001375365-19-000084:note_history:33]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of September 30, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2019-12-19, similarity 0.7098):
[0001375365-19-000078:note_history:33]
The Company recorded a deferred gain related to the contribution of certain technology rights of $7.0 million in the third fiscal quarter of 2017. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled.

- changed (2019-12-20):
[0001375365-19-000084:note_history:34]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three months ended September 30, 2019 and 2018, respectively.
  (was, 2019-12-19, similarity 0.9132):
[0001375365-19-000078:note_history:34]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three and nine months ended March 31, 2019 and March 31, 2018, respectively.

- added (2019-12-20):
[0001375365-19-000084:note_history:35]
Additionally, the Company sold products worth $22.1 million and $9.3 million to the Corporate Venture in the three months ended September 30, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.3 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

- changed (2019-12-20):
[0001375365-19-000084:note_history:36]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.7% and 19.7% of total purchases for the three months ended September 30, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 9, "Related Party Transactions," accounted for 9.7% and 9.2% of total cost of sales for the three months ended September 30, 2019 and 2018, respectively.
  (was, 2019-12-19, similarity 0.8662):
[0001375365-19-000078:note_history:36]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 26.9% of total purchases for the three months ended March 31, 2019 and 2018, respectively, and 21.2% and 26.2% for the nine months ended March 31, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 8, "Related Party Transactions," accounted for 9.9% and 8.6% of total cost of sales for the three months ended March 31, 2019 and 2018, respectively, and 9.4% and 9.2% for the nine months ended March 31, 2019 and 2018, respectively.

- added (2019-12-20):
[0001375365-19-000084:note_history:37]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three months ended September 30, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

- added (2019-12-20):
[0001375365-19-000084:note_history:38]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The new lease accounting guidance supersedes the existing guidance. Under the new lease accounting guidance, lessees are required to recognize assets and liabilities on the balance sheet for most leases and provide enhanced disclosures. Leases will continue to be classified as either finance or operating. The Company adopted the new lease accounting guidance on July 1, 2019 using the modified retrospective approach, and as a result did not restate prior comparative periods. The Company elected the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new lease accounting guidance its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease accounting guidance. In connection with the adoption of the new lease accounting guidance, the Company recorded a transition adjustment to recognize ROU assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, on July 1, 2019, primarily related to real estate leases. See Note 8, "Leases," for further details.

- changed (2019-12-20):
[0001375365-19-000084:note_history:39]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The Company adopted this guidance on July 1, 2019. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.
  (was, 2019-12-19, similarity 0.7219):
[0001375365-19-000078:note_history:39]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election and is effective for the Company from July 1, 2019. The adoption of the guidance will not have a material impact on its consolidated financial statements.

- changed (2019-12-20):
[0001375365-19-000084:note_history:40]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The Company adopted this guidance on July 1, 2019. The adoption of the guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.
  (was, 2019-12-19, similarity 0.9011):
[0001375365-19-000078:note_history:40]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The new amendment is effective for the Company from July 1, 2019. The adoption of the new standard will not have a material impact on its consolidated financial statements and related disclosures.

- added (2019-12-20):
[0001375365-19-000084:note_history:41]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an

- changed (2019-12-20):
[0001375365-19-000084:note_history:42]
expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.
  (was, 2019-12-19, similarity 0.7486):
[0001375365-19-000078:note_history:42]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

- removed (2019-12-20):
[0001375365-19-000078:note_history:43]
The Company’s revenue recognition policy and related disclosures are discussed in Note 2, “Revenue.”

- removed (2019-12-20):
[0001375365-19-000078:note_history:44]
As a result of the adoption of new accounting guidance as of the beginning of fiscal year 2019, the Company recorded an increase of $3.0 million to the investment in equity investee for the contribution of those technology rights, and corresponding increases in deferred gain and retained earnings of $2.1 million and $0.9 million, respectively. As of March 31, 2019 and June 30, 2018, the Company had unamortized deferred gain balance of $2.0 million and $1.4 million, respectively, in accrued liabilities and $3.5 million and $3.5 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- removed (2019-12-20):
[0001375365-19-000078:note_history:45]
Additionally, the Company sold products worth $13.7 million and $3.1 million to the Corporate Venture in the three months ended March 31, 2019 and March 31, 2018, respectively, and $35.2 million and $14.5 million in the nine months ended March 31, 2019 and March 31, 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2019 and June 30, 2018 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $11.6 million and $2.9 million due from the Corporate Venture in accounts receivable, net as of March 31, 2019 and June 30, 2018, respectively, in its condensed consolidated balance sheets.

- removed (2019-12-20):
[0001375365-19-000078:note_history:46]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and nine months ended March 31, 2019 and 2018. No country other than the United States accounted for 10% or more of the net sales in the three and nine months ended March 31, 2019. No country other than the United States accounted for 10% or more of the net sales in the three months ended March 31, 2018, whereas the United States and China accounted for 55.4% and 11.4%, respectively, of the net sales in the nine months ended March 31, 2018. One customer accounted for 14.9% of the Company's accounts receivable, net as of March 31, 2019, and one customer accounted for 11.6% of the Company's accounts receivable, net as of June 30, 2018.

- removed (2019-12-20):
[0001375365-19-000078:note_history:47]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance,ASC 606, that supersedes nearly all U.S. GAAP on revenue recognition and eliminates industry-specific guidance. ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Since its issuance, the FASB has issued several amendments to ASC 606. The Company adopted ASC 606 on July 1, 2018 using the modified retrospective method. In connection with the adoption of ASC 606, the Company recorded a transition adjustment to increase retained earnings by $6.8 million as of July 1, 2018. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

- removed (2019-12-20):
[0001375365-19-000078:note_history:48]
The primary impact of the adoption of ASC 606 was the acceleration of revenue recognition for (i) sales to distributors where the Company previously accounted for such sales on a sell-through basis and (ii) software arrangements. The following tables summarize the impacts of the adoption of ASC 606 on the Company’s condensed consolidated financial statements. The adoption of ASC 606 did not have any impact on the net cash provided by operating activities.

- removed (2019-12-20):
[0001375365-19-000078:note_history:49]
Selected Captions from the Condensed Consolidated Balance Sheet as of March 31, 2019 (in thousands)

- removed (2019-12-20):
[0001375365-19-000078:note_history:50]
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| ASSETS |  |  |  |  |  |
| Accounts receivable, net of allowances | $ | 327,366 |  |  | $ | (17,367 | ) |  | $ | 309,999 |  |
| Inventories | 761,113 |  |  | 11,808 |  |  | 772,921 |  |
| Prepaid expenses and other current assets | 97,857 |  |  | (1,916 | ) |  | 95,941 |  |
| Deferred income taxes, net | 33,776 |  |  | 1,558 |  |  | 35,334 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Accrued liabilities | $ | 112,951 |  |  | $ | (4,655 | ) |  | $ | 108,296 |  |
| Deferred revenue | 87,746 |  |  | 653 |  |  | 88,399 |  |
| Income taxes payable | 8,729 |  |  | 71 |  |  | 8,800 |  |
| Deferred revenue, non-current | 105,584 |  |  | 2,783 |  |  | 108,367 |  |
| Retained earnings | 588,193 |  |  | (4,769 | ) |  | 583,424 |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:51]
Selected Captions from the Condensed Consolidated Statement of Operations for the Three and Nine Months ended March 31, 2019 (in thousands)

- removed (2019-12-20):
[0001375365-19-000078:note_history:52]
|  | Three Months Ended March 31, 2019 |  | Nine Months Ended March 31, 2019 |
|  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Net sales | $ | 743,499 |  |  | $ | (1,621 | ) |  | $ | 741,878 |  |  | $ | 2,646,126 |  |  | $ | 18,449 |  |  | $ | 2,664,575 |  |
| Cost of sales | 631,172 |  |  | (403 | ) |  | 630,769 |  |  | 2,282,638 |  |  | 18,995 |  |  | 2,301,633 |  |
| Gross profit | 112,327 |  |  | (1,218 | ) |  | 111,109 |  |  | 363,488 |  |  | (546 | ) |  | 362,942 |  |
| General and administrative | 36,174 |  |  | (1,626 | ) |  | 34,548 |  |  | 106,214 |  |  | (2,662 | ) |  | 103,552 |  |
| Income before income tax provision | 11,502 |  |  | 408 |  |  | 11,910 |  |  | 62,320 |  |  | 2,116 |  |  | 64,436 |  |
| Income tax provision | 497 |  |  | (244 | ) |  | 253 |  |  | 10,540 |  |  | 71 |  |  | 10,611 |  |
| Net income | 10,646 |  |  | 652 |  |  | 11,298 |  |  | 48,208 |  |  | 2,045 |  |  | 50,253 |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:53]
In January 2016, the FASB issued new guidance, Financial Instruments - Overall: Recognition and Measurement of Financial Assets and Financial Liabilities. This guidance changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of equity investments not accounted for under the equity method to be recorded at fair value through the consolidated statement of operations at the end of each reporting period.  The Company adopted this accounting standard update as of July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements. As a result of the adoption of the new standard, the Company’s equity investments are accounted for as follows:

- removed (2019-12-20):
[0001375365-19-000078:note_history:54]
| • | Marketable equity securities that have a readily determinable fair value are measured and recorded at fair value. |

- removed (2019-12-20):
[0001375365-19-000078:note_history:55]
| • | Non-marketable equity securities that do not have a readily determinable fair value and for which the Company does not control the investee nor is it able to exert significant influence over the investee are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. |

- removed (2019-12-20):
[0001375365-19-000078:note_history:56]
| • | Equity method investments are equity securities for which the Company does not control the investee but is able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus the Company's share of equity method investee income or loss. |

- removed (2019-12-20):
[0001375365-19-000078:note_history:57]
In August 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments. This amendment consists of eight provisions that provide guidance on the classification of certain cash receipts and cash payments. If practicable, this amendment should be applied using a retrospective transition method to each period presented. For the provisions that are impracticable to apply retrospectively, those provisions may be applied prospectively as of the earliest date practicable. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated statements of cash flows.

- removed (2019-12-20):
[0001375365-19-000078:note_history:58]
In October 2016, the FASB issued an amendment to the accounting guidance, Intra-Entity Transfers of Assets Other Than Inventory. This amendment simplifies the accounting for income tax consequences of intra-entity transfers of assets other than inventory by requiring recognition of current and deferred income tax consequences when such transfers occur. The Company adopted the accounting guidance on July 1, 2018. The result of the adoption did not have a material impact on the consolidated financial statements and related disclosures.

- removed (2019-12-20):
[0001375365-19-000078:note_history:59]
In November 2016, the FASB issued an amendment to the accounting guidance, Statement of Cash Flows: Restricted Cash. This amendment addresses presentations of total cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. Amounts generally described as restricted cash and restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The Company adopted the accounting guidance on July 1, 2018 using a retrospective transition method to each period presented. The adoption did not have a material impact on the consolidated statements of cash flows. Presentation of prior period information has been retrospectively adjusted.

- removed (2019-12-20):
[0001375365-19-000078:note_history:60]
In February 2017, the FASB issued new accounting guidance, Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets: Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets. This guidance clarifies the scope and application on the sale or transfer of nonfinancial assets and in substance nonfinancial assets to noncustomers, including partial sales. The Company adopted this guidance on July 1, 2018. Prior to adoption, the Company had previously contributed certain technology rights in exchange for 30% ownership in a privately-held company (the “Corporate Venture”) and accounted for the transaction in accordance with the guidance related to exchanges of a nonfinancial asset for a noncontrolling ownership interest in ASC 845 - Nonmonetary Transactions, which has been eliminated by the new guidance. As a result of the adoption of the new guidance, the Company recognized $3.0 million increase in the carrying value of the equity-method investment, a $2.1 million increase in deferred gain, and a $0.9 million increase in retained earnings.

- removed (2019-12-20):
[0001375365-19-000078:note_history:61]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018. The SEC staff subsequently indicated that it would not object if a filer’s first presentation of changes in stockholders’ equity is included in its Form 10-Q for the quarter that begins after the final rule’s effective date. Among the amendments is the requirement to present the changes in stockholders’ equity in the interim financial statements (either in a separate statement or footnote) in Quarterly Reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The Company adopted this guidance in the first quarter of fiscal year 2019.

- removed (2019-12-20):
[0001375365-19-000078:note_history:62]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. Since its issuance, the FASB has issued several amendments to the new lease standard. The standard is effective for the Company from July 1, 2019 and the Company will apply this standard using the modified retrospective approach and will not restate prior comparative periods.  The Company will elect the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new standard its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease guidance. While the Company is currently finalizing its implementation of new policies, processes and internal controls to comply with the new rules, it is anticipated that the adoption of the new standard will result in the recognition of right-of-use assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, as of July 1, 2019, primarily related to real estate leases. The adoption of the new standard will not have a material impact on the Company’s consolidated statement of operations or consolidated statement of cash flows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:63]
Short-term debt obligations as of September 30, 2019 and June 30, 2019 consisted of the following (in thousands):
  (was, 2019-12-19, similarity 0.9505):
[0001375365-19-000078:note_history:63]
Short-term debt obligations as of March 31, 2019 and June 30, 2018 consisted of the following (in thousands):

- changed (2019-12-20):
[0001375365-19-000084:note_history:64]
|  | September 30, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 22,544 |  |  | 22,531 |  |
| Total short-term debt | $ | 22,544 |  |  | $ | 23,647 |  |
  (was, 2019-12-19, similarity 0.6787):
[0001375365-19-000078:note_history:64]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | — |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,660 |  |  | 22,935 |  |
| Total short-term debt | $ | 22,660 |  |  | $ | 116,181 |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:65]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.
  (was, 2019-12-19, similarity 0.983):
[0001375365-19-000078:note_history:65]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the 2016 Bank of America Credit Facility. The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

- changed (2019-12-20):
[0001375365-19-000084:note_history:66]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the
  (was, 2019-12-19, similarity 0.745):
[0001375365-19-000078:note_history:66]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

- added (2019-12-20):
[0001375365-19-000084:note_history:67]
Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

- added (2019-12-20):
[0001375365-19-000084:note_history:68]
As of September 30, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2019 and June 30, 2019 were 4.13% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were immaterial as of September 30, 2019 and June 30, 2019. As of September 30, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2019-12-20):
[0001375365-19-000084:note_history:69]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.5 million at September 30, 2019 and June 30, 2019. The interest rate for these loans were 0.88% per annum as of September 30, 2019 and 0.93% per annum as of June 30, 2019. At September 30, 2019, the amount available for future borrowing under the CTBC Credit Facility was $27.5 million. As of September 30, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.7 million.
  (was, 2019-12-19, similarity 0.6288):
[0001375365-19-000078:note_history:69]
The total outstanding borrowings under the 2018 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.7 million and $22.9 million at March 31, 2019 and June 30, 2018, respectively. At March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 CTBC Credit Facility revolving line of credit were $0.0 million and $25.9 million, respectively, in U.S. dollars. The interest rate for these loans was 0.92% and 0.95% as of March 31, 2019 and June 30, 2018, respectively. At March 31, 2019, the amount available for future borrowing under the 2018 CTBC Credit Facility was $17.3 million. As of March 31, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2018 CTBC Credit Facility term loan was $26.0 million.

- added (2019-12-20):
[0001375365-19-000084:note_history:70]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31,

- added (2019-12-20):
[0001375365-19-000084:note_history:71]
2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

- added (2019-12-20):
[0001375365-19-000084:note_history:72]
On December 19, 2019 the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such the Company has complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

- removed (2019-12-20):
[0001375365-19-000078:note_history:73]
In June 2016, the Company entered into a credit agreement with Bank of America (the “2016 Bank of America Credit Facility”). Prior to its maturity in April 2018, the Company repaid and terminated the 2016 Bank of America Credit Facility using the proceeds from its 2018 Bank of America Credit Facility (defined below). Immediately prior to its termination, the 2016 Bank of America Credit Facility (giving effect to all amendments since the inception of the 2016 Bank of America Credit Facility), provided for (i) a $85.0 million revolving line of credit including a $5.0 million letter of credit sublimit (ii) a $20.0 million revolving line of credit for the Company's Taiwan and the Netherlands entities, and (iii) a five-year $50.0 million term loan. The 2016 Bank of America Credit Facility term loan was secured by seven buildings located in San Jose, California and the property, plant and equipment and the inventory in those buildings. The principal and interest of the 2016 Bank of America Credit Facility term loan were payable monthly through June 30, 2021 with an interest rate at the LIBOR rate plus 1.25% per annum. The interest rate for the $85.0 million revolving line of credit was at the LIBOR rate plus 1.25% per annum. The interest rate of the $20.0 million revolving line of credit was equal to a minimum of 0.9% per annum plus the lender's cost of funds, as defined in the agreements.

- removed (2019-12-20):
[0001375365-19-000078:note_history:74]
As of March 31, 2019 and June 30, 2018, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $0.0 million and $67.3 million, respectively. The interest rates under the 2018 Bank of America Credit Facility as of March 31, 2019 and June 30, 2018 were 5.25% per annum and 4.75% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were $0.7 million and $2.8 million as of March 31, 2019 and June 30, 2018, respectively. As of March 31, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

- removed (2019-12-20):
[0001375365-19-000078:note_history:75]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NTD$700.0 million ($21.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, the term loan facility also included a 12-month guarantee of up to NTD$100.0 million ($3.1 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which was adjusted monthly (collectively, the “2016 CTBC Credit Facility”). The total borrowings allowed under the 2016 CTBC Credit Facility was capped at $40.0 million. The Company extended the 2016 CTBC Credit Facility to mature on May 31, 2017.

- removed (2019-12-20):
[0001375365-19-000078:note_history:76]
In May 2017, the Company renewed the 2016 CTBC Credit Facility, such that it provided for (i) a 12-month NTD $700.0 million ($23.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.3 million U.S. dollar equivalent) with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit of up to 80.0% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.40% to 0.45% per annum which was adjusted monthly. The total borrowings allowed under the renewed 2016 CTBC Credit Facility were capped at $50.0 million. The 2016 CTBC Credit Facility was to mature on April 30, 2018 but prior to the maturity, the Company entered into the 2018 CTBC Credit Facility (defined below) with CTBC Bank in January 2018, which replaced the 2016 CTBC Credit Facility.

- removed (2019-12-20):
[0001375365-19-000078:note_history:77]
2018 Bank of America Credit Facility

- removed (2019-12-20):
[0001375365-19-000078:note_history:78]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company is required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:79]
Short-term debt obligations as of September 30, 2019 and June 30, 2019 consisted of the following (in thousands):
  (was, 2019-12-19, similarity 0.9505):
[0001375365-19-000078:note_history:79]
Short-term debt obligations as of March 31, 2019 and June 30, 2018 consisted of the following (in thousands):

- changed (2019-12-20):
[0001375365-19-000084:note_history:80]
|  | September 30, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 22,544 |  |  | 22,531 |  |
| Total short-term debt | $ | 22,544 |  |  | $ | 23,647 |  |
  (was, 2019-12-19, similarity 0.6787):
[0001375365-19-000078:note_history:80]
|  | March 31, |  | June 30, |
|  | 2019 |  | 2018 |
| Line of credit: |  |  |  |
| Bank of America | $ | — |  |  | $ | 67,346 |  |
| CTBC Bank | — |  |  | 25,900 |  |
| Total line of credit | — |  |  | 93,246 |  |
| Term loan: CTBC Bank | 22,660 |  |  | 22,935 |  |
| Total short-term debt | $ | 22,660 |  |  | $ | 116,181 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:81]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of September 30, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of September 30, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.
  (was, 2019-12-19, similarity 0.7942):
[0001375365-19-000078:note_history:81]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Steve Liang owned approximately 0.4% of the Company's common stock as of June 30, 2017, but owned no shares as of June 30, 2018 and thereafter. As of March 31, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Certain family members of Yih-Shyan (Wally) Liaw, who until January 2018 was the Senior Vice President of International Sales and a director of the Company, owned approximately 11.7% of Ablecom’s capital stock as of March 31, 2019. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of March 31, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

- changed (2019-12-20):
[0001375365-19-000084:note_history:82]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.7% and 95.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2019-12-19, similarity 0.9116):
[0001375365-19-000078:note_history:82]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.0% and 97.6% of the chassis included in the products sold by the Company during the three months ended March 31, 2019 and 2018, respectively; and approximately 95.5% and 97.7% of the chassis included in the products sold by the Company during the nine months ended March 31, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- added (2019-12-20):
[0001375365-19-000084:note_history:83]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such

- changed (2019-12-20):
[0001375365-19-000084:note_history:84]
that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $41.1 million and $31.0 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2019-12-19, similarity 0.856):
[0001375365-19-000078:note_history:84]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $28.3 million and $39.3 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2019-12-20):
[0001375365-19-000084:note_history:85]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $76.7 million and $70.6 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2019-12-19, similarity 0.6378):
[0001375365-19-000078:note_history:85]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $67.3 million and $111.7 million at March 31, 2019 and June 30, 2018, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2019-12-20):
[0001375365-19-000084:note_history:86]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2019 and 2018, are as follows (in thousands):
  (was, 2019-12-19, similarity 0.9385):
[0001375365-19-000078:note_history:86]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2019, and 2018, are as follows (in thousands):

- changed (2019-12-20):
[0001375365-19-000084:note_history:87]
|  | Three months ended September, 30 |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Purchases (1) | $ | 33,120 |  |  | $ | 44,636 |  |
| Compuware |  |  |  |
| Net sales | $ | 5,547 |  |  | $ | 5,142 |  |
| Purchases (1) | 33,316 |  |  | 37,212 |  |
  (was, 2019-12-19, similarity 0.7202):
[0001375365-19-000078:note_history:87]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 29,372 |  |  | $ | 37,405 |  |  | $ | 110,290 |  |  | $ | 107,644 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,846 |  |  | $ | 14,528 |  |  | $ | 13,628 |  |  | $ | 31,645 |  |
| Purchases (1) | 34,140 |  |  | 27,969 |  |  | 111,629 |  |  | 91,925 |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:88]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9064):
[0001375365-19-000078:note_history:88]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2019 and 2018.

- changed (2019-12-20):
[0001375365-19-000084:note_history:89]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2019 and June 30, 2019 (in thousands):
  (was, 2019-12-19, similarity 0.9632):
[0001375365-19-000078:note_history:89]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2019 and June 30, 2018 (in thousands):

- added (2019-12-20):
[0001375365-19-000084:note_history:90]
|  | September 30, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 8,383 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 36,417 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,374 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 19,117 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 41,048 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 398 |  |  | — |  |

- added (2019-12-20):
[0001375365-19-000084:note_history:91]
____________________________

- added (2019-12-20):
[0001375365-19-000084:note_history:92]
(1) Includes current portion of operating lease liabilities.

- added (2019-12-20):
[0001375365-19-000084:note_history:93]
(2) Represents non-current portion of operating lease liabilities.

- changed (2019-12-20):
[0001375365-19-000084:note_history:94]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three months ended September 30, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9417):
[0001375365-19-000078:note_history:94]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three and nine months ended March 31, 2019 and 2018.

- removed (2019-12-20):
[0001375365-19-000078:note_history:95]
|  | March 31, 2019 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,950 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 26,925 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 8,588 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 33,109 |  |  | 45,617 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:96]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2019 and 2018, are as follows (in thousands):
  (was, 2019-12-19, similarity 0.9385):
[0001375365-19-000078:note_history:96]
The Company’s results from transactions with Ablecom and Compuware for each of the three and nine months ended March 31, 2019, and 2018, are as follows (in thousands):

- changed (2019-12-20):
[0001375365-19-000084:note_history:97]
|  | Three months ended September, 30 |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Purchases (1) | $ | 33,120 |  |  | $ | 44,636 |  |
| Compuware |  |  |  |
| Net sales | $ | 5,547 |  |  | $ | 5,142 |  |
| Purchases (1) | 33,316 |  |  | 37,212 |  |
  (was, 2019-12-19, similarity 0.7202):
[0001375365-19-000078:note_history:97]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 29,372 |  |  | $ | 37,405 |  |  | $ | 110,290 |  |  | $ | 107,644 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 3,846 |  |  | $ | 14,528 |  |  | $ | 13,628 |  |  | $ | 31,645 |  |
| Purchases (1) | 34,140 |  |  | 27,969 |  |  | 111,629 |  |  | 91,925 |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:98]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2019 and 2018.
  (was, 2019-12-19, similarity 0.9064):
[0001375365-19-000078:note_history:98]
The Company's net sales to Ablecom were not material for the three and nine months ended March 31, 2019 and 2018.

- changed (2019-12-20):
[0001375365-19-000084:note_history:99]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2019 and June 30, 2019 (in thousands):
  (was, 2019-12-19, similarity 0.9632):
[0001375365-19-000078:note_history:99]
The Company had the following balances related to transactions with Ablecom and Compuware as of March 31, 2019 and June 30, 2018 (in thousands):

- added (2019-12-20):
[0001375365-19-000084:note_history:100]
|  | September 30, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 8,383 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 36,417 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,374 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 19,117 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 41,048 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 398 |  |  | — |  |

- added (2019-12-20):
[0001375365-19-000084:note_history:101]
____________________________

- added (2019-12-20):
[0001375365-19-000084:note_history:102]
(1) Includes current portion of operating lease liabilities.

- added (2019-12-20):
[0001375365-19-000084:note_history:103]
(2) Represents non-current portion of operating lease liabilities.

- removed (2019-12-20):
[0001375365-19-000078:note_history:104]
|  | March 31, 2019 |  | June 30, 2018 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 5,950 |  |  | $ | 7,884 |  |
| Accounts payable and accrued liabilities | 26,925 |  |  | 49,187 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 8,588 |  |  | $ | 16,295 |  |
| Accounts payable and accrued liabilities | 33,109 |  |  | 45,617 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:105]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 636,026 |  |  | 79.5 | % |  | $ | 808,027 |  |  | 83.2 | % |
| Subsystems and accessories | 163,778 |  |  | 20.5 | % |  | 163,091 |  |  | 16.8 | % |
| Total | $ | 799,804 |  |  | 100.0 | % |  | $ | 971,118 |  |  | 100.0 | % |
  (was, 2019-12-19, similarity 0.6605):
[0001375365-19-000078:note_history:105]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 592,783 |  |  | 79.7 | % |  | $ | 669,114 |  |  | 80.1 | % |  | $ | 2,161,321 |  |  | 81.7 | % |  | $ | 1,841,218 |  |  | 77.4 | % |
| Subsystems and accessories | 150,716 |  |  | 20.3 | % |  | 165,996 |  |  | 19.9 | % |  | 484,805 |  |  | 18.3 | % |  | 537,612 |  |  | 22.6 | % |
| Total | $ | 743,499 |  |  | 100.0 | % |  | $ | 835,110 |  |  | 100.0 | % |  | $ | 2,646,126 |  |  | 100.0 | % |  | $ | 2,378,830 |  |  | 100.0 | % |

- changed (2019-12-20):
[0001375365-19-000084:note_history:106]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.
  (was, 2019-12-19, similarity 0.7398):
[0001375365-19-000078:note_history:106]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

- added (2019-12-20):
[0001375365-19-000084:note_history:107]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

- changed (2019-12-20):
[0001375365-19-000084:note_history:108]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-19, similarity 0.8894):
[0001375365-19-000078:note_history:108]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2019 and 2018, of net sales by geographic region (in thousands):

- added (2019-12-20):
[0001375365-19-000084:note_history:109]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| United States | $ | 468,841 |  |  | $ | 567,615 |  |
| Europe | 128,059 |  |  | 162,560 |  |
| Asia | 161,639 |  |  | 206,868 |  |
| Others | 41,265 |  |  | 34,075 |  |
|  | $ | 799,804 |  |  | $ | 971,118 |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:110]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three months ended September 30, 2019 and 2018:
  (was, 2019-12-19, similarity 0.8825):
[0001375365-19-000078:note_history:110]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:

- added (2019-12-20):
[0001375365-19-000084:note_history:111]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:112]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 436,734 |  |  | $ | 455,021 |  |  | $ | 1,516,262 |  |  | $ | 1,317,175 |  |
| Europe | 128,789 |  |  | 150,319 |  |  | 472,325 |  |  | 392,797 |  |
| Asia | 146,120 |  |  | 188,101 |  |  | 549,296 |  |  | 561,807 |  |
| Others | 31,856 |  |  | 41,669 |  |  | 108,243 |  |  | 107,051 |  |
|  | $ | 743,499 |  |  | $ | 835,110 |  |  | $ | 2,646,126 |  |  | $ | 2,378,830 |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 over 2018 |  | 2019 |  | 2018 |  | 2019 over 2018 |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-12-20):
[0001375365-19-000084:note_history:114]
Revenue Recognition

- changed (2019-12-20):
[0001375365-19-000084:note_history:115]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor
  (was, 2019-12-19, similarity 0.8185):
[0001375365-19-000078:note_history:115]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- added (2019-12-20):
[0001375365-19-000084:note_history:116]
obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2019-12-20):
[0001375365-19-000078:note_history:117]
Revenue recognition for periods after the Company’s adoption of ASC 606 as of July 1, 2018

- removed (2019-12-20):
[0001375365-19-000078:note_history:118]
The Company adopted ASC 606 as of July 1, 2018 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, the Company considered the effect of all modifications when identifying performance obligations and allocating transaction price, which did not have a material effect on the adjustment to retained earnings. The Company recognized the cumulative effect of initially applying ASC 606 as an adjustment to the opening balance of retained earnings. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

- removed (2019-12-20):
[0001375365-19-000078:note_history:119]
ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of the promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.

- removed (2019-12-20):
[0001375365-19-000078:note_history:120]
Revenue recognition for periods prior to the Company’s adoption of ASC 606 as of July 1, 2018

- removed (2019-12-20):
[0001375365-19-000078:note_history:121]
Product sales. The Company recognizes revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of its  products to customers, unless customer acceptance  is uncertain or significant obligations to the  customer remain: (i) persuasive evidence of an arrangement exists through   customer contracts and  orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

- removed (2019-12-20):
[0001375365-19-000078:note_history:122]
The Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. The Company also reduces revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

- removed (2019-12-20):
[0001375365-19-000078:note_history:123]
The Company may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement between the Company and the distributor.

- removed (2019-12-20):
[0001375365-19-000078:note_history:124]
The Company records costs related to shipping and handling in sales and marketing expenses. Shipping and handling fees billed to customers are included in net sales.

- removed (2019-12-20):
[0001375365-19-000078:note_history:125]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- removed (2019-12-20):
[0001375365-19-000078:note_history:126]
Multiple-element arrangements. Certain of the Company’s arrangements contain multiple elements, consisting of   both the Company’s products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

- removed (2019-12-20):
[0001375365-19-000078:note_history:127]
The Company allocates arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of     selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available.

- removed (2019-12-20):
[0001375365-19-000078:note_history:128]
The Company does not have VSOE for deliverables in its arrangements, and TPE is generally not available because its products are highly differentiated, and the Company is unable to obtain reliable information on the products and pricing practices of the Company’s competitors. BESP reflects the Company’s estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

- removed (2019-12-20):
[0001375365-19-000078:note_history:129]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. The Company determines BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.

- removed (2019-12-20):
[0001375365-19-000078:note_history:130]
Disaggregation of Revenue

- removed (2019-12-20):
[0001375365-19-000078:note_history:131]
The Company disaggregates revenue by type of product, by geographical market, and by products sold to indirect sales channel partners or direct customers and original equipment manufacturers ("OEMs") that depict the nature, amount, and timing of revenue and cash flows. Service revenues are not a significant component of total revenue and are aggregated within the respective categories.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-12-20):
[0001375365-19-000084:note_history:132]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 636,026 |  |  | 79.5 | % |  | $ | 808,027 |  |  | 83.2 | % |
| Subsystems and accessories | 163,778 |  |  | 20.5 | % |  | 163,091 |  |  | 16.8 | % |
| Total | $ | 799,804 |  |  | 100.0 | % |  | $ | 971,118 |  |  | 100.0 | % |
  (was, 2019-12-19, similarity 0.6605):
[0001375365-19-000078:note_history:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 592,783 |  |  | 79.7 | % |  | $ | 669,114 |  |  | 80.1 | % |  | $ | 2,161,321 |  |  | 81.7 | % |  | $ | 1,841,218 |  |  | 77.4 | % |
| Subsystems and accessories | 150,716 |  |  | 20.3 | % |  | 165,996 |  |  | 19.9 | % |  | 484,805 |  |  | 18.3 | % |  | 537,612 |  |  | 22.6 | % |
| Total | $ | 743,499 |  |  | 100.0 | % |  | $ | 835,110 |  |  | 100.0 | % |  | $ | 2,646,126 |  |  | 100.0 | % |  | $ | 2,378,830 |  |  | 100.0 | % |

- changed (2019-12-20):
[0001375365-19-000084:note_history:133]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.
  (was, 2019-12-19, similarity 0.7398):
[0001375365-19-000078:note_history:133]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services. Subsystems and accessories are comprised of serverboards, chassis and accessories.

- added (2019-12-20):
[0001375365-19-000084:note_history:134]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

- changed (2019-12-20):
[0001375365-19-000084:note_history:135]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2019 and 2018, of net sales by geographic region (in thousands):
  (was, 2019-12-19, similarity 0.8894):
[0001375365-19-000078:note_history:135]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2019 and 2018, of net sales by geographic region (in thousands):

- added (2019-12-20):
[0001375365-19-000084:note_history:136]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| United States | $ | 468,841 |  |  | $ | 567,615 |  |
| Europe | 128,059 |  |  | 162,560 |  |
| Asia | 161,639 |  |  | 206,868 |  |
| Others | 41,265 |  |  | 34,075 |  |
|  | $ | 799,804 |  |  | $ | 971,118 |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:137]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three months ended September 30, 2019 and 2018:
  (was, 2019-12-19, similarity 0.8825):
[0001375365-19-000078:note_history:137]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three and nine months ended March 31, 2019 and 2018:

- added (2019-12-20):
[0001375365-19-000084:note_history:138]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

- changed (2019-12-20):
[0001375365-19-000084:note_history:139]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On June 30, 2019, deferred revenue totaled $203.4 million, of which $25.5 million was recognized as revenue during the three months ended September 30, 2019.
  (was, 2019-12-19, similarity 0.8339):
[0001375365-19-000078:note_history:139]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On July 1, 2018, deferred revenue totaled $143.5 million after recognizing the cumulative effect of initially applying ASC 606. Of that amount, $14.1 million and $39.8 million was recognized as revenue during the three and nine months ended March 31, 2019, respectively.

- added (2019-12-20):
[0001375365-19-000084:note_history:140]
Deferred revenue decreased during the three months ended September 30, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.

- changed (2019-12-20):
[0001375365-19-000084:note_history:141]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2019 was approximately $201.9 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2019-12-19, similarity 0.9923):
[0001375365-19-000078:note_history:141]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2019 was approximately $193.3 million. The Company expects to recognize approximately 45% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2019-12-20):
[0001375365-19-000078:note_history:142]
Revenue recognition for periods after the Company’s adoption of ASC 606 as of July 1, 2018

- removed (2019-12-20):
[0001375365-19-000078:note_history:143]
The Company adopted ASC 606 as of July 1, 2018 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, the Company considered the effect of all modifications when identifying performance obligations and allocating transaction price, which did not have a material effect on the adjustment to retained earnings. The Company recognized the cumulative effect of initially applying ASC 606 as an adjustment to the opening balance of retained earnings. The comparative information has not been recast and continues to be reported under the accounting standards in effect for those periods.

- removed (2019-12-20):
[0001375365-19-000078:note_history:144]
ASC 606 provides a unified model in determining when and how revenue is recognized with the core principle that revenue should be recognized when a customer obtains control of the promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.

- removed (2019-12-20):
[0001375365-19-000078:note_history:145]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

- removed (2019-12-20):
[0001375365-19-000078:note_history:146]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

- removed (2019-12-20):
[0001375365-19-000078:note_history:147]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

- removed (2019-12-20):
[0001375365-19-000078:note_history:148]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- removed (2019-12-20):
[0001375365-19-000078:note_history:149]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services.  Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

- removed (2019-12-20):
[0001375365-19-000078:note_history:150]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

- removed (2019-12-20):
[0001375365-19-000078:note_history:151]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- removed (2019-12-20):
[0001375365-19-000078:note_history:152]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

- removed (2019-12-20):
[0001375365-19-000078:note_history:153]
Revenue recognition for periods prior to the Company’s adoption of ASC 606 as of July 1, 2018

- removed (2019-12-20):
[0001375365-19-000078:note_history:154]
Product sales. The Company recognizes revenue from sales of products upon meeting all of the following revenue recognition criteria, which is typically met upon shipment or delivery of its  products to customers, unless customer acceptance  is uncertain or significant obligations to the  customer remain: (i) persuasive evidence of an arrangement exists through   customer contracts and  orders, (ii) the customer takes title and assumes the risks and rewards of ownership, (iii) the sales price charged is fixed or determinable as evidenced by customer contracts and orders and (iv) collectibility is reasonably assured.

- removed (2019-12-20):
[0001375365-19-000078:note_history:155]
The Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. The Company also reduces revenue for customer and distributor programs and incentive offerings such as price protection and rebates as well as cooperative marketing arrangements where the fair value of the benefit identified from the costs cannot be reasonably estimated.

- removed (2019-12-20):
[0001375365-19-000078:note_history:156]
The Company may use distributors to sell products to end customers. Revenue from distributors may be recognized on sell-in or sell-through basis depending on the terms of the arrangement between the Company and the distributor.

- removed (2019-12-20):
[0001375365-19-000078:note_history:157]
The Company records costs related to shipping and handling in sales and marketing expenses. Shipping and handling fees billed to customers are included in net sales.

- removed (2019-12-20):
[0001375365-19-000078:note_history:158]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. These services are sold at the time of the sale of the underlying products. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period. These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

- removed (2019-12-20):
[0001375365-19-000078:note_history:159]
Multiple-element arrangements. Certain of the Company’s arrangements contain multiple elements, consisting of   both the Company’s products and services. Revenue allocated to each element is recognized when all the revenue recognition criteria are met for that element.

- removed (2019-12-20):
[0001375365-19-000078:note_history:160]
The Company allocates arrangement consideration at the inception of an arrangement to all deliverables, if they represent a separate unit of accounting, based on their relative estimated stand-alone selling prices. A deliverable qualifies as a separate unit of accounting when the delivered element has stand-alone value to the customer. The guidance establishes the following hierarchy to determine the relative estimated stand-alone selling price to be used for allocating arrangement consideration to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of     selling price (“TPE”) if VSOE is not available, or (iii) the vendor's best estimated selling price (“BESP”) if neither VSOE nor TPE are available.

- removed (2019-12-20):
[0001375365-19-000078:note_history:161]
The Company does not have VSOE for deliverables in its arrangements, and TPE is generally not available because its products are highly differentiated, and the Company is unable to obtain reliable information on the products and pricing practices of the Company’s competitors. BESP reflects the Company’s estimate of what the selling price of a deliverable would be if it were sold regularly on a stand-alone basis.

- removed (2019-12-20):
[0001375365-19-000078:note_history:162]
As such, BESP is generally used to allocate the total arrangement consideration at the arrangement inception. The Company determines BESP for a product by considering multiple factors including, but not limited to, geographies, customer types, internal costs, gross margin objectives and pricing practices.

- removed (2019-12-20):
[0001375365-19-000078:note_history:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 436,734 |  |  | $ | 455,021 |  |  | $ | 1,516,262 |  |  | $ | 1,317,175 |  |
| Europe | 128,789 |  |  | 150,319 |  |  | 472,325 |  |  | 392,797 |  |
| Asia | 146,120 |  |  | 188,101 |  |  | 549,296 |  |  | 561,807 |  |
| Others | 31,856 |  |  | 41,669 |  |  | 108,243 |  |  | 107,051 |  |
|  | $ | 743,499 |  |  | $ | 835,110 |  |  | $ | 2,646,126 |  |  | $ | 2,378,830 |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:164]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 over 2018 |  | 2019 |  | 2018 |  | 2019 over 2018 |
| Indirect sales channel | 38.2 | % |  | 42.8 | % |  | (4.6 | )% |  | 37.7 | % |  | 43.7 | % |  | (6.0 | )% |
| Direct customers and OEMs | 61.8 | % |  | 57.2 | % |  | 4.6 | % |  | 62.3 | % |  | 56.3 | % |  | 6.0 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

- removed (2019-12-20):
[0001375365-19-000078:note_history:165]
Deferred revenue increased during the nine months ended March 31, 2019 because the amounts for service contracts invoiced during the period exceeded the recognition of revenue from contracts entered into in prior periods.

- removed (2019-12-20):
[0001375365-19-000078:note_history:166]
Capitalized Contract Acquisition Costs and Fulfillment Cost

- removed (2019-12-20):
[0001375365-19-000078:note_history:167]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company allocates the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Such contract acquisition costs that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

- removed (2019-12-20):
[0001375365-19-000078:note_history:168]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- removed (2019-12-20):
[0001375365-19-000078:note_history:169]
On February 8, 2018, two putative class action complaints were filed against us, our Chief Executive Officer, and our former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff and it filed an amended complaint naming our Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, plaintiff filed a further amended complaint naming our former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, we filed a motion to dismiss which remains pending. We believe the allegations filed are without merit and intend to vigorously defend against the lawsuit.
