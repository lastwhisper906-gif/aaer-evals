# SMCI MD&A — 0001375365-19-000084


## mdna

[0001375365-19-000084:mdna:1]
[same as prior period, unchanged from 0001375365-19-000078:mdna:1]

[0001375365-19-000084:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Q1 2020 Quarterly Report and included in our 2019 Comprehensive 10-K, which includes our consolidated financial statements for the fiscal years ended June 30, 2019 and 2018.

[0001375365-19-000084:mdna:3]
[same as prior period, unchanged from 0001375365-19-000078:mdna:3]

[0001375365-19-000084:mdna:4]
[same as prior period, unchanged from 0001375365-19-000078:mdna:4]

[0001375365-19-000084:mdna:5]
[same as prior period, unchanged from 0001375365-19-000078:mdna:5]

[0001375365-19-000084:mdna:6]
[same as prior period, unchanged from 0001375365-19-000078:mdna:6]

[0001375365-19-000084:mdna:7]
We commenced operations in 1993 and have been profitable every year since inception. Although our net sales for the three months ended September 30, 2019 declined from our net sales for the corresponding period in the prior year, we seek

[0001375365-19-000084:mdna:8]
to increase our sales and profits every quarter. We believe that to do so, we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, Advanced Micro Devices, Inc., Nvidia Corporation, Samsung Electronics Company Limited, Micron Technology, Inc. and others carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-19-000084:mdna:9]
For the three months ended September 30, 2019, our industry continued to experience a softening of customer demand. While we saw a lower volume of products purchased by our customers, we saw a more profitable mix of products sold. In addition, the prices we charged our customers and the prices that our suppliers charged us for key components both declined. The prices we charged our customers on average declined at a slower rate than the drop-in prices we paid for the components we purchased. Therefore, despite the decline in net sales, our gross margin increased. As a result, net income and earnings per share increased as compared to the comparable period in the prior fiscal year.

[0001375365-19-000084:mdna:10]
[same as prior period, unchanged from 0001375365-19-000078:mdna:9]

[0001375365-19-000084:mdna:11]
The following is a summary of our financial highlights of the first quarter of fiscal year 2020:

[0001375365-19-000084:mdna:12]
| • | Net sales decreased by 17.6% as compared to the three months ended September 30, 2018. The decrease was mainly due to a decline in the volume of server and storage sales, decline in average selling prices per compute node and decline in sales in Asia and Europe. |

[0001375365-19-000084:mdna:13]
| • | Gross margin increased to 16.4% in the three months ended September 30, 2019 from 12.7% for the three months ended September 30, 2018, primarily due to a favorable geographic, customer and product mix and lower costs for key components. |

[0001375365-19-000084:mdna:14]
| • | Operating expenses increased by 3.5% as compared to the three months ended September 30, 2018, and were equal to 12.3% and 9.8% of net sales in the three months ended September 30, 2019 and 2018, respectively. |

[0001375365-19-000084:mdna:15]
| • | Effective tax rate increased from 21.0% in the three months ended September 30, 2018 to 25.3% in the three months ended September 30, 2019. |

[0001375365-19-000084:mdna:16]
[same as prior period, unchanged from 0001375365-19-000078:mdna:17]

[0001375365-19-000084:mdna:17]
[same as prior period, unchanged from 0001375365-19-000078:mdna:18]

[0001375365-19-000084:mdna:18]
[same as prior period, unchanged from 0001375365-19-000078:mdna:19]

[0001375365-19-000084:mdna:19]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During the first quarter of fiscal year 2020 and during fiscal year 2019, we continued to expand manufacturing and service operations in Taiwan and the Netherlands primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware represented 9.7% and 9.2% of our cost of sales for the three months ended September 30, 2019 and 2018, respectively. For further details on our dealings with related parties, see Part I, Item 1, Note 9, “Related Party Transactions.”

[0001375365-19-000084:mdna:20]
[same as prior period, unchanged from 0001375365-19-000078:mdna:22]

[0001375365-19-000084:mdna:21]
[same as prior period, unchanged from 0001375365-19-000078:mdna:23]

[0001375365-19-000084:mdna:22]
[same as prior period, unchanged from 0001375365-19-000078:mdna:24]

[0001375365-19-000084:mdna:23]
[same as prior period, unchanged from 0001375365-19-000078:mdna:25]

[0001375365-19-000084:mdna:24]
[same as prior period, unchanged from 0001375365-19-000078:mdna:26]

[0001375365-19-000084:mdna:25]
[same as prior period, unchanged from 0001375365-19-000078:mdna:27]

[0001375365-19-000084:mdna:26]
[same as prior period, unchanged from 0001375365-19-000078:mdna:28]

[0001375365-19-000084:mdna:27]
[same as prior period, unchanged from 0001375365-19-000078:mdna:29]

[0001375365-19-000084:mdna:28]
Except for the changes to our accounting policy as a result of the adoption of the new lease accounting guidance on July 1, 2019, there have been no material change to our critical accounting policies and estimates as compared to those disclosed in our 2019 Comprehensive 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Organization and Summary of Significant Accounting Policies" in our notes to the condensed consolidated financial statements in this Q1 2020 Quarterly Report.

[0001375365-19-000084:mdna:29]
[same as prior period, unchanged from 0001375365-19-000078:mdna:31]

[0001375365-19-000084:mdna:30]
[same as prior period, unchanged from 0001375365-19-000078:mdna:32]

[0001375365-19-000084:mdna:31]
The following table presents net sales by product type for the three months ended September 30, 2019 and 2018 (dollars in millions):

[0001375365-19-000084:mdna:32]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |
| Server and storage systems | $ | 636.0 |  |  | $ | 808.0 |  |  | $ | (172.0 | ) |  | (21.3 | )% |
| Percentage of total net sales | 79.5 | % |  | 83.2 | % |  |  |  |  |
| Subsystems and accessories | $ | 163.8 |  |  | $ | 163.1 |  |  | $ | 0.7 |  |  | 0.4 | % |
| Percentage of total net sales | 20.5 | % |  | 16.8 | % |  |  |  |  |
| Total net sales | $ | 799.8 |  |  | $ | 971.1 |  |  | $ | (171.3 | ) |  | (17.6 | )% |

[0001375365-19-000084:mdna:33]
The period-over-period decrease in net sales of our server and storage systems was primarily due to a decrease in average selling price per compute node by approximately 14% and due to a decrease of approximately 11% in the number of units of compute nodes shipped due to the continued softening of customer demand. The decline in average selling prices was primarily due to substantially lower costs for key components, specifically for memory and storage.

[0001375365-19-000084:mdna:34]
The following table presents the percentages of net sales from products sold through our indirect sales channel and to our direct customers and OEMs customers for the three months ended September 30, 2019 and 2018:

[0001375365-19-000084:mdna:35]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000084:mdna:36]
The period-over-period increase in net sales through our indirect sales channel as a percentage of total net sales was primarily due to a decrease in sales to direct customers and OEMs. The period-over-period decrease in net sales to our direct customers and OEMs as a percentage of total net sales was primarily due lower sales to larger internet data center and cloud and enterprise customers, as well as lower average selling prices per compute node.

[0001375365-19-000084:mdna:37]
The following table presents percentages of net sales by geographic region for the three months ended September 30, 2019 and 2018:

[0001375365-19-000084:mdna:38]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| United States | 58.6 | % |  | 58.5 | % |  | 0.1 | % |
| Europe | 16.0 | % |  | 16.7 | % |  | (0.7 | )% |
| Asia | 20.2 | % |  | 21.3 | % |  | (1.1 | )% |
| Others | 5.2 | % |  | 3.5 | % |  | 1.7 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000084:mdna:39]
Net sales in the United States as a percentage of total net sales were primarily flat and continued to be weighted toward sales of our server and storage systems to our direct customers and OEMs. The period-over-period decrease in net sales in Asia as a percentage of total net sales was due primarily to decreased sales in China, Japan, and Korea, partially offset by increased sales in Taiwan. The decreased percentage of net sales in Europe was primarily due to lower sales in the United Kingdom, Germany, and the Netherlands, partially offset by increased sales in Russia. The period-over-period increase in net sales in other countries as a percentage of total net sales was due to stronger sales in South America, primarily Brazil and Mexico.

[0001375365-19-000084:mdna:40]
[same as prior period, unchanged from 0001375365-19-000078:mdna:48]

[0001375365-19-000084:mdna:41]
Cost of sales and gross margin for the three months ended September 30, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000084:mdna:42]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |
| Cost of sales | $ | 668.9 |  |  | $ | 847.9 |  |  | $ | (179.0 | ) |  | (21.1 | )% |
| Gross profit | $ | 130.9 |  |  | $ | 123.2 |  |  | $ | 7.7 |  |  | 6.3 | % |
| Gross margin | 16.4 | % |  | 12.7 | % |  |  |  | 3.7 | % |

[0001375365-19-000084:mdna:43]
The period-over-period decrease in cost of sales was primarily attributable to a decrease of $181.9 million in product costs related to the decrease in net sales volume. In addition, product costs for key components, specifically for memory and storage, declined substantially period-over-period as shortages in supply chain for key components, which adversely affected the prices we paid in the previous fiscal year, shifted to over-supply in the second half of fiscal year 2019 and in the three months ended September 30, 2019.

[0001375365-19-000084:mdna:44]
The period-over-period increase in the gross margin percentage was primarily due to lower costs for key components. The prices we charged our customers on average declined at a slower rate than the drop-in prices we paid for the components we purchased. Therefore, despite the decline in net sales, our gross margin increased. In addition, in the three months ended September 30, 2019, as compared with three months ended September 30, 2018, we had a lower percentage of net sales in Asia where pricing is typically more competitive, which had a positive impact on our gross margin percentage.

[0001375365-19-000084:mdna:45]
[same as prior period, unchanged from 0001375365-19-000078:mdna:57]

[0001375365-19-000084:mdna:46]
Operating expenses for the three months ended September 30, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000084:mdna:47]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |
| Research and development | $ | 49.6 |  |  | $ | 43.0 |  |  | $ | 6.6 |  |  | 15.3 | % |
| Percentage of total net sales | 6.2 | % |  | 4.4 | % |  |  |  |  |
| Sales and marketing | $ | 20.2 |  |  | $ | 18.3 |  |  | $ | 1.9 |  |  | 10.4 | % |
| Percentage of total net sales | 2.5 | % |  | 1.9 | % |  |  |  |  |
| General and administrative | $ | 28.3 |  |  | $ | 33.4 |  |  | $ | (5.1 | ) |  | (15.3 | )% |
| Percentage of total net sales | 3.6 | % |  | 3.5 | % |  |  |  |  |
| Total operating expenses | $ | 98.1 |  |  | $ | 94.7 |  |  | $ | 3.4 |  |  | 3.6 | % |
| Percentage of total net sales | 12.3 | % |  | 9.8 | % |  |  |  |  |

[0001375365-19-000084:mdna:48]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $1.6 million in product development costs and an increase of $4.3 million in personnel expenses as a result of an increase in the number of personnel.

[0001375365-19-000084:mdna:49]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to an increase of $1.1 million in expenses related to advertising and promotion activities.

[0001375365-19-000084:mdna:50]
General and administrative expenses. The period-over-period decrease in general and administrative expenses includes a decrease of $7.1 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, offset by an increase of $1.3 million in personnel expenses as a result of an increase in the number of personnel.

[0001375365-19-000084:mdna:51]
Interest and Other Income (Expense), Net

[0001375365-19-000084:mdna:52]
Other income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-19-000084:mdna:53]
[same as prior period, unchanged from 0001375365-19-000078:mdna:71]

[0001375365-19-000084:mdna:54]
Interest and other income (expense), net for the three months ended September 30, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000084:mdna:55]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |
| Other income, net | $ | 1.6 |  |  | $ | 0.2 |  |  | $ | 1.4 |  |  | 700.0 | % |
| Interest expense | (0.6 | ) |  | (2.4 | ) |  | 1.8 |  |  | (75.0 | )% |
| Interest and other income (expense), net | $ | 1.0 |  |  | $ | (2.2 | ) |  | $ | 3.2 |  |  | (145.5 | )% |

[0001375365-19-000084:mdna:56]
The period-over-period change in interest and other income (expense), net was due to a decrease of $1.8 million in interest expense primarily as a result of lower amount of outstanding debt during the three months ended September 30, 2019 as compared to three months ended September 30, 2018, which was due to repayments of our borrowings, and an increase of $1.4 million in other income, net attributable to an increase in interest income on our interest bearing deposits and foreign exchange gain due to favorable foreign currency fluctuations.

[0001375365-19-000084:mdna:57]
[same as prior period, unchanged from 0001375365-19-000078:mdna:78]

[0001375365-19-000084:mdna:58]
Provision for income taxes and effective tax rates for the three months ended September 30, 2019 and 2018 are as follows (dollars in millions):

[0001375365-19-000084:mdna:59]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | $ |  | % |
| Income tax provision | $ | 8.6 |  |  | $ | 5.5 |  |  | $ | 3.1 |  |  | 56.4 | % |
| Percentage of total net sales | 1.1 | % |  | 0.6 | % |  |  |  |  |
| Effective tax rate | 25.3 | % |  | 21.0 | % |  |  |  |  |

[0001375365-19-000084:mdna:60]
The period-over-period increase in income tax provision and effective tax rate was primarily due to an increase in unrecognized tax benefits for the three months ended September 30, 2019.

[0001375365-19-000084:mdna:61]
[same as prior period, unchanged from 0001375365-19-000078:mdna:85]

[0001375365-19-000084:mdna:62]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $239.3 million and $248.2 million as of September 30, 2019 and June 30, 2019, respectively. Our cash in foreign locations was $91.4 million and $124.6 million as of September 30, 2019 and June 30, 2019, respectively.

[0001375365-19-000084:mdna:63]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through ongoing cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-19-000084:mdna:64]
[same as prior period, unchanged from 0001375365-19-000078:mdna:89]

[0001375365-19-000084:mdna:65]
[same as prior period, unchanged from 0001375365-19-000078:mdna:90]

[0001375365-19-000084:mdna:66]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  |
| Net cash provided by operating activities | $ | 5.6 |  |  | $ | 37.7 |  |  | $ | (32.1 | ) |
| Net cash used in investing activities | $ | (13.3 | ) |  | $ | (3.2 | ) |  | $ | (10.1 | ) |
| Net cash used in financing activities | $ | (1.7 | ) |  | $ | (37.7 | ) |  | $ | 36.0 |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (9.5 | ) |  | $ | (3.2 | ) |  | $ | (6.3 | ) |

[0001375365-19-000084:mdna:67]
[same as prior period, unchanged from 0001375365-19-000078:mdna:92]

[0001375365-19-000084:mdna:68]
Net cash provided by operating activities decreased by $32.1 million for the three months ended September 30, 2019 as compared to the three months ended September 30, 2018.  The decrease was due primarily to increased net working capital of $12.5 million primarily as a result of higher cash payments for inventory purchases to meet expected customer demand, prepayments for income taxes, and reduced payments for accounts payable, and a reduction in cash receipts of $25.7 million as a result of lower deferred revenue, offset by an increase in net income in the current period of $7.0 million.

[0001375365-19-000084:mdna:69]
[same as prior period, unchanged from 0001375365-19-000078:mdna:94]

[0001375365-19-000084:mdna:70]
Net cash used in investing activities was $13.3 million and $3.2 million for the three months ended September 30, 2019 and 2018, respectively, as we continued to invest in expanding our capacity and office space, including the expansion of our Green Computing Park in San Jose.

[0001375365-19-000084:mdna:71]
[same as prior period, unchanged from 0001375365-19-000078:mdna:96]

[0001375365-19-000084:mdna:72]
Net cash used in financing activities decreased by $36.0 million for the three months ended September 30, 2019 as compared to the three months ended September 30, 2018 primarily due to decreased debt repayments of $35.4 million.

[0001375365-19-000084:mdna:73]
[same as prior period, unchanged from 0001375365-19-000078:mdna:98]

[0001375365-19-000084:mdna:74]
[same as prior period, unchanged from 0001375365-19-000078:mdna:99]

[0001375365-19-000084:mdna:75]
[same as prior period, unchanged from 0001375365-19-000078:mdna:100]

[0001375365-19-000084:mdna:76]
2018 Bank of America Credit Facility

[0001375365-19-000084:mdna:77]
In April 2018, we entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at our option and if certain conditions are satisfied, including being current on all of our delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against our line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to a five-year revolving credit facility, Super Micro Computer’s assets, and at our option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to either repurchase our shares or pay any dividends.

[0001375365-19-000084:mdna:78]
In the fourth fiscal quarter of 2018, we paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in our consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in our consolidated balance sheets.

[0001375365-19-000084:mdna:79]
On January 31, 2019, we paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, we entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000084:mdna:80]
As of September 30, 2019, we had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2019 and June 30, 2019 was 4.13% per annum and 4.50% per annum, respectively. As of September 30, 2019, a $3.2 million letter of credit was outstanding under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were immaterial as of September 30, 2019 and June 30, 2019. As of September 30, 2019, our available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000084:mdna:81]
[same as prior period, unchanged from 0001375365-19-000078:mdna:109]

[0001375365-19-000084:mdna:82]
In January 2018, we entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000084:mdna:83]
In June 2019, we entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ( $48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000084:mdna:84]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.5 million at September 30, 2019 and June 30, 2019. The interest rate for these loans were 0.88% per annum as of September 30, 2019 and 0.93% per annum as of June 30, 2019. At September 30, 2019, the amount available for future borrowing under the 2019 CTBC Credit Facility was $27.5 million. As of September 30, 2019, the net book value of land and building located in Bade, Taiwan collateralizing the 2019 CTBC Credit Facility term loan was $25.7 million.

[0001375365-19-000084:mdna:85]
Covenant Compliance

[0001375365-19-000084:mdna:86]
2018 Bank of America Credit Facility

[0001375365-19-000084:mdna:87]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The

[0001375365-19-000084:mdna:88]
credit agreement contains a financial covenant, which requires that we maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. We have been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000084:mdna:89]
On September 7, 2018, Bank of America issued an extension letter to us in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31, 2019, we entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of our audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, we paid a fee to extend the delivery to June 30, 2019 of our audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, we were required to deliver our audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver our audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If we elect to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, we are required to deliver our audited financial statements by March 31, 2020.

[0001375365-19-000084:mdna:90]
On December 19, 2019 we filed with the SEC our comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, we also filed with the SEC our Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such we have complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

[0001375365-19-000084:mdna:91]
[same as prior period, unchanged from 0001375365-19-000078:mdna:120]

[0001375365-19-000084:mdna:92]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.

[0001375365-19-000084:mdna:93]
[same as prior period, unchanged from 0001375365-19-000078:mdna:122]

[0001375365-19-000084:mdna:94]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Organization and Summary of Significant Accounting Policies,” in our notes to the condensed consolidated financial statements in this Q1 2020 Quarterly Report.

[0001375365-19-000084:mdna:95]
[same as prior period, unchanged from 0001375365-19-000078:mdna:124]

[0001375365-19-000084:mdna:96]
[same as prior period, unchanged from 0001375365-19-000078:mdna:125]
