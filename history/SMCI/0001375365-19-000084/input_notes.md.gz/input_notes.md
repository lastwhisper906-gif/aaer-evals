# SMCI notes — 0001375365-19-000084


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-19-000084:notes:1]
[same as prior period, unchanged from 0001375365-19-000078:notes:126]

[0001375365-19-000084:notes:2]
[same as prior period, unchanged from 0001375365-19-000078:notes:127]

[0001375365-19-000084:notes:3]
[same as prior period, unchanged from 0001375365-19-000078:notes:128]

[0001375365-19-000084:notes:4]
Basis of Presentation

[0001375365-19-000084:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP"). The condensed consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the condensed consolidated statements of operations and condensed consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

[0001375365-19-000084:notes:6]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”) and include the accounts of Super Micro Computer and its consolidated subsidiaries. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. GAAP have been condensed or omitted pursuant to such rules and regulations.

[0001375365-19-000084:notes:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2020.

[0001375365-19-000084:notes:8]
[same as prior period, unchanged from 0001375365-19-000078:notes:129]

[0001375365-19-000084:notes:9]
[same as prior period, unchanged from 0001375365-19-000078:notes:130]

[0001375365-19-000084:notes:10]
[same as prior period, unchanged from 0001375365-19-000078:notes:131]

[0001375365-19-000084:notes:11]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-19-000084:notes:12]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain.  Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customer from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor

[0001375365-19-000084:notes:13]
obtains control of the product, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain, and in the amount of consideration to which the Company expects to be entitled.

[0001375365-19-000084:notes:14]
As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-19-000084:notes:15]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-19-000084:notes:16]
Contracts with multiple promised goods and services. Certain of the Company’s contracts contain multiple promised goods and services.  Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-19-000084:notes:17]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company estimates the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-19-000084:notes:18]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-19-000084:notes:19]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of products sold. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-19-000084:notes:20]
[same as prior period, unchanged from 0001375365-19-000078:notes:133]

[0001375365-19-000084:notes:21]
The Company offers product warranties ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions,

[0001375365-19-000084:notes:22]
changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively.

[0001375365-19-000084:notes:23]
Inventories

[0001375365-19-000084:notes:24]
Inventories are stated at weighted average cost, subject to lower of cost or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, writes down the valuation of units based upon the Company's forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-19-000084:notes:25]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-19-000084:notes:26]
Income Taxes

[0001375365-19-000084:notes:27]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-19-000084:notes:28]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

[0001375365-19-000084:notes:29]
Stock-Based Compensation

[0001375365-19-000084:notes:30]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options and restricted stock units ("RSUs"). The share-based awards granted to non-employees have not been material to date. The Company is required to estimate the fair value of share-based awards on the date of grant. The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. The fair value of RSUs with service conditions or performance conditions is based on the closing market price of the Company's common stock on the date of grant. The fair value for RSUs with service conditions, or time-based RSUs, is amortized on a straight-line basis over the requisite service period. The fair value for RSUs with performance conditions ("PRSUs") is recognized on a ratable basis over the requisite service period when it is probable the performance conditions of the awards will be met. The Company reassesses the probability of vesting at each reporting period and adjusts the total compensation expense of the award based on this probability assessment.

[0001375365-19-000084:notes:31]
The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-19-000084:notes:32]
Leases

[0001375365-19-000084:notes:33]
Recognition of leases for periods after the Company’s adoption of the new leasing standard as of July 1, 2019

[0001375365-19-000084:notes:34]
The Company has arrangements for certain of its office, warehouse spaces and other premises, and equipment. As of July 1, 2019, the Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-19-000084:notes:35]
Operating Leases

[0001375365-19-000084:notes:36]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") asset is included in other assets, and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-19-000084:notes:37]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized, at lease commencement, based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments, and in economic environments where the leased asset is located.  Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amounts of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and liabilities.

[0001375365-19-000084:notes:38]
Finance Leases

[0001375365-19-000084:notes:39]
Assets under finance leases are included in property, plant and equipment, net and current and non-current lease liabilities are included in accrued liabilities and other long-term liabilities, respectively, on the condensed consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-19-000084:notes:40]
Recognition of leases for periods prior to the Company’s adoption of the new leasing standard as of July 1, 2019

[0001375365-19-000084:notes:41]
Prior to July 1, 2019, leases were evaluated and recorded as capital leases if one of the following is true at inception: (a) the present value of minimum lease payments meets or exceeds 90% of the fair value of the asset, (b) the lease term is greater than or equal to 75% of the economic life of the asset, (c) the lease arrangement contains a bargain purchase option, or (d) title to the property transfers to the Company at the end of the lease. The Company records an asset and liability for capital leases at present value of the minimum lease payments based on the incremental borrowing rate. Assets are depreciated over the useful life in accordance with the Company’s depreciation policy while rental payments and interest on the liability are accounted for using the effective interest method.

[0001375365-19-000084:notes:42]
Leases that are not classified as capital leases are accounted for as operating leases. Operating lease agreements that have tenant improvement allowances are evaluated for lease incentives. For leases that contain escalating rent payments, the Company recognizes rent expense on a straight-line basis over the lease term, with any lease incentives amortized as a reduction of rent expense over the lease term.

[0001375365-19-000084:notes:43]
[same as prior period, unchanged from 0001375365-19-000078:notes:135]

[0001375365-19-000084:notes:44]
[same as prior period, unchanged from 0001375365-19-000078:notes:136]

[0001375365-19-000084:notes:45]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware") are VIEs in accordance with applicable accounting standards and guidance; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, including the supplier arrangements. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect those related parties’ interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-19-000084:notes:46]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each company contributed $0.2 million and owns 50% of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the three months ended September 30, 2019 and 2018, the accounts of the Management Company have been consolidated with the accounts of Super Micro Computer, and a noncontrolling interest has been recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's condensed consolidated statements of operations.

[0001375365-19-000084:notes:47]
[same as prior period, unchanged from 0001375365-19-000078:notes:139]

[0001375365-19-000084:notes:48]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party. As of September 30, 2019 and June 30, 2019, the Company's equity investment in the Corporate Venture was $2.3 million and $1.7 million, respectively, and was recorded under investment in equity investee on the Company's condensed consolidated balance sheet. The Company's share of gains (losses) of the Corporate Venture were $1.0 million and $(1.4) million for the three months ended September 30, 2019 and 2018, respectively.

[0001375365-19-000084:notes:49]
The Company previously recorded a deferred gain related to the contribution of certain technology rights of $10.0 million. The amortization of the deferred gain is being recognized as a credit to research and development expenses in the Company's condensed consolidated statement of operations over a period of five years which represents the estimated period over which the remaining obligations will be fulfilled. As of September 30, 2019 and June 30, 2019, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $2.5 million and $3.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

[0001375365-19-000084:notes:50]
The Company monitors the investment for events or circumstances indicative of potential other-than-temporary impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. No impairment charge was recorded for the three months ended September 30, 2019 and 2018, respectively.

[0001375365-19-000084:notes:51]
Additionally, the Company sold products worth $22.1 million and $9.3 million to the Corporate Venture in the three months ended September 30, 2019 and 2018, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2019 and June 30, 2019 have been eliminated and have reduced the Company's investment in the Corporate Venture. The Company had $15.3 million and $13.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2019 and June 30, 2019, respectively, in its condensed consolidated balance sheets.

[0001375365-19-000084:notes:52]
[same as prior period, unchanged from 0001375365-19-000078:notes:145]

[0001375365-19-000084:notes:53]
Certain materials used by the Company in the manufacture of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 28.7% and 19.7% of total purchases for the three months ended September 30, 2019 and 2018, respectively. Ablecom and Compuware, related parties of the Company, as noted in Note 9, "Related Party Transactions," accounted for 9.7% and 9.2% of total cost of sales for the three months ended September 30, 2019 and 2018, respectively.

[0001375365-19-000084:notes:54]
[same as prior period, unchanged from 0001375365-19-000078:notes:147]

[0001375365-19-000084:notes:55]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2019 and 2018. No country other than the United States represented greater than 10% of the Company’s total net sales in the three months ended September 30, 2019 and 2018. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2019, whereas one customer accounted for 17.0% of accounts receivable, net as of June 30, 2019.

[0001375365-19-000084:notes:56]
Accounting Pronouncements Recently Adopted

[0001375365-19-000084:notes:57]
In February 2016, the FASB issued an amendment to the accounting guidance, Leases. The new lease accounting guidance supersedes the existing guidance. Under the new lease accounting guidance, lessees are required to recognize assets and liabilities on the balance sheet for most leases and provide enhanced disclosures. Leases will continue to be classified as either finance or operating. The Company adopted the new lease accounting guidance on July 1, 2019 using the modified retrospective approach, and as a result did not restate prior comparative periods. The Company elected the “package of practical expedients” under the transition guidance of the new standard, which permits it not to reassess under the new lease accounting guidance its prior conclusions about lease identification, lease classification and initial direct costs, for leases that are in effect as of the date of adoption of the new lease accounting guidance. In connection with the adoption of the new lease accounting guidance, the Company recorded a transition adjustment to recognize ROU assets and lease liabilities on the Company’s consolidated balance sheet of $14.8 million and $15.2 million, respectively, on July 1, 2019, primarily related to real estate leases. See Note 8, "Leases," for further details.

[0001375365-19-000084:notes:58]
In February 2018, the FASB issued Income Statement - Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act ("2017 Tax Reform Act"), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The Company adopted this guidance on July 1, 2019. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.

[0001375365-19-000084:notes:59]
In June 2018, the FASB issued amended guidance to expand the scope of ASC 718 - Compensation-Stock Compensation, to include share-based payment transactions for acquiring goods and services from non-employees. The amendments specify that the guidance applies to all share-based payment transactions in which a grantor acquires goods or services to be used or consumed in a grantor’s own operations by issuing share-based payment awards. The Company adopted this guidance on July 1, 2019. The adoption of the guidance did not have a material impact on the Company's consolidated financial statements and related disclosures.

[0001375365-19-000084:notes:60]
Accounting Pronouncements Not Yet Adopted

[0001375365-19-000084:notes:61]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, that amends the impairment model for certain financial assets by requiring the use of an

[0001375365-19-000084:notes:62]
expected loss methodology, which will result in more timely recognition of credit losses. The amendment is effective for the Company from July 1, 2020. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.

[0001375365-19-000084:notes:63]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the Concepts Statement, including the consideration of costs and benefits. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures.

[0001375365-19-000084:notes:64]
In August 2018, the FASB issued amended guidance to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal use software license). The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments. According to the amendments, the entity shall determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. It requires the entity (customer) to expense the capitalized implementation costs of a hosting arrangement that is a service contract over the term of the hosting arrangement. The new standard is effective for the Company from July 1, 2020. The Company is currently evaluating the effect the guidance will have on its consolidated financial statement disclosures, results of operations and financial position.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-19-000084:notes:65]
[same as prior period, unchanged from 0001375365-19-000078:notes:197]

[0001375365-19-000084:notes:66]
Disaggregation of Revenue

[0001375365-19-000084:notes:67]
The Company disaggregates revenue by type of product, by geographical market, and by products sold to indirect sales channel partners or direct customers and original equipment manufacturers ("OEMs") that depict the nature, amount, and timing of revenue and cash flows. Service revenues are not a significant component of total revenue and are aggregated within the respective categories.

[0001375365-19-000084:notes:68]
The following is a summary of net sales by product type (in thousands):

[0001375365-19-000084:notes:69]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server and storage systems | $ | 636,026 |  |  | 79.5 | % |  | $ | 808,027 |  |  | 83.2 | % |
| Subsystems and accessories | 163,778 |  |  | 20.5 | % |  | 163,091 |  |  | 16.8 | % |
| Total | $ | 799,804 |  |  | 100.0 | % |  | $ | 971,118 |  |  | 100.0 | % |

[0001375365-19-000084:notes:70]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

[0001375365-19-000084:notes:71]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-19-000084:notes:72]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2019 and 2018, of net sales by geographic region (in thousands):

[0001375365-19-000084:notes:73]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| United States | $ | 468,841 |  |  | $ | 567,615 |  |
| Europe | 128,059 |  |  | 162,560 |  |
| Asia | 161,639 |  |  | 206,868 |  |
| Others | 41,265 |  |  | 34,075 |  |
|  | $ | 799,804 |  |  | $ | 971,118 |  |

[0001375365-19-000084:notes:74]
The following table presents the percentages of net sales from products sold through the Company's indirect sales channel and to its direct customers and OEMs for the three months ended September 30, 2019 and 2018:

[0001375365-19-000084:notes:75]
|  | Three Months Ended September 30, |  | Change |
|  | 2019 |  | 2018 |  | % |
| Indirect sales channel | 50.2 | % |  | 34.4 | % |  | 15.8 | % |
| Direct customers and OEMs | 49.8 | % |  | 65.6 | % |  | (15.8 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |

[0001375365-19-000084:notes:76]
[same as prior period, unchanged from 0001375365-19-000078:notes:198]

[0001375365-19-000084:notes:77]
[same as prior period, unchanged from 0001375365-19-000078:notes:199]

[0001375365-19-000084:notes:78]
[same as prior period, unchanged from 0001375365-19-000078:notes:200]

[0001375365-19-000084:notes:79]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. On June 30, 2019, deferred revenue totaled $203.4 million, of which $25.5 million was recognized as revenue during the three months ended September 30, 2019.

[0001375365-19-000084:notes:80]
Deferred revenue decreased during the three months ended September 30, 2019 because the recognition of revenue from contracts entered into in prior periods exceeded the amounts for service contracts invoiced during the period.

[0001375365-19-000084:notes:81]
[same as prior period, unchanged from 0001375365-19-000078:notes:203]

[0001375365-19-000084:notes:82]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2019 was approximately $201.9 million. The Company expects to recognize approximately 48% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-19-000084:notes:83]
[same as prior period, unchanged from 0001375365-19-000078:notes:42]

[0001375365-19-000084:notes:84]
[same as prior period, unchanged from 0001375365-19-000078:notes:43]

[0001375365-19-000084:notes:85]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for awards of stock options, stock appreciation rights, restricted stock, RSUs and

[0001375365-19-000084:notes:86]
other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of the date the 2016 Plan became effective, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006 Plan"). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan, although no further awards have been or will be granted under the 2006 Plan. Up to 2,800,000 shares subject to awards that remained outstanding under the 2006 Plan at the time the 2016 Plan became effective, if those awards were or are forfeited at any time after the 2016 Plan became effective, will become available for use under the 2016 Plan. At the time the 2016 Plan became effective, all remaining ungranted shares under the 2006 Plan were canceled. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. Under the 2016 Plan, the Company granted PRSUs to its Chief Executive Officer, 50% of which vest based on the achievement of certain performance metrics at the end of the performance period while the remainder vest in equal amounts over the following ten quarters provided he continues to be employed by the Company. As of September 30, 2019, the Company had 313,872 authorized shares available for future issuance under the 2016 Plan.

[0001375365-19-000084:notes:87]
[same as prior period, unchanged from 0001375365-19-000078:notes:45]

[0001375365-19-000084:notes:88]
[same as prior period, unchanged from 0001375365-19-000078:notes:46]

[0001375365-19-000084:notes:89]
[same as prior period, unchanged from 0001375365-19-000078:notes:47]

[0001375365-19-000084:notes:90]
Expected Volatility—Expected volatility is based on the Company's historical volatility.

[0001375365-19-000084:notes:91]
[same as prior period, unchanged from 0001375365-19-000078:notes:49]

[0001375365-19-000084:notes:92]
[same as prior period, unchanged from 0001375365-19-000078:notes:50]

[0001375365-19-000084:notes:93]
The fair value of stock option grants for the three months ended September 30, 2019 and 2018 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-19-000084:notes:94]
|  | Three Months EndedSeptember 30, |
|  | 2019 |  | 2018 |
| Risk-free interest rate | 1.58 | % |  | 2.87 | % |
| Expected term | 6.27 years |  |  | 6.05 years |  |
| Dividend yield | — | % |  | — | % |
| Volatility | 50.04 | % |  | 47.34 | % |
| Weighted-average fair value | $ | 8.72 |  |  | $ | 10.78 |  |

[0001375365-19-000084:notes:95]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three months ended September 30, 2019 and 2018 (in thousands):

[0001375365-19-000084:notes:96]
|  | Three Months EndedSeptember 30, |
|  | 2019 |  | 2018 |
| Cost of sales | $ | 395 |  |  | $ | 438 |  |
| Research and development | 3,130 |  |  | 3,496 |  |
| Sales and marketing | 436 |  |  | 505 |  |
| General and administrative | 1,093 |  |  | 1,435 |  |
| Stock-based compensation expense before taxes | 5,054 |  |  | 5,874 |  |
| Income tax impact | (1,143 | ) |  | (1,242 | ) |
| Stock-based compensation expense, net | $ | 3,911 |  |  | $ | 4,632 |  |

[0001375365-19-000084:notes:97]
As of September 30, 2019, $7.0 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.61 years, $32.5 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.83 years and $0.2 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 1.25 years.

[0001375365-19-000084:notes:98]
[same as prior period, unchanged from 0001375365-19-000078:notes:56]

[0001375365-19-000084:notes:99]
The following table summarizes stock option activity during the three months ended September 30, 2019 under all plans:

[0001375365-19-000084:notes:100]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |
| Granted |  | 118,230 |  |  | $ | 17.60 |  |  |  |
| Exercised |  | — |  |  | $ | — |  |  |  |
| Forfeited/Cancelled |  | (39,524 | ) |  | $ | 10.14 |  |  |  |
| Balance as of September 30, 2019 |  | 7,453,341 |  |  | $ | 18.06 |  |  | 3.68 |
| Options vested and exercisable at September 30, 2019 |  | 6,665,457 |  |  | $ | 17.76 |  |  | 3.08 |

[0001375365-19-000084:notes:101]
[same as prior period, unchanged from 0001375365-19-000078:notes:59]

[0001375365-19-000084:notes:102]
[same as prior period, unchanged from 0001375365-19-000078:notes:60]

[0001375365-19-000084:notes:103]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. The first award was a one-year PRSU and the second award was a two-year PRSU. The one-year PRSUs would be earned based on the Company’s performance as it relates to a revenue growth metric and a minimum non-GAAP operating margin metric during the fiscal year ended June 30, 2018 with eligibility up to 200% of the targeted number of units based on revenue growth if the minimum non-GAAP operating margin is achieved. If the performance metrics were met, 50% of the PRSUs would vest at June 30, 2018 while the remainder would vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors determined that the Company achieved the revenue and non-GAAP operating margin metrics for the fiscal year ended June 30, 2018 at a level that entitled the Chief Executive Officer to 200% of the originally targeted number of shares subject to the one-year PRSU. 50% of the PRSUs so earned were vested as of June 30, 2018, and an additional 25% of the PRSUs vested during the five quarters ended September 30, 2019, in accordance with the terms of the grant.

[0001375365-19-000084:notes:104]
The two-year PRSUs would be earned based on the Company’s performance for the average non-GAAP operating margin metric for the two fiscal years ended June 30, 2019 with eligibility up to 100% of the targeted number of units. If the performance metrics would have been met, 50% of the PRSUs would have vested at June 30, 2019 while the remainder would have been vested in equal amounts over the following ten quarters if the Chief Executive Officer continued to be employed

[0001375365-19-000084:notes:105]
during those ten quarters. In December 2019, the Compensation Committee of the Company's Board of Directors has determined that the Company did not achieve the required performance metrics for these two-year PRSUs to be earned and, consequently, this PRSU terminated in December 2019.

[0001375365-19-000084:notes:106]
The following table summarizes RSUs and PRSUs activity during the three months ended September 30, 2019 under all plans:

[0001375365-19-000084:notes:107]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2019 | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  | (1) |  | $ | 27.10 |  |
| Granted | 337,730 |  |  | $ | 17.60 |  |  | — |  |  |  |  |
| Released (2) | (100,186 | ) |  | $ | 24.27 |  |  | — |  |  |  |  |
| Forfeited | (45,313 | ) |  | $ | 18.20 |  |  | — |  |  |  |  |
| Balance as of September 30, 2019 | 2,065,333 |  |  | $ | 19.66 |  |  | 120,000 |  |  |  | $ | 27.10 |  |

[0001375365-19-000084:notes:108]
[same as prior period, unchanged from 0001375365-19-000078:notes:65]

[0001375365-19-000084:notes:109]
[same as prior period, unchanged from 0001375365-19-000078:notes:66]

[0001375365-19-000084:notes:110]
(2)

[0001375365-19-000084:notes:111]
The number of shares released excludes 221,352 RSUs that were vested but not released as of September 30, 2019, of which 48,495 RSUs vested during the three months ended September 30, 2019. The number of shares released also excludes 90,000 PRSUs that were vested but not released as of September 30, 2019, of which 6,000 PRSUs vested during the three months ended September 30, 2019. These vested RSUs and PRSUs will be released upon the effectiveness of the Company's registration statement on Form S-8.


## us-gaap:EarningsPerShareTextBlock

[0001375365-19-000084:notes:112]
[same as prior period, unchanged from 0001375365-19-000078:notes:68]

[0001375365-19-000084:notes:113]
The following table shows the computation of basic and diluted net income per common share for the three months ended September 30, 2019 and 2018 (in thousands, except per share amounts):

[0001375365-19-000084:notes:114]
|  | Three Months EndedSeptember 30, |
|  | 2019 |  | 2018 |
| Numerator: |  |  |  |
| Net income | $ | 26,345 |  |  | $ | 19,342 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 50,274 |  |  | 49,704 |  |
| Effect of dilutive securities | 1,430 |  |  | 2,514 |  |
| Weighted-average diluted shares | 51,704 |  |  | 52,218 |  |
| Basic net income per common share | $ | 0.52 |  |  | $ | 0.39 |  |
| Diluted net income per common share | $ | 0.51 |  |  | $ | 0.37 |  |

[0001375365-19-000084:notes:115]
For the three months ended September 30, 2019 and 2018, the Company had stock options and RSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 3,958,789 and 2,627,703 for the three months ended September 30, 2019 and 2018, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-19-000084:notes:116]
[same as prior period, unchanged from 0001375365-19-000078:notes:230]

[0001375365-19-000084:notes:117]
[same as prior period, unchanged from 0001375365-19-000078:notes:231]

[0001375365-19-000084:notes:118]
Inventories:

[0001375365-19-000084:notes:119]
|  | September 30, 2019 |  | June 30, 2019 |
| Finished goods | $ | 480,954 |  |  | $ | 492,387 |  |
| Work in process | 76,098 |  |  | 43,598 |  |
| Purchased parts and raw materials | 128,179 |  |  | 134,203 |  |
| Total inventories | $ | 685,231 |  |  | $ | 670,188 |  |

[0001375365-19-000084:notes:120]
During the three months ended September 30, 2019 and 2018, the Company recorded a provision for excess and obsolete inventory to cost of sales totaling $10.1 million and $8.0 million, respectively, excluding a (recovery) provision for adjusting the cost of certain inventories to net realizable value of $(1.8) million and $1.5 million for the three months ended September 30, 2019 and 2018, respectively.

[0001375365-19-000084:notes:121]
Prepaid Expenses and Other Current Assets:

[0001375365-19-000084:notes:122]
|  | September 30, 2019 |  | June 30, 2019 |
| Receivables from vendors (1) | $ | 96,038 |  |  | $ | 83,050 |  |
| Prepaid income tax | 15,748 |  |  | 607 |  |
| Restricted cash | 11,021 |  |  | 11,673 |  |
| Prepaid expenses | 8,057 |  |  | 7,269 |  |
| Deferred service costs | 3,611 |  |  | 3,374 |  |
| Others | 5,095 |  |  | 3,822 |  |
| Total prepaid expenses and other current assets | $ | 139,570 |  |  | $ | 109,795 |  |

[0001375365-19-000084:notes:123]
(1) Includes receivables from contract manufacturers based on certain buy-sell arrangements of $91.0 million and $82.0 million as of September 30, 2019 and June 30, 2019, respectively.

[0001375365-19-000084:notes:124]
Cash, cash equivalents and restricted cash:

[0001375365-19-000084:notes:125]
|  | September 30, 2019 |  | June 30, 2019 |
| Cash and cash equivalents | $ | 239,300 |  |  | $ | 248,164 |  |
| Restricted cash included in prepaid expenses and other current assets | 11,021 |  |  | 11,673 |  |
| Restricted cash included in other assets | 2,301 |  |  | 2,303 |  |
| Total cash, cash equivalents and restricted cash | $ | 252,622 |  |  | $ | 262,140 |  |

[0001375365-19-000084:notes:126]
Property, Plant, and Equipment:

[0001375365-19-000084:notes:127]
|  | September 30, 2019 |  | June 30, 2019 |
| Buildings | $ | 86,864 |  |  | $ | 86,136 |  |
| Machinery and equipment | 81,482 |  |  | 79,946 |  |
| Land | 75,197 |  |  | 74,926 |  |
| Building and leasehold improvements | 23,238 |  |  | 22,307 |  |
| Furniture and fixtures | 20,345 |  |  | 20,193 |  |
| Buildings construction in progress (1) | 19,877 |  |  | 14,189 |  |
| Software | 18,752 |  |  | 18,415 |  |
|  | 325,755 |  |  | 316,112 |  |
| Accumulated depreciation and amortization | (113,266 | ) |  | (108,775 | ) |
| Property, plant and equipment, net | $ | 212,489 |  |  | $ | 207,337 |  |

[0001375365-19-000084:notes:128]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California.

[0001375365-19-000084:notes:129]
Other Assets:

[0001375365-19-000084:notes:130]
|  | September 30, 2019 |  | June 30, 2019 |
| Operating lease right-of-use asset | $ | 13,623 |  |  | $ | — |  |
| Deferred service costs, non-current | 3,634 |  |  | 3,572 |  |
| Restricted cash, non-current | 2,301 |  |  | 2,303 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Non-marketable equity securities | 878 |  |  | 878 |  |
| Deposits | 587 |  |  | 686 |  |
| Prepaid expense, non-current | 1,865 |  |  | 1,649 |  |
| Total other assets | $ | 24,459 |  |  | $ | 10,659 |  |

[0001375365-19-000084:notes:131]
Accrued Liabilities:

[0001375365-19-000084:notes:132]
|  | September 30, 2019 |  | June 30, 2019 |
| Contract manufacturers liability | $ | 31,389 |  |  | $ | 25,308 |  |
| Accrued payroll and related expenses | 22,515 |  |  | 25,552 |  |
| Customer deposits | 19,992 |  |  | 11,133 |  |
| Accrued professional fees | 12,058 |  |  | 11,756 |  |
| Accrued warranty costs | 8,655 |  |  | 8,661 |  |
| Accrued cooperative marketing expenses | 6,042 |  |  | 5,830 |  |
| Operating lease liability | 5,159 |  |  | — |  |
| Others | 26,482 |  |  | 26,438 |  |
| Total accrued liabilities | $ | 132,292 |  |  | $ | 114,678 |  |

[0001375365-19-000084:notes:133]
Other Long-term Liabilities:

[0001375365-19-000084:notes:134]
|  | September 30, 2019 |  | June 30, 2019 |
| Accrued unrecognized tax benefits including related interest and penalties | $ | 22,851 |  |  | $ | 20,102 |  |
| Operating lease liability, non-current | 8,624 |  |  | — |  |
| Accrued warranty costs, non-current | 2,630 |  |  | 2,373 |  |
| Others | 2,607 |  |  | 3,708 |  |
| Total other long-term liabilities | $ | 36,712 |  |  | $ | 26,183 |  |

[0001375365-19-000084:notes:135]
Product Warranties:

[0001375365-19-000084:notes:136]
|  | Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| Balance, beginning of the period | $ | 11,034 |  |  | $ | 9,884 |  |
| Provision for warranty | 5,872 |  |  | 6,189 |  |
| Costs utilized | (7,662 | ) |  | (6,557 | ) |
| Change in estimated liability for pre-existing warranties | 2,041 |  |  | 729 |  |
| Balance, end of the period | 11,285 |  |  | 10,245 |  |
| Current portion | 8,655 |  |  | 8,150 |  |
| Non-current portion | $ | 2,630 |  |  | $ | 2,095 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-19-000084:notes:137]
[same as prior period, unchanged from 0001375365-19-000078:notes:78]

[0001375365-19-000084:notes:138]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and other assets. The Company classifies its cash equivalents and other assets, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of September 30, 2019 and June 30, 2019. The Company used discounted cash flows to estimate the fair value of the auction rate security as of September 30, 2019 and June 30, 2019. The material factors used in preparing the discounted cash flows are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return.

[0001375365-19-000084:notes:139]
[same as prior period, unchanged from 0001375365-19-000078:notes:80]

[0001375365-19-000084:notes:140]
The following table sets forth the Company’s cash equivalents, certificates of deposit and investment in an auction rate security as of September 30, 2019 and June 30, 2019 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-19-000084:notes:141]
| September 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,158 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,158 |  |
| Certificates of deposit (2) | — |  |  | 1,279 |  |  | — |  |  | 1,279 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,158 |  |  | $ | 1,279 |  |  | $ | 1,571 |  |  | $ | 4,008 |  |
| June 30, 2019 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds (1) | $ | 1,162 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,162 |  |
| Certificates of deposit (2) | — |  |  | 1,285 |  |  | — |  |  | 1,285 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,162 |  |  | $ | 1,285 |  |  | $ | 1,571 |  |  | $ | 4,018 |  |

[0001375365-19-000084:notes:142]
(1) $0.4 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2019 and June 30, 2019, respectively.

[0001375365-19-000084:notes:143]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents and $1.1 million and $1.1 million in certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of September 30, 2019 and June 30, 2019, respectively.

[0001375365-19-000084:notes:144]
The above table excludes $238.7 million and $247.6 million of cash included in cash and cash equivalents, $11.0 million and $11.7 million of restricted cash included in prepaid expenses and other current assets, and $0.4 million and $0.4 million of restricted cash, non-current included in other assets in the condensed consolidated balance sheets as of September 30, 2019 and June 30, 2019, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three months ended September 30, 2019 and 2018.

[0001375365-19-000084:notes:145]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three months ended September 30, 2019 and 2018.

[0001375365-19-000084:notes:146]
The following is a summary of the Company’s investment in an auction rate security as of September 30, 2019 and June 30, 2019 (in thousands):

[0001375365-19-000084:notes:147]
|  | September 30, 2019 and June 30, 2019 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179 | ) |  | $ | 1,571 |  |

[0001375365-19-000084:notes:148]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of September 30, 2019 and June 30, 2019, total debt of $22.5 million and $23.6 million, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-19-000084:notes:149]
[same as prior period, unchanged from 0001375365-19-000078:notes:85]

[0001375365-19-000084:notes:150]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values. During the three months ended September 30, 2019 and 2018 the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during the three months ended September 30, 2019 and 2018.

[0001375365-19-000084:notes:151]
There were no transfers of financial assets measured on a non-recurring basis between Level 1, Level 2 or Level 3 securities during the three months ended September 30, 2019 and 2018.


## us-gaap:DebtDisclosureTextBlock

[0001375365-19-000084:notes:152]
Short-term Debt

[0001375365-19-000084:notes:153]
Short-term debt obligations as of September 30, 2019 and June 30, 2019 consisted of the following (in thousands):

[0001375365-19-000084:notes:154]
|  | September 30, |  | June 30, |
|  | 2019 |  | 2019 |
| Bank of America line of credit | $ | — |  |  | $ | 1,116 |  |
| CTBC Bank term loan | 22,544 |  |  | 22,531 |  |
| Total short-term debt | $ | 22,544 |  |  | $ | 23,647 |  |

[0001375365-19-000084:notes:155]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-19-000084:notes:156]
Bank of America

[0001375365-19-000084:notes:157]
2018 Bank of America Credit Facility

[0001375365-19-000084:notes:158]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which replaced the then existing credit facility with Bank of America (the "2016 Bank of America Credit Facility"). The 2018 Bank of America Credit Facility provides for a revolving credit line and other financial accommodations of up to $250.0 million extended by certain lenders, including a $5.0 million letter of credit sublimit, which was extended to $15.0 million in October 2019. The 2018 Bank of America Credit Facility was originally set to expire after 364 days and has been extended to June 30, 2020 through subsequent amendments. Prior to its maturity, at the Company's option and if certain conditions are satisfied, including the Company being current on all of its delinquent quarterly and annual filings with the SEC, the 2018 Bank of America Credit Facility may convert into a five-year revolving credit facility. If and upon such conversion, the lenders for the 2018 Bank of America Credit Facility shall extend, in aggregate, a principal amount of up to $400.0 million. Prior to the 2018 Bank of America Credit Facility’s conversion to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus 2.75% per annum. Upon the 2018 Bank of America Credit Facility converting to the five-year revolving credit facility, interest shall accrue at the LIBOR rate plus an amount between 1.50% and 2.00% for loans to both Super Micro Computer and Super Micro Computer B.V. Under the terms of the 2018 Bank of America Credit Facility, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility, unless payment is required earlier as determined by the lenders. Voluntary prepayments are permitted without early repayment fees or penalties. The terms of the arrangement require any amounts in the deposit accounts to be applied against the Company's line of credit the next business day. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets. If converted to the five-year revolving credit facility, Super Micro Computer’s assets, and at the Company's option, Super Micro Computer B.V.'s assets will be used as collateral for the 2018 Bank of America Credit Facility. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to either repurchase its common stock or pay any dividends.

[0001375365-19-000084:notes:159]
In the fourth fiscal quarter of 2018, the Company paid $3.2 million in fees to the lenders and third parties in connection with the 2018 Bank of America Credit Facility.  The replacement of the 2016 Bank of America Credit Facility by the 2018 Bank of America Credit Facility is accounted for as a modification of the existing credit facility to the extent the lenders before and after the modification were the same. Any unamortized fees relating to the 2016 Bank of America Credit Facility and the fees paid for the 2018 Bank of America Credit Facility are amortized over the term of the 2018 Bank of America Credit Facility as interest expense in the Company's consolidated statements of operation and any unamortized amounts are classified within prepaid and other current assets in the Company's consolidated balance sheets.

[0001375365-19-000084:notes:160]
On January 31, 2019, the Company paid a fee and entered into an amendment of the 2018 Bank of America Credit Facility that resulted in the extension of the maturity date from April 19, 2019 to June 30, 2019. On June 27, 2019, the

[0001375365-19-000084:notes:161]
Company entered into a second amendment of the 2018 Bank of America Credit Facility that extended the maturity date from June 30, 2019 to June 30, 2020.

[0001375365-19-000084:notes:162]
As of September 30, 2019, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. As of June 30, 2019, the total outstanding borrowings under the 2018 Bank of America Credit facility were $1.1 million. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2019 and June 30, 2019 were 4.13% per annum and 4.50% per annum, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility. The balance of debt issuance costs outstanding were immaterial as of September 30, 2019 and June 30, 2019. As of September 30, 2019, the Company's available borrowing capacity under the 2018 Bank of America Credit Facility was $246.8 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-19-000084:notes:163]
CTBC Bank

[0001375365-19-000084:notes:164]
In January 2018, the Company entered into a credit agreement with CTBC Bank that provided for (i) a 12-month NTD $700.0 million ($23.6 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly, which term loan facility also included a 12-month guarantee of up to NTD $100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month NTD $1,500.0 million ($50.5 million U.S. dollar equivalent) term loan facility with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum, which was adjusted monthly (collectively, the “2018 CTBC Credit Facility”). The total borrowings allowed under the 2018 CTBC Credit Facility was initially capped at $50.0 million and in August 2018 was reduced to $40.0 million. In June 2019 prior to its maturity, the 2018 CTBC Credit Facility was replaced by the 2019 CTBC Credit Facility (defined below).

[0001375365-19-000084:notes:165]
In June 2019, the Company entered into a credit agreement with CTBC Bank that provides for (i) a 12-month NTD $700.0 million ($22.5 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD $100.0 million ($3.2 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD $1,500.0 million ($48.2 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly (collectively, the “2019 CTBC Credit Facility”). The total borrowings allowed under the 2019 CTBC Credit Facility was capped at $50.0 million. The 2019 CTBC Credit Facility is to mature on June 30, 2020.

[0001375365-19-000084:notes:166]
The total outstanding borrowings under the 2019 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $22.5 million at September 30, 2019 and June 30, 2019. The interest rate for these loans were 0.88% per annum as of September 30, 2019 and 0.93% per annum as of June 30, 2019. At September 30, 2019, the amount available for future borrowing under the CTBC Credit Facility was $27.5 million. As of September 30, 2019, the net book value of land and building located in Bade, Taiwan, collateralizing the 2019 CTBC Credit Facility term loan was $25.7 million.

[0001375365-19-000084:notes:167]
Covenant Compliance

[0001375365-19-000084:notes:168]
The credit agreement with Bank of America related to the 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains a financial covenant, which requires that the Company maintain a Fixed Charge Coverage Ratio, as defined in the agreement of at least 1.00 for each twelve-month period while a Trigger Period, as defined in the agreement, is in effect. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility.

[0001375365-19-000084:notes:169]
On September 7, 2018, Bank of America issued an extension letter to the Company in connection with the 2018 Bank of America Credit Facility, which extended the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to January 31, 2019. On January 31,

[0001375365-19-000084:notes:170]
2019, the Company entered into an amendment of the loan and security agreement with respect to the 2018 Bank of America Credit Facility to, among other matters, (a) extend the delivery date of the Company's audited consolidated financial statements, compliance certificates and other material reports for the fiscal year ended June 30, 2018 to June 30, 2019, and (b) require the delivery, by no later than March 31, 2019 of the Company's audited consolidated financial statements for the fiscal year ended June 30, 2019. In April 2019, the Company paid a fee to extend the delivery to June 30, 2019 of its audited consolidated financial statements for the fiscal year ended June 30, 2017. In connection with the second amendment of the 2018 Bank of America Credit Facility to extend the maturity of the 2018 Bank of America Credit Facility, the Company was required to deliver its audited consolidated financial statements for the fiscal year ended June 30, 2018 by December 31, 2019, and deliver its audited consolidated financial statements for the fiscal year ended June 30, 2019 by March 31, 2020. If the Company elects to deliver the audited consolidated financial statements for the fiscal years ended June 30, 2019 and 2018 together in a combined filing with the SEC, the Company is required to deliver its audited financial statements by March 31, 2020.

[0001375365-19-000084:notes:171]
On December 19, 2019 the Company filed with the SEC its comprehensive Annual Report on Form 10-K for the fiscal year ended June 30, 2019, with expanded financial and other disclosures in lieu of filing a separate Annual Report on Form 10-K for the fiscal year ended June 30, 2018 and in lieu of filing Quarterly Reports on Form 10-Q for the first three quarters of fiscal year 2018. On December 19, 2019, the Company also filed with the SEC its Quarterly Reports on Form 10-Q for the quarters ended September 30, 2018, December 31, 2018 and March 31, 2019. As such the Company has complied with the requirements of the second amendment of the 2018 Bank of America Credit Facility.

[0001375365-19-000084:notes:172]
There are no financial covenants associated with the 2018 CTBC Credit Facility or the 2019 CTBC Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-19-000084:notes:173]
Leases
Upon adoption of the new lease accounting guidance, the Company recognized operating lease liabilities of approximately $15.2 million based on the present value of the remaining minimum rental payments using an incremental borrowing rate of approximately 4%. The Company also recognized corresponding operating lease ROU assets of approximately $14.8 million. The difference relates to adjustments made to operating lease ROU assets for prepaid rent and deferred rent that existed as of the date of adoption. These operating lease ROU assets relate to offices, warehouses and other premises leased under non-cancelable operating leases expiring through June 2026 and vehicles and certain equipment leased under non-cancelable operating leases expiring through August 2023.

[0001375365-19-000084:notes:174]
Operating lease expense recognized and supplemental cash flow information related to operating leases for the three months ended September 30, 2019 were as follows (in thousands):

[0001375365-19-000084:notes:175]
|  |  | Three Months Ended |
|  |  | September 30, 2019 |
| Operating lease expense (including expense for lease agreements with related parties of $365) |  | $ | 1,709 |  |
| Cash payments for operating leases (including payments to related parties of $357) |  | $ | 1,845 |  |
| New operating lease assets obtained in exchange for operating lease liabilities |  | $ | 231 |  |

[0001375365-19-000084:notes:176]
Variable payments expensed in the three months ended September 30, 2019 were immaterial.

[0001375365-19-000084:notes:177]
As of September 30, 2019, the weighted average remaining lease term for operating leases was 4.1 years and the weighted average discount rate was 3.9%. Future minimum lease payments under noncancelable operating lease arrangements as of September 30, 2019 were as follows (in thousands):

[0001375365-19-000084:notes:178]
| Year ending: |  | Minimum lease payments |
| 2020 (remainder) |  | $ | 4,728 |  |
| 2021 |  | 3,621 |  |
| 2022 |  | 2,402 |  |
| 2023 |  | 1,130 |  |
| 2024 |  | 1,120 |  |
| 2025 and beyond |  | 1,910 |  |
| Total future lease payments |  | $ | 14,911 |  |
| Less: Imputed interest |  | (1,128 | ) |
| Present value of operating lease liabilities |  | $ | 13,783 |  |

[0001375365-19-000084:notes:179]
As of September 30, 2019, operating and financing leases that have not yet commenced were immaterial.

[0001375365-19-000084:notes:180]
The Company has entered into lease agreements with related parties.  See Note 9, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-19-000084:notes:181]
Related Party Transactions

[0001375365-19-000084:notes:182]
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. As of September 30, 2019, Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. The Company does not own, nor has it ever owned, any of Ablecom’s capital stock. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock as of September 30, 2019. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. None of the Company, Charles Liang or Sara Liu own any capital stock of Compuware.

[0001375365-19-000084:notes:183]
Dealings with Ablecom

[0001375365-19-000084:notes:184]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-19-000084:notes:185]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.7% and 95.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2019 and 2018, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-19-000084:notes:186]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-19-000084:notes:187]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such

[0001375365-19-000084:notes:188]
that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $41.1 million and $31.0 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-19-000084:notes:189]
Dealings with Compuware

[0001375365-19-000084:notes:190]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-19-000084:notes:191]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-19-000084:notes:192]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-19-000084:notes:193]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-19-000084:notes:194]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $76.7 million and $70.6 million at September 30, 2019 and June 30, 2019, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-19-000084:notes:195]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2019 and 2018, are as follows (in thousands):

[0001375365-19-000084:notes:196]
|  | Three months ended September, 30 |
|  | 2019 |  | 2018 |
| Ablecom |  |  |  |
| Purchases (1) | $ | 33,120 |  |  | $ | 44,636 |  |
| Compuware |  |  |  |
| Net sales | $ | 5,547 |  |  | $ | 5,142 |  |
| Purchases (1) | 33,316 |  |  | 37,212 |  |

[0001375365-19-000084:notes:197]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-19-000084:notes:198]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2019 and 2018.

[0001375365-19-000084:notes:199]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2019 and June 30, 2019 (in thousands):

[0001375365-19-000084:notes:200]
|  | September 30, 2019 |  | June 30, 2019 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables | $ | 8,383 |  |  | $ | 7,236 |  |
| Accounts payable and accrued liabilities (1) | 36,417 |  |  | 33,928 |  |
| Other long-term liabilities (2) | 1,374 |  |  | — |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables | $ | 19,117 |  |  | $ | 14,396 |  |
| Accounts payable and accrued liabilities (1) | 41,048 |  |  | 34,417 |  |
| Other long-term liabilities (2) | 398 |  |  | — |  |

[0001375365-19-000084:notes:201]
____________________________

[0001375365-19-000084:notes:202]
(1) Includes current portion of operating lease liabilities.

[0001375365-19-000084:notes:203]
(2) Represents non-current portion of operating lease liabilities.

[0001375365-19-000084:notes:204]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture, which is accounted for using the equity method. See Note 1, "Organization and Summary of Significant Accounting Policies" for a discussion of the investment and the transactions that took place during the three months ended September 30, 2019 and 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-19-000084:notes:205]
The Company recorded provisions for income taxes of $8.6 million and $5.5 million for the three months ended September 30, 2019 and 2018, respectively. The effective tax rate was 25.3% and 21.0% for the three months ended September 30, 2019 and 2018, respectively. The effective tax rate for the three months ended September 30, 2019 is higher than that for the three months ended September 30, 2018 primarily due to an increase in unrecognized tax benefits.

[0001375365-19-000084:notes:206]
As of September 30, 2019, the Company had a liability for gross unrecognized tax benefits of $30.8 million, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three months ended September 30, 2019, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of September 30, 2019, the Company had accrued $1.8 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-19-000084:notes:207]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. The Company previously asserted that all of its foreign undistributed earnings

[0001375365-19-000084:notes:208]
were indefinitely reinvested. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for Netherlands. The Company may repatriate certain foreign earnings from Netherlands that have been previously taxed in the U.S. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-19-000084:notes:209]
[same as prior period, unchanged from 0001375365-19-000078:notes:95]

[0001375365-19-000084:notes:210]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-19-000084:notes:211]
The federal statute of limitations remains open in general for tax years ended June 30, 2016 through 2019. Various states statute of limitations remain open in general for tax years ended June 30, 2015 through 2019. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2013 through 2019. The Company does not expect its unrecognized tax benefits to change materially over the next 12 months, except for the reductions arising from the lapse of the statute of limitations. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.8 million in the next 12 months, primarily due to the lapse of the statute of limitations and settlement with the Tax Authorities. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-19-000084:notes:212]
Commitments and Contingencies

[0001375365-19-000084:notes:213]
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant.  On July 26, 2019, the Company filed a motion to dismiss the complaint, which motion remains pending with the court.  The Company believes the allegations filed are without merit, and intends to vigorously defend against the lawsuit.

[0001375365-19-000084:notes:214]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001375365-19-000084:notes:215]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-19-000084:notes:216]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2019, these remaining noncancelable commitments were $383.4 million, including $117.8 million for related parties.

[0001375365-19-000084:notes:217]
Standby Letter of Credit— In October 2018, Bank of America issued a standby letter of credit on behalf of the Company to a beneficiary for an initial value of $3.2 million to facilitate the ongoing operations of the Company. The standby letter of credit is automatically extended without amendment for successive one-year periods from the original expiration date of November 1, 2019 and will do so until canceled through written notice from the issuer. In October 2019, upon the

[0001375365-19-000084:notes:218]
Company's request, Bank of America increased the amount under the letter of credit issued to the beneficiary to $6.4 million. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-19-000084:notes:219]
[same as prior period, unchanged from 0001375365-19-000078:notes:224]

[0001375365-19-000084:notes:220]
[same as prior period, unchanged from 0001375365-19-000078:notes:225]

[0001375365-19-000084:notes:221]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-19-000084:notes:222]
|  | September 30, |  | June 30, |
| Long-lived assets: | 2019 |  | 2019 |
| United States | $ | 167,483 |  |  | $ | 162,835 |  |
| Asia | 41,383 |  |  | 41,915 |  |
| Europe | 3,623 |  |  | 2,587 |  |
|  | $ | 212,489 |  |  | $ | 207,337 |  |

[0001375365-19-000084:notes:223]
The Company’s revenue is presented on a disaggregated basis in Note 2, “Revenue,” by type of product, by geographical market, and by products sold through its indirect sales channel or to its direct customers and OEMs.


## us-gaap:SubsequentEventsTextBlock

[0001375365-19-000084:notes:224]
Subsequent Events

[0001375365-19-000084:notes:225]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. This tax restructuring is not expected to have a material impact to the estimated annual effective tax rate.
