# SMCI 8-K — 0001375365-22-000008 filed 2022-02-01

## item codes, every 8-K on or before 2022-02-04

- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2022-02-04

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-22-000008:8k_2_02:1]
EX-99.1
2
exhibit991_20211231.htm
EX-99.1

[0001375365-22-000008:8k_2_02:2]
Document

[0001375365-22-000008:8k_2_02:3]
Exhibit 99.1

[0001375365-22-000008:8k_2_02:4]
Supermicro Announces Second Quarter Fiscal Year 2022 Financial Results

[0001375365-22-000008:8k_2_02:5]
SAN JOSE, Calif. -- February 1, 2022 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced financial results for its second quarter of fiscal year 2022 ended December 31, 2021.

[0001375365-22-000008:8k_2_02:6]
Second Quarter Fiscal Year 2022 Highlights

[0001375365-22-000008:8k_2_02:7]
•Net sales of $1.17 billion versus $1.03 billion in the first quarter of fiscal year 2022 and $830 million in the same quarter of last year.

[0001375365-22-000008:8k_2_02:8]
•Gross margin of 14.0% versus 13.4% in the first quarter of fiscal year 2022 and 16.4% in the same quarter of last year.

[0001375365-22-000008:8k_2_02:9]
•Net income of $42 million versus $25 million in the first quarter of fiscal year 2022 and $28 million in the same quarter of last year.

[0001375365-22-000008:8k_2_02:10]
•Diluted net income per common share of $0.78 versus $0.48 in the first quarter of fiscal year 2022 and $0.52 in the same quarter of last year.

[0001375365-22-000008:8k_2_02:11]
•Non-GAAP diluted net income per common share of $0.88 versus $0.58 in the first quarter of fiscal year 2022 and $0.63 in the same quarter of last year.

[0001375365-22-000008:8k_2_02:12]
•Cash flow used in operations for the second quarter of fiscal year 2022 of $53 million and capital expenditures of $12 million.

[0001375365-22-000008:8k_2_02:13]
Non-GAAP gross margin for the second quarter of fiscal year 2022 was 14.0%, which adds back stock-based compensation expenses of $0.5 million. Non-GAAP diluted net income per common share for the second quarter of fiscal year 2022 was $0.88, which adds back stock-based compensation expenses of $9.2 million and controls remediation and litigation expenses of $0.6 million, net of the related tax effects.

[0001375365-22-000008:8k_2_02:14]
As of December 31, 2021, total cash and cash equivalents was $247 million and total bank debt was $316 million.

[0001375365-22-000008:8k_2_02:15]
“We are pleased to announce that our fiscal Q2 quarterly revenue grew 41% year over year, exceeding $1 billion for the third consecutive quarter, as Supermicro continues its transformation from a server hardware company into a higher value Total IT

[0001375365-22-000008:8k_2_02:16]
Solutions company,” said Charles Liang, Chairman and CEO. “Our Q2 performance significantly outperformed the industry growth rate again and was driven by strong design win momentum and record high shipments to our key global customers in the large enterprise, cloud, AI, and 5G/Telco markets. We continue to gain more top leading technology partners and global large enterprise accounts while growing market share and are accelerating our plan to achieve $10 billion in annual revenue much sooner.”

[0001375365-22-000008:8k_2_02:17]
Business Outlook and Management Commentary

[0001375365-22-000008:8k_2_02:18]
For the third quarter of fiscal year 2022 ending March 31, 2022, the Company expects net sales of $1.1 billion to $1.2 billion, GAAP net income per diluted share of $0.58 to $0.81 and non-GAAP net income per diluted share of $0.70 to $0.90. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 15% and 16.5%, respectively, and a fully diluted share count of 54.5 million shares for GAAP and fully diluted share count of 56.0 million shares for non-GAAP. The outlook for Q3 of fiscal year 2022 GAAP net income per diluted share includes approximately $8.5 million in expected stock-based compensation expense and $1.7 million in other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000008:8k_2_02:19]
For fiscal year 2022 ending June 30, 2022, the Company maintains its previous guidance of net sales of $4.2 billion to $4.6 billion, GAAP net income per diluted share of at least $2.77 and non-GAAP net income per diluted share of at least $3.20. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 15% and 17%, respectively, and a fully diluted share count of 54.1 million shares for GAAP and fully diluted share count of 55.6 million shares for non-GAAP. The outlook for fiscal year 2022 GAAP net income per diluted share includes approximately $37 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-22-000008:8k_2_02:20]
Conference Call and Webcast Information

[0001375365-22-000008:8k_2_02:21]
Supermicro will hold a public webcast at 2:00 p.m. PST today to discuss the results for its second quarter of fiscal year 2022.

[0001375365-22-000008:8k_2_02:22]
Those wishing to access the live webcast may use the following link:

[0001375365-22-000008:8k_2_02:23]
https://event.on24.com/wcc/r/3574289/D238497E507F483833A2377F81B76B13

[0001375365-22-000008:8k_2_02:24]
The conference call can be accessed by registering online at:

[0001375365-22-000008:8k_2_02:25]
https://conferencingportals.com/event/fIceWmPv

[0001375365-22-000008:8k_2_02:26]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-22-000008:8k_2_02:27]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-22-000008:8k_2_02:28]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-22-000008:8k_2_02:29]
Use of Non-GAAP Financial Measures

[0001375365-22-000008:8k_2_02:30]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses and other expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses, special performance bonuses, controls remediation and litigation expenses and other non-recurring expenses, and excludes a credit from an executive SEC settlement, which are all adjusted for the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of gross margin to non-GAAP gross margin and from diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-22-000008:8k_2_02:31]
About Super Micro Computer, Inc.

[0001375365-22-000008:8k_2_02:32]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI and 5G Telco/Edge IT Infrastructure. We are transforming to being a Total IT Solutions provider with server, AI, storage, IoT and switch systems, software and services while continuing to deliver advanced high-volume motherboard, power and chassis products. The products are designed and manufactured in-house (in US, Taiwan and Netherlands) leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power and cooling solutions (air conditioned, free air cooling or liquid cooling).

[0001375365-22-000008:8k_2_02:33]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-22-000008:8k_2_02:34]
Investor Relations Contact

[0001375365-22-000008:8k_2_02:35]
Nicole Noutsios

[0001375365-22-000008:8k_2_02:36]
email: ir@supermicro.com

[0001375365-22-000008:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000008:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-22-000008:8k_2_02:39]
(in thousands)

[0001375365-22-000008:8k_2_02:40]
(unaudited)

[0001375365-22-000008:8k_2_02:41]
|  | December 31, |  | June 30, |
|  | 2021 |  | 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 247,407 |  |  | $ | 232,266 |  |
| Accounts receivable, net of allowances | 497,431 |  |  | 463,834 |  |
| Inventories | 1,393,672 |  |  | 1,040,964 |  |
| Prepaid expenses and other current assets | 154,778 |  |  | 130,195 |  |
| Total current assets | 2,293,288 |  |  | 1,867,259 |  |
| Investment in equity investee | 4,459 |  |  | 4,578 |  |
| Property, plant and equipment, net | 280,282 |  |  | 274,713 |  |
| Deferred income taxes, net | 61,837 |  |  | 63,288 |  |
| Other assets | 36,736 |  |  | 32,126 |  |
| Total assets | $ | 2,676,602 |  |  | $ | 2,241,964 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 695,180 |  |  | $ | 612,336 |  |
| Accrued liabilities | 171,010 |  |  | 178,850 |  |
| Income taxes payable | 14,464 |  |  | 12,741 |  |
| Short-term debt | 176,904 |  |  | 63,490 |  |
| Deferred revenue | 142,021 |  |  | 101,479 |  |
| Total current liabilities | 1,199,579 |  |  | 968,896 |  |
| Deferred revenue, non-current | 110,531 |  |  | 100,838 |  |
| Long-term debt, net of debt issuance costs | 139,032 |  |  | 34,700 |  |
| Other long-term liabilities | 40,615 |  |  | 41,132 |  |
| Total liabilities | 1,489,757 |  |  | 1,145,566 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 460,990 |  |  | 438,012 |  |
| Accumulated other comprehensive income | 549 |  |  | 453 |  |
| Retained earnings | 725,129 |  |  | 657,760 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,186,668 |  |  | 1,096,225 |  |
| Noncontrolling interest | 177 |  |  | 173 |  |
| Total stockholders’ equity | 1,186,845 |  |  | 1,096,398 |  |
| Total liabilities and stockholders’ equity | $ | 2,676,602 |  |  | $ | 2,241,964 |  |

[0001375365-22-000008:8k_2_02:42]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000008:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-22-000008:8k_2_02:44]
(in thousands except per share amounts)

[0001375365-22-000008:8k_2_02:45]
(unaudited)

[0001375365-22-000008:8k_2_02:46]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 1,172,419 |  |  | $ | 830,306 |  |  | $ | 2,205,149 |  |  | $ | 1,592,556 |  |
| Cost of sales | 1,008,676 |  |  | 694,211 |  |  | 1,903,267 |  |  | 1,326,546 |  |
| Gross profit | 163,743 |  |  | 136,095 |  |  | 301,882 |  |  | 266,010 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 65,471 |  |  | 52,729 |  |  | 130,614 |  |  | 107,527 |  |
| Sales and marketing | 21,960 |  |  | 20,740 |  |  | 43,584 |  |  | 41,032 |  |
| General and administrative | 25,263 |  |  | 25,261 |  |  | 47,507 |  |  | 49,640 |  |
| Total operating expenses | 112,694 |  |  | 98,730 |  |  | 221,705 |  |  | 198,199 |  |
| Income from operations | 51,049 |  |  | 37,365 |  |  | 80,177 |  |  | 67,811 |  |
| Other expense, net | (607) |  |  | (2,539) |  |  | (557) |  |  | (3,380) |  |
| Interest expense | (1,150) |  |  | (569) |  |  | (1,954) |  |  | (1,243) |  |
| Income before income tax provision | 49,292 |  |  | 34,257 |  |  | 77,666 |  |  | 63,188 |  |
| Income tax provision | (7,599) |  |  | (5,108) |  |  | (10,924) |  |  | (8,768) |  |
| Share of income (loss) from equity investee, net of taxes | 239 |  |  | (1,475) |  |  | 627 |  |  | (145) |  |
| Net income | $ | 41,932 |  |  | $ | 27,674 |  |  | $ | 67,369 |  |  | $ | 54,275 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.82 |  |  | $ | 0.54 |  |  | $ | 1.32 |  |  | $ | 1.05 |  |
| Diluted | $ | 0.78 |  |  | $ | 0.52 |  |  | $ | 1.27 |  |  | $ | 1.00 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 51,314 |  |  | 51,499 |  |  | 51,055 |  |  | 51,914 |  |
| Diluted | 53,511 |  |  | 53,584 |  |  | 53,213 |  |  | 54,005 |  |

[0001375365-22-000008:8k_2_02:47]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-22-000008:8k_2_02:48]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of sales | $ | 471 |  |  | $ | 407 |  |  | $ | 918 |  |  | $ | 910 |  |
| Research and development | 4,103 |  |  | 3,339 |  |  | 7,983 |  |  | 7,041 |  |
| Sales and marketing | 496 |  |  | 497 |  |  | 1,013 |  |  | 1,014 |  |
| General and administrative | 4,106 |  |  | 2,210 |  |  | 6,277 |  |  | 4,658 |  |
| Stock-based compensation expense | $ | 9,176 |  |  | $ | 6,453 |  |  | $ | 16,191 |  |  | $ | 13,623 |  |

[0001375365-22-000008:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000008:8k_2_02:50]
SELECTED CASH FLOW INFORMATION

[0001375365-22-000008:8k_2_02:51]
(in thousands)

[0001375365-22-000008:8k_2_02:52]
(unaudited)

[0001375365-22-000008:8k_2_02:53]
|  | Six Months EndedDecember 31, |
|  | 2021 |  | 2020 |
| Net cash provided by (used in) operating activities | $ | (187,722) |  |  | $ | 183,802 |  |
| Net cash used in investing activities | (24,306) |  |  | (25,551) |  |
| Net cash provided by (used in) financing activities | 227,173 |  |  | (53,697) |  |
| Effect of exchange rate fluctuations on cash | (9) |  |  | 540 |  |
| Net increase in cash, cash equivalents and restricted cash | 15,136 |  |  | 105,094 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 233,449 |  |  | 212,390 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 248,585 |  |  | $ | 317,484 |  |

[0001375365-22-000008:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000008:8k_2_02:55]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000008:8k_2_02:56]
(in thousands except per share amounts)

[0001375365-22-000008:8k_2_02:57]
(unaudited)

[0001375365-22-000008:8k_2_02:58]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2021 |  |  | 2020 |  | 2021 |  | 2020 |
| GAAP GROSS PROFIT | $ | 163,743 |  |  |  | $ | 136,095 |  |  | 301,882 |  |  | $ | 266,010 |  |
| Stock-based compensation | 471 |  |  |  | 407 |  |  | 918 |  |  | 910 |  |
| Other expenses | — |  |  |  | — |  |  | 295 |  |  | 20 |  |
| NON-GAAP GROSS PROFIT | $ | 164,214 |  |  |  | $ | 136,502 |  |  | $ | 303,095 |  |  | $ | 266,940 |  |
| GAAP GROSS MARGIN | 14.0 | % |  |  | 16.4 | % |  | 13.7 | % |  | 16.7 | % |
| Stock-based compensation expenses | — | % |  |  | — | % |  | — | % |  | 0.1 | % |
| Other expenses | — | % |  |  | — | % |  | — | % |  | — | % |
| NON-GAAP GROSS MARGIN | 14.0 | % |  |  | 16.4 | % |  | 13.7 | % |  | 16.8 | % |
| GAAP OPERATING EXPENSE | $ | 112,694 |  |  |  | $ | 98,730 |  |  | $ | 221,705 |  |  | $ | 198,199 |  |
| Stock-based compensation | (8,705) |  |  |  | (6,046) |  |  | (15,273) |  |  | (12,713) |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | 2,122 |  |
| Special performance bonuses | — |  |  |  | (2,531) |  |  | (158) |  |  | (2,621) |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | (221) |  |
| Controls remediation and litigation expenses | (597) |  |  |  | — |  |  | (1,923) |  |  | — |  |
| NON-GAAP OPERATING EXPENSE | $ | 103,392 |  |  |  | $ | 90,153 |  |  | $ | 204,351 |  |  | $ | 184,766 |  |
| GAAP INCOME FROM OPERATIONS | $ | 51,049 |  |  |  | $ | 37,365 |  |  | $ | 80,177 |  |  | $ | 67,811 |  |
| Stock-based compensation | 9,176 |  |  |  | 6,453 |  |  | 16,191 |  |  | 13,623 |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | (2,122) |  |
| Special performance bonuses | — |  |  |  | 2,531 |  |  | 453 |  |  | 2,621 |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | 241 |  |
| Controls remediation and litigation expenses | 597 |  |  |  | — |  |  | 1,923 |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 60,822 |  |  |  | $ | 46,349 |  |  | $ | 98,744 |  |  | $ | 82,174 |  |
| GAAP TAX EXPENSE | $ | 7,599 |  |  |  | 5,108 |  |  | 10,924 |  |  | $ | 8,768 |  |
| Adjustments to tax provision | 3,339 |  |  |  | 1,977 |  |  | 6,169 |  |  | 3,160 |  |
| NON-GAAP TAX EXPENSE | $ | 10,938 |  |  |  | $ | 7,085 |  |  | $ | 17,093 |  |  | $ | 11,928 |  |
| GAAP NET INCOME | $ | 41,932 |  |  |  | $ | 27,674 |  |  | $ | 67,369 |  |  | $ | 54,275 |  |
| Stock-based compensation | 9,176 |  |  |  | 6,453 |  |  | 16,191 |  |  | 13,623 |  |
| Executive SEC settlement | — |  |  |  | — |  |  | — |  |  | (2,122) |  |
| Special performance bonuses | — |  |  |  | 2,531 |  |  | 453 |  |  | 2,621 |  |
| Other expenses | — |  |  |  | — |  |  | — |  |  | 241 |  |
| Controls remediation and litigation expenses | 597 |  |  |  | — |  |  | 1,923 |  |  | — |  |
| Adjustments to tax provision | (3,339) |  |  |  | (1,977) |  |  | (6,169) |  |  | (3,160) |  |
| NON-GAAP NET INCOME | $ | 48,366 |  |  |  | $ | 34,681 |  |  | $ | 79,767 |  |  | $ | 65,478 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.82 |  |  |  | 0.54 |  |  | $ | 1.32 |  |  | $ | 1.05 |  |
| Impact of Non-GAAP adjustments | 0.12 |  |  |  | 0.13 |  |  | 0.24 |  |  | 0.21 |  |

[0001375365-22-000008:8k_2_02:59]
SUPER MICRO COMPUTER, INC.

[0001375365-22-000008:8k_2_02:60]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-22-000008:8k_2_02:61]
(in thousands except per share amounts)

[0001375365-22-000008:8k_2_02:62]
(unaudited)

[0001375365-22-000008:8k_2_02:63]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2021 |  |  | 2020 |  | 2021 |  | 2020 |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.94 |  |  |  | $ | 0.67 |  |  | $ | 1.56 |  |  | $ | 1.26 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.78 |  |  |  | 0.52 |  |  | 1.27 |  |  | 1.00 |  |
| Impact of Non-GAAP adjustments | 0.10 |  |  |  | 0.11 |  |  | 0.19 |  |  | 0.18 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.88 |  |  |  | $ | 0.63 |  |  | $ | 1.46 |  |  | $ | 1.18 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 51,314 |  |  |  | 51,499 |  |  | 51,055 |  |  | 51,914 |  |
| BASIC - NON-GAAP | 51,314 |  |  |  | 51,499 |  |  | 51,055 |  |  | 51,914 |  |
| DILUTED – GAAP | 53,511 |  |  |  | 53,584 |  |  | 53,213 |  |  | 54,005 |  |
| DILUTED - NON-GAAP | 54,947 |  |  |  | 55,133 |  |  | 54,655 |  |  | 55,508 |  |
