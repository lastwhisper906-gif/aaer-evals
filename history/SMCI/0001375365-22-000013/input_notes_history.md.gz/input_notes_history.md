# SMCI note change history — 0001375365-21-000083 → 0001375365-22-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss.  Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes.  Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales.  The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO.  Discovery has commenced, and the Court has calendared a hearing on class certification for April 21, 2022. The Company intends to defend the lawsuit vigorously.
  (was, 2021-11-05, similarity 0.9978):
[0001375365-21-000083:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss.  Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes.  Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales.  The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO.  Discovery has commenced, and the Court has calendared a hearing on class certification for January 22, 2022. The Company intends to defend the lawsuit vigorously.

- changed (2022-02-04):
[0001375365-22-000013:note_history:2]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021, and the Court has continued the hearing to March 23, 2022. The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously.
  (was, 2021-11-05, similarity 0.978):
[0001375365-21-000083:note_history:2]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021, and the Court has calendared the hearing for January 26, 2022. The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously.

- changed (2022-02-04):
[0001375365-22-000013:note_history:3]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice.  On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval.  On December 16, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval.  The Company provided notice as required by the Court on December 21, 2021. The Court order notes that, if no shareholder seeks to intervene during the 45-day notice period ending on February 4, 2022, plaintiff may file an administrative motion requesting that the Court dismiss the lawsuit with prejudice.
  (was, 2021-11-05, similarity 0.8936):
[0001375365-21-000083:note_history:3]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021. Rather than oppose defendants’ motions, plaintiff informed defendants that plaintiff was prepared to dismiss his action with prejudice.  On September 29, 2021, the parties submitted a stipulation for dismissal with prejudice as to the named plaintiff to the Court for its approval.  On October 27, 2021, the Court issued an order for the parties to submit within 30 days a plan of notice of dismissal for the Court’s approval.  The Court noted that, if no shareholder seeks to intervene during the notice period, plaintiff may file an administrative motion requesting that the Court dismiss the lawsuit with prejudice

- changed (2022-02-04):
[0001375365-22-000013:note_history:4]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations in the first  quarter of fiscal 2021. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense in the first quarter of fiscal 2021.
  (was, 2021-11-05, similarity 0.7658):
[0001375365-21-000083:note_history:4]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

- changed (2022-02-04):
[0001375365-22-000013:note_history:5]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2021 and any prior periods.
  (was, 2021-11-05, similarity 0.9893):
[0001375365-21-000083:note_history:5]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2021 and any prior periods.

- changed (2022-02-04):
[0001375365-22-000013:note_history:6]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2021, these remaining noncancelable commitments were $816.0 million, including $100.3 million for related parties.
  (was, 2021-11-05, similarity 0.6362):
[0001375365-21-000083:note_history:6]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2021, these remaining noncancelable commitments were $508.2 million, including $124.4 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2022.
  (was, 2021-11-05, similarity 0.7142):
[0001375365-21-000083:note_history:7]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2021 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2022.

- changed (2022-02-04):
[0001375365-22-000013:note_history:8]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 26.9% and 20.0% of total purchases for the three months ended December 31, 2021 and 2020, respectively, and 23.1% and 20.9% of total purchases for the six months ended December 31, 2021 and 2020, respectively. Purchases from Ablecom, and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 9.4% and 7.3% of total cost of sales for the three months ended December 31, 2021 and 2020, respectively, and a combined 9.5% and 8.2% of total cost of sales for the six months ended December 31, 2021 and 2020, respectively.
  (was, 2021-11-05, similarity 0.845):
[0001375365-21-000083:note_history:8]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.1% and 22.0% of total purchases for the three months ended September 30, 2021 and 2020, respectively. Purchases from Ablecom, and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 9.6% and 9.2% of total cost of sales for the three months ended September 30, 2021 and 2020, respectively.

- changed (2022-02-04):
[0001375365-22-000013:note_history:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2021 and 2020. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2021, whereas one customer accounted for 13.5% of accounts receivable, net as of June 30, 2021.
  (was, 2021-11-05, similarity 0.6611):
[0001375365-21-000083:note_history:9]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2021 and 2020. One customer accounted for 11.7% and 13.5% of accounts receivable, net as of September 30, 2021 and June 30, 2021, respectively.

- changed (2022-02-04):
[0001375365-22-000013:note_history:10]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 which provided for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. As the amendment had changes not related to LIBOR replacement, optional expedients under this guidance cannot be elected. The Company is currently evaluating the overall impact of adoption of the guidance on its consolidated financial statements and disclosures.
  (was, 2021-11-05, similarity 0.9193):
[0001375365-21-000083:note_history:10]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 which provided for a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. As the amendment had changes not related to LIBOR replacement, optional expedients under this guidance cannot be elected. The E.SUN Credit Facility will terminate on July 29, 2022 before the phase out of LIBOR. Therefore, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:11]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2021 and June 30, 2021 consisted of the following (in thousands):
  (was, 2021-11-05, similarity 0.9829):
[0001375365-21-000083:note_history:11]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of September 30, 2021 and June 30, 2021 consisted of the following (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:12]
|  | December 31, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 60,588 |  |  | $ | — |  |
| CTBC Bank | 97,000 |  |  | 18,000 |  |
| E.SUN Bank | 16,500 |  |  | 20,400 |  |
| Total line of credit | 174,088 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | — |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 40,435 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 3,522 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 18,346 |  |  | — |  |
| Mega Bank term loan, due September 15, 2026 | 43,388 |  |  | — |  |
| Chang Hwa Bank term loan due October 15, 2026 | 36,157 |  |  | — |  |
| Total term loans | 141,848 |  |  | 59,790 |  |
| Total debt | 315,936 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 176,904 |  |  | 63,490 |  |
| Debt, Non-current | $ | 139,032 |  |  | $ | 34,700 |  |
  (was, 2021-11-05, similarity 0.7311):
[0001375365-21-000083:note_history:12]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 110,193 |  |  | $ | — |  |
| CTBC Bank | 68,100 |  |  | 18,000 |  |
| E.SUN Bank | 30,000 |  |  | 20,400 |  |
| Total line of credit | 208,293 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | 25,195 |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,018 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 1,434 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 4,868 |  |  | — |  |
| Total term loans | 70,515 |  |  | 59,790 |  |
| Total debt | 278,808 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 233,674 |  |  | 63,490 |  |
| Debt, Non-current | $ | 45,134 |  |  | $ | 34,700 |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:13]
As of December 31, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $60.6 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2021 and June 30, 2021 were 1.50%. The balance of debt issuance costs outstanding as of December 31, 2021 and June 30, 2021 were $0.5 million. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of December 31, 2021, the Company's available borrowing capacity was $139.4 million, subject to the borrowing base limitation and compliance with other applicable terms.
  (was, 2021-11-05, similarity 0.7403):
[0001375365-21-000083:note_history:13]
As of September 30, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $110.2 million. As of June 30, 2021, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2021 and June 30, 2021 were 1.50%. The balance of debt issuance costs outstanding as of September 30, 2021 and June 30, 2021 were $0.5 million. The

- changed (2022-02-04):
[0001375365-22-000013:note_history:14]
As of December 31, 2021 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $40.4 million and $34.7 million, respectively. The interest rates for these loans were 0.45% per annum as of December 31, 2021 and June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $3.5 million at December 31, 2021. The interest rates for this loan was 0.65% per annum as of December 31, 2021. As of December 31, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.
  (was, 2021-11-05, similarity 0.821):
[0001375365-21-000083:note_history:14]
As of September 30, 2021 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $39.0 million and $34.7 million, respectively. The interest rates for these loans were 0.45% per annum as of September 30, 2021 and June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $1.4 million at September 30, 2021. The interest rates for these loans were 0.65% per annum as of September 30, 2021. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

- changed (2022-02-04):
[0001375365-22-000013:note_history:15]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan was denominated in NTD and remeasured into U.S. dollars of $0.0 million and $25.1 million at December 31, 2021 and June 30, 2021, respectively. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021.  The interest rate for the 2021 CTBC Credit Facility term loan was 0.75% per annum as of June 30, 2021.  As of December 31, 2021 and June 30, 2021, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were $97.0 million and $18.0 million, respectively. The interest rates for these loans were approximately 1.00% per annum as of December 31, 2021. The interest rate was 0.98% per annum as of June 30, 2021. As of December 31, 2021, the amount available for future borrowing under the 2021 CTBC Credit Facility was $8.0 million. As of December 31, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $78.2 million. As of December 31, 2021, all financial covenants under the 2021 CTBC Credit Lines were satisfied.
  (was, 2021-11-05, similarity 0.621):
[0001375365-21-000083:note_history:15]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.2 million and $25.1 million at September 30, 2021 and June 30, 2021, respectively. The interest rate for these loans were 0.74% and 0.75% per annum as of September 30, 2021 and June 30, 2021, respectively.  As of September 30, 2021, and June 30, 2021, the outstanding borrowings of 2021 CTBC Credit Facility revolving line of credit were $68.1 million and $18.0 million, respectively. The interest rates for these loans ranged from approximately 0.94% to 0.95% per annum as of September 30, 2021. The interest rate was 0.98% per annum as of June 30, 2021. As of September 30, 2021, the amount available for future borrowing under the 2021 CTBC Credit Facility was $11.7 million. As of September 30, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $77.7 million. As of September 30, 2021, all financial covenants under the 2021 CTBC Credit Lines were satisfied.

- changed (2022-02-04):
[0001375365-22-000013:note_history:16]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility expired on September 18, 2021.
  (was, 2021-11-05, similarity 0.9792):
[0001375365-21-000083:note_history:16]
The Company through its Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of US$30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility was until September 18, 2021.

- changed (2022-02-04):
[0001375365-22-000013:note_history:17]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements to be reviewed on a yearly basis at fiscal year end.
  (was, 2021-11-05, similarity 0.9801):
[0001375365-21-000083:note_history:17]
On September 13, 2021 (the “E.SUN Bank Effective Date”), the Company through its Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Subsidiary has an overdue liability at another financial organization. There are various financial covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements.

- changed (2022-02-04):
[0001375365-22-000013:note_history:18]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of December 31, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $18.3 million and the interest rates for these loans were 0.995% per annum. As of December 31, 2021 and June 30, 2021, the amounts outstanding under the Import Loan were $16.5 million and $20.4 million, respectively. The interest rates for the quarter ended December 31, 2021 is 0.96%.  The interest rate for the quarter ended June 30, 2021 ranges approximately from 1.00% to 1.29% per annum. At December 31, 2021, the amount available for future borrowing under the Import Loan was $13.5 million.
  (was, 2021-11-05, similarity 0.8049):
[0001375365-21-000083:note_history:18]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and  development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of September 30, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $4.9 million and the interest rates for these loans were 0.995% per annum. As of September 30, 2021 and June 30, 2021, the amounts outstanding under the Import Loan were $30.0 and $20.4 million, respectively. The interest rates for these loans ranged approximately from 0.96% to 1.23% and 1.00% to 1.29% per annum as of September 30, 2021 and June 30, 2021, respectively. At September 30, 2021, the amount available for future borrowing under the Import Loan was $0.0 million and all financial covenants under the 2021 E.SUN Bank Credit Facility were satisfied.

- changed (2022-02-04):
[0001375365-22-000013:note_history:19]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable.  As of December 31, 2021, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $43.4 million and the interest rates ranged is 0.65% to 0.85% per annum.
  (was, 2021-11-05, similarity 0.9531):
[0001375365-21-000083:note_history:19]
On September 13, 2021 (the “Mega Bank Effective Date”), the Company through its Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of September 30, 2021, there were no outstanding borrowings under the Mega Bank Credit Facility.

- changed (2022-02-04):
[0001375365-22-000013:note_history:20]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed. As of December 31, 2021, the total outstanding borrowings under the Chang Hwa Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $36.2 million and the interest rate is 0.8% per annum.
  (was, 2021-11-05, similarity 0.8972):
[0001375365-21-000083:note_history:20]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), the Company through its Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments.  The Chang Hwa Bank Credit Facility has customary default provisions permitting the Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed.

- added (2022-02-04):
[0001375365-22-000013:note_history:21]
HSBC Bank

- added (2022-02-04):
[0001375365-22-000013:note_history:22]
HSBC Bank Credit Facility

- added (2022-02-04):
[0001375365-22-000013:note_history:23]
On January 7, 2022 (the “HSBC Bank Effective Date”), the Company through its Taiwan subsidiary entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with the Taiwan affiliate of HSBC Bank (“HSBC Bank”).  The Loan Agreement provides for borrowings in the form of loans, export/import financings, overdrafts, commercial paper guaranties, and other types of drawdown instruments.  The Loan Agreement has customary default provisions permitting HSBC Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event its Taiwan subsidiary fails to make payment of sums under another agreement which permits acceleration of maturity of such indebtedness. The Company is not a guarantor of the Loan Agreement.

- added (2022-02-04):
[0001375365-22-000013:note_history:24]
Terms for specific drawdown instruments issued under the Loan Agreement, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, may be set forth in Facility Letters (a “Facility Letter”) negotiated with the HSBC Bank. Under a Facility Letter entered into on the HSBC Bank Effective Date, its Taiwan subsidiary and the HSBC Bank have agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on the HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date.

- removed (2022-02-04):
[0001375365-21-000083:note_history:25]
Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2021, the Company's available borrowing capacity was $89.8 million, subject to the borrowing base limitation and compliance with other applicable terms.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:26]
Short-term and long-term debt obligations as of December 31, 2021 and June 30, 2021 consisted of the following (in thousands):
  (was, 2021-11-05, similarity 0.9785):
[0001375365-21-000083:note_history:26]
Short-term and long-term debt obligations as of September 30, 2021 and June 30, 2021 consisted of the following (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:27]
|  | December 31, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 60,588 |  |  | $ | — |  |
| CTBC Bank | 97,000 |  |  | 18,000 |  |
| E.SUN Bank | 16,500 |  |  | 20,400 |  |
| Total line of credit | 174,088 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | — |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 40,435 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 3,522 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 18,346 |  |  | — |  |
| Mega Bank term loan, due September 15, 2026 | 43,388 |  |  | — |  |
| Chang Hwa Bank term loan due October 15, 2026 | 36,157 |  |  | — |  |
| Total term loans | 141,848 |  |  | 59,790 |  |
| Total debt | 315,936 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 176,904 |  |  | 63,490 |  |
| Debt, Non-current | $ | 139,032 |  |  | $ | 34,700 |  |
  (was, 2021-11-05, similarity 0.7311):
[0001375365-21-000083:note_history:27]
|  | September 30, |  | June 30, |
|  | 2021 |  | 2021 |
| Line of credit: |  |  |  |
| Bank of America | $ | 110,193 |  |  | $ | — |  |
| CTBC Bank | 68,100 |  |  | 18,000 |  |
| E.SUN Bank | 30,000 |  |  | 20,400 |  |
| Total line of credit | 208,293 |  |  | 38,400 |  |
| Term loans: |  |  |  |
| CTBC Bank term loan, due August 31, 2022 | $ | 25,195 |  |  | $ | 25,090 |  |
| CTBC Bank term loan, due June 4, 2030 | 39,018 |  |  | 34,700 |  |
| CTBC Bank term loan, due December 27, 2027 | 1,434 |  |  | — |  |
| E.SUN Bank term loan, due September 15, 2026 | 4,868 |  |  | — |  |
| Total term loans | 70,515 |  |  | 59,790 |  |
| Total debt | 278,808 |  |  | 98,190 |  |
| Short-term debt and current portion of long-term debt | 233,674 |  |  | 63,490 |  |
| Debt, Non-current | $ | 45,134 |  |  | $ | 34,700 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:28]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2021-11-05, similarity 0.9972):
[0001375365-21-000083:note_history:28]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- added (2022-02-04):
[0001375365-22-000013:note_history:29]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 88.3% and 91.6% of the chassis included in the products sold by the Company during the three months ended December 31, 2021 and 2020, respectively, and 90.3% and 92.6% of the chassis included in the products sold by the Company during the six months ended December 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2022-02-04):
[0001375365-22-000013:note_history:30]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $49.4 million and $40.2 million at December 31, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2021-11-05, similarity 0.9966):
[0001375365-21-000083:note_history:30]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $36.7 million and $40.2 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2022-02-04):
[0001375365-22-000013:note_history:31]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $50.9 million and $71.0 million at December 31, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2021-11-05, similarity 0.9946):
[0001375365-21-000083:note_history:31]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $87.8 million and $71.0 million at September 30, 2021 and June 30, 2021, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2022-02-04):
[0001375365-22-000013:note_history:32]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of December 31, 2021 and June 30, 2021, the Company had unamortized deferred gain balance of $0 million and $1.0 million, respectively, in accrued liabilities in the Company’s condensed consolidated balance sheets.
  (was, 2021-11-05, similarity 0.9264):
[0001375365-21-000083:note_history:32]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2021 and June 30, 2021, the Company had unamortized deferred gain balance of $0.5 million and $1.0 million, respectively, in accrued liabilities and none in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- changed (2022-02-04):
[0001375365-22-000013:note_history:33]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of the third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2021. No impairment charge was recorded for the three and six months ended December 31, 2021 and 2020, respectively.
  (was, 2021-11-05, similarity 0.969):
[0001375365-21-000083:note_history:33]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of the third party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2021. No impairment charge was recorded for the three months ended September 30, 2021 and 2020, respectively.

- changed (2022-02-04):
[0001375365-22-000013:note_history:34]
The Company had the following balances related to transactions with its related parties as of December 31, 2021 and June 30, 2021 (in thousands):
  (was, 2021-11-05, similarity 0.9815):
[0001375365-21-000083:note_history:34]
The Company had the following balances related to transactions with its related parties as of September 30, 2021 and June 30, 2021 (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:35]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 |
| Accounts receivable | $ | 1 |  | $ | 2 |  | $ | 264 |  | $ | 198 |  | $ | 34,267 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 34,532 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,933 |  | $ | 5,575 |  | $ | 29,847 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 222 |  | $ | 89 |  | $ | 35,002 |  | $ | 23,837 |  |
| Accounts payable | $ | 41,725 |  | $ | 38,152 |  | $ | 54,311 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 96,036 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 2,829 |  | $ | 3,042 |  | $ | 17,200 |  | $ | 14,486 |  | $ | — |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,029 |  | $ | 18,528 |  |
  (was, 2021-11-05, similarity 0.8955):
[0001375365-21-000083:note_history:35]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 1,332 |  | $ | 198 |  | $ | 12,659 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 13,993 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,428 |  | $ | 5,575 |  | $ | 21,690 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 165 |  | $ | 89 |  | $ | 26,283 |  | $ | 23,837 |  |
| Accounts payable | $ | 40,730 |  | $ | 38,152 |  | $ | 37,024 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 77,754 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 1,813 |  | $ | 3,042 |  | $ | 17,790 |  | $ | 14,486 |  | $ | 500 |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,103 |  | $ | 18,528 |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:36]
The Company's results from transactions with its related parties for each of the three months ended December 31, 2021 and 2020, are as follows (in thousands):
  (was, 2021-11-05, similarity 0.9833):
[0001375365-21-000083:note_history:36]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2022-02-04):
[0001375365-22-000013:note_history:37]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 3 |  | $ | (31) |  | $ | 3,302 |  | $ | 5,572 |  | $ | 38,311 |  | $ | 13,165 |  | $ | — |  | $ | — |  | $ | 41,616 |  | $ | 18,706 |  |
| Purchases - inventory | $ | 47,520 |  | $ | 21,818 |  | $ | 46,821 |  | $ | 29,017 |  | $ | — |  | $ | — |  | $ | 2,387 |  | $ | 697 |  | $ | 96,728 |  | $ | 51,532 |  |
| Purchases - other miscellaneous items | $ | 2,867 |  | $ | 2,762 |  | $ | 347 |  | $ | 626 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,214 |  | $ | 3,388 |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:38]
The Company's results from transactions with its related parties for each of the six months ended December 31, 2021 and 2020, are as follows (in thousands):
  (was, 2021-11-05, similarity 0.8954):
[0001375365-21-000083:note_history:38]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2022-02-04):
[0001375365-22-000013:note_history:39]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 10 |  | $ | (27) |  | $ | 19,004 |  | $ | 18,871 |  | $ | 53,524 |  | $ | 19,577 |  | $ | — |  | $ | — |  | $ | 72,538 |  | $ | 38,421 |  |
| Purchases - inventory | $ | 98,309 |  | $ | 45,689 |  | $ | 82,050 |  | $ | 63,215 |  | $ | — |  | $ | — |  | $ | 4,056 |  | $ | 1,488 |  | $ | 184,415 |  | $ | 110,392 |  |
| Purchases - other miscellaneous items | $ | 4,983 |  | $ | 5,480 |  | $ | 686 |  | $ | 960 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,669 |  | $ | 6,440 |  |

- added (2022-02-04):
[0001375365-22-000013:note_history:40]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2021 and 2020, are as follows (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:41]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | 1 |  | $ | (29) |  | $ | (66) |  | $ | 311 |  | $ | (25,789) |  | $ | (6,586) |  | $ | — |  | $ | — |  | $ | (25,854) |  | $ | (6,304) |  |
| Changes in other receivable | $ | 641 |  | $ | 308 |  | $ | (11,673) |  | $ | 7,246 |  | $ | — |  | $ | — |  | $ | (133) |  | $ | 75 |  | $ | (11,165) |  | $ | 7,629 |  |
| Changes in accounts payable | $ | 3,573 |  | $ | (13,921) |  | $ | 22,367 |  | $ | (10,191) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 25,940 |  | $ | (24,112) |  |
| Changes in accrued liabilities | $ | (212) |  | $ | 867 |  | $ | 2,713 |  | $ | (5,734) |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,501 |  | $ | (4,867) |  |
| Changes in other long-term liabilities | $ | — |  | $ | (513) |  | $ | — |  | $ | (158) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | — |  | $ | (1,671) |  |
| Purchases of property, plant and equipment | $ | 1,678 |  | $ | 2,968 |  | $ | 92 |  | $ | 90 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,770 |  | $ | 3,058 |  |
| Unpaid property, plant and equipment | $ | 2,312 |  | $ | 2,976 |  | $ | — |  | 80 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,312 |  | $ | 3,056 |  |
  (was, 2021-11-05, similarity 0.6253):
[0001375365-21-000083:note_history:41]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | — |  | $ | (27) |  | $ | (1,134) |  | $ | 353 |  | $ | (4,181) |  | $ | 7,184 |  | — |  | — |  | $ | (5,315) |  | $ | 7,510 |  |
| Changes in other receivable | $ | 1,147 |  | $ | 4,243 |  | $ | (3,517) |  | $ | 7,840 |  | — |  | — |  | $ | (76) |  | $ | 75 |  | $ | (2,446) |  | $ | 12,158 |  |
| Changes in accounts payable | $ | 2,578 |  | $ | (14,952) |  | $ | 5,080 |  | $ | (9,724) |  | — |  | — |  | — |  | — |  | $ | 7,658 |  | $ | (24,676) |  |
| Changes in accrued liabilities | $ | (1,229) |  | $ | (203) |  | $ | 3,304 |  | $ | (3,374) |  | $ | (500) |  | — |  | — |  | — |  | $ | 1,575 |  | $ | (3,577) |  |
| Changes in other long-term liabilities | — |  | $ | 47 |  | — |  | $ | (77) |  | — |  | $ | (500) |  | — |  | — |  | — |  | $ | (530) |  |
| Purchases of property, plant and equipment | $ | 338 |  | $ | 2,140 |  | $ | 62 |  | $ | 90 |  | — |  | — |  | — |  | — |  | $ | 400 |  | $ | 2,230 |  |
| Unpaid property, plant and equipment | $ | 1,360 |  | $ | 1,664 |  | — |  | — |  | — |  | — |  | — |  | — |  | $ | 1,360 |  | $ | 1,664 |  |

- added (2022-02-04):
[0001375365-22-000013:note_history:42]
Tripartite Agreement

- added (2022-02-04):
[0001375365-22-000013:note_history:43]
On November 8, 2021, Super Micro Computer Inc., Taiwan (the “Subsidiary”), a Taiwan corporation and wholly-owned subsidiary of the Company, entered into a Tripartite Agreement (the “Agreement”) with Ablecom and Compuware related to a three-way purchase of land.

- added (2022-02-04):
[0001375365-22-000013:note_history:44]
Pursuant to the Agreement, the Subsidiary will participate in purchasing 33.33% of the 137,225.97 square meters (approximately 34 acres) of land Ablecom has agreed to acquire from third-party landowners in proximity to the Company’s campus in Bade, Taiwan. Compuware will acquire 17.21% of such land and Ablecom will retain the remaining 49.46% of the land. Under the Agreement, fees and costs related to such land purchase would be borne by the parties according to their proportionate share of the land purchased. The Company intends to fund its proportionate share of the land purchased under the Agreement which is estimated to be approximately NTD789 million (or approximately US$28.3 million) from either available cash and/or borrowings under loan agreements the Subsidiary has in Taiwan. Amounts payable related to the purchase of the land are due in three installments based upon the achievement of specified milestones. The transaction is subject to various customary conditions precedent, including the receipt of government approvals, the discharge of mortgages and leases on the land, and the completion of due diligence. As of December 31, 2021, due diligence and discussions with government officials are continuing, and no installment payments have been made with respect to the transaction. If the transaction does not close within 12 months, Ablecom may offer the land to other parties.

- removed (2022-02-04):
[0001375365-21-000083:note_history:45]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 92.5% and 93.6% of the chassis included in the products sold by the Company during the three months ended September 30, 2021 and 2020, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2022-02-04):
[0001375365-21-000083:note_history:46]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 7 |  | $ | 5 |  | $ | 15,702 |  | $ | 13,299 |  | $ | 15,213 |  | $ | 6,412 |  | — |  | — |  | $ | 30,922 |  | $ | 19,716 |  |
| Purchases - inventory | $ | 50,788 |  | $ | 23,871 |  | $ | 35,229 |  | $ | 34,197 |  | — |  | — |  | $ | 1,670 |  | $ | 791 |  | $ | 87,687 |  | $ | 58,859 |  |
| Purchases - other miscellaneous items | $ | 2,116 |  | $ | 2,718 |  | $ | 339 |  | $ | 333 |  | — |  | — |  | — |  | — |  | $ | 2,455 |  | $ | 3,051 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:47]
The Company had the following balances related to transactions with its related parties as of December 31, 2021 and June 30, 2021 (in thousands):
  (was, 2021-11-05, similarity 0.9815):
[0001375365-21-000083:note_history:47]
The Company had the following balances related to transactions with its related parties as of September 30, 2021 and June 30, 2021 (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:48]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 | December 31, 2021 | June 30, 2021 |
| Accounts receivable | $ | 1 |  | $ | 2 |  | $ | 264 |  | $ | 198 |  | $ | 34,267 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 34,532 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,933 |  | $ | 5,575 |  | $ | 29,847 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 222 |  | $ | 89 |  | $ | 35,002 |  | $ | 23,837 |  |
| Accounts payable | $ | 41,725 |  | $ | 38,152 |  | $ | 54,311 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 96,036 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 2,829 |  | $ | 3,042 |  | $ | 17,200 |  | $ | 14,486 |  | $ | — |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,029 |  | $ | 18,528 |  |
  (was, 2021-11-05, similarity 0.8955):
[0001375365-21-000083:note_history:48]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 | September 30, 2021 | June 30, 2021 |
| Accounts receivable | $ | 2 |  | $ | 2 |  | $ | 1,332 |  | $ | 198 |  | $ | 12,659 |  | $ | 8,478 |  | $ | — |  | $ | — |  | $ | 13,993 |  | $ | 8,678 |  |
| Other receivable (1) | $ | 4,428 |  | $ | 5,575 |  | $ | 21,690 |  | $ | 18,173 |  | $ | — |  | $ | — |  | $ | 165 |  | $ | 89 |  | $ | 26,283 |  | $ | 23,837 |  |
| Accounts payable | $ | 40,730 |  | $ | 38,152 |  | $ | 37,024 |  | $ | 31,944 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 77,754 |  | $ | 70,096 |  |
| Accrued liabilities (2) | $ | 1,813 |  | $ | 3,042 |  | $ | 17,790 |  | $ | 14,486 |  | $ | 500 |  | $ | 1,000 |  | $ | — |  | $ | — |  | $ | 20,103 |  | $ | 18,528 |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:49]
The Company's results from transactions with its related parties for each of the three months ended December 31, 2021 and 2020, are as follows (in thousands):
  (was, 2021-11-05, similarity 0.9833):
[0001375365-21-000083:note_history:49]
The Company's results from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2022-02-04):
[0001375365-22-000013:note_history:50]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, | Three months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 3 |  | $ | (31) |  | $ | 3,302 |  | $ | 5,572 |  | $ | 38,311 |  | $ | 13,165 |  | $ | — |  | $ | — |  | $ | 41,616 |  | $ | 18,706 |  |
| Purchases - inventory | $ | 47,520 |  | $ | 21,818 |  | $ | 46,821 |  | $ | 29,017 |  | $ | — |  | $ | — |  | $ | 2,387 |  | $ | 697 |  | $ | 96,728 |  | $ | 51,532 |  |
| Purchases - other miscellaneous items | $ | 2,867 |  | $ | 2,762 |  | $ | 347 |  | $ | 626 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 3,214 |  | $ | 3,388 |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:51]
The Company's results from transactions with its related parties for each of the six months ended December 31, 2021 and 2020, are as follows (in thousands):
  (was, 2021-11-05, similarity 0.8954):
[0001375365-21-000083:note_history:51]
The Company’s cash flow impact from transactions with its related parties for each of the three months ended September 30, 2021 and 2020, are as follows (in thousands):

- added (2022-02-04):
[0001375365-22-000013:note_history:52]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 10 |  | $ | (27) |  | $ | 19,004 |  | $ | 18,871 |  | $ | 53,524 |  | $ | 19,577 |  | $ | — |  | $ | — |  | $ | 72,538 |  | $ | 38,421 |  |
| Purchases - inventory | $ | 98,309 |  | $ | 45,689 |  | $ | 82,050 |  | $ | 63,215 |  | $ | — |  | $ | — |  | $ | 4,056 |  | $ | 1,488 |  | $ | 184,415 |  | $ | 110,392 |  |
| Purchases - other miscellaneous items | $ | 4,983 |  | $ | 5,480 |  | $ | 686 |  | $ | 960 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 5,669 |  | $ | 6,440 |  |

- added (2022-02-04):
[0001375365-22-000013:note_history:53]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2021 and 2020, are as follows (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:54]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, | Six months ended December 31, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | 1 |  | $ | (29) |  | $ | (66) |  | $ | 311 |  | $ | (25,789) |  | $ | (6,586) |  | $ | — |  | $ | — |  | $ | (25,854) |  | $ | (6,304) |  |
| Changes in other receivable | $ | 641 |  | $ | 308 |  | $ | (11,673) |  | $ | 7,246 |  | $ | — |  | $ | — |  | $ | (133) |  | $ | 75 |  | $ | (11,165) |  | $ | 7,629 |  |
| Changes in accounts payable | $ | 3,573 |  | $ | (13,921) |  | $ | 22,367 |  | $ | (10,191) |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 25,940 |  | $ | (24,112) |  |
| Changes in accrued liabilities | $ | (212) |  | $ | 867 |  | $ | 2,713 |  | $ | (5,734) |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,501 |  | $ | (4,867) |  |
| Changes in other long-term liabilities | $ | — |  | $ | (513) |  | $ | — |  | $ | (158) |  | $ | — |  | $ | (1,000) |  | $ | — |  | $ | — |  | $ | — |  | $ | (1,671) |  |
| Purchases of property, plant and equipment | $ | 1,678 |  | $ | 2,968 |  | $ | 92 |  | $ | 90 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 1,770 |  | $ | 3,058 |  |
| Unpaid property, plant and equipment | $ | 2,312 |  | $ | 2,976 |  | $ | — |  | 80 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | 2,312 |  | $ | 3,056 |  |
  (was, 2021-11-05, similarity 0.6253):
[0001375365-21-000083:note_history:54]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Changes in accounts receivable | — |  | $ | (27) |  | $ | (1,134) |  | $ | 353 |  | $ | (4,181) |  | $ | 7,184 |  | — |  | — |  | $ | (5,315) |  | $ | 7,510 |  |
| Changes in other receivable | $ | 1,147 |  | $ | 4,243 |  | $ | (3,517) |  | $ | 7,840 |  | — |  | — |  | $ | (76) |  | $ | 75 |  | $ | (2,446) |  | $ | 12,158 |  |
| Changes in accounts payable | $ | 2,578 |  | $ | (14,952) |  | $ | 5,080 |  | $ | (9,724) |  | — |  | — |  | — |  | — |  | $ | 7,658 |  | $ | (24,676) |  |
| Changes in accrued liabilities | $ | (1,229) |  | $ | (203) |  | $ | 3,304 |  | $ | (3,374) |  | $ | (500) |  | — |  | — |  | — |  | $ | 1,575 |  | $ | (3,577) |  |
| Changes in other long-term liabilities | — |  | $ | 47 |  | — |  | $ | (77) |  | — |  | $ | (500) |  | — |  | — |  | — |  | $ | (530) |  |
| Purchases of property, plant and equipment | $ | 338 |  | $ | 2,140 |  | $ | 62 |  | $ | 90 |  | — |  | — |  | — |  | — |  | $ | 400 |  | $ | 2,230 |  |
| Unpaid property, plant and equipment | $ | 1,360 |  | $ | 1,664 |  | — |  | — |  | — |  | — |  | — |  | — |  | $ | 1,360 |  | $ | 1,664 |  |

- removed (2022-02-04):
[0001375365-21-000083:note_history:55]
|  | Ablecom | Compuware | Corporate Venture | MPS | Total |
|  | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, | Three months ended September 30, |
|  | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 | 2021 | 2020 |
| Net sales | $ | 7 |  | $ | 5 |  | $ | 15,702 |  | $ | 13,299 |  | $ | 15,213 |  | $ | 6,412 |  | — |  | — |  | $ | 30,922 |  | $ | 19,716 |  |
| Purchases - inventory | $ | 50,788 |  | $ | 23,871 |  | $ | 35,229 |  | $ | 34,197 |  | — |  | — |  | $ | 1,670 |  | $ | 791 |  | $ | 87,687 |  | $ | 58,859 |  |
| Purchases - other miscellaneous items | $ | 2,116 |  | $ | 2,718 |  | $ | 339 |  | $ | 333 |  | — |  | — |  | — |  | — |  | $ | 2,455 |  | $ | 3,051 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:56]
|  | Three Months Ended December 31, |  |  |  | Six Months Ended December 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |  |
| Server and storage systems | $ | 986,052 |  |  |  |  | $ | 642,711 |  |  |  |  | $ | 1,835,908 |  |  |  |  | $ | 1,260,499 |  |  |  |
| Subsystems and accessories | 186,367 |  |  |  |  | 187,595 |  |  |  |  | 369,241 |  |  |  |  | 332,057 |  |  |  |
| Total | $ | 1,172,419 |  |  |  |  | $ | 830,306 |  |  |  |  | $ | 2,205,149 |  |  |  |  | $ | 1,592,556 |  |  |  |
  (was, 2021-11-05, similarity 0.6924):
[0001375365-21-000083:note_history:56]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849,856 |  |  |  |  | $ | 617,788 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 182,874 |  |  |  |  | 144,462 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,032,730 |  |  |  |  | $ | 762,250 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:57]
The following is a summary for the three and six months ended December 31, 2021 and 2020, of net sales by geographic region (in thousands):
  (was, 2021-11-05, similarity 0.9486):
[0001375365-21-000083:note_history:57]
The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:58]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 638,207 |  |  | $ | 463,102 |  |  | $ | 1,199,155 |  |  | $ | 959,188 |  |
| Asia | 284,107 |  |  | 161,415 |  |  | 547,193 |  |  | 288,121 |  |
| Europe | 215,451 |  |  | 154,819 |  |  | 395,145 |  |  | 266,908 |  |
| Other | 34,654 |  |  | 50,970 |  |  | 63,656 |  |  | 78,339 |  |
|  | $ | 1,172,419 |  |  | $ | 830,306 |  |  | $ | 2,205,149 |  |  | $ | 1,592,556 |  |
  (was, 2021-11-05, similarity 0.6102):
[0001375365-21-000083:note_history:58]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 560,948 |  |  | $ | 496,086 |  |  |  |  |  |
| Asia | 263,086 |  |  | 126,707 |  |  |  |  |  |
| Europe | 179,694 |  |  | 112,089 |  |  |  |  |  |
| Other | 29,002 |  |  | 27,368 |  |  |  |  |  |
|  | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001375365-22-000013:note_history:59]
|  | Three Months Ended December 31, |  |  |  | Six Months Ended December 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |  |
| Server and storage systems | $ | 986,052 |  |  |  |  | $ | 642,711 |  |  |  |  | $ | 1,835,908 |  |  |  |  | $ | 1,260,499 |  |  |  |
| Subsystems and accessories | 186,367 |  |  |  |  | 187,595 |  |  |  |  | 369,241 |  |  |  |  | 332,057 |  |  |  |
| Total | $ | 1,172,419 |  |  |  |  | $ | 830,306 |  |  |  |  | $ | 2,205,149 |  |  |  |  | $ | 1,592,556 |  |  |  |
  (was, 2021-11-05, similarity 0.6924):
[0001375365-21-000083:note_history:59]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 849,856 |  |  |  |  | $ | 617,788 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 182,874 |  |  |  |  | 144,462 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,032,730 |  |  |  |  | $ | 762,250 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:60]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2021 and 2020, of net sales by geographic region (in thousands):
  (was, 2021-11-05, similarity 0.9122):
[0001375365-21-000083:note_history:60]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three months ended September 30, 2021 and 2020, of net sales by geographic region (in thousands):

- changed (2022-02-04):
[0001375365-22-000013:note_history:61]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States | $ | 638,207 |  |  | $ | 463,102 |  |  | $ | 1,199,155 |  |  | $ | 959,188 |  |
| Asia | 284,107 |  |  | 161,415 |  |  | 547,193 |  |  | 288,121 |  |
| Europe | 215,451 |  |  | 154,819 |  |  | 395,145 |  |  | 266,908 |  |
| Other | 34,654 |  |  | 50,970 |  |  | 63,656 |  |  | 78,339 |  |
|  | $ | 1,172,419 |  |  | $ | 830,306 |  |  | $ | 2,205,149 |  |  | $ | 1,592,556 |  |
  (was, 2021-11-05, similarity 0.6102):
[0001375365-21-000083:note_history:61]
|  | Three Months Ended September 30, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| United States | $ | 560,948 |  |  | $ | 496,086 |  |  |  |  |  |
| Asia | 263,086 |  |  | 126,707 |  |  |  |  |  |
| Europe | 179,694 |  |  | 112,089 |  |  |  |  |  |
| Other | 29,002 |  |  | 27,368 |  |  |  |  |  |
|  | $ | 1,032,730 |  |  | $ | 762,250 |  |  |  |  |  |

- changed (2022-02-04):
[0001375365-22-000013:note_history:62]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2021, which was included in the opening deferred revenue balance as of June 30, 2021 of $202.3 million, was $26.7 million and $56.7 million, respectively.
  (was, 2021-11-05, similarity 0.7619):
[0001375365-21-000083:note_history:62]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2021, which was included in the opening deferred revenue balance as of June 30, 2021 of $202.3 million, was $30.0 million.

- added (2022-02-04):
[0001375365-22-000013:note_history:63]
Deferred revenue increased $50.2 million as of December 31, 2021 as compared to the fiscal year ended June 30, 2021 of which $37.8 million was due to the increase in non-cancellable non-refundable advance consideration received from customers which precedes the Company's satisfaction of the associated performance obligations relating to product sales that the Company expects to fulfill in the next 12 months.

- changed (2022-02-04):
[0001375365-22-000013:note_history:64]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2021 was $252.6 million. The Company expects to recognize approximately 56% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2021-11-05, similarity 0.9963):
[0001375365-21-000083:note_history:64]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2021 was $215.4 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2022-02-04):
[0001375365-21-000083:note_history:65]
Deferred revenue increased $13.1 million during the three months ended September 30, 2021 as compared to the fiscal year ended June 30, 2021 mainly due to the increase in non-cancellable non-refundable advance considerations received from customers which precede the Company's satisfaction of the associated performance obligations.
