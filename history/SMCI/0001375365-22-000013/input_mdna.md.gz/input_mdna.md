# SMCI MD&A — 0001375365-22-000013


## mdna

[0001375365-22-000013:mdna:1]
[same as prior period, unchanged from 0001375365-21-000083:mdna:1]

[0001375365-22-000013:mdna:2]
[same as prior period, unchanged from 0001375365-21-000083:mdna:2]

[0001375365-22-000013:mdna:3]
[same as prior period, unchanged from 0001375365-21-000083:mdna:3]

[0001375365-22-000013:mdna:4]
[same as prior period, unchanged from 0001375365-21-000083:mdna:4]

[0001375365-22-000013:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended December 31, 2021 increased to $41.9 million from $27.7 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Intel Corporation, NVIDIA Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc., Broadcom Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-22-000013:mdna:6]
[same as prior period, unchanged from 0001375365-21-000083:mdna:6]

[0001375365-22-000013:mdna:7]
[same as prior period, unchanged from 0001375365-21-000083:mdna:7]

[0001375365-22-000013:mdna:8]
We quickly transitioned certain of our indirect labor forces to work from home at the earlier phase of the pandemic and continued to operate our local assembly in Taiwan and, after an initial period of disruption, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continued to see ongoing demand and do not have significant direct exposure to industries which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-22-000013:mdna:9]
We have actively managed our supply chain for potential shortage risk by building inventories of critical components required for our motherboards and other system printed circuit boards in response to the early outbreak of COVID-19 in China. Since that time, we have continued to add to our inventories of key components such as CPUs, memory, SSDs and GPUs to support our ability to fulfill customer orders.

[0001375365-22-000013:mdna:10]
[same as prior period, unchanged from 0001375365-21-000083:mdna:10]

[0001375365-22-000013:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In June 2021, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2026. In July 2021, we replaced our prior credit facility and term loan facility with CTBC Bank, with a new facility for omnibus credit lines. In September 2021, we replaced our prior credit facility with E.SUN Bank, with new credit facility and term facility. In September 2021, we entered into a term loan facility with Mega Bank which will be used to support our manufacturing activities (such as purchase of materials and components) and provide medium-term working capital. In October 2021, we entered into a credit facility with Chang Hwa Bank and in January 2022 we entered into a loan agreement with HSBC Bank which will both be used to support the growth of our Taiwan business. See “- Liquidity and Capital Resources – Other Factors Affecting Liquidity and Capital Resources.”

[0001375365-22-000013:mdna:12]
Our management team is focused on guiding our company through the ongoing challenges presented by COVID-19, including the recent emergence of the omicron variant. There are positive signs with vaccine availability and the rollout of boosters; however, with the omicron variant and the possibility of the emergence of other new virus strains and vaccine supply constraints, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months.

[0001375365-22-000013:mdna:13]
[same as prior period, unchanged from 0001375365-21-000083:mdna:15]

[0001375365-22-000013:mdna:14]
The following is a summary of our financial highlights of the second quarter of fiscal year 2022:

[0001375365-22-000013:mdna:15]
•Net sales increased by 41.2% in the three months ended December 31, 2021 as compared to the three months ended December 31, 2020.

[0001375365-22-000013:mdna:16]
•Gross margin decreased to 14.0% in the three months ended December 31, 2021 from 16.4% in the three months ended December 31, 2020.

[0001375365-22-000013:mdna:17]
•Operating expenses increased by 14.1% as compared to the three months ended December 31, 2020, and were equal to 9.6% and 11.9% of net sales in the three months ended December 31, 2021 and 2020, respectively.

[0001375365-22-000013:mdna:18]
•Effective tax rate increased to 15.4% in the three months ended December 31, 2021 from 14.9% in the three months ended December 30, 2020.

[0001375365-22-000013:mdna:19]
[same as prior period, unchanged from 0001375365-21-000083:mdna:21]

[0001375365-22-000013:mdna:20]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses. We evaluate our estimates and assumptions on an ongoing basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for the judgments we make about the carrying value of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from these estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-22-000013:mdna:21]
[same as prior period, unchanged from 0001375365-21-000083:mdna:23]

[0001375365-22-000013:mdna:22]
[same as prior period, unchanged from 0001375365-21-000083:mdna:24]

[0001375365-22-000013:mdna:23]
[same as prior period, unchanged from 0001375365-21-000083:mdna:25]

[0001375365-22-000013:mdna:24]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2021 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 86.0 | % |  | 83.6 | % |  | 86.3 | % |  | 83.3 | % |
| Gross profit | 14.0 | % |  | 16.4 | % |  | 13.7 | % |  | 16.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.6 | % |  | 6.4 | % |  | 5.9 | % |  | 6.8 | % |
| Sales and marketing | 1.9 | % |  | 2.5 | % |  | 2.0 | % |  | 2.6 | % |
| General and administrative | 2.2 | % |  | 3.0 | % |  | 2.2 | % |  | 3.1 | % |
| Total operating expenses | 9.6 | % |  | 11.9 | % |  | 10.1 | % |  | 12.4 | % |
| Income from operations | 4.4 | % |  | 4.5 | % |  | 3.6 | % |  | 4.3 | % |
| Other (expense) income, net | (0.1) | % |  | (0.3) | % |  | — | % |  | (0.2) | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 4.2 | % |  | 4.1 | % |  | 3.5 | % |  | 4.0 | % |
| Income tax provision | (0.6) | % |  | (0.6) | % |  | (0.5) | % |  | (0.6) | % |
| Share of income (loss) from equity investee, net of taxes | — | % |  | (0.2) | % |  | — | % |  | — | % |
| Net income | 3.6 | % |  | 3.3 | % |  | 3.1 | % |  | 3.4 | % |

[0001375365-22-000013:mdna:25]
[same as prior period, unchanged from 0001375365-21-000083:mdna:27]

[0001375365-22-000013:mdna:26]
[same as prior period, unchanged from 0001375365-21-000083:mdna:28]

[0001375365-22-000013:mdna:27]
[same as prior period, unchanged from 0001375365-21-000083:mdna:29]

[0001375365-22-000013:mdna:28]
The following table presents net sales by product type for the three and six months ended December 31, 2021 and 2020 (dollars in millions):

[0001375365-22-000013:mdna:29]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Server and storage systems | $ | 986.1 |  |  | $ | 642.7 |  |  | $ | 343.4 |  |  | 53.4 | % |  | $ | 1,835.9 |  |  | $ | 1,260.5 |  |  | $ | 575.4 |  |  | 45.6 | % |
| Percentage of total net sales | 84.1 | % |  | 77.4 | % |  |  |  |  |  | 83.3 | % |  | 79.1 | % |  |  |  |  |
| Subsystems and accessories | $ | 186.4 |  |  | $ | 187.6 |  |  | $ | (1.2) |  |  | (0.6) | % |  | $ | 369.2 |  |  | $ | 332.1 |  |  | $ | 37.1 |  |  | 11.2 | % |
| Percentage of total net sales | 15.9 | % |  | 22.6 | % |  |  |  |  |  | 16.7 | % |  | 20.9 | % |  |  |  |  |
| Total net sales | $ | 1,172.4 |  |  | $ | 830.3 |  |  | $ | 342.1 |  |  | 41.2 | % |  | $ | 2,205.2 |  |  | $ | 1,592.6 |  |  | $ | 612.6 |  |  | 38.5 | % |

[0001375365-22-000013:mdna:30]
[same as prior period, unchanged from 0001375365-21-000083:mdna:32]

[0001375365-22-000013:mdna:31]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:32]
The period-over-period increase in net sales of our server and storage systems was due to a 30.7% increase in the number of units of compute nodes sold and a 19.5% increase in the average selling price. The increase in the number of units of compute nodes shipped was primarily due to more systems shipments compared to the same period last year.

[0001375365-22-000013:mdna:33]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the average selling price by 23.1% offset by a decrease in the number of units sold by 19.3%, driven by product mix.

[0001375365-22-000013:mdna:34]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:35]
The period-over-period increase in net sales of our server and storage systems was due to a 28.2% increase in the number of units of compute nodes sold and a 15.8% increase in the average selling price. The increase in the number of units of compute nodes shipped was primarily due to more systems shipments compared to the same period last year.

[0001375365-22-000013:mdna:36]
The period-over-period increase in net sales of our subsystems and accessories is primarily due to an increase in the average selling price by 23.1% due to favorable change in product mix offset by a decrease in the number of units sold by 9.7%.

[0001375365-22-000013:mdna:37]
The following table presents net sales by geographic region for the three and six months ended December 31, 2021 and 2020 (dollars in millions):

[0001375365-22-000013:mdna:38]
|  | Three Months Ended December 31, |  | Change |  | Change |  | Six Months Ended December 31, |  | Change |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| United States | $ | 638.2 |  |  | $ | 463.1 |  |  | $ | 175.1 |  |  | 37.8 | % |  | $ | 1,199.2 |  |  | $ | 959.2 |  |  | $ | 240.0 |  |  | 25.0 | % |
| Percentage of total net sales | 54.4 | % |  | 55.8 | % |  |  |  |  |  | 54.4 | % |  | 60.2 | % |  |  |  |  |
| Asia | $ | 284.1 |  |  | $ | 161.4 |  |  | $ | 122.7 |  |  | 76.0 | % |  | $ | 547.2 |  |  | $ | 288.1 |  |  | $ | 259.1 |  |  | 89.9 | % |
| Percentage of total net sales | 24.2 | % |  | 19.4 | % |  |  |  |  |  | 24.8 | % |  | 18.1 | % |  |  |  |  |
| Europe | $ | 215.5 |  |  | $ | 154.8 |  |  | $ | 60.7 |  |  | 39.2 | % |  | $ | 395.1 |  |  | $ | 266.9 |  |  | $ | 128.2 |  |  | 48.0 | % |
| Percentage of total net sales | 18.4 | % |  | 18.6 | % |  |  |  |  |  | 17.9 | % |  | 16.8 | % |  |  |  |  |
| Others | $ | 34.7 |  |  | $ | 51.0 |  |  | $ | (16.3) |  |  | (32.0) | % |  | $ | 63.7 |  |  | $ | 78.4 |  |  | $ | (14.7) |  |  | (18.8) | % |
| Percentage of total net sales | 3.0 | % |  | 6.1 | % |  |  |  |  |  | 2.9 | % |  | 4.9 | % |  |  |  |  |
| Total net sales | $ | 1,172.4 |  |  | $ | 830.3 |  |  |  |  |  |  | $ | 2,205.1 |  |  | $ | 1,592.6 |  |  |  |  |  |

[0001375365-22-000013:mdna:39]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:40]
The period-over-period increase in net sales in the United States was primarily due to higher sales driven by higher server and storage systems unit volume combined with higher average selling price. The period-over-period increase in net sales in Asia was due primarily to increased sales in China, and Korea offset by decrease in sales in Taiwan. The increase of net sales in Europe was primarily due to higher sales in Netherlands, Germany, Russia, and the United Kingdom. The period-over-period decrease in net sales in other countries was primarily due to decrease in sales in Saudi Arabia, South Africa, Mexico and Australia.

[0001375365-22-000013:mdna:41]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:42]
The period-over-period increase in net sales in the United States was primarily due to higher sales driven by higher server and storage systems unit volume combined with higher average selling price. The period-over-period increase in net sales in Asia was due primarily to increased sales in China, Taiwan, Japan, Korea and Singapore. The period-over-period increase of net sales in Europe was primarily due to higher sales in Germany, the United Kingdom, the Netherlands and Russia, partially offset by lower sales in France. The period-over-period decrease in net sales in other countries was primarily due to lower sales in Canada, Brazil, Mexico, Saudi Arabia, and South Africa, partially offset by increased sales in Israel and U.A.E.

[0001375365-22-000013:mdna:43]
[same as prior period, unchanged from 0001375365-21-000083:mdna:40]

[0001375365-22-000013:mdna:44]
[same as prior period, unchanged from 0001375365-21-000083:mdna:41]

[0001375365-22-000013:mdna:45]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-22-000013:mdna:46]
Cost of sales and gross margin for the three months ended December 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000013:mdna:47]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Cost of sales | $ | 1,008.7 |  |  | $ | 694.2 |  |  | $ | 314.5 |  |  | 45.3 | % |  | $ | 1,903.3 |  |  | $ | 1,326.5 |  |  | $ | 576.8 |  |  | 43.5 | % |
| Gross profit | $ | 163.7 |  |  | $ | 136.1 |  |  | $ | 27.6 |  |  | 20.3 | % |  | $ | 301.9 |  |  | $ | 266.0 |  |  | $ | 35.9 |  |  | 13.5 | % |
| Gross margin | 14.0 | % |  | 16.4 | % |  |  |  | (2.4) | % |  | 13.7 | % |  | 16.7 | % |  |  |  | (3.0) | % |

[0001375365-22-000013:mdna:48]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:49]
The period-over-period increase in cost of sales was primarily attributed to an increase of $284.7 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $19.3 million increase in freight costs, a $9.8 million increase due to lower cost recovery of cost paid in prior periods, an increase of $2.5 million  in overhead costs, offset by a decrease of $2.5 million in excess and obsolete inventory charges.

[0001375365-22-000013:mdna:50]
[same as prior period, unchanged from 0001375365-21-000083:mdna:47]

[0001375365-22-000013:mdna:51]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:52]
The period-over-period increase in cost of sales was primarily attributed to an increase of $519.4 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $34.3 million increase in freight charges, a $19.8 million increase due to lower cost recovery of cost paid in prior periods, an increase of $1.8 million in excess and obsolete inventory charges, offset by a decrease of $2.1 million in overhead costs.

[0001375365-22-000013:mdna:53]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of sales. Since the start of the COVID-19 pandemic, we have experienced an increase in costs of sales, logistics costs as well as direct labor costs as we incentivize our employees. This increase in costs negatively impacts our gross margin, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-22-000013:mdna:54]
[same as prior period, unchanged from 0001375365-21-000083:mdna:48]

[0001375365-22-000013:mdna:55]
[same as prior period, unchanged from 0001375365-21-000083:mdna:49]

[0001375365-22-000013:mdna:56]
[same as prior period, unchanged from 0001375365-21-000083:mdna:50]

[0001375365-22-000013:mdna:57]
[same as prior period, unchanged from 0001375365-21-000083:mdna:51]

[0001375365-22-000013:mdna:58]
Operating expenses for the three and six months ended December 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000013:mdna:59]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Research and development | $ | 65.5 |  |  | $ | 52.7 |  |  | $ | 12.8 |  |  | 24.3 | % |  | $ | 130.6 |  |  | $ | 107.5 |  |  | $ | 23.1 |  |  | 21.5 | % |
| Percentage of total net sales | 5.6 | % |  | 6.4 | % |  |  |  |  |  | 5.9 | % |  | 6.8 | % |  |  |  |  |
| Sales and marketing | $ | 22.0 |  |  | $ | 20.7 |  |  | $ | 1.3 |  |  | 6.3 | % |  | $ | 43.6 |  |  | $ | 41.0 |  |  | $ | 2.6 |  |  | 6.3 | % |
| Percentage of total net sales | 1.9 | % |  | 2.5 | % |  |  |  |  |  | 2.0 | % |  | 2.6 | % |  |  |  |  |
| General and administrative | $ | 25.3 |  |  | $ | 25.3 |  |  | $ | — |  |  | — | % |  | $ | 47.5 |  |  | $ | 49.6 |  |  | $ | (2.1) |  |  | (4.2) | % |
| Percentage of total net sales | 2.2 | % |  | 3.0 | % |  |  |  |  |  | 2.2 | % |  | 3.1 | % |  |  |  |  |
| Total operating expenses | $ | 112.7 |  |  | $ | 98.7 |  |  | $ | 14.0 |  |  | 14.2 | % |  | $ | 221.7 |  |  | $ | 198.2 |  |  | $ | 23.5 |  |  | 11.9 | % |
| Percentage of total net sales | 9.6 | % |  | 11.9 | % |  |  |  |  |  | 10.1 | % |  | 12.4 | % |  |  |  |  |

[0001375365-22-000013:mdna:60]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:61]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $7.8 million increase in personnel expenses due to merit increases and higher headcount, $2.8 million lower non-recurring engineering ("'NRE") payments from certain suppliers and customers towards our development efforts and a $1.5 million increase in product development costs.

[0001375365-22-000013:mdna:62]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $1.4 million increase in personnel expenses.

[0001375365-22-000013:mdna:63]
General and administrative expenses. The period-over-period change in general and administrative expenses was primarily due to an increase of $0.6 million in outside services offset by a $0.6 million decrease in compensation expenses.

[0001375365-22-000013:mdna:64]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:65]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to a $15.8 million increase in personnel expenses due to merit increases and higher headcount, $3.7 million lower NRE payments from certain suppliers and customers towards our development efforts and a $2.3 million increase in product development costs.

[0001375365-22-000013:mdna:66]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was primarily due to a $3.4 million increase in personnel expenses, offset by a decrease in advertising and other expenses.

[0001375365-22-000013:mdna:67]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $1.0 million in professional fees driven by lower expenses incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements and a $1.1 million decrease in compensation expenses and other expenses.

[0001375365-22-000013:mdna:68]
Interest and Other Expense, Net

[0001375365-22-000013:mdna:69]
Other expense, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-22-000013:mdna:70]
[same as prior period, unchanged from 0001375365-21-000083:mdna:60]

[0001375365-22-000013:mdna:71]
Interest and other income (expense), net for the three and six months ended December 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000013:mdna:72]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Other expense, net | $ | (0.6) |  |  | $ | (2.5) |  |  | $ | 1.9 |  |  | (76.0) | % |  | $ | (0.6) |  |  | $ | (3.4) |  |  | $ | 2.8 |  |  | (82.4) | % |
| Interest expense | $ | (1.2) |  |  | $ | (0.6) |  |  | $ | (0.6) |  |  | 100.0 | % |  | $ | (2.0) |  |  | $ | (1.2) |  |  | $ | (0.8) |  |  | 66.7 | % |
| Interest and other expense, net | $ | (1.7) |  |  | $ | (3.1) |  |  | $ | 1.4 |  |  | (45.2) | % |  | $ | (2.5) |  |  | $ | (4.6) |  |  | $ | 2.1 |  |  | (45.7) | % |

[0001375365-22-000013:mdna:73]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:74]
The change of $1.9 million in other expense, net was primarily attributable to a decrease in foreign exchange loss due to foreign currency fluctuations.

[0001375365-22-000013:mdna:75]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:76]
The change of $2.8 million in other expense, net was attributable to a decrease in foreign exchange loss due to  foreign currency fluctuations.

[0001375365-22-000013:mdna:77]
[same as prior period, unchanged from 0001375365-21-000083:mdna:65]

[0001375365-22-000013:mdna:78]
[same as prior period, unchanged from 0001375365-21-000083:mdna:66]

[0001375365-22-000013:mdna:79]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000013:mdna:80]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Income tax provision | $ | 7.6 |  |  | $ | 5.1 |  |  | $ | 2.5 |  |  | 49.0 | % |  | $ | 10.9 |  |  | $ | 8.8 |  |  | $ | 2.1 |  |  | 23.9 | % |
| Percentage of total net sales | 0.6 | % |  | 0.6 | % |  |  |  |  |  | 0.5 | % |  | 0.6 | % |  |  |  |  |
| Effective tax rate | 15.4 | % |  | 14.9 | % |  |  |  |  |  | 14.1 | % |  | 13.9 | % |  |  |  |  |

[0001375365-22-000013:mdna:81]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:82]
The income tax provision and effective tax rate for the three months ended December 31, 2021 is higher than that for the three months ended December 31, 2020, primarily due to a decrease in the deduction from foreign-derived intangible income and an increase in certain non-deductible expenses.

[0001375365-22-000013:mdna:83]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:84]
The income tax provision and effective tax rate for the six months ended December 31, 2021 is higher than that for the six months ended December 31, 2020, primarily due to a decrease in the deduction from foreign-derived intangible income and an increase in certain non-deductible expenses.

[0001375365-22-000013:mdna:85]
[same as prior period, unchanged from 0001375365-21-000083:mdna:71]

[0001375365-22-000013:mdna:86]
[same as prior period, unchanged from 0001375365-21-000083:mdna:72]

[0001375365-22-000013:mdna:87]
Share of income from equity investee, net of taxes for the three and six months ended December 31, 2021 and 2020 are as follows (dollars in millions):

[0001375365-22-000013:mdna:88]
|  | Three Months EndedDecember 31, |  | Change | Six Months EndedDecember 31, |  | Change |
|  | 2021 |  | 2020 |  | $ |  | % |  | 2021 |  | 2020 |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 0.2 |  |  | $ | (1.5) |  |  | $ | 1.7 |  |  | (113.3)% |  | $ | 0.6 |  |  | $ | (0.1) |  |  | $ | 0.7 |  |  | —% |
| Percentage of total net sales | — | % |  | (0.2) | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001375365-22-000013:mdna:89]
Comparison of Three Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:90]
The period-over-period increase of $1.7 million in share of income from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-22-000013:mdna:91]
Comparison of Six Months Ended December 31, 2021 and 2020

[0001375365-22-000013:mdna:92]
The period-over-period increase of $0.7 million in share of income from equity investee, net of taxes was primarily due to more net income recognized by the Corporate Venture.

[0001375365-22-000013:mdna:93]
[same as prior period, unchanged from 0001375365-21-000083:mdna:77]

[0001375365-22-000013:mdna:94]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as an increase in the need for working capital due to longer supply chain manufacturing and delivery times. Our cash and cash equivalents were $247.4 million and $232.3 million as of December 31, 2021 and June 30, 2021, respectively. Our cash in foreign locations was $156.5 million and $152.6 million as of December 31, 2021 and June 30, 2021, respectively.

[0001375365-22-000013:mdna:95]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective, but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-22-000013:mdna:96]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses, and maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements.

[0001375365-22-000013:mdna:97]
On January 29, 2021, a duly authorized subcommittee of the Board of Directors approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until the earlier of July 31, 2022 or the date when the maximum amount of common stock is repurchased. The Company had $150.0 million of remaining availability under the share repurchase program as of December 31, 2021.

[0001375365-22-000013:mdna:98]
[same as prior period, unchanged from 0001375365-21-000083:mdna:83]

[0001375365-22-000013:mdna:99]
|  | Six Months EndedDecember 31, |  | Change |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (187.7) |  |  | $ | 183.8 |  |  | $ | (371.5) |  |  |  |  |
| Net cash used in investing activities | $ | (24.3) |  |  | $ | (25.6) |  |  | $ | 1.3 |  |  |  |  |
| Net cash provided by (used in) financing activities | $ | 227.2 |  |  | $ | (53.7) |  |  | $ | 280.9 |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 15.1 |  |  | $ | 105.1 |  |  | $ | (90.0) |  |  |  |  |

[0001375365-22-000013:mdna:100]
[same as prior period, unchanged from 0001375365-21-000083:mdna:85]

[0001375365-22-000013:mdna:101]
Net cash provided by operating activities decreased by $371.5 million for the six months ended December 31, 2021 as compared to the six months ended December 31, 2020. The decrease was primarily due to an increase in net cash required for net working capital of $388.2 million to meet customer demand, support expected business growth and mitigate supply chain risk due to the COVID-19 pandemic environment and $5.6 million decrease in unrealized gain and loss. These decreases are partially offset by increase in net income of $13.1 million.

[0001375365-22-000013:mdna:102]
[same as prior period, unchanged from 0001375365-21-000083:mdna:87]

[0001375365-22-000013:mdna:103]
Net cash used in investing activities decreased by $1.2 million for the six months ended December 31, 2021 as compared to the six months ended December 31, 2020 as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-22-000013:mdna:104]
[same as prior period, unchanged from 0001375365-21-000083:mdna:89]

[0001375365-22-000013:mdna:105]
Net cash provided by financing activities for the six months ended December 31, 2021 was $227.2 million while net cash used by financing activities for the six months ended December 31, 2020 was $53.7 million. The change in cash flows from financing activities was primarily due to an increase of $206.3 million in proceeds from borrowings net of repayment, offset by a $74.8 million decrease in stock repurchases.

[0001375365-22-000013:mdna:106]
[same as prior period, unchanged from 0001375365-21-000083:mdna:91]

[0001375365-22-000013:mdna:107]
Bank of America

[0001375365-22-000013:mdna:108]
2018 Bank of America Credit Facility

[0001375365-22-000013:mdna:109]
In April 2018, the we entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million, increase the maximum amount that we can request the facility be increased from $100.0 million to $150.0 million, and update provisions relating to erroneous payments and LIBOR replacement mechanics. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, we are not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to us and its subsidiaries and contains a financial covenant, which requires us to maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-22-000013:mdna:110]
As of December 31, 2021, the total outstanding borrowings under the 2018 Bank of America Credit Facility were $60.6 million. As of June 30, 2021, we had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2021 and June 30, 2021 were 1.50%. The balance of debt issuance costs outstanding as of December 31, 2021 and June 30, 2021 were $0.5 million. We have been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of December 31, 2021, our available borrowing capacity was $139.4 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-22-000013:mdna:111]
CTBC Bank

[0001375365-22-000013:mdna:112]
2021 CTBC Credit Lines

[0001375365-22-000013:mdna:113]
We through our Taiwan subsidiary was party to (i) that certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC Bank”), which  provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1,200.0 million ($40.7 million U.S. dollar equivalent) and (ii) that certain credit agreement, dated August 24, 2020, with CTBC Bank (the “CTBC Credit Facility”), which provided for total borrowings of up to $50.0 million (collectively, the “Prior CTBC Credit Lines”).

[0001375365-22-000013:mdna:114]
On July 20, 2021 (the “Effective Date”), we through our Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2021 CTBC Credit Lines), which replaced the Prior CTBC Credit Lines in their entirety and permit borrowings, from time to time, pursuant to (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million U.S. dollar equivalents) including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million ($42.9 million U.S. dollar equivalents) and a new 75-month, non-revolving term loan facility of NTD 350.0 million ($12.5 million U.S. dollar equivalents) to use to purchase machinery and equipment for our Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”), and (ii) a line of credit facility of up to $105.0 million (the “2021 CTBC Credit Facility”), which increased the borrowing capacity of CTBC Credit Facility. The 2021 CTBC Credit Facility provides (i) a 12-month NTD 1,250.0 million ($44.7 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.50% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.6 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, and (ii) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $105.0 million with an interest rate equal to the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly.

[0001375365-22-000013:mdna:115]
Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Taiwan subsidiary’s assets, including certain property, land, plant, and equipment. There are various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-22-000013:mdna:116]
As of December 31, 2021 and June 30, 2021, the amounts outstanding under the 2020 CTBC Term Loan Facility were $40.4 million and $34.7 million, respectively. The interest rates for these loans were 0.45% per annum as of December 31, 2021 and June 30, 2021. Under the 2021 CTBC Machine Loan, the amounts outstanding were $3.5 million at December 31, 2021. The interest rates for this loan was 0.65% per annum as of December 31, 2021. As of June 30, 2021, there were no outstanding borrowings under the 2021 CTBC Machine Loan.

[0001375365-22-000013:mdna:117]
The total outstanding borrowings under the 2021 CTBC Credit Facility term loan was denominated in NTD and remeasured into U.S. dollars of $0.0 million and $25.1 million at December 31, 2021 and June 30, 2021, respectively. The 2021 CTBC Credit Facility term loan was repaid on October 26, 2021. The interest rate for the 2021 CTBC Credit Facility term loan was 0.75% per annum as of June 30, 2021.  As of December 31, 2021, and June 30, 2021, the outstanding borrowings under the 2021 CTBC Credit Facility revolving line of credit were $97.0 million and $18.0 million, respectively. The interest rates for these loans were approximately 1.00% per annum as of December 31, 2021. The interest rate was 0.98% per annum as of June 30, 2021. As of December 31, 2021, the amount available for future borrowing under the 2021 CTBC Credit Facility was $8.0 million. As of December 31, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the 2021 CTBC Credit Lines was $78.2 million. As of December 31, 2021, all financial covenants under the 2021 CTBC Credit Lines were satisfied.

[0001375365-22-000013:mdna:118]
E.SUN Bank

[0001375365-22-000013:mdna:119]
2021 E.SUN Bank Credit Facility

[0001375365-22-000013:mdna:120]
We through our Taiwan subsidiary was party to that certain General Credit Agreement, dated December 2, 2020, with E.SUN Bank (“E.SUN Bank”), which provided for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30 million (the “Prior E.SUN Bank Credit Facility”). The term of the Prior E.SUN Bank Credit Facility expired September 18, 2021.

[0001375365-22-000013:mdna:121]
On September 13, 2021 (the “E.SUN Bank Effective Date”), we through our Taiwan subsidiary entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permits borrowings of up to (i) NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) and (ii) $30.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. Other terms of the 2021 E.SUN Bank Credit Facility are substantially identical to the Prior E.SUN Bank Credit Facility. Generally, interest for base rate loans made under the 2021 E.SUN Bank Credit Facility are based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. The 2021 E.SUN Bank Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Subsidiary has an overdue liability at another financial organization. There are various financial

[0001375365-22-000013:mdna:122]
covenants under the 2021 E.SUN Bank Credit Facility, including current ratio, net debt ratio, and interest coverage requirements which are reviewed on a yearly basis at fiscal year end.

[0001375365-22-000013:mdna:123]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the E.SUN Bank Effective Date for (i) a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million ($57.6 million U.S. dollar equivalent) in financing for use in research and development activities (the “Term Loan”), and (ii) a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. As of December 31, 2021, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $18.3 million and the interest rates for these loans were 0.995% per annum. As of December 31, 2021, and June 30, 2021, the amounts outstanding under the Import Loan were $16.5 million and $20.4 million, respectively. The interest rates for these loans as of December 31, 2021 was approximately 0.96%. The interest rates as of  June 30, 2021 ranges from 1.00% to 1.29%. At December 31, 2021, the amount available for future borrowing under the Import Loan was $13.5 million.

[0001375365-22-000013:mdna:124]
Mega Bank

[0001375365-22-000013:mdna:125]
[same as prior period, unchanged from 0001375365-21-000083:mdna:99]

[0001375365-22-000013:mdna:126]
On September 13, 2021 (the “Mega Bank Effective Date”), we through our Taiwan subsidiary entered into a NTD 1,200.0 million ($43.2 million U.S. dollar equivalent) credit facility (the “Mega Bank Credit Facility”) with Mega International Commercial Bank (“Mega Bank”). The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate depends upon the amount borrowed under Mega Bank Credit Facility, and as of the Mega Bank Effective Date, ranged from 0.645% to 0.845% per annum. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown, and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable. As of December 31, 2021, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $43.4 million and the interest rates ranged is 0.65% to 0.85% per annum.

[0001375365-22-000013:mdna:127]
Chang Hwa Bank

[0001375365-22-000013:mdna:128]
Chang Hwa Bank Credit Facility

[0001375365-22-000013:mdna:129]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), we through our Taiwan subsidiary entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”).  The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million ($36.0 million U.S. dollar equivalent), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments. The Chang Hwa Bank Credit Facility has customary default provisions permitting the Chang Hwa Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in cross-default provisions with respect to the other Taiwan subsidiary debt obligations. Under the Chang Hwa Bank Credit Facility, Chang Hwa Bank has the right to demand collateral for debts owed.  As of December 31, 2021, the total outstanding borrowings under the Chang Hwa Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars of $36.2 million and the interest rate was 0.8% per annum.

[0001375365-22-000013:mdna:130]
Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with Chang Hwa Bank. On the Chang Hwa Bank Effective Date, three Loan Contracts were entered into. None of the three Loan Contracts are secured and there are no financial covenants.

[0001375365-22-000013:mdna:131]
HSBC Bank

[0001375365-22-000013:mdna:132]
HSBC Bank Credit Facility

[0001375365-22-000013:mdna:133]
On January 7, 2022 (the “HSBC Bank Effective Date”), we through our Taiwan subsidiary entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with the Taiwan affiliate of HSBC Bank (“HSBC Bank”).  The Loan Agreement provides for borrowings in the form of loans, export/import financings, overdrafts, commercial paper guaranties, and other types of drawdown instruments.  The Loan Agreement has customary default provisions permitting HSBC Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event the Taiwan subsidiary fails to make payment of sums under another agreement which permits acceleration of maturity of such indebtedness. We are not a guarantor of the Loan Agreement.

[0001375365-22-000013:mdna:134]
Terms for specific drawdown instruments issued under the Loan Agreement, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, may be set forth in Facility Letters (a “Facility Letter”) negotiated with the HSBC Bank.  Under a Facility Letter entered into on the HSBC Bank Effective Date, our Taiwan subsidiary and HSBC Bank have agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on the HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments are due on a monthly basis, and principal is repayable on the due date.

[0001375365-22-000013:mdna:135]
Refer to Part I, Item 1, Note 6, “Short-term and Long-term Debt,” in our notes to condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding debt.

[0001375365-22-000013:mdna:136]
[same as prior period, unchanged from 0001375365-21-000083:mdna:104]

[0001375365-22-000013:mdna:137]
We intend to continue to focus our capital expenditures in fiscal year 2022 to support the growth of our operations. We anticipate our capital expenditures for the remainder of fiscal year 2022 will be approximately $20 to $25 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our information systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-22-000013:mdna:138]
[same as prior period, unchanged from 0001375365-21-000083:mdna:106]

[0001375365-22-000013:mdna:139]
[same as prior period, unchanged from 0001375365-21-000083:mdna:107]
