# SMCI notes — 0001375365-25-000014


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-25-000014:notes:1]
Note 1.                 Summary of Significant Accounting Policies

[0001375365-25-000014:notes:2]
[same as prior period, unchanged from 0001375365-25-000006:notes:3]

[0001375365-25-000014:notes:3]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) and applicable rules and regulations of the Securities and Exchange Commission regarding interim financial reporting. Certain information and note disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to such rules and regulations. As such, the information included in this quarterly report on Form 10-Q should be read in conjunction with the consolidated financial statements and accompanying notes included in the Annual Report on Form 10-K for the year ended June 30, 2024, of Super Micro Computer, Inc., a Delaware corporation, and its consolidated entities (collectively, the “Company”). The condensed consolidated balance sheet as of March 31, 2025 included herein was derived from the audited financial statements as of that date, but does not include all disclosures including notes required by GAAP.

[0001375365-25-000014:notes:4]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. All intercompany balances and transactions have been eliminated. Interim results are not necessarily indicative of the results for the full year ending June 30, 2025.

[0001375365-25-000014:notes:5]
Significant Accounting Policies

[0001375365-25-000014:notes:6]
There have been no material changes to the Company's significant accounting policies from its Annual Report on Form 10-K for the fiscal year ended June 30, 2024.

[0001375365-25-000014:notes:7]
[same as prior period, unchanged from 0001375365-25-000006:notes:8]

[0001375365-25-000014:notes:8]
[same as prior period, unchanged from 0001375365-25-000006:notes:9]

[0001375365-25-000014:notes:9]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 67.7% |  | 69.8% |  | 65.4% |  | 65.8% |
| Supplier B | 5.1% |  | n/a |  | 3.9% |  | n/a |
| Supplier C | 4.9% |  | 5.1% |  | 5.5% |  | 7.1% |

[0001375365-25-000014:notes:10]
^The supplier references of A-C above may represent different suppliers than those reported in a previous period.

[0001375365-25-000014:notes:11]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, “Related Party Transactions”), accounted for a combined 2.8% and 4.0% of total cost of sales for the three months ended March 31, 2025 and 2024, respectively, and a combined 3.4% and 4.4% of total cost of sales for the nine months ended March 31, 2025 and 2024, respectively.

[0001375365-25-000014:notes:12]
[same as prior period, unchanged from 0001375365-25-000006:notes:17]

[0001375365-25-000014:notes:13]
The concentration of customer risk refers to the potential adverse impact on a business due to a high dependency on a limited number of customers. This risk arises when a significant portion of the Company's revenue is generated from a small group of clients. If any of these key customers reduce their orders, delay payments, or terminate their contracts, the business could face substantial financial instability.

[0001375365-25-000014:notes:14]
[same as prior period, unchanged from 0001375365-25-000006:notes:14]

[0001375365-25-000014:notes:15]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total net sales |  |  |  |  |  |  |  |
| Customer A | 22.5% |  | 21.2% |  | 23.5% |  | 23.7% |
| Customer B | 14.1% |  | * |  | * |  | * |
| Customer C | * |  | 16.8% |  | 13.5% |  | * |
| Customer D | * |  | * |  | 15.1% |  | * |

[0001375365-25-000014:notes:16]
^The customer references of A-D above may represent different customers than those reported in a previous period.

[0001375365-25-000014:notes:17]
*Below 10%

[0001375365-25-000014:notes:18]
[same as prior period, unchanged from 0001375365-25-000006:notes:12]

[0001375365-25-000014:notes:19]
[same as prior period, unchanged from 0001375365-25-000006:notes:13]

[0001375365-25-000014:notes:20]
|  | March 31, 2025 |  | June 30, 2024 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 46.4% |  | 15.4% |
| Customer C | 17.4% |  | * |
| Customer D | * |  | 44.8% |

[0001375365-25-000014:notes:21]
Recent Accounting Pronouncements Not Yet Adopted

[0001375365-25-000014:notes:22]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.

[0001375365-25-000014:notes:23]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.

[0001375365-25-000014:notes:24]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. The ASU affects a variety of Topics in the Codification. The amendments apply to all reporting entities within the scope of the affected accounting guidance. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect this ASU to have a material impact on its consolidated financial statements and disclosures.

[0001375365-25-000014:notes:25]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-25-000014:notes:26]
Note 2.                 Revenue

[0001375365-25-000014:notes:27]
Disaggregation of Revenue

[0001375365-25-000014:notes:28]
[same as prior period, unchanged from 0001375365-25-000006:notes:24]

[0001375365-25-000014:notes:29]
[same as prior period, unchanged from 0001375365-25-000006:notes:25]

[0001375365-25-000014:notes:30]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Server and storage systems | $ | 4,458,895 |  |  | $ | 3,698,446 |  |  | $ | 15,693,826 |  |  | $ | 9,100,616 |  |
| Subsystems and accessories | 141,018 |  |  | 151,620 |  |  | 521,305 |  |  | 534,046 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |

[0001375365-25-000014:notes:31]
[same as prior period, unchanged from 0001375365-25-000006:notes:27]

[0001375365-25-000014:notes:32]
Revenue related to services for the three months ended March 31, 2025 and 2024 was $57.2 million and $38.3 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the nine months ended March 31, 2025 and 2024 was $161.8 million and $110.7 million, respectively, which is recognized over time ratably over the contract term.

[0001375365-25-000014:notes:33]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):

[0001375365-25-000014:notes:34]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 2,768,181 |  |  | $ | 2,685,213 |  |  | $ | 10,856,490 |  |  | $ | 6,910,312 |  |
| Asia | 1,354,346 |  |  | 764,614 |  |  | 3,077,166 |  |  | 1,646,302 |  |
| Europe | 290,108 |  |  | 297,653 |  |  | 1,869,722 |  |  | 776,949 |  |
| Other | 187,278 |  |  | 102,586 |  |  | 411,753 |  |  | 301,099 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |

[0001375365-25-000014:notes:35]
[same as prior period, unchanged from 0001375365-25-000006:notes:31]

[0001375365-25-000014:notes:36]
[same as prior period, unchanged from 0001375365-25-000006:notes:32]

[0001375365-25-000014:notes:37]
[same as prior period, unchanged from 0001375365-25-000006:notes:33]

[0001375365-25-000014:notes:38]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2025, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $38.5 million and $154.0 million, respectively. Revenue recognized during the three and nine months ended March 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $28.9 million and $104.1 million, respectively.

[0001375365-25-000014:notes:39]
Deferred revenue increased $249.4 million as of March 31, 2025 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $116.7 million increase in non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales which are expected to be fulfilled in the next 12 months.

[0001375365-25-000014:notes:40]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-25-000014:notes:41]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to the remaining performance obligations as of March 31, 2025 was approximately $665.8 million. The Company expects to recognize approximately 53% of such value in the next 12 months, and the remainder thereafter.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-25-000014:notes:42]
The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-25-000014:notes:43]
Note 3.                 Net Income Per Common Share

[0001375365-25-000014:notes:44]
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2025 and 2024 (in thousands, except per share amounts):

[0001375365-25-000014:notes:45]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 108,777 |  |  | $ | 402,459 |  |  | $ | 853,700 |  |  | $ | 855,422 |  |
| Convertible Notes interest charge, net of tax | — |  |  | 385 |  |  | 1,777 |  |  | 385 |  |
| Net income - diluted | $ | 108,777 |  |  | $ | 402,844 |  |  | $ | 855,477 |  |  | $ | 855,807 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 595,041 |  |  | 564,780 |  |  | 592,349 |  |  | 545,620 |  |
| Effect of dilutive convertible notes | — |  |  | 4,710 |  |  | 1,673 |  |  | 1,550 |  |
| Effect of dilutive securities | 26,768 |  |  | 44,820 |  |  | 31,250 |  |  | 41,720 |  |
| Weighted-average shares outstanding - diluted | 621,809 |  |  | 614,310 |  |  | 625,272 |  |  | 588,890 |  |
| Net income per common share - basic | $ | 0.18 |  |  | $ | 0.71 |  |  | $ | 1.44 |  |  | $ | 1.57 |  |
| Net income per common share - diluted | $ | 0.17 |  |  | $ | 0.66 |  |  | $ | 1.37 |  |  | $ | 1.45 |  |

[0001375365-25-000014:notes:46]
Potentially dilutive shares of common stock issuable upon conversion of the Company's outstanding 3.50% Convertible Senior Notes (as amended, restated, and/or otherwise modified from time to time, the “2029 Convertible Notes”), and outstanding 2.25% 2028 Convertible Senior Notes (the “2028 Convertible Notes”) are determined using the if-converted method. For the nine months ended March 31, 2025, shares issuable upon conversion of the 2028 Convertible Notes were dilutive and were included within the numerator for interest and denominator for shares issuable upon conversion of the diluted net income per common share computation. For three months ended March 31, 2025, shares issuable upon conversion of 2028 Convertible Notes were anti-dilutive. For three and nine months ended March 31, 2025, shares issuable upon conversion of 2029 Convertible Notes were anti-dilutive.

[0001375365-25-000014:notes:47]
The following table presents the potentially dilutive shares that were excluded from the computation of diluted net income per share of common shares attributable to common stockholders, because their effect was anti-dilutive (in thousands):

[0001375365-25-000014:notes:48]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Stock-based awards | 16,245 |  |  | 88 |  |  | 9,278 |  |  | 3,105 |  |
| Convertible notes | 32,138 |  |  | — |  |  | 20,673 |  |  | — |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-25-000014:notes:49]
Note 4.                 Balance Sheet Components

[0001375365-25-000014:notes:50]
The following tables provide details of the selected balance sheet items (in thousands):

[0001375365-25-000014:notes:51]
[same as prior period, unchanged from 0001375365-25-000006:notes:43]

[0001375365-25-000014:notes:52]
|  | March 31, 2025 |  | June 30, 2024 |
| Cash and cash equivalents | $ | 2,536,101 |  |  | $ | 1,669,766 |  |
| Restricted cash included in other assets | 991 |  |  | 507 |  |
| Total cash, cash equivalents and restricted cash | $ | 2,537,092 |  |  | $ | 1,670,273 |  |

[0001375365-25-000014:notes:53]
[same as prior period, unchanged from 0001375365-25-000006:notes:45]

[0001375365-25-000014:notes:54]
|  | March 31, 2025 |  | June 30, 2024 |
| Finished goods | $ | 2,870,043 |  |  | $ | 3,312,768 |  |
| Work in process | 454,396 |  |  | 450,993 |  |
| Purchased parts and raw materials | 545,804 |  |  | 569,268 |  |
| Total inventories | $ | 3,870,243 |  |  | $ | 4,333,029 |  |

[0001375365-25-000014:notes:55]
The Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $125.1 million and $15.4 million during the three months ended March 31, 2025 and 2024, respectively, and $159.0 million and $28.3 million for the nine months ended March 31, 2025 and 2024, respectively.

[0001375365-25-000014:notes:56]
[same as prior period, unchanged from 0001375365-25-000006:notes:48]

[0001375365-25-000014:notes:57]
|  | March 31, 2025 |  | June 30, 2024 |
| Land | $ | 162,963 |  |  | $ | 150,137 |  |
| Buildings | 182,461 |  |  | 163,764 |  |
| Machinery and equipment | 187,133 |  |  | 156,496 |  |
| Building and leasehold improvements | 119,360 |  |  | 72,075 |  |
| Furniture and fixtures | 53,062 |  |  | 46,241 |  |
| Software | 28,905 |  |  | 24,363 |  |
| Construction in progress | 669 |  |  | 14,828 |  |
| Property, plant and equipment, gross | 734,553 |  |  | 627,904 |  |
| Accumulated depreciation and amortization | (241,988) |  |  | (213,896) |  |
| Property, plant and equipment, net | $ | 492,565 |  |  | $ | 414,008 |  |

[0001375365-25-000014:notes:58]
Depreciation expense for the three months ended March 31, 2025 and 2024, was $10.9 million and $7.6 million, respectively, and for the nine months ended March 31, 2025 and 2024, was $29.4 million and $21.9 million, respectively.

[0001375365-25-000014:notes:59]
[same as prior period, unchanged from 0001375365-25-000006:notes:51]

[0001375365-25-000014:notes:60]
|  | March 31, 2025 |  | June 30, 2024 |
| Accrued payroll and related expenses | $ | 57,373 |  |  | $ | 62,006 |  |
| Customer deposits | 52,954 |  |  | 46,942 |  |
| Accrued cooperative marketing expenses | 25,431 |  |  | 15,967 |  |
| Accrued warranty costs | 10,740 |  |  | 10,009 |  |
| Operating lease liability | 13,188 |  |  | 9,248 |  |
| Accrued professional fees | 5,484 |  |  | 1,699 |  |
| Accrued interest - convertible notes | 10,011 |  |  | — |  |
| Customer-related liabilities | 71,920 |  |  | 42,455 |  |
| Input tax payable | 42,299 |  |  | 14,064 |  |
| Other | 55,279 |  |  | 57,284 |  |
| Total accrued liabilities | $ | 344,679 |  |  | $ | 259,674 |  |

[0001375365-25-000014:notes:61]
[same as prior period, unchanged from 0001375365-25-000006:notes:53]

[0001375365-25-000014:notes:62]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Balance, beginning of the period | $ | 18,288 |  |  | $ | 16,616 |  |  | $ | 17,815 |  |  | $ | 14,859 |  |
| Provision for warranty | 25,253 |  |  | 13,176 |  |  | 53,949 |  |  | 36,220 |  |
| Costs utilized | (24,277) |  |  | (12,423) |  |  | (51,131) |  |  | (33,813) |  |
| Change in estimated liability for pre-existing warranties | (337) |  |  | 273 |  |  | (1,706) |  |  | 376 |  |
| Balance, end of the period | 18,927 |  |  | 17,642 |  |  | 18,927 |  |  | 17,642 |  |
| Current portion | 10,740 |  |  | 10,028 |  |  | 10,740 |  |  | 10,028 |  |
| Non-current portion | $ | 8,187 |  |  | $ | 7,614 |  |  | $ | 8,187 |  |  | $ | 7,614 |  |

[0001375365-25-000014:notes:63]
[same as prior period, unchanged from 0001375365-25-000006:notes:55]


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-25-000014:notes:64]
Note 5.                 Financial Instruments and Fair Value Measurements

[0001375365-25-000014:notes:65]
The Company classifies its financial instruments, except for its investment in an auction rate security and other investments in privately held companies, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-25-000014:notes:66]
[same as prior period, unchanged from 0001375365-25-000006:notes:57]

[0001375365-25-000014:notes:67]
[same as prior period, unchanged from 0001375365-25-000006:notes:58]

[0001375365-25-000014:notes:68]
The following table sets forth the Company’s financial instruments as of March 31, 2025 and June 30, 2024, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-25-000014:notes:69]
| March 31, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 289 |  |  | $ | — |  |  | $ | — |  |  | $ | 289 |  |
| Certificates of deposit | — |  |  | 479 |  |  | — |  |  | 479 |  |
| Investment in marketable equity security | 3,482 |  |  | — |  |  | — |  |  | 3,482 |  |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 3,771 |  |  | $ | 479 |  |  | $ | 1,829 |  |  | $ | 6,079 |  |
| June 30, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 340 |  |  | $ | — |  |  | $ | — |  |  | $ | 340 |  |
| Certificates of deposit | — |  |  | 486 |  |  | — |  |  | 486 |  |
| Investment in marketable equity security | 3,686 |  |  | — |  |  | — |  |  | 3,686 |  |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 4,026 |  |  | $ | 486 |  |  | $ | 1,829 |  |  | $ | 6,341 |  |

[0001375365-25-000014:notes:70]
(1) $0.1 million and $0.1 million in money market funds are included in Cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in Restricted cash, non-current in Other assets in the condensed consolidated balance sheets as of March 31, 2025 and June 30, 2024, respectively.

[0001375365-25-000014:notes:71]
[same as prior period, unchanged from 0001375365-25-000006:notes:62]

[0001375365-25-000014:notes:72]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in Prepaid expenses and other current assets in the condensed consolidated balance sheets. The unrealized gains and losses of the investment are included in earnings. For the three and nine months ended March 31, 2025, an unrealized loss of $1.3 million and an unrealized loss of $0.2 million, respectively, has been recorded in Other (expense) income, net in the condensed consolidated statement of operations. For the three and nine months ended March 31, 2024, an unrealized loss of $1.5 million and $2.3 million, respectively, has been recorded in Other (expense) income, net in the condensed consolidated statements of operations.

[0001375365-25-000014:notes:73]
The Company’s investment in an auction rate security is classified as an available for sale security within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2025 and June 30, 2024. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and using the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount would not result in a significantly higher or lower fair value measurement of the auction rate security as of March 31, 2025.

[0001375365-25-000014:notes:74]
For the three and nine months ended March 31, 2025 and 2024, there were no unrealized gains and losses recognized for the auction rate security in other comprehensive income.

[0001375365-25-000014:notes:75]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions, and reasonable economic forecasts that affect collectability. For the three and nine months ended March 31, 2025 and 2024, the credit losses related to the Company’s investments were not material.

[0001375365-25-000014:notes:76]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and nine months ended March 31, 2025 and 2024.

[0001375365-25-000014:notes:77]
[same as prior period, unchanged from 0001375365-25-000006:notes:68]

[0001375365-25-000014:notes:78]
The Company's non-marketable equity securities consist of investments in privately held companies without readily determinable fair values and are classified as Level 2 in the fair value hierarchy. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer.

[0001375365-25-000014:notes:79]
The Company performed a qualitative assessment to identify impairment indicators and records an impairment identified to Other (expense) income, net on the condensed consolidated statements of operations. During the three and nine months ended March 31, 2025, the Company did not record an impairment. The Company did not record an impairment during the three months ended March 31, 2024 and recorded $1.8 million of impairment during the nine months ended March 31, 2024.

[0001375365-25-000014:notes:80]
As of March 31, 2025 and June 30, 2024, the Company had $54.6 million and $54.6 million of investments in privately held companies recorded in Other assets on the condensed consolidated balance sheets for which the measurement alternative was elected.

[0001375365-25-000014:notes:81]
[same as prior period, unchanged from 0001375365-25-000006:notes:72]

[0001375365-25-000014:notes:82]
The Company estimates the fair value of outstanding debt, including its 2029 Convertible Notes and 2028 Convertible Notes for disclosure purposes on a recurring basis.

[0001375365-25-000014:notes:83]
As of March 31, 2025 and June 30, 2024, our total lines of credit and term loans of $107.0 million and $476.4 million, respectively, are reported at amortized cost. The outstanding debt was categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-25-000014:notes:84]
The estimated fair value as of March 31, 2025 of the 2029 Convertible Notes and 2028 Convertible Notes were $1,689.5 million and $730.4 million, respectively. The estimated fair value of the 2029 Convertible Notes and 2028 Convertible Notes was determined through consideration of quoted market prices. The 2029 Convertible Notes and 2028 Convertible Notes are categorized as Level 2 since their fair value was based on Level 2 inputs of quoted prices.


## us-gaap:DebtDisclosureTextBlock

[0001375365-25-000014:notes:85]
Note 6.                 Lines of Credit and Term Loans

[0001375365-25-000014:notes:86]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands):

[0001375365-25-000014:notes:87]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 24,166 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 24,166 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,957 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,756 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,980 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 14,500 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,490 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 18,125 |  |  | 27,644 |  |
| Total term loans | 82,808 |  |  | 114,557 |  |
| Total lines of credit and term loans | 106,974 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Term loans, non-current | $ | 43,003 |  |  | $ | 74,083 |  |

[0001375365-25-000014:notes:88]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-25-000014:notes:89]
Available borrowings and interest rates as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):

[0001375365-25-000014:notes:90]
|  | March 31, 2025 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 160,834 |  |  | 2.63% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,062 |  |  | 1.88% - 5.18% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | — |  |  | n/a |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 2.02% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  |  | n/a |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 46,822 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |

[0001375365-25-000014:notes:91]
See Note 7 “Lines of Credit and Term Loans” of the Company’s 2024 Annual Report on Form 10-K for the fiscal year ended June 30, 2024 (“2024 10-K”) to the condensed consolidated financial statements in this Quarterly Report for a more complete description of the Company's credit facilities.

[0001375365-25-000014:notes:92]
The Company entered into new agreements during the nine months ended March 31, 2025 with the following terms:

[0001375365-25-000014:notes:93]
Bank of America

[0001375365-25-000014:notes:94]
Bridge Term Loan Facility

[0001375365-25-000014:notes:95]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder.

[0001375365-25-000014:notes:96]
On November 1, 2024, the Company prepaid in full and terminated its obligations under the Term Loan Agreement.

[0001375365-25-000014:notes:97]
2018 Bank of America Credit Facility

[0001375365-25-000014:notes:98]
On July 19, 2024, the Company entered into an Eighth Amendment to Loan and Security Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as administrative agent for the lenders (the “ABL Agent”), which amends the Loan and Security Agreement, dated as of April 19, 2018 (the “ABL Agreement”) to, among other things, allow for the Company’s entry into and borrowing under the Term Loan Facility.

[0001375365-25-000014:notes:99]
On September 27, 2024, the Company entered into the Ninth Amendment to the ABL Agreement, by and among the Company, the lenders party thereto, and the ABL Agent, which amended the ABL Agreement to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year ended June 30, 2024 under the ABL Agreement and added a $70 million availability block to the U.S borrowing base thereunder.

[0001375365-25-000014:notes:100]
On November 20, 2024, the Company prepaid in full and terminated its obligations under the ABL Agreement.

[0001375365-25-000014:notes:101]
2022 Bank of America Credit Facility

[0001375365-25-000014:notes:102]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the “Taiwan Subsidiary”), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

[0001375365-25-000014:notes:103]
Cathay Bank

[0001375365-25-000014:notes:104]
Cathay Bank Line of Credit

[0001375365-25-000014:notes:105]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the “Cathay Bank Loan Agreement”), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sub-limit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

[0001375365-25-000014:notes:106]
CTBC Bank

[0001375365-25-000014:notes:107]
2025 CTBC Facility Letter

[0001375365-25-000014:notes:108]
On February 27, 2025, the Taiwan Subsidiary received a new facility letter from CTBC Bank (“2025 Facility”), issued under the general agreement for omnibus credit lines with CTBC Bank, dated February 16, 2024 (the “2024 CTBC Agreement”). As a result, the credit arrangements under the 2024 CTBC Agreement now include the previously issued long and medium-term loan facility of New Taiwan Dollar (“NTD”) 1,550 million entered into in 2020 and 2021 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,800 million and NTD 100 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40 million (the “USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105 million for exports and imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80 million (the “Import O/A Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “2025 CTBC Credit Lines”). Aggregate borrowings under all the 2025 CTBC Credit Lines are subject to a cap of $185 million as set forth under the 2024 CTBC Agreement.

[0001375365-25-000014:notes:109]
The 2025 Facility expires on February 28, 2026. As of March 31, 2025, the outstanding borrowings under the 2025 CTBC Bank Credit Lines were $24.2 million.

[0001375365-25-000014:notes:110]
E.SUN Bank

[0001375365-25-000014:notes:111]
E.SUN Bank Term Loan Facilities and Credit Lines

[0001375365-25-000014:notes:112]
On November 14, 2024, the Taiwan Subsidiary entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements issued by the Taiwan Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

[0001375365-25-000014:notes:113]
HSBC Bank

[0001375365-25-000014:notes:114]
HSBC Bank Credit Lines

[0001375365-25-000014:notes:115]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Taiwan Subsidiary had entered into with the Taiwan affiliate of HSBC Bank (the “HSBC Loan Agreement”) was terminated and not renewed. The balance of $50 million under the HSBC Loan Agreement was fully repaid on September 9, 2024, and the loan had remained undrawn since such date.

[0001375365-25-000014:notes:116]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-25-000014:notes:117]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2025 |  | $ | 34,118 |  |
| 2026 |  | 39,805 |  |
| 2027 |  | 17,293 |  |
| 2028 |  | 5,833 |  |
| 2029 |  | 5,178 |  |
| 2030 and thereafter |  | 4,747 |  |
| Total lines of credit and term loans |  | $ | 106,974 |  |

[0001375365-25-000014:notes:118]
As of March 31, 2025, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6 “Lines of Credit and Term Loans”.

[0001375365-25-000014:notes:119]
Note 7.                 Convertible Notes

[0001375365-25-000014:notes:120]
2029 Convertible Notes

[0001375365-25-000014:notes:121]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 0.00% Convertible Senior Notes due 2029 (the “Original 2029 Convertible Notes”). On February 11, 2025, the Company entered into privately negotiated subscription agreements with certain holders of the Original 2029 Convertible Notes (the “Convertible Note SPAs”) to, among other things, amend certain terms of, and obtain waivers with respect to, the Original 2029 Convertible Notes and to issue $700.0 million aggregate principal amount of the 2028 Convertible Notes (as further described below). On February 12, 2025, pricing of the amended 2029 Convertible Notes and 2028 Convertible Notes was set pursuant to the Convertible Note SPAs, establishing a binding commitment by the parties to the Convertible Note SPAs. On February 20, 2025, the Company amended and supplemented that certain indenture governing the Original 2029 Convertible Notes (the “Original 2029 Notes Indenture”), dated as of February 27, 2024, by and between the Company U.S. Bank Trust Company, National Association, as trustee (the “Trustee”) by entering into a first supplemental indenture and a second supplemental indenture (the Original 2029 Notes Indenture, as so amended, the “2029 Convertible Notes Indenture”), in each case with the Trustee. Pursuant to the 2029 Convertible Notes Indenture, the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes which is equivalent to a conversion price of approximately $83.44 per share of the Company’s common stock, in each case subject to adjustment as set forth in 2029 Convertible Notes Indenture (such amendments, the “Amendments”). The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election. The other terms of the 2029 Convertible Notes remained substantially unchanged. The amendment was treated as an extinguishment of the original debt and an issuance of the new debt, in which a debt extinguishment loss of $30.3 million was recognized during the quarter ended March 31, 2025.

[0001375365-25-000014:notes:122]
The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture. The debt issuance costs and premium are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

[0001375365-25-000014:notes:123]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2029 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2029 Convertible Notes for each trading day of the 2029 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000014:notes:124]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000014:notes:125]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date.

[0001375365-25-000014:notes:126]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. No sinking fund is provided for the 2029 Convertible Notes.

[0001375365-25-000014:notes:127]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2028 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

[0001375365-25-000014:notes:128]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs and premium of $23.9 million, was $1,701.1 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs and premium was $0.8 million and interest was $8.2 million for the quarter ended March 31, 2025. The effective interest rate is 3.88%.

[0001375365-25-000014:notes:129]
In connection with the Amendment, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to discussion below under “Capped Calls”.

[0001375365-25-000014:notes:130]
2028 Convertible Notes

[0001375365-25-000014:notes:131]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of its 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture by and between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Convertible Notes Indenture”). The Company received proceeds from the offering of approximately $700.0 million before deducting any issuance costs and fees payable to the placement agents. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier repurchased, redeemed or converted.

[0001375365-25-000014:notes:132]
The 2028 Convertible Notes bear interest from February 20, 2025 at an annual rate of 2.25%, payable semi-annually in arrears on each January 15 and July 15, beginning on July 15, 2025. The 2028 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of the Company’s common stock, at the Company’s election, at an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2028 Convertible Notes Indenture. The Company may pay special interest, if any, at its election as the sole remedy relating to a failure to comply with its reporting obligations and will be obligated to pay additional interest, if any, under the circumstances set forth in the 2028 Convertible Notes Indenture. The 2028 Convertible Notes do not contain financial maintenance covenants.

[0001375365-25-000014:notes:133]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2028 Convertible Notes Indenture; (4) if the Company calls such 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000014:notes:134]
If the Company undergoes a fundamental change (as defined in the 2028 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2028 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2028 Convertible Notes to be repurchased, plus any accrued and unpaid interest, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2028 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000014:notes:135]
The 2028 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2026 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 150% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the 2028 Convertible Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001375365-25-000014:notes:136]
The 2028 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2028 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2028 Convertible Notes. No sinking fund is provided for the 2028 Convertible Notes.

[0001375365-25-000014:notes:137]
The 2028 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2028 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2029 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2028 Convertible Notes to convert their notes early had been met. Therefore, the 2028 Convertible Notes are classified as long-term debt.

[0001375365-25-000014:notes:138]
The Company accounted for the issuance of the 2028 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000014:notes:139]
The carrying value of the 2028 Convertible Notes, net of unamortized issuance costs of $15.8 million, was $684.2 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs was $0.5 million and for interest was $1.8 million for the quarter ended March 31, 2025. The effective interest rate is 2.97%.

[0001375365-25-000014:notes:140]
Capped Calls

[0001375365-25-000014:notes:141]
On February 12, 2025, in connection with the Amendments, the Company also entered into agreements to amend certain terms of the privately negotiated capped call transactions (collectively and as amended, the “Capped Call Transactions”) originally entered into with certain financial institutions (the “Capped Call Counterparties”) on February 22, 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the strike price and cap price. The strike price, after giving effect to the amendments, is initially $83.44 per share of the Company's common stock. The cap price, after giving effect to the amendments, is initially $94.17 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls. The number of shares underlying the Capped Calls increased from 7.455 to 11.984 per $1,000 principal amount of 2029 Convertible Notes.

[0001375365-25-000014:notes:142]
The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. 
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. The amendment to the Capped Call Transactions did not change the recognition of the Capped Call Transactions as shareholders’ equity and did not result in any incremental value requiring recognition. The amended 2029 Convertible Notes and the amended Capped Call Transactions have been integrated for tax purposes. The impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-25-000014:notes:143]
Note 8.                 Leases

[0001375365-25-000014:notes:144]
The Company leases offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2025 and 2024 were as follows (in thousands):

[0001375365-25-000014:notes:145]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating lease expense (including expense for lease agreements with related parties of $208 and $86 for the three months ended March 31, 2025 and 2024, respectively, and $538 and $363 for the nine months ended March 31, 2025 and 2024, respectively) | $ | 5,712 |  |  | $ | 2,538 |  |  | $ | 12,685 |  |  | $ | 7,076 |  |
| Cash payments for operating leases (including payments to related parties of $202 and $75 for the three months ended March 31, 2025 and 2024, respectively, $508 and $333 for the nine months ended March 31, 2025 and 2024, respectively) | $ | 5,380 |  |  | $ | 2,469 |  |  | $ | 11,959 |  |  | $ | 6,756 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 110,145 |  |  | $ | 22,301 |  |  | $ | 128,617 |  |  | $ | 24,140 |  |

[0001375365-25-000014:notes:146]
During the three and nine months ended March 31, 2025 and 2024, the Company’s costs related to short-term lease arrangements for real estate were $0.2 million each, and costs related to short-term lease arrangements for non-real estate were $0.8 million and $0.6 million, respectively. Non-lease variable payments expensed in the three and nine months ended March 31, 2025 were $1.0 million and $2.5 million. Non-lease variable payments expensed in the three and nine months ended March 31, 2024 were $0.6 million and $1.6 million, respectively.

[0001375365-25-000014:notes:147]
As of March 31, 2025 and June 30, 2024, the Operating lease right of use assets recorded within Other assets in the condensed consolidated balance sheets were $152.9 million and $34.6 million, respectively. As of March 31, 2025, the weighted average remaining lease term for operating leases was 8.5 years and the weighted average discount rate was 5.8%. As of March 31, 2024, the weighted average remaining lease term for operating leases was 4.8 years and the weighted average discount rate was 5.0%. The short-term portion of the lease liability is included in accrued liabilities and the long-term portion of the lease liability is included in other long-term liabilities on the condensed consolidated balance sheets.

[0001375365-25-000014:notes:148]
In June 2024, the Company entered into a lease agreement for a 21 megawatt (“MW”) data center co-location space located in Vernon, California (the “Data Center Space”), with a lease term expiring on August 31, 2035. The lease agreement consists of five tranches, with the first tranche of 6 MW having commenced on January 24, 2025. The right-of-use asset and lease liability associated with the commencement of the first tranche, totaling $87.9 million, were recorded during the three months ended March 31, 2025.

[0001375365-25-000014:notes:149]
Simultaneously, the Company sublicensed the first tranche to an unrelated party (the “Sub licensee”) for the same term, expiring on August 31, 2035. Pursuant to the sublicense, the Company sublicensed the Data Center Space lease to the Sub licensee, and the Sub licensee assumed all rights and obligations with respect to the Data Center Space lease. The Company accounted for the lease as an operating lease and the sublicense as a sublease under ASC 842. The first tranche of 6 MW commenced simultaneously on January 24, 2025, and the related sublicense income for the three and nine months ended March 31, 2025, amounted to $1.3 million. As of March 31, 2025, the future total minimum sublicense receipts expected to be received are as follows (in thousands):

[0001375365-25-000014:notes:150]
| Fiscal Year: |  | Future minimum sublicense receipts |
| Remainder of 2025 |  | $ | 3,699 |  |
| 2026 |  | 10,037 |  |
| 2027 |  | 10,984 |  |
| 2028 |  | 11,285 |  |
| 2029 |  | 11,653 |  |
| 2030 and beyond |  | 79,994 |  |
| Total sublicense receipts - Lessor |  | $ | 127,652 |  |

[0001375365-25-000014:notes:151]
The future undiscounted fixed non-cancelable payment obligation and future minimum sublicense receipts pertaining to the remaining four tranches that have not yet commenced as of March 31, 2025 is approximately $291.4 million and $308.9 million, respectively.

[0001375365-25-000014:notes:152]
The Company holds an equity investment of $42.5 million in the Sub licensee, which is classified under investments in privately held companies and recorded in Other assets on the condensed consolidated balance sheets. The Sub licensee does not meet the criteria of a related party. Additionally, the Sub licensee has been a customer of the Company, and the Company concluded that equity investment agreements and sub-licensing agreement are separate from revenue contracts as all transactions have been recorded at the respective fair values.

[0001375365-25-000014:notes:153]
Additionally, the Company extended its warehouse lease in Fremont, California for an additional 63 months, expiring on October 31, 2030. In connection with the foregoing, the Company recorded an additional $20.5 million right-of-use asset and lease liability to the condensed consolidated balance sheets during the three months ended March 31, 2025.

[0001375365-25-000014:notes:154]
Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of March 31, 2025 were as follows (in thousands):

[0001375365-25-000014:notes:155]
| Fiscal Year: |  | Maturities of operating leases(1) |
| Remainder of 2025 |  | $ | 6,258 |  |
| 2026 |  | 23,958 |  |
| 2027 |  | 25,044 |  |
| 2028 |  | 23,899 |  |
| 2029 |  | 23,565 |  |
| 2030 and beyond |  | 101,931 |  |
| Total future lease payments |  | 204,655 |  |
| Less: Imputed interest |  | (49,054) |  |
| Present value of operating lease liabilities |  | 155,601 |  |
| Less: Current portion |  | (13,188) |  |
| Long-term portion of operating lease liabilities |  | $ | 142,413 |  |

[0001375365-25-000014:notes:156]
[same as prior period, unchanged from 0001375365-25-000006:notes:125]

[0001375365-25-000014:notes:157]
Related party leases

[0001375365-25-000014:notes:158]
The Company has entered into lease agreements with related parties. See Note 9 “Related Party Transactions” for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-25-000014:notes:159]
Note 9.                 Related Party Transactions

[0001375365-25-000014:notes:160]
The Company has a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-25-000014:notes:161]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on Nasdaq in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of March 31, 2025 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.7 million and $16.4 million, respectively.

[0001375365-25-000014:notes:162]
Dealings with Ablecom

[0001375365-25-000014:notes:163]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-25-000014:notes:164]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.0% and 95.2% of the chassis purchased by the Company during the three months ended March 31, 2025 and 2024, respectively, and 95.2% and 92.7% of the chassis purchased by the Company during the nine months ended March 31, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-25-000014:notes:165]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. There is no revenue recognized by the Company from these transactions. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-25-000014:notes:166]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on March 31, 2025 were $54.4 million and $25.6 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000014:notes:167]
Dealings with Compuware

[0001375365-25-000014:notes:168]
The Company appointed Compuware as a non-exclusive authorized distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility of installing the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-25-000014:notes:169]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. The Company has extended a $65.0 million trade credit line with a net 60 days payment terms to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000014:notes:170]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-25-000014:notes:171]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by the Company from these transactions. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-25-000014:notes:172]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on March 31, 2025 were $109.1 million and $81.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-25-000014:notes:173]
Dealings with Leadtek Research Inc.

[0001375365-25-000014:notes:174]
In October 2023, Ablecom and Compuware together acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended March 31, 2025, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the nine months ended March 31, 2025, the Company engaged in transactions in which it sold $0.5 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.

[0001375365-25-000014:notes:175]
Dealings with Investment in a Corporate Venture

[0001375365-25-000014:notes:176]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is approximately 30% owned by the Company and approximately 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-25-000014:notes:177]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.7 million and $4.6 million as of March 31, 2025 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of March 31, 2025 and June 30, 2024. No impairment charge was recorded for the three and nine months ended March 31, 2025 and 2024.

[0001375365-25-000014:notes:178]
The Company sold products worth $4.2 million and $4.3 million to the Corporate Venture during the three months ended March 31, 2025 and 2024, respectively, and $9.0 million and $16.5 million to the Corporate Venture during the nine months ended March 31, 2025 and 2024, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2025 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.1 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2025 and June 30, 2024, respectively.

[0001375365-25-000014:notes:179]
Other Transactions

[0001375365-25-000014:notes:180]
For the three months ended March 31, 2025, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the nine months ended March 31, 2025, the Company had immaterial chargebacks from Green Earth. As of March 31, 2025, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth were immaterial.

[0001375365-25-000014:notes:181]
The Company had the following balances related to transactions with its related parties as of March 31, 2025 and June 30, 2024 (in thousands):

[0001375365-25-000014:notes:182]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  |  |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |
| Accounts receivable | $ | 1 |  |  | $ | 1 |  |  | $ | 94 |  |  | $ | 142 |  |  | $ | 85 |  |  | $ | 5,075 |  |  |  |  | $ | 136 |  |  | $ | 976 |  |  | $ | 316 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,350 |  |  | $ | 1,927 |  |  | $ | 13,371 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 14,721 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 50,359 |  |  | $ | 98,629 |  |  | $ | 64,945 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 230 |  |  | $ | 115,304 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 487 |  |  | $ | — |  |  | $ | 254 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 741 |  |  | $ | 170 |  |
| Other Long-term liabilities (3) | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | — |  |

[0001375365-25-000014:notes:183]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.

[0001375365-25-000014:notes:184]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-25-000014:notes:185]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

[0001375365-25-000014:notes:186]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2025 and 2024, are as follows (in thousands):

[0001375365-25-000014:notes:187]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 3 |  |  | $ | 2 |  |  | $ | 3,278 |  |  | $ | 21,501 |  |  | $ | 4,201 |  |  | $ | 4,301 |  |  |  |  | $ | 165 |  |  | $ | — |  |  | $ | 7,647 |  |  | $ | 25,804 |  |
| Purchases - inventory | $ | 50,147 |  |  | $ | 65,933 |  |  | $ | 65,372 |  |  | $ | 64,464 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 115,519 |  |  | $ | 130,397 |  |
| Purchases - other miscellaneous items | $ | 8,748 |  |  | $ | 4,401 |  |  | $ | 460 |  |  | $ | 343 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 9,208 |  |  | $ | 4,744 |  |

[0001375365-25-000014:notes:188]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

[0001375365-25-000014:notes:189]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 10 |  |  | $ | 8 |  |  | $ | 24,318 |  |  | $ | 42,498 |  |  | $ | 8,977 |  |  | $ | 16,474 |  |  |  |  | $ | 494 |  |  | $ | — |  |  | $ | 33,799 |  |  | $ | 58,980 |  |
| Purchases - inventory | $ | 252,426 |  |  | $ | 163,131 |  |  | $ | 238,720 |  |  | $ | 192,817 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  |  | $ | 491,680 |  |  | $ | 355,948 |  |
| Purchases - other miscellaneous items | $ | 18,866 |  |  | $ | 12,616 |  |  | $ | 1,491 |  |  | $ | 1,092 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 20,357 |  |  | $ | 13,708 |  |

[0001375365-25-000014:notes:190]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):

[0001375365-25-000014:notes:191]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Changes in accounts receivable | $ | — |  |  | $ | (1) |  |  | $ | 48 |  |  | $ | 3,260 |  |  | $ | 4,990 |  |  | $ | 1,104 |  |  |  |  | $ | 840 |  |  | $ | — |  |  | $ | 5,878 |  |  | $ | 4,363 |  |
| Changes in other receivable | $ | 577 |  |  | $ | 1,022 |  |  | $ | (3,359) |  |  | $ | (3,539) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | (2,782) |  |  | $ | (2,517) |  |
| Changes in accounts payable | $ | (48,270) |  |  | $ | 18,480 |  |  | $ | (1,491) |  |  | $ | (5,032) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (230) |  |  | $ | — |  |  | $ | (49,991) |  |  | $ | 13,448 |  |
| Changes in accrued liabilities | $ | 487 |  |  | $ | (538) |  |  | $ | 84 |  |  | $ | 5,319 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 4,781 |  |
| Changes in other long-term liabilities | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (178) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | (178) |  |
| Purchases of property, plant and equipment | $ | 10,137 |  |  | $ | 8,935 |  |  | $ | 371 |  |  | $ | 197 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 10,508 |  |  | $ | 9,132 |  |
| Unpaid property, plant and equipment | $ | 7,111 |  |  | $ | 1,492 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 7,111 |  |  | $ | 1,492 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-25-000014:notes:192]
Note 10.               Stock-based Compensation and Stockholders' Equity

[0001375365-25-000014:notes:193]
Preferred Stock

[0001375365-25-000014:notes:194]
The Company has 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by the Company’s Board of Directors at the time of issuance of such shares. As of March 31, 2025 and 2024, there were no shares of preferred stock issued and outstanding.

[0001375365-25-000014:notes:195]
[same as prior period, unchanged from 0001375365-25-000006:notes:163]

[0001375365-25-000014:notes:196]
[same as prior period, unchanged from 0001375365-25-000006:notes:164]

[0001375365-25-000014:notes:197]
[same as prior period, unchanged from 0001375365-25-000006:notes:165]

[0001375365-25-000014:notes:198]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 50,000,000, plus 10,450,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 72,460,000 shares of common stock remained reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 20,000,000 shares.

[0001375365-25-000014:notes:199]
On January 22, 2024, the stockholders of the Company approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 15,000,000 shares.

[0001375365-25-000014:notes:200]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units (“RSUs”), performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company’s outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-25-000014:notes:201]
As of March 31, 2025, the Company had 2,652,165 authorized shares available for future issuance under the 2020 Plan.

[0001375365-25-000014:notes:202]
[same as prior period, unchanged from 0001375365-25-000006:notes:170]

[0001375365-25-000014:notes:203]
[same as prior period, unchanged from 0001375365-25-000006:notes:171]

[0001375365-25-000014:notes:204]
The Company received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company. The Company did not receive any proceeds from the sale of the shares of common stock by the selling stockholders.

[0001375365-25-000014:notes:205]
On March 22, 2024, the Company completed a public offering of 20,000,000 shares of the Company's common stock at $87.50 per share. The Company received net proceeds of $1,731.5 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.

[0001375365-25-000014:notes:206]
[same as prior period, unchanged from 0001375365-25-000006:notes:174]

[0001375365-25-000014:notes:207]
[same as prior period, unchanged from 0001375365-25-000006:notes:175]

[0001375365-25-000014:notes:208]
[same as prior period, unchanged from 0001375365-25-000006:notes:176]

[0001375365-25-000014:notes:209]
[same as prior period, unchanged from 0001375365-25-000006:notes:177]

[0001375365-25-000014:notes:210]
[same as prior period, unchanged from 0001375365-25-000006:notes:178]

[0001375365-25-000014:notes:211]
[same as prior period, unchanged from 0001375365-25-000006:notes:179]

[0001375365-25-000014:notes:212]
The fair value of stock option grants for the three and nine months ended March 31, 2025 and 2024 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-25-000014:notes:213]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Risk-free interest rate | 4.05% - 4.39% |  | 4.01% - 4.09% |  | 3.82% - 4.39% |  | 4.01% - 4.78% |
| Expected term | 3.00 years - 5.98 years |  | 3.0 years - 5.99 years |  | 3.00 years - 5.98 years |  | 3.00 years - 5.99 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 73.06% - 95.28% |  | 59.74% - 64.55% |  | 63.67% - 95.28% |  | 56.87% - 64.55% |
| Weighted-average fair value of options | $18.97 |  | $29.01 |  | $26.03 |  | $20.58 |

[0001375365-25-000014:notes:214]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2025 and 2024 (in thousands):

[0001375365-25-000014:notes:215]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of sales | $ | 7,060 |  |  | $ | 3,221 |  |  | $ | 17,713 |  |  | $ | 12,680 |  |
| Research and development | 54,254 |  |  | 24,856 |  |  | 141,590 |  |  | 86,005 |  |
| Sales and marketing | 9,923 |  |  | 4,993 |  |  | 27,245 |  |  | 14,998 |  |
| General and administrative | 13,467 |  |  | 23,037 |  |  | 44,292 |  |  | 42,864 |  |
| Stock-based compensation expense before taxes | 84,704 |  |  | 56,107 |  |  | 230,840 |  |  | 156,547 |  |
| Income tax impact | (22,433) |  |  | (47,023) |  |  | (57,442) |  |  | (72,641) |  |
| Stock-based compensation expense, net | $ | 62,271 |  |  | $ | 9,084 |  |  | $ | 173,398 |  |  | $ | 83,906 |  |

[0001375365-25-000014:notes:216]
During the three and nine months ended March 31, 2025, stock-based compensation expense capitalized to our condensed consolidated balance sheets was $0.2 million and $0.5 million, respectively. During the three and nine months ended March 31, 2024, there was no stock-based compensation expense capitalized to our condensed consolidated balance sheets.

[0001375365-25-000014:notes:217]
[same as prior period, unchanged from 0001375365-25-000006:notes:186]

[0001375365-25-000014:notes:218]
[same as prior period, unchanged from 0001375365-25-000006:notes:187]

[0001375365-25-000014:notes:219]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 10,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). As of March 31, 2025, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000014:notes:220]
[same as prior period, unchanged from 0001375365-25-000006:notes:189]

[0001375365-25-000014:notes:221]
[same as prior period, unchanged from 0001375365-25-000006:notes:190]

[0001375365-25-000014:notes:222]
[same as prior period, unchanged from 0001375365-25-000006:notes:191]

[0001375365-25-000014:notes:223]
[same as prior period, unchanged from 0001375365-25-000006:notes:192]

[0001375365-25-000014:notes:224]
[same as prior period, unchanged from 0001375365-25-000006:notes:193]

[0001375365-25-000014:notes:225]
[same as prior period, unchanged from 0001375365-25-000006:notes:194]

[0001375365-25-000014:notes:226]
During the three and nine months ended March 31, 2024, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.0 million and $0.7 million, respectively. As of June 30, 2024, the Company had no unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-25-000014:notes:227]
[same as prior period, unchanged from 0001375365-25-000006:notes:196]

[0001375365-25-000014:notes:228]
[same as prior period, unchanged from 0001375365-25-000006:notes:197]

[0001375365-25-000014:notes:229]
The achievement status of the operational and stock price milestones as of March 31, 2025 was as follows:

[0001375365-25-000014:notes:230]
| Annualized Revenue Milestone (in billions)(1) |  | Achievement Status |  | Stock Price Milestone(1) |  | Achievement Status |
| $13.0 |  | Achieved (6) |  | $45.00 |  | Achieved (2) |
| $15.0 |  | Achieved (7) |  | $60.00 |  | Achieved (3) |
| $17.0 |  | Achieved (8) |  | $75.00 |  | Achieved (4) |
| $19.0 |  | Achieved (9) |  | $90.00 |  | Achieved (5) |
| $21.0 |  | Probable |  | $110.00 |  | Not yet achieved |

[0001375365-25-000014:notes:231]
[same as prior period, unchanged from 0001375365-25-000006:notes:200]

[0001375365-25-000014:notes:232]
[same as prior period, unchanged from 0001375365-25-000006:notes:201]

[0001375365-25-000014:notes:233]
[same as prior period, unchanged from 0001375365-25-000006:notes:202]

[0001375365-25-000014:notes:234]
[same as prior period, unchanged from 0001375365-25-000006:notes:203]

[0001375365-25-000014:notes:235]
[same as prior period, unchanged from 0001375365-25-000006:notes:204]

[0001375365-25-000014:notes:236]
(6)On February 27, 2025, the Compensation Committee certified achievement of the $13.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of June 30, 2024.

[0001375365-25-000014:notes:237]
(7)On April 22, 2025, the Compensation Committee certified achievement of the $15.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000014:notes:238]
(8)On April 22, 2025, the Compensation Committee certified achievement of the $17.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000014:notes:239]
(9)On April 22, 2025, the Compensation Committee certified achievement of the $19.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of December 31, 2024.

[0001375365-25-000014:notes:240]
During the three and nine months ended March 31, 2025, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $0.9 million and $12.4 million, respectively. As of March 31, 2025, the Company had $6.4 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2025 is expected to be recognized over a period of 1.75 years. During the three and nine months ended March 31, 2024, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $16.9 million and $19.4 million, respectively. As of March 31, 2024, the Company had $36.9 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2024 is expected to be recognized over a period of 2.5 years.

[0001375365-25-000014:notes:241]
[same as prior period, unchanged from 0001375365-25-000006:notes:206]

[0001375365-25-000014:notes:242]
The following table summarizes stock option activity during the nine months ended March 31, 2025 under all plans:

[0001375365-25-000014:notes:243]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2024 |  | 35,443,550 |  |  | $ | 17.57 |  |  | $ | — |  |  | — |  |  |  |
| Granted |  | 3,648,725 |  |  | $ | 40.95 |  |  | $ | 26.03 |  |  | — |  |  |  |
| Exercised |  | (4,354,877) |  |  | $ | 4.80 |  |  | $ | — |  |  | — |  |  |  |
| Forfeited/Cancelled |  | (666,062) |  |  | $ | 34.12 |  |  | $ | — |  |  | — |  |  |  |
| Balance as of March 31, 2025 |  | 34,071,336 |  |  | $ | 21.38 |  |  | $ | — |  |  | 7.09 |  |  |
| Options vested and expected to vest at March 31, 2025 |  | 34,071,336 |  |  | $ | 21.38 |  |  | $ | — |  |  | 7.09 |  |  |
| Options exercisable at March 31, 2025 |  | 19,525,313 |  |  | $ | 8.83 |  |  | $ | — |  |  | 5.93 |  |  |

[0001375365-25-000014:notes:244]
The total pretax intrinsic value of options exercised during the three and nine months ended March 31, 2025 was $46.8 million and $162.6 million, respectively. The total pretax intrinsic value of options exercised during the three and nine months ended March 31, 2024 was $317.7 million and $400.3 million, respectively.

[0001375365-25-000014:notes:245]
As of March 31, 2025, $195.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.85 years.

[0001375365-25-000014:notes:246]
[same as prior period, unchanged from 0001375365-25-000006:notes:211]

[0001375365-25-000014:notes:247]
The following table summarizes RSU activity during the nine months ended March 31, 2025 under all plans:

[0001375365-25-000014:notes:248]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2024 | 21,272,990 |  |  | $ | 24.19 |  |  |  |  |  |  |
| Granted | 8,171,728 |  |  | $ | 40.72 |  |  |  |  |  |  |
| Released | (7,613,580) |  |  | $ | 17.07 |  |  |  |  |  |  |
| Forfeited | (1,137,456) |  |  | $ | 33.59 |  |  |  |  |  |  |
| Balance as of March 31, 2025 | 20,693,682 |  |  | $ | 32.83 |  |  |  |  |  |  |

[0001375365-25-000014:notes:249]
As of March 31, 2025, $587.5 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.51 years.


## smci:SummaryOfOperationalAndStockPriceMilestonesTableTextBlock

[0001375365-25-000014:notes:250]
As of March 31, 2025, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000014:notes:251]
(8)On April 22, 2025, the Compensation Committee certified achievement of the $17.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of September 30, 2024.
(9)On April 22, 2025, the Compensation Committee certified achievement of the $19.0 billion revenue milestone based on the Company’s previous four consecutive fiscal quarters revenue as of December 31, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-25-000014:notes:252]
Note 11.               Income Taxes

[0001375365-25-000014:notes:253]
The Company recorded a provision for income taxes of $5.8 million and $137.5 million for the three and nine months ended March 31, 2025, respectively, and tax benefits of $(20.0) million and provision of $61.7 million for the three and nine months ended March 31, 2024, respectively. The effective tax rate was 5.1% and 13.9% for the three and nine months ended March 31, 2025, respectively, and (5.2)% and 6.7% for the three and nine months ended March 31, 2024, respectively. The effective tax rates for the three and nine months ended March 31, 2025 are higher than these for the three and nine months ended March 31, 2024, primarily due to the decrease in the stock compensation tax deduction driven by the decrease in the Company's stock price. The effective tax rates for the three and nine months of fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21%, primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit.

[0001375365-25-000014:notes:254]
[same as prior period, unchanged from 0001375365-25-000006:notes:216]

[0001375365-25-000014:notes:255]
In general, the federal statute of limitations remains open for tax years ended June 30, 2022 through 2024. Various states' statutes of limitations remain open in general for tax years ended June 30, 2020 through 2024. Certain statutes of limitations in major foreign jurisdictions remain open for the tax years ended June 30, 2019 through 2024. It is reasonably possible that the Company's gross unrecognized tax benefits will decrease by approximately $3.7 million, in the next 12 months, due to the lapse of the statute of limitations in certain jurisdictions. These adjustments, if recognized, would positively impact the Company's effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-25-000014:notes:256]
Note 12.               Commitments and Contingencies

[0001375365-25-000014:notes:257]
Litigation and claims

[0001375365-25-000014:notes:258]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Averza and Covey Financial complaints are pending Court appointment of a lead plaintiff. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000014:notes:259]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000014:notes:260]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000014:notes:261]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. The Company is cooperating with these document requests and there have been no charges brought against any person as of the date of this filing.

[0001375365-25-000014:notes:262]
Other legal proceedings and indemnifications

[0001375365-25-000014:notes:263]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of March 31, 2025 and any prior periods.

[0001375365-25-000014:notes:264]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-25-000014:notes:265]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2025, these remaining non-cancelable commitments were $1.8 billion, including $107.5 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of March 31, 2025 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.

[0001375365-25-000014:notes:266]
Lease Commitments— See Note 8 “Leases”, for a discussion of the Company's operating lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-25-000014:notes:267]
Note 13.               Segment Reporting

[0001375365-25-000014:notes:268]
The Company operates and reports in one operating segment focused on developing and providing high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s Chief Executive Officer is the chief operating decision maker.

[0001375365-25-000014:notes:269]
[same as prior period, unchanged from 0001375365-25-000006:notes:230]

[0001375365-25-000014:notes:270]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Long-lived assets: |  |  |  |
| United States | $ | 310,538 |  |  | $ | 281,874 |  |
| Taiwan | 117,929 |  |  | 107,878 |  |
| Malaysia | 59,542 |  |  | 21,739 |  |
| Other | 4,556 |  |  | 2,517 |  |
|  | $ | 492,565 |  |  | $ | 414,008 |  |

[0001375365-25-000014:notes:271]
The table above excludes other assets, goodwill and intangible assets. Operating lease assets in the United States were $143.0 million as of March 31, 2025. Operating lease assets in the United States were $29.3 million as of June 30, 2024. Operating lease assets in all other countries were less than 10% as of March 31, 2025 and June 30, 2024.

[0001375365-25-000014:notes:272]
For the three months ended March 31, 2025 and 2024, 60.2% and 69.7% of the Company’s revenues were from the United States, and 14.2% and 1.5% of the Company's revenues were from Thailand, respectively. For the nine months ended March 31, 2025 and 2024, 67.0% and 71.7% of the Company’s revenues were from the United States. For the nine months ended March 31, 2025 and 2024, all other countries were individually less than 10%. The Company’s revenue by geographic region is based on where the products were shipped to for the three and nine months ended March 31, 2025 and 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001375365-25-000014:notes:273]
Insider Trading Arrangements

[0001375365-25-000014:notes:274]
During the three months ended March 31, 2025, the following officer (as defined in Rule 16a-1(f) under the Exchange Act) of the Company adopted or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.

[0001375365-25-000014:notes:275]
| Name |  | Action |  | Adoption/Termination Date |  | Trading Arrangement |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
|  |  |  | Rule 10b5-1* |  | Non-Rule 10b5-1** |  |  |
| Charles Liang(President, Chief Executive Officer, and Chairman) |  | Adoption |  | February 28, 2025 |  | X |  |  |  | 500,000 |  | December 31, 2025 |

[0001375365-25-000014:notes:276]
_________________

[0001375365-25-000014:notes:277]
* Contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.

[0001375365-25-000014:notes:278]
** “Non-Rule 10b5-1 trading arrangement” as defined in Item 408(c) of Regulation S-K under the Exchange Act.
