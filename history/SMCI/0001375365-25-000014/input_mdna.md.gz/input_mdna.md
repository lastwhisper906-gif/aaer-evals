# SMCI MD&A — 0001375365-25-000014


## mdna

[0001375365-25-000014:mdna:1]
[same as prior period, unchanged from 0001375365-25-000006:mdna:1]

[0001375365-25-000014:mdna:2]
[same as prior period, unchanged from 0001375365-25-000006:mdna:2]

[0001375365-25-000014:mdna:3]
[same as prior period, unchanged from 0001375365-25-000006:mdna:3]

[0001375365-25-000014:mdna:4]
We are a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, we are committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the United States, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, graphic processing units (“GPUs”), storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-25-000014:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. For the three months ended March 31, 2025 and 2024, our net income was $108.8 million and $402.5 million, respectively. For the nine months ended March 31, 2025 and 2024, our net income was $853.7 million and $855.4 million, respectively.

[0001375365-25-000014:mdna:6]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offering and customer service and support, particularly as we focus more on large enterprise and data center customers. A key component of our strategy is our Data Center Building Block Solutions, which significantly reduces data center build time and supports the full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services and maintenance. We must also develop our sales partners and distribution channels to further expand our market share.

[0001375365-25-000014:mdna:7]
SMCI | Q3 2025 Form 10-Q | 40

[0001375365-25-000014:mdna:8]
We measure our financial success based on various indicators, including growth in net sales, gross profit margin, operating margin, and growth in net income per common share. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. To achieve this, we work closely with the developers and manufacturers of key components, ensuring we leverage emerging technologies as they become available. Historically, our ability to quickly introduce new products has allowed us to capitalize on technology transitions such as the launch of new GPUs, microprocessors and storage technologies. As a result, we closely monitor the product introduction cycles of industry leaders, including NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others. This focus also influences our research and development expenditures as we continue to invest in both our current and future product development efforts.

[0001375365-25-000014:mdna:9]
[same as prior period, unchanged from 0001375365-25-000006:mdna:7]

[0001375365-25-000014:mdna:10]
The growing use of artificial intelligence (“AI”), which requires enhanced datacenter capabilities, has substantially increased demand for our products. We expect this trend to continue, with further demand for datacenter expansion driven by the AI market. As a result, we will continue to enhance our product capabilities and expand our service offerings to address the growing demand in the AI market and datacenter markets. We believe that our ability to tailor certain products to the unique needs of these sectors sets us apart from many competitors and positions us to capture an even greater market share going forward.

[0001375365-25-000014:mdna:11]
[same as prior period, unchanged from 0001375365-25-000006:mdna:9]

[0001375365-25-000014:mdna:12]
Our business, results of operations, and financial outlook have been, and may continue to be, impacted by adverse macroeconomic conditions and uncertainties. These challenges include labor shortages, global supply chain disruptions, tariffs, inflation, higher interest rates, fluctuations in capital markets, and ongoing global economic and geopolitical developments. These challenges could, among other things, impact demand for our products as well as our ability to supply products, both of which could impact net sales, affect our operating costs due to foreign exchange rate movements and impact our margins due to exogenous factors such as new and increased tariffs. While many of these macroeconomic factors could have a long-term impact, others may have a short-term impact which could lead to our financial results not being comparable on a period to period basis.

[0001375365-25-000014:mdna:13]
[same as prior period, unchanged from 0001375365-25-000006:mdna:11]

[0001375365-25-000014:mdna:14]
The following is a summary of our financial highlights for the three months ended March 31, 2025 and 2024:

[0001375365-25-000014:mdna:15]
•Net sales increased by 19.5% in the three months ended March 31, 2025 as compared to the three months ended March 31, 2024.

[0001375365-25-000014:mdna:16]
•Gross margin decreased to 9.6% in the three months ended March 31, 2025 from 15.5% in the three months ended March 31, 2024.

[0001375365-25-000014:mdna:17]
•Operating expenses increased by 33.9% as compared to the three months ended March 31, 2024 and were equal to 6.4% and 5.6% of net sales in the three months ended March 31, 2025 and 2024, respectively.

[0001375365-25-000014:mdna:18]
•Effective tax rate increased to 5.1% in the three months ended March 31, 2025 from (5.2)% in the three months ended March 31, 2024.

[0001375365-25-000014:mdna:19]
SMCI | Q3 2025 Form 10-Q | 41

[0001375365-25-000014:mdna:20]
[same as prior period, unchanged from 0001375365-25-000006:mdna:17]

[0001375365-25-000014:mdna:21]
[same as prior period, unchanged from 0001375365-25-000006:mdna:18]

[0001375365-25-000014:mdna:22]
[same as prior period, unchanged from 0001375365-25-000006:mdna:19]

[0001375365-25-000014:mdna:23]
[same as prior period, unchanged from 0001375365-25-000006:mdna:21]

[0001375365-25-000014:mdna:24]
Components of Results of Operations

[0001375365-25-000014:mdna:25]
[same as prior period, unchanged from 0001375365-25-000006:mdna:25]

[0001375365-25-000014:mdna:26]
Net sales primarily consist of sales of our server and storage solutions, including systems and related services, subsystems, and accessories. The key factors that impact net sales of our server and storage systems are the number of servers and racks sold and the average selling prices per server or rack. For subsystems and accessories, the main drivers of net sales are the number of units shipped and the average selling price per unit. The prices for our server and storage systems can vary widely depending on the configuration, including factors such as speed, functionality and performance of key components, including central processing units (“CPUs”), GPUs, solid state drives (“SSDs”), cooling systems and memory. Similarly, the prices for our subsystems and accessories fluctuate depending on the relative value of the specific item being purchased. such as power supplies, server boards, chassis or other accessories.

[0001375365-25-000014:mdna:27]
[same as prior period, unchanged from 0001375365-25-000006:mdna:45]

[0001375365-25-000014:mdna:28]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of components and materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges.

[0001375365-25-000014:mdna:29]
Research and Development

[0001375365-25-000014:mdna:30]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities.

[0001375365-25-000014:mdna:31]
Sales and Marketing

[0001375365-25-000014:mdna:32]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for trade shows, sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses.

[0001375365-25-000014:mdna:33]
SMCI | Q3 2025 Form 10-Q | 42

[0001375365-25-000014:mdna:34]
General and Administrative

[0001375365-25-000014:mdna:35]
[same as prior period, unchanged from 0001375365-25-000006:mdna:60]

[0001375365-25-000014:mdna:36]
Other (Expense) Income, Net and Interest Expense

[0001375365-25-000014:mdna:37]
Other (expense) income, net consists primarily of interest earned on our investments, cash balances and foreign exchange gains and losses. Interest expense represents interest expense on our term loans and lines of credit and amortization of the 2029 Convertible Notes and 2028 Convertible Notes issuance costs.

[0001375365-25-000014:mdna:38]
Income Tax (Provision) Benefit

[0001375365-25-000014:mdna:39]
[same as prior period, unchanged from 0001375365-25-000006:mdna:83]

[0001375365-25-000014:mdna:40]
SMCI | Q3 2025 Form 10-Q | 43

[0001375365-25-000014:mdna:41]
The following table presents certain items of our condensed consolidated statements of operations for the three and nine months ended March 31, 2025 and 2024 (dollars in millions):

[0001375365-25-000014:mdna:42]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 4,599.9 |  |  | $ | 3,850.1 |  |  | $ | 16,215.1 |  |  | $ | 9,634.7 |  |
| Cost of sales | 4,159.7 |  |  | 3,252.7 |  |  | 14,329.3 |  |  | 8,119.3 |  |
| Gross profit | 440.2 |  |  | 597.4 |  |  | 1,885.8 |  |  | 1,515.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 162.9 |  |  | 116.2 |  |  | 453.3 |  |  | 336.1 |  |
| Sales and marketing | 60.0 |  |  | 49.7 |  |  | 208.4 |  |  | 133.8 |  |
| General and administrative | 70.5 |  |  | 53.1 |  |  | 199.5 |  |  | 123.2 |  |
| Total operating expenses | 293.4 |  |  | 219.1 |  |  | 861.2 |  |  | 593.1 |  |
| Income from operations | 146.8 |  |  | 378.3 |  |  | 1,024.6 |  |  | 922.3 |  |
| Other (expense) income, net | (18.3) |  |  | 10.0 |  |  | 1.9 |  |  | 8.8 |  |
| Interest expense | (13.4) |  |  | (6.2) |  |  | (37.3) |  |  | (16.2) |  |
| Income before income tax provision | 115.1 |  |  | 382.1 |  |  | 989.2 |  |  | 914.9 |  |
| Income tax (provision) benefit | (5.8) |  |  | 20.0 |  |  | (137.5) |  |  | (61.7) |  |
| Share of income from equity investee, net of taxes | (0.5) |  |  | 0.4 |  |  | 2.0 |  |  | 2.2 |  |
| Net income | $ | 108.8 |  |  | $ | 402.5 |  |  | $ | 853.7 |  |  | $ | 855.4 |  |

[0001375365-25-000014:mdna:43]
*Totals may not sum due to rounding.

[0001375365-25-000014:mdna:44]
The following table presents certain items of our condensed consolidated statements of operations expressed as a percentage of revenue for the three and nine months ended March 31, 2025 and 2024:

[0001375365-25-000014:mdna:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 90.4 | % |  | 84.5 | % |  | 88.4 | % |  | 84.3 | % |  |
| Gross profit | 9.6 | % |  | 15.5 | % |  | 11.6 | % |  | 15.7 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development | 3.5 | % |  | 2.9 | % |  | 2.8 | % |  | 3.4 | % |  |
| Sales and marketing | 1.3 | % |  | 1.3 | % |  | 1.3 | % |  | 1.4 | % |  |
| General and administrative | 1.6 | % |  | 1.4 | % |  | 1.2 | % |  | 1.3 | % |  |
| Total operating expenses | 6.4 | % |  | 5.6 | % |  | 5.3 | % |  | 6.1 | % |  |
| Income from operations | 3.2 | % |  | 9.9 | % |  | 6.3 | % |  | 9.6 | % |  |
| Other (expense) income, net | (0.4) | % |  | 0.3 | % |  | 0.0 | % |  | 0.1 | % |  |
| Interest expense | (0.3) | % |  | (0.2) | % |  | (0.2) | % |  | (0.2) | % |  |
| Income before income tax provision | 2.5 | % |  | 10.0 | % |  | 6.1 | % |  | 9.5 | % |  |
| Income tax (provision) benefit | (0.1) | % |  | 0.5 | % |  | (0.8) | % |  | (0.6) | % |  |
| Share of income from equity investee, net of taxes | — | % | * | — | % | * | — | % | * | — | % | * |
| Net income | 2.4 | % |  | 10.5 | % |  | 5.3 | % |  | 8.9 | % |  |

[0001375365-25-000014:mdna:46]
[same as prior period, unchanged from 0001375365-25-000006:mdna:24]

[0001375365-25-000014:mdna:47]
SMCI | Q3 2025 Form 10-Q | 44

[0001375365-25-000014:mdna:48]
Nets Sales by Product Type

[0001375365-25-000014:mdna:49]
The following table presents net sales by product type for the three and nine months ended March 31, 2025 and 2024 (dollars in millions):

[0001375365-25-000014:mdna:50]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Server and storage systems | $ | 4,458.9 |  | $ | 3,698.5 |  | $ | 760.4 |  |  | 20.6 | % |  | $ | 15,693.8 |  | $ | 9,100.7 |  | $ | 6,593.1 |  |  | 72.4 | % |
| Percentage of total net sales | 96.9 | % |  | 96.1 | % |  |  |  |  |  | 96.8 | % |  | 94.5 | % |  |  |  |  |
| Subsystems and accessories | $ | 141.0 |  | $ | 151.6 |  | $ | (10.6) |  |  | (7.0) | % |  | $ | 521.3 |  | $ | 534.0 |  | $ | (12.7) |  |  | (2.4) | % |
| Percentage of total net sales | 3.1 | % |  | 3.9 | % |  |  |  |  |  | 3.2 | % |  | 5.5 | % |  |  |  |  |
| Total net sales | $ | 4,599.9 |  |  | $ | 3,850.1 |  |  | $ | 749.8 |  |  | 19.5 | % |  | $ | 16,215.1 |  |  | $ | 9,634.7 |  |  | $ | 6,580.4 |  |  | 68.3 | % |

[0001375365-25-000014:mdna:51]
[same as prior period, unchanged from 0001375365-25-000006:mdna:31]

[0001375365-25-000014:mdna:52]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:53]
The $760.4 million increase in net sales of our server and storage systems was primarily driven by an increase in the demand from customers for GPU servers, high performance computing (“HPC”), and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling price (“ASP”).

[0001375365-25-000014:mdna:54]
The $10.6 million decrease in net sales for our subsystems and accessories of 7.0% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling them as parts of subsystems and accessories.

[0001375365-25-000014:mdna:55]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:56]
The $6,593.1 million increase in net sales of our server and storage systems was primarily driven by an increase in the demand from customers for GPU servers, HPC, and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of ASP.

[0001375365-25-000014:mdna:57]
The $12.7 million decrease in net sales for our subsystems and accessories of 2.4% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling them as parts of subsystems and accessories.

[0001375365-25-000014:mdna:58]
Nets Sales by Geography

[0001375365-25-000014:mdna:59]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2025 and 2024 (dollars in millions):

[0001375365-25-000014:mdna:60]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months EndedMarch 31, |  | Change |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| United States | $ | 2,768.2 |  |  | $ | 2,685.2 |  |  | $ | 83.0 |  |  | 3.1 | % |  | $ | 10,856.5 |  |  | $ | 6,910.3 |  |  | $ | 3,946.2 |  |  | 57.1 | % |
| Percentage of total net sales | 60.2 | % |  | 69.7 | % |  |  |  |  |  | 67.0 | % |  | 71.7 | % |  |  |  |  |
| Asia | $ | 1,354.3 |  |  | $ | 764.6 |  |  | $ | 589.7 |  |  | 77.1 | % |  | $ | 3,077.2 |  |  | $ | 1,646.3 |  |  | $ | 1,430.9 |  |  | 86.9 | % |
| Percentage of total net sales | 29.4 | % |  | 19.9 | % |  |  |  |  |  | 19.0 | % |  | 17.1 | % |  |  |  |  |
| Europe | $ | 290.1 |  |  | $ | 297.7 |  |  | $ | (7.6) |  |  | (2.6) | % |  | $ | 1,869.7 |  |  | $ | 777.0 |  |  | $ | 1,092.7 |  |  | 140.6 | % |
| Percentage of total net sales | 6.3 | % |  | 7.7 | % |  |  |  |  |  | 11.5 | % |  | 8.1 | % |  |  |  |  |
| Others | $ | 187.3 |  |  | $ | 102.6 |  |  | $ | 84.7 |  |  | 82.6 | % |  | $ | 411.7 |  |  | $ | 301.1 |  |  | $ | 110.6 |  |  | 36.7 | % |
| Percentage of total net sales | 4.1 | % |  | 2.7 | % |  |  |  |  |  | 2.5 | % |  | 3.1 | % |  |  |  |  |
| Total net sales | $ | 4,599.9 |  |  | $ | 3,850.1 |  |  |  |  |  |  | $ | 16,215.1 |  |  | $ | 9,634.7 |  |  |  |  |  |

[0001375365-25-000014:mdna:61]
SMCI | Q3 2025 Form 10-Q | 45

[0001375365-25-000014:mdna:62]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:63]
The $749.8 million increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC, and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from Asia where these customers have experienced significant growth. The $589.7 million increase of net sales in Asia is mainly due to an increase in net sales in Japan, and Thailand.

[0001375365-25-000014:mdna:64]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:65]
The $6,580.4 million increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC, and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States, Asia and Europe where these customers have experienced significant growth. The increase of net sales in Europe and Asia is mainly due to an increase in net sales in the United Kingdom, Sweden, Spain, Japan, Singapore and Thailand.

[0001375365-25-000014:mdna:66]
Cost of Sales

[0001375365-25-000014:mdna:67]
Cost of sales and gross margin for the three and nine months ended March 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000014:mdna:68]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Cost of sales | $ | 4,159.7 |  | $ | 3,252.7 |  | $ | 907.0 |  |  | 27.9 | % |  | $ | 14,329.3 |  | $ | 8,119.3 |  | $ | 6,210.0 |  |  | 76.5 | % |
| Gross profit | $ | 440.2 |  | $ | 597.4 |  | $ | (157.2) |  |  | (26.3) | % |  | $ | 1,885.8 |  | $ | 1,515.4 |  | $ | 370.4 |  |  | 24.4 | % |
| Gross margin | 9.6 | % |  | 15.5 | % |  |  |  | (5.9) | % |  | 11.6 | % |  | 15.7 | % |  |  |  | (4.1) | % |

[0001375365-25-000014:mdna:69]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:70]
The $907.0 million increase in cost of sales can primarily be attributed to an increase of $772.5 million in costs of materials, contract manufacturing expenses, and the expedited recognition of costs in order to accelerate time-to-market for new products that primarily resulted in the increase in net sales volume. Additionally, there was a $109.6 million increase in inventory write-down adjustment, mainly from prior generations of GPUs and related components, along with additional reserves established during the period. Further, overhead costs increased by $18.0 million and freight costs increased by a $6.9 million, primarily due to the increase in net sales volume.

[0001375365-25-000014:mdna:71]
The 5.9% decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition, a shift in product focus towards modular system designs that offer scalability and flexibility to meet the diverse needs of data centers, and a change in customer mix, including an increased presence in international markets.

[0001375365-25-000014:mdna:72]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:73]
The $6,210.0 million increase in cost of sales can primarily be attributed to an increase of $5,978.6 million in costs of materials, contract manufacturing expenses, and expedited costs to accelerate time-to-market for new products primarily related to the increase in net sales volume. Additionally, there was a $131.4 million increase in inventory write-down adjustment, mainly from prior generations of GPU and related components, along with additional reserves established during the period. Further, overhead costs increased by $59.1 million and freight costs increased by $40.9 million, primarily due to the increase in net sales volume.

[0001375365-25-000014:mdna:74]
The 4.1% decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition, a shift in product focus towards modular system designs that offer scalability and flexibility to meet the diverse needs of data centers, and a change in customer mix, including an increased presence in international markets.

[0001375365-25-000014:mdna:75]
SMCI | Q3 2025 Form 10-Q | 46

[0001375365-25-000014:mdna:76]
[same as prior period, unchanged from 0001375365-25-000006:mdna:57]

[0001375365-25-000014:mdna:77]
Operating expenses for the three and nine months ended March 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000014:mdna:78]
|  | Three Months Ended March 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Research and development | $ | 162.9 |  | $ | 116.2 |  | $ | 46.7 |  |  | 40.2 | % |  | $ | 453.3 |  | $ | 336.1 |  | $ | 117.2 |  |  | 34.9 | % |
| Percentage of total net sales | 3.5 | % |  | 2.9 | % |  |  |  |  |  | 2.8 | % |  | 3.4 | % |  |  |  |  |
| Sales and marketing | $ | 60.0 |  | $ | 49.7 |  | $ | 10.3 |  |  | 20.7 | % |  | $ | 208.4 |  | $ | 133.8 |  | $ | 74.6 |  |  | 55.8 | % |
| Percentage of total net sales | 1.3 | % |  | 1.3 | % |  |  |  |  |  | 1.3 | % |  | 1.4 | % |  |  |  |  |
| General and administrative | $ | 70.5 |  | $ | 53.1 |  | $ | 17.4 |  |  | 32.8 | % |  | $ | 199.5 |  | $ | 123.2 |  | $ | 76.3 |  |  | 61.9 | % |
| Percentage of total net sales | 1.5 | % |  | 1.4 | % |  |  |  |  |  | 1.2 | % |  | 1.3 | % |  |  |  |  |
| Total operating expenses | $ | 293.4 |  | $ | 219.1 |  | $ | 74.3 |  |  | 33.9 | % |  | $ | 861.2 |  | $ | 593.1 |  | $ | 268.1 |  |  | 45.2 | % |
| Percentage of total net sales | 6.3 | % |  | 5.6 | % |  |  |  |  |  | 5.3 | % |  | 6.1 | % |  |  |  |  |

[0001375365-25-000014:mdna:79]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:80]
Research and development expenses. The $46.7 million increase in research and development expenses was driven by a $41.9 million increase in employee-related costs driven by our planned workforce expansion as we continue to invest in key talent, primarily comprised of additional stock compensation expense and salary increases. In addition, there was a $5.1 million increase in product development costs to support next generation products and technologies. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-25-000014:mdna:81]
Sales and marketing expenses. The $10.3 million increase in sales and marketing expenses was primarily driven by a $8.6 million increase in employee-related costs, driven by increased strategic hiring across sales and marketing functions to support our growth and sales strategy, primarily comprised of additional stock-based compensation expense and salary increases. In addition, there was $13.8 million increase in advertising and other expenses, which was partially offset by a $12.1 million increase in marketing development funds received.

[0001375365-25-000014:mdna:82]
General and administrative expenses. The $17.4 million increase in general and administrative expenses was driven by a $19.0 million increase in professional and service fees primarily from additional external accounting, tax, legal, and advisory services necessary to support our external reporting related activities. This was partially offset by a $3.1 million decrease in employee-related costs, primarily due to lower stock-based compensation expense. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000014:mdna:83]
SMCI | Q3 2025 Form 10-Q | 47

[0001375365-25-000014:mdna:84]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:85]
Research and development expenses. The $117.2 million increase in research and development expenses was driven by a $100.4 million increase in employee-related costs driven by our planned workforce expansion as we continue to invest in key talent, primarily comprised of stock-based compensation expense and salary increases. In addition, there was a $22.1 million increase in product development costs to support next generation products and technologies, which was partially offset by a $5.3 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of developing next generation products and technologies.

[0001375365-25-000014:mdna:86]
Sales and marketing expenses. The $74.6 million increase in sales and marketing expenses was primarily driven by a $47.2 million increase in employee-related costs, driven by increased strategic hiring across sales and marketing functions to support our growth and sales strategy, primarily comprised of additional stock-based compensation expense and salary increases. In addition, there was a $45.0 million increase in advertising and other expenses, which was partially offset by a $17.6 million increase in marketing development funds received.

[0001375365-25-000014:mdna:87]
General and administrative expenses. The $76.3 million increase in general and administrative expenses was driven by a $55.1 million increase in professional and service fees primarily from additional external accounting, tax, legal, and advisory services necessary to support our external reporting related activities. In addition, there was a $13.2 million increase in employee-related costs driven by increased strategic hiring across various finance and other functions, comprised primarily of stock-based compensation expense and salary increases, and an $8.0 million increase in facilities related expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000014:mdna:88]
Other (Expense) Income, Net and Interest Expense

[0001375365-25-000014:mdna:89]
Other (expense) income, net and Interest expense for the three and nine months ended March 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000014:mdna:90]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Other (expense) income, net | $ | (18.3) |  |  | $ | 10.0 |  |  | $ | (28.3) |  |  | (283.0) | % |  | $ | 1.9 |  |  | $ | 8.8 |  |  | $ | (6.9) |  |  | (78.4) | % |
| Interest expense | (13.4) |  |  | (6.2) |  |  | (7.2) |  |  | 116.1 | % |  | (37.3) |  |  | (16.2) |  |  | (21.1) |  |  | 130.2 | % |
| Other (expense) income, net and interest expense | $ | (31.7) |  |  | $ | 3.8 |  |  | $ | (35.5) |  |  | (934.2) | % |  | $ | (35.4) |  |  | $ | (7.4) |  |  | $ | (28.0) |  |  | 378.4 | % |

[0001375365-25-000014:mdna:91]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:92]
The $28.3 million decrease in other (expense) income, net and interest expense was primarily driven by a $30.3 million loss on extinguishment of the 2029 convertible notes due to the amendment of the existing notes (see Note 7 “Convertible Notes”), and a $6.2 million decrease in foreign exchange gain. The decrease was partially offset by a $9.8 million increase in interest income.

[0001375365-25-000014:mdna:93]
The increase in interest expense of $7.2 million was primarily driven by interest charges on the 2029 Convertible Notes and 2028 Convertible Notes of $11.5 million, which was partially offset by decrease in interest expenses associated with the Company's reduced utilization of its lines of credit of $4.3 million.

[0001375365-25-000014:mdna:94]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:95]
The $6.9 million decrease in other (expense) income, net and interest expense was primarily attributable to a $30.3 million decrease from the loss on extinguishment of the 2029 convertible notes due to the amendment of the existing notes (see Note 7 “Convertible Notes”), partially offset by a $22.9 million increase in interest income.

[0001375365-25-000014:mdna:96]
The increase in interest expense of $21.1 million was primarily driven by interest charges on the 2029 Convertible Notes and 2028 Convertible Notes of $14.4 million, as well as an increase in interest expenses associated with the Company's line of credit of $6.7 million.

[0001375365-25-000014:mdna:97]
SMCI | Q3 2025 Form 10-Q | 48

[0001375365-25-000014:mdna:98]
Income Tax (Provision) Benefit

[0001375365-25-000014:mdna:99]
Income tax (provision) benefit and effective tax rates for the three and nine months ended March 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-25-000014:mdna:100]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Income tax (provision) benefit | $ | (5.8) |  |  | $ | 20.0 |  | $ | (25.8) |  |  | (129.0) | % |  | $ | (137.5) |  | $ | (61.7) |  | $ | (75.8) |  |  | 122.9 | % |
| Percentage of total net sales | (0.1) | % |  | 0.5 | % |  |  |  |  |  | (0.8) | % |  | (0.6) | % |  |  |  |  |
| Effective tax rate | 5.1 | % |  | (5.2) | % |  |  |  |  |  | 13.9 | % |  | 6.7 | % |  |  |  |  |

[0001375365-25-000014:mdna:101]
Comparison of Three Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:102]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended March 31, 2025, was higher than that for the three months ended March 31, 2024, primarily due to a decrease in the stock compensation tax deduction for the three months ended March 31, 2025 driven by the decrease in our stock price.

[0001375365-25-000014:mdna:103]
Comparison of Nine Months Ended March 31, 2025 and 2024

[0001375365-25-000014:mdna:104]
The income tax provision for the nine months ended March 31, 2025 was higher than that for the nine months ended March 31, 2024, primarily due to a decrease in the stock compensation tax deduction for the nine months ended March 31, 2025 driven by the decrease in our stock price.

[0001375365-25-000014:mdna:105]
[same as prior period, unchanged from 0001375365-25-000006:mdna:91]

[0001375365-25-000014:mdna:106]
We have financed our growth primarily through funds generated from operations, borrowing facilities, the sale of our common stock, and the issuance of convertible notes. Recent factors contributing to changes in liquidity include an increased need for working capital to support higher inventory levels required for our growing revenues and, to a lesser extent, longer supply chain lead times for certain key components. Our cash and cash equivalents were $2.5 billion and $1.7 billion as of March 31, 2025 and June 30, 2024, respectively. Of these amounts, cash and cash equivalents held in foreign locations were $728.1 million and $337.3 million as of March 31, 2025 and June 30, 2024, respectively.

[0001375365-25-000014:mdna:107]
Amounts held outside of the U.S. are typically used to meet non-U.S. liquidity needs. Repatriations of these funds is generally not subject to U.S. federal income tax, though state income or foreign withholding taxes may apply. In cases where local restrictions prevent the intercompany transfer of funds, our strategy is to retain cash balances outside the U.S. and meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes on the repatriation of amounts held outside the U.S. to materially affect our overall liquidity, financial condition, or results of operations.

[0001375365-25-000014:mdna:108]
We believe that our current cash, cash equivalents, borrowing capacity from available credit facilities and internally generated cash flows will be sufficient to support our operating activities, as well as maturing debt and interest payments, for the 12 months following the filing of this Quarterly Report. We continue to assess financing options that may be necessary to support the growth of our business.

[0001375365-25-000014:mdna:109]
[same as prior period, unchanged from 0001375365-25-000006:mdna:95]

[0001375365-25-000014:mdna:110]
|  | Nine Months EndedMarch 31, |  | Change |  |  |  |
|  | 2025 |  | 2024 |  | $ |  |  |  |
| Net cash provided by (used in) operating activities | $ | 795.9 |  |  | $ | (1,838.2) |  |  | $ | 2,634.1 |  |  |  |  |
| Net cash used in investing activities | $ | (104.5) |  |  | $ | (138.0) |  |  | $ | 33.5 |  |  |  |  |
| Net cash provided by financing activities | $ | 174.6 |  |  | $ | 3,652.8 |  |  | $ | (3,478.2) |  |  |  |  |
| Effect of exchange rate fluctuations on cash | $ | 0.8 |  |  | $ | (1.6) |  |  | $ | 2.4 |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 866.8 |  |  | $ | 1,675.0 |  |  | $ | (808.2) |  |  |  |  |

[0001375365-25-000014:mdna:111]
SMCI | Q3 2025 Form 10-Q | 49

[0001375365-25-000014:mdna:112]
[same as prior period, unchanged from 0001375365-25-000006:mdna:97]

[0001375365-25-000014:mdna:113]
Net cash provided by operating activities increased by $2,634.1 million for the nine months ended March 31, 2025, compared to the nine months ended March 31, 2024. This increase was primarily driven by a $2,505.0 million increase in working capital and a $130.8 million increase in non-cash items, comprised of stock-based compensation expense and the loss on extinguishment of our 2029 convertible notes. The increase in working capital was due to a $3,136.9 million increase in inventory in anticipation of planned future shipments. Accounts receivable increased by $596.7 million due to stronger cash collections in the current period, partially offset by a $1,121.3 million decrease in accounts payable, resulting from the timing of vendor payments during the current period. Other operating assets and liabilities decreased by $107.3 million, driven by movements in prepaid expenses, income tax payable, accrued liabilities, and deferred revenue.

[0001375365-25-000014:mdna:114]
[same as prior period, unchanged from 0001375365-25-000006:mdna:99]

[0001375365-25-000014:mdna:115]
Net cash used in investing activities decreased by $33.5 million for the nine months ended March 31, 2025 compared to the nine months ended March 31, 2024 primarily due to a reduction in investments in marketable securities by $27.7 million, and a decrease in capital expenditures on property, plant, and equipment of $5.8 million.

[0001375365-25-000014:mdna:116]
[same as prior period, unchanged from 0001375365-25-000006:mdna:101]

[0001375365-25-000014:mdna:117]
Net cash provided by financing activities decreased by $3,478.2 million for the nine months ended March 31, 2025 as compared to the nine months ended March 31, 2024. The decrease was primarily driven by a $2,314.0 million reduction in proceeds from the issuance of common stock, net of issuance costs. In addition, net proceeds from convertible notes decreased by $901.2 million, reflecting the difference between the issuances of the 2029 Convertible Notes in February 2024 and the 2028 Convertible Notes in February 2025, net of the purchase of capped calls. There was also a $252.7 million decrease in proceeds from borrowings, net of repayment compared to the prior period.

[0001375365-25-000014:mdna:118]
[same as prior period, unchanged from 0001375365-25-000006:mdna:104]

[0001375365-25-000014:mdna:119]
Refer to Note 6 “Lines of Credit and Term Loans”, in our notes to the condensed consolidated financial statements in this Quarterly Report for further information on our outstanding bank debt.

[0001375365-25-000014:mdna:120]
On February 20, 2025, we (i) closed the offering of $700.0 million aggregate principal amount of 2028 Convertible Notes and (ii) executed a first supplemental indenture and second supplemental indenture governing to the 2029 Convertible Notes, pursuant to which, among other things, the Company amended certain terms of, and obtained waivers with respect to, the Original 2029 Convertible Notes. Refer to Note 7 “Convertible Notes”, in our notes to the condensed consolidated financial statements in this Quarterly Report for further information on the issuance of the 2028 Convertible Notes and the amendment of the terms of the 2029 Convertible Notes.

[0001375365-25-000014:mdna:121]
[same as prior period, unchanged from 0001375365-25-000006:mdna:107]

[0001375365-25-000014:mdna:122]
We anticipate our capital expenditures for the remainder of fiscal year 2025 will be in range of $45.0 million to $55.0 million, relating primarily to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention).

[0001375365-25-000014:mdna:123]
Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our manufacturing and office facilities and enhancements to our IT system infrastructure.

[0001375365-25-000014:mdna:124]
[same as prior period, unchanged from 0001375365-25-000006:mdna:110]

[0001375365-25-000014:mdna:125]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Note 1 “Summary of Significant Accounting Policies”, in our notes to the condensed consolidated financial statements in this Quarterly Report.

[0001375365-25-000014:mdna:126]
SMCI | Q3 2025 Form 10-Q | 50
