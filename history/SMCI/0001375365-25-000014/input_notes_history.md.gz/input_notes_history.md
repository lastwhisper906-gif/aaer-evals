# SMCI note change history — 0001375365-25-000006 → 0001375365-25-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:1]
Note 12.               Commitments and Contingencies
  (was, 2025-02-25, similarity 0.6667):
[0001375365-25-000006:note_history:1]
Commitments and Contingencies
Litigation and claims

- added (2025-05-12):
[0001375365-25-000014:note_history:2]
Litigation and claims

- changed (2025-05-12):
[0001375365-25-000014:note_history:3]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Averza and Covey Financial complaints are pending Court appointment of a lead plaintiff. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.
  (was, 2025-02-25, similarity 0.8587):
[0001375365-25-000006:note_history:3]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. On October 28, 2024, the Spatz plaintiff voluntarily dismissed the Spatz complaint without prejudice against all Defendants, ending the suit. On November 21, 2024, the Averza Court entered a Stipulation and Order extending Defendants’ time to respond to the Averza complaint until after the Court appoints a lead plaintiff, which hearing is set for March 6, 2025. A similar stipulation was entered among the parties as to the Covey Financial complaint. On January 9, 2025, the Menditto plaintiff voluntarily dismissed the Menditto complaint without prejudice against all Defendants, ending the suit. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

- added (2025-05-12):
[0001375365-25-000014:note_history:4]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- changed (2025-05-12):
[0001375365-25-000014:note_history:5]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.
  (was, 2025-02-25, similarity 0.8972):
[0001375365-25-000006:note_history:5]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. A case management judge was assigned in December 2024, but no case conference has been scheduled and no timetable for subsequent procedural steps has been set. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

- changed (2025-05-12):
[0001375365-25-000014:note_history:6]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. The Company is cooperating with these document requests and there have been no charges brought against any person as of the date of this filing.
  (was, 2025-02-25, similarity 0.8188):
[0001375365-25-000006:note_history:6]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication in a short seller report which was published in August 2024. The Company is cooperating with these document requests and no charges have been brought as of the date of this filing.

- changed (2025-05-12):
[0001375365-25-000014:note_history:7]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of March 31, 2025 and any prior periods.
  (was, 2025-02-25, similarity 0.9858):
[0001375365-25-000006:note_history:7]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of December 31, 2024 and any prior periods.

- changed (2025-05-12):
[0001375365-25-000014:note_history:8]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2025, these remaining non-cancelable commitments were $1.8 billion, including $107.5 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of March 31, 2025 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.
  (was, 2025-02-25, similarity 0.9803):
[0001375365-25-000006:note_history:8]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2024, these remaining non-cancelable commitments were $2.3 billion, including $101.1 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of December 31, 2024 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.

- changed (2025-05-12):
[0001375365-25-000014:note_history:9]
Lease Commitments— See Note 8 “Leases”, for a discussion of the Company's operating lease commitments.
  (was, 2025-02-25, similarity 0.9804):
[0001375365-25-000006:note_history:9]
Lease Commitments— See Note 8, "Leases," for a discussion of the Company's operating lease commitments.

- removed (2025-05-12):
[0001375365-25-000006:note_history:10]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been

- removed (2025-05-12):
[0001375365-25-000006:note_history:11]
filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On November 5, 2024, the Court in the Hollin Action entered a Stipulation and Order staying all proceedings in Hollin and any related federal derivative actions, which includes the Federal Derivative Litigation. The Court in the State Court Derivative Litigation stayed all proceedings until case management conferences were held in each suit, with the first conference scheduled for April 24, 2025 in Spatz. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:12]
Note 1.                 Summary of Significant Accounting Policies
  (was, 2025-02-25, similarity 0.6131):
[0001375365-25-000006:note_history:12]
Summary of Significant Accounting Policies
Significant Accounting Policies and Estimates

- added (2025-05-12):
[0001375365-25-000014:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) and applicable rules and regulations of the Securities and Exchange Commission regarding interim financial reporting. Certain information and note disclosures normally included in the financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to such rules and regulations. As such, the information included in this quarterly report on Form 10-Q should be read in conjunction with the consolidated financial statements and accompanying notes included in the Annual Report on Form 10-K for the year ended June 30, 2024, of Super Micro Computer, Inc., a Delaware corporation, and its consolidated entities (collectively, the “Company”). The condensed consolidated balance sheet as of March 31, 2025 included herein was derived from the audited financial statements as of that date, but does not include all disclosures including notes required by GAAP.

- added (2025-05-12):
[0001375365-25-000014:note_history:14]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. All intercompany balances and transactions have been eliminated. Interim results are not necessarily indicative of the results for the full year ending June 30, 2025.

- added (2025-05-12):
[0001375365-25-000014:note_history:15]
Significant Accounting Policies

- added (2025-05-12):
[0001375365-25-000014:note_history:16]
There have been no material changes to the Company's significant accounting policies from its Annual Report on Form 10-K for the fiscal year ended June 30, 2024.

- changed (2025-05-12):
[0001375365-25-000014:note_history:17]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 67.7% |  | 69.8% |  | 65.4% |  | 65.8% |
| Supplier B | 5.1% |  | n/a |  | 3.9% |  | n/a |
| Supplier C | 4.9% |  | 5.1% |  | 5.5% |  | 7.1% |
  (was, 2025-02-25, similarity 0.6846):
[0001375365-25-000006:note_history:17]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 63.5% |  | 68.1% |  | 64.5% |  | 62.9% |
| Supplier B | 6.0% |  | 7.3% |  | 5.8% |  | 8.6% |

- added (2025-05-12):
[0001375365-25-000014:note_history:18]
^The supplier references of A-C above may represent different suppliers than those reported in a previous period.

- changed (2025-05-12):
[0001375365-25-000014:note_history:19]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, “Related Party Transactions”), accounted for a combined 2.8% and 4.0% of total cost of sales for the three months ended March 31, 2025 and 2024, respectively, and a combined 3.4% and 4.4% of total cost of sales for the nine months ended March 31, 2025 and 2024, respectively.
  (was, 2025-02-25, similarity 0.8564):
[0001375365-25-000006:note_history:19]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, "Related Party Transactions"), accounted for a combined 2.7% and 3.6% of total cost of sales for the three months ended December 31, 2024 and 2023, respectively, and a combined 3.7% and 4.6% of total cost of sales for the six months ended December 31, 2024 and 2023, respectively.

- added (2025-05-12):
[0001375365-25-000014:note_history:20]
The concentration of customer risk refers to the potential adverse impact on a business due to a high dependency on a limited number of customers. This risk arises when a significant portion of the Company's revenue is generated from a small group of clients. If any of these key customers reduce their orders, delay payments, or terminate their contracts, the business could face substantial financial instability.

- added (2025-05-12):
[0001375365-25-000014:note_history:21]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total net sales |  |  |  |  |  |  |  |
| Customer A | 22.5% |  | 21.2% |  | 23.5% |  | 23.7% |
| Customer B | 14.1% |  | * |  | * |  | * |
| Customer C | * |  | 16.8% |  | 13.5% |  | * |
| Customer D | * |  | * |  | 15.1% |  | * |

- added (2025-05-12):
[0001375365-25-000014:note_history:22]
^The customer references of A-D above may represent different customers than those reported in a previous period.

- added (2025-05-12):
[0001375365-25-000014:note_history:23]
*Below 10%

- added (2025-05-12):
[0001375365-25-000014:note_history:24]
Significant customer information is as follows:

- changed (2025-05-12):
[0001375365-25-000014:note_history:25]
|  | March 31, 2025 |  | June 30, 2024 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 46.4% |  | 15.4% |
| Customer C | 17.4% |  | * |
| Customer D | * |  | 44.8% |
  (was, 2025-02-25, similarity 0.8382):
[0001375365-25-000006:note_history:25]
|  | December 31, 2024 | June 30, 2024 |
| Percentage of accounts receivable |  |  |
| Customer A | 16.0% | 15.4% |
| Customer G | 57.3% | 44.8% |

- added (2025-05-12):
[0001375365-25-000014:note_history:26]
^The customer references of A-D above may represent different customers than those reported in a previous period.

- added (2025-05-12):
[0001375365-25-000014:note_history:27]
*Below 10%

- changed (2025-05-12):
[0001375365-25-000014:note_history:28]
Recent Accounting Pronouncements Not Yet Adopted
  (was, 2025-02-25, similarity 0.9213):
[0001375365-25-000006:note_history:28]
Accounting Pronouncements Not Yet Adopted

- changed (2025-05-12):
[0001375365-25-000014:note_history:29]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.
  (was, 2025-02-25, similarity 0.8833):
[0001375365-25-000006:note_history:29]
In November 2023, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.

- changed (2025-05-12):
[0001375365-25-000014:note_history:30]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect the adoption of this standard to have a material impact on its consolidated financial statements other than additional disclosures.
  (was, 2025-02-25, similarity 0.8348):
[0001375365-25-000006:note_history:30]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.

- added (2025-05-12):
[0001375365-25-000014:note_history:31]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. The ASU affects a variety of Topics in the Codification. The amendments apply to all reporting entities within the scope of the affected accounting guidance. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company does not expect this ASU to have a material impact on its consolidated financial statements and disclosures.

- added (2025-05-12):
[0001375365-25-000014:note_history:32]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

- removed (2025-05-12):
[0001375365-25-000006:note_history:33]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies," in its Annual Report on Form 10-K, filed on February 25, 2025, for the year ended June 30, 2024 (the "2024 10-K"). Management's estimates take into consideration, as applicable, general macroeconomic conditions, inflation, changes in interest rates and geopolitical events.

- removed (2025-05-12):
[0001375365-25-000006:note_history:34]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.

- removed (2025-05-12):
[0001375365-25-000006:note_history:35]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2025. These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes contained in the 2024 10-K.

- removed (2025-05-12):
[0001375365-25-000006:note_history:36]
Forward Stock Split

- removed (2025-05-12):
[0001375365-25-000006:note_history:37]
On September 30, 2024, the Company completed a 10-for-1 forward split of its common stock. Trading on a split-adjusted basis commenced on October 1, 2024. All references to shares of common stock and per share amounts contained in this Quarterly Report have been retroactively adjusted to reflect the stock split.

- removed (2025-05-12):
[0001375365-25-000006:note_history:38]
These accounts receivable represent a concentration of credit risk to the Company.

- removed (2025-05-12):
[0001375365-25-000006:note_history:39]
Customer A accounted for 27.1%, and customer G accounted for 30.6% of the net sales for the three months ended December 31, 2024 and customer A accounted for 23.9%, customer G accounted for 21.0% and customer B accounted for 14.9% of the net sales for the six months ended December 31, 2024. Customer A accounted for 25.5% and customer D accounted for 10.4% of the net sales for the three months ended December 31, 2023 and customer A accounted for 25.3% of the net sales for the six months ended December 31, 2023. Other customers were individually below 10% of the net sales for the three and six months ended December 31, 2024 and 2023.

- removed (2025-05-12):
[0001375365-25-000006:note_history:40]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2026 and for the interim periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027, and for the interim period beginning July 1, 2028. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-12):
[0001375365-25-000014:note_history:41]
Note 6.                 Lines of Credit and Term Loans

- changed (2025-05-12):
[0001375365-25-000014:note_history:42]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands):
  (was, 2025-02-25, similarity 0.694):
[0001375365-25-000006:note_history:42]
Lines of Credit and Term Loans
Short-term and long-term loan obligations as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:43]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 24,166 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 24,166 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,957 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,756 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,980 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 14,500 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,490 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 18,125 |  |  | 27,644 |  |
| Total term loans | 82,808 |  |  | 114,557 |  |
| Total lines of credit and term loans | 106,974 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Term loans, non-current | $ | 43,003 |  |  | $ | 74,083 |  |
  (was, 2025-02-25, similarity 0.9923):
[0001375365-25-000006:note_history:43]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 90,467 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | 24,374 |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 114,841 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 13,964 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 28,291 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,350 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 17,062 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 10,562 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 21,327 |  |  | 27,644 |  |
| Total term loans | 93,556 |  |  | 114,557 |  |
| Total lines of credit and term loans | 208,397 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 154,988 |  |  | 402,346 |  |
| Term loans, non-current | $ | 53,409 |  |  | $ | 74,083 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:44]
Available borrowings and interest rates as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):
  (was, 2025-02-25, similarity 0.9668):
[0001375365-25-000006:note_history:44]
Available borrowings and interest rates as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-05-12):
[0001375365-25-000014:note_history:45]
|  | March 31, 2025 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 160,834 |  |  | 2.63% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,062 |  |  | 1.88% - 5.18% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | — |  |  | n/a |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 2.02% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  |  | n/a |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 46,822 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |
  (was, 2025-02-25, similarity 0.9724):
[0001375365-25-000006:note_history:45]
|  | December 31, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 94,533 |  |  | 2.15% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,140 |  |  | 1.88% - 5.30% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 35,626 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 30,000 |  |  | 2.03% - 5.26% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 47,224 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |

- added (2025-05-12):
[0001375365-25-000014:note_history:46]
See Note 7 “Lines of Credit and Term Loans” of the Company’s 2024 Annual Report on Form 10-K for the fiscal year ended June 30, 2024 (“2024 10-K”) to the condensed consolidated financial statements in this Quarterly Report for a more complete description of the Company's credit facilities.

- changed (2025-05-12):
[0001375365-25-000014:note_history:47]
The Company entered into new agreements during the nine months ended March 31, 2025 with the following terms:
  (was, 2025-02-25, similarity 0.9333):
[0001375365-25-000006:note_history:47]
The Company entered into new agreements during the six months ended December 31, 2024 with the following terms:

- changed (2025-05-12):
[0001375365-25-000014:note_history:48]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder.
  (was, 2025-02-25, similarity 0.913):
[0001375365-25-000006:note_history:48]
party thereto,and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder.

- changed (2025-05-12):
[0001375365-25-000014:note_history:49]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the “Taiwan Subsidiary”), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.
  (was, 2025-02-25, similarity 0.9272):
[0001375365-25-000006:note_history:49]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the "Taiwan Subsidiary"), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

- changed (2025-05-12):
[0001375365-25-000014:note_history:50]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the “Cathay Bank Loan Agreement”), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sub-limit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.
  (was, 2025-02-25, similarity 0.9977):
[0001375365-25-000006:note_history:50]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the "Cathay Bank Loan Agreement"), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sublimit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

- added (2025-05-12):
[0001375365-25-000014:note_history:51]
CTBC Bank

- added (2025-05-12):
[0001375365-25-000014:note_history:52]
2025 CTBC Facility Letter

- added (2025-05-12):
[0001375365-25-000014:note_history:53]
On February 27, 2025, the Taiwan Subsidiary received a new facility letter from CTBC Bank (“2025 Facility”), issued under the general agreement for omnibus credit lines with CTBC Bank, dated February 16, 2024 (the “2024 CTBC Agreement”). As a result, the credit arrangements under the 2024 CTBC Agreement now include the previously issued long and medium-term loan facility of New Taiwan Dollar (“NTD”) 1,550 million entered into in 2020 and 2021 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,800 million and NTD 100 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40 million (the “USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105 million for exports and imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80 million (the “Import O/A Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “2025 CTBC Credit Lines”). Aggregate borrowings under all the 2025 CTBC Credit Lines are subject to a cap of $185 million as set forth under the 2024 CTBC Agreement.

- added (2025-05-12):
[0001375365-25-000014:note_history:54]
The 2025 Facility expires on February 28, 2026. As of March 31, 2025, the outstanding borrowings under the 2025 CTBC Bank Credit Lines were $24.2 million.

- changed (2025-05-12):
[0001375365-25-000014:note_history:55]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2025 |  | $ | 34,118 |  |
| 2026 |  | 39,805 |  |
| 2027 |  | 17,293 |  |
| 2028 |  | 5,833 |  |
| 2029 |  | 5,178 |  |
| 2030 and thereafter |  | 4,747 |  |
| Total lines of credit and term loans |  | $ | 106,974 |  |
  (was, 2025-02-25, similarity 0.8936):
[0001375365-25-000006:note_history:55]
| Remainder of 2025 |  | $ | 134,914 |  |
| 2026 |  | 40,147 |  |
| 2027 |  | 17,442 |  |
| 2028 |  | 5,883 |  |
| 2029 |  | 5,223 |  |
| 2030 and thereafter |  | 4,788 |  |
| Total lines of credit and term loans |  | $ | 208,397 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:56]
As of March 31, 2025, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6 “Lines of Credit and Term Loans”.
  (was, 2025-02-25, similarity 0.8587):
[0001375365-25-000006:note_history:56]
As of December 31, 2024, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6.
Convertible Notes 
2029 Convertible Notes

- added (2025-05-12):
[0001375365-25-000014:note_history:57]
Note 7.                 Convertible Notes

- added (2025-05-12):
[0001375365-25-000014:note_history:58]
2029 Convertible Notes

- added (2025-05-12):
[0001375365-25-000014:note_history:59]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 0.00% Convertible Senior Notes due 2029 (the “Original 2029 Convertible Notes”). On February 11, 2025, the Company entered into privately negotiated subscription agreements with certain holders of the Original 2029 Convertible Notes (the “Convertible Note SPAs”) to, among other things, amend certain terms of, and obtain waivers with respect to, the Original 2029 Convertible Notes and to issue $700.0 million aggregate principal amount of the 2028 Convertible Notes (as further described below). On February 12, 2025, pricing of the amended 2029 Convertible Notes and 2028 Convertible Notes was set pursuant to the Convertible Note SPAs, establishing a binding commitment by the parties to the Convertible Note SPAs. On February 20, 2025, the Company amended and supplemented that certain indenture governing the Original 2029 Convertible Notes (the “Original 2029 Notes Indenture”), dated as of February 27, 2024, by and between the Company U.S. Bank Trust Company, National Association, as trustee (the “Trustee”) by entering into a first supplemental indenture and a second supplemental indenture (the Original 2029 Notes Indenture, as so amended, the “2029 Convertible Notes Indenture”), in each case with the Trustee. Pursuant to the 2029 Convertible Notes Indenture, the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes which is equivalent to a conversion price of approximately $83.44 per share of the Company’s common stock, in each case subject to adjustment as set forth in 2029 Convertible Notes Indenture (such amendments, the “Amendments”). The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election. The other terms of the 2029 Convertible Notes remained substantially unchanged. The amendment was treated as an extinguishment of the original debt and an issuance of the new debt, in which a debt extinguishment loss of $30.3 million was recognized during the quarter ended March 31, 2025.

- added (2025-05-12):
[0001375365-25-000014:note_history:60]
The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture. The debt issuance costs and premium are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

- changed (2025-05-12):
[0001375365-25-000014:note_history:61]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2029 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2029 Convertible Notes for each trading day of the 2029 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.
  (was, 2025-02-25, similarity 0.7191):
[0001375365-25-000006:note_history:61]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date.

- changed (2025-05-12):
[0001375365-25-000014:note_history:62]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.
  (was, 2025-02-25, similarity 0.9796):
[0001375365-25-000006:note_history:62]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

- changed (2025-05-12):
[0001375365-25-000014:note_history:63]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date.
  (was, 2025-02-25, similarity 0.9808):
[0001375365-25-000006:note_history:63]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

- changed (2025-05-12):
[0001375365-25-000014:note_history:64]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. No sinking fund is provided for the 2029 Convertible Notes.
  (was, 2025-02-25, similarity 0.8965):
[0001375365-25-000006:note_history:64]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. The 2029 Convertible Notes were not eligible for conversion as of December 31, 2024. No sinking fund is provided for the 2029 Convertible Notes.

- added (2025-05-12):
[0001375365-25-000014:note_history:65]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2028 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

- changed (2025-05-12):
[0001375365-25-000014:note_history:66]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs and premium of $23.9 million, was $1,701.1 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs and premium was $0.8 million and interest was $8.2 million for the quarter ended March 31, 2025. The effective interest rate is 3.88%.
  (was, 2025-02-25, similarity 0.8721):
[0001375365-25-000006:note_history:66]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $24.4 million, was $1,700.6 million as of December 31, 2024. Interest expense related to the amortization of debt issuance costs was $1.5 million for the quarter ended December 31, 2024. The effective interest rate is 0.34%.

- added (2025-05-12):
[0001375365-25-000014:note_history:67]
In connection with the Amendment, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to discussion below under “Capped Calls”.

- added (2025-05-12):
[0001375365-25-000014:note_history:68]
2028 Convertible Notes

- added (2025-05-12):
[0001375365-25-000014:note_history:69]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of its 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture by and between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Convertible Notes Indenture”). The Company received proceeds from the offering of approximately $700.0 million before deducting any issuance costs and fees payable to the placement agents. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier repurchased, redeemed or converted.

- added (2025-05-12):
[0001375365-25-000014:note_history:70]
The 2028 Convertible Notes bear interest from February 20, 2025 at an annual rate of 2.25%, payable semi-annually in arrears on each January 15 and July 15, beginning on July 15, 2025. The 2028 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of the Company’s common stock, at the Company’s election, at an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2028 Convertible Notes Indenture. The Company may pay special interest, if any, at its election as the sole remedy relating to a failure to comply with its reporting obligations and will be obligated to pay additional interest, if any, under the circumstances set forth in the 2028 Convertible Notes Indenture. The 2028 Convertible Notes do not contain financial maintenance covenants.

- added (2025-05-12):
[0001375365-25-000014:note_history:71]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2028 Convertible Notes Indenture; (4) if the Company calls such 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

- added (2025-05-12):
[0001375365-25-000014:note_history:72]
If the Company undergoes a fundamental change (as defined in the 2028 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2028 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2028 Convertible Notes to be repurchased, plus any accrued and unpaid interest, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2028 Convertible Notes in connection with such corporate event or during the relevant redemption period.

- added (2025-05-12):
[0001375365-25-000014:note_history:73]
The 2028 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2026 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 150% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the 2028 Convertible Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date.

- added (2025-05-12):
[0001375365-25-000014:note_history:74]
The 2028 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2028 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2028 Convertible Notes. No sinking fund is provided for the 2028 Convertible Notes.

- added (2025-05-12):
[0001375365-25-000014:note_history:75]
The 2028 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2028 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness (including the 2029 Convertible Notes); effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2025, none of the conditions permitting the holders of the 2028 Convertible Notes to convert their notes early had been met. Therefore, the 2028 Convertible Notes are classified as long-term debt.

- added (2025-05-12):
[0001375365-25-000014:note_history:76]
The carrying value of the 2028 Convertible Notes, net of unamortized issuance costs of $15.8 million, was $684.2 million as of March 31, 2025. Interest expense related to the amortization of debt issuance costs was $0.5 million and for interest was $1.8 million for the quarter ended March 31, 2025. The effective interest rate is 2.97%.

- added (2025-05-12):
[0001375365-25-000014:note_history:77]
On February 12, 2025, in connection with the Amendments, the Company also entered into agreements to amend certain terms of the privately negotiated capped call transactions (collectively and as amended, the “Capped Call Transactions”) originally entered into with certain financial institutions (the “Capped Call Counterparties”) on February 22, 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the strike price and cap price. The strike price, after giving effect to the amendments, is initially $83.44 per share of the Company's common stock. The cap price, after giving effect to the amendments, is initially $94.17 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls. The number of shares underlying the Capped Calls increased from 7.455 to 11.984 per $1,000 principal amount of 2029 Convertible Notes.

- added (2025-05-12):
[0001375365-25-000014:note_history:78]
The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. 
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. The amendment to the Capped Call Transactions did not change the recognition of the Capped Call Transactions as shareholders’ equity and did not result in any incremental value requiring recognition. The amended 2029 Convertible Notes and the amended Capped Call Transactions have been integrated for tax purposes. The impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.

- removed (2025-05-12):
[0001375365-25-000006:note_history:79]
See Note 7 "Short-term and Long-term Debt” and Note 16 "Subsequent Events" of the Company’s 2024 10-K for a more complete description of the Company's credit facilities.

- removed (2025-05-12):
[0001375365-25-000006:note_history:80]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders

- removed (2025-05-12):
[0001375365-25-000006:note_history:81]
Fiscal Year                                                                                                                                                                                                Principal Payments

- removed (2025-05-12):
[0001375365-25-000006:note_history:82]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 2029 Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The 2029 Convertible Notes will mature on March 1, 2029, unless earlier converted, redeemed or repurchased. On February 20, 2025, the Company executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented amendments to the 2029 Convertible Notes. Refer to Note 14. "Subsequent Events", in the notes to the condensed consolidated financial statements below.

- removed (2025-05-12):
[0001375365-25-000006:note_history:83]
The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. Because the Company did not file its Annual Report on Form 10-K for the fiscal year ended June 30, 2024 in a timely manner, it elected to accrue special interest on the 2029 Convertible Notes and accrued additional interest on the 2029 Convertible Notes in accordance with the indenture governing the 2029 Convertible Notes (the "2029 Convertible Notes Indenture"). As of December 31, 2024, such accrued and unpaid interest under the 2029 Convertible Notes was $2.2 million. The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 7.455 shares of common stock per $1,000 principal amount of 2029 Convertible Notes, which is equivalent to an initial conversion price of approximately $134.14 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest and additional interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture and have accrued on the 2029 Convertible Notes subsequent to June 30, 2024 as described above. The debt issuance costs are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

- removed (2025-05-12):
[0001375365-25-000006:note_history:84]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of December 31, 2024, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

- removed (2025-05-12):
[0001375365-25-000006:note_history:85]
In connection with the issuance of the 2029 Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. In connection with the amendment of the 2029 Convertible Notes, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to Note 14. "Subsequent Events", below.

- removed (2025-05-12):
[0001375365-25-000006:note_history:86]
The Capped Call Transactions initially have a strike price of $134.14 per share, subject to certain adjustments, which corresponds to the initial conversion price of the 2029 Convertible Notes. The cap price of the Capped Call Transactions was initially $195.10 per share of common stock subject to certain adjustments under the terms of the Capped Call Transactions.

- removed (2025-05-12):
[0001375365-25-000006:note_history:87]
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The 2029 Convertible Notes and the Capped Call Transactions have been integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:88]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands):
  (was, 2025-02-25, similarity 0.7692):
[0001375365-25-000006:note_history:88]
Short-term and long-term loan obligations as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:89]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 24,166 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | — |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 24,166 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,957 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,756 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,980 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 14,500 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,490 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 18,125 |  |  | 27,644 |  |
| Total term loans | 82,808 |  |  | 114,557 |  |
| Total lines of credit and term loans | 106,974 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Term loans, non-current | $ | 43,003 |  |  | $ | 74,083 |  |
  (was, 2025-02-25, similarity 0.9923):
[0001375365-25-000006:note_history:89]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 90,467 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | 24,374 |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 114,841 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 13,964 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 28,291 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,350 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 17,062 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 10,562 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 21,327 |  |  | 27,644 |  |
| Total term loans | 93,556 |  |  | 114,557 |  |
| Total lines of credit and term loans | 208,397 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 154,988 |  |  | 402,346 |  |
| Term loans, non-current | $ | 53,409 |  |  | $ | 74,083 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:90]
Available borrowings and interest rates as of March 31, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):
  (was, 2025-02-25, similarity 0.9668):
[0001375365-25-000006:note_history:90]
Available borrowings and interest rates as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):

- changed (2025-05-12):
[0001375365-25-000014:note_history:91]
|  | March 31, 2025 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 160,834 |  |  | 2.63% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,062 |  |  | 1.88% - 5.18% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | — |  |  | n/a |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 2.02% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  |  | n/a |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 46,822 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |
  (was, 2025-02-25, similarity 0.9724):
[0001375365-25-000006:note_history:91]
|  | December 31, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 94,533 |  |  | 2.15% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,140 |  |  | 1.88% - 5.30% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 35,626 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 30,000 |  |  | 2.03% - 5.26% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 47,224 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:92]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2025 |  | $ | 34,118 |  |
| 2026 |  | 39,805 |  |
| 2027 |  | 17,293 |  |
| 2028 |  | 5,833 |  |
| 2029 |  | 5,178 |  |
| 2030 and thereafter |  | 4,747 |  |
| Total lines of credit and term loans |  | $ | 106,974 |  |
  (was, 2025-02-25, similarity 0.8936):
[0001375365-25-000006:note_history:92]
| Remainder of 2025 |  | $ | 134,914 |  |
| 2026 |  | 40,147 |  |
| 2027 |  | 17,442 |  |
| 2028 |  | 5,883 |  |
| 2029 |  | 5,223 |  |
| 2030 and thereafter |  | 4,788 |  |
| Total lines of credit and term loans |  | $ | 208,397 |  |

- removed (2025-05-12):
[0001375365-25-000006:note_history:93]
Fiscal Year                                                                                                                                                                                                Principal Payments


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-05-12):
[0001375365-25-000014:note_history:94]
Note 9.                 Related Party Transactions

- changed (2025-05-12):
[0001375365-25-000014:note_history:95]
The Company has a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. As of March 31, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.
  (was, 2025-02-25, similarity 0.9519):
[0001375365-25-000006:note_history:95]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

- changed (2025-05-12):
[0001375365-25-000014:note_history:96]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on Nasdaq in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of March 31, 2025 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.7 million and $16.4 million, respectively.
  (was, 2025-02-25, similarity 0.9931):
[0001375365-25-000006:note_history:96]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on NASDAQ in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of December 31, 2024 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.6 million and $16.4 million, respectively.

- changed (2025-05-12):
[0001375365-25-000014:note_history:97]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.0% and 95.2% of the chassis purchased by the Company during the three months ended March 31, 2025 and 2024, respectively, and 95.2% and 92.7% of the chassis purchased by the Company during the nine months ended March 31, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2025-02-25, similarity 0.9292):
[0001375365-25-000006:note_history:97]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.1% and 87.2% of the chassis included in the products sold by the Company during the three months ended December 31, 2024 and 2023, respectively, and 96.5% and 86.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2025-05-12):
[0001375365-25-000014:note_history:98]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on March 31, 2025 were $54.4 million and $25.6 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.
  (was, 2025-02-25, similarity 0.9953):
[0001375365-25-000006:note_history:98]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on December 31, 2024 were $25.9 million and $34.1 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

- changed (2025-05-12):
[0001375365-25-000014:note_history:99]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.
  (was, 2025-02-25, similarity 0.9981):
[0001375365-25-000006:note_history:99]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

- changed (2025-05-12):
[0001375365-25-000014:note_history:100]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on March 31, 2025 were $109.1 million and $81.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2025-02-25, similarity 0.992):
[0001375365-25-000006:note_history:100]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on December 31, 2024 were $113.5 million and $66.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2025-05-12):
[0001375365-25-000014:note_history:101]
In October 2023, Ablecom and Compuware together acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended March 31, 2025, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the nine months ended March 31, 2025, the Company engaged in transactions in which it sold $0.5 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.
  (was, 2025-02-25, similarity 0.8353):
[0001375365-25-000006:note_history:101]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended December 31, 2024, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and purchased $0.1 million of graphics cards from Leadtek. During the six months ended December 31, 2024, the Company engaged in transactions in which it sold $0.3 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.

- changed (2025-05-12):
[0001375365-25-000014:note_history:102]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is approximately 30% owned by the Company and approximately 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.
  (was, 2025-02-25, similarity 0.9753):
[0001375365-25-000006:note_history:102]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- changed (2025-05-12):
[0001375365-25-000014:note_history:103]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.7 million and $4.6 million as of March 31, 2025 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of March 31, 2025 and June 30, 2024. No impairment charge was recorded for the three and nine months ended March 31, 2025 and 2024.
  (was, 2025-02-25, similarity 0.9279):
[0001375365-25-000006:note_history:103]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.3 million and $4.6 million as of December 31, 2024 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of December 31, 2024 and June 30, 2024. No impairment charge was recorded for the three and six months ended December 31, 2024 and 2023.

- changed (2025-05-12):
[0001375365-25-000014:note_history:104]
The Company sold products worth $4.2 million and $4.3 million to the Corporate Venture during the three months ended March 31, 2025 and 2024, respectively, and $9.0 million and $16.5 million to the Corporate Venture during the nine months ended March 31, 2025 and 2024, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2025 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.1 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of March 31, 2025 and June 30, 2024, respectively.
  (was, 2025-02-25, similarity 0.9461):
[0001375365-25-000006:note_history:104]
The Company sold products worth $0.0 million and $11.4 million to the Corporate Venture during the three months ended December 31, 2024 and 2023, respectively, and $4.8 million and $12.2 million to the Corporate Venture during the six months ended December 31, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2024 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.0 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2024 and June 30, 2024, respectively.

- changed (2025-05-12):
[0001375365-25-000014:note_history:105]
For the three months ended March 31, 2025, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the nine months ended March 31, 2025, the Company had immaterial chargebacks from Green Earth. As of March 31, 2025, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth were immaterial.
  (was, 2025-02-25, similarity 0.9071):
[0001375365-25-000006:note_history:105]
For the three months ended December 31, 2024, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the six months ended December 31, 2024, the Company had immaterial chargebacks from Green Earth. As of December 31, 2024, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth are immaterial.

- changed (2025-05-12):
[0001375365-25-000014:note_history:106]
The Company had the following balances related to transactions with its related parties as of March 31, 2025 and June 30, 2024 (in thousands):
  (was, 2025-02-25, similarity 0.9663):
[0001375365-25-000006:note_history:106]
The Company had the following balances related to transactions with its related parties as of December 31, 2024 and June 30, 2024 (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:107]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  |  |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |
| Accounts receivable | $ | 1 |  |  | $ | 1 |  |  | $ | 94 |  |  | $ | 142 |  |  | $ | 85 |  |  | $ | 5,075 |  |  |  |  | $ | 136 |  |  | $ | 976 |  |  | $ | 316 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,350 |  |  | $ | 1,927 |  |  | $ | 13,371 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 14,721 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 50,359 |  |  | $ | 98,629 |  |  | $ | 64,945 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 230 |  |  | $ | 115,304 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 487 |  |  | $ | — |  |  | $ | 254 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 741 |  |  | $ | 170 |  |
| Other Long-term liabilities (3) | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | — |  |
  (was, 2025-02-25, similarity 0.8766):
[0001375365-25-000006:note_history:107]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  |  |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 34 |  |  | $ | 142 |  |  | $ | (2) |  |  | $ | 5,075 |  |  |  |  | $ | 134 |  |  | $ | 976 |  |  | $ | 168 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,597 |  |  | $ | 1,927 |  |  | $ | 15,753 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 17,350 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 52,754 |  |  | $ | 98,629 |  |  | $ | 56,697 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 230 |  |  | $ | 109,535 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 294 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 170 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:108]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.
  (was, 2025-02-25, similarity 0.6515):
[0001375365-25-000006:note_history:108]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

- added (2025-05-12):
[0001375365-25-000014:note_history:109]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

- added (2025-05-12):
[0001375365-25-000014:note_history:110]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

- changed (2025-05-12):
[0001375365-25-000014:note_history:111]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9695):
[0001375365-25-000006:note_history:111]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:112]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 3 |  |  | $ | 2 |  |  | $ | 3,278 |  |  | $ | 21,501 |  |  | $ | 4,201 |  |  | $ | 4,301 |  |  |  |  | $ | 165 |  |  | $ | — |  |  | $ | 7,647 |  |  | $ | 25,804 |  |
| Purchases - inventory | $ | 50,147 |  |  | $ | 65,933 |  |  | $ | 65,372 |  |  | $ | 64,464 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 115,519 |  |  | $ | 130,397 |  |
| Purchases - other miscellaneous items | $ | 8,748 |  |  | $ | 4,401 |  |  | $ | 460 |  |  | $ | 343 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 9,208 |  |  | $ | 4,744 |  |
  (was, 2025-02-25, similarity 0.6997):
[0001375365-25-000006:note_history:112]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21,040 |  |  | $ | 20,998 |  |  | $ | 4,776 |  |  | $ | 12,173 |  |  |  |  | $ | 329 |  |  | $ | — |  | $ | 26,152 |  |  | $ | 33,177 |  |
| Purchases - inventory | $ | 202,279 |  |  | $ | 97,199 |  |  | $ | 173,348 |  |  | $ | 128,353 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  | 376,161 |  |  | 225,552 |  |
| Purchases - other miscellaneous items | $ | 10,118 |  |  | $ | 8,215 |  |  | $ | 1,031 |  |  | $ | 749 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 11,149 |  |  | $ | 8,964 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:113]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9521):
[0001375365-25-000006:note_history:113]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:114]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 10 |  |  | $ | 8 |  |  | $ | 24,318 |  |  | $ | 42,498 |  |  | $ | 8,977 |  |  | $ | 16,474 |  |  |  |  | $ | 494 |  |  | $ | — |  |  | $ | 33,799 |  |  | $ | 58,980 |  |
| Purchases - inventory | $ | 252,426 |  |  | $ | 163,131 |  |  | $ | 238,720 |  |  | $ | 192,817 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  |  | $ | 491,680 |  |  | $ | 355,948 |  |
| Purchases - other miscellaneous items | $ | 18,866 |  |  | $ | 12,616 |  |  | $ | 1,491 |  |  | $ | 1,092 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 20,357 |  |  | $ | 13,708 |  |
  (was, 2025-02-25, similarity 0.6833):
[0001375365-25-000006:note_history:114]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, | Three months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 5 |  |  | $ | 4 |  |  | $ | 11,065 |  |  | $ | 4,392 |  |  | $ | (51) |  |  | $ | 11,385 |  |  |  |  | $ | 258 |  |  | $ | — |  | $ | 11,277 |  |  | $ | 15,781 |  |
| Purchases - inventory | $ | 64,773 |  |  | $ | 50,586 |  |  | $ | 71,230 |  |  | $ | 61,859 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 106 |  |  | $ | — |  | $ | 136,109 |  |  | $ | 112,445 |  |
| Purchases - other miscellaneous items | $ | 3,764 |  |  | $ | 3,456 |  |  | $ | 294 |  |  | $ | 332 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 4,058 |  |  | $ | 3,788 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:115]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9548):
[0001375365-25-000006:note_history:115]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:116]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Changes in accounts receivable | $ | — |  |  | $ | (1) |  |  | $ | 48 |  |  | $ | 3,260 |  |  | $ | 4,990 |  |  | $ | 1,104 |  |  |  |  | $ | 840 |  |  | $ | — |  |  | $ | 5,878 |  |  | $ | 4,363 |  |
| Changes in other receivable | $ | 577 |  |  | $ | 1,022 |  |  | $ | (3,359) |  |  | $ | (3,539) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | (2,782) |  |  | $ | (2,517) |  |
| Changes in accounts payable | $ | (48,270) |  |  | $ | 18,480 |  |  | $ | (1,491) |  |  | $ | (5,032) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (230) |  |  | $ | — |  |  | $ | (49,991) |  |  | $ | 13,448 |  |
| Changes in accrued liabilities | $ | 487 |  |  | $ | (538) |  |  | $ | 84 |  |  | $ | 5,319 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 4,781 |  |
| Changes in other long-term liabilities | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (178) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | (178) |  |
| Purchases of property, plant and equipment | $ | 10,137 |  |  | $ | 8,935 |  |  | $ | 371 |  |  | $ | 197 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 10,508 |  |  | $ | 9,132 |  |
| Unpaid property, plant and equipment | $ | 7,111 |  |  | $ | 1,492 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 7,111 |  |  | $ | 1,492 |  |
  (was, 2025-02-25, similarity 0.655):
[0001375365-25-000006:note_history:116]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 108 |  |  | $ | 3,239 |  |  | $ | 5,077 |  |  | $ | (1,625) |  |  |  |  | $ | 842 |  |  | $ | — |  | $ | 6,026 |  |  | $ | 1,614 |  |
| Changes in other receivable | $ | 330 |  |  | $ | 571 |  |  | $ | (5,741) |  |  | $ | (7,132) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | (5,411) |  |  | $ | (6,561) |  |
| Changes in accounts payable | $ | (45,875) |  |  | $ | 10,938 |  |  | $ | (9,739) |  |  | $ | 1,628 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 146 |  |  | $ | — |  | $ | (55,468) |  |  | $ | 12,566 |  |
| Changes in accrued liabilities | $ | 294 |  |  | $ | (156) |  |  | $ | (146) |  |  | $ | 4,648 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 148 |  |  | $ | 4,492 |  |
| Changes in other long-term liabilities | $ | 154 |  |  | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 154 |  |  | $ | (152) |  |
| Purchases of property, plant and equipment | $ | 6,525 |  |  | $ | 4,460 |  |  | $ | 357 |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 6,882 |  |  | $ | 4,528 |  |
| Unpaid property, plant and equipment | $ | 2,946 |  |  | $ | 2,570 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 2,960 |  |  | $ | 2,577 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:117]
The Company had the following balances related to transactions with its related parties as of March 31, 2025 and June 30, 2024 (in thousands):
  (was, 2025-02-25, similarity 0.9663):
[0001375365-25-000006:note_history:117]
The Company had the following balances related to transactions with its related parties as of December 31, 2024 and June 30, 2024 (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:118]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |  |  |  | March 31, 2025 |  | June 30, 2024 |  | March 31, 2025 |  | June 30, 2024 |
| Accounts receivable | $ | 1 |  |  | $ | 1 |  |  | $ | 94 |  |  | $ | 142 |  |  | $ | 85 |  |  | $ | 5,075 |  |  |  |  | $ | 136 |  |  | $ | 976 |  |  | $ | 316 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,350 |  |  | $ | 1,927 |  |  | $ | 13,371 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 14,721 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 50,359 |  |  | $ | 98,629 |  |  | $ | 64,945 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 230 |  |  | $ | 115,304 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 487 |  |  | $ | — |  |  | $ | 254 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 741 |  |  | $ | 170 |  |
| Other Long-term liabilities (3) | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | — |  |
  (was, 2025-02-25, similarity 0.8766):
[0001375365-25-000006:note_history:118]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  |  |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 34 |  |  | $ | 142 |  |  | $ | (2) |  |  | $ | 5,075 |  |  |  |  | $ | 134 |  |  | $ | 976 |  |  | $ | 168 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,597 |  |  | $ | 1,927 |  |  | $ | 15,753 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 17,350 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 52,754 |  |  | $ | 98,629 |  |  | $ | 56,697 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 230 |  |  | $ | 109,535 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 294 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 170 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:119]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.
  (was, 2025-02-25, similarity 0.6515):
[0001375365-25-000006:note_history:119]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

- added (2025-05-12):
[0001375365-25-000014:note_history:120]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

- added (2025-05-12):
[0001375365-25-000014:note_history:121]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

- changed (2025-05-12):
[0001375365-25-000014:note_history:122]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9695):
[0001375365-25-000006:note_history:122]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:123]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |  |  | Three Months EndedMarch 31, |  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 3 |  |  | $ | 2 |  |  | $ | 3,278 |  |  | $ | 21,501 |  |  | $ | 4,201 |  |  | $ | 4,301 |  |  |  |  | $ | 165 |  |  | $ | — |  |  | $ | 7,647 |  |  | $ | 25,804 |  |
| Purchases - inventory | $ | 50,147 |  |  | $ | 65,933 |  |  | $ | 65,372 |  |  | $ | 64,464 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 115,519 |  |  | $ | 130,397 |  |
| Purchases - other miscellaneous items | $ | 8,748 |  |  | $ | 4,401 |  |  | $ | 460 |  |  | $ | 343 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 9,208 |  |  | $ | 4,744 |  |
  (was, 2025-02-25, similarity 0.6997):
[0001375365-25-000006:note_history:123]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21,040 |  |  | $ | 20,998 |  |  | $ | 4,776 |  |  | $ | 12,173 |  |  |  |  | $ | 329 |  |  | $ | — |  | $ | 26,152 |  |  | $ | 33,177 |  |
| Purchases - inventory | $ | 202,279 |  |  | $ | 97,199 |  |  | $ | 173,348 |  |  | $ | 128,353 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  | 376,161 |  |  | 225,552 |  |
| Purchases - other miscellaneous items | $ | 10,118 |  |  | $ | 8,215 |  |  | $ | 1,031 |  |  | $ | 749 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 11,149 |  |  | $ | 8,964 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:124]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9521):
[0001375365-25-000006:note_history:124]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:125]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 10 |  |  | $ | 8 |  |  | $ | 24,318 |  |  | $ | 42,498 |  |  | $ | 8,977 |  |  | $ | 16,474 |  |  |  |  | $ | 494 |  |  | $ | — |  |  | $ | 33,799 |  |  | $ | 58,980 |  |
| Purchases - inventory | $ | 252,426 |  |  | $ | 163,131 |  |  | $ | 238,720 |  |  | $ | 192,817 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  |  | $ | 491,680 |  |  | $ | 355,948 |  |
| Purchases - other miscellaneous items | $ | 18,866 |  |  | $ | 12,616 |  |  | $ | 1,491 |  |  | $ | 1,092 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 20,357 |  |  | $ | 13,708 |  |
  (was, 2025-02-25, similarity 0.6833):
[0001375365-25-000006:note_history:125]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, | Three months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 5 |  |  | $ | 4 |  |  | $ | 11,065 |  |  | $ | 4,392 |  |  | $ | (51) |  |  | $ | 11,385 |  |  |  |  | $ | 258 |  |  | $ | — |  | $ | 11,277 |  |  | $ | 15,781 |  |
| Purchases - inventory | $ | 64,773 |  |  | $ | 50,586 |  |  | $ | 71,230 |  |  | $ | 61,859 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 106 |  |  | $ | — |  | $ | 136,109 |  |  | $ | 112,445 |  |
| Purchases - other miscellaneous items | $ | 3,764 |  |  | $ | 3,456 |  |  | $ | 294 |  |  | $ | 332 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 4,058 |  |  | $ | 3,788 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:126]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-02-25, similarity 0.9548):
[0001375365-25-000006:note_history:126]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:127]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |  |  | Nine Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Changes in accounts receivable | $ | — |  |  | $ | (1) |  |  | $ | 48 |  |  | $ | 3,260 |  |  | $ | 4,990 |  |  | $ | 1,104 |  |  |  |  | $ | 840 |  |  | $ | — |  |  | $ | 5,878 |  |  | $ | 4,363 |  |
| Changes in other receivable | $ | 577 |  |  | $ | 1,022 |  |  | $ | (3,359) |  |  | $ | (3,539) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | (2,782) |  |  | $ | (2,517) |  |
| Changes in accounts payable | $ | (48,270) |  |  | $ | 18,480 |  |  | $ | (1,491) |  |  | $ | (5,032) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (230) |  |  | $ | — |  |  | $ | (49,991) |  |  | $ | 13,448 |  |
| Changes in accrued liabilities | $ | 487 |  |  | $ | (538) |  |  | $ | 84 |  |  | $ | 5,319 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |  | $ | 4,781 |  |
| Changes in other long-term liabilities | $ | 227 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (178) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 729 |  |  | $ | (178) |  |
| Purchases of property, plant and equipment | $ | 10,137 |  |  | $ | 8,935 |  |  | $ | 371 |  |  | $ | 197 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 10,508 |  |  | $ | 9,132 |  |
| Unpaid property, plant and equipment | $ | 7,111 |  |  | $ | 1,492 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 7,111 |  |  | $ | 1,492 |  |
  (was, 2025-02-25, similarity 0.655):
[0001375365-25-000006:note_history:127]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 108 |  |  | $ | 3,239 |  |  | $ | 5,077 |  |  | $ | (1,625) |  |  |  |  | $ | 842 |  |  | $ | — |  | $ | 6,026 |  |  | $ | 1,614 |  |
| Changes in other receivable | $ | 330 |  |  | $ | 571 |  |  | $ | (5,741) |  |  | $ | (7,132) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | (5,411) |  |  | $ | (6,561) |  |
| Changes in accounts payable | $ | (45,875) |  |  | $ | 10,938 |  |  | $ | (9,739) |  |  | $ | 1,628 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 146 |  |  | $ | — |  | $ | (55,468) |  |  | $ | 12,566 |  |
| Changes in accrued liabilities | $ | 294 |  |  | $ | (156) |  |  | $ | (146) |  |  | $ | 4,648 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 148 |  |  | $ | 4,492 |  |
| Changes in other long-term liabilities | $ | 154 |  |  | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 154 |  |  | $ | (152) |  |
| Purchases of property, plant and equipment | $ | 6,525 |  |  | $ | 4,460 |  |  | $ | 357 |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 6,882 |  |  | $ | 4,528 |  |
| Unpaid property, plant and equipment | $ | 2,946 |  |  | $ | 2,570 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 2,960 |  |  | $ | 2,577 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0001375365-25-000014:note_history:128]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Server and storage systems | $ | 4,458,895 |  |  | $ | 3,698,446 |  |  | $ | 15,693,826 |  |  | $ | 9,100,616 |  |
| Subsystems and accessories | 141,018 |  |  | 151,620 |  |  | 521,305 |  |  | 534,046 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |
  (was, 2025-02-25, similarity 0.8732):
[0001375365-25-000006:note_history:128]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 5,487,150 |  |  | $ | 3,435,562 |  |  | $ | 11,234,931 |  |  | $ | 5,402,170 |  |
| Subsystems and accessories | 190,812 |  |  | 229,362 |  |  | 380,287 |  |  | 382,426 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:129]
The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):
  (was, 2025-02-25, similarity 0.9457):
[0001375365-25-000006:note_history:129]
The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:130]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 2,768,181 |  |  | $ | 2,685,213 |  |  | $ | 10,856,490 |  |  | $ | 6,910,312 |  |
| Asia | 1,354,346 |  |  | 764,614 |  |  | 3,077,166 |  |  | 1,646,302 |  |
| Europe | 290,108 |  |  | 297,653 |  |  | 1,869,722 |  |  | 776,949 |  |
| Other | 187,278 |  |  | 102,586 |  |  | 411,753 |  |  | 301,099 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |
  (was, 2025-02-25, similarity 0.897):
[0001375365-25-000006:note_history:130]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 3,846,960 |  |  | $ | 2,605,585 |  |  | $ | 8,088,309 |  |  | $ | 4,225,099 |  |
| Asia | 768,246 |  |  | 656,220 |  |  | 1,722,820 |  |  | 881,688 |  |
| Europe | 933,772 |  |  | 288,448 |  |  | 1,579,614 |  |  | 479,296 |  |
| Other | 128,984 |  |  | 114,671 |  |  | 224,475 |  |  | 198,513 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-12):
[0001375365-25-000014:note_history:131]
Note 2.                 Revenue

- changed (2025-05-12):
[0001375365-25-000014:note_history:132]
Disaggregation of Revenue
  (was, 2025-02-25, similarity 0.8621):
[0001375365-25-000006:note_history:132]
Revenue
Disaggregation of Revenue

- changed (2025-05-12):
[0001375365-25-000014:note_history:133]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Server and storage systems | $ | 4,458,895 |  |  | $ | 3,698,446 |  |  | $ | 15,693,826 |  |  | $ | 9,100,616 |  |
| Subsystems and accessories | 141,018 |  |  | 151,620 |  |  | 521,305 |  |  | 534,046 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |
  (was, 2025-02-25, similarity 0.8732):
[0001375365-25-000006:note_history:133]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 5,487,150 |  |  | $ | 3,435,562 |  |  | $ | 11,234,931 |  |  | $ | 5,402,170 |  |
| Subsystems and accessories | 190,812 |  |  | 229,362 |  |  | 380,287 |  |  | 382,426 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:134]
Revenue related to services for the three months ended March 31, 2025 and 2024 was $57.2 million and $38.3 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the nine months ended March 31, 2025 and 2024 was $161.8 million and $110.7 million, respectively, which is recognized over time ratably over the contract term.
  (was, 2025-02-25, similarity 0.9132):
[0001375365-25-000006:note_history:134]
Revenue related to services for the three months ended December 31, 2024 and 2023 was $54.4 million, and $37.2 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the six months ended December 31, 2024 and 2023 was $104.6 million and $72.4 million, respectively, which is recognized over time ratably over the contract term.

- changed (2025-05-12):
[0001375365-25-000014:note_history:135]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2025 and 2024, of net sales by geographic region (in thousands):
  (was, 2025-02-25, similarity 0.8983):
[0001375365-25-000006:note_history:135]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):

- changed (2025-05-12):
[0001375365-25-000014:note_history:136]
|  | Three Months Ended March 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States | $ | 2,768,181 |  |  | $ | 2,685,213 |  |  | $ | 10,856,490 |  |  | $ | 6,910,312 |  |
| Asia | 1,354,346 |  |  | 764,614 |  |  | 3,077,166 |  |  | 1,646,302 |  |
| Europe | 290,108 |  |  | 297,653 |  |  | 1,869,722 |  |  | 776,949 |  |
| Other | 187,278 |  |  | 102,586 |  |  | 411,753 |  |  | 301,099 |  |
| Total | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |
  (was, 2025-02-25, similarity 0.897):
[0001375365-25-000006:note_history:136]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 3,846,960 |  |  | $ | 2,605,585 |  |  | $ | 8,088,309 |  |  | $ | 4,225,099 |  |
| Asia | 768,246 |  |  | 656,220 |  |  | 1,722,820 |  |  | 881,688 |  |
| Europe | 933,772 |  |  | 288,448 |  |  | 1,579,614 |  |  | 479,296 |  |
| Other | 128,984 |  |  | 114,671 |  |  | 224,475 |  |  | 198,513 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |

- changed (2025-05-12):
[0001375365-25-000014:note_history:137]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2025, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $38.5 million and $154.0 million, respectively. Revenue recognized during the three and nine months ended March 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $28.9 million and $104.1 million, respectively.
  (was, 2025-02-25, similarity 0.9526):
[0001375365-25-000006:note_history:137]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $47.3 million and $115.5 million, respectively. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.

- changed (2025-05-12):
[0001375365-25-000014:note_history:138]
Deferred revenue increased $249.4 million as of March 31, 2025 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $116.7 million increase in non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales which are expected to be fulfilled in the next 12 months.
  (was, 2025-02-25, similarity 0.6214):
[0001375365-25-000006:note_history:138]
Deferred revenue increased $182.3 million as of December 31, 2024 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods.

- added (2025-05-12):
[0001375365-25-000014:note_history:139]
Transaction Price Allocated to the Remaining Performance Obligations

- changed (2025-05-12):
[0001375365-25-000014:note_history:140]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to the remaining performance obligations as of March 31, 2025 was approximately $665.8 million. The Company expects to recognize approximately 53% of such value in the next 12 months, and the remainder thereafter.
  (was, 2025-02-25, similarity 0.8888):
[0001375365-25-000006:note_history:140]
Transaction Price Allocated to the Remaining Performance Obligations
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to deferred revenue as of December 31, 2024 was approximately $598.7 million. The Company expects to recognize approximately 52%


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-12):
[0001375365-25-000006:note_history:141]
Subsequent Events

- removed (2025-05-12):
[0001375365-25-000006:note_history:142]
Amendment of 2029 Convertible Notes and associated capped calls

- removed (2025-05-12):
[0001375365-25-000006:note_history:143]
On February 20, 2025, the Company amended the terms of the 2029 Convertible Notes pursuant to a first supplemental indenture and a second supplemental indenture, in each case by and between the Company and U.S. Bank Trust Company, National Association as trustee. The terms of the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated initial conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes (equivalent to an initial conversion price of approximately $83.44 per share of the Company’s common stock). The conversion rate and conversion price will be subject to adjustment upon the occurrence of certain events. The remaining terms of the 2029 Convertible Notes remain substantially unchanged.

- removed (2025-05-12):
[0001375365-25-000006:note_history:144]
In connection with the amendment of the terms of the 2029 Convertible Notes, the Company amended the capped call transactions entered into in connection with the initial issuance of the 2029 Convertible Notes in February 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the cap price. The cap price, after giving effect to the amendments, is initially $94.1666 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls.

- removed (2025-05-12):
[0001375365-25-000006:note_history:145]
Issuance of 2028 Convertible Notes

- removed (2025-05-12):
[0001375365-25-000006:note_history:146]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture, dated as of February 20, 2025 by and between the Company and U.S. Bank Trust Company, National Association, as trustee for gross proceeds of $700 million and approximately $50 million of issuance cost. The 2028 Convertible Notes were sold to investors pursuant to privately negotiated agreements. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier redeemed, repurchased or converted. The 2028 Convertible Notes have an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of the 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock, in each case subject to adjustment upon the occurrence of certain events. Prior to January 15, 2028, the 2028 Convertible Notes will be convertible only upon the satisfaction of certain conditions and during certain periods, and on and after January 15, 2028, at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date, the 2028 Convertible Notes will be convertible regardless of these conditions. The Company will settle conversions of the 2028 Convertible Notes by paying or delivering cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock at the Company’s election.
