# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001375365-25-000014:item_4_controls:1]
Item 4.    Controls and Procedures

[0001375365-25-000014:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001375365-25-000014:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for evaluating the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the period covered by this Quarterly Report. Our disclosure controls and procedures are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Exchange Act is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure and is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that their objectives are met. Because of the inherent limitations in all control systems, no evaluation of disclosure controls and procedures can provide absolute assurance that all disclosure control issues, if any, have been detected. We carried out an evaluation under the supervision of and with the participation of management, including Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures and concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of the end of the period covered by this Quarterly Report due to the material weaknesses in our internal control over financial reporting described below.

[0001375365-25-000014:item_4_controls:4]
Material Weaknesses in Internal Control over Financial Reporting

[0001375365-25-000014:item_4_controls:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended, or the Exchange Act). Our management, including our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of June 30, 2024. In making this assessment, our management used the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”).

[0001375365-25-000014:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected in a timely basis.

[0001375365-25-000014:item_4_controls:7]
As previously reported in our Annual Report on Form 10-K, we identified the following material weaknesses in internal control over financial reporting as of June 30, 2024, which are unremdiated as of March 31, 2025:

[0001375365-25-000014:item_4_controls:8]
(i) information technology general controls for certain systems that support the Company's financial reporting process that were not appropriately identified, designed or implemented; (ii) controls to address segregation of duties conflicts which were not properly designed and appropriately implemented; (iii) controls and documentation thereof, over the review and approval of manual journal entries that were not properly designed and appropriately implemented to prevent unauthorized access to post journal entries; (iv) controls over the completeness and accuracy of information produced by the entity impacting multiple financial statement areas that were not properly documented; and (v) management did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new leasing arrangements and new related party transactions.

[0001375365-25-000014:item_4_controls:9]
Notwithstanding the material weaknesses in internal control over financial reporting described above, management believes and has concluded that the condensed consolidated financial statements included in this Quarterly Report fairly present, in all material respects, our financial position, results of operations and cash flows for the periods presented in conformity with GAAP.

[0001375365-25-000014:item_4_controls:10]
(b) Remediation Plan

[0001375365-25-000014:item_4_controls:11]
We have identified and are implementing actions intended to improve the effectiveness of our internal control over financial reporting and disclosure controls and procedures and will continue to do so until such remediation is complete. During the quarter ended March 31, 2025, we began to implement changes designed to improve our internal controls over financial reporting and to remediate the material weaknesses, including, but not limited to:

[0001375365-25-000014:item_4_controls:12]
SMCI | Q3 2025 Form 10-Q | 52

[0001375365-25-000014:item_4_controls:13]
•Enhancing our Accounting organization’s competencies, by adding additional qualified leadership personnel with strong technical accounting, external reporting and governance experience; specifically;

[0001375365-25-000014:item_4_controls:14]
◦identified and hired a Vice President who is qualified to lead our technical accounting, external reporting and global internal controls compliance functions;

[0001375365-25-000014:item_4_controls:15]
◦reassessing our accounting procedures and related information provided by entity documentation, and, as part of the financial reporting process, are implementing the use of supplementary checklists as well as conducting additional reviews and evaluations of transactions to improve the accuracy and reliability of our financial information; and

[0001375365-25-000014:item_4_controls:16]
◦replaced certain existing financial personnel with appropriate qualified resources in the quarter ended March 31, 2025 to ensure that procedures are implemented, adequate reviews are performed, and financial information as presented is accurate.

[0001375365-25-000014:item_4_controls:17]
•The design of a global learning management and communication system, including working with various service providers to develop appropriate trainings, across various areas, including Finance, Compliance, Information Technology and Sales, to our global workforce to ensure that our accounting and finance personnel stay current on a wide-variety of areas, and are focused on sufficiently documenting our internal control over the completeness and accuracy of the information we use to support our financial reporting.

[0001375365-25-000014:item_4_controls:18]
•Establishing standardized policies and procedures for manual journal entry creation and posting, including clear documentation and approval requirements based on the risk profile of the financial statement line item impacted, and analyzing manual journal entry approval workflow requirements against SAP functionality and automation solutions, including enforcing user roles and access controls to ensure oversight and prevent unauthorized entries.

[0001375365-25-000014:item_4_controls:19]
•Reviewing our IT architecture and organization, with an increased emphasis on automation of manual processes, thereby strengthening our overall information technology related processes and controls.

[0001375365-25-000014:item_4_controls:20]
The process of implementing an effective financial reporting system is a continuous effort that requires us to anticipate and react to changes in our business and regulatory environments. Further, we are required to expend significant resources to maintain a financial reporting system that is adequate to satisfy our reporting obligations. As we continue to evaluate and take actions to improve our internal control over financial reporting, we may take additional actions to address control deficiencies or modify certain of the remediation measures described above.

[0001375365-25-000014:item_4_controls:21]
While progress has been made to enhance our internal control over financial reporting, we are still in the process of implementing these processes, procedures and controls. Additional time is required to complete the implementation and to assess and ensure the long-term sustainability of these procedures. We believe the above actions will be effective in remediating the material weaknesses described above and we will continue to devote significant time and attention to these remedial efforts. However, the material weaknesses cannot be considered remediated until the applicable remedial controls operate for a sufficient period of time and management has concluded that these controls are operating effectively.

[0001375365-25-000014:item_4_controls:22]
(c) Changes in Internal Control over Financial Reporting

[0001375365-25-000014:item_4_controls:23]
There were no changes in our internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act, during the quarter ended March 31, 2025 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-25-000014:item_4_controls:24]
However, as noted above, we will be implementing changes to our internal control over financial reporting to address the material weakness described above.

[0001375365-25-000014:item_4_controls:25]
SMCI | Q3 2025 Form 10-Q | 53
