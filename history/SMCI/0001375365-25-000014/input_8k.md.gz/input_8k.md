# SMCI 8-K — 0001375365-25-000013 filed 2025-05-06

## item codes, every 8-K on or before 2025-05-12

- 2025-05-06 0001375365-25-000013 — 2.02, 9.01
- 2025-04-29 0001375365-25-000012 — 2.02, 9.01
- 2025-03-31 0001375365-25-000008 — 5.02, 7.01, 9.01
- 2025-02-26 0001375365-25-000007 — 3.01, 5.08, 8.01, 9.01
- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2025-05-12

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-25-000013:8k_2_02:1]
EX-99.1
2
exhibit991_20250506.htm
EX-99.1

[0001375365-25-000013:8k_2_02:2]
Document

[0001375365-25-000013:8k_2_02:3]
Exhibit 99.1

[0001375365-25-000013:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2025 Financial Results

[0001375365-25-000013:8k_2_02:5]
SAN JOSE, Calif. -- May 6, 2025 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced unaudited financial results for its third quarter of fiscal year 2025 ended March 31, 2025.

[0001375365-25-000013:8k_2_02:6]
Third Quarter Fiscal Year 2025 Highlights

[0001375365-25-000013:8k_2_02:7]
•Net sales of $4.60 billion versus $5.68 billion in Q2'25 and $3.85 billion in Q3'24.

[0001375365-25-000013:8k_2_02:8]
.

[0001375365-25-000013:8k_2_02:9]
•Gross margin of 9.6% versus 11.8% in Q2'25 and 15.5% in Q3'24.

[0001375365-25-000013:8k_2_02:10]
•Net income of $109 million versus $321 million in Q2'25 and $402 million in Q3'24.

[0001375365-25-000013:8k_2_02:11]
•Diluted net income per common share of $0.17 versus $0.51 in Q2'25 and $0.66 in Q3'24.

[0001375365-25-000013:8k_2_02:12]
•Non-GAAP diluted net income per common share of $0.31 versus $0.59 in Q2'25 and $0.66 in Q3'24.

[0001375365-25-000013:8k_2_02:13]
•Cash flow provided by operations for Q3'25 of $627 million and capital expenditures of $33 million.

[0001375365-25-000013:8k_2_02:14]
“We continue to make great progress with our DCBBS (Data Center Building Block Solution), DLC (Direct Liquid Cooled-2) and AI technology leadership, but some customers delayed making platform decisions in the quarter,” said Charles Liang, Founder, President, and CEO of Supermicro. “We do expect many of those commitments to land in the June and September quarters, reinforcing my confidence in our ability to meet our long-term targets, however economic uncertainty and tariff impacts may have a short-term impact. We believe that we are well positioned in the long-term to capitalize on the growing market opportunity."

[0001375365-25-000013:8k_2_02:15]
The non-GAAP gross margin for the third quarter of fiscal year 2025 was 9.7% with adjustments for stock-based compensation expenses of $7 million. The non-GAAP diluted net income per common share for the third quarter of fiscal year 2025 was $0.31. This non-GAAP figure includes adjustments for stock-based compensation expenses and the loss on extinguishment of convertible notes of $62 million and $23 million, which are net of the related tax effect of $22 million and $7 million, respectively. As of March 31, 2025, total cash and cash equivalents was $2.54 billion and total bank debt and convertible notes were $2.49 billion.

[0001375365-25-000013:8k_2_02:16]
Recent Corporate Governance Updates

[0001375365-25-000013:8k_2_02:17]
The Company has made progress on strengthening its corporate governance practices and implementing recommendations by the Special Committee of the board of directors. All outstanding financial statements have been filed and the Company is in compliance with all Nasdaq filing requirements. Since December 2, 2024, Supermicro has strengthened its board of directors and management team with the additions of Scott Angel, who joined the company’s board of directors, Yitai Hu, as the Company's General Counsel & Senior Vice President of Corporate Development, and Kenneth Cheung, as the Company’s Senior Vice President and Chief Accounting Officer.

[0001375365-25-000013:8k_2_02:18]
Business Outlook

[0001375365-25-000013:8k_2_02:19]
The Company expects net sales of $5.6 billion to $6.4 billion for the fourth quarter of fiscal year 2025 ending June 30, 2025, GAAP net income per diluted share of $0.30 to $0.40 and non-GAAP net income per diluted share of $0.40 to $0.50. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 14.9% and 16.5%, respectively, and a fully diluted share count of 628 million shares for GAAP and fully diluted share count of 642 million shares for non-GAAP. The outlook for fourth quarter of fiscal year 2025 GAAP net income per diluted share includes approximately $63 million in expected stock-based compensation, net of related tax effects of $18 million that are excluded from non-GAAP net income per diluted share.

[0001375365-25-000013:8k_2_02:20]
For fiscal year 2025, the Company is updating its revenue guidance from a range of $23.5 billion to $25.0 billion to a new range of $21.8 billion to $22.6 billion.

[0001375365-25-000013:8k_2_02:21]
Conference Call and Webcast Information

[0001375365-25-000013:8k_2_02:22]
Supermicro will present a live audio webcast of a conference call to review its third quarter of fiscal year 2025 on Tuesday, May 6, 2025, at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-25-000013:8k_2_02:23]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-25-000013:8k_2_02:24]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-25-000013:8k_2_02:25]
About Super Micro Computer, Inc.

[0001375365-25-000013:8k_2_02:26]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-25-000013:8k_2_02:27]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-25-000013:8k_2_02:28]
All other brands, names, and trademarks are the property of their respective owners.

[0001375365-25-000013:8k_2_02:29]
Investor Relations Contact:

[0001375365-25-000013:8k_2_02:30]
Nicole Noutsios

[0001375365-25-000013:8k_2_02:31]
Stratos Advisors

[0001375365-25-000013:8k_2_02:32]
email: ir@supermicro.com

[0001375365-25-000013:8k_2_02:33]
Source: Super Micro Computer, Inc.

[0001375365-25-000013:8k_2_02:34]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-25-000013:8k_2_02:36]
(in thousands)

[0001375365-25-000013:8k_2_02:37]
(unaudited)

[0001375365-25-000013:8k_2_02:38]
|  | March 31, |  | June 30, |
|  | 2025 |  | 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,536,101 |  |  | $ | 1,669,766 |  |
| Accounts receivable, net of allowance for credit losses | 2,642,556 |  |  | 2,737,331 |  |
| Inventories | 3,870,243 |  |  | 4,333,029 |  |
| Prepaid expenses and other current assets | 464,689 |  |  | 191,834 |  |
| Total current assets | 9,513,589 |  |  | 8,931,960 |  |
| Property, plant and equipment, net | 492,565 |  |  | 414,008 |  |
| Deferred income taxes, net | 481,216 |  |  | 365,172 |  |
| Other assets | 251,155 |  |  | 114,952 |  |
| Total assets | $ | 10,738,525 |  |  | $ | 9,826,092 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 643,050 |  |  | $ | 1,472,381 |  |
| Accrued liabilities | 344,679 |  |  | 259,674 |  |
| Income taxes payable | 23,633 |  |  | 18,268 |  |
| Lines of credit and current portion of term loans | 63,971 |  |  | 402,346 |  |
| Deferred revenue | 352,803 |  |  | 193,052 |  |
| Total current liabilities | 1,428,136 |  |  | 2,345,721 |  |
| Deferred revenue, non-current | 312,994 |  |  | 223,324 |  |
| Term loans, non-current | 43,003 |  |  | 74,083 |  |
| Convertible notes | 2,385,320 |  |  | 1,697,716 |  |
| Other long-term liabilities | 189,593 |  |  | 67,878 |  |
| Total liabilities | 4,359,046 |  |  | 4,408,722 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 2,939,276 |  |  | 2,830,820 |  |
| Accumulated other comprehensive income | 663 |  |  | 706 |  |
| Retained earnings | 3,439,380 |  |  | 2,585,680 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 6,379,319 |  |  | 5,417,206 |  |
| Noncontrolling interest | 160 |  |  | 164 |  |
| Total stockholders’ equity | 6,379,479 |  |  | 5,417,370 |  |
| Total liabilities and stockholders’ equity | $ | 10,738,525 |  |  | $ | 9,826,092 |  |

[0001375365-25-000013:8k_2_02:39]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-25-000013:8k_2_02:41]
(in thousands, except per share amounts)

[0001375365-25-000013:8k_2_02:42]
(unaudited)

[0001375365-25-000013:8k_2_02:43]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 4,599,913 |  |  | $ | 3,850,066 |  |  | $ | 16,215,131 |  |  | $ | 9,634,662 |  |
| Cost of sales | 4,159,695 |  |  | 3,252,698 |  |  | 14,329,311 |  |  | 8,119,281 |  |
| Gross profit | 440,218 |  |  | 597,368 |  |  | 1,885,820 |  |  | 1,515,381 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 162,857 |  |  | 116,226 |  |  | 453,329 |  |  | 336,077 |  |
| Sales and marketing | 59,978 |  |  | 49,691 |  |  | 208,400 |  |  | 133,775 |  |
| General and administrative | 70,603 |  |  | 53,137 |  |  | 199,488 |  |  | 123,241 |  |
| Total operating expenses | 293,438 |  |  | 219,054 |  |  | 861,217 |  |  | 593,093 |  |
| Income from operations | 146,780 |  |  | 378,314 |  |  | 1,024,603 |  |  | 922,288 |  |
| Other (expense) income, net | (18,313) |  |  | 10,035 |  |  | 1,879 |  |  | 8,762 |  |
| Interest expense | (13,402) |  |  | (6,246) |  |  | (37,291) |  |  | (16,240) |  |
| Income before income tax provision | 115,065 |  |  | 382,103 |  |  | 989,191 |  |  | 914,810 |  |
| Income tax (provision) benefit | (5,843) |  |  | 19,983 |  |  | (137,544) |  |  | (61,735) |  |
| Share of (expense) income from equity investee, net of taxes | (445) |  |  | 373 |  |  | 2,053 |  |  | 2,347 |  |
| Net income | $ | 108,777 |  |  | $ | 402,459 |  |  | $ | 853,700 |  |  | $ | 855,422 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.18 |  |  | $ | 0.71 |  |  | $ | 1.44 |  |  | $ | 1.57 |  |
| Diluted | $ | 0.17 |  |  | $ | 0.66 |  |  | $ | 1.37 |  |  | $ | 1.45 |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 595,041 |  |  | 564,780 |  |  | 592,349 |  |  | 545,620 |  |
| Diluted | 621,809 |  |  | 614,310 |  |  | 625,272 |  |  | 588,890 |  |

[0001375365-25-000013:8k_2_02:44]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-25-000013:8k_2_02:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of sales | $ | 7,060 |  |  | $ | 3,221 |  |  | $ | 17,713 |  |  | $ | 12,680 |  |
| Research and development | 54,254 |  |  | 24,856 |  |  | 141,590 |  |  | 86,005 |  |
| Sales and marketing | 9,923 |  |  | 4,993 |  |  | 27,245 |  |  | 14,998 |  |
| General and administrative | 13,467 |  |  | 23,037 |  |  | 44,292 |  |  | 42,864 |  |
| Stock-based compensation expense, before taxes | $ | 84,704 |  |  | $ | 56,107 |  |  | $ | 230,840 |  |  | $ | 156,547 |  |

[0001375365-25-000013:8k_2_02:46]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000013:8k_2_02:48]
(in thousands)

[0001375365-25-000013:8k_2_02:49]
(unaudited)

[0001375365-25-000013:8k_2_02:50]
|  | Nine Months EndedMarch 31, |
|  | 2025 |  | 2024 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 853,700 |  |  | $ | 855,422 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 39,708 |  |  | 29,174 |  |
| Stock-based compensation expense | 230,840 |  |  | 156,547 |  |
| Share of income from equity investee | (2,053) |  |  | (2,347) |  |
| Unrealized foreign currency exchange loss (gain) | 2,742 |  |  | (282) |  |
| Loss on extinguishment of convertible notes | 30,251 |  |  | — |  |
| Deferred income taxes, net | (134,401) |  |  | (144,485) |  |
| Other | 5,577 |  |  | 3,186 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 94,782 |  |  | (501,870) |  |
| Inventories | 457,897 |  |  | (2,679,023) |  |
| Prepaid expenses and other assets | (284,356) |  |  | (25,673) |  |
| Accounts payable | (811,690) |  |  | 309,613 |  |
| Accrued liabilities | 52,714 |  |  | 123,937 |  |
| Income taxes payable | 5,365 |  |  | (99,824) |  |
| Deferred revenue | 249,421 |  |  | 132,043 |  |
| Other long-term liabilities | 5,414 |  |  | 5,424 |  |
| Net cash provided by (used in) operating activities | 795,911 |  |  | (1,838,158) |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (104,536) |  |  | (110,296) |  |
| Investment in equity securities | — |  |  | (27,673) |  |
| Net cash used in investing activities | (104,536) |  |  | (137,969) |  |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from lines of credit and term loans | 1,357,991 |  |  | 1,818,850 |  |
| Repayment of lines of credit and term loans | (1,731,366) |  |  | (1,939,590) |  |
| Proceeds from exercise of stock options | 14,452 |  |  | 25,114 |  |
| Payment for withholding taxes related to settlement of equity awards | (118,960) |  |  | (119,285) |  |
| Issuances of common stock in public offerings, net of issuance costs | — |  |  | 2,313,990 |  |
| Debt issuance costs in connection with amended 2029 Convertibles Notes | (31,217) |  |  | — |  |
| Proceeds from issuance of 2029 Convertible Notes, net of issuance costs | — |  |  | 1,695,768 |  |
| Proceeds from issuance of 2028 Convertible Notes, net of issuance costs | 683,696 |  |  | — |  |
| Purchase of capped calls | — |  |  | (142,140) |  |
| Other | 22 |  |  | 76 |  |
| Net cash provided by financing activities | 174,618 |  |  | 3,652,783 |  |
| Effect of exchange rate fluctuations on cash | 826 |  |  | (1,634) |  |
| Net increase in cash, cash equivalents and restricted cash | 866,819 |  |  | 1,675,022 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 1,670,273 |  |  | 440,960 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 2,537,092 |  |  | $ | 2,115,982 |  |

[0001375365-25-000013:8k_2_02:51]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000013:8k_2_02:53]
(in thousands)

[0001375365-25-000013:8k_2_02:54]
(unaudited)

[0001375365-25-000013:8k_2_02:55]
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | $ | 24,046 |  |  | $ | 14,813 |  |
| Cash paid for taxes, net of refunds | $ | 270,392 |  |  | $ | 300,596 |  |
| Unpaid property, plant and equipment purchases | $ | 18,283 |  |  | $ | 9,345 |  |
| Right of use assets obtained in exchange for operating lease commitments | $ | 128,617 |  |  | $ | 24,140 |  |
| Transfer of inventory to property, plant and equipment | $ | 4,889 |  |  | $ | — |  |

[0001375365-25-000013:8k_2_02:56]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:57]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000013:8k_2_02:58]
(in thousands, except per share amounts)

[0001375365-25-000013:8k_2_02:59]
(unaudited)

[0001375365-25-000013:8k_2_02:60]
Use of Non-GAAP Financial Measures

[0001375365-25-000013:8k_2_02:61]
To supplement its condensed consolidated financial results presented in accordance with United States Generally Accepted Accounting Principles ("GAAP"), the Company uses non-GAAP measures that are adjusted for certain items from the most directly comparable GAAP measures. The specific non-GAAP measures presented below are: gross margin; operating expenses; net income; net income per common share; diluted net income; diluted net income per common share; and effective tax rate. Further, beginning with this reporting period management is adding adjusted earnings before interest, taxes, depreciation, and amortization, ("Adjusted EBITDA") as an additional non-GAAP financial measure. Management believes these non-GAAP measures provide useful information to investors by offering a consistent basis for comparing the Company's performance across periods, excluding items that are not reflective of our core operating results. These non-GAAP measures are not prepared in accordance with GAAP or intended to be a replacement for GAAP financial data; and therefore, should be reviewed together with the GAAP measures and are not intended to serve as a substitute for results under GAAP, and may be different from non-GAAP measures used by other companies.

[0001375365-25-000013:8k_2_02:62]
We exclude the following adjustments from our non-GAAP financial measures:

[0001375365-25-000013:8k_2_02:63]
Non-GAAP Adjustments

[0001375365-25-000013:8k_2_02:64]
•Stock-based compensation: Stock-based compensation relates primarily to our equity incentive awards. Stock-based compensation is a non-cash expense that is dependent on market forces that are difficult to predict. We believe that this adjustment for stock-based compensation provides investors with a basis to measure the company's core performance, including compared with the performance of other companies, without the period-to-period variability created by stock-based compensation.

[0001375365-25-000013:8k_2_02:65]
•Loss on extinguishment of convertible notes: We exclude the loss on extinguishment of debt related to our convertible notes from our non-GAAP results, as it is a non-recurring, financing-related charge that does not reflect our underlying operating performance in the period incurred. We believe it is appropriate to exclude this loss - and to present it separately - to provide investors with greater insight, as it is directly tied to a capital-raising event and is not reflective of ongoing operating results.

[0001375365-25-000013:8k_2_02:66]
•Adjusted EBITDA adjustments: When calculating Adjusted EBITDA, in addition to the adjustments described above, we exclude the impact of the following items during the period:

[0001375365-25-000013:8k_2_02:67]
◦Interest expense

[0001375365-25-000013:8k_2_02:68]
◦Income tax (provision) benefit

[0001375365-25-000013:8k_2_02:69]
◦Depreciation and amortization

[0001375365-25-000013:8k_2_02:70]
Pursuant to the requirements of SEC Regulation G, please see the tables below for the reconciliations of GAAP to Non-GAAP measures. These should be read together with the preceding financial statements prepared in accordance with GAAP.

[0001375365-25-000013:8k_2_02:71]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:72]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000013:8k_2_02:73]
(in thousands, except per share amounts)

[0001375365-25-000013:8k_2_02:74]
(unaudited)

[0001375365-25-000013:8k_2_02:75]
Reconciliation of GAAP Net Income to Adjusted EBITDA:

[0001375365-25-000013:8k_2_02:76]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |  |  |
| GAAP Net Income | $ | 156,995 |  |  | $ | 295,968 |  |  | $ | 402,459 |  |  | $ | 297,244 |  |  | $ | 424,327 |  |  | $ | 320,596 |  |  | $ | 108,777 |  |  |  |
| Interest expense | 1,863 |  |  | 8,131 |  |  | 6,246 |  |  | 3,112 |  |  | 17,354 |  |  | 6,535 |  |  | 13,402 |  |  |  |
| Income tax provision (benefit) | 20,215 |  |  | 61,503 |  |  | (19,983) |  |  | 1,559 |  |  | 74,732 |  |  | 56,969 |  |  | 5,843 |  |  |  |
| Depreciation & Amortization | 9,097 |  |  | 9,479 |  |  | 9,830 |  |  | 10,287 |  |  | 11,776 |  |  | 12,725 |  |  | 15,207 |  |  |  |
| Stock-based compensation | 57,379 |  |  | 43,061 |  |  | 56,107 |  |  | 74,960 |  |  | 64,014 |  |  | 82,122 |  |  | 84,704 |  |  |  |
| Loss on extinguishment of convertible notes | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 30,251 |  |  |  |
| Adjusted EBITDA | $ | 245,549 |  |  | $ | 418,142 |  |  | $ | 454,659 |  |  | $ | 387,162 |  |  | $ | 592,203 |  |  | $ | 478,947 |  |  | $ | 258,184 |  |  |  |
| Adjusted EBITDA % of net sales | 11.6% |  | 11.4% |  | 11.8% |  | 7.2% |  | 10.0% |  | 8.4% |  | 5.6% |  |  |

[0001375365-25-000013:8k_2_02:77]
Reconciliation of GAAP to Non-GAAP Gross Margin:

[0001375365-25-000013:8k_2_02:78]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |
| GAAP Gross Profit | $ | 353,691 |  |  | $ | 564,322 |  |  | $ | 597,368 |  |  | $ | 546,029 |  |  | $ | 775,580 |  |  | $ | 670,022 |  |  | $ | 440,218 |  |
| Stock-based compensation | 5,904 |  |  | 3,555 |  |  | 3,221 |  |  | 3,185 |  |  | 3,959 |  |  | 6,694 |  |  | 7,060 |  |
| Non-GAAP Gross Profit | $ | 359,595 |  |  | $ | 567,877 |  |  | $ | 600,589 |  |  | $ | 549,214 |  |  | $ | 779,539 |  |  | $ | 676,716 |  |  | $ | 447,278 |  |
| GAAP gross margin (%) | 16.7 | % |  | 15.4 | % |  | 15.5 | % |  | 10.2 | % |  | 13.1 | % |  | 11.8 | % |  | 9.6 | % |
| Stock-based compensation (%) | 0.3 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |  | — | % | * | 0.1 | % |  | 0.1 | % |
| Non-GAAP gross margin (%) | 17.0 | % |  | 15.5 | % |  | 15.6 | % |  | 10.3 | % |  | 13.1 | % |  | 11.9 | % |  | 9.7 | % |

[0001375365-25-000013:8k_2_02:79]
*Represents an amount less than 0.1%.

[0001375365-25-000013:8k_2_02:80]
Reconciliation of GAAP to Non-GAAP Operating Expenses:

[0001375365-25-000013:8k_2_02:81]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |
| GAAP Operating Expenses | $ | 181,181 |  |  | $ | 192,858 |  |  | $ | 219,054 |  |  | $ | 257,543 |  |  | $ | 266,381 |  |  | $ | 301,398 |  |  | $ | 293,438 |  |
| Adjustments to operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP R&D operating expenses | 111,027 |  |  | 108,824 |  |  | 116,226 |  |  | 127,471 |  |  | 132,243 |  |  | 158,229 |  |  | 162,857 |  |
| Stock-based compensation | 35,710 |  |  | 25,439 |  |  | 24,856 |  |  | 28,890 |  |  | 36,527 |  |  | 50,809 |  |  | 54,254 |  |
| Non-GAAP R&D operating expenses | 75,317 |  |  | 83,385 |  |  | 91,370 |  |  | 98,581 |  |  | 95,716 |  |  | 107,420 |  |  | 108,603 |  |
| GAAP S&M operating expenses | 37,230 |  |  | 46,854 |  |  | 49,691 |  |  | 55,963 |  |  | 68,854 |  |  | 79,568 |  |  | 59,978 |  |
| Stock-based compensation | 5,665 |  |  | 4,340 |  |  | 4,993 |  |  | 6,197 |  |  | 7,763 |  |  | 9,559 |  |  | 9,923 |  |
| Non-GAAP S&M operating expenses | 31,565 |  |  | 42,514 |  |  | 44,698 |  |  | 49,766 |  |  | 61,091 |  |  | 70,009 |  |  | 50,055 |  |
| GAAP G&A operating expenses | 32,924 |  |  | 37,180 |  |  | 53,137 |  |  | 74,109 |  |  | 65,284 |  |  | 63,601 |  |  | 70,603 |  |
| Stock-based compensation | 10,100 |  |  | 9,727 |  |  | 23,037 |  |  | 36,688 |  |  | 15,765 |  |  | 15,060 |  |  | 13,467 |  |
| Non-GAAP G&A operating expenses | 22,824 |  |  | 27,453 |  |  | 30,100 |  |  | 37,421 |  |  | 49,519 |  |  | 48,541 |  |  | 57,136 |  |
| Non-GAAP Operating Expenses | $ | 129,706 |  |  | $ | 153,352 |  |  | $ | 166,168 |  |  | $ | 185,768 |  |  | $ | 206,326 |  |  | $ | 225,970 |  |  | $ | 215,794 |  |

[0001375365-25-000013:8k_2_02:82]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:83]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000013:8k_2_02:84]
(in thousands, except per share amounts)

[0001375365-25-000013:8k_2_02:85]
(unaudited)

[0001375365-25-000013:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP Net Income:

[0001375365-25-000013:8k_2_02:87]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |
| GAAP net income | $ | 156,995 |  |  | $ | 295,968 |  |  | $ | 402,459 |  |  | $ | 297,244 |  |  | $ | 424,327 |  |  | $ | 320,596 |  |  | $ | 108,777 |  |
| Adjustments related to stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales | 5,904 |  |  | 3,555 |  |  | 3,221 |  |  | 3,185 |  |  | 3,959 |  |  | 6,694 |  |  | 7,060 |  |
| Operating expenses | 51,475 |  |  | 39,506 |  |  | 52,886 |  |  | 71,775 |  |  | 60,055 |  |  | 75,428 |  |  | 77,644 |  |
| Total adjustments to GAAP income from operations | 57,379 |  |  | 43,061 |  |  | 56,107 |  |  | 74,960 |  |  | 64,014 |  |  | 82,122 |  |  | 84,704 |  |
| Adjustments related to loss on extinguishment of convertible notes: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expense | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 30,251 |  |
| Total adjustments to GAAP Other expense | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 30,251 |  |
| Total adjustments to GAAP income before income tax provision | 57,379 |  |  | 43,061 |  |  | 56,107 |  |  | 74,960 |  |  | 64,014 |  |  | 82,122 |  |  | 114,955 |  |
| Income tax effect of non-GAAP adjustments | (16,049) |  |  | (9,569) |  |  | (47,023) |  |  | (20,169) |  |  | (15,873) |  |  | (19,136) |  |  | (29,706) |  |
| Non-GAAP net income | $ | 198,325 |  |  | $ | 329,460 |  |  | $ | 411,543 |  |  | $ | 352,035 |  |  | $ | 472,468 |  |  | $ | 383,582 |  |  | $ | 194,026 |  |
| GAAP net income - diluted | $ | 156,995 |  |  | $ | 295,968 |  |  | $ | 402,844 |  |  | $ | 298,339 |  |  | $ | 427,076 |  |  | $ | 321,706 |  |  | $ | 108,777 |  |
| Convertible note interest charge, net of tax | — |  |  | — |  |  | 385 |  |  | 1,095 |  |  | 2,749 |  |  | 1,110 |  |  | — |  |
| Non-GAAP net income - diluted | $ | 198,325 |  |  | $ | 329,460 |  |  | $ | 411,928 |  |  | $ | 353,130 |  |  | $ | 475,217 |  |  | $ | 384,692 |  |  | $ | 194,026 |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic - GAAP | 530,928 |  |  | 541,354 |  |  | 564,780 |  |  | 586,883 |  |  | 589,558 |  |  | 592,507 |  |  | 595,041 |  |
| Basic - Non-GAAP | 530,928 |  |  | 541,354 |  |  | 564,780 |  |  | 586,883 |  |  | 589,558 |  |  | 592,507 |  |  | 595,041 |  |
| Diluted - GAAP | 571,853 |  |  | 580,777 |  |  | 614,310 |  |  | 642,081 |  |  | 639,148 |  |  | 636,047 |  |  | 621,809 |  |
| Stock-based compensation | 6,607 |  |  | 8,843 |  |  | 5,220 |  |  | 6,186 |  |  | 8,930 |  |  | 10,624 |  |  | 14,108 |  |
| Diluted - Non-GAAP | 578,460 |  |  | 589,620 |  |  | 619,530 |  |  | 648,267 |  |  | 648,078 |  |  | 646,671 |  |  | 635,917 |  |

[0001375365-25-000013:8k_2_02:88]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000013:8k_2_02:89]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000013:8k_2_02:90]
(in thousands, except per share amounts)

[0001375365-25-000013:8k_2_02:91]
(unaudited)

[0001375365-25-000013:8k_2_02:92]
Reconciliation of GAAP to Non-GAAP EPS:

[0001375365-25-000013:8k_2_02:93]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |
| GAAP Net Income per common share - basic | $ | 0.30 |  |  | $ | 0.55 |  |  | $ | 0.71 |  |  | $ | 0.51 |  |  | $ | 0.72 |  |  | $ | 0.54 |  |  | $ | 0.18 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - basic | 0.11 |  | 0.08 |  | 0.10 |  | 0.13 |  | 0.11 |  | 0.14 |  | 0.14 |
| Loss on extinguishment of convertible notes - basic | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.05 |  |
| Income tax - basic | (0.04) |  |  | (0.02) |  |  | (0.08) |  |  | (0.04) |  |  | (0.03) |  |  | (0.03) |  |  | (0.04) |  |
| Non-GAAP Net Income per common share - basic | $ | 0.37 |  |  | $ | 0.61 |  |  | $ | 0.73 |  |  | $ | 0.60 |  |  | $ | 0.80 |  |  | $ | 0.65 |  |  | $ | 0.33 |  |
| GAAP net income per common share - dilutive | $ | 0.27 |  |  | $ | 0.51 |  |  | $ | 0.66 |  |  | $ | 0.46 |  |  | $ | 0.67 |  |  | $ | 0.51 |  |  | $ | 0.17 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - diluted | 0.10 |  | 0.07 |  | 0.09 |  | 0.12 |  | 0.09 |  | 0.12 |  | 0.14 |
| Loss on extinguishment of convertible notes - diluted | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.05 |  |
| Income tax - diluted | (0.03) |  |  | (0.02) |  |  | (0.09) |  |  | (0.04) |  |  | (0.03) |  |  | (0.04) |  |  | (0.05) |  |
| Non-GAAP Net Income per common share – diluted | $ | 0.34 |  |  | $ | 0.56 |  |  | $ | 0.66 |  |  | $ | 0.54 |  |  | $ | 0.73 |  |  | $ | 0.59 |  |  | $ | 0.31 |  |

[0001375365-25-000013:8k_2_02:94]
GAAP to Non-GAAP Effective Tax Rate:

[0001375365-25-000013:8k_2_02:95]
|  | Q1 2024 |  | Q2 2024 |  | Q3 2024 |  | Q4 2024 |  | Q1 2025 |  | Q2 2025 |  | Q3 2025 |
| GAAP effective tax rate | 11.4 | % |  | 17.3 | % |  | (5.2) | % |  | 0.5 | % |  | 15.0 | % |  | 15.2 | % |  | 5.1 | % |
| Total adjustments to GAAP provision to income tax | 4.1 | % |  | 0.5 | % |  | 11.4 | % |  | 5.3 | % |  | 1.1 | % |  | 1.4 | % |  | 10.4 | % |
| Non-GAAP effective tax rate | 15.5 | % |  | 17.8 | % |  | 6.2 | % |  | 5.8 | % |  | 16.1 | % |  | 16.6 | % |  | 15.5 | % |
