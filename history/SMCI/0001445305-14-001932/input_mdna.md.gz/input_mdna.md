# SMCI MD&A — 0001445305-14-001932


## mdna

[0001445305-14-001932:mdna:1]
[same as prior period, unchanged from 0001445305-14-000277:mdna:1]

[0001445305-14-001932:mdna:2]
[same as prior period, unchanged from 0001445305-14-000277:mdna:2]

[0001445305-14-001932:mdna:3]
We are a global leader in high-performance, high-efficiency server technology and green computing innovation. We develop and provide advanced server Building Block Solutions to Data Center, Cloud Computing, Enterprise, Hadoop/Big Data, High Performance Computing, or HPC, and Embedded markets. Our solutions range from complete server, storage, blade, workstation and full rack solutions to networking devices and server management software, which can be used by distributors, original equipment manufacturers, or OEMs, and end customers. Net sales of optimized servers were $187.3 million and $504.6 million for the three and nine months ended March 31, 2014, respectively, and $116.2 million and $349.2 million for the three and nine months ended March 31, 2013, respectively. Net sales of subsystems and accessories were $186.5 million and $534.5 million for the three and nine months ended March 31, 2014, respectively, and $161.8 million and $491.1 million for the three and nine months ended March 31, 2013, respectively. The increase in our net sales in the three and nine months ended March 31, 2014 compared with the three and nine months ended March 31, 2013 was primarily due to increased sales of complete integrated-high-end server systems particularly to our internet data center customers. We are also benefited from the technology transition from Intel's Sandybridge to Ivybridge processor as well as new product offerings of FatTwin, Storage and GPU/Xeon Phi based solutions. The strength of our innovative and broad product lines and the beginning of a technology refresh cycle resulted in a sequential growth in sales notwithstanding what has traditionally been a seasonally weak quarter for the industry. On a geographical basis, we had strong growth in the United States in the three months ended March 31, 2014 as we benefited from the expansion of the cloud and internet data center customers.

[0001445305-14-001932:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net sales were $373.8 million and $1,039.1 million for the three and nine months ended March 31, 2014, respectively, and $278.0 million and $840.2 million for the three and nine months ended March 31, 2013, respectively. Our net income was $16.6 million and $37.6 million for the three and nine months ended March 31, 2014, respectively, and $7.0 million and $12.9 million for the three and nine months ended March 31, 2013, respectively. Our increase in net income in the three and nine months ended March 31, 2014 compared to the three and nine months ended March 31, 2013 was primarily attributable to an increase in our gross profit resulting primarily from higher sales of server systems partially offset by higher research and development expenses.

[0001445305-14-001932:mdna:5]
We sell our server systems and subsystems and accessories primarily through distributors and to a lesser extent to OEMs as well as through our direct sales force. We derived 51.9% and 55.1% of our net sales from products sold to distributors and derived 48.1% and 44.9% from sales to OEMs and to end customers for the three and nine months ended March 31, 2014, respectively, and 58.8% and 56.2% of our net sales from products sold to distributors, and 41.2% and 43.8% from sales to OEMs and to end customers for the three and nine months ended March 31, 2013, respectively. None of our customers accounted for 10% or more of our net sales in the three and nine months ended March 31, 2014 and 2013. We derived 54.5% and 53.7% of our net sales from customers in the United States for the three and nine months ended March 31, 2014, respectively, and 56.6% and 53.4% for the three and nine months ended March 31, 2013, respectively. We derived 45.5% and 46.3% of our net sales from customers outside the United States for the three and nine months ended March 31, 2014, respectively, and 43.4% and 46.6% for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.5% and 5.9% of our net sales for the three and nine months ended March 31, 2014, respectively, and 6.7% and 6.6% for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2014, we have continued to invest in expanding our operations both in San Jose, California and our subsidiaries in Taiwan and the Netherlands in order to support our growth. We have increased manufacturing and service operations in Taiwan

[0001445305-14-001932:mdna:8]
and the Netherlands to support our Asian and European customers and we have increased our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and nine months ended March 31, 2014, our purchases from Ablecom represented 14.4% and 16.5%, respectively, compared to 18.8% and 18.3% of our cost of sales for the three and nine months ended March 31, 2013, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our product costs. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001445305-14-001932:mdna:9]
[same as prior period, unchanged from 0001445305-14-000277:mdna:8]

[0001445305-14-001932:mdna:10]
[same as prior period, unchanged from 0001445305-14-000277:mdna:9]

[0001445305-14-001932:mdna:11]
The following is a summary of other financial highlights of the third quarter of fiscal year 2014:

[0001445305-14-001932:mdna:12]
| • | Net cash provided by (used in) operating activities was $(5.9) million and $12.5 million during the three and nine months ended March 31, 2014, respectively, and $8.0 million and $13.6 million during the three and nine months ended March 31, 2013, respectively. Our cash and cash equivalents, together with our investments, were $104.4 million at the end of the third quarter of fiscal year 2014, compared with $95.7 million at the end of fiscal year 2013. The increase in our cash, cash equivalents and investments at the end of the third quarter of fiscal year 2014 was primarily due to $19.2 million of proceeds from exercise of stock options, $12.5 million of cash generated from operating activities and $11.7 million of proceeds from debt, net of repayment, partially offset by $36.8 million of purchases of property and equipment. |

[0001445305-14-001932:mdna:13]
| • | Days sales outstanding in accounts receivables (“DSO”) at the end of the third quarter of fiscal year 2014 was 41 days, compared with 38 days at the end of the fourth quarter of fiscal year 2013. The increase in DSO was primarily due to an increase in sales late in the quarter. |

[0001445305-14-001932:mdna:14]
| • | Our inventory balance was $295.1 million at the end of the third quarter of fiscal year 2014, compared with $254.2 million at the end of fiscal year 2013. Days sales of inventory (“DSI”) at the end of the third quarter of fiscal year 2014 was 83 days, compared with 84 days at the end of the fourth quarter of fiscal year 2013. The increase in our inventory was to support our revenue growth in fiscal year 2014. |

[0001445305-14-001932:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $271.2 million at the end of the third quarter of fiscal year 2014 and $249.0 million at the end of fiscal year 2013. Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $72.4 million, which have terms expiring through December 2014. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001445305-14-001932:mdna:16]
[same as prior period, unchanged from 0001445305-14-000277:mdna:18]

[0001445305-14-001932:mdna:17]
[same as prior period, unchanged from 0001445305-14-000277:mdna:19]

[0001445305-14-001932:mdna:18]
[same as prior period, unchanged from 0001445305-14-000277:mdna:20]

[0001445305-14-001932:mdna:19]
[same as prior period, unchanged from 0001445305-14-000277:mdna:21]

[0001445305-14-001932:mdna:20]
Cost of sales. Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel and related expenses, equipment and facility expenses, warranty costs and inventory excess and obsolete provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include raw material costs, shipping costs and salary and benefits related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales, as a percentage of net sales, is generally lower on server systems than on subsystems and accessories, but generally higher in the case of sales of server systems to internet data system customers. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on market conditions.

[0001445305-14-001932:mdna:21]
[same as prior period, unchanged from 0001445305-14-000277:mdna:23]

[0001445305-14-001932:mdna:22]
[same as prior period, unchanged from 0001445305-14-000277:mdna:24]

[0001445305-14-001932:mdna:23]
[same as prior period, unchanged from 0001445305-14-000277:mdna:25]

[0001445305-14-001932:mdna:24]
[same as prior period, unchanged from 0001445305-14-000277:mdna:26]

[0001445305-14-001932:mdna:25]
Income tax provision. Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, currently primarily the United States, Taiwan, the Netherlands, and to a lesser extent, China. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, the domestic production activities deduction and lower taxes in foreign jurisdictions which were partially offset by the impact of state taxes and stock option expenses.

[0001445305-14-001932:mdna:26]
[same as prior period, unchanged from 0001445305-14-000277:mdna:29]

[0001445305-14-001932:mdna:27]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, revenues and expenses. We evaluate our estimates on an on-going basis, including those related to allowances for doubtful accounts and sales returns, cooperative marketing accruals, investment valuations, inventory valuations, income taxes, warranty obligations and stock-based compensation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the

[0001445305-14-001932:mdna:28]
judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates.

[0001445305-14-001932:mdna:29]
[same as prior period, unchanged from 0001445305-14-000277:mdna:31]

[0001445305-14-001932:mdna:30]
Revenue recognition. We recognize revenue from sales of products, when persuasive evidence of an arrangement exists, shipment has occurred and title has transferred, the sales price is fixed or determinable, collection of the resulting receivable is reasonably assured, and all significant obligations have been met. Generally this occurs at the time of shipment when risk of loss and title has passed to the customer. Our standard arrangement with our customers includes a signed purchase order or contract, 30 to 60 days payment terms, Ex-works terms, except for a few customers who have free-on-board destination terms, for which revenue is recognized when the products arrive at the destination. We generally do not provide for non-warranty rights of return except for products which have “Out-of-box” failure, where customers could return these products for credit within 30 days of receiving the items. Certain distributors and OEMs are also permitted to return products in unopened boxes, limited to purchases over a specified period of time, generally within 60 to 90 days of the purchase, or to products in the distributor’s or OEM’s inventory at certain times (such as the termination of the agreement or product obsolescence). To estimate reserves for future sales returns, we regularly review our history of actual returns for each major product line. We also communicate regularly with our distributors to gather information about end customer satisfaction, and to determine the volume of inventory in the channel. Reserves for future returns are adjusted as necessary, based on returns experience, returns expectations and communication with our distributors.

[0001445305-14-001932:mdna:31]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. At March 31, 2014 and June 30, 2013, we had deferred revenue of $0.5 million and $1.0 million and related deferred product costs of $0.5 million and $0.7 million, respectively, related to shipments to customers pending acceptances.

[0001445305-14-001932:mdna:32]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentrations, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision for bad debt was $0.3 million and $1.4 million in the three and nine months ended March 31, 2014, respectively, and $0.6 million and $0.7 million in the three and nine months ended March 31, 2013, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001445305-14-001932:mdna:33]
[same as prior period, unchanged from 0001445305-14-000277:mdna:35]

[0001445305-14-001932:mdna:34]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are charged to cost of sales and included in accrued liabilities. The liability for product warranties was $6.9 million as of March 31, 2014, compared with $6.5 million as of June 30, 2013. The provision for warranty reserve was $3.5 million and $10.5 million in the three and nine months ended March 31, 2014, respectively, and $3.1 million and $9.5 million in the three and nine months ended March 31, 2013, respectively. Our estimates and assumptions used have been historically close to actual. The change in estimated liability for pre-existing warranties was $0.1 million and $0.2 million in the three and nine months ended March 31, 2014, respectively, and ($0.2) million and $30,000 in the three and nine months ended March 31, 2013, respectively. As a result of our increase in cost of servicing warranty claims from our increase in net sales in the three and nine months ended March 31, 2014, the provision for warranty reserve increased $0.5 million and $0.9 million compared to the three and

[0001445305-14-001932:mdna:35]
nine months ended March 31, 2013, respectively. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates appropriately.

[0001445305-14-001932:mdna:36]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units to lower of cost or market or for excess and obsolescence based upon the number of units that are unlikely to be sold based upon estimated demand for the following twelve months. This evaluation takes into account matters including expected demand, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $0.9 million and $2.4 million in the three and nine months ended March 31, 2014, respectively, and $2.4 million and $8.7 million in the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:mdna:37]
[same as prior period, unchanged from 0001445305-14-000277:mdna:38]

[0001445305-14-001932:mdna:38]
[same as prior period, unchanged from 0001445305-14-000277:mdna:39]

[0001445305-14-001932:mdna:39]
Stock-based compensation. We measure and recognize the compensation expense for all share-based awards made to employees and non-employee members of the Board of Directors including employee stock options and restricted stock awards based on estimated fair values. We are required to estimate the fair value of share-based awards on the date of grant. The value of awards that are ultimately expected to vest is recognized as an expense over the requisite service periods. Compensation expense for options and restricted stock awards granted to employees was $2.8 million and $8.2 million for the three and nine months ended March 31, 2014, respectively, and $2.9 million and $8.7 million for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:mdna:40]
As of March 31, 2014, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options granted since July 1, 2006 to employees and non-employee members of the Board of Directors, was $18.6 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.38 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001445305-14-001932:mdna:41]
[same as prior period, unchanged from 0001445305-14-000277:mdna:43]

[0001445305-14-001932:mdna:42]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on an analysis of the relevant peer companies’ post-vest termination rates and exercise behavior for the stock options granted prior to June 30, 2011. For stock options and restricted stock awards granted after June 30, 2011, expected term is based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and

[0001445305-14-001932:mdna:43]
revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001445305-14-001932:mdna:44]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001445305-14-001932:mdna:45]
In May 2012, we and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of March 31, 2014, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.

[0001445305-14-001932:mdna:46]
[same as prior period, unchanged from 0001445305-14-000277:mdna:47]

[0001445305-14-001932:mdna:47]
[same as prior period, unchanged from 0001445305-14-000277:mdna:48]

[0001445305-14-001932:mdna:48]
[same as prior period, unchanged from 0001445305-14-000277:mdna:49]

[0001445305-14-001932:mdna:49]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.7 |  |  | 86.0 |  |  | 84.7 |  |  | 86.4 |  |
| Gross profit | 15.3 |  |  | 14.0 |  |  | 15.3 |  |  | 13.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5.5 |  |  | 6.7 |  |  | 5.9 |  |  | 6.6 |  |
| Sales and marketing | 2.5 |  |  | 3.1 |  |  | 2.6 |  |  | 3.0 |  |
| General and administrative | 1.6 |  |  | 2.2 |  |  | 1.6 |  |  | 2.2 |  |
| Total operating expenses | 9.6 |  |  | 12.0 |  |  | 10.1 |  |  | 11.8 |  |
| Income from operations | 5.7 |  |  | 2.0 |  |  | 5.2 |  |  | 1.8 |  |
| Interest and other income, net | — |  |  | — |  |  | — |  |  | — |  |
| Interest expense | — |  |  | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Income before income tax provision | 5.7 |  |  | 1.9 |  |  | 5.1 |  |  | 1.7 |  |
| Income tax provision | 1.3 |  |  | (0.6 | ) |  | 1.5 |  |  | 0.2 |  |
| Net income | 4.4 | % |  | 2.5 | % |  | 3.6 | % |  | 1.5 | % |

[0001445305-14-001932:mdna:50]
Comparison of Three Months Ended March 31, 2014 and 2013

[0001445305-14-001932:mdna:51]
Net sales. Net sales increased by $95.7 million, or 34.4%, to $373.8 million from $278.0 million, for the three months ended March 31, 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of server systems and subsystems and accessories as we sold more higher density server systems on a processing compute basis.

[0001445305-14-001932:mdna:52]
For the three months ended March 31, 2014, the number of server system units sold increased 33.3% to 72,000 compared to 54,000 for the three months ended March 31, 2013. The average selling price of server system units increased 23.8% to $2,600 in the three months ended March 31, 2014 compared to $2,100 in the three months ended March 31, 2013. The average selling prices of our server systems increased primarily due to higher average selling prices of complete integrated-high-end server solutions particularly to internet data center customers, the Twin family of servers, especially the FatTwin, storage and GPU/Xeon Phi servers which offered higher density computing and more CPU, memory and hard disk drive capacity. Sales of server systems increased by $71.1 million or 61.2% from the three months ended March 31, 2013 to the three months ended March 31, 2014, primarily due to the increased sales of the products described above. In addition, our new server products based on Intel's Ivy Bridge processor, which was launched in September 2013, also contributed to our growth in server systems sales in the three months ended March 31, 2014. Sales of server systems represented 50.1% of our net sales for the three months ended March 31, 2014 compared to 41.8% of our net sales for the three months ended March 31, 2013.

[0001445305-14-001932:mdna:53]
For the three months ended March 31, 2014, the number of subsystems and accessories units sold increased 0.5% to 1,116,000 compared to 1,111,000 for the three months ended March 31, 2013. Sales of subsystems and accessories increased by $24.6 million or 15.2% from the three months ended March 31, 2013 to the three months ended March 31, 2014, primarily related to higher sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who purchased additional accessories from us prior to completing the final assembly themselves. Sales of subsystems and accessories represented 49.9% of our net sales for the three months ended March 31, 2014 as compared to 58.2% of our net sales for the three months ended March 31, 2013.

[0001445305-14-001932:mdna:54]
For the three months ended March 31, 2014 and 2013, we derived 51.9% and 58.8%, respectively, of our net sales from products sold to distributors and we derived 48.1% and 41.2%, respectively, from sales to OEMs and to end customers. For the three months ended March 31, 2014, customers in the United States, Europe and Asia accounted for 54.5%, 21.7% and 21.0% of our net sales, respectively, as compared to 56.6%, 22.0% and 19.0%, respectively, for the three months ended March 31, 2013.

[0001445305-14-001932:mdna:55]
Cost of sales. Cost of sales increased by $77.4 million, or 32.3%, to $316.5 million from $239.1 million, for the three months ended March 31, 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 84.7% and 86.0% for the three months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales partially offset by a decrease of $1.5 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to an increase in purchasing power, a lower provision for inventory reserve, an increase in the mix of server system sales and higher utilization of our manufacturing facilities in Taiwan, offset by higher sales to internet data center customers, which generally have a lower gross margin. In the three months ended March 31, 2014, we recorded a $0.9 million expense or 0.2% of net sales related to the inventory provision as compared to $2.4 million, or 0.9% of net sales, in the three months ended March 31, 2013. The decrease in the inventory provision was primarily due to lower inventory reserves for special items as we have improved our processes and reduced our excess and slow moving inventory. In the three months ended March 31, 2014, we recorded a $3.5 million expense, or 0.9% of net sales, related to the provision for warranty reserve as compared to $3.1 million, or 1.1% of net sales, in the three months ended March 31, 2013. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the three months ended March 31, 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001445305-14-001932:mdna:56]
Research and development expenses. Research and development expenses increased by $2.0 million, or 10.6%, to $20.6 million from $18.6 million, for the three months ended March 31, 2014 and 2013, respectively. Research and development expenses were 5.5% and 6.7% of net sales for the three months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $2.4 million in compensation and benefits resulting from an annual salary increase and growth in research and development personnel related to expanded product development initiatives in the United States and in Taiwan. This increase was partially offset by an increase of $0.9 million in non-recurring engineering funding from certain suppliers and customers. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:57]
Research and development expenses include stock-based compensation expense of $1.7 million for both three months ended March 31, 2014 and 2013.

[0001445305-14-001932:mdna:58]
Sales and marketing expenses. Sales and marketing expenses increased by $0.7 million, or 8.1%, to $9.4 million from $8.7 million, for the three months ended March 31, 2014 and 2013, respectively. Sales and marketing expenses were 2.5% and 3.1% of net sales for the three months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $0.4 million in compensation and benefits resulting from growth in sales and marketing personnel. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:59]
Sales and marketing expenses include stock-based compensation expense of $0.3 million and $0.4 million for the three months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:60]
General and administrative expenses. General and administrative expenses decreased by $0.3 million, or 5.3%, to $5.8 million from $6.1 million, for the three months ended March 31, 2014 and 2013, respectively. General and administrative expenses were 1.6% and 2.2% of net sales for the three months ended March 31, 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to a decrease of $0.3 million in bad debt expense. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:61]
General and administrative expenses include stock-based compensation expense of $0.5 million and $0.6 million for three months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:62]
Interest and other expense, net. Interest and other expense, net was $0.1 million for both three months ended March 31, 2014 and 2013, which included $0.2 million and $0.1 million of interest expense for both three months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:63]
Provision for (benefit from) income taxes. Provision for income taxes increased by $6.5 million, or 373.1%, to $4.8 million from $(1.7) million, for the three months ended March 31, 2014 and 2013, respectively. The effective tax rate was 22.3% and (32.8)% for the three months ended March 31, 2014 and 2013, respectively. The higher income tax provision and effective tax rate for the three months ended March 31, 2014 were primarily attributable to our higher operating income and the expiration of the U.S. federal research and development credit on December 31, 2013. The higher income tax benefit and lower effective tax rate for the three months ended March 31, 2013 were primarily attributable to our lower operating income, a tax benefit of $2.9 million related to the reinstatement of the U.S. federal research and development tax credit, of which $2.3

[0001445305-14-001932:mdna:64]
million related to calendar year 2012, and the recognition of $2.0 million related to our resolution of IRS audits for all outstanding items covering fiscal year 2008 through 2010.

[0001445305-14-001932:mdna:65]
Comparison of Nine Months Ended March 31, 2014 and 2013

[0001445305-14-001932:mdna:66]
Net sales. Net sales increased by $198.9 million, or 23.7%, to $1,039.1 million from $840.2 million, for the nine months ended March 31, 2014 and 2013, respectively. This increase was due primarily to an increase in the average selling price of our server systems and to a lesser extent an increase in unit volumes of subsystems and accessories and server systems as we sold more higher density server systems on a processing compute basis.

[0001445305-14-001932:mdna:67]
For the nine months ended March 31, 2014, the number of server system units sold increased 12.4% to 190,000 compared to 169,000 for the nine months ended March 31, 2013. The average selling price of server system units increased 28.6% to $2,700 in the nine months ended March 31, 2014 compared to $2,100 in the nine months ended March 31, 2013. The average selling prices of our server systems increased primarily due to higher average selling prices of our complete integrated-high-end servers solutions to OEM and end customers, the Twin family of servers, storage and GPU/Xeon Phi servers which offered higher density computing and more memory and hard disk drive capacity. Sales of server systems increased by $155.5 million or 44.5% from the nine months ended March 31, 2013 to the nine months ended March 31, 2014, primarily due to the increased sales of the products described above. In addition, our new server products based on Intel's Ivy Bridge processor, which was launched in September 2013, also contributed to our growth in server system sales in the nine months ended March 31, 2014. Sales of server systems represented 48.6% of our net sales for the nine months ended March 31, 2014, compared to 41.6% of our net sales for the nine months ended March 31, 2013.

[0001445305-14-001932:mdna:68]
For the nine months ended March 31, 2014, the number of subsystems and accessories units sold increased 3.4% to 3,345,000 compared to 3,234,000 for the nine months ended March 31, 2013. Sales of subsystems and accessories increased by $43.4 million or 8.8% from the nine months ended March 31, 2013 to the nine months ended March 31, 2014, primarily related to higher sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who purchased additional accessories from us prior to completing the final assembly themselves. Sales of subsystems and accessories represented 51.4% of our net sales for the nine months ended March 31, 2014 as compared to 58.4% of our net sales for the nine months ended March 31, 2013.

[0001445305-14-001932:mdna:69]
For the nine months ended March 31, 2014 and 2013, we derived 55.1% and 56.2% of our net sales from products sold to distributors, respectively, and we derived 44.9% and 43.8%, respectively, from sales to OEMs and to end customers. For the nine months ended March 31, 2014, customers in the United States, Europe and Asia accounted for 53.7%, 22.8% and 20.7% of our net sales, respectively, as compared to 53.4%, 22.8% and 21.2%, respectively, for the nine months ended March 31, 2013.

[0001445305-14-001932:mdna:70]
Cost of sales. Cost of sales increased by $153.8 million, or 21.2%, to $880.0 million from $726.2 million, for the nine months ended March 31, 2014 and 2013, respectively. Cost of sales as a percentage of net sales was 84.7% and 86.4% for the nine months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars of cost of sales was primarily attributable to the increase in net sales partially offset by a decrease of $6.3 million in provision for inventory reserve. The lower cost of sales as a percentage of net sales was primarily due to a lower provision for inventory reserve, an increase in purchasing power, an increase in the mix of server system sales and higher utilization of our manufacturing facilities in Taiwan, offset by higher sales to internet data center customers, which generally have a lower gross margin. In the nine months ended March 31, 2014, we recorded a $2.4 million expense, or 0.2% of net sales, related to the inventory provision as compared to $8.7 million, or 1.0% of net sales, in the nine months ended March 31, 2013. The decrease in the inventory provision was primarily due to lower inventory reserves for special items and higher sales of previously reserved inventory as we have improved our processes and reduced our excess and slow moving inventory. In the nine months ended March 31, 2014, we recorded a $10.5 million expense, or 1.0% of net sales, related to the provision for warranty reserve as compared to $9.5 million, or 1.1% of net sales, in the nine months ended March 31, 2013. The increase in the provision for warranty reserve was primarily due to higher cost of servicing warranty claims from higher net sales in the nine months ended March 31, 2014. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001445305-14-001932:mdna:71]
Research and development expenses. Research and development expenses increased by $5.6 million, or 10.0%, to $61.2 million from $55.7 million, for the nine months ended March 31, 2014 and 2013, respectively. Research and development expenses were 5.9% and 6.6% of net sales for the nine months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $5.3 million in compensation and benefits resulting from an annual salary increase and growth in research and development personnel related to expanded product development initiatives

[0001445305-14-001932:mdna:72]
in the United States and in Taiwan and an increase of $1.7 million in development expenses for prototype materials and testing associated with new product introductions, particularly related to the introduction of new products including servers based on Intel's Ivy Bridge processor, TwinPro, UltraTwin and MicroBlade series of servers. This increase was partially offset by an increase of $1.0 million in non-recurring engineering funding from certain suppliers and customers. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:73]
Research and development expenses include stock-based compensation expense of $5.0 million and $4.9 million for the nine months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:74]
Sales and marketing expenses. Sales and marketing expenses increased by $1.8 million, or 7.2%, to $27.3 million from $25.4 million, for the nine months ended March 31, 2014 and 2013, respectively. Sales and marketing expenses were 2.6% and 3.0% of net sales for the nine months ended March 31, 2014 and 2013, respectively. The increase in absolute dollars was primarily due to an increase of $1.3 million in compensation and benefits resulting from growth in sales and marketing personnel. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:75]
Sales and marketing expenses include stock-based compensation expense of $0.9 million and $1.2 million for the nine months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:76]
General and administrative expenses. General and administrative expenses decreased by $1.3 million, or 7.1%, to $16.9 million from $18.2 million, for the nine months ended March 31, 2014 and 2013, respectively. General and administrative expenses were 1.6% and 2.2% of net sales for the nine months ended March 31, 2014 and 2013, respectively. The decrease in absolute dollars was primarily due to an increase of $0.7 million in miscellaneous income relating to the settlement of our outstanding accounts payable with one vendor, a decrease of $0.6 million resulting from payroll tax audit assessment in fiscal year 2013 and a decrease of $0.6 million in audit/tax and other professional service fees, offset in part by an increase of $0.7 million in bad debt expenses. The decrease as a percentage of net sales was primarily due to the significant increase in net sales during the period.

[0001445305-14-001932:mdna:77]
General and administrative expenses include stock-based compensation expense of $1.5 million and $1.9 million for the nine months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:78]
Interest and other expense, net. Interest and other expense, net was $0.5 million and $0.4 million for the nine months ended March 31, 2014 and 2013, respectively, which included $0.5 million and $0.4 million of interest expense for the nine months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:79]
Provision for income taxes. Provision for income taxes increased by $14.2 million, to $15.6 million from $1.5 million, for the nine months ended March 31, 2014 and 2013, respectively. The effective tax rate was 29.4% and 10.2% for the nine months ended March 31, 2014 and 2013, respectively. The higher of provision for income taxes and effective tax rate for the nine months ended March 31, 2014 were primarily attributable to our higher operating income and the expiration of the U.S. federal research and development tax credit on December 31, 2013. The lower of provision for income taxes and effective tax rate for the nine months ended March 31, 2013 were primarily attributable to our lower operating income, a tax benefit of $2.9 million related to the reinstatement of the U.S. federal research and development tax credit, of which $2.3 million related to calendar year 2012, and the recognition of $2.0 million related to our resolution of IRS audits for all outstanding items covering fiscal year 2008 through 2010.

[0001445305-14-001932:mdna:80]
[same as prior period, unchanged from 0001445305-14-000277:mdna:81]

[0001445305-14-001932:mdna:81]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have, from time to time, utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $101.8 million and $93.1 million as of March 31, 2014 and June 30, 2013, respectively. Our cash in foreign locations was $28.9 million and $16.6 million at March 31, 2014 and June 30, 2013, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001445305-14-001932:mdna:82]
Operating Activities. Net cash provided by operating activities was $12.5 million and $13.6 million for the nine months ended March 31, 2014 and 2013, respectively.

[0001445305-14-001932:mdna:83]
Net cash provided by our operating activities for the nine months ended March 31, 2014 was primarily due to our net income of $37.6 million, an increase in accounts payable of $32.5 million, an increase in net income tax payable of $9.9 million, stock-based compensation expense of $8.2 million and depreciation expense of $4.6 million, which were partially offset by an increase in inventory of $43.3 million and an increase in accounts receivable of $34.1 million.

[0001445305-14-001932:mdna:84]
Net cash provided by our operating activities for the nine months ended March 31, 2013 was primarily due to our net income of $12.9 million, a decrease in inventory of $10.5 million, provision for inventory of $8.7 million, stock-based compensation expense of $8.7 million, depreciation expense of $5.9 million, an increase in accrued liabilities of $3.3 million and an increase in net income taxes payable of $1.9 million, which were partially offset by an increase in accounts receivable of $21.0 million, a decrease in accounts payable of $9.6 million, an increase in deferred income taxes of $6.2 million and excess tax benefits from stock-based compensation of $0.8 million.

[0001445305-14-001932:mdna:85]
The increase for the nine months ended March 31, 2014 in accounts receivable was primarily due to an increase in our sales late in the third quarter. The increase for the nine months ended March 31, 2014 in accounts payable was due to higher purchases and timing of payments to our vendors. The increase for the nine months ended March 31, 2014 in inventory was due to support the anticipated level of growth in net sales in fiscal year 2014. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001445305-14-001932:mdna:86]
The increase for the nine months ended March 31, 2013 in accounts receivable was primarily due to an increase in sales late in the third quarter and an increase in sales with longer payment term. The decrease for the nine months ended March 31, 2013 in accounts payable was due to timing of payments to our vendors. The decrease for the nine months ended March 31, 2013 in inventory was in part due to increased sales in hard disk drives and memory as we have aggressively promoted hard disk drives and memory bundling with server solutions.

[0001445305-14-001932:mdna:87]
Investing activities. Net cash used in our investing activities was $36.4 million and $4.5 million for the nine months ended March 31, 2014 and 2013, respectively. In the nine months ended March 31, 2014, $36.8 million was related to the purchase of property, plant and equipment including $30.2 million related to the real property purchased in San Jose, California in October 2013, offset in part by the termination of the certificates of deposits for $0.4 million, which were pledged as security for value added tax examination required by tax authority of Taiwan. In the nine months ended March 31, 2013, $4.3 million was related to the purchase of property, plant and equipment and $0.4 million was related to certificates of deposits pledged as security for value added tax examination required by tax authority of Taiwan, offset in part by the redemption at par of investments in auction rate securities of $0.3 million.

[0001445305-14-001932:mdna:88]
Financing activities. Net cash provided by our financing activities was $32.9 million and $4.1 million for the nine months ended March 31, 2014 and 2013, respectively. In the nine months ended March 31, 2014, we received $19.2 million

[0001445305-14-001932:mdna:89]
related to proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding mainly on behalf of one executive officer for his restricted stock awards of $0.7 million for the nine months ended March 31, 2014. Further, we borrowed an additional $6.8 million under the line of credit from Bank of America, borrowed $7.1 million from the CTBC Bank secured term loan, and borrowed $3.5 million of our CTBC Bank revolving line of credit and repaid $5.6 million in loans in the nine months ended March 31, 2014. In the nine months ended March 31, 2014, excess tax benefits from stock-based compensation were $2.7 million.

[0001445305-14-001932:mdna:90]
In the nine months ended March 31, 2013, we received $1.4 million of proceeds from the exercise of stock options. We withheld shares and paid the minimum tax withholding on behalf of one executive officer for his restricted stock awards of $1.0 million for the nine months ended March 31, 2013. Further, we borrowed $15.0 million under a new term loan from China Trust Bank, borrowed $5.6 million of our revolving line of credit from Bank of America and repaid $17.4 million in loans in the nine months ended March 31, 2013. In the nine months ended March 31, 2013, excess tax benefits from stock-based compensation were $0.8 million.

[0001445305-14-001932:mdna:91]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001445305-14-001932:mdna:92]
29

[0001445305-14-001932:mdna:93]
[same as prior period, unchanged from 0001445305-14-000277:mdna:93]

[0001445305-14-001932:mdna:94]
[same as prior period, unchanged from 0001445305-14-000277:mdna:94]

[0001445305-14-001932:mdna:95]
[same as prior period, unchanged from 0001445305-14-000277:mdna:95]

[0001445305-14-001932:mdna:96]
In October 2011, we entered into an amendment to the existing credit agreement with Bank of America, which provided for (i) a $40.0 million revolving line of credit facility through June 15, 2013 and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit to August 15, 2014.

[0001445305-14-001932:mdna:97]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at March 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001445305-14-001932:mdna:98]
As of March 31, 2014 and June 30, 2013, the total outstanding borrowings under the Bank of America term loan was $7.2 million and $9.3 million, respectively. The total outstanding borrowings under the Bank of America line of credit was $17.7 million as of March 31, 2014 and $10.9 million as of June 30, 2013. The interest rates for these loans ranged from 1.19% to 1.65% per annum at March 31, 2014 and ranged from 1.23% to 1.69% per annum at June 30, 2013, respectively. As of March 31, 2014, the unused revolving line of credit under Bank of America was $22.3 million.

[0001445305-14-001932:mdna:99]
[same as prior period, unchanged from 0001445305-14-000277:mdna:99]

[0001445305-14-001932:mdna:100]
In October 2011, we obtained an unsecured revolving line of credit from CTBC Bank totaling NT$300.0 million, or $9.9 million U.S. dollar equivalents. In July 2012, we increased the credit line to a NT$450.0 million, or $14.9 million U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate at the lender's established interest rate plus 0.3% which is adjusted monthly.

[0001445305-14-001932:mdna:101]
In November 2013, we entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700.0 million or $23.8 million U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100.0 million or $3.4 million U.S. dollar equivalents, and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500.0 million or $17.0 million U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1.0 billion or $34.0 million U.S. dollar equivalents.

[0001445305-14-001932:mdna:102]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21.6 million and $14.9 million at March 31, 2014 and June 30, 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at March 31, 2014 and June 30, 2013. The interest rate for the loan was at 1.13% per annum at March 31, 2014 and was at 1.20% per annum at June 30, 2013. At March 31, 2014, NT$340.0 million or $11.1 million U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001445305-14-001932:mdna:103]
Covenant Compliance

[0001445305-14-001932:mdna:104]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001445305-14-001932:mdna:105]
[same as prior period, unchanged from 0001445305-14-000277:mdna:105]

[0001445305-14-001932:mdna:106]
[same as prior period, unchanged from 0001445305-14-000277:mdna:106]

[0001445305-14-001932:mdna:107]
[same as prior period, unchanged from 0001445305-14-000277:mdna:107]

[0001445305-14-001932:mdna:108]
As of March 31, 2014 and June 30, 2013, our total assets of $705.5 million and $586.7 million, respectively, collateralized the line of credit with Bank of America and were all of our assets except for the three buildings located in San Jose, California and the land and building located in Bade, Taiwan. As of March 31, 2014 and June 30, 2013, total assets collateralizing the term loan with Bank of America were $17.6 million and $17.8 million, respectively. As of March 31, 2014, we were in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001445305-14-001932:mdna:109]
As of March 31, 2014 and June 30, 2013, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27.4 million and $27.7 million, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2014.

[0001445305-14-001932:mdna:110]
[same as prior period, unchanged from 0001445305-14-000277:mdna:110]

[0001445305-14-001932:mdna:111]
For the three and nine months ended March 31, 2014, we paid our contract manufacturers within 61 to 75 days of invoice and Ablecom between 50 to 96 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of March 31, 2014 and June 30, 2013 amounts owed to Ablecom by us were approximately $42.2 million and $50.4 million, respectively.

[0001445305-14-001932:mdna:112]
[same as prior period, unchanged from 0001445305-14-000277:mdna:112]

[0001445305-14-001932:mdna:113]
As of March 31, 2014, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AAA or AA2 at March 31, 2014. These auction rate preferred shares have no stated maturity date.

[0001445305-14-001932:mdna:114]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2014, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at March 31, 2014, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. During the three and nine months ended March 31, 2014, there were no auction rate securities redeemed or sold. During the three and nine months ended March 31, 2013, $0 and $0.3 million of the auction rate securities were redeemed at par, respectively.

[0001445305-14-001932:mdna:115]
[same as prior period, unchanged from 0001445305-14-000277:mdna:115]

[0001445305-14-001932:mdna:116]
The following table describes our contractual obligations as of March 31, 2014:

[0001445305-14-001932:mdna:117]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 3,474 |  |  | $ | 1,947 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,421 |  |
| Capital leases, including interest | 69 |  |  | 129 |  |  | 99 |  |  | — |  |  | 297 |  |
| Short-term and Long-term debt, including interest (1) | 42,237 |  |  | 4,499 |  |  | — |  |  | — |  |  | 46,736 |  |
| License arrangements | 600 |  |  | — |  |  | — |  |  | — |  |  | 600 |  |
| Purchase commitments (2) | 271,106 |  |  | 103 |  |  | — |  |  | — |  |  | 271,209 |  |
| Total | $ | 317,486 |  |  | $ | 6,678 |  |  | $ | 99 |  |  | $ | — |  |  | $ | 324,263 |  |

[0001445305-14-001932:mdna:118]
[same as prior period, unchanged from 0001445305-14-000277:mdna:118]

[0001445305-14-001932:mdna:119]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at March 31, 2014. |

[0001445305-14-001932:mdna:120]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $72.4 million of hard disk drive purchase commitments at March 31, 2014, which will be paid through December 2014. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001445305-14-001932:mdna:121]
The table above excludes liabilities for deferred revenue for warranty and on-site services of $4.1 million and unrecognized tax benefits and related interest and penalties accrual of $8.7 million as of March 31, 2014. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due.

[0001445305-14-001932:mdna:122]
[same as prior period, unchanged from 0001445305-14-000277:mdna:122]

[0001445305-14-001932:mdna:123]
[same as prior period, unchanged from 0001445305-14-000277:mdna:123]

[0001445305-14-001932:mdna:124]
[same as prior period, unchanged from 0001445305-14-000277:mdna:124]

[0001445305-14-001932:mdna:125]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. We are currently reviewing the provisions but do not expect it to have a material impact on our financial statement disclosures, results of operations or financial position.

[0001445305-14-001932:mdna:126]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. We currently plan to adopt the new disclosure requirement on July 1, 2014. We do not believe the adoption of this guidance will have a material impact on our financial statement disclosure, results of operations or financial position.

[0001445305-14-001932:mdna:127]
[same as prior period, unchanged from 0001445305-14-000277:mdna:126]

[0001445305-14-001932:mdna:128]
[same as prior period, unchanged from 0001445305-14-000277:mdna:127]
