# SMCI notes — 0001445305-14-001932


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-14-001932:notes:1]
Commitments and Contingencies

[0001445305-14-001932:notes:2]
Litigation and Claims — The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s condensed consolidated financial condition, results of operations or liquidity.

[0001445305-14-001932:notes:3]
Purchase Commitments — The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of March 31, 2014, these remaining non-cancellable commitments were $271,209,000 compared to $249,005,000 at June 30, 2013. The increase was primarily due to support the growth of the Company's revenue.

[0001445305-14-001932:notes:4]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $72,395,000, which will be paid through December 2014. The Company entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001445305-14-001932:notes:5]
[same as prior period, unchanged from 0001445305-14-000277:notes:5]

[0001445305-14-001932:notes:6]
[same as prior period, unchanged from 0001445305-14-000277:notes:6]

[0001445305-14-001932:notes:7]
[same as prior period, unchanged from 0001445305-14-000277:notes:7]

[0001445305-14-001932:notes:8]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2014.

[0001445305-14-001932:notes:9]
As of March 31, 2014, the Company contributed $168,000 and owned a 50% interest in Super Micro Business Park, Inc. ("Management Company") in Taiwan. The Management Company was established to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. The Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. Therefore, the accounts of the Management Company have been consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income(loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations


## us-gaap:DebtDisclosureTextBlock

[0001445305-14-001932:notes:10]
Short-term and Long-term Obligations

[0001445305-14-001932:notes:11]
Short-term and long-term obligations as of March 31, 2014 and June 30, 2013 consisted of the following (in thousands):

[0001445305-14-001932:notes:12]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,233 |  |  | 9,333 |  |
| CTBC Bank | 21,631 |  |  | 14,939 |  |
| Total building term loans | 28,864 |  |  | 24,272 |  |
| Total debt | 46,563 |  |  | 35,171 |  |
| Current portion | (42,130 | ) |  | (28,638 | ) |
| Long-term portion | $ | 4,433 |  |  | $ | 6,533 |  |

[0001445305-14-001932:notes:13]
Activities under Revolving Lines of Credit and Term Loans

[0001445305-14-001932:notes:14]
Bank of America

[0001445305-14-001932:notes:15]
In October 2011, the Company entered into an amendment to the existing credit agreement with Bank of America, N.A. ("Bank of America") which provided for (i) a $40,000,000 revolving line of credit facility that matured on June 15, 2013 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. The credit agreement was subsequently amended to extend the maturity date of the revolving line of credit facility to August 15, 2014.

[0001445305-14-001932:notes:16]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at March 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001445305-14-001932:notes:17]
As of March 31, 2014 and June 30, 2013, the total outstanding borrowings under the Bank of America term loan was $7,233,000 and $9,333,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $17,699,000 as of March 31, 2014 and $10,899,000 as of June 30, 2013, respectively. The interest rates for these loans ranged from 1.19% to 1.65% per annum at March 31, 2014 and 1.23% to 1.69% per annum at June 30, 2013, respectively. As of March 31, 2014, the unused revolving line of credit with Bank of America was $22,301,000.

[0001445305-14-001932:notes:18]
CTBC Bank

[0001445305-14-001932:notes:19]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000, or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which was adjusted monthly.

[0001445305-14-001932:notes:20]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established New Taiwan Dollar ("NTD") interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.

[0001445305-14-001932:notes:21]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,631,000 and $14,939,000 at March 31, 2014 and June 30, 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at March 31, 2014 and June 30, 2013. The interest rate for the loan was at 1.13% per annum at March 31, 2014 and was at 1.20% per annum at June 30, 2013. At March 31, 2014, NT$340,000,000 or $11,143,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

[0001445305-14-001932:notes:22]
Covenant Compliance

[0001445305-14-001932:notes:23]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001445305-14-001932:notes:24]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001445305-14-001932:notes:25]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001445305-14-001932:notes:26]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001445305-14-001932:notes:27]
As of March 31, 2014 and June 30, 2013, total assets of $705,506,000 and $586,742,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings located in San Jose, California and the land and building located in Bade, Taiwan. As of March 31, 2014 and June 30, 2013, total assets collateralizing the term loan with Bank of America were $17,641,000 and $17,813,000, respectively. As of March 31, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001445305-14-001932:notes:28]
As of March 31, 2014 and June 30, 2013, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,394,000 and $27,702,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-14-001932:notes:29]
[same as prior period, unchanged from 0001445305-14-000277:notes:29]

[0001445305-14-001932:notes:30]
[same as prior period, unchanged from 0001445305-14-000277:notes:30]

[0001445305-14-001932:notes:31]
In January 2011, the Board of Directors approved an amendment to the 2006 Equity Incentive Plan (the “2006 Plan”) that increased by 2,000,000 the aggregate maximum number of shares that may be issued under the 2006 Plan. The amendment to the 2006 Plan was approved by the Company’s stockholders in February 2011. The authorized number of shares that may be issued under the 2006 Plan automatically increases on July 1 each year through 2016, by an amount equal to (a) 3.0% of shares of stock issued and outstanding on the immediately preceding June 30, or (b) a lesser amount determined by the Board of Directors. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant and options vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of March 31, 2014, the Company had 777,248 authorized shares available for future issuance under the 2006 Plan.

[0001445305-14-001932:notes:32]
[same as prior period, unchanged from 0001445305-14-000277:notes:32]

[0001445305-14-001932:notes:33]
Restricted stock awards are share awards that provide the rights to a set number of shares of the Company’s stock on the grant date. In August 2008, the Compensation Committee of the Board of Directors of the Company (the “Committee”) approved the terms of an agreement (the “Option Exercise Agreement”) with Charles Liang, a director and President and Chief Executive Officer of the Company, pursuant to which Mr. Liang exercised a fully vested option previously granted to him for the purchase of 925,000 shares. The option was exercised using a “net-exercise” procedure in which he was issued a number of shares representing the spread between the option exercise price and the then current market value of the shares subject to the option (898,205 shares based upon the market value as of the date of exercise). The shares issued upon exercise of the option are subject to vesting over five years. Vesting of the shares subject to the award may accelerate in certain circumstances pursuant to the terms of the Option Exercise Agreement. The Company determined that there was no incremental fair value of the option exchanged for the award. 898,205 and 718,564 shares were vested as of March 31, 2014 and June 30, 2013, respectively.

[0001445305-14-001932:notes:34]
[same as prior period, unchanged from 0001445305-14-000277:notes:34]

[0001445305-14-001932:notes:35]
[same as prior period, unchanged from 0001445305-14-000277:notes:35]

[0001445305-14-001932:notes:36]
[same as prior period, unchanged from 0001445305-14-000277:notes:36]

[0001445305-14-001932:notes:37]
Expected Volatility—Expected volatility is based on a combination of the Company's implied and historical volatility.

[0001445305-14-001932:notes:38]
[same as prior period, unchanged from 0001445305-14-000277:notes:38]

[0001445305-14-001932:notes:39]
[same as prior period, unchanged from 0001445305-14-000277:notes:39]

[0001445305-14-001932:notes:40]
[same as prior period, unchanged from 0001445305-14-000277:notes:40]

[0001445305-14-001932:notes:41]
The fair value of stock option grants for the three and nine months ended March 31, 2014 and 2013 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001445305-14-001932:notes:42]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Risk-free interest rate | 1.69% - 1.81% |  |  | 0.80% - 0.90% |  |  | 1.53% - 1.81% |  |  | 0.65% - 0.90% |  |
| Expected life | 5.58 years |  |  | 5.14 years |  |  | 5.49 - 5.58 years |  |  | 5.03 - 5.14 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 43.48% - 44.66% |  |  | 51.27% - 51.49% |  |  | 43.48% - 50.07% |  |  | 51.27% - 51.57% |  |
| Weighted-average fair value | $ | 7.70 |  |  | $ | 3.92 |  |  | $ | 6.67 |  |  | $ | 4.56 |  |

[0001445305-14-001932:notes:43]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2014 and 2013 (in thousands):

[0001445305-14-001932:notes:44]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 246 |  |  | $ | 232 |  |  | $ | 726 |  |  | $ | 696 |  |
| Research and development | 1,723 |  |  | 1,666 |  |  | 4,993 |  |  | 4,928 |  |
| Sales and marketing | 306 |  |  | 389 |  |  | 925 |  |  | 1,182 |  |
| General and administrative | 531 |  |  | 563 |  |  | 1,539 |  |  | 1,856 |  |
| Stock-based compensation expense before taxes | 2,806 |  |  | 2,850 |  |  | 8,183 |  |  | 8,662 |  |
| Income tax impact | (1,477 | ) |  | (40 | ) |  | (2,146 | ) |  | (449 | ) |
| Stock-based compensation expense, net | $ | 1,329 |  |  | $ | 2,810 |  |  | $ | 6,037 |  |  | $ | 8,213 |  |

[0001445305-14-001932:notes:45]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash from financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash from operating activities. The Company had $4,533,000 and $1,687,000 of excess tax benefits accounted in the Company’s additional paid-in capital in the nine months ended March 31, 2014 and 2013, respectively. The Company had excess tax benefits that are classified as cash from financing activities of $2,719,000 and $844,000 in the nine months ended March 31, 2014 and 2013, respectively, for options issued since July 1, 2006. Excess tax benefits for stock options issued prior to July 1, 2006 continue to be classified as cash from operating activities.

[0001445305-14-001932:notes:46]
[same as prior period, unchanged from 0001445305-14-000277:notes:46]

[0001445305-14-001932:notes:47]
The following table summarizes stock option activity during the nine months ended March 31, 2014 under all stock option plans:

[0001445305-14-001932:notes:48]
|  |  | Number of Shares |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Outstanding at July 1, 2013 |  | 12,206,178 |  |  | $ | 10.83 |  |  | 6.23 |  | $ | 22,631 |  |
| Granted |  | 1,339,160 |  |  | 14.80 |  |  |  |  |  |
| Exercised |  | (2,103,534 | ) |  | 9.11 |  |  |  |  |  |
| Forfeited or cancelled |  | (211,489 | ) |  | 14.22 |  |  |  |  |  |
| Outstanding at March 31, 2014 |  | 11,230,315 |  |  | 11.57 |  |  | 6.12 |  | 67,169 |  |
| Options vested and expected to vest at March 31, 2014 |  | 10,965,812 |  |  | 11.50 |  |  | 6.05 |  | 66,292 |  |
| Options vested and exercisable at March 31, 2014 |  | 7,914,484 |  |  | $ | 10.44 |  |  | 5.05 |  | $ | 55,876 |  |

[0001445305-14-001932:notes:49]
The total pretax intrinsic value of options exercised was $14,746,000 and $19,961,000 for the three and nine months ended March 31, 2014, respectively, and $1,152,000 and $4,220,000 for the three and nine months ended March 31, 2013, respectively. As of March 31, 2014, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted since July 1, 2006 to employees and non-employee directors was $18,557,000, which will be recognized over a weighted-average vesting period of approximately 2.38 years.

[0001445305-14-001932:notes:50]
[same as prior period, unchanged from 0001445305-14-000277:notes:50]

[0001445305-14-001932:notes:51]
The following table summarizes the Company’s restricted stock award activity for the nine months ended March 31, 2014:

[0001445305-14-001932:notes:52]
|  | Restricted Stock Awards |
|  | Numberof Shares |  | WeightedAverageGrant DateFair ValuePer Share |
| Nonvested stock at July 1, 2013 | 179,641 |  |  | $ | 10.66 |  |
| Granted | 3,500 |  |  | 14.23 |  |
| Vested | (179,641 | ) |  | 10.66 |  |
| Forfeited | — |  |  | — |  |
| Nonvested stock at March 31, 2014 | 3,500 |  |  | $ | 14.23 |  |

[0001445305-14-001932:notes:53]
The total pretax intrinsic value of restricted stock awards vested was $0 and $2,337,000 for the three and nine months ended March 31, 2014, respectively, and $0 and $2,190,000 for the three and nine months ended March 31, 2013, respectively. In the nine months ended March 31, 2014 and 2013, upon vesting, 179,641 shares of restricted stock awards were partially net share-settled such that the Company withheld 50,000 and 83,857 shares, respectively, with value equivalent to an officer's minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the restricted stock awards on the vesting date as determined by the Company’s closing stock price. Total payments for an officer's tax obligations to the taxing authorities were $651,000 and $1,022,000 in the nine months ended March 31, 2014 and 2013, respectively, and are reflected as a financing activity within the condensed consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. The total intrinsic value of the outstanding restricted stock awards was $61,000 as of March 31, 2014.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-14-001932:notes:54]
[same as prior period, unchanged from 0001445305-14-000277:notes:54]

[0001445305-14-001932:notes:55]
[same as prior period, unchanged from 0001445305-14-000277:notes:55]


## us-gaap:EarningsPerShareTextBlock

[0001445305-14-001932:notes:56]
[same as prior period, unchanged from 0001445305-14-000277:notes:56]

[0001445305-14-001932:notes:57]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Basic net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 16,574 |  |  | $ | 7,040 |  |  | $ | 37,608 |  |  | $ | 12,853 |  |
| Less: Undistributed earnings allocated to participating securities | (1 | ) |  | (30 | ) |  | (34 | ) |  | (67 | ) |
| Net income attributable to common shares—basic | $ | 16,573 |  |  | $ | 7,010 |  |  | $ | 37,574 |  |  | $ | 12,786 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 43,992 |  |  | 42,147 |  |  | 43,128 |  |  | 41,901 |  |
| Basic net income per common share | $ | 0.38 |  |  | $ | 0.17 |  |  | $ | 0.87 |  |  | $ | 0.31 |  |
| Diluted net income per common share calculation |  |  |  |  |  |  |  |
| Net income | $ | 16,574 |  |  | $ | 7,040 |  |  | $ | 37,608 |  |  | $ | 12,853 |  |
| Less: Undistributed earnings allocated to participating securities | (1 | ) |  | (29 | ) |  | (32 | ) |  | (64 | ) |
| Net income attributable to common shares—diluted | $ | 16,573 |  |  | $ | 7,011 |  |  | $ | 37,576 |  |  | $ | 12,789 |  |
| Weighted-average number of common shares used to compute basic net income per common share | 43,992 |  |  | 42,147 |  |  | 43,128 |  |  | 41,901 |  |
| Dilutive effect of options to purchase common stock | 3,432 |  |  | 2,001 |  |  | 2,729 |  |  | 2,020 |  |
| Weighted-average number of common shares used to compute diluted net income per common share | 47,424 |  |  | 44,148 |  |  | 45,857 |  |  | 43,921 |  |
| Diluted net income per common share | $ | 0.35 |  |  | $ | 0.16 |  |  | $ | 0.82 |  |  | $ | 0.29 |  |

[0001445305-14-001932:notes:58]
For the three and nine months ended March 31, 2014 and 2013, the Company had stock options outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The shares of common stock issuable upon exercise of such anti-dilutive outstanding stock options were 2,142,000 and 3,892,000 for the three and nine months ended March 31, 2014, respectively, and 6,551,000 and 6,076,000 for the three and nine months ended March 31, 2013, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001445305-14-001932:notes:59]
The following table sets forth the Company’s cash equivalents and long-term investments as of March 31, 2014 and June 30, 2013 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement, (in thousands):

[0001445305-14-001932:notes:60]
| March 31, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,637 |  |  | 2,637 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,637 |  |  | $ | 2,947 |  |
| June 30, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,637 |  |  | 2,637 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,637 |  |  | $ | 2,947 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001445305-14-001932:notes:61]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2014 and 2013 (in thousands):

[0001445305-14-001932:notes:62]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance as of beginning of period | $ | 2,637 |  |  | $ | 2,650 |  |  | $ | 2,637 |  |  | $ | 2,923 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |  | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |  | — |  |  | 27 |  |
| Sales and settlements at par | — |  |  | — |  |  | — |  |  | (300 | ) |
| Transfers in and/or out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 2,637 |  |  | $ | 2,650 |  |  | $ | 2,637 |  |  | $ | 2,650 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-001932:notes:63]
[same as prior period, unchanged from 0001445305-14-000277:notes:63]

[0001445305-14-001932:notes:64]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of March 31, 2014 and June 30, 2013. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001445305-14-001932:notes:65]
The above table excludes $101,171,000 and $92,495,000 of cash and $738,000 and $1,139,000 of certificates of deposit held by the Company as of March 31, 2014 and June 30, 2013, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and nine months ended March 31, 2014 and 2013.

[0001445305-14-001932:notes:66]
The following is a summary of the Company’s long-term investments as of March 31, 2014 and June 30, 2013 (in thousands):

[0001445305-14-001932:notes:67]
|  | March 31, 2014 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (113 | ) |  | $ | 2,637 |  |
|  | June 30, 2013 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (113 | ) |  | $ | 2,637 |  |

[0001445305-14-001932:notes:68]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2014 and June 30, 2013, short-term and long-term debt of $46,563,000 and $35,171,000, respectively, are reported at amortized cost. This outstanding debt is classified at Level 2 as they are not actively traded and are valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-001932:notes:69]
[same as prior period, unchanged from 0001445305-14-000277:notes:69]

[0001445305-14-001932:notes:70]
The Company recorded provisions for (benefits from) income taxes of $4,752,000 and $15,649,000 for the three and nine months ended March 31, 2014, respectively, and $(1,740,000) and $1,452,000 for the three and nine months ended March 31, 2013. The effective tax rate was 22.3% and 29.4% for the three and nine months ended March 31, 2014, respectively, and (32.8)% and 10.2% for the three and nine months ended March 31, 2013, respectively. The effective tax rates for three and nine months ended March 31, 2014 are estimated to be lower than the federal statutory rate primarily due to the benefit from disqualifying dispositions of shares issued upon exercise of incentive stock options and foreign tax credits, which are in part offset by an increase in state tax expenses.

[0001445305-14-001932:notes:71]
As of March 31, 2014, the Company had a liability for gross unrecognized tax benefits of $9,397,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three and nine months ended March 31, 2014, there were no material changes in the total amount of the liability for gross unrecognized tax benefits.

[0001445305-14-001932:notes:72]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2014, the Company had accrued $780,000 of interest and penalties relating to unrecognized tax benefits.

[0001445305-14-001932:notes:73]
[same as prior period, unchanged from 0001445305-14-000277:notes:73]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-001932:notes:74]
Adoption of New Accounting Pronouncements

[0001445305-14-001932:notes:75]
In February 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance associated with reporting of amounts reclassified out of accumulated other comprehensive income, which requires companies to present significant reclassifications out of accumulated other comprehensive income in their entirety in the statement of operations or in a separate footnote to the financial statements. For amounts that are not required to be reclassified in their entirety to net income, the standard requires companies to cross-reference to related footnoted disclosures. The new disclosure requirements are effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2012 and early adoption is permitted. The adoption of this guidance did not have a material impact on the Company's financial statement disclosures, results of operations or financial position.

[0001445305-14-001932:notes:76]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. The Company is currently reviewing the provisions but does not expect it to have a material impact on the Company’s financial statement disclosures, results of operations or financial position.

[0001445305-14-001932:notes:77]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company currently plans to adopt the new disclosure requirement on July 1, 2014. The Company does not believe the adoption of this guidance will have a material impact on its financial statement disclosures, results of operations or financial position.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001445305-14-001932:notes:78]
[same as prior period, unchanged from 0001445305-14-000277:notes:77]

[0001445305-14-001932:notes:79]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Land | $ | 63,958 |  |  | $ | 41,774 |  |
| Buildings | 51,959 |  |  | 43,979 |  |
| Building and leasehold improvements | 7,632 |  |  | 7,483 |  |
| Machinery and equipment | 32,978 |  |  | 26,941 |  |
| Furniture and fixtures | 5,119 |  |  | 4,731 |  |
| Purchased software | 5,547 |  |  | 5,380 |  |
|  | 167,193 |  |  | 130,288 |  |
| Accumulated depreciation and amortization | (38,689 | ) |  | (34,376 | ) |
| Property, plant and equipment, net | $ | 128,504 |  |  | $ | 95,912 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001445305-14-001932:notes:80]
Related-party and Other Transactions

[0001445305-14-001932:notes:81]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at March 31, 2014.

[0001445305-14-001932:notes:82]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001445305-14-001932:notes:83]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products. The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001445305-14-001932:notes:84]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001445305-14-001932:notes:85]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $45,398,000 and $145,139,000 and sold products to Ablecom totaling $3,418,000 and $10,805,000 for the three and nine months ended March 31, 2014, respectively. The Company purchased products from Ablecom totaling $44,765,000 and $132,704,000 and sold products to Ablecom totaling $3,600,000 and $9,390,000 for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:notes:86]
Amounts owed to the Company by Ablecom as of March 31, 2014 and June 30, 2013, were $469,000 and $974,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2014 and June 30, 2013, were $42,198,000 and $50,448,000, respectively. For the three and nine months ended March 31, 2014, the Company paid Ablecom the majority of invoiced dollars between 50 and 96 days of invoice. For the three and nine months ended March 31, 2014, the Company paid $2,187,000 and $5,923,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2013, the Company paid $531,000 and $3,398,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001445305-14-001932:notes:87]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $63,997,000 and $53,684,000 at March 31, 2014 and June 30, 2013, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001445305-14-001932:notes:88]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001445305-14-001932:notes:89]
[same as prior period, unchanged from 0001445305-14-000277:notes:88]

[0001445305-14-001932:notes:90]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Accrued payroll and related expenses | $ | 10,757 |  |  | $ | 12,084 |  |
| Customer prepayments | 3,727 |  |  | 4,134 |  |
| Accrued warranty costs | 6,921 |  |  | 6,472 |  |
| Accrued cooperative marketing expenses | 4,095 |  |  | 4,016 |  |
| Others | 6,872 |  |  | 7,416 |  |
| Total accrued liabilities | $ | 32,372 |  |  | $ | 34,122 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001445305-14-001932:notes:91]
[same as prior period, unchanged from 0001445305-14-000277:notes:90]

[0001445305-14-001932:notes:92]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 187,282 |  |  | 50.1 | % |  | $ | 116,209 |  |  | 41.8 | % |  | $ | 504,637 |  |  | 48.6 | % |  | $ | 349,175 |  |  | 41.6 | % |
| Subsystems and accessories | 186,473 |  |  | 49.9 | % |  | 161,825 |  |  | 58.2 | % |  | 534,496 |  |  | 51.4 | % |  | 491,053 |  |  | 58.4 | % |
| Total | $ | 373,755 |  |  | 100.0 | % |  | $ | 278,034 |  |  | 100.0 | % |  | $ | 1,039,133 |  |  | 100.0 | % |  | $ | 840,228 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001445305-14-001932:notes:93]
The following tables provide details of the selected balance sheet items (in thousands):

[0001445305-14-001932:notes:94]
[same as prior period, unchanged from 0001445305-14-000277:notes:92]

[0001445305-14-001932:notes:95]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Finished goods | $ | 216,775 |  |  | $ | 185,459 |  |
| Work in process | 29,607 |  |  | 10,440 |  |
| Purchased parts and raw materials | 48,707 |  |  | 58,271 |  |
| Total inventory | $ | 295,089 |  |  | $ | 254,170 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001445305-14-001932:notes:96]
[same as prior period, unchanged from 0001445305-14-000277:notes:94]

[0001445305-14-001932:notes:97]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Prepaid royalty license | $ | 1,308 |  |  | $ | 1,496 |  |
| Restricted cash | 446 |  |  | 847 |  |
| Investment in a privately held company | 750 |  |  | 750 |  |
| Others | 311 |  |  | 148 |  |
| Total other assets | $ | 2,815 |  |  | $ | 3,241 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001445305-14-001932:notes:98]
[same as prior period, unchanged from 0001445305-14-000277:notes:96]

[0001445305-14-001932:notes:99]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance, beginning of period | $ | 6,822 |  |  | $ | 6,227 |  |  | $ | 6,472 |  |  | $ | 5,522 |  |
| Provision for warranty | 3,517 |  |  | 3,055 |  |  | 10,458 |  |  | 9,547 |  |
| Costs charged to accrual | (3,558 | ) |  | (2,963 | ) |  | (10,222 | ) |  | (9,020 | ) |
| Change in estimated liability for pre-existing warranties | 140 |  |  | (240 | ) |  | 213 |  |  | 30 |  |
| Balance, end of period | $ | 6,921 |  |  | $ | 6,079 |  |  | $ | 6,921 |  |  | $ | 6,079 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001445305-14-001932:notes:100]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2014 and 2013, of net sales by geographic region (in thousands):

[0001445305-14-001932:notes:101]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 203,638 |  |  | $ | 157,370 |  |  | $ | 558,423 |  |  | $ | 448,729 |  |
| Europe | 81,165 |  |  | 61,115 |  |  | 237,327 |  |  | 191,438 |  |
| Asia | 78,373 |  |  | 52,820 |  |  | 215,556 |  |  | 177,917 |  |
| Other | 10,579 |  |  | 6,729 |  |  | 27,827 |  |  | 22,144 |  |
|  | $ | 373,755 |  |  | $ | 278,034 |  |  | $ | 1,039,133 |  |  | $ | 840,228 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001445305-14-001932:notes:102]
[same as prior period, unchanged from 0001445305-14-000277:notes:100]

[0001445305-14-001932:notes:103]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Long-lived assets: |  |  |  |
| United States | $ | 91,713 |  |  | $ | 61,976 |  |
| Asia | 36,442 |  |  | 33,500 |  |
| Europe | 349 |  |  | 436 |  |
|  | $ | 128,504 |  |  | $ | 95,912 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-14-001932:notes:104]
[same as prior period, unchanged from 0001445305-14-000277:notes:102]

[0001445305-14-001932:notes:105]
[same as prior period, unchanged from 0001445305-14-000277:notes:103]

[0001445305-14-001932:notes:106]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories done by the Company. No customer represented greater than 10% of the Company’s total net sales nor did net sales in any country other than the United States represent greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2014 and 2013. No customer accounted for 10% or more of accounts receivable as of March 31, 2014. One customer accounted for 14.4% of the Company's accounts receivable as of June 30, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001445305-14-001932:notes:107]
[same as prior period, unchanged from 0001445305-14-000277:notes:105]

[0001445305-14-001932:notes:108]
[same as prior period, unchanged from 0001445305-14-000277:notes:106]

[0001445305-14-001932:notes:109]
[same as prior period, unchanged from 0001445305-14-000277:notes:107]

[0001445305-14-001932:notes:110]
As of March 31, 2014, the Company contributed $168,000 and owned a 50% interest in Super Micro Business Park, Inc. ("Management Company") in Taiwan. The Management Company was established to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. The Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. Therefore, the accounts of the Management Company have been consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income(loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.

[0001445305-14-001932:notes:111]
[same as prior period, unchanged from 0001445305-14-000277:notes:109]

[0001445305-14-001932:notes:112]
[same as prior period, unchanged from 0001445305-14-000277:notes:110]

[0001445305-14-001932:notes:113]
[same as prior period, unchanged from 0001445305-14-000277:notes:111]

[0001445305-14-001932:notes:114]
[same as prior period, unchanged from 0001445305-14-000277:notes:112]

[0001445305-14-001932:notes:115]
[same as prior period, unchanged from 0001445305-14-000277:notes:113]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001445305-14-001932:notes:116]
Balance Sheet Components

[0001445305-14-001932:notes:117]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $889,000 and $2,427,000 in the three and nine months ended March 31, 2014, respectively, and $2,431,000 and $8,744,000 in the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001932:notes:118]
[same as prior period, unchanged from 0001445305-14-000277:notes:117]

[0001445305-14-001932:notes:119]
Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California and bank guarantees in connection with office leases in the Netherlands.


## invest:InvestmentTextBlock

[0001445305-14-001932:notes:120]
[same as prior period, unchanged from 0001445305-14-000277:notes:119]

[0001445305-14-001932:notes:121]
As of March 31, 2014 and June 30, 2013, the Company held $2,637,000 of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AAA or AA2 at March 31, 2014 and June 30, 2013. These auction rate preferred shares have no stated maturity date.

[0001445305-14-001932:notes:122]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2014 and June 30, 2013, $2,637,000 of these auction rate securities have been classified as long-term available-for-sale investments.

[0001445305-14-001932:notes:123]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2014 and June 30, 2013. The material factors used in preparing the discounted cash flow model are i) the discount rate utilized to present value the cash flows, ii) the time period until redemption and iii) the estimated rate of return. As of March 31, 2014, the discount rate, the time period until redemption and the estimated rate of return were 1.70%, 3 years and 0.35%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001445305-14-001932:notes:124]
Based on this assessment of fair value, the Company determined there were no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2014 and the three months ended March 31, 2013. There was a recovery in fair value of $27,000 during the nine months ended March 31, 2013. There was a cumulative total decline in fair value of $113,000 as of March 31, 2014 and June 30, 2013. That amount has been recorded as a component of other comprehensive income. As of March 31, 2014 and June 30, 2013, the Company has recorded an accumulated unrealized loss of $68,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001445305-14-001932:notes:125]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. During the three and nine months ended March 31, 2014, there were no auction rate securities redeemed or sold. During the three and nine months ended March 31, 2013, $0 and $300,000 of the auction rate securities were redeemed at par.
