# SMCI note change history — 0001445305-14-000277 → 0001445305-14-001932


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001445305-14-001932:note_history:1]
Purchase Commitments — The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of March 31, 2014, these remaining non-cancellable commitments were $271,209,000 compared to $249,005,000 at June 30, 2013. The increase was primarily due to support the growth of the Company's revenue.
  (was, 2014-02-07, similarity 0.768):
[0001445305-14-000277:note_history:1]
Purchase Commitments — The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2016. As of December 31, 2013, these remaining non-cancellable commitments were $257,728,000.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001445305-14-001932:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2014.
  (was, 2014-02-07, similarity 0.9555):
[0001445305-14-000277:note_history:2]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2014.

- changed (2014-05-07):
[0001445305-14-001932:note_history:3]
As of March 31, 2014, the Company contributed $168,000 and owned a 50% interest in Super Micro Business Park, Inc. ("Management Company") in Taiwan. The Management Company was established to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. The Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. Therefore, the accounts of the Management Company have been consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income(loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2014-02-07, similarity 0.845):
[0001445305-14-000277:note_history:3]
As of December 31, 2013, the Company contributed $168,000 and owned a 50% interest in Super Micro Business Park, Inc. ("Management Company") in Taiwan. The Management Company was established to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. The Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. Therefore, the accounts of the Management Company have been consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2013, $7,000 and $13,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2012, $2,000 and $0, respectively, of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.

- added (2014-05-07):
[0001445305-14-001932:note_history:4]
In March 2013, the FASB issued authoritative guidance associated with a parent company’s accounting for the cumulative translation adjustment upon derecognition of certain subsidiaries or groups of assets within a foreign entity or of an investment in a foreign entity. The standard applies to the release of the cumulative translation adjustment into net income when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets that is a business (other than a sale of in substance real estate or conveyance of oil and gas mineral rights) within a foreign entity. This new accounting pronouncement is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those years, beginning after December 15, 2013. The Company is currently reviewing the provisions but does not expect it to have a material impact on the Company’s financial statement disclosures, results of operations or financial position.

- changed (2014-05-07):
[0001445305-14-001932:note_history:5]
In July 2013, the FASB issued authoritative guidance associated with the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to an unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company currently plans to adopt the new disclosure requirement on July 1, 2014. The Company does not believe the adoption of this guidance will have a material impact on its financial statement disclosures, results of operations or financial position.
  (was, 2014-02-07, similarity 0.9959):
[0001445305-14-000277:note_history:5]
In July 2013, the FASB issued authoritative guidance associated with the presentation of unrecognized tax benefit when a net operating loss carryforward, a similar tax loss or a tax credit carryforward exists. It requires a liability related to unrecognized tax benefit to offset a deferred tax asset for a net operating loss carryforward, a similar tax loss or a tax credit carryforward if a settlement is required or expected in the event the uncertain tax position is disallowed. The Company currently plans to adopt the new disclosure requirement on July 1, 2014. The Company does not believe the adoption of this guidance will have a material impact on its financial statement disclosures, results of operations or financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001445305-14-001932:note_history:6]
Short-term and long-term obligations as of March 31, 2014 and June 30, 2013 consisted of the following (in thousands):
  (was, 2014-02-07, similarity 0.9589):
[0001445305-14-000277:note_history:6]
Short-term and long-term obligations as of December 31, 2013 and June 30, 2013 consisted of the following (in thousands):

- changed (2014-05-07):
[0001445305-14-001932:note_history:7]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,233 |  |  | 9,333 |  |
| CTBC Bank | 21,631 |  |  | 14,939 |  |
| Total building term loans | 28,864 |  |  | 24,272 |  |
| Total debt | 46,563 |  |  | 35,171 |  |
| Current portion | (42,130 | ) |  | (28,638 | ) |
| Long-term portion | $ | 4,433 |  |  | $ | 6,533 |  |
  (was, 2014-02-07, similarity 0.898):
[0001445305-14-000277:note_history:7]
|  | December 31, |  | June 30, |
|  | 2013 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 10,899 |  |  | $ | 10,899 |  |
| CTBC Bank | 3,520 |  |  | — |  |
| Total line of credit | 14,419 |  |  | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,933 |  |  | 9,333 |  |
| CTBC Bank | 19,989 |  |  | 14,939 |  |
| Total building term loans | 27,922 |  |  | 24,272 |  |
| Total debt | 42,341 |  |  | 35,171 |  |
| Current portion | (37,208 | ) |  | (28,638 | ) |
| Long-term portion | $ | 5,133 |  |  | $ | 6,533 |  |

- changed (2014-05-07):
[0001445305-14-001932:note_history:8]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.15% at March 31, 2014. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.
  (was, 2014-02-07, similarity 0.9871):
[0001445305-14-000277:note_history:8]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.17% at December 31, 2013. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

- changed (2014-05-07):
[0001445305-14-001932:note_history:9]
As of March 31, 2014 and June 30, 2013, the total outstanding borrowings under the Bank of America term loan was $7,233,000 and $9,333,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $17,699,000 as of March 31, 2014 and $10,899,000 as of June 30, 2013, respectively. The interest rates for these loans ranged from 1.19% to 1.65% per annum at March 31, 2014 and 1.23% to 1.69% per annum at June 30, 2013, respectively. As of March 31, 2014, the unused revolving line of credit with Bank of America was $22,301,000.
  (was, 2014-02-07, similarity 0.9176):
[0001445305-14-000277:note_history:9]
As of December 31, 2013 and June 30, 2013, the total outstanding borrowings under the Bank of America term loan was $7,933,000 and $9,333,000, respectively. The total outstanding borrowings under the Bank of America line of credit was $10,899,000 as of December 31, 2013 and June 30, 2013, respectively. The interest rates for these loans ranged from 1.20% to 1.67% per annum at December 31, 2013 and 1.23% to 1.69% per annum at June 30, 2013, respectively. As of December 31, 2013, the unused revolving line of credit with Bank of America was $29,101,000.

- changed (2014-05-07):
[0001445305-14-001932:note_history:10]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000, or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which was adjusted monthly.
  (was, 2014-02-07, similarity 0.9608):
[0001445305-14-000277:note_history:10]
In October 2011, the Company obtained an unsecured revolving line of credit from CTBC Bank Co., Ltd ("CTBC Bank", formerly, China Trust Bank) totaling NT$300,000,000 Taiwanese dollars, or $9,898,000 U.S. dollar equivalents. In July 2012, the Company increased the credit facility to NT$450,000,000 Taiwanese dollars or $14,912,000 U.S. dollar equivalents. The term loan was secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender’s established interest rate plus 0.30% which was adjusted monthly.

- changed (2014-05-07):
[0001445305-14-001932:note_history:11]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established New Taiwan Dollar ("NTD") interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 or $3,398,000 U.S. dollar equivalents and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 or $33,981,000 U.S. dollar equivalents.
  (was, 2014-02-07, similarity 0.9645):
[0001445305-14-000277:note_history:11]
In November 2013, the Company entered into an amendment to the existing credit agreement with CTBC Bank to increase the credit facility amount and extend the maturity date to November 30, 2014. The amendment provides for (i) a 13-month NT$700,000,000 Taiwanese dollars or $23,787,000 U.S. dollar equivalents term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established New Taiwan Dollar ("NTD") interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 13-month unsecured term loan up to NT$100,000,000 Taiwanese dollars or $3,398,000 U.S. dollar equivalents and a 13-month revolving line of credit up to 80% of eligible accounts receivable in an aggregate amount of up to NT$500,000,000 Taiwanese dollars or $16,991,000 U.S. dollar equivalents with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum or lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement is capped at NT$1,000,000,000 Taiwanese dollars or $33,981,000 U.S. dollar equivalents.

- changed (2014-05-07):
[0001445305-14-001932:note_history:12]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $21,631,000 and $14,939,000 at March 31, 2014 and June 30, 2013, respectively. There were no outstanding borrowings under the CTBC Bank revolving line of credit at March 31, 2014 and June 30, 2013. The interest rate for the loan was at 1.13% per annum at March 31, 2014 and was at 1.20% per annum at June 30, 2013. At March 31, 2014, NT$340,000,000 or $11,143,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.
  (was, 2014-02-07, similarity 0.8228):
[0001445305-14-000277:note_history:12]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $19,989,000 and $14,939,000 at December 31, 2013 and June 30, 2013, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $3,520,000 and $0 at December 31, 2013 and June 30, 2013, respectively. The interest rates for these loans ranged from 1.11% to 1.74% per annum at December 31, 2013 and was at 1.20% per annum at June 30, 2013. At December 31, 2013, NT$294,340,000 Taiwanese dollars or $9,806,000 U.S. dollar equivalents were available for future borrowing under this credit agreement.

- changed (2014-05-07):
[0001445305-14-001932:note_history:13]
As of March 31, 2014 and June 30, 2013, total assets of $705,506,000 and $586,742,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings located in San Jose, California and the land and building located in Bade, Taiwan. As of March 31, 2014 and June 30, 2013, total assets collateralizing the term loan with Bank of America were $17,641,000 and $17,813,000, respectively. As of March 31, 2014, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.
  (was, 2014-02-07, similarity 0.9638):
[0001445305-14-000277:note_history:13]
As of December 31, 2013 and June 30, 2013, total assets of $663,476,000 and $586,742,000, respectively collateralized the line of credit with Bank of America and were all of the assets of the Company except for the three buildings located in San Jose, California and the land and building located in Bade, Taiwan. As of December 31, 2013 and June 30, 2013, total assets collateralizing the term loan with Bank of America were $17,699,000 and $17,813,000, respectively. As of December 31, 2013, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

- changed (2014-05-07):
[0001445305-14-001932:note_history:14]
As of March 31, 2014 and June 30, 2013, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,394,000 and $27,702,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2014.
  (was, 2014-02-07, similarity 0.9344):
[0001445305-14-000277:note_history:14]
As of December 31, 2013 and June 30, 2013, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $27,556,000 and $27,702,000, respectively. There are no financial covenants associated with the term loan with CTBC Bank at December 31, 2013.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001445305-14-001932:note_history:15]
Short-term and long-term obligations as of March 31, 2014 and June 30, 2013 consisted of the following (in thousands):
  (was, 2014-02-07, similarity 0.9589):
[0001445305-14-000277:note_history:15]
Short-term and long-term obligations as of December 31, 2013 and June 30, 2013 consisted of the following (in thousands):

- changed (2014-05-07):
[0001445305-14-001932:note_history:16]
|  | March 31, |  | June 30, |
|  | 2014 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 17,699 |  |  | $ | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,233 |  |  | 9,333 |  |
| CTBC Bank | 21,631 |  |  | 14,939 |  |
| Total building term loans | 28,864 |  |  | 24,272 |  |
| Total debt | 46,563 |  |  | 35,171 |  |
| Current portion | (42,130 | ) |  | (28,638 | ) |
| Long-term portion | $ | 4,433 |  |  | $ | 6,533 |  |
  (was, 2014-02-07, similarity 0.898):
[0001445305-14-000277:note_history:16]
|  | December 31, |  | June 30, |
|  | 2013 |  | 2013 |
| Lines of credit: |  |  |  |
| Bank of America | $ | 10,899 |  |  | $ | 10,899 |  |
| CTBC Bank | 3,520 |  |  | — |  |
| Total line of credit | 14,419 |  |  | 10,899 |  |
| Building term loans: |  |  |  |
| Bank of America | 7,933 |  |  | 9,333 |  |
| CTBC Bank | 19,989 |  |  | 14,939 |  |
| Total building term loans | 27,922 |  |  | 24,272 |  |
| Total debt | 42,341 |  |  | 35,171 |  |
| Current portion | (37,208 | ) |  | (28,638 | ) |
| Long-term portion | $ | 5,133 |  |  | $ | 6,533 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001445305-14-001932:note_history:17]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.0% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at March 31, 2014.
  (was, 2014-02-07, similarity 0.9914):
[0001445305-14-000277:note_history:17]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over the operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 1.1% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 35.9% of Ablecom at December 31, 2013.

- changed (2014-05-07):
[0001445305-14-001932:note_history:18]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $45,398,000 and $145,139,000 and sold products to Ablecom totaling $3,418,000 and $10,805,000 for the three and nine months ended March 31, 2014, respectively. The Company purchased products from Ablecom totaling $44,765,000 and $132,704,000 and sold products to Ablecom totaling $3,600,000 and $9,390,000 for the three and nine months ended March 31, 2013, respectively.
  (was, 2014-02-07, similarity 0.9016):
[0001445305-14-000277:note_history:18]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $54,424,000 and $99,741,000 and sold products to Ablecom totaling $3,859,000 and $7,387,000 for the three and six months ended December 31, 2013, respectively. The Company purchased products from Ablecom totaling $38,683,000 and $87,940,000 and sold products to Ablecom totaling $2,898,000 and $5,791,000 for the three and six months ended December 31, 2012, respectively.

- changed (2014-05-07):
[0001445305-14-001932:note_history:19]
Amounts owed to the Company by Ablecom as of March 31, 2014 and June 30, 2013, were $469,000 and $974,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2014 and June 30, 2013, were $42,198,000 and $50,448,000, respectively. For the three and nine months ended March 31, 2014, the Company paid Ablecom the majority of invoiced dollars between 50 and 96 days of invoice. For the three and nine months ended March 31, 2014, the Company paid $2,187,000 and $5,923,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2013, the Company paid $531,000 and $3,398,000, respectively, for tooling assets and miscellaneous costs to Ablecom.
  (was, 2014-02-07, similarity 0.8629):
[0001445305-14-000277:note_history:19]
Amounts owed to the Company by Ablecom as of December 31, 2013 and June 30, 2013, were $417,000 and $974,000, respectively. Amounts owed to Ablecom by the Company as of December 31, 2013 and June 30, 2013, were $48,150,000 and $50,448,000, respectively. For the three and six months ended December 31, 2013, the Company paid Ablecom the majority of invoiced dollars between 55 and 93 days of invoice. For the three and six months ended December 31, 2013, the Company paid $1,460,000 and $3,736,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and six months ended December 31, 2012, the Company paid $1,483,000 and $2,867,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

- changed (2014-05-07):
[0001445305-14-001932:note_history:20]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $63,997,000 and $53,684,000 at March 31, 2014 and June 30, 2013, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.
  (was, 2014-02-07, similarity 0.9915):
[0001445305-14-000277:note_history:20]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $63,352,000 and $53,684,000 at December 31, 2013 and June 30, 2013, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

- changed (2014-05-07):
[0001445305-14-001932:note_history:21]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2014, $6,000 and $(7,000), respectively, of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2013, $7,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
  (was, 2014-02-07, similarity 0.8718):
[0001445305-14-000277:note_history:21]
In May 2012, the Company and Ablecom jointly established Super Micro Business Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and six months ended December 31, 2013, $7,000 and $13,000, respectively, of net loss attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and six months ended December 31, 2012, $2,000 and $0, respectively, of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.
