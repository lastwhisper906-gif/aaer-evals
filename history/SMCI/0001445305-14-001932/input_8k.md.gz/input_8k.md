# SMCI 8-K — 0001445305-14-001395 filed 2014-04-22

## item codes, every 8-K on or before 2014-05-07

- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2014-05-07

- none on or before 2014-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-001395:8k_2_02:1]
EX-99.1
2
exhibit991q32014.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001445305-14-001395:8k_2_02:2]
Exhibit 991 Q32014

[0001445305-14-001395:8k_2_02:3]
Exhibit 99.1

[0001445305-14-001395:8k_2_02:4]
Super Micro Computer, Inc. Announces 3rd Quarter 2014 Financial Results

[0001445305-14-001395:8k_2_02:5]
SAN JOSE, Calif., April 22, 2014 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a leader in application optimized, high performance server solutions, today announced third quarter fiscal 2014 financial results for the quarter ended March 31, 2014.

[0001445305-14-001395:8k_2_02:6]
Fiscal 3rd Quarter Highlights

[0001445305-14-001395:8k_2_02:7]
| • | Quarterly net sales of $373.8 million, up 4.9% from the second quarter of fiscal year 2014 and up 34.4% from the same quarter of last year. |

[0001445305-14-001395:8k_2_02:8]
| • | GAAP net income of $16.6 million, up 24.3% from the second quarter of fiscal year 2014 and up 135.4% from the same quarter of last year. |

[0001445305-14-001395:8k_2_02:9]
| • | GAAP gross margin of 15.3%, down from 15.5% in the second quarter of fiscal year 2014 and up from 14.0% in the same quarter of last year. |

[0001445305-14-001395:8k_2_02:10]
| • | Server solutions accounted for 50.1% of net sales compared with 48.8% in the second quarter of fiscal year 2014 and 41.8% in the same quarter of last year. |

[0001445305-14-001395:8k_2_02:11]
Net sales for the third quarter ended March 31, 2014 totaled $373.8 million, up 4.9% from $356.4 million in the second quarter of fiscal year 2014. No customer accounted for more than 10% of net sales during the quarter ended March 31, 2014.

[0001445305-14-001395:8k_2_02:12]
GAAP net income for the third quarter of fiscal year 2014 was $16.6 million or $0.35 per diluted share, an increase of 135.4% from the net income of $7.0 million, or $0.16 per diluted share in the same period a year ago. Included in net income for the quarter is $2.8 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the third quarter was $17.8 million, or $0.37 per diluted share, compared to non-GAAP net income of $10.0 million, or $0.23 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income increased from the second quarter of fiscal year 2014 by $1.9 million or $0.02 per diluted share.

[0001445305-14-001395:8k_2_02:13]
GAAP gross margin for the third quarter was 15.3% compared to 14.0% in the same period a year ago. Non-GAAP gross margin for the third quarter was 15.4% compared to 14.1% in the same period a year ago. GAAP gross margin and Non-GAAP gross margin for the second quarter of fiscal year 2014 were both 15.5%.

[0001445305-14-001395:8k_2_02:14]
The Company's cash and cash equivalents and short and long term investments at March 31, 2014 were $104.4 million compared to $95.7 million at June 30, 2013. Free cash flow for the nine months ended March 31, 2014 was $(24.3) million primarily due to the purchase of real property in San Jose, California for $30.1 million partially offset by an increase in cash provided by operating activities for $12.5 million.

[0001445305-14-001395:8k_2_02:15]
Business Outlook & Management Commentary

[0001445305-14-001395:8k_2_02:16]
The Company expects net sales of $370 million to $410 million for the fourth quarter of fiscal year 2014 ending June 30, 2014. The Company expects non-GAAP earnings per diluted share of approximately $0.35 to $0.41 for the fourth quarter.

[0001445305-14-001395:8k_2_02:17]
“Supermicro’s third quarter was a second straight quarter of record highs for revenue and earnings. Revenues were 34.4% higher year over year with strong growth coming from North America and from internet data centers. We grew again in multiples of the industry growth rate, expanded market share, and continued to lead the industry in system innovation and time to market," said Charles Liang, CEO and President of Super Micro. “As we extend our business model to provide more complete solutions including software and maintenance support together with our global operations, we are prepared to drive Supermicro to increased sales momentum in 2014."

[0001445305-14-001395:8k_2_02:18]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001445305-14-001395:8k_2_02:19]
Conference Call Information

[0001445305-14-001395:8k_2_02:20]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference call, please call 1-888-329-8893 (international callers dial 1-719-325-2491) 10 minutes prior. A recording of the conference call will be available until 11:59 pm ET on Tuesday, May 6, 2014 by dialing 1-877-870-5176 (international callers dial 1-858-384-5517) and entering replay PIN 6828329. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference call conclusion. They will remain available until the Company's next earnings call.

[0001445305-14-001395:8k_2_02:21]
Cautionary Statement Regarding Forward Looking Statements

[0001445305-14-001395:8k_2_02:22]
Use of Non-GAAP Financial Measures

[0001445305-14-001395:8k_2_02:23]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001445305-14-001395:8k_2_02:24]
About Super Micro Computer, Inc.

[0001445305-14-001395:8k_2_02:25]
Supermicro® (NASDAQ: SMCI), a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, FatTwin™, MicroCloud, MicroBlade, SuperBlade®, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001445305-14-001395:8k_2_02:26]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001445305-14-001395:8k_2_02:27]
Supermicro, FatTwin, UltraTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc. All other brands, names and trademarks are the property of their respective owners.

[0001445305-14-001395:8k_2_02:28]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | March 31, |  | June 30, |
|  |  |  |  | 2014 |  | 2013 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 101,714 |  |  | $ | 93,038 |  |
|  | Accounts receivable, net | 182,028 |  |  | 149,340 |  |
|  | Inventory |  | 295,089 |  |  | 254,170 |  |
|  | Deferred income taxes – current | 21,168 |  |  | 15,786 |  |
|  | Prepaid income taxes | 5,426 |  |  | 4,039 |  |
|  | Prepaid expenses and other current assets | 5,420 |  |  | 6,819 |  |
|  |  | Total current assets | 610,845 |  |  | 523,192 |  |
| Long-term investments | 2,637 |  |  | 2,637 |  |
| Property, plant and equipment, net | 128,504 |  |  | 95,912 |  |
| Deferred income taxes – noncurrent |  | 5,740 |  |  | 7,275 |  |
| Other assets |  |  | 2,815 |  |  | 3,241 |  |
|  |  | Total assets | $ | 750,541 |  |  | $ | 632,257 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 205,246 |  |  | $ | 172,855 |  |
|  | Accrued liabilities |  | 32,372 |  |  | 34,122 |  |
|  | Income taxes payable |  | 12,782 |  |  | 6,049 |  |
|  | Short-term debt and current portion of long-term debt | 42,130 |  |  | 28,638 |  |
|  |  | Total current liabilities | 292,530 |  |  | 241,664 |  |
| Long term debt-net of current portion | 4,433 |  |  | 6,533 |  |
| Other long-term liabilities | 11,039 |  |  | 10,336 |  |
|  |  | Total liabilities | 308,002 |  |  | 258,533 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital |  | 188,931 |  |  | 157,712 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (74 | ) |  | (69 | ) |
|  | Retained earnings |  | 255,538 |  |  | 217,930 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 442,365 |  |  | 373,543 |  |
|  | Noncontrolling interest | 174 |  |  | 181 |  |
|  |  | Total stockholders' equity | 442,539 |  |  | 373,724 |  |
|  |  | Total liabilities and stockholders' equity | $ | 750,541 |  |  | $ | 632,257 |  |

[0001445305-14-001395:8k_2_02:29]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |  | March 31, |  | March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 373,755 |  |  | $ | 278,034 |  |  | $ | 1,039,133 |  |  | $ | 840,228 |  |
| Cost of sales | 316,491 |  |  | 239,141 |  |  | 879,985 |  |  | 726,198 |  |
| Gross profit | 57,264 |  |  | 38,893 |  |  | 159,148 |  |  | 114,030 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 20,570 |  |  | 18,606 |  |  | 61,234 |  |  | 55,651 |  |
| Sales and marketing | 9,416 |  |  | 8,713 |  |  | 27,257 |  |  | 25,424 |  |
| General and administrative | 5,806 |  |  | 6,134 |  |  | 16,938 |  |  | 18,225 |  |
| Total operating expenses | 35,792 |  |  | 33,453 |  |  | 105,429 |  |  | 99,300 |  |
| Income from operations | 21,472 |  |  | 5,440 |  |  | 53,719 |  |  | 14,730 |  |
| Interest and other income, net | 10 |  |  | 2 |  |  | 73 |  |  | 24 |  |
| Interest expense | (156 | ) |  | (142 | ) |  | (535 | ) |  | (449 | ) |
| Income before income tax provision | 21,326 |  |  | 5,300 |  |  | 53,257 |  |  | 14,305 |  |
| Income tax provision (benefit) | 4,752 |  |  | (1,740 | ) |  | 15,649 |  |  | 1,452 |  |
| Net income | $ | 16,574 |  |  | $ | 7,040 |  |  | $ | 37,608 |  |  | $ | 12,853 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 0.17 |  |  | $ | 0.87 |  |  | $ | 0.31 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.16 |  |  | $ | 0.82 |  |  | $ | 0.29 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic (a) | 43,992 |  |  | 42,147 |  |  | 43,128 |  |  | 41,901 |  |
| Diluted (b) | 47,424 |  |  | 44,148 |  |  | 45,857 |  |  | 43,921 |  |
| Stock-based compensation is included in the following cost and expense |  |  |  |  |
| categories by period (in thousands): |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, |  | March 31, |  | March 31, |  | March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of sales | $ | 246 |  |  | $ | 232 |  |  | $ | 726 |  |  | $ | 696 |  |
| Research and development | 1,723 |  |  | 1,666 |  |  | 4,993 |  |  | 4,928 |  |
| Sales and marketing | 306 |  |  | 389 |  |  | 925 |  |  | 1,182 |  |
| General and administrative | 531 |  |  | 563 |  |  | 1,539 |  |  | 1,856 |  |

[0001445305-14-001395:8k_2_02:30]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Nine Months EndedMarch 31, |
|  | 2014 |  | 2013 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 37,608 |  |  | $ | 12,853 |  |
| Reconciliation of net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 4,590 |  |  | 5,900 |  |
| Stock-based compensation expense | 8,183 |  |  | 8,662 |  |
| Excess tax benefits from stock-based compensation | (2,719 | ) |  | (844 | ) |
| Allowance for doubtful accounts | 1,384 |  |  | 696 |  |
| Provision for inventory | 2,427 |  |  | 8,744 |  |
| Exchange gain | (334 | ) |  | (158 | ) |
| Deferred income taxes | (3,847 | ) |  | (6,205 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (34,072 | ) |  | (21,021 | ) |
| Inventory | (43,346 | ) |  | 10,514 |  |
| Prepaid expenses and other assets | 1,417 |  |  | 169 |  |
| Accounts payable | 32,492 |  |  | (9,602 | ) |
| Income taxes payable, net | 9,879 |  |  | 1,943 |  |
| Accrued liabilities | (1,767 | ) |  | 3,268 |  |
| Other long-term liabilities | 579 |  |  | (1,350 | ) |
| Net cash provided by operating activities | 12,474 |  |  | 13,569 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (36,779 | ) |  | (4,346 | ) |
| Restricted cash | 401 |  |  | (407 | ) |
| Proceeds from investments | — |  |  | 300 |  |
| Net cash used in investing activities | (36,378 | ) |  | (4,453 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 17,354 |  |  | 20,641 |  |
| Repayment of debt | (5,620 | ) |  | (17,373 | ) |
| Proceeds from exercise of stock options | 19,154 |  |  | 1,446 |  |
| Excess tax benefits from stock-based compensation | 2,719 |  |  | 844 |  |
| Payment of obligations under capital leases | (26 | ) |  | (31 | ) |
| Payments under receivable financing arrangements | (8 | ) |  | (586 | ) |
| Contribution from noncontrolling interests | — |  |  | 168 |  |
| Minimum tax withholding paid on behalf of an officer for restricted stock awards | (651 | ) |  | (1,022 | ) |
| Net cash provided by financing activities | 32,922 |  |  | 4,087 |  |
| Effect of exchange rate fluctuations on cash | (342 | ) |  | (55 | ) |
| Net increase in cash and cash equivalents | 8,676 |  |  | 13,148 |  |
| Cash and cash equivalents at beginning of period | 93,038 |  |  | 80,826 |  |
| Cash and cash equivalents at end of period | $ | 101,714 |  |  | $ | 93,974 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | $ | 533 |  |  | $ | 551 |  |
| Cash paid for taxes, net of refunds | $ | 8,940 |  |  | $ | 6,793 |  |
| Non-cash investing and financing activities: |  |  |  |
| Accrued costs for property, plant and equipment purchases | $ | 2,055 |  |  | $ | 180 |  |

[0001445305-14-001395:8k_2_02:31]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, |  | March 31, |  | March 31, |  | March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP GROSS PROFIT | $ | 57,264 |  |  | $ | 38,893 |  |  | $ | 159,148 |  |  | $ | 114,030 |  |
|  | Add back stock-based compensation (c) | 246 |  |  | 232 |  |  | 726 |  |  | 696 |  |
| Non-GAAP GROSS PROFIT | $ | 57,510 |  |  | $ | 39,125 |  |  | $ | 159,874 |  |  | $ | 114,726 |  |
| GAAP GROSS MARGIN | 15.3 | % |  | 14.0 | % |  | 15.3 | % |  | 13.6 | % |
|  | Add back stock-based compensation (c) | 0.1 | % |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP GROSS MARGIN | 15.4 | % |  | 14.1 | % |  | 15.4 | % |  | 13.7 | % |
| GAAP INCOME FROM OPERATIONS | $ | 21,472 |  |  | $ | 5,440 |  |  | $ | 53,719 |  |  | $ | 14,730 |  |
|  | Add back stock-based compensation (c) | 2,806 |  |  | 2,850 |  |  | 8,183 |  |  | 8,662 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 24,278 |  |  | $ | 8,290 |  |  | $ | 61,902 |  |  | $ | 23,392 |  |
| GAAP NET INCOME | $ | 16,574 |  |  | $ | 7,040 |  |  | $ | 37,608 |  |  | $ | 12,853 |  |
|  | Add back stock-based compensation (c) | 2,806 |  |  | 2,850 |  |  | 8,183 |  |  | 8,662 |  |
|  | Add back adjustments to tax benefit (provision) (d) | (1,619 | ) |  | 139 |  |  | (2,272 | ) |  | (607 | ) |
| Non-GAAP NET INCOME | $ | 17,761 |  |  | $ | 10,029 |  |  | $ | 43,519 |  |  | $ | 20,908 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC (a) | $ | 0.38 |  |  | $ | 0.17 |  |  | $ | 0.87 |  |  | $ | 0.31 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.02 |  |  | 0.07 |  |  | 0.14 |  |  | 0.19 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC (e) | $ | 0.40 |  |  | $ | 0.24 |  |  | $ | 1.01 |  |  | $ | 0.50 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED (b) | $ | 0.35 |  |  | $ | 0.16 |  |  | $ | 0.82 |  |  | $ | 0.29 |  |
|  | Add back stock-based compensation and adjustments to tax provision (c) (d) | 0.02 |  |  | 0.07 |  |  | 0.12 |  |  | 0.18 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED (f) | $ | 0.37 |  |  | $ | 0.23 |  |  | $ | 0.94 |  |  | $ | 0.47 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP (g) | 43,992 |  |  | 42,147 |  |  | 43,128 |  |  | 41,901 |  |
|  | BASIC - Non-GAAP (h) | 43,996 |  |  | 42,330 |  |  | 43,167 |  |  | 42,121 |  |
|  | DILUTED – GAAP (g) | 47,424 |  |  | 44,148 |  |  | 45,857 |  |  | 43,921 |  |
|  | DILUTED - Non-GAAP (h) | 48,103 |  |  | 44,498 |  |  | 46,403 |  |  | 44,279 |  |

[0001445305-14-001395:8k_2_02:32]
(a) Approximately $1,000 and $34,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP basic net income per common share for the three and nine months ended March 31, 2014, respectively, and approximately $30,000 and $67,000 for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:33]
(b) Approximately $1,000 and $32,000 of undistributed earnings allocated to participating securities were not included in the determination of GAAP diluted net income per common share for the three and nine months ended March 31, 2014, respectively, and approximately $29,000 and $64,000 for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:34]
(c) Amortization of ASC Topic 718 stock-based compensation for the three and nine months ended March 31, 2014 and 2013.

[0001445305-14-001395:8k_2_02:35]
(d) The provision of (benefit from) income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 26.4% and 29.2% for the three and nine months ended March 31, 2014, respectively, and (23.1)% and 9.0% for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:36]
(e) Approximately $1,000 and $39,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP basic net income per common share for the three and nine months ended March 31, 2014, respectively, and approximately $43,000 and $109,000 for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:37]
(f) Approximately $1,000 and $36,000 of undistributed earnings allocated to participating securities were included in the determination of Non-GAAP diluted net income per common share for the three and nine months ended March 31, 2014, respectively, and approximately $41,000 and $104,000 for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:38]
(g) 3,500 and 38,784 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2014, respectively. 183,141 and 219,856 shares of unvested restricted stock awards were not included in the determination of GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:39]
(h) 3,500 and 38,784 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2014, respectively. 183,141 and 219,856 shares of unvested restricted stock awards were included in the determination of Non-GAAP basic and diluted net income per common share for the three and nine months ended March 31, 2013, respectively.

[0001445305-14-001395:8k_2_02:40]
SOURCE: Super Micro Computer, Inc.

[0001445305-14-001395:8k_2_02:41]
Super Micro Computer, Inc.

[0001445305-14-001395:8k_2_02:42]
Howard Hideshima, 408-503-8000

[0001445305-14-001395:8k_2_02:43]
Chief Financial Officer

[0001445305-14-001395:8k_2_02:44]
ir@supermicro.com

[0001445305-14-001395:8k_2_02:45]
or

[0001445305-14-001395:8k_2_02:46]
Perry G. Hayes

[0001445305-14-001395:8k_2_02:47]
SVP, Investor Relations

[0001445305-14-001395:8k_2_02:48]
ir@supermicro.com

[0001445305-14-001395:8k_2_02:49]
SMCI-F
