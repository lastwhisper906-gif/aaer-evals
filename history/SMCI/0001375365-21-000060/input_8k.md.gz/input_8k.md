# SMCI 8-K — 0001375365-21-000055 filed 2021-08-10

## item codes, every 8-K on or before 2021-08-27

- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2021-08-27

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-21-000055:8k_2_02:1]
EX-99.1
2
exhibit991_20210630.htm
EX-99.1

[0001375365-21-000055:8k_2_02:2]
Document

[0001375365-21-000055:8k_2_02:3]
Exhibit 99.1

[0001375365-21-000055:8k_2_02:4]
Supermicro Announces Fourth Quarter and Full Year Fiscal Year 2021

[0001375365-21-000055:8k_2_02:5]
Financial Results

[0001375365-21-000055:8k_2_02:6]
SAN JOSE, Calif. -- August 10, 2021 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a global leader in high-performance, high-efficiency server and storage technology and green computing, today announced fourth quarter and full-year financial results for fiscal year 2021 ended June 30, 2021.

[0001375365-21-000055:8k_2_02:7]
Fourth Quarter of Fiscal Year 2021 Highlights

[0001375365-21-000055:8k_2_02:8]
•Net sales of $1.07 billion versus $896 million in the third quarter of fiscal year 2021 and $896 million in the same quarter of last year.

[0001375365-21-000055:8k_2_02:9]
•Gross margin of 13.6% versus 13.7% in the third quarter of fiscal year 2021 and 13.8% in the same quarter of last year.

[0001375365-21-000055:8k_2_02:10]
•Net income of $39 million versus $18 million in the third quarter of fiscal year 2021 and $18 million in the same quarter of last year.

[0001375365-21-000055:8k_2_02:11]
•Diluted net income per common share of $0.74 versus $0.35 in the third quarter of fiscal year 2021 and $0.34 in the same quarter of last year.

[0001375365-21-000055:8k_2_02:12]
•Non-GAAP diluted net income per common share of $0.81 versus $0.50 in the third quarter of fiscal year 2021 and $0.68 in the same quarter of last year.

[0001375365-21-000055:8k_2_02:13]
•Cash flow generated from operations of $64 million and capital expenditures of $13 million.

[0001375365-21-000055:8k_2_02:14]
Non-GAAP gross margin for the fourth quarter of fiscal year 2021 was 13.7%, which adds back stock-based compensation expense of $0.5 million. Non-GAAP diluted net income per common share for the fourth quarter of fiscal year 2021 was $0.81, which adds back stock-based compensation expense of $7.4 million, special performance bonuses of $0.7 million and controls remediation costs recovery of $0.2 million, less tax effects of $3.4 million.

[0001375365-21-000055:8k_2_02:15]
As of June 30, 2021, total cash and cash equivalents was $232 million and bank debt was $98 million.

[0001375365-21-000055:8k_2_02:16]
Fiscal Year 2021 Summary

[0001375365-21-000055:8k_2_02:17]
Net sales for the fiscal year ended June 30, 2021, were $3.56 billion versus $3.34 billion for the fiscal year ended June 30, 2020. Net income for fiscal year 2021 was $112 million, or $2.09 per diluted share, versus $84 million, or $1.60 per diluted share, for fiscal year 2020. Non-GAAP net income for the fiscal year 2021 was $136 million, or $2.48 per diluted share, versus $150 million, or $2.77 per diluted share, for fiscal year 2020. Non-GAAP net income for the fiscal year 2021 adds back stock-based compensation expense of $28.5 million, special performance bonuses of $5.8 million, executive SEC settlement credit of $2.1 million, and controls remediation costs and other expenses of $1.3 million, less tax effects of $9.0 million.

[0001375365-21-000055:8k_2_02:18]
Business Outlook and Management Commentary

[0001375365-21-000055:8k_2_02:19]
The Company expects net sales of $900 million to $980 million, GAAP net income per diluted share of $0.16 to $0.36 and non-GAAP net income per diluted share of $0.28 to $0.48 for the first quarter of fiscal year 2022 ending September 30, 2021. The Company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 16% and a fully diluted share count of 53.7 million shares for GAAP and fully diluted share count of 55.0 million shares for non-GAAP. The outlook for Q1 of fiscal year 2022 GAAP net income per diluted share includes approximately $8 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.  The Company expects net sales of $4.1 billion to $4.5 billion, GAAP net income per diluted share of at least $2.60 and non-GAAP net income per diluted share of at least $3.00 for fiscal year 2022 ending June 30, 2022. The Company’s projections for GAAP and non-GAAP net income per diluted share both assume a tax rate of approximately 16% and a fully diluted share count of 55.3 million shares for GAAP and fully diluted share count of 56.5 million shares for non-GAAP. The outlook for fiscal year 2022 GAAP net income per diluted share includes approximately $30 million in expected stock-based compensation expense and other expenses that are excluded from non-GAAP net income per diluted share.

[0001375365-21-000055:8k_2_02:20]
“I am pleased to announce that for the first time our quarterly revenue has exceeded one billion dollars.  For fiscal Q4 2021, we delivered year-over-year revenue growth of 19%.  For fiscal year 2021, our revenue grew 7%.  We are gaining market share and finally resumed fast growth starting from the March quarter this year,” said Charles Liang, Chairman and Chief Executive Officer. “We also delivered strong Q4 non-GAAP EPS year-on-year growth of 19% despite elevated operating costs due to the impact of COVID-19.  We are shifting a greater portion of our operations and R&D investment to our Taiwan campus, which will result in lower costs.  While our Q1 outlook reflects continued pressure from COVID-19 and global shortage headwinds, we are very optimistic about our future.  We are committed to accelerating our revenue growth, our products have traction with top-tier customers, we are penetrating key markets, and we are continuing our long history of market share gains.”

[0001375365-21-000055:8k_2_02:21]
Conference Call and Webcast Information

[0001375365-21-000055:8k_2_02:22]
Supermicro will hold a public webcast at 2:00 p.m. PDT today to discuss the results for its fourth quarter and full-year fiscal 2021 financial results. Those wishing to access the live webcast may use the following link:

[0001375365-21-000055:8k_2_02:23]
https://event.on24.com/wcc/r/3195684/8DCDB8BCDC914B20C703A18392CAE17B

[0001375365-21-000055:8k_2_02:24]
The conference call can be accessed by registering online at:

[0001375365-21-000055:8k_2_02:25]
http://www.directeventreg.com/registration/event/5254758

[0001375365-21-000055:8k_2_02:26]
After registering, a confirmation will be sent through email, including dial-in details and unique conference call codes for entry. Registration is open during the live call, but to ensure connectivity for the full call, it is recommended that participants register a day in advance and dial-in for the call at least 10 minutes before the start of the call.

[0001375365-21-000055:8k_2_02:27]
A replay of the webcast will be available shortly after the call on the Company’s investor relations website (https://ir.supermicro.com) and will remain accessible for one year.

[0001375365-21-000055:8k_2_02:28]
Cautionary Statement Regarding Forward-Looking Statements

[0001375365-21-000055:8k_2_02:29]
Exchange Commission, including those factors discussed under the caption "Risk Factors" in such filings, particularly in our Annual Report on Form 10-K for our fiscal year ended June 30, 2020.

[0001375365-21-000055:8k_2_02:30]
Use of Non-GAAP Financial Measures

[0001375365-21-000055:8k_2_02:31]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expense, special performance bonuses and other expenses. Non-GAAP operating expenses discussed in this press release adds back stock-based compensation expense, legal settlement costs, special performance bonuses , other expenses,  controls remediation, and executive SEC settlement credit. Non-GAAP income from operations discussed in this press release adds back stock-based compensation expense, legal settlement costs, special performance bonuses, other expenses,  controls remediation and executive SEC settlement credit. Non-GAAP diluted net income and non-GAAP net income per common share discussed in this press release adds back stock-based compensation expense, special performance bonuses, legal settlement costs, other expenses, controls remediation, executive SEC settlement credit and less the related tax effects of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of each of the foregoing non-GAAP measures to the corresponding GAAP metric is included in the tables below.

[0001375365-21-000055:8k_2_02:32]
.

[0001375365-21-000055:8k_2_02:33]
About Super Micro Computer, Inc.

[0001375365-21-000055:8k_2_02:34]
Supermicro (Nasdaq: SMCI), the leading innovator in high-performance, high-efficiency server technology, is a premier provider of advanced Server Building Block Solutions® for Enterprise Data Center, Cloud Computing, Artificial Intelligence, and Edge Computing Systems worldwide. Supermicro is committed to protecting the environment through its “We Keep IT Green®” initiative and provides customers with the most energy-efficient, environmentally-friendly solutions available on the market.

[0001375365-21-000055:8k_2_02:35]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-21-000055:8k_2_02:36]
All other brands, names and trademarks are the property of their respective owners.

[0001375365-21-000055:8k_2_02:37]
SMCI-F

[0001375365-21-000055:8k_2_02:38]
Investor Relations Contact:

[0001375365-21-000055:8k_2_02:39]
Avelina Kauffman

[0001375365-21-000055:8k_2_02:40]
email: ir@supermicro.com

[0001375365-21-000055:8k_2_02:41]
Source: Super Micro Computer, Inc.

[0001375365-21-000055:8k_2_02:42]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000055:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-21-000055:8k_2_02:44]
(in thousands)

[0001375365-21-000055:8k_2_02:45]
(unaudited)

[0001375365-21-000055:8k_2_02:46]
|  | June 30, |  | June 30, |
|  | 2021 |  | 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 232,266 |  |  | $ | 210,533 |  |
| Accounts receivable, net of allowances | 463,834 |  |  | 403,745 |  |
| Inventories | 1,040,964 |  |  | 851,498 |  |
| Prepaid expenses and other current assets | 130,195 |  |  | 126,985 |  |
| Total current assets | 1,867,259 |  |  | 1,592,761 |  |
| Investment in equity investee | 4,578 |  |  | 2,703 |  |
| Property, plant and equipment, net | 274,713 |  |  | 233,785 |  |
| Deferred income taxes, net | 63,288 |  |  | 54,898 |  |
| Other assets | 32,126 |  |  | 34,499 |  |
| Total assets | $ | 2,241,964 |  |  | $ | 1,918,646 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 612,336 |  |  | $ | 417,673 |  |
| Accrued liabilities | 178,850 |  |  | 155,401 |  |
| Income taxes payable | 12,741 |  |  | 4,700 |  |
| Short-term debt | 63,490 |  |  | 23,704 |  |
| Deferred revenue | 101,479 |  |  | 106,157 |  |
| Total current liabilities | 968,896 |  |  | 707,635 |  |
| Deferred revenue, non-current | 100,838 |  |  | 97,612 |  |
| Long-term debt | 34,700 |  |  | 5,697 |  |
| Other long-term liabilities | 41,132 |  |  | 41,995 |  |
| Total liabilities | 1,145,566 |  |  | 852,939 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and Additional Paid In Capital | 438,012 |  |  | 389,972 |  |
| Treasury stock | — |  |  | (20,491) |  |
| Accumulated other comprehensive loss | 453 |  |  | (152) |  |
| Retained earnings | 657,760 |  |  | 696,211 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 1,096,225 |  |  | 1,065,540 |  |
| Noncontrolling interest | 173 |  |  | 167 |  |
| Total stockholders’ equity | 1,096,398 |  |  | 1,065,707 |  |
| Total liabilities and stockholders’ equity | $ | 2,241,964 |  |  | $ | 1,918,646 |  |

[0001375365-21-000055:8k_2_02:47]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000055:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-21-000055:8k_2_02:49]
(in thousands, except share and per share amounts)

[0001375365-21-000055:8k_2_02:50]
(unaudited)

[0001375365-21-000055:8k_2_02:51]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 1,068,985 |  |  | $ | 896,126 |  |  | $ | 3,557,422 |  |  | $ | 3,339,281 |  |
| Cost of sales | 923,474 |  |  | 772,609 |  |  | 3,022,884 |  |  | 2,813,071 |  |
| Gross profit | 145,511 |  |  | 123,517 |  |  | 534,538 |  |  | 526,210 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 58,930 |  |  | 66,748 |  |  | 224,369 |  |  | 221,478 |  |
| Sales and marketing | 22,825 |  |  | 21,080 |  |  | 85,683 |  |  | 85,137 |  |
| General and administrative | 24,675 |  |  | 26,261 |  |  | 100,539 |  |  | 133,941 |  |
| Total operating expenses | 106,430 |  |  | 114,089 |  |  | 410,591 |  |  | 440,556 |  |
| Income from operations | 39,081 |  |  | 9,428 |  |  | 123,947 |  |  | 85,654 |  |
| Other income (expense), net | (1,471) |  |  | (700) |  |  | (2,834) |  |  | 1,410 |  |
| Interest expense | (635) |  |  | (606) |  |  | (2,485) |  |  | (2,236) |  |
| Income before income tax | 36,975 |  |  | 8,122 |  |  | 118,628 |  |  | 84,828 |  |
| Income tax benefit (provision) | 1,605 |  |  | 6,860 |  |  | (6,936) |  |  | (2,922) |  |
| Share of income (loss) from equity investee, net of taxes | 582 |  |  | 3,468 |  |  | 173 |  |  | 2,402 |  |
| Net income | $ | 39,162 |  |  | $ | 18,450 |  |  | $ | 111,865 |  |  | $ | 84,308 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.78 |  |  | $ | 0.35 |  |  | $ | 2.19 |  |  | $ | 1.65 |  |
| Diluted | $ | 0.74 |  |  | $ | 0.34 |  |  | $ | 2.09 |  |  | $ | 1.60 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 50,230 |  |  | 52,240 |  |  | 51,157 |  |  | 50,987 |  |
| Diluted | 52,782 |  |  | 54,218 |  |  | 53,507 |  |  | 52,838 |  |

[0001375365-21-000055:8k_2_02:52]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-21-000055:8k_2_02:53]
|  | Three Months Ended June 30, |  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of sales | $ | 450 |  |  | $ | 355 |  |  | $ | 1,762 |  |  | $ | 1,504 |  |
| Research and development | 3,661 |  |  | 2,903 |  |  | 14,030 |  |  | 12,202 |  |
| Sales and marketing | 505 |  |  | 404 |  |  | 2,022 |  |  | 1,680 |  |
| General and administrative | 2,816 |  |  | 1,704 |  |  | 10,735 |  |  | 4,803 |  |
| Stock-based compensation expense | $ | 7,432 |  |  | $ | 5,366 |  |  | $ | 28,549 |  |  | $ | 20,189 |  |

[0001375365-21-000055:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000055:8k_2_02:55]
SELECTED CASH FLOW INFORMATION

[0001375365-21-000055:8k_2_02:56]
(in thousands)

[0001375365-21-000055:8k_2_02:57]
(unaudited)

[0001375365-21-000055:8k_2_02:58]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  |
| Net cash provided by (used in) operating activities | $ | 122,955 |  |  | $ | (30,334) |  |  |
| Net cash used in investing activities | (58,016) |  |  | (43,588) |  |  |
| Net cash (used in) provided by financing activities | (44,440) |  |  | 23,796 |  |  |
| Effect of exchange rate fluctuations on cash | 560 |  |  | 376 |  |  |
| Net change in cash equivalents and restricted cash | 21,059 |  |  | (49,750) |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the year | 212,390 |  |  | 262,140 |  |  |
| Cash, cash equivalents and restricted cash at the end of the year | $ | 233,449 |  |  | $ | 212,390 |  |  |

[0001375365-21-000055:8k_2_02:59]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000055:8k_2_02:60]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000055:8k_2_02:61]
(in thousands, except share and per share amounts)

[0001375365-21-000055:8k_2_02:62]
(unaudited)

[0001375365-21-000055:8k_2_02:63]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP GROSS PROFIT | $ | 145,511 |  |  | $ | 123,517 |  |  | $ | 534,538 |  |  | $ | 526,210 |  |
| Stock-based compensation | 450 |  |  | 355 |  |  | 1,762 |  |  | 1,504 |  |
| Special performance bonuses | — |  |  | 1,201 |  |  | — |  |  | 4,072 |  |
| Other expenses | — |  |  | 39 |  |  | 20 |  |  | 39 |  |
| NON-GAAP GROSS PROFIT | $ | 145,961 |  |  | $ | 125,112 |  |  | $ | 536,320 |  |  | $ | 531,825 |  |
| GAAP GROSS MARGIN | 13.6 | % |  | 13.8 | % |  | 15.0 | % |  | 15.8 | % |
| Stock-based compensation | 0.1 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |
| Special performance bonuses | 0.0 | % |  | 0.2 | % |  | 0.0 | % |  | 0.1 | % |
| Other expenses | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |
| NON-GAAP GROSS MARGIN | 13.7 | % |  | 14.0 | % |  | 15.1 | % |  | 15.9 | % |
| GAAP OPERATING EXPENSES | $ | 106,430 |  |  | $ | 114,089 |  |  | $ | 410,591 |  |  | $ | 440,556 |  |
| Stock-based compensation | (6,982) |  |  | (5,011) |  |  | (26,787) |  |  | (18,685) |  |
| Legal settlement costs | — |  |  | — |  |  | — |  |  | (17,500) |  |
| Executive SEC settlement | — |  |  | — |  |  | 2,122 |  |  | — |  |
| Special performance bonuses | (672) |  |  | (16,224) |  |  | (5,801) |  |  | (23,682) |  |
| Other expenses | — |  |  | (638) |  |  | (221) |  |  | (638) |  |
| Controls remediation | 163 |  |  | (1,004) |  |  | (1,076) |  |  | (13,863) |  |
| NON-GAAP OPERATING EXPENSES | $ | 98,939 |  |  | $ | 91,212 |  |  | $ | 378,828 |  |  | $ | 366,188 |  |
| GAAP INCOME FROM OPERATIONS | $ | 39,081 |  |  | $ | 9,428 |  |  | $ | 123,947 |  |  | $ | 85,654 |  |
| Stock-based compensation | 7,432 |  |  | 5,366 |  |  | 28,549 |  |  | 20,189 |  |
| Legal settlement costs | — |  |  | — |  |  | — |  |  | 17,500 |  |
| Executive SEC settlement | — |  |  | — |  |  | (2,122) |  |  | — |  |
| Special performance bonuses | 672 |  |  | 17,425 |  |  | 5,801 |  |  | 27,754 |  |
| Other expenses | — |  |  | 677 |  |  | 241 |  |  | 677 |  |
| Controls remediation | (163) |  |  | 1,004 |  |  | 1,076 |  |  | 13,863 |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 47,022 |  |  | $ | 33,900 |  |  | $ | 157,492 |  |  | $ | 165,637 |  |
| GAAP NET INCOME | $ | 39,162 |  |  | $ | 18,450 |  |  | 111,865 |  |  | 84,308 |  |
| Stock-based compensation | 7,432 |  |  | 5,366 |  |  | 28,549 |  |  | 20,189 |  |
| Legal settlement costs | — |  |  | — |  |  | — |  |  | 17,500 |  |
| Executive SEC settlement | — |  |  | — |  |  | (2,122) |  |  | — |  |
| Special performance bonuses | 672 |  |  | 17,425 |  |  | 5,801 |  |  | 27,754 |  |
| Other expenses | — |  |  | 677 |  |  | 241 |  |  | 677 |  |
| Controls remediation | (163) |  |  | 1,004 |  |  | 1,076 |  |  | 13,863 |  |
| Adjustments to tax provision | (3,373) |  |  | (5,101) |  |  | (9,006) |  |  | (13,969) |  |
| NON-GAAP NET INCOME | $ | 43,730 |  |  | $ | 37,821 |  |  | $ | 136,404 |  |  | $ | 150,322 |  |

[0001375365-21-000055:8k_2_02:64]
SUPER MICRO COMPUTER, INC.

[0001375365-21-000055:8k_2_02:65]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-21-000055:8k_2_02:66]
(in thousands, except share and per share amounts)

[0001375365-21-000055:8k_2_02:67]
(unaudited)

[0001375365-21-000055:8k_2_02:68]
|  | Three Months EndedJune 30, |  | Twelve Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.78 |  |  | $ | 0.35 |  |  | $ | 2.19 |  |  | $ | 1.65 |  |
| Impact of NON-GAAP adjustments | 0.09 |  |  | 0.37 |  |  | 0.48 |  |  | 1.30 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.87 |  |  | $ | 0.72 |  |  | $ | 2.67 |  |  | $ | 2.95 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.74 |  |  | $ | 0.34 |  |  | $ | 2.09 |  |  | $ | 1.60 |  |
| Impact of NON-GAAP adjustments | 0.07 |  |  | 0.34 |  |  | 0.39 |  |  | 1.17 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.81 |  |  | $ | 0.68 |  |  | $ | 2.48 |  |  | $ | 2.77 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
| BASIC – GAAP | 50,230 |  |  | 52,240 |  |  | 51,157 |  |  | 50,987 |  |
| BASIC – NON-GAAP | 50,230 |  |  | 52,240 |  |  | 51,157 |  |  | 50,987 |  |
| DILUTED – GAAP | 52,782 |  |  | 54,218 |  |  | 53,507 |  |  | 52,838 |  |
| DILUTED – NON-GAAP | 54,082 |  |  | 55,595 |  |  | 54,910 |  |  | 54,317 |  |
