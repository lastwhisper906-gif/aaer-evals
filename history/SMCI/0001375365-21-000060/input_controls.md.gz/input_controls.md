# SMCI 10-K controls and the auditor's report


## auditors_report

[0001375365-21-000060:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-21-000060:auditors_report:2]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-21-000060:auditors_report:3]
Opinion on the Financial Statements

[0001375365-21-000060:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Super Micro Computer, Inc. and subsidiaries (the "Company") as of June 30,2021 and 2020, the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended June 30, 2021, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2021 and 2020, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2021, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-21-000060:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2021, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) and our report dated August 27, 2021, expressed an unqualified opinion on the Company’s internal control over financial reporting.

[0001375365-21-000060:auditors_report:6]
Basis for Opinion

[0001375365-21-000060:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-21-000060:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001375365-21-000060:auditors_report:9]
Critical Audit Matters

[0001375365-21-000060:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001375365-21-000060:auditors_report:11]
Inventories - Excess and Obsolescence Reserve — Refer to Notes 1 and 5 to the financial statements

[0001375365-21-000060:auditors_report:12]
Critical Audit Matter Description

[0001375365-21-000060:auditors_report:13]
The Company’s inventories are stated at lower of cost, using weighted average cost method, or net realizable value. The Company evaluates inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventory based upon inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors.

[0001375365-21-000060:auditors_report:14]
We identified the excess and obsolescence reserve as a critical audit matter because of judgments made by management in determining the reserve rates applied by inventory aging category to estimate the Company’s excess and obsolescence reserve.  This required a high degree of auditor judgment and an increased extent of effort when performing audit procedures to evaluate the reasonableness of the Company’s reserve rates within its estimation of the inventory excess and obsolescence reserve.

[0001375365-21-000060:auditors_report:15]
How the Critical Audit Matter Was Addressed in the Audit

[0001375365-21-000060:auditors_report:16]
50

[0001375365-21-000060:auditors_report:17]
Our audit procedures related to the reserve rates applied to the inventory aging categories to estimate the Company’s excess and obsolescence reserve included the following procedures, among others:

[0001375365-21-000060:auditors_report:18]
a.We tested the effectiveness of controls over the review of the calculation of excess and obsolescence reserve based on the Company’s reserve methodology, including management’s evaluation of the reserve rates by inventory aging category using historical data.

[0001375365-21-000060:auditors_report:19]
b.To understand and evaluate the Company’s methodology for determining inventory that is excess or obsolete and the key assumptions and judgments made as part of the process, including the reserve rates, we made inquiries of various personnel in the Company including but not limited to finance and operations personnel about the expected product lifecycles and product development plans.

[0001375365-21-000060:auditors_report:20]
c.We involved data specialists to assess management’s estimate on reserve rates by recalculating historical reserve rates across multiple fiscal periods. We compared our independently developed historical reserve rates with the reserve rates used by management.

[0001375365-21-000060:auditors_report:21]
d.We tested the accuracy and completeness of the underlying data utilized in management’s excess and obsolescence reserve, including the classification of inventory by aging category. Then, selected a sample of inventory products and verified the items were properly included in the correct aging category for determination of the reserve rate.

[0001375365-21-000060:auditors_report:22]
e.We considered the existence of contradictory evidence based on reading of internal communications to management, Company press releases, and industry reports, as well as our observations and inquires as to changes within the business.

[0001375365-21-000060:auditors_report:23]
/s/ Deloitte & Touche LLP

[0001375365-21-000060:auditors_report:24]
San Jose, California

[0001375365-21-000060:auditors_report:25]
August 27, 2021

[0001375365-21-000060:auditors_report:26]
We have served as the Company's auditor since fiscal 2003.

[0001375365-21-000060:auditors_report:27]
51

[0001375365-21-000060:auditors_report:28]
SUPER MICRO COMPUTER, INC.


## item_9a

[0001375365-21-000060:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-21-000060:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001375365-21-000060:item_9a:3]
Under the supervision, and with the participation, of our management, including our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), we evaluated the effectiveness of our disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of June 30, 2021. Based on this evaluation, our CEO and CFO have concluded that our disclosure controls and procedures were effective at a reasonable assurance level as of June 30, 2021.

[0001375365-21-000060:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0001375365-21-000060:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f).

[0001375365-21-000060:item_9a:6]
Internal control over financial reporting is a process designed by, or under the supervision of, our CEO and CFO to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our consolidated financial statements for external purposes in accordance with U.S. GAAP. Management’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets, (ii) provide reasonable assurance that transactions are appropriately recorded to permit preparation of financial statements in accordance with U.S. GAAP and that our receipts and expenditures are made only in accordance with authorizations of management, acting under authority delegated to them by the Board, and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on our financial statements.

[0001375365-21-000060:item_9a:7]
Management, including our CEO and CFO, assessed our internal control over financial reporting as of June 30, 2021. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in its Internal Control - Integrated Framework (2013) (the “COSO Framework”). Based on this assessment, management has concluded that our internal control over financial reporting was effective as of June 30, 2021 to provide reasonable assurance regarding the reliability of financial reporting and preparation of consolidated financial statements in accordance with U.S. GAAP. The effectiveness of our internal control over financial reporting as of June 30, 2021 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, and their opinion is stated in their report which is included in this Annual Report on Form 10-K.

[0001375365-21-000060:item_9a:8]
Remediation of Prior Year Material Weakness

[0001375365-21-000060:item_9a:9]
We have remediated the IT general controls that aggregated to a material weakness as previously disclosed in our Annual Report on Form 10-K for the year ended June 30, 2020. Since that time, with the oversight of our management and audit committee, we have implemented measures to remediate the material weakness. The following actions have been implemented and performed:

[0001375365-21-000060:item_9a:10]
•Re-designed the logical access roles associated with our primary ERP application and re-provisioned those roles to enforce segregation of duties and align user access commensurate with their business process role and job responsibilities;

[0001375365-21-000060:item_9a:11]
•Implemented a third-party application to facilitate improved processes and controls related to provisioning privileged access roles and the monitoring of those roles;

[0001375365-21-000060:item_9a:12]
•For our boundary applications relevant to financial reporting, implemented new program change management control;

[0001375365-21-000060:item_9a:13]
•Strengthened access and monitoring controls related to boundary systems;

[0001375365-21-000060:item_9a:14]
•For our primary ERP application, strengthened provisioning of privileged access roles; and

[0001375365-21-000060:item_9a:15]
•Monitored instances in which individuals were granted broad access.

[0001375365-21-000060:item_9a:16]
We believe the foregoing efforts have effectively remediated the material weakness as these procedures

[0001375365-21-000060:item_9a:17]
91

[0001375365-21-000060:item_9a:18]
have been implemented for a sufficient period of time during the fiscal year and we have completed our testing of the design and operating effectiveness of these above procedures as of June 30, 2021. As we continue to evaluate and work to improve our internal control over financial reporting, we may execute additional measures to enhance the overall design of our internal controls.

[0001375365-21-000060:item_9a:19]
Changes in Internal Control over Financial Reporting

[0001375365-21-000060:item_9a:20]
Other than the remediation efforts described above, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the three months ended June 30, 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-21-000060:item_9a:21]
92

[0001375365-21-000060:item_9a:22]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-21-000060:item_9a:23]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-21-000060:item_9a:24]
Opinion on Internal Control over Financial Reporting

[0001375365-21-000060:item_9a:25]
We have audited the internal control over financial reporting of Super Micro Computer, Inc. and subsidiaries (the “Company”) as of June 30, 2021, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2021, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0001375365-21-000060:item_9a:26]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended June 30, 2021, of the Company and our report dated August 27, 2021, expressed an unqualified opinion on those financial statements.

[0001375365-21-000060:item_9a:27]
Basis for Opinion

[0001375365-21-000060:item_9a:28]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-21-000060:item_9a:29]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-21-000060:item_9a:30]
Definition and Limitations of Internal Control over Financial Reporting

[0001375365-21-000060:item_9a:31]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-21-000060:item_9a:32]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-21-000060:item_9a:33]
/s/ Deloitte & Touche LLP

[0001375365-21-000060:item_9a:34]
San Jose, California

[0001375365-21-000060:item_9a:35]
August 27, 2021
