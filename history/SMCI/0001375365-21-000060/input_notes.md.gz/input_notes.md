# SMCI notes — 0001375365-21-000060


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001375365-21-000060:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001375365-21-000060:notes:2]
None


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-21-000060:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001375365-21-000060:notes:4]
Super Micro Computer, Inc. (“Super Micro Computer”) was incorporated in 1993. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, the Netherlands, Taiwan, China and Japan.

[0001375365-21-000060:notes:5]
Basis of Presentation

[0001375365-21-000060:notes:6]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (“U.S. GAAP”). The consolidated financial statements of Super Micro Computer include the accounts of Super Micro Computer and entities consolidated under the variable interest model or the voting interest model. Noncontrolling interests are not presented separately in the consolidated statements of operations, and consolidated statements of comprehensive income as the amounts are immaterial. All intercompany accounts and transactions of Super Micro Computer and its consolidated entities (collectively, the "Company") have been eliminated in consolidation. For equity investments over which the Company is able to exercise significant influence over the investee but does not control the investee, and is not the primary beneficiary of the investee’s activities are accounted for using the equity method. Investments in equity securities which do not have readily determinable fair values and for which the Company is not able to exercise significant influence over the investee are accounted for under the measurement alternative which is the cost minus impairment, if any, plus or minus changes resulting from observable price changes in orderly transactions for the identical or a similar securities of the same investee.

[0001375365-21-000060:notes:7]
Use of Estimates

[0001375365-21-000060:notes:8]
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to revenue recognition, allowances for doubtful accounts and sales returns, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, stock-based compensation, impairment of investments and long-lived assets, and income taxes. The Company’s estimates are evaluated on an ongoing basis and changes in the estimates are recognized prospectively. Actual results could differ from those estimates. The Company considered estimates of the economic implications of the COVID-19 pandemic on its critical and significant accounting estimates, including an assessment of the collectability of each customer contract as part of the revenue recognition process, assessment of the valuation of accounts receivable, assessment of provision for excess and obsolete inventory and an impairment of long-lived assets.

[0001375365-21-000060:notes:9]
Fair Value of Financial Instruments

[0001375365-21-000060:notes:10]
The Company accounts for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, the Company takes into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. The Company considers one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. The Company categorizes each of its fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-21-000060:notes:11]
•Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001375365-21-000060:notes:12]
•Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and

[0001375365-21-000060:notes:13]
•Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable.

[0001375365-21-000060:notes:14]
Accounts receivable and accounts payable are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash equivalents, certificates of deposit and the investment in an auction rate security are carried at fair value. Short-term and long-term debt is carried at amortized cost, which approximates its fair value based on borrowing rates currently available to the Company for loans with similar terms.

[0001375365-21-000060:notes:15]
Cash and Cash Equivalents

[0001375365-21-000060:notes:16]
The Company considers all highly liquid instruments with an original maturity of three months or less from the date of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months.

[0001375365-21-000060:notes:17]
Restricted Cash and Cash Equivalents

[0001375365-21-000060:notes:18]
Restricted cash is comprised of amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to the Company’s workers’ compensation program. These restricted cash balances have been excluded from the Company's cash and cash equivalents balance.

[0001375365-21-000060:notes:19]
Inventories

[0001375365-21-000060:notes:20]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of the Company's products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. The Company evaluates inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based upon the Company's inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-21-000060:notes:21]
The Company receives various rebate incentives from certain suppliers based on its contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-21-000060:notes:22]
Property, Plant and Equipment

[0001375365-21-000060:notes:23]
Property, plant and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-21-000060:notes:24]
| Software | 3 to 5 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |

[0001375365-21-000060:notes:25]
Long-Lived Assets

[0001375365-21-000060:notes:26]
The Company evaluates its long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. When the sum of the undiscounted future net cash flows expected to result from the use of the asset and its eventual disposition is less than its carrying amount, an impairment loss would be measured based on the fair value of the asset compared to the carrying amount. No impairment charge for long-lived assets has been recorded in any of the periods presented.

[0001375365-21-000060:notes:27]
Revenue Recognition

[0001375365-21-000060:notes:28]
The Company generates revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.

[0001375365-21-000060:notes:29]
Product sales. The Company recognizes revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is uncertain. Products sold by the Company are delivered via shipment from the Company’s facilities or drop shipment directly to its customers from a Company vendor. The Company may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-21-000060:notes:30]
The Company applies judgment in determining the transaction price as the Company may be required to estimate variable consideration when determining the amount of revenue to recognize. As part of determining the transaction price in contracts with customers, the Company estimates reserves for future sales returns based on a review of its history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. The Company also reduces revenue for the estimated costs of customer and distributor programs and incentive offerings such as price protection and rebates as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated.  Any provision for customer and distributor programs and other discounts is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-21-000060:notes:31]
Services sales. The Company’s sale of services mainly consists of extended warranty and on-site services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as the Company stands ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer.  These service contracts are typically one to five years in length. Service revenue has been less than 10% of net sales for all periods presented and is not separately disclosed.

[0001375365-21-000060:notes:32]
Contracts with multiple promised goods and services.  Certain of the Company’s contracts contain multiple promised goods and services. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from the Company, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation. Revenue allocated to each performance obligation is recognized at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer.

[0001375365-21-000060:notes:33]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. The Company determines standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, the Company applies judgment to estimate the standalone selling price taking into account available information, such as internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives, for the related performance obligations.

[0001375365-21-000060:notes:34]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-21-000060:notes:35]
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.

[0001375365-21-000060:notes:36]
Allowances for Doubtful Accounts

[0001375365-21-000060:notes:37]
Customers are subjected to a credit review process that evaluates each customer’s financial position and ability and intent to pay. On a quarterly basis, the Company makes estimates of its uncollectible accounts receivable by analyzing the aging of accounts receivable, history of bad debts, customer concentrations, customer-credit-worthiness, and current economic trends to evaluate the adequacy of the allowance for doubtful accounts. The Company's (recovery of) provision for bad debt was $(0.8) million, $(3.1) million, and $7.1 million in fiscal years 2021, 2020 and 2019, respectively.

[0001375365-21-000060:notes:38]
Cost of Sales

[0001375365-21-000060:notes:39]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, equipment and facility expenses, warranty costs and provision for lower of cost or net realizable value and excess and obsolete inventory.

[0001375365-21-000060:notes:40]
Product Warranties

[0001375365-21-000060:notes:41]
The Company offers product warranties typically ranging from 15 to 39 months against any defective products. These standard warranties are assurance type warranties and the Company does not offer any services beyond the assurance that the product will continue working as specified. Therefore, these warranties are not considered separate performance obligations in the arrangement.  Based on historical experience, the Company accrues for estimated returns of defective products at the time revenue is recognized. The Company monitors warranty obligations and may make revisions to its warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are recorded to cost of sales and included in accrued liabilities and other long-term liabilities. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with the Company's historical experience, and the changes in the cost of servicing warranty claims. The Company accounts for the effect of such changes in estimates prospectively. The following table presents for the fiscal years ended June 30, 2021, 2020 and 2019, the reconciliation of the changes in accrued warranty costs which is included as a component of accrued liabilities and other long-term liabilities (in thousands):

[0001375365-21-000060:notes:42]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Balance, beginning of the year | $ | 12,379 |  |  | $ | 11,034 |  |  | $ | 9,884 |  |
| Provision for warranty | 29,638 |  |  | 35,962 |  |  | 22,991 |  |
| Costs utilized | (30,575) |  |  | (34,502) |  |  | (26,281) |  |
| Change in estimated liability for pre-existing warranties | 1,421 |  |  | (115) |  |  | 4,440 |  |
| Balance, end of the year | $ | 12,863 |  |  | $ | 12,379 |  |  | $ | 11,034 |  |
| Current portion | 10,185 |  |  | 9,984 |  |  | 8,661 |  |
| Non-current portion | $ | 2,678 |  |  | $ | 2,395 |  |  | $ | 2,373 |  |

[0001375365-21-000060:notes:43]
Research and Development

[0001375365-21-000060:notes:44]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for the Company's research and development personnel, as well as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to the Company's research and development activities. All research and development costs are expensed as incurred. The Company occasionally receives funding from certain suppliers and customers towards its development efforts. Such amounts are recorded as a reduction of research and development expenses and were $10.9 million, $2.1 million, and $2.8 million for the fiscal years ended June 30, 2021, 2020 and 2019, respectively. During the fiscal year ended June 30, 2020, the Company also recorded a

[0001375365-21-000060:notes:45]
$9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-21-000060:notes:46]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-21-000060:notes:47]
Advertising Costs

[0001375365-21-000060:notes:48]
Advertising costs, net of reimbursements received under the cooperative marketing arrangements with the Company's vendors, are expensed as incurred. Total advertising and promotional expenses were $4.1 million, $3.0 million and $2.4 million for the fiscal years ended June 30, 2021, 2020 and 2019, respectively.

[0001375365-21-000060:notes:49]
Stock-Based Compensation

[0001375365-21-000060:notes:50]
The Company measures and recognizes compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). The Company recognizes the grant date fair value of all share-based awards over the requisite service period and accounts for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. The Company bases initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-21-000060:notes:51]
The fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using a Black-Scholes option pricing model. This model requires the Company to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of the Company's common stock. The expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience. The expected volatility is based on the historical volatility of the Company’s common stock. The fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period.

[0001375365-21-000060:notes:52]
Leases

[0001375365-21-000060:notes:53]
The Company has arrangements for the right to use certain of its office, warehouse spaces and other premises, and equipment. The Company determines at inception if an arrangement is or contains a lease. When the terms of a lease effectively transfer control of the underlying asset to the Company, it is classified as a finance lease. All other leases are classified as operating leases.

[0001375365-21-000060:notes:54]
Operating Leases

[0001375365-21-000060:notes:55]
For operating leases with lease terms of more than 12 months, operating lease right-of-use ("ROU") assets are recorded in long-term other assets, and lease liabilities are recorded in accrued liabilities and other long-term liabilities on the consolidated balance sheet. The Company's lease term includes options to extend or terminate the lease when it is reasonably certain that it will exercise that option. The Company elected to apply the short-term lease recognition exemption and does not recognize ROU asset and lease liabilities for leases with an initial term of 12 months or less and recognizes as expense the payments under such leases on a straight-line basis over the lease term. The Company's leases with an initial term of 12 months or less are immaterial.

[0001375365-21-000060:notes:56]
Operating lease ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments over the lease term. Operating lease ROU assets and liabilities are recognized at lease commencement based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate as the interest rate implicit in the lease arrangements is not readily determinable. The incremental borrowing rate is estimated to be the interest rate on a fully collateralized basis with similar terms and payments and in the economic environment where the leased asset is located. Operating lease ROU assets also include initial direct costs incurred, prepaid lease payments, minus any lease incentives. Operating lease expense is recognized on a straight-line basis over the lease term. The Company accounts for fixed payments for lease and non-lease components as a single lease component which increases the amount of ROU assets and liabilities. Non-lease components that are variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities.

[0001375365-21-000060:notes:57]
Finance Leases

[0001375365-21-000060:notes:58]
Assets under finance leases are recorded in property, plant and equipment, net and lease liabilities are included in accrued liabilities and other long-term liabilities on the consolidated balance sheet. Finance lease interest expense is recognized based on an effective interest method and depreciation of assets is recorded on a straight-line basis over the shorter of the lease term and useful life of the asset. The Company's finance leases are immaterial.

[0001375365-21-000060:notes:59]
Income Taxes

[0001375365-21-000060:notes:60]
The Company accounts for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-21-000060:notes:61]
The Company recognizes tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires the Company to determine the probability of various possible outcomes. The Company evaluates these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If the Company later determines that its exposure is lower or that the liability is not sufficient to cover its revised expectations, the Company adjusts the liability and effects a related charge in its tax provision during the period in which the Company makes such a determination.

[0001375365-21-000060:notes:62]
Variable Interest Entities

[0001375365-21-000060:notes:63]
The Company determines at the inception of each arrangement whether an entity in which the Company holds an investment or in which the Company has other variable interests is considered a variable interest entity ("VIE"). The Company consolidates VIEs when it is the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, the Company assesses whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether the Company is the primary beneficiary. If the Company is not the primary beneficiary in a VIE, the Company accounts for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-21-000060:notes:64]
The Company has concluded that Ablecom Technology, Inc. (“Ablecom”) and its affiliate, Compuware Technology, Inc. ("Compuware"), are VIEs; however, the Company is not the primary beneficiary as it does not have the power to direct the activities that are most significant to the entities and therefore, the Company does not consolidate these entities. In performing its analysis, the Company considered its explicit arrangements with Ablecom and Compuware, all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between the Company and these entities, the Company considered whether any implicit arrangements exist that would cause the Company to protect these related parties’

[0001375365-21-000060:notes:65]
interests from suffering losses. The Company determined it has no material implicit arrangements with Ablecom, Compuware or their shareholders.

[0001375365-21-000060:notes:66]
The Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. (the "Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for its separately constructed manufacturing facilities. In fiscal year 2012, each party contributed $0.2 million for a 50% ownership interest of the Management Company. The Company has concluded that the Management Company is a VIE, and the Company is the primary beneficiary as it has the power to direct the activities that are most significant to the Management Company. For the fiscal years ended 2021, 2020 and 2019, the accounts of the Management Company were consolidated with the accounts of Super Micro Computer, and a noncontrolling interest was recorded for Ablecom's interest in the net assets and operations of the Management Company. Net income (loss) attributable to Ablecom's interest was not material for the periods presented and was included in general and administrative expenses in the Company's consolidated statements of operations.

[0001375365-21-000060:notes:67]
Foreign Currency Transactions

[0001375365-21-000060:notes:68]
The functional currency of the Company’s international subsidiaries is the U.S. dollar, with the exception of Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Monetary assets and liabilities of the Company's international subsidiaries that are denominated in foreign currency are remeasured into U.S. dollars at period-end exchange rates. Non-monetary assets and liabilities that are denominated in the foreign currency are remeasured into U.S. dollars at the historical rates. Revenue and expenses that are denominated in the foreign currency are remeasured into U.S. dollars at the average exchange rates during the period. Remeasurement of foreign currency accounts and resulting foreign exchange transaction gains and losses, which have not been material, are reflected in the consolidated statements of operations in other expense, net.

[0001375365-21-000060:notes:69]
The functional currency of Super Micro Asia and Technology Park, Inc. is New Taiwanese Dollar (“NTD”). Assets and liabilities are translated to U.S. dollars at the period-end exchange rate. Revenues and expenses are translated using the average exchange rate for the period. The effects of foreign currency translation are included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-21-000060:notes:70]
The Company has an investment in a privately-held company that is accounted for under the equity method  (the "Corporate Venture").  The functional currency of the Corporate Venture is the Chinese Yuan. Adjustments for the Company's share of the effects of foreign currency translation from local currency to U.S. dollars are recorded as increases or decreases to the carrying value of the investment and included in stockholders’ equity as a component of accumulated other comprehensive (loss) income in the accompanying consolidated balance sheets and periodic movements are summarized as a line item in the consolidated statements of comprehensive income.

[0001375365-21-000060:notes:71]
Net Income Per Common Share

[0001375365-21-000060:notes:72]
Basic net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per common share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options and unvested RSUs and PRSUs. Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-21-000060:notes:73]
Under the treasury stock method, an increase in the fair market value of the Company's common stock results in a greater dilutive effect from outstanding stock options and RSUs and PRSUs. Additionally, the exercise of stock options and the vesting of RSUs results in a further dilutive effect on net income per share.

[0001375365-21-000060:notes:74]
The computation of basic and diluted net income per common share is as follows (in thousands, except per share amounts):

[0001375365-21-000060:notes:75]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 111,865 |  |  | $ | 84,308 |  |  | $ | 71,918 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 51,157 |  |  | 50,987 |  |  | 49,917 |  |
| Effect of dilutive securities | 2,350 |  |  | 1,851 |  |  | 1,799 |  |
| Weighted-average diluted shares | 53,507 |  |  | 52,838 |  |  | 51,716 |  |
| Basic net income per common share | $ | 2.19 |  |  | $ | 1.65 |  |  | $ | 1.44 |  |
| Diluted net income per common share | $ | 2.09 |  |  | $ | 1.60 |  |  | $ | 1.39 |  |

[0001375365-21-000060:notes:76]
For the fiscal years ended June 30, 2021, 2020 and 2019, the Company had stock options, RSUs and PRSUs outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 670,179, 2,208,000, and 3,758,000 for the fiscal years ended June 30, 2021, 2020 and 2019, respectively.

[0001375365-21-000060:notes:77]
Concentration of Supplier Risk

[0001375365-21-000060:notes:78]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.3%, 26.8%, and 21.8% of total purchases for the fiscal years ended June 30, 2021, 2020 and 2019, respectively. Purchases from Ablecom and Compuware, related parties of the Company as noted in Note 13, "Related Party Transactions," accounted for a combined 7.8%, 10.1%, and 9.2% of total cost of sales for the fiscal years ended June 30, 2021, 2020 and 2019, respectively.

[0001375365-21-000060:notes:79]
Concentration of Credit Risk

[0001375365-21-000060:notes:80]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales in fiscal years 2021, 2020 and 2019. One customer accounted for 13.5% and 10.1% of accounts receivable, net as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:notes:81]
Treasury Stock

[0001375365-21-000060:notes:82]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-21-000060:notes:83]
Accounting Pronouncements Recently Adopted

[0001375365-21-000060:notes:84]
In June 2016, the FASB issued authoritative guidance, Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments. Under this new guidance, a company is required to estimate credit losses on certain types of financial instruments using an expected-loss model, replacing the current incurred-loss model, and record the estimate through an allowance for credit losses, which results in more timely recognition of credit losses. The Company adopted this guidance on July 1, 2020 using the modified retrospective transition method, which requires a cumulative-effect adjustment, if any, to the opening balance of retained earnings to be recognized on the date of adoption with prior periods not restated. The adoption of the guidance had no material impact on the Company’s consolidated financial statements as of July 1, 2020.

[0001375365-21-000060:notes:85]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's consolidated financial statements for the year ended June 30, 2021.

[0001375365-21-000060:notes:86]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of June 30, 2021, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the consolidated financial statements were immaterial. See Note 2, "Fair Value Disclosure".

[0001375365-21-000060:notes:87]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements and disclosures.

[0001375365-21-000060:notes:88]
Accounting Pronouncements Not Yet Adopted

[0001375365-21-000060:notes:89]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The Company determined that the adoption of the guidance will not have a material impact on the Company's consolidated financial statements and disclosures.

[0001375365-21-000060:notes:90]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued. The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 31, 2022. In January 2021, the FASB issued further guidance on this topic, which clarified the scope and application of the original guidance. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility was amended on June 28, 2021 with a new maturity date of June 28, 2026 and fallback terms related to LIBOR replacement mechanics. As the amendment has changes not related to LIBOR replacement, optional expedients under this guidance cannot be elected. E.SUN Credit Facility will terminate on September 18, 2021 before the phase out of LIBOR. Therefore, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-21-000060:notes:91]
When the Company receives consideration from a customer prior to transferring goods or services to the customer, the Company records a contract liability (deferred revenue). The Company also recognizes deferred revenue when it has an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.
The Company considers shipping & handling activities as costs to fulfill the sales of products. Shipping revenue is included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. Taxes imposed by governmental authorities on the Company's revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales and included in operating expenses.Disaggregation of RevenueThe Company disaggregates revenue by type of product and geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue and are aggregated within the respective categories.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-21-000060:notes:92]
Fair Value DisclosureThe financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of June 30, 2021 and June 30, 2020. See Note 1, "Organization and Summary of Significant Accounting Policies," for a discussion of the Company’s policies regarding the fair value hierarchy. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of June 30, 2021.

[0001375365-21-000060:notes:93]
Financial Assets and Liabilities Measured on a Recurring Basis

[0001375365-21-000060:notes:94]
The following table sets forth the Company’s financial instruments as of June 30, 2021 and 2020, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-21-000060:notes:95]
| June 30, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | 151 |  |
| Certificates of deposit(2) | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Auction rate security | — |  |  | — |  |  | 1,556 |  |  | 1,556 |  |
| Total assets measured at fair value | $ | 151 |  |  | $ | 863 |  |  | $ | 1,556 |  |  | $ | 2,570 |  |
| June 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,163 |  |
| Certificates of deposit(2) | — |  |  | 836 |  |  | — |  |  | 836 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,163 |  |  | $ | 836 |  |  | $ | 1,571 |  |  | $ | 3,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability(3) | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |

[0001375365-21-000060:notes:96]
__________________________

[0001375365-21-000060:notes:97]
(1) $0.0 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.2 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:notes:98]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.4 million and $0.3 million in certificates of deposit are included in restricted cash, non-current in other assets in the consolidated balance sheets as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:notes:99]
(3) As of June 30, 2021, the Company no longer measures performance awards liability at fair value because the Company trued up the performance awards liability to the cash payment value. As of June 30, 2020, the current portion of the performance awards liability of $1.5 million is included in accrued liabilities and the noncurrent portion of $0.6 million is included in other long-term liabilities in the consolidated balance sheets.

[0001375365-21-000060:notes:100]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the fiscal year ended June 30, 2021, the credit losses related to the Company’s investments was not significant.

[0001375365-21-000060:notes:101]
As of June 30, 2020, the Company estimated the fair value of performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of June 30, 2020 are as follows:

[0001375365-21-000060:notes:102]
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $28.39 |  | 1.25 - 2.00 years |  | 0.16% |  | 53.75% |  | — |

[0001375365-21-000060:notes:103]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for fiscal years 2021 and 2020.

[0001375365-21-000060:notes:104]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in fiscal years 2021 and 2020.

[0001375365-21-000060:notes:105]
The following is a summary of the Company’s investment in an auction rate security as of June 30, 2021 and 2020 (in thousands):

[0001375365-21-000060:notes:106]
|  | June 30, 2021 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (194) |  |  | $ | 1,556 |  |

[0001375365-21-000060:notes:107]
|  | June 30, 2020 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179) |  |  | $ | 1,571 |  |

[0001375365-21-000060:notes:108]
For the fiscal year ended June 30, 2021, the Company's loss recognized in other comprehensive income for the auction rate security was immaterial. No gain or loss was recognized in other comprehensive income for the auction rate security for the fiscal years ended June 30, 2020 and 2019.

[0001375365-21-000060:notes:109]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of June 30, 2021 and 2020, total debt of $98.2 million and $29.4 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.

[0001375365-21-000060:notes:110]
Other Financial Assets - Investments into Non-Marketable Equity Securities

[0001375365-21-000060:notes:111]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $0.1 million as of June 30, 2021 and 2020, respectively. The Company accounts for these investments at cost minus impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the years ended June 30, 2021 and 2020, the Company did not record any upward or downward adjustments to the carrying values of the non-marketable equity securities related to observable price changes. The Company also did not record any impairment to the carrying values of the non-marketable equity securities during fiscal year 2021 and 2020. During fiscal year 2019, the Company recorded impairment charges of $2.7 million for its non-marketable equity securities which had an initial cost basis of $2.7 million as it was determined the carrying value of the investments were not recoverable.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-21-000060:notes:112]
Revenue
    Disaggregation of Revenue

[0001375365-21-000060:notes:113]
The Company disaggregates revenue by type of product and geographical market in order to depict the nature, amount, and timing of revenue and cash flows. Service revenues, which are less than 10%, are not a significant component of total revenue and are aggregated within the respective categories.

[0001375365-21-000060:notes:114]
The following is a summary of net sales by product type (in thousands):

[0001375365-21-000060:notes:115]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Server and storage systems | $ | 2,790,305 |  |  | $ | 2,620,754 |  |  | $ | 2,858,644 |  |
| Subsystems and accessories | 767,117 |  |  | 718,527 |  |  | 641,716 |  |
| Total | $ | 3,557,422 |  |  | $ | 3,339,281 |  |  | $ | 3,500,360 |  |

[0001375365-21-000060:notes:116]
Server and storage systems constitute an assembly and integration of subsystems and accessories, and related services.

[0001375365-21-000060:notes:117]
Subsystems and accessories are comprised of serverboards, chassis and accessories.

[0001375365-21-000060:notes:118]
International net sales are based on the country and geographical region to which the products were shipped. The following is a summary of net sales by geographic region (in thousands):

[0001375365-21-000060:notes:119]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| United States | $ | 2,107,910 |  |  | $ | 1,957,329 |  |  | $ | 2,032,948 |  |
| Asia | 699,653 |  |  | 650,652 |  |  | 712,211 |  |
| Europe | 614,826 |  |  | 598,558 |  |  | 611,014 |  |
| Other | 135,033 |  |  | 132,742 |  |  | 144,187 |  |
| Total | $ | 3,557,422 |  |  | $ | 3,339,281 |  |  | $ | 3,500,360 |  |

[0001375365-21-000060:notes:120]
Starting July 1, 2020, the Company does not separately disclose revenue by products sold to indirect sales channel partners or direct customers and original equipment manufacturers because management does not make business operational decisions based on this set of disaggregation so the disclosure is no longer material to investors.

[0001375365-21-000060:notes:121]
Contract Balances

[0001375365-21-000060:notes:122]
Generally, the payment terms of the Company’s offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables relate to the Company’s unconditional right to consideration for performance obligations either partially or fully completed.

[0001375365-21-000060:notes:123]
Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to the Company’s consolidated financial statements.

[0001375365-21-000060:notes:124]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during fiscal year ended June 30, 2021, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $101.6 million.

[0001375365-21-000060:notes:125]
Deferred revenue decreased $1.5 million during the fiscal year ended June 30, 2021 as compared to the fiscal year ended June 30, 2020 mainly due to the recognition of revenue from contracts entered into in prior periods exceeding the value of the transaction price allocated for service contract performance obligations during the fiscal year ended June 30, 2021.

[0001375365-21-000060:notes:126]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-21-000060:notes:127]
Remaining performance obligations represent the aggregate the amount of transaction price that is allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services. that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of June 30, 2021 was approximately $202.3 million. The Company expects to recognize approximately 50% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-21-000060:notes:128]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-21-000060:notes:129]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

[0001375365-21-000060:notes:130]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-21-000060:notes:131]
The following is a summary of net sales by geographic region (in thousands):


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001375365-21-000060:notes:132]
Accounts Receivable Allowances
    The Company has established an allowance for doubtful accounts. The allowance for doubtful accounts is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2021, 2020 and 2019 consisted of the following (in thousands):

[0001375365-21-000060:notes:133]
|  | BeginningBalance |  | Charged toCost andExpenses (Recovered), net |  | Write-offs |  | EndingBalance |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |
| Year ended June 30, 2021 | $ | 4,586 |  |  | $ | (820) |  |  | $ | (1,175) |  |  | $ | 2,591 |  |
| Year ended June 30, 2020 | 8,906 |  |  | (3,081) |  |  | (1,239) |  |  | 4,586 |  |
| Year ended June 30, 2019 | 1,945 |  |  | 7,058 |  |  | (97) |  |  | 8,906 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001375365-21-000060:notes:134]
Inventories 
Inventories as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:135]
|  | June 30, |
|  | 2021 |  | 2020 |
| Finished goods | $ | 761,694 |  |  | $ | 656,817 |  |
| Work in process | 80,472 |  |  | 38,146 |  |
| Purchased parts and raw materials | 198,798 |  |  | 156,535 |  |
| Total inventories | $ | 1,040,964 |  |  | $ | 851,498 |  |

[0001375365-21-000060:notes:136]
During fiscal years 2021, 2020 and 2019, the Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $6.8 million, $18.4 million and $32.9 million, respectively. The Company classifies subsystems and accessories that may be sold separately or incorporated into systems as finished goods.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001375365-21-000060:notes:137]
Property, Plant, and Equipment
    Property, plant and equipment as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:138]
|  | June 30, |
|  | 2021 |  | 2020 |
| Buildings | $ | 86,930 |  |  | $ | 86,930 |  |
| Land | 76,421 |  |  | 75,251 |  |
| Machinery and equipment | 97,671 |  |  | 85,381 |  |
| Buildings construction in progress(1) | 87,438 |  |  | 46,311 |  |
| Building and leasehold improvements | 26,640 |  |  | 24,517 |  |
| Software | 22,592 |  |  | 20,597 |  |
| Furniture and fixtures | 22,843 |  |  | 21,544 |  |
|  | 420,535 |  |  | 360,531 |  |
| Accumulated depreciation and amortization | (145,822) |  |  | (126,746) |  |
| Property, plant and equipment, net | $ | 274,713 |  |  | $ | 233,785 |  |

[0001375365-21-000060:notes:139]
(1) Primarily relates to the development and construction costs associated with the Company’s Green Computing Park located in San Jose, California and a new building in Taiwan.


## us-gaap:OtherAssetsDisclosureTextBlock

[0001375365-21-000060:notes:140]
Prepaid Expenses and Other Assets
Prepaid expenses and other current assets as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:141]
|  | June 30, |
|  | 2021 |  | 2020 |
| Other receivables(1) | $ | 99,921 |  |  | $ | 96,669 |  |
| Prepaid income tax | 12,288 |  |  | 14,323 |  |
| Prepaid expenses | 6,719 |  |  | 7,075 |  |
| Deferred service costs | 4,900 |  |  | 4,161 |  |
| Restricted cash | 251 |  |  | 250 |  |
| Others | 6,116 |  |  | 4,507 |  |
| Total prepaid expenses and other current assets | $ | 130,195 |  |  | $ | 126,985 |  |

[0001375365-21-000060:notes:142]
(1) Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $76.2 million and $83.8 million as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:notes:143]
Other assets as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:144]
|  | June 30, |
|  | 2021 |  | 2020 |
| Operating lease right-of-use asset | $ | 20,047 |  |  | $ | 23,784 |  |
| Deferred service costs, non-current | 5,421 |  |  | 4,632 |  |
| Deposits | 1,669 |  |  | 1,201 |  |
| Prepaid expense, non-current | 1,973 |  |  | 1,576 |  |
| Investment in auction rate security | 1,556 |  |  | 1,571 |  |
| Restricted cash, non-current | 932 |  |  | 1,607 |  |
| Others | 528 |  |  | 128 |  |
| Total other assets | $ | 32,126 |  |  | $ | 34,499 |  |

[0001375365-21-000060:notes:145]
Cash, cash equivalents and restricted cash as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:146]
|  | June 30, |
|  | 2021 |  | 2020 |
| Cash and cash equivalents | $ | 232,266 |  |  | $ | 210,533 |  |
| Restricted cash included in prepaid expenses and other current assets | 251 |  |  | 250 |  |
| Restricted cash included in other assets | 932 |  |  | 1,607 |  |
| Total cash, cash equivalents and restricted cash | $ | 233,449 |  |  | $ | 212,390 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001375365-21-000060:notes:147]
Investment in a Corporate Venture
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in the Corporate Venture to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment has been accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-21-000060:notes:148]
The Company recorded a deferred gain related to the contribution of certain technology rights.  As of June 30, 2021 and 2020, the Company had unamortized deferred gain balance of $1.0 million and $2.0 million, respectively, in accrued liabilities and $0.0 million and $1.0 million, respectively, in other long-term liabilities in the Company’s consolidated balance sheets.

[0001375365-21-000060:notes:149]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with

[0001375365-21-000060:notes:150]
several of such third-party parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of June 30, 2021. No impairment charge was recorded for the fiscal years ended June 30, 2021 and 2020.

[0001375365-21-000060:notes:151]
The Company sold products worth $51.2 million, $61.9 million, $52.2 million to the Corporate Venture in the fiscal years 2021, 2020, 2019, respectively, and the Company's share of intra-entity profits on the products that remained unsold by the Corporate Venture as of June 30, 2021 and June 30, 2020 have been eliminated and have reduced the carrying value of the Company's investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $8.5 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of June 30, 2021 and 2020, respectively.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001375365-21-000060:notes:152]
Accrued Liabilities
Accrued liabilities as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:153]
|  | June 30, |
|  | 2021 |  | 2020 |
| Accrued payroll and related expenses | $ | 45,770 |  |  | $ | 33,577 |  |
| Contract manufacturers liabilities | 45,319 |  |  | 36,249 |  |
| Customer deposits | 32,419 |  |  | 9,942 |  |
| Accrued warranty costs | 10,185 |  |  | 9,984 |  |
| Operating lease liability | 6,322 |  |  | 6,310 |  |
| Accrued cooperative marketing expenses | 5,652 |  |  | 5,925 |  |
| Accrued professional fees | 2,737 |  |  | 5,661 |  |
| Accrued legal liabilities | — |  |  | 18,114 |  |
| Others | 30,446 |  |  | 29,639 |  |
| Total accrued liabilities | $ | 178,850 |  |  | $ | 155,401 |  |

[0001375365-21-000060:notes:154]
Performance Awards Liability

[0001375365-21-000060:notes:155]
In March 2020, the Board of Directors (the “Board”) approved performance bonuses for the Chief Executive Officer, a senior executive and two members of the Board, which payments will be earned when specified market and performance conditions are achieved.

[0001375365-21-000060:notes:156]
The Chief Executive Officer’s aggregate cash bonuses of up to $8.1 million are earned in two tranches. The first 50% is payable if the average closing price for the Company’s common stock equals or exceeds $31.61 for any period of 20 consecutive trading days following the date of the agreement and ending prior to September 30, 2021 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is determined to have been achieved. This payment can be reduced at the discretion of the Board to the extent the Company has not made adequate progress in remediating its material weaknesses in its internal control over financial reporting as determined by the Board. The second 50% is payable if the average closing price for the Company’s common stock equals or exceeds $32.99 for any period of 20 consecutive trading days following the date of the agreement and ending prior to June 30, 2022 and the Chief Executive Officer remains employed with the Company through the date that such common stock price goal is achieved. During the fiscal year ended June 30, 2021, the target average closing prices for both tranches were met but no determination has been made if there has been adequate progress in remediating the Company’s internal weaknesses in its internal control over financial reporting. The cash payment under the second tranche has been made as of June 30, 2021, but no cash payment had been made for the first tranche as the Board has to approve this payment.

[0001375365-21-000060:notes:157]
Performance bonuses for a senior executive and two members of the Board are earned based on achieving a specified target average closing price for the Company’s common stock over the specified period as determined by the Board at the grant dates and continuous services through the payment dates. A senior executive earned an aggregate cash payment of $0.1 million when the target average closing price was met in the fourth quarter of fiscal year 2020. The two members of the Board can earn aggregate cash payments of $0.3 million in two tranches if the target average closing price reaches $31.61 for the first tranche and $32.99 per share for the second tranche. During the fiscal year ended June 30, 2021, the target average closing prices for both tranches were met and the cash payment for both tranches was made to the two Board members.

[0001375365-21-000060:notes:158]
The Company accounts for the outstanding performance bonuses as liabilities and estimates fair value of payable amounts using a Monte-Carlo simulation model. The awards are re-measured at each period end with changes in fair value recorded in the Company’s consolidated statement of operations in operating expenses. The cumulative recorded expense at each period end is trued-up to the expected payable amount vested through the period end. The requisite service periods over which expenses are recognized are derived from the Monte-Carlo model for all performance awards, except for the first 50% of the Chief Executive Officer’s award that includes a performance condition. The Company estimates if it is probable that the performance condition will be met prior to the expiration date of this award. If at the measurement date it is determined to be probable, the Company estimates the requisite period as the longer of the service period derived by the Monte-Carlo model and the implicit service period when the Company expects to make adequate progress in remediating its material weaknesses in its internal control over financial reporting, as reported by the Company's Audit Committee. If it is determined to not be probable,

[0001375365-21-000060:notes:159]
then the Company will reverse any previously recognized expense for this award in the period when it is no longer probable that the performance condition will be achieved.

[0001375365-21-000060:notes:160]
With the satisfaction of the target average closing price conditions in the fiscal year ended June 30, 2021, the Company trued up all the unpaid performance bonuses to the cash payment value. As of June 30, 2021, the full cash value of the bonuses were paid, except the Chief Executive Officer's first tranche performance bonus which was recorded as an accrued liability on the Company's consolidated balance sheet. The Company has completed the remediation of its material weaknesses in its internal control over financial reporting, and anticipates that the Board will conclude that there has been adequate progress in remediating the Company's material weaknesses in its internal control over financial reporting by October 31, 2021.  Therefore, as of June 30, 2021, the Company trued up the accrued liability for the Chief Executive Officer’s first tranche award to the expected payable amount vested through the period end and the unrecognized cash value will be recorded over the remaining service period.

[0001375365-21-000060:notes:161]
Based on the cash payment value and estimated fair value of these performance bonuses as of June 30, 2021 and June 30, 2020, the Company recorded a $3.6 million and $2.1 million liability, respectively, of which $3.6 million and $1.5 million, respectively, was recorded within accrued liabilities and $0.0 million and $0.6 million, respectively, was recorded within other long-term liabilities on the Company's consolidated balance sheet. An unrecognized compensation expense of $0.5 million will be recorded over the remaining service periods of 0.18 years. The expense recognized during fiscal years 2021 and 2020 was $5.8 million and $2.1 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001375365-21-000060:notes:162]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:163]
|  | June 30, |
|  | 2021 |  | 2020 |
| Line of credit: |  |  |  |
| CTBC Bank | $ | 18,000 |  |  | $ | — |  |
| E.SUN Bank | 20,400 |  |  | — |  |
| Total line of credit | 38,400 |  |  | — |  |
| Term loans: |  |  |  |
| CTBC Bank, due August 31, 2021 | 25,090 |  |  | 23,704 |  |
| CTBC Bank, due June 4, 2030 | 34,700 |  |  | 5,697 |  |
| Total term loans | 59,790 |  |  | 29,401 |  |
| Total debt | 98,190 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 63,490 |  |  | 23,704 |  |
| Debt, Non-current | $ | 34,700 |  |  | $ | 5,697 |  |

[0001375365-21-000060:notes:164]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-21-000060:notes:165]
Bank of America

[0001375365-21-000060:notes:166]
2018 Bank of America Credit Facility

[0001375365-21-000060:notes:167]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million, increase the maximum amount that the Company can request the facility be increased (the accordion feature) from $100.0 million to $150.0 million, and update provisions relating to erroneous payments and LIBOR replacement mechanics. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum.

[0001375365-21-000060:notes:168]
The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-21-000060:notes:169]
As of June 30, 2021 and 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of June 30, 2021 and 2020 were 1.50% and 3.00%, respectively. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amount was drawn under the standby letter of credit. In May 2021, the letter of credit was cancelled. The balance of debt issuance costs outstanding were $0.5 million and $0.6 million as of June 30, 2021 and 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of June 30, 2021, the Company's available borrowing capacity was $200.0 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-21-000060:notes:170]
CTBC Bank

[0001375365-21-000060:notes:171]
CTBC Credit Facility

[0001375365-21-000060:notes:172]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. In February 2021, CTBC Bank amended the USD interest rate to be the lender's established USD interest rate plus 0.70% to 0.75% per annum which is adjusted monthly. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

[0001375365-21-000060:notes:173]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.1 million and $23.7 million at June 30, 2021 and 2020, respectively. The interest rate for these loans were 0.75%  per annum as of June 30, 2021 and 0.63% per annum as of June 30, 2020. As of June 30, 2021 and 2020, the outstanding borrowings under the CTBC Credit Facility revolving line of credit were $18.0 million and $0.0 million, respectively. The interest rate was 0.98% per annum as of June 30, 2021. As of June 30, 2021, the amount available for future borrowing under the CTBC Credit Facility was $6.9 million. As of June 30, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $24.8 million.

[0001375365-21-000060:notes:174]
2020 CTBC Term Loan Facility due June 4, 2030

[0001375365-21-000060:notes:175]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term

[0001375365-21-000060:notes:176]
floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

[0001375365-21-000060:notes:177]
As of June 30, 2021 and 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $34.7 million and $5.7 million, respectively. The interest rates for these loans were 0.45%  per annum as of June 30, 2021 and June 30, 2020. The net book value of the property serving as collateral as of June 30, 2021 was $45.9 million. As of June 30, 2021, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000060:notes:178]
2021 CTBC Credit Lines

[0001375365-21-000060:notes:179]
On July 20, 2021 (the “Effective Date”), the Company entered into a general agreement for omnibus credit lines with CTBC Bank, which replaced the CTBC Credit Facility and 2020 CTBC Term Loan Facility (the “Prior CTBC Credit Lines”) in their entirety and permit borrowings, from time to time, of (i) a term loan facility of up to NTD 1,550.0 million ($55.4 million in U.S. dollar equivalents) and (ii) a line of credit facility of up to US$105.0 million (the “2021 CTBC Credit Lines”). Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of the Company’s assets, including certain property, land, plant, and equipment. As of June 30, 2021, the net book value of land and building located in Bade, Taiwan, collateralizing the New CTBC Credit Facility term loan was $70.7 million. The Company is subject to various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-21-000060:notes:180]
E.SUN Bank Credit Facility

[0001375365-21-000060:notes:181]
In December 2020, Super Micro Computer Inc, Taiwan, a wholly-owned Taiwan subsidiary of the Company, entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. The E.SUN Credit Facility provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. The E.SUN Credit Facility expires on September 18, 2021.

[0001375365-21-000060:notes:182]
Generally, the interest for base rate loans made under the E.SUN Credit Facility is based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment. Interest for adjustable loan rate loans made under the E.SUN Credit Facility is based upon an average one-year fixed rate time saving deposit rate of a selected reference bank which shall be a well-known domestic bank in Taiwan, and is subject to occasional adjustment. The E.SUN Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event such Taiwan subsidiary of the Company has an overdue liability at another financial organization. There are no financial covenants associated with the E.SUN Credit Facility.

[0001375365-21-000060:notes:183]
Terms for specific drawdown instruments issued under the E.SUN Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions by and between the Company and E.SUN Bank. A Notification and Confirmation of Credit Conditions agreement under the E.SUN Credit Facility was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days. In June 2021, the Import Loan was amended to, among other items, bearing interest at a rate based on the higher of LIBOR plus 1.00% then divided by 0.946 or TAIFX plus 0.80% then divided by 0.946. As of June 30, 2021, the amounts outstanding under the E.SUN Credit Facility was $20.4 million and the interest rates for these loans ranged from approximately 1.0% to 1.29% per annum. As of June 30, 2021, the amount available for future borrowing under the E.SUN Credit Facility was $9.6 million.

[0001375365-21-000060:notes:184]
Principal payments on short-term and long-term debt obligations are due as follows (in thousands):

[0001375365-21-000060:notes:185]
| Fiscal Year: | Principal Payments |
| 2022 | $ | 63,490 |  |
| 2023 | 413 |  |
| 2024 | 4,957 |  |
| 2025 | 4,957 |  |
| 2026 | 4,957 |  |
| 2027 and thereafter | 19,416 |  |
| Total short-term and long-term debt | $ | 98,190 |  |


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001375365-21-000060:notes:186]
Other Long-term Liabilities
Other long-term liabilities as of June 30, 2021 and 2020 consisted of the following (in thousands):

[0001375365-21-000060:notes:187]
|  | June 30, |
|  | 2021 |  | 2020 |
| Accrued unrecognized tax benefits including related interest and penalties | $ | 17,841 |  |  | $ | 15,496 |  |
| Operating lease liability, non-current | 14,539 |  |  | 18,102 |  |
| Accrued warranty costs, non-current | 2,678 |  |  | 2,395 |  |
| Others | 6,074 |  |  | 6,002 |  |
| Total other long-term liabilities | $ | 41,132 |  |  | $ | 41,995 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-21-000060:notes:188]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the years ended June 30, 2021 and 2020 were as follows (in thousands):

[0001375365-21-000060:notes:189]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |
| Operating lease expense (including expense for lease agreements with related parties of $1,319 and $1,421 for the years ended June 30, 2021 and 2020, respectively) | $ | 7,827 |  |  | $ | 6,993 |  |
| Cash payments for operating leases (including payments to related parties of $1,351 and $1,443 for the years ended June 30, 2021 and 2020, respectively) | 7,966 |  |  | 6,411 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | 3,538 |  |  | 15,229 |  |

[0001375365-21-000060:notes:190]
During the years ended June 30, 2021 and 2020, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the years ended June 30, 2021, 2020 and 2019 were $1.8 million, $1.3 million and $0.0 million, respectively.

[0001375365-21-000060:notes:191]
As of June 30, 2021, the weighted average remaining lease term for operating leases was 3.8 years and the weighted average discount rate was 3.4%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of June 30, 2021 were as follows (in thousands):

[0001375365-21-000060:notes:192]
| Fiscal Year: |  | Maturities of operating leases |
| 2022 |  | $ | 6,932 |  |
| 2023 |  | 5,430 |  |
| 2024 |  | 4,538 |  |
| 2025 |  | 4,382 |  |
| 2026 and beyond |  | 1,017 |  |
| Total future lease payments |  | $ | 22,299 |  |
| Less: Imputed interest |  | (1,438) |  |
| Present value of operating lease liabilities |  | $ | 20,861 |  |

[0001375365-21-000060:notes:193]
As of June 30, 2021, commitments under short-term lease arrangements and operating and financing leases that have not yet commenced were immaterial.

[0001375365-21-000060:notes:194]
The Company has entered into lease agreements with related parties.  See Note 13, "Related Party Transactions" for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-21-000060:notes:195]
Related Party Transactions
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of June 30, 2021. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Charles Liang or Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware's capital stock.

[0001375365-21-000060:notes:196]
Dealings with Ablecom

[0001375365-21-000060:notes:197]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-21-000060:notes:198]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 91.8%, 95.5% and 96.3% of the chassis included in the products sold by the Company during fiscal years 2021, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-21-000060:notes:199]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-21-000060:notes:200]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $40.2 million and $23.2 million at June 30, 2021 and 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-21-000060:notes:201]
Dealings with Compuware

[0001375365-21-000060:notes:202]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-21-000060:notes:203]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-21-000060:notes:204]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-21-000060:notes:205]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-21-000060:notes:206]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $71.0 million and $45.7 million at June 30, 2021 and 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-21-000060:notes:207]
The Company’s results from transactions with Ablecom and Compuware for each of the fiscal years ended June 30, 2021, 2020 and 2019 are as follows (in thousands):

[0001375365-21-000060:notes:208]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |
| Purchases(1) | $ | 130,852 |  |  | $ | 160,084 |  |  | $ | 145,273 |  |
| Compuware |  |  |  |  |  |
| Net sales | $ | 27,865 |  |  | $ | 23,867 |  |  | $ | 17,651 |  |
| Purchases(1) | 115,213 |  |  | 131,763 |  |  | 139,579 |  |

[0001375365-21-000060:notes:209]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-21-000060:notes:210]
The Company's net sales to Ablecom were not material for the fiscal years ended June 30, 2021, 2020 and 2019.

[0001375365-21-000060:notes:211]
The Company had the following balances related to transactions with Ablecom and Compuware as of June 30, 2021 and 2020 (in thousands):

[0001375365-21-000060:notes:212]
|  | June 30, |
|  | 2021 |  | 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables(1) | $ | 5,577 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities(2) | 41,194 |  |  | 40,056 |  |
| Other long-term liabilities(3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables(1) | 18,371 |  |  | 14,323 |  |
| Accounts payable and accrued liabilities(2) | 46,430 |  |  | 46,518 |  |
| Other long-term liabilities(3) | — |  |  | 186 |  |

[0001375365-21-000060:notes:213]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.

[0001375365-21-000060:notes:214]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-21-000060:notes:215]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-21-000060:notes:216]
The Company procures certain semiconductor products from Monolithic Power Systems, Inc. (“MPS”), a fabless manufacturer of high-performance analog and mixed-signal semiconductors, for use in its products. Saria Tseng, who serves as a member on the Board of Directors, also serves as Vice President of Strategic Corporate Development, General Counsel and Secretary of MPS. The Company purchased $3.9 million, $5.2 million and $3.7 million of semiconductor products from MPS for use in its manufacturing process during the years ended June 30, 2021, 2020 and 2019, respectively. The amounts due to MPS as of June 30, 2021 and 2020 were not material.

[0001375365-21-000060:notes:217]
See Note 8, "Investment in a Corporate Venture" for a discussion of the investment and the transactions and balances in the Company's Corporate Venture.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-21-000060:notes:218]
Stock-based Compensation and Stockholders’ Equity
Equity Incentive Plan

[0001375365-21-000060:notes:219]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the "2020 Plan"). The maximum number of shares available under the 2020 Plan is 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remain reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the 2020 Plan.

[0001375365-21-000060:notes:220]
Under the 2020 Plan, the Company can grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, the Company’s common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company's outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-21-000060:notes:221]
As of June 30, 2021, the Company had 2,730,277 authorized shares available for future issuance under the 2020 Plan.

[0001375365-21-000060:notes:222]
Common Stock Repurchase and Retirement

[0001375365-21-000060:notes:223]
On August 9, 2020, the Board approved a share repurchase program to repurchase up to an aggregate of $30.0 million of the Company's common stock at market prices. The program was effective until December 31, 2020 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended September 30, 2020, 1,142,294 shares of common stock were repurchased for $30.0 million and the program ended. Repurchased shares were recorded as treasury shares in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000060:notes:224]
On December 11, 2020, the Company retired 2,475,419 shares of common stock, which were recorded as treasury stock in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000060:notes:225]
On October 31, 2020, the Board approved a share repurchase program to repurchase up to an aggregate of $50.0 million of the Company's common stock at market prices. The program was effective until October 31, 2021 or if earlier, until the maximum amount of common stock was repurchased. As of March 31, 2021, 1,675,746 shares of common stock were repurchased and retired for an aggregate $50.0 million and the program ended.

[0001375365-21-000060:notes:226]
On January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase up to an aggregate of $200.0 million of the Company's common stock at market prices. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased. 1,391,171 shares of common stock were repurchased and retired for an aggregate $50.0 million as of June 30, 2021.

[0001375365-21-000060:notes:227]
During the fiscal year ended June 30, 2021, the Company repurchased and retired 4,209,211 shares of common stock for an aggregated $130.0 million. Additionally, the Company retired 1,333,125 shares of common stock repurchased in prior years.

[0001375365-21-000060:notes:228]
Determining Fair Value

[0001375365-21-000060:notes:229]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-21-000060:notes:230]
Expected Term—The Company’s expected term represents the period that the Company’s stock-based awards are expected to be outstanding and was determined based on the Company's historical experience.

[0001375365-21-000060:notes:231]
Expected Volatility—Expected volatility is based on the Company's implied and historical volatility.

[0001375365-21-000060:notes:232]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the Company has no plans to pay dividends.

[0001375365-21-000060:notes:233]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-21-000060:notes:234]
The fair value of stock option grants for the fiscal years ended June 30, 2021, 2020 and 2019 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-21-000060:notes:235]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Risk-free interest rate | 0.27% - 1.09% |  | 0.47% - 1.72% |  | 2.32% - 2.97% |
| Expected term | 5.98 years |  | 6.27 years |  | 6.05 years |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 50.03% - 50.43% |  | 49.61% - 50.46% |  | 47.34% - 50.28% |
| Weighted-average fair value | $ | 14.92 |  |  | $ | 9.59 |  |  | $ | 9.25 |  |

[0001375365-21-000060:notes:236]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2021, 2020 and 2019 (in thousands):

[0001375365-21-000060:notes:237]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Cost of sales | $ | 1,762 |  |  | $ | 1,504 |  |  | $ | 1,663 |  |
| Research and development | 14,030 |  |  | 12,202 |  |  | 12,981 |  |
| Sales and marketing | 2,022 |  |  | 1,680 |  |  | 1,805 |  |
| General and administrative | 10,735 |  |  | 4,803 |  |  | 4,735 |  |
| Stock-based compensation expense before taxes | 28,549 |  |  | 20,189 |  |  | 21,184 |  |
| Income tax impact | (8,574) |  |  | (6,814) |  |  | (4,349) |  |
| Stock-based compensation expense, net | $ | 19,975 |  |  | $ | 13,375 |  |  | $ | 16,835 |  |

[0001375365-21-000060:notes:238]
As of June 30, 2021, $8.4 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 4 years, $45.1 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.73 years and $0.1 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.36 year. Additionally, as described below, $10.5 million of unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 5 years.

[0001375365-21-000060:notes:239]
Stock Option Activity

[0001375365-21-000060:notes:240]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 1,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). The 2021 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between the Company’s CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2021 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $120.00 per share thereafter (based on a 60 calendar day average, counting only trading days), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to March 2, 2024, the Company’s CEO must hold shares that he acquires until March 2, 2024, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-21-000060:notes:241]
The achievement status of the operational and stock price milestones as of June 30, 2021 was as follows:

[0001375365-21-000060:notes:242]
| Annualized Revenue Milestone |  | Achievement Status | Stock Price Milestone | Achievement Status |  |
| (in billions) |  |  |  |  |  |

[0001375365-21-000060:notes:243]
| $4.0 |  | Probable | $45 | Not met |  |
| $4.8 |  | Probable | $60 | Not met |  |
| $5.8 |  | Probable | $75 | Not met |  |
| $6.8 |  | Probable | $95 | Not met |  |
| $8.0 |  | — | $120 | Not met |  |

[0001375365-21-000060:notes:244]
On the grant date, a Monte Carlo simulation was used to determine for each tranche (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-21-000060:notes:245]
During the fiscal year ended June 30, 2021, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $1.1 million. As of June 30, 2021, $10.5 million in unrecognized compensation cost related to the 2021 CEO Performance Stock Option is expected to be recognized over a period of 5 years.

[0001375365-21-000060:notes:246]
The following table summarizes stock option activity during the fiscal years ended June 30, 2021, 2020 and 2019 under all plans:

[0001375365-21-000060:notes:247]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2018 |  | 8,301,138 |  |  | $ | 16.50 |  |  |  |  |  |
| Granted |  | 434,320 |  |  | $ | 18.58 |  |  |  |  |  |
| Forfeited/Cancelled |  | (1,360,823) |  |  | $ | 8.94 |  |  |  |  |  |
| Balance as of June 30, 2019 |  | 7,374,635 |  |  | $ | 18.02 |  |  |  |  |  |
| Granted |  | 273,260 |  |  | $ | 19.61 |  |  |  |  |  |
| Exercised |  | (1,812,000) |  |  | $ | 15.74 |  |  |  |  |  |
| Forfeited/Cancelled |  | (456,127) |  |  | $ | 11.97 |  |  |  |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  |  |  |  |
| Granted |  | 1,517,110 |  |  | $ | 40.49 |  |  |  |  |  |
| Exercised |  | (1,645,800) |  |  | $ | 17.25 |  |  |  |  |  |
| Forfeited/Cancelled |  | (75,524) |  |  | $ | 24.43 |  |  |  |  |  |
| Balance as of June 30, 2021 |  | 5,175,554 |  |  | $ | 26.17 |  |  | 5.36 |  | $ | 57,099 |  |
| Options vested and exercisable at June 30, 2021 |  | 3,448,888 |  |  | $ | 20.47 |  |  | 3.41 |  | $ | 50,887 |  |

[0001375365-21-000060:notes:248]
The total pretax intrinsic value of options exercised during the fiscal year ended June 30, 2021, 2020 and 2019 was $24.3 million, $19.3 million and $0, respectively. Additional information regarding options outstanding as of June 30, 2021, is as follows:

[0001375365-21-000060:notes:249]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $9.24 - $12.50 |  | 521,886 |  |  | 1.54 |  | $ | 10.81 |  |  | 521,886 |  |  | $ | 10.81 |  |
| $13.00 - $15.22 |  | 540,699 |  |  | 2.68 |  | $ | 14.33 |  |  | 490,794 |  |  | $ | 14.40 |  |
| $17.09 - $18.93 |  | 714,906 |  |  | 3.17 |  | $ | 17.94 |  |  | 648,411 |  |  | $ | 17.97 |  |
| $20.37 - $22.10 |  | 619,745 |  |  | 4.90 |  | $ | 21.13 |  |  | 547,375 |  |  | $ | 21.10 |  |
| $22.15 - $25.44 |  | 614,906 |  |  | 5.81 |  | $ | 24.26 |  |  | 436,968 |  |  | $ | 24.67 |  |
| $26.60 - $28.71 |  | 536,681 |  |  | 4.69 |  | $ | 27.08 |  |  | 529,181 |  |  | $ | 27.06 |  |
| $30.33 - $38.50 |  | 590,341 |  |  | 7.26 |  | $ | 34.31 |  |  | 246,273 |  |  | $ | 34.48 |  |
| $39.19 - $39.19 |  | 28,000 |  |  | 3.62 |  | $ | 39.19 |  |  | 28,000 |  |  | $ | 39.19 |  |
| $42.35 - $42.35 |  | 8,390 |  |  | 4.82 |  | $ | 42.35 |  |  | — |  |  | $ | — |  |
| $45.00 - $45.00 |  | 1,000,000 |  |  | 9.67 |  | $ | 45.00 |  |  | — |  |  | $ | — |  |
| $9.24 - $45.00 |  | 5,175,554 |  |  | 5.36 |  | $ | 26.17 |  |  | 3,448,888 |  |  | $ | 20.47 |  |

[0001375365-21-000060:notes:250]
RSU and PRSU Activity

[0001375365-21-000060:notes:251]
In January 2015, the Company began to grant RSUs to employees. The Company grants RSUs to certain employees as part of its regular employee equity compensation review program as well as to selected new hires. RSUs are typically service based share awards that entitle the holder to receive freely tradable shares of the Company's common stock upon vesting.

[0001375365-21-000060:notes:252]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. 50% of the PRSUs vested at June 30, 2018 when performance conditions were achieved, while the remainder vest in equal amounts over the following ten quarters subject to the continued employment of the CEO. As of June 30, 2021, the remaining 50% of the PRSUs had vested in accordance with the terms of the grant.

[0001375365-21-000060:notes:253]
In March 2020, the Compensation Committee granted a PRSU award to one of the Company's senior executives. The award vests in two tranches and includes service and performance conditions. Each tranche has 15,000 RSUs that vest in May 2021 and November 2021 based on service conditions only. Additional units can be earned based on revenue growth percentage in fiscal year 2020 compared to fiscal year 2019, which units would vest in May 2021, and based on revenue growth percentage in fiscal year 2021 compared to fiscal year 2020, which units would vest in November 2021. No additional units were earned for fiscal year 2020 as revenue decreased from fiscal year 2019.

[0001375365-21-000060:notes:254]
The following table summarizes RSUs and PRSUs activity during the fiscal years ended June 30, 2021 and 2020 under all plans:

[0001375365-21-000060:notes:255]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUs Outstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2018 |  | 1,480,605 |  |  | $ | 23.34 |  |  | 120,000 |  |  |  | $ | 27.10 |  |
| Granted |  | 1,086,911 |  |  | $ | 18.37 |  |  | — |  |  |  |  |
| Released(1) |  | (549,886) |  |  | $ | 24.87 |  |  | — |  |  |  |  |
| Forfeited |  | (144,528) |  |  | $ | 20.25 |  |  | — |  |  |  |  |
| Balance as of June 30, 2019 |  | 1,873,102 |  |  | $ | 20.25 |  |  | 120,000 |  |  |  | $ | 27.10 |  |
| Granted |  | 943,650 |  |  | $ | 20.45 |  |  | 30,000 |  |  |  | $ | 20.37 |  |
| Released(1) |  | (871,274) |  |  | $ | 20.97 |  |  | (108,000) |  |  |  | $ | 27.10 |  |
| Forfeited |  | (177,451) |  |  | $ | 19.49 |  |  | — |  |  |  |  |
| Balance as of June 30, 2020 |  | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  |  |  | $ | 22.29 |  |
| Granted |  | 1,334,418 |  |  | $ | 31.54 |  |  | 30,000 |  |  |  | $ | 34.27 |  |
| Released(1) |  | (984,406) |  |  | $ | 21.63 |  |  | (27,000) |  |  |  | $ | 23.36 |  |
| Forfeited |  | (263,083) |  |  | $ | 25.01 |  |  | (30,000) |  |  |  | $ | 20.37 |  |
| Balance as of June 30, 2021 |  | 1,854,956 |  |  | $ | 26.79 |  |  | 15,000 |  |  |  | $ | 34.27 |  |

[0001375365-21-000060:notes:256]
_________________

[0001375365-21-000060:notes:257]
(1)    The number of shares released excludes 172,857 RSUs that were vested but not released in fiscal year 2019. The number of vested but not released RSUs for fiscal years 2021 and 2020 was not material. The number of shares released also excludes 24,000 PRSUs that were vested but not released in fiscal year 2019. These vested RSUs and PRSUs were primarily released in fiscal year 2020 and included in fiscal year 2020 number upon the effectiveness of the Company's registration statement on Form S-8.

[0001375365-21-000060:notes:258]
The total pretax intrinsic value of RSUs and PRSUs vested was $32.6 million, $18.9 million and $14.3 million for the fiscal years ended June 30, 2021, 2020 and 2019, respectively. In fiscal years 2021, 2020 and 2019, the Company withheld 274,620, 331,648 and 175,044 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes from the vesting and release of 1,011,406, 979,274 and 549,886 RSUs and PRSUs, respectively, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the RSUs on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to tax authorities were $8.7 million, $8.2 million and $3.1 million for the fiscal years ended June 30, 2021, 2020 and 2019, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2020 and 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2020 and 2016 Plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-21-000060:notes:259]
Income Taxes
The components of income before income tax provision for the fiscal years ended June 30, 2021, 2020 and 2019 are as follows (in thousands):

[0001375365-21-000060:notes:260]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| United States | $ | 80,922 |  |  | $ | 35,701 |  |  | $ | 45,126 |  |
| Foreign | 37,706 |  |  | 49,127 |  |  | 44,397 |  |
| Income before income tax provision | $ | 118,628 |  |  | $ | 84,828 |  |  | $ | 89,523 |  |

[0001375365-21-000060:notes:261]
The income tax provision for the fiscal years ended June 30, 2021, 2020 and 2019, consists of the following (in thousands):

[0001375365-21-000060:notes:262]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Current: |  |  |  |  |  |
| Federal | $ | 3,406 |  |  | $ | 4,568 |  |  | $ | 12,308 |  |
| State | 1,077 |  |  | 1,727 |  |  | 2,917 |  |
| Foreign | 10,843 |  |  | 10,399 |  |  | 16,531 |  |
|  | 15,326 |  |  | 16,694 |  |  | 31,756 |  |
| Deferred: |  |  |  |  |  |
| Federal | (5,489) |  |  | (10,108) |  |  | (13,078) |  |
| State | (409) |  |  | (1,621) |  |  | (2,888) |  |
| Foreign | (2,492) |  |  | (2,043) |  |  | (906) |  |
|  | (8,390) |  |  | (13,772) |  |  | (16,872) |  |
| Income tax provision | $ | 6,936 |  |  | $ | 2,922 |  |  | $ | 14,884 |  |

[0001375365-21-000060:notes:263]
The Company’s net deferred tax assets as of June 30, 2021 and 2020 consist of the following (in thousands):

[0001375365-21-000060:notes:264]
|  | June 30, |
|  | 2021 |  | 2020 |
| Research and development credits | $ | 30,540 |  |  | $ | 24,304 |  |
| Deferred revenue | 18,584 |  |  | 20,354 |  |
| Inventory valuation | 13,831 |  |  | 13,946 |  |
| Capitalized research and development costs | 15,206 |  |  | 7,509 |  |
| Stock-based compensation | 3,868 |  |  | 4,075 |  |
| Lease obligations | 2,861 |  |  | 3,632 |  |
| Accrued vacation and bonus | 5,098 |  |  | 3,281 |  |
| Prepaid and accrued expenses | 1,179 |  |  | 2,560 |  |
| Warranty accrual | 2,154 |  |  | 2,051 |  |
| Bad debt and other reserves | 1,668 |  |  | 1,917 |  |
| Marketing fund accrual | 720 |  |  | 548 |  |
| Other | 4,460 |  |  | 3,652 |  |
| Total deferred income tax assets | 100,169 |  |  | 87,829 |  |
| Deferred tax liabilities-depreciation and other | (4,137) |  |  | (4,428) |  |
| Right of use asset | (2,831) |  |  | (3,612) |  |
| Valuation allowance | (29,913) |  |  | (24,891) |  |
| Deferred income tax assets, net | $ | 63,288 |  |  | $ | 54,898 |  |

[0001375365-21-000060:notes:265]
The Company assesses its deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2021, the Company believes that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of state research and development tax credits that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2021, the gross excess credits of $37.1 million, or net of federal tax benefit of $29.3 million, are subject to a full valuation allowance. At June 30, 2020, the gross excess credits of $30.8 million, or net of federal tax benefit of $24.3 million, are subject to a full valuation allowance. The change in valuation allowance is $5.0 million and $3.9 million for the fiscal years ended June 30, 2021 and 2020, respectively. The Company will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2021 and 2020 was $63.3 million and $54.9 million, respectively.

[0001375365-21-000060:notes:266]
The 2017 Tax Reform Act also creates a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) that must be included currently in the gross income of a CFC’s U.S. stockholder starting in the tax year that begins after 2017. GILTI does not have material impact on the Company's income tax provision.

[0001375365-21-000060:notes:267]
Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into a company’s measurement of its deferred taxes. The Company's selection of an accounting policy with respect to the GILTI tax rules is to treat GILTI tax as a current period expense under the period cost method.

[0001375365-21-000060:notes:268]
Under the 2017 Tax Reform Act, starting on July 1, 2018, the Company is no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. The Company previously asserted that all of its foreign undistributed earnings were indefinitely reinvested. As a result of the 2017 Tax Reform Act, the Company has determined that its foreign undistributed earnings are indefinitely reinvested except for Netherlands. The Company may repatriate foreign earnings from Netherlands which are previously taxed income as a result of the 2017 Tax Reform Act. The tax impact of such repatriation is estimated to be immaterial.

[0001375365-21-000060:notes:269]
As a result of the 2017 Tax Reform Act, in December 2019, the Company realigned its international business operations and group structure. As a part of this restructuring, the Company moved certain intellectual property back to the United States. As a result of this restructuring, the Company estimated approximately $3.0 million and $1.9 million additional tax benefit from foreign derived intangible income in fiscal years 2021 and 2020 as compared to fiscal year 2019.

[0001375365-21-000060:notes:270]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted. The CARES Act provides temporary relief from certain aspects of the 2017 Tax Reform Act that imposed limitations on the utilization of certain losses, interest expense deductions, alternative minimum tax credits and made a technical correction to the 2017 Tax Reform Act related to the depreciable life of qualified improvement property. The CARES Act did not have a material impact on the Company.

[0001375365-21-000060:notes:271]
The following is a reconciliation for the fiscal years ended June 30, 2021, 2020 and 2019, of the statutory rate to the Company’s effective federal tax rate:

[0001375365-21-000060:notes:272]
|  |  | Years Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Income tax provision at statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax, net of federal tax benefit |  | 0.3 |  |  | — |  |  | 0.5 |  |
| Foreign rate differential |  | (0.5) |  |  | — |  |  | 1.1 |  |
| Research and development tax credit |  | (10.5) |  |  | (13.1) |  |  | (9.5) |  |
| Uncertain tax positions, net of (settlement) with Tax Authorities |  | 2.0 |  |  | (2.3) |  |  | 4.1 |  |
| Foreign derived intangible / Subpart F income inclusion |  | (2.5) |  |  | (3.8) |  |  | (2.1) |  |
| Stock-based compensation |  | (3.3) |  |  | (2.8) |  |  | 2.1 |  |
| Non deductible penalty on SEC matter |  | — |  |  | 4.4 |  |  | — |  |
| Provision to return true-up |  | (1.9) |  |  | (1.1) |  |  | (1.6) |  |
| Other, net |  | 1.2 |  |  | 1.1 |  |  | 1.0 |  |
| Effective tax rate |  | 5.8 | % |  | 3.4 | % |  | 16.6 | % |

[0001375365-21-000060:notes:273]
As of June 30, 2021, the Company had state research and development tax credit carryforwards of $50.2 million. The state research and development tax credits will carryforward indefinitely to offset future state income taxes.

[0001375365-21-000060:notes:274]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-21-000060:notes:275]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2018 | $ | 25,117 |  |
| Gross increases: |  |
| For current year’s tax positions | 7,789 |  |
| For prior years’ tax positions | — |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (1,504) |  |
| Decreases due to lapse of statute of limitations | (3,354) |  |
| Balance at June 30, 2019 | 28,048 |  |
| Gross increases: |  |
| For current year’s tax positions | 8,769 |  |
| For prior years’ tax positions | 505 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (7,632) |  |
| Decreases due to lapse of statute of limitations | (2,484) |  |
| Balance at June 30, 2020 | 27,206 |  |
| Gross increases: |  |
| For current year’s tax positions | 13,333 |  |
| For prior years’ tax positions | 1,439 |  |
| Gross decreases: |  |
| Decreases due to lapse of statute of limitations | (1,243) |  |
| Balance at June 30, 2021 | $ | 40,735 |  |

[0001375365-21-000060:notes:276]
________________________

[0001375365-21-000060:notes:277]
*excludes interest, penalties, federal benefit of state reserves

[0001375365-21-000060:notes:278]
The total amount of unrecognized tax benefits that would affect the effective tax rate, if recognized, was $27.1 million and $13.4 million as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:notes:279]
The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the income tax provision in the consolidated statements of operations. As of June 30, 2021 and 2020, the Company had accrued $2.5 million and $2.1 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively.

[0001375365-21-000060:notes:280]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in February 2020. In February 2020, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2019 and proposed a transfer pricing adjustment on the Company which resulted in additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of these adjustments on the income statement was offset by the release of previously unrecognized tax benefits related to the fiscal years audited in the periods in which the proposed adjustments were accepted.

[0001375365-21-000060:notes:281]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company’s current position. Accordingly, the Company’s provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-21-000060:notes:282]
The federal statute of limitations remains open in general for tax years ended June 30, 2018 through 2021. Various states statute of limitations remains open in general for tax years ended June 30, 2017 through 2021. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2016 through 2021. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $1.0 million, in the next 12 
months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-21-000060:notes:283]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 5, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement. The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement. On October 14, 2020, plaintiffs filed a Fourth Amended Complaint. On October 28, 2020, defendants filed a supplemental motion to dismiss. On March 29, 2021, the Court granted in part and denied in part defendants’ motions to dismiss. Plaintiffs’ claims under Sections 10(b) and 20 of the Exchange Act were dismissed with prejudice as against the Company’s former head of Investor Relations, Perry Hayes. Plaintiffs’ Section 10(b) claim, but not the Section 20 claim, was likewise dismissed as to Wally Liaw, a founder, former director, and former SVP of International Sales. The Court denied the motions to dismiss the Section 10(b) and Section 20 claims against the Company, Charles Liang, and Howard Hideshima, the Company’s former CFO. Discovery has commenced, and the Court has calendared a hearing on class certification for January 20, 2022. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000060:notes:284]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190. The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed demurrers, which were set for hearing on August 4, 2021, but which were continued to September 15, 2021. Following this continuance, on July 21, 2021, Plaintiffs' counsel filed an amended complaint in lieu of responding to the demurrer. The amended complaint added no new claims; primarily, the amendment added allegations describing the March 29, 2021 motion to dismiss decision in the Hessefort class action. Defendants demurred to the amended complaint on August 24, 2021, and the Court has calendared the hearing for November 24, 2021. The case is otherwise currently stayed. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000060:notes:285]
On May 5, 2021, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Stein v. Liang, et al., Case No. 3:21-cv-03357-KAW (the “Stein Derivative Action”).  The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, unjust enrichment, and contribution for violations of federal securities laws arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiff seeks unspecified compensatory damages and other equitable relief. Defendants filed motions to dismiss the complaint on August 6, 2021, and the Court has calendared the hearing for November 4, 2021. The Company intends to defend the lawsuit vigorously.

[0001375365-21-000060:notes:286]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

[0001375365-21-000060:notes:287]
Other legal proceedings and indemnifications

[0001375365-21-000060:notes:288]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of June 30, 2021 and any prior periods.

[0001375365-21-000060:notes:289]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-21-000060:notes:290]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-21-000060:notes:291]
Purchase Commitments - The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2021, these remaining noncancelable commitments were $569.8 million, including $111.2 million for related parties.

[0001375365-21-000060:notes:292]
Standby Letter of Credit - In October 2019, Bank of America increased the value of a previously issued standby letter of credit to a beneficiary from $3.2 million to $6.4 million to facilitate ongoing operations of the Company. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit. In May 2021, the standby letter of credit was cancelled.

[0001375365-21-000060:notes:293]
Lease Commitments - See Note 12, "Leases," for a discussion of the Company's operating lease and financing lease commitments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-21-000060:notes:294]
Retirement Plans
The Company sponsors a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions by the Company are discretionary, and no contributions have been made by the Company for the fiscal years ended June 30, 2021, 2020 and 2019.

[0001375365-21-000060:notes:295]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. The Company is required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, the Company's obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are

[0001375365-21-000060:notes:296]
assumed by the employees and not by the Company. For the fiscal years ended June 30, 2021, 2020 and 2019, the Company’s matching contribution was $0.7 million, $0.6 million, and $0.5 million, respectively.

[0001375365-21-000060:notes:297]
The Company contributes to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. The Company's obligation is limited to the contributions made to the pension plan. The Company has no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2021, 2020 and 2019, the Company’s contribution was $2.5 million, $1.9 million and $1.6 million, respectively.

[0001375365-21-000060:notes:298]
The Company has a defined benefit pension plan under the R.O.C. Labor Standards Law for certain employees of Super Micro Computer, Inc. Taiwan that provides benefits based on an employee’s length of service and average monthly salary for the six-month period prior to retirement. The Company contributes an amount equal to 2% of salaries paid each month to the pension fund (the “Fund”), which is administered by the Labor Pension Fund Supervisory Committee (the “Committee”) and deposited in the Committee’s name in the Bank of Taiwan. Before the end of each year, the Company assesses the balance in the Fund. If the amount of the balance in the Fund is inadequate to pay retirement benefits for eligible employees in the next year, the Company is required to fund the difference in one appropriation that should be made before the end of March 31 of the next year. The Fund is operated and managed by the government’s designated authorities. As such, the Company does not have any right to intervene in the investments of the Fund. For the fiscal year ended June 30, 2021, the Company recorded a pension expense of $1.0 million. For the fiscal years ended June 30, 2020 and 2019, the Company’s pension expense was immaterial.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-21-000060:notes:299]
Segment Reporting
The Company operates in one operating segment that develops and provides high performance server solutions based upon an innovative, modular and open-standard architecture. The Company’s chief operating decision maker is the Chief Executive Officer.

[0001375365-21-000060:notes:300]
The following is a summary of property, plant and equipment, net (in thousands):

[0001375365-21-000060:notes:301]
|  | June 30, |  |  |
|  | 2021 |  | 2020 |  |  |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 180,143 |  |  | $ | 178,812 |  |  |  |
| Asia | 91,640 |  |  | 51,605 |  |  |  |
| Europe | 2,930 |  |  | 3,368 |  |  |  |
|  | $ | 274,713 |  |  | $ | 233,785 |  |  |  |

[0001375365-21-000060:notes:302]
The Company’s revenue is presented on a disaggregated basis in Note 3, “Revenue” by type of product and by geographical market.
