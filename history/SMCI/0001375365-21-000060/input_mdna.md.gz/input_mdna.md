# SMCI MD&A — 0001375365-21-000060


## mdna

[0001375365-21-000060:mdna:1]
Item 7.        Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-21-000060:mdna:2]
Overview

[0001375365-21-000060:mdna:3]
We are a global leader and innovator of application-optimized high performance and high-efficiency server and storage systems for a variety of markets, including enterprise data centers, cloud computing, artificial intelligence, 5G and edge computing. Our solutions include complete servers, storage systems, modular blade servers, blades, workstations, full racks, networking devices, server management software, and server sub-systems. We also provide global support and services to help our customers install, upgrade and maintain their computing infrastructure.

[0001375365-21-000060:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2021, 2020 and 2019, our net income was $111.9 million, $84.3 million and $71.9 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-21-000060:mdna:5]
Coronavirus (COVID-19) Pandemic Impact

[0001375365-21-000060:mdna:6]
The global spread of the coronavirus (COVID-19) and the various attempts to contain it have created significant volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders that govern the operations of businesses, require masks be worn and define shelter in place and social distancing protocols. We are an essential critical infrastructure (information technology) business under the relevant federal, state and county regulations. Accordingly, in late March 2020, we responded to the directives from Santa Clara County and the State of California regarding instructions to combat the spread of COVID-19. Our first priority is the safety of our workforce and we have implemented numerous health precautions and work practices to be in compliance with the law and to operate in a safe manner.

[0001375365-21-000060:mdna:7]
We quickly transitioned certain of our indirect labor forces to work from home at the earlier phase of the pandemic and continued to operate our local assembly in Taiwan and, after an initial period of disruption, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continue to see ongoing demand and do not have significant direct exposure to industries such as retail, oil and gas and hospitality, which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-21-000060:mdna:8]
We have actively managed our supply chain for potential shortage risk by building inventories of critical components required for our motherboards and other system printed circuit boards in response to the early outbreak of COVID-19 in China. Since that time, we have continued to add to our inventories of key components such as CPUs, memory, SSDs and GPUs such that customer orders can be fulfilled as they are received.

[0001375365-21-000060:mdna:9]
Logistics has emerged as a new challenge as globally the transportation industry restricted the frequency of departures and increased logistics costs. We experienced increased costs in freight as well as direct labor costs as we incentivized our employees to continue to work and assist us in serving our customers, many of whom are in critical industries. We expect this trend to continue for the duration of the COVID-19 pandemic.

[0001375365-21-000060:mdna:10]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In December 2020, our Taiwan subsidiary entered into a general credit agreement with E.SUN Bank in Taiwan. This general credit agreement provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30 million. The term of this general credit agreement was through September 18, 2021. In June 2021, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2026. In July 2021, we replaced our prior credit facility and term loan facility with China Trust and Bank Corp ("CTBC Bank"), with a new facility for omnibus credit lines.

[0001375365-21-000060:mdna:11]
Our management team is focused on guiding our company through the ongoing challenges presented by COVID-19. Currently, there are positive signs with vaccine availability and reductions in infection rates; however, with the possibility of new virus strains and vaccine supply constraints, we are unable to predict the ultimate extent to which the global COVID-19 pandemic may further impact our business operations, financial performance and results of operations within the next 12 months. See also “Business–Employees and Human Capital Resources.”

[0001375365-21-000060:mdna:12]
Financial Highlights

[0001375365-21-000060:mdna:13]
The following is a summary of financial highlights of fiscal years 2021 and 2020:

[0001375365-21-000060:mdna:14]
•Net sales increased by 6.5% in fiscal year 2021 as compared to fiscal year 2020.

[0001375365-21-000060:mdna:15]
•Gross margin declined to 15.0% in fiscal year 2021 from 15.8% in fiscal year 2020, primarily due to product and customer mix and increased logistic costs.

[0001375365-21-000060:mdna:16]
•Operating expenses declined by 6.8% in fiscal year 2021 as compared to fiscal year 2020, primarily due to the special performance bonuses to our employees and the accrual for our settlement with the SEC incurred in fiscal year 2020.

[0001375365-21-000060:mdna:17]
•Net income increased to $111.9 million in fiscal year 2021 as compared to $84.3 million in fiscal year 2020, which was primarily due to the higher net sales and lower operating expenses in fiscal year 2021 as compared to fiscal year 2020.

[0001375365-21-000060:mdna:18]
•Our cash and cash equivalents were $232.3 million and $210.5 million at the end of fiscal years 2021 and 2020, respectively. In fiscal year 2021, we generated net cash of $21.1 million, of which $123.0 million was provided by operating activities related primarily to the increase in net income. We also invested $58.0 million in purchases of property and equipment, including construction of a new facility in San Jose, California, and used $44.4 million in financing activities primarily due to the repurchase of $130.0 million of our common stock, which was offset by the proceeds from borrowings.

[0001375365-21-000060:mdna:19]
Critical Accounting Policies and Estimates

[0001375365-21-000060:mdna:20]
General

[0001375365-21-000060:mdna:21]
Our discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these consolidated financial statements requires us to make estimates and judgments that affect the reported amount of assets, liabilities, net sales and expenses. We evaluate our estimates on an on-going basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making the judgments we make about the carrying values of assets and liabilities that are not readily apparent from other sources. Because these estimates can vary depending on the situation, actual results may differ from the estimates. Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-21-000060:mdna:22]
A summary of significant accounting policies is included in Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” in our notes to the consolidated financial statements in this Annual Report. Management believes the following are the most critical accounting policies and reflect the significant estimates and assumptions used in the preparation of the consolidated financial statements.

[0001375365-21-000060:mdna:23]
Revenue Recognition

[0001375365-21-000060:mdna:24]
The most critical accounting policy estimate and judgments required in applying ASC 606, Revenue Recognition of Contracts from Customers, and our revenue recognition policy relate to the determination of the transaction price, distinct performance obligations and the evaluation of the standalone selling price (the “SSP”) for each performance obligation.

[0001375365-21-000060:mdna:25]
We generate revenues from the sale of server and storage systems, subsystems, accessories, services, server software management solutions, and support services.  Many of our customer contracts include multiple performance obligations. Judgment is required in determining whether each performance obligation within a customer contract is distinct. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.

[0001375365-21-000060:mdna:26]
As part of determining the transaction price in contracts with customers, we may be required to estimate variable consideration when determining the amount of revenue to recognize. We estimate reserves for future sales returns based on a review of our history of actual returns. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs. We also estimate the costs of customer and distributor programs and incentive offerings such as price protection, rebates, as well as the estimated costs of cooperative marketing arrangements where the fair value of the benefit derived from the costs cannot be reasonably estimated. Any provision is recorded as a reduction of revenue at the time of sale based on an evaluation of the contract terms and historical experience.

[0001375365-21-000060:mdna:27]
We allocate the transaction price for each customer contract to each performance obligation based on the relative SSP for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue as each performance obligation is delivered. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgement. We determine standalone selling prices based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we apply judgment to estimate the SSP. For substantially all performance obligations, we are able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-21-000060:mdna:28]
These estimates and judgements have not fluctuated significantly for the fiscal year ended June 30, 2021 compared to prior fiscal years.

[0001375365-21-000060:mdna:29]
Inventories

[0001375365-21-000060:mdna:30]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of purchased parts and raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-21-000060:mdna:31]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold. We determine the volume-based rebates to be recognized in the cost of sales on a first-in, first-out basis.

[0001375365-21-000060:mdna:32]
Income Taxes

[0001375365-21-000060:mdna:33]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets

[0001375365-21-000060:mdna:34]
represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or when loss or credit carryforwards are utilized. In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001375365-21-000060:mdna:35]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related charge in our tax provision during the period in which we make such a determination.

[0001375365-21-000060:mdna:36]
Stock-Based Compensation

[0001375365-21-000060:mdna:37]
We measure and recognize compensation expense for all share-based awards made to employees and non-employees, including stock options, restricted stock units ("RSUs") and performance-based restricted stock units (“PRSUs”). We recognize the grant date fair value of all share-based awards over the requisite service period and account for forfeitures as they occur. Stock option and RSU awards are recognized to expense on a straight-line basis over the requisite service period. PRSU awards are recognized to expense using an accelerated method only when it is probable that a performance condition is met during the vesting period. If it is not probable, no expense is recognized and the previously recognized expense is reversed. We base initial accrual of compensation expense on the estimated number of PRSUs that are expected to vest over the requisite service period. That estimate is revised if subsequent information indicates that the actual number of PRSUs is likely to differ from previous estimates. The cumulative effect on current and prior periods of a change in the estimated number of PRSUs expected to vest is recognized in stock-based compensation expense in the period of the change. Previously recognized compensation expense is not reversed if vested stock options, RSUs or PRSUs for which the requisite service has been rendered and the performance condition has been met expire unexercised or are not settled.

[0001375365-21-000060:mdna:38]
The fair value of RSUs and PRSUs is based on the closing market price of our common stock on the date of grant. We estimate the fair value of stock options granted using a Black-Scholes option pricing model. This model requires us to make estimates and assumptions with respect to the expected term of the option and the expected volatility of the price of our common stock. The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience. The expected volatility is based on the historical volatility of our common stock.

[0001375365-21-000060:mdna:39]
The assumptions used to determine the fair value of the option awards represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. Our use of the Black-Scholes option-pricing model requires the input of highly subjective assumptions. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.

[0001375365-21-000060:mdna:40]
Variable Interest Entities

[0001375365-21-000060:mdna:41]
We determine at the inception of each arrangement whether an entity in which we hold an investment or in which we have other variable interests is considered a variable interest entity ("VIE"). We consolidate VIEs when we are the primary beneficiary. The primary beneficiary of a VIE is the party that meets both of the following criteria: (1) has the power to make decisions that most significantly affect the economic performance of the VIE and (2) has the obligation to absorb losses or the right to receive benefits that in either case could potentially be significant to the VIE. Periodically, we assess whether any changes in the interest or relationship with the entity affect the determination of whether the entity is still a VIE and, if so, whether we are the primary beneficiary. If we are not the primary beneficiary in a VIE, we account for the investment or other variable interest in accordance with applicable GAAP.

[0001375365-21-000060:mdna:42]
We have concluded that Ablecom and its affiliate, Compuware, are VIEs; however, we are not the primary beneficiary as we do not have the power to direct the activities that are most significant to the entities and therefore, we do not consolidate these entities. In performing this analysis, we considered our explicit arrangements with Ablecom and Compuware, including all contractual arrangements with these entities. Also, as a result of the substantial related party relationships between us and

[0001375365-21-000060:mdna:43]
these two companies, we considered whether any implicit arrangements exist that would cause us to protect these related parties’ interests from suffering losses. We determined that no material implicit arrangements exist with Ablecom, Compuware, or their shareholders.

[0001375365-21-000060:mdna:44]
Our ability to assess correctly our influence or control over an entity at inception of our involvement or on a continuous basis when determining the primary beneficiary of a VIE affects the presentation of these entities in our consolidated financial statements. Subsequent evaluations of the primary beneficiary of a VIE may require the use of different assumptions that could lead to identification of a different primary beneficiary, resulting in a different consolidation conclusion than what was determined at inception of the arrangement.

[0001375365-21-000060:mdna:45]
Results of Operations

[0001375365-21-000060:mdna:46]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of revenue.

[0001375365-21-000060:mdna:47]
|  | Years Ended June 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 85.0 | % |  | 84.2 | % |  | 85.8 | % |
| Gross profit | 15.0 | % |  | 15.8 | % |  | 14.2 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 6.3 | % |  | 6.6 | % |  | 5.1 | % |
| Sales and marketing | 2.4 | % |  | 2.5 | % |  | 2.2 | % |
| General and administrative | 2.8 | % |  | 4.1 | % |  | 4.0 | % |
| Total operating expenses | 11.5 | % |  | 13.2 | % |  | 11.3 | % |
| Income from operations | 3.5 | % |  | 2.6 | % |  | 2.9 | % |
| Other (expense) income, net | (0.1) | % |  | — | % |  | — | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.2) | % |
| Income before income tax provision | 3.3 | % |  | 2.5 | % |  | 2.7 | % |
| Income tax provision | (0.2) | % |  | (0.1) | % |  | (0.4) | % |
| Share of income (loss) from equity investee, net of taxes | — | % |  | 0.1 | % |  | (0.1) | % |
| Net income | 3.1 | % |  | 2.5 | % |  | 2.2 | % |

[0001375365-21-000060:mdna:48]
Net Sales

[0001375365-21-000060:mdna:49]
Net sales consist of sales of our server and storage solutions, including systems and related services and subsystems and accessories. The main factors that impact net sales of our server and storage systems are the number of compute nodes sold and the average selling prices per node. The main factors that impact net sales of our subsystems and accessories are units shipped and the average selling price per unit. The prices for our server and storage systems range widely depending upon the configuration, including the number of compute nodes in a server system as well as the level of integration of key components such as SSDs and memory. The prices for our subsystems and accessories can also vary widely based on whether a customer is purchasing power supplies, server boards, chassis or other accessories.

[0001375365-21-000060:mdna:50]
A compute node is an independent hardware configuration within a server system capable of having its own CPU, memory and storage and that is capable of running its own instance of a non-virtualized operating system. The number of compute nodes sold, which can vary by product, is an important metric we use to track our business. Measuring volume using compute nodes enables more consistent measurement across different server form factors and across different vendors. As with most electronics-based product life cycles, average selling prices typically are highest at the time of introduction of new products that utilize the latest technology and tend to decrease over time as such products mature in the market and are replaced by next generation products. Additionally, in order to remain competitive throughout all industry cycles, we actively change our selling price per unit in response to changes in costs for key components such as memory and SSDs.

[0001375365-21-000060:mdna:51]
The following table presents net sales by product type for fiscal years 2021, 2020 and 2019 (dollars in millions):

[0001375365-21-000060:mdna:52]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 2,790.3 |  |  | $ | 2,620.8 |  |  | $ | 2,858.7 |  |  | $ | 169.5 |  |  | 6.5 | % |  | $ | (237.9) |  |  | (8.3) | % |
| Percentage of total net sales | 78.4 | % |  | 78.5 | % |  | 81.7 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 767.1 |  |  | 718.5 |  |  | 641.7 |  |  | 48.6 |  |  | 6.8 | % |  | 76.8 |  |  | 12.0 | % |
| Percentage of total net sales | 21.6 | % |  | 21.5 | % |  | 18.3 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,557.4 |  |  | $ | 3,339.3 |  |  | $ | 3,500.4 |  |  | $ | 218.1 |  |  | 6.5 | % |  | $ | (161.1) |  |  | (4.6) | % |

[0001375365-21-000060:mdna:53]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:54]
During fiscal year 2021 we experienced increased revenue from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to an increase of average selling prices per compute node by approximately 17%, offset by a decrease of approximately 9% in the number of units of compute nodes sold. We typically adjust our selling prices as component costs rise and fall. The increase in average selling prices was primarily due to significant inventory component price increases resulting from component shortages during fiscal year 2021. The year-over-year increase in net sales of subsystems and accessories was primarily due to an increase of approximately 5% in the volume of subsystems and accessories sold, mainly due to increased demand and approximately 2% increase in average selling prices due primarily to the increase in costs of the components. Our services and software revenue, included in server and storage systems revenue, increased by $0.2 million year-over-year.

[0001375365-21-000060:mdna:55]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:56]
During fiscal year 2020 we continued to experience a steady demand for server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year decrease in net sales of server and storage systems was primarily due to a decrease of average selling prices per compute node by approximately 11%, offset by a slight increase in the number of units of compute nodes sold. We typically adjust our prices as component costs rise and fall. The decline in average selling prices was primarily due to substantially lower costs for key components, specifically for memory and storage, as compared to the previous fiscal year. The year-over-year increase in net sales of subsystems and accessories was primarily due to an increase of approximately 19% in the volume of subsystems and accessories sold, mainly due to increased demand from our indirect sales channel offset by an approximately 6% decrease in average selling prices due primarily to the decrease in costs of the components. Our services and software revenue, included in server and storage systems revenue, increased by $39.8 million year-over-year.

[0001375365-21-000060:mdna:57]
The following table presents percentages of net sales by geographic region for fiscal years 2021, 2020 and 2019 (dollars in millions):

[0001375365-21-000060:mdna:58]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| United States | $ | 2,107.9 |  |  | $ | 1,957.3 |  |  | $ | 2,032.9 |  |  | $ | 150.6 |  |  | 7.7 | % |  | $ | (75.6) |  |  | (3.7) | % |
| Percentage of total net sales | 59.3 | % |  | 58.6 | % |  | 58.1 | % |  |  |  |  |  |  |  |  |
| Asia | 699.7 |  |  | 650.7 |  |  | 712.2 |  |  | 49.0 |  |  | 7.5 | % |  | (61.5) |  |  | (8.6) | % |
| Percentage of total net sales | 19.7 | % |  | 19.5 | % |  | 20.3 | % |  |  |  |  |  |  |  |  |
| Europe | 614.8 |  |  | 598.6 |  |  | 611.0 |  |  | 16.2 |  |  | 2.7 | % |  | (12.4) |  |  | (2.0) | % |
| Percentage of total net sales | 17.3 | % |  | 17.9 | % |  | 17.5 | % |  |  |  |  |  |  |  |  |
| Others | 135.0 |  |  | 132.7 |  |  | 144.3 |  |  | 2.3 |  |  | 1.7 | % |  | (11.6) |  |  | (8.0) | % |
| Percentage of total net sales | 3.7 | % |  | 4.0 | % |  | 4.1 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 3,557.4 |  |  | $ | 3,339.3 |  |  | $ | 3,500.4 |  |  | $ | 218.1 |  |  | 6.5 | % |  | $ | (161.1) |  |  | (4.6) | % |

[0001375365-21-000060:mdna:59]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:60]
The year-over-year increase in net sales in the United States was primarily due to an increase in net sales of our server and storage systems. The year-over-year increase in net sales in Asia was primarily due to an increase in net sales of our server and storage systems in China, Singapore, India and Japan, partially offset by a decrease in the net sales in Taiwan. The year-over-year increase in net sales in Europe was primarily due to an increase in net sales of our server and storage systems in the Germany, UK and France, partially offset by a decrease in net sales in the Netherlands and Russia.

[0001375365-21-000060:mdna:61]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:62]
The year-over-year decrease in net sales in the United States was primarily due to a decrease in net sales of our server and storage systems to our direct customers and OEMs. The year-over-year decrease in net sales in Asia was primarily due to a decrease in net sales of our server and storage systems to OEMs in China, India and Japan, partially offset by a slight increase in the net sales of subsystems and accessories in China and of server and storage systems in the rest of Asia region. The year-over-year decrease in net sales in Europe was primarily due to a decrease in net sales of our server and storage systems to our direct customers and OEMs in the Netherlands, partially offset by an increase in net sales of our subsystems and accessories to our indirect sales channel in Germany and an increase in sales to our indirect sales channel in France.

[0001375365-21-000060:mdna:63]
Cost of Sales and Gross Margin

[0001375365-21-000060:mdna:64]
Cost of sales primarily consists of the costs to manufacture our products, including the costs of materials, contract manufacturing, shipping, personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, equipment and facility expenses, warranty costs and inventory excess and obsolescence provisions. The primary factors that impact our cost of sales are the mix of products sold and cost of materials, which include purchased parts and material costs, shipping costs, salary and benefits and overhead costs related to production. Cost of sales as a percentage of net sales may increase over time if decreases in average selling prices are not offset by corresponding decreases in our costs. Our cost of sales as a percentage of net sales is also impacted by the extent to which we are able to efficiently utilize our expanding manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to change based on the cost of materials and market conditions. As a result, our cost of sales as a percentage of net sales in any period can increase due to significant component price increases resulting from component shortages.

[0001375365-21-000060:mdna:65]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. During the fiscal year 2021, we continued to expand manufacturing and service operations in Taiwan primarily to support our Asian and European customers and have continued to work on improving our utilization of our overseas manufacturing capacity. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of our manufacturing of components, particularly power supplies. Our purchases of products from Ablecom and Compuware combined represented 7.8%, 10.1% and 9.2% of our cost of sales for fiscal years 2021, 2020 and 2019, respectively. For further details on our dealings with related parties, see Part II, Item 8, Note 13, “Related Party Transactions.”

[0001375365-21-000060:mdna:66]
Cost of sales and gross margin for fiscal years 2021, 2020 and 2019, are as follows (dollars in millions):

[0001375365-21-000060:mdna:67]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 3,022.9 |  |  | $ | 2,813.1 |  |  | $ | 3,004.8 |  |  | $ | 209.8 |  |  | 7.5 | % |  | $ | (191.7) |  |  | (6.4) | % |
| Gross profit | 534.5 |  |  | 526.2 |  |  | 495.5 |  |  | 8.3 |  |  | 1.6 | % |  | 30.7 |  |  | 6.2 | % |
| Gross margin | 15.0 | % |  | 15.8 | % |  | 14.2 | % |  |  |  | (0.8) | % |  |  |  | 1.6 | % |

[0001375365-21-000060:mdna:68]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:69]
The year-over-year increase in cost of sales was primarily attributable to an increase of $244.1 million in costs of

[0001375365-21-000060:mdna:70]
materials and contract manufacturing expenses primarily related to the increase in net sales volume and an increase of $8.9 million of freight. This was offset by a decrease of $29.5 million in overhead costs attributable primarily to a recovery of costs paid in prior periods, a decrease of $12.4 million in the provision of excess inventory and obsolescence and a decrease of $2.6 million in personnel expenses due to a decrease in special performance bonuses in the fiscal year 2021. Warranty and repairs costs also decreased by $3.4 million in the fiscal year 2021 as compared to the fiscal year 2020.

[0001375365-21-000060:mdna:71]
The period-over-period decrease in the gross margin percentage was primarily due to sales prices increasing at a slower rate than the increase in the costs of components and due to the decrease in services and software revenue which have higher margins than product sales. Since the start of the COVID-19 pandemic, we have experienced an increase in both logistics costs as well as direct labor costs as we incentivize our employees to continue to work and assist us in serving our customers.  This increase in costs negatively impacts our gross margins, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-21-000060:mdna:72]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:73]
The year-over-year decrease in cost of sales was primarily attributable to a decrease of $214.3 million in inventory costs related primarily to the decrease in the prices of components and a decrease of $14.6 million in the provision of excess inventory and obsolescence due to fewer excess and obsolescence items identified in the fiscal year 2020. This was offset by an increase of $19.6 million in overhead costs attributable primarily to increased tariffs and an increase of $11.3 million in personnel expenses, which included a special performance bonus of $4.1 million. Warranty and repairs costs also increased by $5.7 million in the fiscal year 2020 as compared to the fiscal year 2019.

[0001375365-21-000060:mdna:74]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components and due to the increase in services and software revenue which have higher margins than product sales. Since the start of the COVID-19 pandemic, we have experienced an increase in both logistics costs as well as direct labor costs as we incentivize our employees to continue to work and assist us in serving our customers. This increase in costs negatively impacts our gross margins, and we expect these higher costs to continue for the duration of the COVID-19 pandemic.

[0001375365-21-000060:mdna:75]
Operating Expenses

[0001375365-21-000060:mdna:76]
Research and development expenses consist of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive non-recurring engineering funding from certain suppliers and customers for joint development. Under these arrangements, we are reimbursed for certain research and development costs that we incur as part of the joint development efforts with our suppliers and customers. These amounts offset a portion of the related research and development expenses and have the effect of reducing our reported research and development expenses.

[0001375365-21-000060:mdna:77]
Sales and marketing expenses consist primarily of personnel expenses, including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, costs for tradeshows, independent sales representative fees and marketing programs. From time to time, we receive cooperative marketing funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-21-000060:mdna:78]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, information technology, corporate governance and compliance, outside legal, audit, tax fees, insurance and bad debt reserves on accounts receivable.

[0001375365-21-000060:mdna:79]
Operating expenses for fiscal years 2021, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000060:mdna:80]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 224.4 |  |  | $ | 221.5 |  |  | $ | 179.9 |  |  | $ | 2.9 |  |  | 1.3 | % |  | $ | 41.6 |  |  | 23.1 | % |
| Sales and marketing | 85.7 |  |  | 85.1 |  |  | 77.2 |  |  | 0.6 |  |  | 0.7 | % |  | 7.9 |  |  | 10.2 | % |
| General and administrative | 100.5 |  |  | 133.9 |  |  | 141.2 |  |  | (33.4) |  |  | (24.9) | % |  | (7.3) |  |  | (5.2) | % |
| Total operating expenses | $ | 410.6 |  |  | $ | 440.5 |  |  | $ | 398.3 |  |  | (29.9) |  |  | (6.8) | % |  | 42.2 |  |  | 10.6 | % |

[0001375365-21-000060:mdna:81]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:82]
The year-over-year increase in research and development expenses was primarily due to an increase of $11.6 million in costs mainly related to materials, supplies and equipment used in product development. During the fiscal year 2020, we recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred materials, supplies and equipment costs for one canceled joint product development agreement.

[0001375365-21-000060:mdna:83]
Personnel expenses increased $1.7 million as a result of an increase in the number of research and development employees, These increases were partially offset by an increase of $8.8 million in research and development credits from certain suppliers and customers towards our development efforts and a $1.5 million decrease in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic.

[0001375365-21-000060:mdna:84]
The year-over-year increase in sales and marketing expenses was primarily due to an increase of $1.2 million in advertising expenses, a $1.0 million increase in other sales and marketing expenses, offset by a $1.7 million decrease in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic.

[0001375365-21-000060:mdna:85]
The year-over-year decrease in general and administrative expenses was due to a decrease of $41.8 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $4.1 million in other expenses related to the COVID-19 pandemic, and a $1.1 million decrease in supplies costs. These decreases were partially offset by a $12.9 million increase in personnel expenses due to increased full time personnel and bonuses.

[0001375365-21-000060:mdna:86]
We anticipate the above expenses impacted by the COVID-19 pandemic to normalize if and when the COVID-19 pandemic is over.

[0001375365-21-000060:mdna:87]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:88]
The year-over-year increase in research and development expenses was primarily due to an increase of $41.3 million in personnel expenses as a result of an increase in the number of research and development employees and a special performance bonus of $17.3 million, a decrease of $0.7 million in reimbursements received for certain research and development costs that we incurred as part of joint product development; an increase of $6.7 million in costs mainly related to materials, supplies and equipment used in product development, and an increase of $1.8 million in facilities expenses. During fiscal year 2020, we also recorded a $9.5 million net settlement fee as a reduction in the research and development expenses related to the reimbursement of previously incurred expenses for one canceled joint product development agreement.

[0001375365-21-000060:mdna:89]
The year-over-year increase in sales and marketing expenses was primarily due to an increase of $8.1 million in personnel expenses as a result of an increase in the number of sales and marketing personnel and a special performance bonus of $1.8 million.

[0001375365-21-000060:mdna:90]
The year-over-year decrease in general and administrative expenses was due to a decrease of $33.9 million in professional fees that were primarily incurred to investigate, assess and begin remediating the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements; a decrease of $10.2 million in bad debt provision expenses due to recovery of previously provisioned receivables from certain international customers, offset by an increase of $17.5 million related to an expense accrual for the settlement with the SEC; an increase of $14.1 million in personnel expenses as a result of an increase in the number of personnel and a special performance bonus of $4.5 million; an increase of $3.2 million in insurance expense; and an increase of $1.7 million related primarily to facilities expenses.

[0001375365-21-000060:mdna:91]
Interest and Other Expense, Net

[0001375365-21-000060:mdna:92]
Other (expense) income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-21-000060:mdna:93]
Interest expense represents interest expense on our term loans and lines of credit.

[0001375365-21-000060:mdna:94]
Interest and other expense, net for fiscal years 2021, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000060:mdna:95]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Other (expense) income, net | $ | (2.8) |  |  | $ | 1.4 |  |  | $ | (1.0) |  |  | $ | (4.2) |  |  | (300.0) | % |  | $ | 2.4 |  |  | (240.0) | % |
| Interest expense | (2.5) |  |  | (2.2) |  |  | (6.7) |  |  | (0.3) |  |  | 13.6 | % |  | 4.5 |  |  | (67.2) | % |
| Interest and other expense, net | $ | (5.3) |  |  | $ | (0.8) |  |  | $ | (7.7) |  |  | $ | (4.5) |  |  | 562.5 | % |  | $ | 6.9 |  |  | (89.6) | % |

[0001375365-21-000060:mdna:96]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:97]
The change of $4.2 million in other (expense) income, net was attributable to a decrease of $2.4 million in interest income on our interest-bearing deposits due primarily to lower yields on investments and an increase of $1.8 million in foreign exchange loss due to unfavorable foreign currency fluctuations.

[0001375365-21-000060:mdna:98]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:99]
The year-over-year change in interest expense of $4.5 million is primarily a result of lower interest rates and reduced levels of borrowings in fiscal year 2020 as compared to fiscal year 2019. The change of $2.4 million in other (expense) income, net was attributable to an increase of $1.6 million in interest income on our interest bearing deposits and a decrease of $0.8 million in other expenses.

[0001375365-21-000060:mdna:100]
Provision for Income Taxes

[0001375365-21-000060:mdna:101]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, primarily the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, uncertain tax positions, tax benefits from foreign derived intangible income and stock based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Part II, Item 8, Note 15, “Income Taxes” to the consolidated financial statements in this Annual Report.

[0001375365-21-000060:mdna:102]
Provision for income taxes and effective tax rates for fiscal years 2021, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000060:mdna:103]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | 6.9 |  |  | $ | 2.9 |  |  | $ | 14.9 |  |  | $ | 4.0 |  |  | 137.9 | % |  | $ | (12.0) |  |  | (80.5) | % |
| Effective tax rate | 5.8 | % |  | 3.4 | % |  | 16.6 | % |  |  |  |  |  |  |  |  |

[0001375365-21-000060:mdna:104]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:105]
The year-over-year increase in the effective tax rate was primarily due to a release of reserve from uncertain tax positions in the prior year.

[0001375365-21-000060:mdna:106]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:107]
The year-over-year decrease in the effective tax rate was primarily due to an increase in tax benefits from research and development tax credits, stock based compensation, releases of uncertain tax positions, and U.S. sales to foreign jurisdictions, partially offset by the tax impact from the non-deductible settlement with the SEC.

[0001375365-21-000060:mdna:108]
Share of (Loss) from Equity Investee, Net of Taxes

[0001375365-21-000060:mdna:109]
|  | Years Ended June 30, |  | 2021 over 2020 Change |  | 2020 over 2019 Change |
|  | 2021 |  | 2020 |  | 2019 |  | $ |  | % |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 0.2 |  |  | $ | 2.4 |  |  | $ | (2.7) |  |  | $ | (2.2) |  |  | (91.7) | % |  | $ | 5.1 |  |  | 188.9 | % |

[0001375365-21-000060:mdna:110]
Fiscal Year 2021 Compared with Fiscal Year 2020

[0001375365-21-000060:mdna:111]
The year-over-year decrease of $2.2 million in share of income from equity investee, net of taxes was primarily due to lower net income recognized by the Corporate Venture in the fiscal year 2021 as compared to 2020.

[0001375365-21-000060:mdna:112]
Fiscal Year 2020 Compared with Fiscal Year 2019

[0001375365-21-000060:mdna:113]
The year-over-year increase of $5.1 million from share of (loss) to income from equity investee, net of taxes was primarily due to net income recognized by the Corporate Venture in the fiscal year 2020 as compared to net loss in the fiscal year 2019.

[0001375365-21-000060:mdna:114]
Liquidity and Capital Resources

[0001375365-21-000060:mdna:115]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as an increase in the need for working capital due to longer supply chain manufacturing and delivery times. Our cash and cash equivalents were $232.3 million and $210.5 million as of June 30, 2021 and 2020, respectively. Our cash in foreign locations was $152.6 million and $98.0 million as of June 30, 2021 and 2020, respectively.

[0001375365-21-000060:mdna:116]
Amounts held outside of the U.S. are generally utilized to support non-U.S. liquidity needs. Repatriations generally will not be taxable from a U.S. federal tax perspective, but may be subject to state income or foreign withholding tax. Where local restrictions prevent an efficient intercompany transfer of funds, our intent is to keep cash balances outside of the U.S. and to meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes incurred on repatriation of amounts held outside of the U.S. to have a material effect on our overall liquidity, financial condition or results of operations.

[0001375365-21-000060:mdna:117]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the twelve months following the issuance of these consolidated financial statements. We expect to pay a special performance bonus of approximately $4.0 million to our CEO within the next year. During the fiscal year 2021, the target average closing price of our common stock condition for the bonus was satisfied but no determination has been made if the specified performance condition has been satisfied.

[0001375365-21-000060:mdna:118]
During the fiscal year ended June 30, 2021, we retired 1,333,125 shares of common stock repurchased in prior years. Additionally, we repurchased and retired 4,209,211 shares of common stock for an aggregated $130.0 million under multiple share repurchase programs. All programs were completed during the fiscal year except for the program approved on January 29, 2021 to repurchase up to an aggregate of $200.0 million of our common stock at market prices. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased. As of June 30, 2021, we still had $150.0 million available to be used by July 31, 2022.

[0001375365-21-000060:mdna:119]
Our key cash flow metrics were as follows (dollars in millions):

[0001375365-21-000060:mdna:120]
|  | Years Ended June 30, |  | 2021 over 2020 |  | 2020 over 2019 |  |  |
|  | 2021 |  | 2020 |  | 2019 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 123.0 |  |  | $ | (30.3) |  |  | $ | 262.6 |  |  | $ | 153.3 |  |  | $ | (292.9) |  |  |  |
| Net cash used in investing activities | $ | (58.0) |  |  | $ | (43.6) |  |  | $ | (24.8) |  |  | $ | (14.4) |  |  | $ | (18.8) |  |  |  |
| Net cash (used in) provided by financing activities | $ | (44.4) |  |  | $ | 23.8 |  |  | $ | (95.8) |  |  | $ | (68.2) |  |  | $ | 119.6 |  |  |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 21.1 |  |  | $ | (49.8) |  |  | $ | 141.8 |  |  | $ | 70.9 |  |  | $ | (191.6) |  |  |  |

[0001375365-21-000060:mdna:121]
Operating Activities

[0001375365-21-000060:mdna:122]
Net cash provided by operating activities increased by $153.3 million for fiscal year 2021 as compared to fiscal year 2020. While net income increased by $27.6 million in fiscal year 2021 as compared to fiscal year 2020, the increase in cash flows from operating activities was due primarily to a decrease of cash used for net working capital requirements of $120.3 million. Non-cash charges related to stock-based compensation expense increased by $8.4 million, collection of bad debt previously reserved decreased by $2.3 million, income from equity investee decreased by $2.2 million and $5.4 million decrease in the non-cash charges related to the change in our deferred income tax assets. These increases in the cash flow from operating activities were partially offset by the decrease of $11.6 million in previously reserved excess and obsolete inventory.

[0001375365-21-000060:mdna:123]
Net cash provided by operating activities decreased by $292.9 million for fiscal year 2020 as compared to fiscal year 2019. While net income increased by $12.4 million in fiscal year 2020 as compared to fiscal year 2019, the decrease in cash flows from operating activities was due primarily to an increase of cash used for net working capital requirements of $281.3 million, including a $181.3 million increase in inventories to meet customer demand, support expected business growth and mitigate supply chain risk due to the COVID-19 pandemic environment. Non-cash charges related to excess and obsolete inventory decreased by $14.6 million, related to bad debt reserve decreased by $10.1 million, related to income (loss) from equity investee decreased by $5.1 million, and related to impairment of investments decreased by $2.7 million in fiscal year 2020 compared to fiscal year 2019. These decreases were offset by an increase of $8.9 million in the non-cash charges related to the change in our deferred income tax assets, unrealized losses on our foreign currency-denominated credit facilities, and depreciation and amortization expense resulting from the amortization of operating lease right-of-use assets.

[0001375365-21-000060:mdna:124]
Investing Activities

[0001375365-21-000060:mdna:125]
Net cash used in investing activities was $58.0 million, $43.6 million and $24.8 million for the fiscal years 2021, 2020 and 2019, respectively, as we invested in our Green Computing Park in San Jose to expand our capacity and office space we purchased and expanded our Bade Facility in Taiwan and made purchases of property, plant and equipment.

[0001375365-21-000060:mdna:126]
Financing Activities

[0001375365-21-000060:mdna:127]
Net cash used in financing activities increased by $68.2 million for fiscal year 2021 as compared to fiscal year 2020 primarily due to an increase of $130.0 million in repurchase of our common stock, partially offset by an increase of $61.9 million in proceeds from borrowings net of repayment. Net cash used in financing activities decreased by $119.6 million for fiscal year 2020 as compared to fiscal year 2019 primarily due to decreased net repayments of debt of $96.4 million, and cash receipts from exercises of stock options of $28.3 million offset by increased cash payments for withholding taxes from the vesting of restricted stock of $5.2 million.

[0001375365-21-000060:mdna:128]
Other Factors Affecting Liquidity and Capital Resources

[0001375365-21-000060:mdna:129]
2018 Bank of America Credit Facility

[0001375365-21-000060:mdna:130]
In April 2018, we entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility").  On June 28, 2021, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 28, 2026, reduce the size of the facility from $250.0 million to $200.0 million, increase the maximum amount that we can request the facility be increased (the accordion feature) from $100.0 million to $150.0 million, and update provisions relating to erroneous payments and LIBOR replacement mechanics. In addition, the amendment reduced both the unused line fee from 0.375% per annum to 0.2% or 0.3% per annum (depending upon amount drawn under the facility) and the interest rate applicable to the facility from LIBOR plus 2.00% or 3.00% per annum (depending upon amount drawn under the facility) to LIBOR plus 1.375% or 1.625% per annum. As of June 30, 2021, we had no outstanding borrowings. Our available borrowing capacity was $200.0 million, subject to the borrowing base limitation and compliance with other applicable terms. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. In addition, we are not permitted to pay any dividends. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-21-000060:mdna:131]
CTBC Bank

[0001375365-21-000060:mdna:132]
2020 CTBC Credit Facility

[0001375365-21-000060:mdna:133]
In August 2020, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans of up to $50.0 million (the "2020 CTBC Credit Facility"), which had a maturity date of August 2021. As of June 30, 2021, the outstanding borrowings under the CTBC Credit Facility revolving line of credit were $18.0 million and the interest rates for these loans were 0.98% per annum. The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $25.1 million at June 30, 2021 and the interest rates for these loans were 0.75% per annum. The amount available for future borrowing under the CTBC Credit Facility was $6.9 million as of June 30, 2021. The term loans are secured by certain of our assets, including certain property, plant, and land. There are no financial covenants under the 2020 CTBC Credit Facility.

[0001375365-21-000060:mdna:134]
2020 CTBC Term Loan Facility due June 4, 2030

[0001375365-21-000060:mdna:135]
In May 2020, we entered into a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of our Bade Manufacturing Facility located in Taiwan. Draw downs on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and are drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. We are required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility, including any expansion. Fees paid to the lender as debt issuance costs were immaterial. We borrowed $29.0 million in the fiscal year ended June 30, 2021 with a rate of 0.45% per annum. As of June 30, 2021, the amount outstanding under the 2020 CTBC Term Loan Facility was $34.7 million and the net book value of the property serving as collateral was $45.9 million. We have financial covenants

[0001375365-21-000060:mdna:136]
requiring our current ratio, debt service coverage ratio, and financial debt ratio, to be maintained at certain levels. As of June 30, 2021, we were in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000060:mdna:137]
2021 CTBC Credit Lines

[0001375365-21-000060:mdna:138]
On July 20, 2021 (the “Effective Date”), we entered into a general agreement for omnibus credit lines with CTBC Bank, which replaced the 2020 CTBC Credit Facility and 2020 CTBC Term Loan Facility (the “Prior CTBC Credit Lines”) in their entirety and permits borrowings, from time to time, of (i) a term loan facility of up to NTD1,550.0 million ($55.4 million in U.S. dollar equivalents) and (ii) a line of credit facility of up to US$105.0 million (the “2021 CTBC Credit Lines”). Interest rates are to be established according to individual credit arrangements established pursuant to the 2021 CTBC Credit Lines, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Term loans made pursuant to the 2021 CTBC Credit Lines are secured by certain of our assets, including certain property, land, plant, and equipment located in Bade, Taiwan. We are subject to various financial covenants under the 2021 CTBC Credit Lines, including current ratio, debt service coverage ratio, and financial debt ratio requirements. Amounts outstanding under the Prior CTBC Credit Lines on the Effective Date were assumed by the 2021 CTBC Credit Lines.

[0001375365-21-000060:mdna:139]
E.SUN Credit Facility

[0001375365-21-000060:mdna:140]
In December 2020, Super Micro Computer Inc, Taiwan, our wholly-owned Taiwan subsidiary, entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. The E.SUN Credit Facility provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. Terms for specific drawdowns are set forth in separate Notification and Confirmation of Credit Conditions by and between us and E.SUN Bank. The E.SUN Credit Facility expires September 18, 2021. There are no financial covenants associated with the E.SUN Credit Facility. A Notification and Confirmation Agreement was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) under the E. SUN Credit Facility with a tenor of 120 days bearing interest at a rate based on LIBOR or TAIFX plus a fixed margin. As of June 30, 2021, the amounts outstanding under the E.SUN Credit Facility were $20.4 million and the interest rates for these loans ranged from approximately .0% to1.29% per annum. As of June 30, 2021, the amount available for future borrowing under the E.SUN Credit Facility was $9.6 million.

[0001375365-21-000060:mdna:141]
Refer to Part I, Item 1, Note 10, “Short-term and Long-term Debt” in our notes to consolidated financial statements in this Annual Report on Form 10-K for further information on our outstanding debt.

[0001375365-21-000060:mdna:142]
Capital Expenditure Requirements

[0001375365-21-000060:mdna:143]
We anticipate our capital expenditures in fiscal year 2022 will be approximately $21.4 million, relating primarily to costs associated in our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades. We will continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-21-000060:mdna:144]
We intend to continue to focus our capital expenditures in fiscal year 2022 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings, the investments in our office facilities and our systems infrastructure, the continuing market acceptance of our offerings and our planned investments, particularly in our product development efforts, applications or technologies.

[0001375365-21-000060:mdna:145]
Contractual Obligations

[0001375365-21-000060:mdna:146]
Our estimated future obligations as of June 30, 2021 include both current and long term obligations. For our long-term debt as noted in Part I, Item 1, Note 10, “Short-term and Long-term Debt”, we have a current obligation of $63.5 million and a long-term obligation of $34.7 million. Under our operating leases as noted in Note 12, "Leases", we have a current obligation of $6.3 million and a long-term obligation of $14.5 million. As noted in Note 16, "Commitments and Contingencies", we have current obligations related to noncancelable purchase commitments of $569.8 million.

[0001375365-21-000060:mdna:147]
Recent Accounting Pronouncements

[0001375365-21-000060:mdna:148]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Part II, Item 8, Note 1, “Organization and Summary of Significant Accounting Policies” to the consolidated financial statements in this Annual Report.

[0001375365-21-000060:mdna:149]
47
