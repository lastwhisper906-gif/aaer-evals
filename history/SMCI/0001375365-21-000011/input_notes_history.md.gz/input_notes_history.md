# SMCI note change history — 0001375365-20-000074 → 0001375365-21-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  The Court has taken the motion under submission. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.
  (was, 2020-11-06, similarity 0.9476):
[0001375365-20-000074:note_history:1]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  The Court has not set a new date for the motion to dismiss hearing, but expects the hearing will be set in late 2020 or early 2021 following completion of supplemental motion to dismiss briefing. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

- added (2021-02-05):
[0001375365-21-000011:note_history:2]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190 (the “Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.  A case management conference has been set for late February 2021, and the matter is stayed until such time.

- added (2021-02-05):
[0001375365-21-000011:note_history:3]
On November 13, 2020, Build Group Inc. (“Build Group”) filed a complaint against the Company in the Superior Court for Santa Clara County, seeking damages of approximately $2 million.  Build Group served the complaint on the Company on December 1, 2020.  Build Group alleged that the Company breached the construction contract between the Company and Build Group by failing to approve or reject certain requests for change orders to the scope of work covered by the construction project in a timely manner, or at all. A substantial portion of the amounts covered by the change orders at issue related to delays in the construction project.  Build Group asserted that these delays were beyond its control and that therefore it was entitled to additional payments as a result of the delays in completion of the project.  The Company believed that it had meritorious defenses to Build Group’s claims, but nonetheless negotiated a settlement with Build Group. The settlement agreement resolving this dispute was executed effective January 19, 2021. As a result, the Company did not have to respond to the complaint. Per the settlement agreement, Build Group agreed to dismiss the entire action with prejudice once the Company complied with its obligations under the settlement agreement. The Company has complied with its obligations and Build Group has submitted the dismissal, which should be granted by the court in the near term. As of December 31, 2020, the Company recorded a liability of $1.6 million for the construction project expenses incurred pertaining to this matter.

- changed (2021-02-05):
[0001375365-21-000011:note_history:4]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections
  (was, 2020-11-06, similarity 0.732):
[0001375365-20-000074:note_history:4]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections 17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

- added (2021-02-05):
[0001375365-21-000011:note_history:5]
17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

- changed (2021-02-05):
[0001375365-21-000011:note_history:6]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2020 and any prior periods.
  (was, 2020-11-06, similarity 0.9893):
[0001375365-20-000074:note_history:6]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of September 30, 2020 and any prior periods.

- changed (2021-02-05):
[0001375365-21-000011:note_history:7]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2020, these remaining noncancelable commitments were $248.3 million, including $52.3 million for related parties.
  (was, 2020-11-06, similarity 0.6362):
[0001375365-20-000074:note_history:7]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2020, these remaining noncancelable commitments were $119.7 million, including $33.1 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:8]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies", in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.
  (was, 2020-11-06, similarity 0.9959):
[0001375365-20-000074:note_history:8]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, Organization and Summary of Significant Accounting Policies, in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19') pandemic.

- changed (2021-02-05):
[0001375365-21-000011:note_history:9]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.
  (was, 2020-11-06, similarity 0.9959):
[0001375365-20-000074:note_history:9]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principals in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.

- changed (2021-02-05):
[0001375365-21-000011:note_history:10]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.
  (was, 2020-11-06, similarity 0.7142):
[0001375365-20-000074:note_history:10]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.

- changed (2021-02-05):
[0001375365-21-000011:note_history:11]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of December 31, 2020 and June 30, 2020, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $0.0 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed
  (was, 2020-11-06, similarity 0.9501):
[0001375365-20-000074:note_history:11]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of September 30, 2020 and June 30, 2020, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $0.5 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed consolidated balance sheets.

- added (2021-02-05):
[0001375365-21-000011:note_history:12]
consolidated balance sheets.

- changed (2021-02-05):
[0001375365-21-000011:note_history:13]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2020. No impairment charge was recorded for the three and six months ended December 31, 2020 and 2019, respectively.
  (was, 2020-11-06, similarity 0.9518):
[0001375365-20-000074:note_history:13]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of September 30, 2020. No impairment charge was recorded for the three months ended September 30, 2020 and 2019, respectively.

- added (2021-02-05):
[0001375365-21-000011:note_history:14]
The Company sold products worth $13.2 million and $15.4 million to the Corporate Venture in the three months ended December 31, 2020 and 2019, respectively, and $19.6 million and $37.5 million for the six months ended December 31, 2020 and 2019, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2020 and June 30, 2020 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $14.4 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of December 31, 2020 and June 30, 2020, respectively.

- changed (2021-02-05):
[0001375365-21-000011:note_history:15]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.0% and 28.5% of total purchases for the three months ended December 31, 2020 and 2019, respectively, and 20.9% and 28.6% for the six months ended December 31, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 7.3% and 10.3% of total cost of sales for the three months ended December 31, 2020 and 2019, respectively, and a combined 8.5% and 10.0% for the six months ended December 31, 2020 and 2019, respectively.
  (was, 2020-11-06, similarity 0.7633):
[0001375365-20-000074:note_history:15]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 22.0% and 28.7% of total purchases for the three months ended September 30, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for 9.8% and 9.7% of total cost of sales for the three months ended September 30, 2020 and 2019, respectively.

- changed (2021-02-05):
[0001375365-21-000011:note_history:16]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2020, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.
  (was, 2020-11-06, similarity 0.9535):
[0001375365-20-000074:note_history:16]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three months ended September 30, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of September 30, 2020, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.

- added (2021-02-05):
[0001375365-21-000011:note_history:17]
Treasury Stock

- added (2021-02-05):
[0001375365-21-000011:note_history:18]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

- changed (2021-02-05):
[0001375365-21-000011:note_history:19]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three and six months ended December 31, 2020.
  (was, 2020-11-06, similarity 0.9738):
[0001375365-20-000074:note_history:19]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three months ended September 30, 2020.

- changed (2021-02-05):
[0001375365-21-000011:note_history:20]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of December 31, 2020, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial. See Note 5, "Fair Value Disclosure".
  (was, 2020-11-06, similarity 0.9728):
[0001375365-20-000074:note_history:20]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of September 30, 2020, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial.  See Note 5 below.

- changed (2021-02-05):
[0001375365-21-000011:note_history:21]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of
  (was, 2020-11-06, similarity 0.8062):
[0001375365-20-000074:note_history:21]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.

- added (2021-02-05):
[0001375365-21-000011:note_history:22]
a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.

- changed (2021-02-05):
[0001375365-21-000011:note_history:23]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its condensed consolidated financial statements and disclosures.
  (was, 2020-11-06, similarity 0.7982):
[0001375365-20-000074:note_history:23]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July

- changed (2021-02-05):
[0001375365-21-000011:note_history:24]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 and E.SUN Credit Facility will terminate on September 18, 2021. As both credit facilities will expire before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its condensed consolidated financial statements and disclosures.
  (was, 2020-11-06, similarity 0.7926):
[0001375365-20-000074:note_history:24]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility. As the 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its consolidated financial statements and disclosures.

- removed (2021-02-05):
[0001375365-20-000074:note_history:25]
The Company sold products worth $0.6 million and $22.1 million to the Corporate Venture in the three months ended September 30, 2020 and 2019, respectively, and the Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture in the amounts of $2.3 million and $3.0 million as of September 30, 2020 and June 30, 2020, respectively, have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.6 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of September 30, 2020 and June 30, 2020, respectively.

- removed (2021-02-05):
[0001375365-20-000074:note_history:26]
1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:27]
Short-term and Long-term Debt
    Short-term debt obligations as of December 31, 2020 and June 30, 2020 consisted of the following (in thousands):
  (was, 2020-11-06, similarity 0.9811):
[0001375365-20-000074:note_history:27]
Short-term and Long-term Debt
    Short-term debt obligations as of September 30, 2020 and June 30, 2020 consisted of the following (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:28]
|  | December 31, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,921 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 20,577 |  |  | 5,697 |  |
| Total debt | 45,498 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,921 |  |  | 23,704 |  |
| Debt, Non-current | $ | 20,577 |  |  | $ | 5,697 |  |
  (was, 2020-11-06, similarity 0.9884):
[0001375365-20-000074:note_history:28]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,047 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 11,980 |  |  | 5,697 |  |
| Total debt | 36,027 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,047 |  |  | 23,704 |  |
| Debt, Non-current | $ | 11,980 |  |  | $ | 5,697 |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:29]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 30, 2021 and provide that in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. The amendment was accounted for as a modification and the impact was immaterial to the condensed consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.
  (was, 2020-11-06, similarity 0.7842):
[0001375365-20-000074:note_history:29]
In April 2018, the Company entered into a revolving line of credit with Bank of America (the "2018 Bank of America Credit Facility"), which was amended on May 12, 2020. The Company paid a fee of $0.7 million and entered into a third amendment of the 2018 Bank of America Credit Facility that extended the maturity of the credit facility to June 30, 2021 and changed certain terms of the original agreement. The amendment was accounted for as a modification and the impact was immaterial to the consolidated financial statements. Under the terms of the May 12, 2020 amendment of the 2018 Bank of America Credit Facility, in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

- changed (2021-02-05):
[0001375365-21-000011:note_history:30]
As of December 31, 2020 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2020 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.3 million and $0.6 million as of December 31, 2020 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of December 31, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.
  (was, 2020-11-06, similarity 0.9836):
[0001375365-20-000074:note_history:30]
As of September 30, 2020 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of September 30, 2020 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.5 million and $0.6 million as of September 30, 2020 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of September 30, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

- changed (2021-02-05):
[0001375365-21-000011:note_history:31]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar
  (was, 2020-11-06, similarity 0.7445):
[0001375365-20-000074:note_history:31]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade,

- changed (2021-02-05):
[0001375365-21-000011:note_history:32]
equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.
  (was, 2020-11-06, similarity 0.8888):
[0001375365-20-000074:note_history:32]
Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

- changed (2021-02-05):
[0001375365-21-000011:note_history:33]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.9 million and $23.7 million at December 31, 2020 and June 30, 2020, respectively. As of December 31, 2020 and June 30, 2020, the Company did not have any outstanding borrowings under the CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.73% per annum as of December 31, 2020 and 0.63% per annum as of June 30, 2020. At December 31, 2020, the amount available for future borrowing under the CTBC Credit Facility was $25.1 million. As of December 31, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.1 million.
  (was, 2020-11-06, similarity 0.9752):
[0001375365-20-000074:note_history:33]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.0 million and $23.7 million at September 30, 2020 and June 30, 2020, respectively. As of September 30, 2020 and June 30, 2020, the Company did not have any outstanding borrowings under the CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.73% per annum as of September 30, 2020 and 0.63% per annum as of June 30, 2020. At September 30, 2020, the amount available for future borrowing under the CTBC Credit Facility was $26.0 million. As of September 30, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.3 million.

- changed (2021-02-05):
[0001375365-21-000011:note_history:34]
As of December 31, 2020 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $20.6 million and $5.7 million, respectively. The interest rate for these loans were 0.45% per annum as of December 31, 2020 and June 30, 2020. The net book value of the property serving as collateral as of December 31, 2020 was $29.2 million. As of December 31, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.
  (was, 2020-11-06, similarity 0.9674):
[0001375365-20-000074:note_history:34]
As of September 30, 2020 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $12.0 million and $5.7 million, respectively. The interest rate for these loans were 0.45% per annum as of September 30, 2020 and June 30, 2020. The net book value of the property serving as collateral as of September 30, 2020 was $17.1 million. As of September 30, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

- added (2021-02-05):
[0001375365-21-000011:note_history:35]
E.SUN Bank Credit Facility

- added (2021-02-05):
[0001375365-21-000011:note_history:36]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. Such Credit Facility provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. The term of the E.SUN Credit Facility expires on September 18, 2021.

- added (2021-02-05):
[0001375365-21-000011:note_history:37]
Generally, the interest for base rate loans made under the E.SUN Credit Facility is based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment.  Interest for adjustable loan rate loans made under the E.SUN Credit Facility is based upon an average one-year fixed rate time saving deposit rate of a selected reference bank which shall be a well-known domestic bank in Taiwan, and is subject to occasional adjustment. The E.SUN Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event such Taiwan subsidiary of the Company has an overdue liability at another financial organization. There are no financial covenants associated with the E.SUN Credit Facility.
Terms for specific drawdown instruments issued under the E.SUN Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions negotiated with E.SUN Bank. A Notification and Confirmation of Credit Conditions agreement under the E.SUN Credit Facility was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days and with an interest rate calculated based on the higher of LIBOR plus 0.75% then divided by 0.946 or TAIFX plus 0.55% then divided by 0.946. As of December 31, 2020, no drawings had been made from the Import Loan.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:38]
Short-term debt obligations as of December 31, 2020 and June 30, 2020 consisted of the following (in thousands):
  (was, 2020-11-06, similarity 0.9756):
[0001375365-20-000074:note_history:38]
Short-term debt obligations as of September 30, 2020 and June 30, 2020 consisted of the following (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:39]
|  | December 31, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,921 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 20,577 |  |  | 5,697 |  |
| Total debt | 45,498 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,921 |  |  | 23,704 |  |
| Debt, Non-current | $ | 20,577 |  |  | $ | 5,697 |  |
  (was, 2020-11-06, similarity 0.9884):
[0001375365-20-000074:note_history:39]
|  | September 30, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,047 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 11,980 |  |  | 5,697 |  |
| Total debt | 36,027 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,047 |  |  | 23,704 |  |
| Debt, Non-current | $ | 11,980 |  |  | $ | 5,697 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:40]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.
  (was, 2020-11-06, similarity 0.9971):
[0001375365-20-000074:note_history:40]
Related Party Transactions The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and 
Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

- added (2021-02-05):
[0001375365-21-000011:note_history:41]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 91.6% and 97.5% of the chassis included in the products sold by the Company during the three months ended December 31, 2020 and 2019, respectively, and 92.6% and 95.4% of the chassis included in the products sold by the Company during the six months ended December31, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2021-02-05):
[0001375365-21-000011:note_history:42]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $25.4 million and $23.2 million at December 31, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2020-11-06, similarity 0.9965):
[0001375365-20-000074:note_history:42]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $11.1 million and $23.2 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2021-02-05):
[0001375365-21-000011:note_history:43]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the
  (was, 2020-11-06, similarity 0.6829):
[0001375365-20-000074:note_history:43]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

- added (2021-02-05):
[0001375365-21-000011:note_history:44]
responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

- changed (2021-02-05):
[0001375365-21-000011:note_history:45]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.
  (was, 2020-11-06, similarity 0.9955):
[0001375365-20-000074:note_history:45]
The Company also has entered into a series of agreements with Compuware, including a multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

- changed (2021-02-05):
[0001375365-21-000011:note_history:46]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.
  (was, 2020-11-06, similarity 0.8885):
[0001375365-20-000074:note_history:46]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these

- changed (2021-02-05):
[0001375365-21-000011:note_history:47]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $26.8 million and $45.7 million at December 31, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2020-11-06, similarity 0.9946):
[0001375365-20-000074:note_history:47]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $21.9 million and $45.7 million at September 30, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- changed (2021-02-05):
[0001375365-21-000011:note_history:48]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2020 and 2019, are as follows (in thousands):
  (was, 2020-11-06, similarity 0.9582):
[0001375365-20-000074:note_history:48]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2020 and 2019, are as follows (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:49]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 24,580 |  |  | $ | 44,568 |  |  | $ | 50,903 |  |  | $ | 77,688 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 5,572 |  |  | $ | 6,406 |  |  | $ | 18,871 |  |  | $ | 11,953 |  |
| Purchases (1) | 29,644 |  |  | 33,438 |  |  | 68,571 |  |  | 66,754 |  |
  (was, 2020-11-06, similarity 0.7619):
[0001375365-20-000074:note_history:49]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 26,324 |  |  | $ | 33,120 |  |  |  |  |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 13,299 |  |  | $ | 5,547 |  |  |  |  |  |
| Purchases (1) | 38,927 |  |  | 33,316 |  |  |  |  |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:50]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2020 and 2019.
  (was, 2020-11-06, similarity 0.9366):
[0001375365-20-000074:note_history:50]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2020 and 2019.

- changed (2021-02-05):
[0001375365-21-000011:note_history:51]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2020 and June 30, 2020 (in thousands):
  (was, 2020-11-06, similarity 0.9818):
[0001375365-20-000074:note_history:51]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2020 and June 30, 2020 (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:52]
|  | December 31, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,099 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 27,002 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,767 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 30,594 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 28 |  |  | 186 |  |
  (was, 2020-11-06, similarity 0.9898):
[0001375365-20-000074:note_history:52]
|  | September 30, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 2,164 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 24,901 |  |  | 40,056 |  |
| Other long-term liabilities (3) | 560 |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,130 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 33,421 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 108 |  |  | 186 |  |

- removed (2021-02-05):
[0001375365-20-000074:note_history:53]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 93.6% and 92.7% of the chassis included in the products sold by the Company during the three months ended September 30, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- removed (2021-02-05):
[0001375365-20-000074:note_history:54]
materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:55]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2020 and 2019, are as follows (in thousands):
  (was, 2020-11-06, similarity 0.9582):
[0001375365-20-000074:note_history:55]
The Company’s results from transactions with Ablecom and Compuware for each of the three months ended September 30, 2020 and 2019, are as follows (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:56]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 24,580 |  |  | $ | 44,568 |  |  | $ | 50,903 |  |  | $ | 77,688 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 5,572 |  |  | $ | 6,406 |  |  | $ | 18,871 |  |  | $ | 11,953 |  |
| Purchases (1) | 29,644 |  |  | 33,438 |  |  | 68,571 |  |  | 66,754 |  |
  (was, 2020-11-06, similarity 0.7619):
[0001375365-20-000074:note_history:56]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 26,324 |  |  | $ | 33,120 |  |  |  |  |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 13,299 |  |  | $ | 5,547 |  |  |  |  |  |
| Purchases (1) | 38,927 |  |  | 33,316 |  |  |  |  |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:57]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2020 and 2019.
  (was, 2020-11-06, similarity 0.9366):
[0001375365-20-000074:note_history:57]
The Company's net sales to Ablecom were not material for the three months ended September 30, 2020 and 2019.

- changed (2021-02-05):
[0001375365-21-000011:note_history:58]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2020 and June 30, 2020 (in thousands):
  (was, 2020-11-06, similarity 0.9818):
[0001375365-20-000074:note_history:58]
The Company had the following balances related to transactions with Ablecom and Compuware as of September 30, 2020 and June 30, 2020 (in thousands):

- changed (2021-02-05):
[0001375365-21-000011:note_history:59]
|  | December 31, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,099 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 27,002 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,767 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 30,594 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 28 |  |  | 186 |  |
  (was, 2020-11-06, similarity 0.9898):
[0001375365-20-000074:note_history:59]
|  | September 30, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 2,164 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 24,901 |  |  | 40,056 |  |
| Other long-term liabilities (3) | 560 |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,130 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 33,421 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 108 |  |  | 186 |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:60]
(2) Includes current portion of operating lease liabilities.
  (was, 2020-11-06, similarity 0.6417):
[0001375365-20-000074:note_history:60]
(2) Includes current portion of operating lease liabilities.
(3) Represents non-current portion of operating lease liabilities.

- added (2021-02-05):
[0001375365-21-000011:note_history:61]
(3) Represents non-current portion of operating lease liabilities.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:62]
|  | Three Months Ended December 31, |  |  |  | Six Months Ended December 31, |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2019 |  |  |
| Server and storage systems | $ | 642,711 |  |  |  |  | $ | 672,727 |  |  |  |  | $ | 1,260,499 |  |  |  |  | $ | 1,308,753 |  |  |  |
| Subsystems and accessories | 187,595 |  |  |  |  | 198,216 |  |  |  |  | 332,057 |  |  |  |  | 361,994 |  |  |  |
| Total | $ | 830,306 |  |  |  |  | $ | 870,943 |  |  |  |  | $ | 1,592,556 |  |  |  |  | $ | 1,670,747 |  |  |  |
  (was, 2020-11-06, similarity 0.6924):
[0001375365-20-000074:note_history:62]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617,788 |  |  |  |  | $ | 636,026 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 144,462 |  |  |  |  | 163,778 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 762,250 |  |  |  |  | $ | 799,804 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:63]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-11-06, similarity 0.886):
[0001375365-20-000074:note_history:63]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2020 and 2019, of net sales by geographic region (in thousands):

- added (2021-02-05):
[0001375365-21-000011:note_history:64]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 463,102 |  |  | $ | 527,404 |  |  | $ | 959,188 |  |  | $ | 996,245 |  |
| Asia | 161,415 |  |  | 165,716 |  |  | 288,121 |  |  | 327,355 |  |
| Europe | 154,819 |  |  | 147,564 |  |  | 266,908 |  |  | 275,623 |  |
| Others | 50,970 |  |  | 30,259 |  |  | 78,339 |  |  | 71,524 |  |
|  | $ | 830,306 |  |  | $ | 870,943 |  |  | $ | 1,592,556 |  |  | $ | 1,670,747 |  |

- removed (2021-02-05):
[0001375365-20-000074:note_history:65]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 496,086 |  |  | $ | 468,841 |  |  |  |  |  |
| Europe | 112,089 |  |  | 128,059 |  |  |  |  |  |
| Asia | 126,707 |  |  | 161,639 |  |  |  |  |  |
| Others | 27,368 |  |  | 41,265 |  |  |  |  |  |
|  | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001375365-21-000011:note_history:66]
|  | Three Months Ended December 31, |  |  |  | Six Months Ended December 31, |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2019 |  |  |
| Server and storage systems | $ | 642,711 |  |  |  |  | $ | 672,727 |  |  |  |  | $ | 1,260,499 |  |  |  |  | $ | 1,308,753 |  |  |  |
| Subsystems and accessories | 187,595 |  |  |  |  | 198,216 |  |  |  |  | 332,057 |  |  |  |  | 361,994 |  |  |  |
| Total | $ | 830,306 |  |  |  |  | $ | 870,943 |  |  |  |  | $ | 1,592,556 |  |  |  |  | $ | 1,670,747 |  |  |  |
  (was, 2020-11-06, similarity 0.6924):
[0001375365-20-000074:note_history:66]
|  | Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |  |  |  |  |
| Server and storage systems | $ | 617,788 |  |  |  |  | $ | 636,026 |  |  |  |  |  |  |  |  |  |  |  |
| Subsystems and accessories | 144,462 |  |  |  |  | 163,778 |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 762,250 |  |  |  |  | $ | 799,804 |  |  |  |  |  |  |  |  |  |  |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:67]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2020 and 2019, of net sales by geographic region (in thousands):
  (was, 2020-11-06, similarity 0.886):
[0001375365-20-000074:note_history:67]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three months ended September 30, 2020 and 2019, of net sales by geographic region (in thousands):

- added (2021-02-05):
[0001375365-21-000011:note_history:68]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 463,102 |  |  | $ | 527,404 |  |  | $ | 959,188 |  |  | $ | 996,245 |  |
| Asia | 161,415 |  |  | 165,716 |  |  | 288,121 |  |  | 327,355 |  |
| Europe | 154,819 |  |  | 147,564 |  |  | 266,908 |  |  | 275,623 |  |
| Others | 50,970 |  |  | 30,259 |  |  | 78,339 |  |  | 71,524 |  |
|  | $ | 830,306 |  |  | $ | 870,943 |  |  | $ | 1,592,556 |  |  | $ | 1,670,747 |  |

- changed (2021-02-05):
[0001375365-21-000011:note_history:69]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and six months ended December 31, 2020, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $26.8 million and $55.4 million, respectively.
  (was, 2020-11-06, similarity 0.9418):
[0001375365-20-000074:note_history:69]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three months ended September 30, 2020, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $28.6 million.

- changed (2021-02-05):
[0001375365-21-000011:note_history:70]
Deferred revenue decreased $8.8 million during the six months ended December 31, 2020 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.
  (was, 2020-11-06, similarity 0.9099):
[0001375365-20-000074:note_history:70]
Deferred revenue decreased $1.9 million during the three months ended September 30, 2020 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

- changed (2021-02-05):
[0001375365-21-000011:note_history:71]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2020 was $194.9 million. The Company expects to recognize approximately 51% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2020-11-06, similarity 0.7399):
[0001375365-20-000074:note_history:71]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of September 30, 2020 was $201.8 million. The Company expects to recognize approximately 52% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- changed (2021-02-05):
[0001375365-21-000011:note_history:72]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies
  (was, 2020-11-06, similarity 0.7267):
[0001375365-20-000074:note_history:72]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s consolidated financial statements.

- added (2021-02-05):
[0001375365-21-000011:note_history:73]
judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

- changed (2021-02-05):
[0001375365-21-000011:note_history:74]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s condensed consolidated financial statements.
  (was, 2020-11-06, similarity 0.9886):
[0001375365-20-000074:note_history:74]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s consolidated financial statements.

- removed (2021-02-05):
[0001375365-20-000074:note_history:75]
|  | Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| United States | $ | 496,086 |  |  | $ | 468,841 |  |  |  |  |  |
| Europe | 112,089 |  |  | 128,059 |  |  |  |  |  |
| Asia | 126,707 |  |  | 161,639 |  |  |  |  |  |
| Others | 27,368 |  |  | 41,265 |  |  |  |  |  |
|  | $ | 762,250 |  |  | $ | 799,804 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-02-05):
[0001375365-21-000011:note_history:76]
Subsequent EventOn January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $200.0 million at market price. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased.

- removed (2021-02-05):
[0001375365-20-000074:note_history:77]
Subsequent EventsOn October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190 (the “Derivative Action”).  The Company was also named as a nominal defendant.  The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.On October 31, 2020, the Company's Board of Directors approved a share repurchase program to repurchase shares of its common stock for up to $50 million at prevailing prices in the open market. The share repurchase program is effective until October 31, 2021 or until the maximum amount of common stock is repurchased, whichever occurs first.
