# SMCI notes — 0001375365-21-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-21-000011:notes:1]
[same as prior period, unchanged from 0001375365-20-000074:notes:1]

[0001375365-21-000011:notes:2]
No material changes have been made to the significant accounting policies of Super Micro Computer, Inc., a corporation incorporated under the laws of Delaware, and its consolidated entities (together, the “Company”), disclosed in Note 1, "Organization and Summary of Significant Accounting Policies", in its Annual Report on Form 10-K, filed on August 28, 2020, for the year ended June 30, 2020. Management's estimates include, as applicable, the anticipated impacts of the coronavirus ("COVID-19") pandemic.

[0001375365-21-000011:notes:3]
[same as prior period, unchanged from 0001375365-20-000074:notes:3]

[0001375365-21-000011:notes:4]
The unaudited condensed consolidated financial statements included herein have been prepared by the Company pursuant to the rules and regulations of the United States Securities and Exchange Commission (the “SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States of America ("U.S. GAAP") have been condensed or omitted pursuant to such rules and regulations.

[0001375365-21-000011:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2020 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2021.

[0001375365-21-000011:notes:6]
[same as prior period, unchanged from 0001375365-20-000074:notes:6]

[0001375365-21-000011:notes:7]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the "Corporate Venture") located in China to expand the Company's presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-21-000011:notes:8]
The Company recorded a deferred gain related to the contribution of certain technology rights. As of December 31, 2020 and June 30, 2020, the Company had unamortized deferred gain balance of $2.0 million and $2.0 million, respectively, in accrued liabilities and $0.0 million and $1.0 million, respectively, in other long-term liabilities in the Company’s condensed

[0001375365-21-000011:notes:9]
consolidated balance sheets.

[0001375365-21-000011:notes:10]
[same as prior period, unchanged from 0001375365-20-000074:notes:9]

[0001375365-21-000011:notes:11]
several of the parent's related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company is working with the Corporate Venture's management to ensure that the Corporate Venture remains in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2020. No impairment charge was recorded for the three and six months ended December 31, 2020 and 2019, respectively.

[0001375365-21-000011:notes:12]
The Company sold products worth $13.2 million and $15.4 million to the Corporate Venture in the three months ended December 31, 2020 and 2019, respectively, and $19.6 million and $37.5 million for the six months ended December 31, 2020 and 2019, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2020 and June 30, 2020 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $14.4 million and $7.8 million due from the Corporate Venture in accounts receivable, net as of December 31, 2020 and June 30, 2020, respectively.

[0001375365-21-000011:notes:13]
[same as prior period, unchanged from 0001375365-20-000074:notes:12]

[0001375365-21-000011:notes:14]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. One supplier accounted for 20.0% and 28.5% of total purchases for the three months ended December 31, 2020 and 2019, respectively, and 20.9% and 28.6% for the six months ended December 31, 2020 and 2019, respectively. Ablecom and Compuware, related parties of the Company (see Note 8, "Related Party Transactions") accounted for a combined 7.3% and 10.3% of total cost of sales for the three months ended December 31, 2020 and 2019, respectively, and a combined 8.5% and 10.0% for the six months ended December 31, 2020 and 2019, respectively.

[0001375365-21-000011:notes:15]
[same as prior period, unchanged from 0001375365-20-000074:notes:14]

[0001375365-21-000011:notes:16]
Financial instruments which potentially subject the Company to concentration of credit risk consist primarily of cash and cash equivalents, restricted cash, investment in an auction rate security and accounts receivable. No single customer accounted for 10% or more of the net sales for the three and six months ended December 31, 2020 and 2019. No customer accounted for greater than 10% of the Company's accounts receivable, net as of December 31, 2020, whereas one customer accounted for 10.1% of accounts receivable, net as of June 30, 2020.

[0001375365-21-000011:notes:17]
Treasury Stock

[0001375365-21-000011:notes:18]
The Company accounts for treasury stock under the cost method. Upon the retirement of treasury shares, the Company deducts the par value of the retired treasury shares from common stock and allocates the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-21-000011:notes:19]
[same as prior period, unchanged from 0001375365-20-000074:notes:16]

[0001375365-21-000011:notes:20]
[same as prior period, unchanged from 0001375365-20-000074:notes:17]

[0001375365-21-000011:notes:21]
The Company maintains an allowance for credit losses for accounts receivable and the investment in an auction rate security. The allowance for credit losses is estimated using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. The new guidance has no material impact on the Company's condensed consolidated financial statements for the three and six months ended December 31, 2020.

[0001375365-21-000011:notes:22]
In August 2018, the FASB issued amended guidance, Fair Value Measurement: Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, to modify the disclosure requirements on fair value measurements based on the concepts in the FASB Concepts Statements, including the consideration of costs and benefits. The Company adopted this guidance on July 1, 2020. As of December 31, 2020, the Company’s investment in an auction rate security is the only Level 3 investment measured at fair value on a recurring basis. Changes to the disclosures in the condensed consolidated financial statements were immaterial. See Note 5, "Fair Value Disclosure".

[0001375365-21-000011:notes:23]
In August 2018, the FASB issued authoritative guidance, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract as well as hosting arrangements that include an internal use software license with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The accounting for the service element of

[0001375365-21-000011:notes:24]
a hosting arrangement that is a service contract is not affected by the new guidance. The Company adopted this guidance on July 1, 2020, prospectively. The adoption of this guidance did not have a material impact on the Company's condensed consolidated financial statements and disclosures.

[0001375365-21-000011:notes:25]
[same as prior period, unchanged from 0001375365-20-000074:notes:21]

[0001375365-21-000011:notes:26]
In December 2019, the FASB issued amended guidance, Simplifying the Accounting for Income Taxes, to remove certain exceptions to the general principles from ASC 740 - Income Taxes, and to improve consistent application of U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. The guidance is effective for the Company from July 1, 2021; early adoption is permitted. The adoption of the guidance is not anticipated to have a material impact on its condensed consolidated financial statements and disclosures.

[0001375365-21-000011:notes:27]
In March 2020, the FASB issued authoritative guidance, Facilitation of the Effects of Reference Rate Reform on Financial Reporting. The new guidance provides optional expedients and exceptions for applying generally accepted accounting principles to contract modifications and hedging relationships, subject to meeting certain criteria, that reference LIBOR or another reference rate expected to be discontinued.  The guidance also establishes (1) a general contract modification principle that entities can apply in other areas that may be affected by reference rate reform and (2) certain elective hedge accounting expedients. The amendment is effective for all entities through December 15, 2022. LIBOR is used to calculate the interest on borrowings under the Company's 2018 Bank of America Credit Facility and E.SUN Credit Facility. The 2018 Bank of America Credit Facility, as amended, will terminate on June 30, 2021 and E.SUN Credit Facility will terminate on September 18, 2021. As both credit facilities will expire before the phase out of LIBOR, the Company does not expect the adoption of the guidance to have an impact on its condensed consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-21-000011:notes:28]
[same as prior period, unchanged from 0001375365-20-000074:notes:25]

[0001375365-21-000011:notes:29]
[same as prior period, unchanged from 0001375365-20-000074:notes:26]

[0001375365-21-000011:notes:30]
[same as prior period, unchanged from 0001375365-20-000074:notes:27]

[0001375365-21-000011:notes:31]
|  | Three Months Ended December 31, |  |  |  | Six Months Ended December 31, |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2019 |  |  |
| Server and storage systems | $ | 642,711 |  |  |  |  | $ | 672,727 |  |  |  |  | $ | 1,260,499 |  |  |  |  | $ | 1,308,753 |  |  |  |
| Subsystems and accessories | 187,595 |  |  |  |  | 198,216 |  |  |  |  | 332,057 |  |  |  |  | 361,994 |  |  |  |
| Total | $ | 830,306 |  |  |  |  | $ | 870,943 |  |  |  |  | $ | 1,592,556 |  |  |  |  | $ | 1,670,747 |  |  |  |

[0001375365-21-000011:notes:32]
[same as prior period, unchanged from 0001375365-20-000074:notes:29]

[0001375365-21-000011:notes:33]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2020 and 2019, of net sales by geographic region (in thousands):

[0001375365-21-000011:notes:34]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| United States | $ | 463,102 |  |  | $ | 527,404 |  |  | $ | 959,188 |  |  | $ | 996,245 |  |
| Asia | 161,415 |  |  | 165,716 |  |  | 288,121 |  |  | 327,355 |  |
| Europe | 154,819 |  |  | 147,564 |  |  | 266,908 |  |  | 275,623 |  |
| Others | 50,970 |  |  | 30,259 |  |  | 78,339 |  |  | 71,524 |  |
|  | $ | 830,306 |  |  | $ | 870,943 |  |  | $ | 1,592,556 |  |  | $ | 1,670,747 |  |

[0001375365-21-000011:notes:35]
[same as prior period, unchanged from 0001375365-20-000074:notes:32]

[0001375365-21-000011:notes:36]
[same as prior period, unchanged from 0001375365-20-000074:notes:33]

[0001375365-21-000011:notes:37]
[same as prior period, unchanged from 0001375365-20-000074:notes:34]

[0001375365-21-000011:notes:38]
[same as prior period, unchanged from 0001375365-20-000074:notes:35]

[0001375365-21-000011:notes:39]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligation(s). The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Revenue recognized during the three and six months ended December 31, 2020, which was included in the opening deferred revenue balance as of June 30, 2020 of $203.8 million, was $26.8 million and $55.4 million, respectively.

[0001375365-21-000011:notes:40]
Deferred revenue decreased $8.8 million during the six months ended December 31, 2020 because the recognition of revenue from contracts entered into in prior periods was greater than the invoiced amounts for service contracts during the period.

[0001375365-21-000011:notes:41]
[same as prior period, unchanged from 0001375365-20-000074:notes:38]

[0001375365-21-000011:notes:42]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially undelivered, as of the end of the reporting period. The Company applies the optional exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2020 was $194.9 million. The Company expects to recognize approximately 51% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

[0001375365-21-000011:notes:43]
[same as prior period, unchanged from 0001375365-20-000074:notes:40]

[0001375365-21-000011:notes:44]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies

[0001375365-21-000011:notes:45]
judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

[0001375365-21-000011:notes:46]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001375365-21-000011:notes:47]
Net Income Per Common Share
    The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2020 and 2019 (in thousands, except per share amounts):

[0001375365-21-000011:notes:48]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 27,674 |  |  | $ | 23,706 |  |  | $ | 54,275 |  |  | $ | 50,051 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 51,499 |  |  | 50,181 |  |  | 51,914 |  |  | 50,129 |  |
| Effect of dilutive securities | 2,084 |  |  | 1,828 |  |  | 2,091 |  |  | 1,629 |  |
| Weighted-average diluted shares | 53,584 |  |  | 52,009 |  |  | 54,005 |  |  | 51,758 |  |
| Basic net income per common share | $ | 0.54 |  |  | $ | 0.47 |  |  | $ | 1.05 |  |  | $ | 1.00 |  |
| Diluted net income per common share | $ | 0.52 |  |  | $ | 0.46 |  |  | $ | 1.00 |  |  | $ | 0.97 |  |

[0001375365-21-000011:notes:49]
For the three and six months ended December 31, 2020 and 2019, the Company had stock options, restricted stock units ("RSUs") and performance based restricted stock units ("PRSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,040,890 and 2,501,684 for the three months ended December 31, 2020 and 2019, respectively, and 1,113,845 and 3,171,619  for the six months ended December 31, 2020 and 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-21-000011:notes:50]
[same as prior period, unchanged from 0001375365-20-000074:notes:46]

[0001375365-21-000011:notes:51]
[same as prior period, unchanged from 0001375365-20-000074:notes:47]

[0001375365-21-000011:notes:52]
|  | December 31, 2020 |  | June 30, 2020 |
| Finished goods | $ | 566,054 |  |  | $ | 656,817 |  |
| Work in process | 93,590 |  |  | 38,146 |  |
| Purchased parts and raw materials | 147,787 |  |  | 156,535 |  |
| Total inventories | $ | 807,431 |  |  | $ | 851,498 |  |

[0001375365-21-000011:notes:53]
The Company recorded a provision for excess and obsolete inventory to cost of sales totaling $2.5 million and $1.7 million in the three and six months ended December 31, 2020 and $6.8 million and $16.9 million for the three and six

[0001375365-21-000011:notes:54]
months ended December 31, 2019, respectively. These amounts exclude a provision (recovery) for adjusting the cost of certain inventories to net realizable value of $0.2 million and $1.0 million for the three and six months ended December 31, 2020, respectively, and $(0.9) million and $(2.7) million for the three and six months ended December 31, 2019, respectively. The recovery is recognized when previously reserved inventories are sold.

[0001375365-21-000011:notes:55]
[same as prior period, unchanged from 0001375365-20-000074:notes:50]

[0001375365-21-000011:notes:56]
|  | December 31, 2020 |  | June 30, 2020 |
| Other receivables (1) | $ | 70,247 |  |  | $ | 96,669 |  |
| Prepaid income tax | 10,966 |  |  | 14,323 |  |
| Prepaid expenses | 5,864 |  |  | 7,075 |  |
| Deferred service costs | 4,514 |  |  | 4,161 |  |
| Restricted cash | 250 |  |  | 250 |  |
| Others | 6,369 |  |  | 4,507 |  |
| Total prepaid expenses and other current assets | $ | 98,211 |  |  | $ | 126,985 |  |

[0001375365-21-000011:notes:57]
[same as prior period, unchanged from 0001375365-20-000074:notes:52]

[0001375365-21-000011:notes:58]
(1) Includes other receivables from contract manufacturers based on certain buy-sell arrangements of $42.9 million and $83.8 million as of December 31, 2020 and June 30, 2020, respectively.

[0001375365-21-000011:notes:59]
[same as prior period, unchanged from 0001375365-20-000074:notes:54]

[0001375365-21-000011:notes:60]
|  | December 31, 2020 |  | June 30, 2020 |
| Cash and cash equivalents | $ | 315,610 |  |  | $ | 210,533 |  |
| Restricted cash included in prepaid expenses and other current assets | 250 |  |  | 250 |  |
| Restricted cash included in other assets | 1,624 |  |  | 1,607 |  |
| Total cash, cash equivalents and restricted cash | $ | 317,484 |  |  | $ | 212,390 |  |

[0001375365-21-000011:notes:61]
[same as prior period, unchanged from 0001375365-20-000074:notes:56]

[0001375365-21-000011:notes:62]
|  | December 31, 2020 |  | June 30, 2020 |
| Buildings | $ | 86,930 |  |  | $ | 86,930 |  |
| Land | 75,262 |  |  | 75,251 |  |
| Machinery and equipment | 91,073 |  |  | 85,381 |  |
| Buildings construction in progress (1) | 69,277 |  |  | 46,311 |  |
| Building and leasehold improvements | 24,960 |  |  | 24,517 |  |
| Software | 22,693 |  |  | 20,597 |  |
| Furniture and fixtures | 22,026 |  |  | 21,544 |  |
|  | 392,221 |  |  | 360,531 |  |
| Accumulated depreciation and amortization | (136,816) |  |  | (126,746) |  |
| Property, plant and equipment, net | $ | 255,406 |  |  | $ | 233,785 |  |

[0001375365-21-000011:notes:63]
[same as prior period, unchanged from 0001375365-20-000074:notes:58]

[0001375365-21-000011:notes:64]
[same as prior period, unchanged from 0001375365-20-000074:notes:59]

[0001375365-21-000011:notes:65]
|  | December 31, 2020 |  | June 30, 2020 |
| Operating lease right-of-use asset | $ | 22,975 |  |  | $ | 23,784 |  |
| Deferred service costs, non-current | 5,406 |  |  | 4,632 |  |
| Restricted cash, non-current | 1,624 |  |  | 1,607 |  |
| Investment in auction rate security | 1,571 |  |  | 1,571 |  |
| Deposits | 1,030 |  |  | 1,201 |  |
| Non-marketable equity securities | 128 |  |  | 128 |  |
| Prepaid expense, non-current | 2,017 |  |  | 1,576 |  |
| Total other assets | $ | 34,750 |  |  | $ | 34,499 |  |

[0001375365-21-000011:notes:66]
[same as prior period, unchanged from 0001375365-20-000074:notes:61]

[0001375365-21-000011:notes:67]
|  | December 31, 2020 |  | June 30, 2020 |
| Accrued payroll and related expenses | $ | 47,650 |  |  | $ | 33,577 |  |
| Contract manufacturing liabilities | 20,276 |  |  | 36,249 |  |
| Accrued warranty costs | 10,904 |  |  | 9,984 |  |
| Customer deposits | 15,058 |  |  | 9,942 |  |
| Operating lease liability | 7,435 |  |  | 6,310 |  |
| Accrued cooperative marketing expenses | 5,754 |  |  | 5,925 |  |
| Accrued professional fees | 1,021 |  |  | 5,661 |  |
| Accrued legal liabilities (Note 11) | — |  |  | 18,114 |  |
| Others (accrued liabilities) | 33,601 |  |  | 29,639 |  |
| Total accrued liabilities | $ | 141,698 |  |  | $ | 155,401 |  |

[0001375365-21-000011:notes:68]
[same as prior period, unchanged from 0001375365-20-000074:notes:63]

[0001375365-21-000011:notes:69]
[same as prior period, unchanged from 0001375365-20-000074:notes:64]

[0001375365-21-000011:notes:70]
[same as prior period, unchanged from 0001375365-20-000074:notes:65]

[0001375365-21-000011:notes:71]
[same as prior period, unchanged from 0001375365-20-000074:notes:66]

[0001375365-21-000011:notes:72]
[same as prior period, unchanged from 0001375365-20-000074:notes:67]

[0001375365-21-000011:notes:73]
The Company accounts for the outstanding performance bonuses as liabilities and estimates fair value of payable amounts using a Monte-Carlo simulation model. The awards are re-measured at each period end with changes in fair value recorded in the Company’s condensed consolidated statement of operations in operating expenses. The cumulative recorded expense at each period end is trued-up to the expected payable amount vested through the period end. The requisite service periods over which expenses are recognized are derived from the Monte-Carlo model for all performance awards, except for the first 50% of the Chief Executive Officer’s award that includes a performance condition. The Company estimates if it is probable that the performance condition will be met through the expiration date of this award. If at the measurement date it is determined to be probable, the Company estimates the requisite period as the longer of the service period derived by the Monte-Carlo model and the implicit service period when the Company expects to make adequate progress in remediating its material weaknesses in its internal control over financial reporting, as reported by the Company's Audit Committee. If it is determined to not be probable, then the Company will reverse any previously recognized expense for this award in the period when it is no longer probable that the performance condition will be achieved.

[0001375365-21-000011:notes:74]
Based on the estimated fair value of these performance bonuses as of December 31, 2020 and June 30, 2020, the Company recorded a $4.7 million and $2.1 million liability, respectively, of which $4.7 million and $1.5 million, respectively, was recorded within accrued liabilities and $0.0 million and $0.6 million, respectively, was recorded within other long-term liabilities on the Company's condensed consolidated balance sheet. An unrecognized compensation expense of $1.9 million will be recorded over the remaining service periods from 0.06 years to 0.67 years. The fair value of these awards is remeasured each reporting period. The expense recognized during the three months ended December 31, 2020 and 2019 was $2.5 million and $0.0 million, respectively, and $2.6 million and $0.0 million for the six months ended December 31, 2020 and 2019, respectively.

[0001375365-21-000011:notes:75]
[same as prior period, unchanged from 0001375365-20-000074:notes:70]

[0001375365-21-000011:notes:76]
|  | December 31, 2020 |  | June 30, 2020 |
| Operating lease liability, non-current | $ | 16,750 |  |  | $ | 18,102 |  |
| Accrued unrecognized tax benefits including related interest and penalties | 16,567 |  |  | 15,496 |  |
| Accrued warranty costs, non-current | 2,600 |  |  | 2,395 |  |
| Others | 4,991 |  |  | 6,002 |  |
| Total other long-term liabilities | $ | 40,908 |  |  | $ | 41,995 |  |

[0001375365-21-000011:notes:77]
[same as prior period, unchanged from 0001375365-20-000074:notes:72]

[0001375365-21-000011:notes:78]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Balance, beginning of the period | $ | 13,727 |  |  | $ | 11,285 |  |  | $ | 12,379 |  |  | $ | 11,034 |  |
| Provision for warranty | 7,112 |  |  | 9,401 |  |  | 15,459 |  |  | 17,106 |  |
| Costs utilized | (7,453) |  |  | (9,115) |  |  | (15,060) |  |  | (16,777) |  |
| Change in estimated liability for pre-existing warranties | 118 |  |  | (129) |  |  | 726 |  |  | 79 |  |
| Balance, end of the period | 13,504 |  |  | 11,442 |  |  | 13,504 |  |  | 11,442 |  |
| Current portion | 10,904 |  |  | 8,956 |  |  | 10,904 |  |  | 8,956 |  |
| Non-current portion | $ | 2,600 |  |  | $ | 2,486 |  |  | $ | 2,600 |  |  | $ | 2,486 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-21-000011:notes:79]
Fair Value Disclosure    The financial instruments of the Company measured at fair value on a recurring basis are included in cash equivalents, other assets and accrued liabilities. The Company classifies its financial instruments, except for its investment in an auction rate 
security, within Level 1 or Level 2 in the fair value hierarchy because the Company uses quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-21-000011:notes:80]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of December 31, 2020 and June 30, 2020. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of December 31, 2020.

[0001375365-21-000011:notes:81]
[same as prior period, unchanged from 0001375365-20-000074:notes:75]

[0001375365-21-000011:notes:82]
The following table sets forth the Company’s financial instruments as of December 31, 2020 and June 30, 2020, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-21-000011:notes:83]
| December 31, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 841 |  |  | $ | — |  |  | $ | — |  |  | $ | 841 |  |
| Certificates of deposit (2) | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 841 |  |  | $ | 863 |  |  | $ | 1,571 |  |  | $ | 3,275 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 4,727 |  |  | $ | — |  |  | $ | 4,727 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4,727 |  |  | $ | — |  |  | $ | 4,727 |  |
| June 30, 2020 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,163 |  |
| Certificates of deposit (2) | — |  |  | 836 |  |  | — |  |  | 836 |  |
| Auction rate security | — |  |  | — |  |  | 1,571 |  |  | 1,571 |  |
| Total assets measured at fair value | $ | 1,163 |  |  | $ | 836 |  |  | $ | 1,571 |  |  | $ | 3,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Performance awards liability (3) | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,100 |  |  | $ | — |  |  | $ | 2,100 |  |

[0001375365-21-000011:notes:84]
(1) $0.0 million and $0.4 million in money market funds are included in cash and cash equivalents and $0.8 million and $0.8 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2020 and June 30, 2020, respectively.

[0001375365-21-000011:notes:85]
(2) $0.2 million and $0.2 million in certificates of deposit are included in cash and cash equivalents, $0.3 million and $0.3 million in certificates of deposit are included in prepaid expenses and other assets, and $0.4 million and $0.3 million in

[0001375365-21-000011:notes:86]
certificates of deposit are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of December 31, 2020 and June 30, 2020, respectively.

[0001375365-21-000011:notes:87]
(3) As of December 31, 2020 and June 30, 2020, the current portion of the performance awards liability of $4.7 million and $1.5 million, respectively, is included in accrued liabilities and the non-current portion of $0.0 million and $0.6 million, respectively, is included in other long-term liabilities in the condensed consolidated balance sheets.

[0001375365-21-000011:notes:88]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three and six months ended December 31, 2020, the credit losses related to the Company’s investments was not significant.

[0001375365-21-000011:notes:89]
The Company estimated the fair value of performance awards using the Monte-Carlo simulation model and classified them within Level 2 of the fair value hierarchy as estimates are based on the observable inputs. The significant inputs used in estimating the fair value of the awards as of December 31, 2020 and June 30, 2020 are as follows:

[0001375365-21-000011:notes:90]
| December 31, 2020 |
| Stock Price as of Period End |  | Performance Period |  | Risk-free Rate |  | Volatility |  | Dividend Yield |
| $31.66 |  | 0.8 - 1.49 years |  | 0.11% |  | 53.55% |  | —% |

[0001375365-21-000011:notes:91]
[same as prior period, unchanged from 0001375365-20-000074:notes:84]

[0001375365-21-000011:notes:92]
There was no movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and six months ended December 31, 2020 and 2019.

[0001375365-21-000011:notes:93]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and six months ended December 31, 2020 and 2019.

[0001375365-21-000011:notes:94]
The following is a summary of the Company’s investment in an auction rate security as of December 31, 2020 and June 30, 2020 (in thousands):

[0001375365-21-000011:notes:95]
|  | December 31, 2020 and June 30, 2020 |
|  | Cost Basis |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate security | $ | 1,750 |  |  | $ | — |  |  | $ | (179) |  |  | $ | 1,571 |  |

[0001375365-21-000011:notes:96]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and six months ended December 31, 2020 and 2019.

[0001375365-21-000011:notes:97]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of December 31, 2020 and June 30, 2020, total debt of $45.5 million and $29.4 million, respectively, is reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded. The amortized cost of the outstanding debt approximates the fair value.


## us-gaap:DebtDisclosureTextBlock

[0001375365-21-000011:notes:98]
Short-term and Long-term Debt
    Short-term debt obligations as of December 31, 2020 and June 30, 2020 consisted of the following (in thousands):

[0001375365-21-000011:notes:99]
|  | December 31, |  | June 30, |
|  | 2020 |  | 2020 |
| CTBC Bank term loan, due August 31, 2021 | $ | 24,921 |  |  | $ | 23,704 |  |
| CTBC Bank term loan, due June 4, 2030 | 20,577 |  |  | 5,697 |  |
| Total debt | 45,498 |  |  | 29,401 |  |
| Short-term debt and current portion of long-term debt | 24,921 |  |  | 23,704 |  |
| Debt, Non-current | $ | 20,577 |  |  | $ | 5,697 |  |

[0001375365-21-000011:notes:100]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-21-000011:notes:101]
Bank of America

[0001375365-21-000011:notes:102]
2018 Bank of America Credit Facility

[0001375365-21-000011:notes:103]
In April 2018, the Company entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility"). On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other items, extend the maturity to June 30, 2021 and provide that in the event of default or if outstanding borrowings are in excess of $220.0 million, the Company is required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of the Company's deposit accounts. In addition, the amendment released the real property of Super Micro Computer as a collateral. The amendment was accounted for as a modification and the impact was immaterial to the condensed consolidated financial statements. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. Subject to customary exceptions, the 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. Under the terms of the 2018 Bank of America Credit Facility, the Company is not permitted to pay any dividends. The Company is required to pay 0.375% per annum on the 2018 Bank of America Credit Facility for any unused borrowings. The 2018 Bank of America Credit Facility contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries and contains a financial covenant, which requires that the Company maintain a certain fixed charge coverage ratio, for each twelve-month period while in a Trigger Period, as defined in the agreement, is in effect.

[0001375365-21-000011:notes:104]
As of December 31, 2020 and June 30, 2020, the Company had no outstanding borrowings under the 2018 Bank of America Credit Facility. The interest rates under the 2018 Bank of America Credit Facility as of December 31, 2020 and June 30, 2020 were 3.00%. In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. No amounts have been drawn under the standby letter of credit. The balance of debt issuance costs outstanding were $0.3 million and $0.6 million as of December 31, 2020 and June 30, 2020, respectively. The Company has been in compliance with all the covenants under the 2018 Bank of America Credit Facility, and as of December 31, 2020, the Company's available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.

[0001375365-21-000011:notes:105]
CTBC Bank

[0001375365-21-000011:notes:106]
CTBC Credit Facility

[0001375365-21-000011:notes:107]
In June 2019, the Company entered into a credit agreement with CTBC Bank, which was amended in August 2020, (collectively, the "CTBC Credit Facility"). The amended credit agreement with CTBC Bank that provides for (i) a 12-month NTD 700.0 million ($24.0 million U.S. dollar equivalent) term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly, which term loan facility also includes a 12-month guarantee of up to NTD 100.0 million ($3.4 million U.S. dollar

[0001375365-21-000011:notes:108]
equivalent) with an annual fee equal to 0.50% per annum, (ii) a 180-day NTD 1,500.0 million ($51.5 million U.S. dollar equivalent) term loan facility up to 100% of eligible accounts receivable in an aggregate amount with an interest rate equal to the lender's established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly, and (ⅲ) a 12-month revolving line of credit of up to 100% of eligible accounts receivable in an aggregate amount of up to $50.0 million with an interest rate equal to the lender's established USD interest rate plus 0.80% per annum which is adjusted monthly, or equal to the lender’s established NTD interest rate plus an interest rate ranging from 0.30% to 0.50% per annum which is adjusted monthly if the borrowing is in NTD. The total borrowings allowed under the CTBC Credit Facility was capped at $50.0 million. There are no financial covenants associated with the CTBC Credit Facility.

[0001375365-21-000011:notes:109]
The total outstanding borrowings under the CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.9 million and $23.7 million at December 31, 2020 and June 30, 2020, respectively. As of December 31, 2020 and June 30, 2020, the Company did not have any outstanding borrowings under the CTBC Credit Facility revolving line of credit. The interest rate for these loans were 0.73% per annum as of December 31, 2020 and 0.63% per annum as of June 30, 2020. At December 31, 2020, the amount available for future borrowing under the CTBC Credit Facility was $25.1 million. As of December 31, 2020, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Facility term loan was $25.1 million.

[0001375365-21-000011:notes:110]
2020 CTBC Term Loan Facility

[0001375365-21-000011:notes:111]
In May 2020, the Company entered into a ten-year, non-revolving term loan facility (“2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of the Company’s Bade Manufacturing Facility located in Taiwan. Drawdowns on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and shall be drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. The Company is required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. Interest under the 2020 CTBC Term Loan Facility is the two-year term floating rate of postal saving interest rate plus 0.105% and is established on the date of the drawdown application. If no interest rate is agreed upon, interest shall accrue at the annual base rate for CTBC plus 4.00%. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility and its expansion. Fees paid to the lender as debt issuance costs were immaterial. The Company has financial covenants requiring the Company's current ratio, debt service coverage ratio, and financial debt ratio, as defined in the agreement, to be maintained at certain levels under the 2020 CTBC Term Loan Facility.

[0001375365-21-000011:notes:112]
As of December 31, 2020 and June 30, 2020, the amounts outstanding under the 2020 CTBC Term Loan Facility were $20.6 million and $5.7 million, respectively. The interest rate for these loans were 0.45% per annum as of December 31, 2020 and June 30, 2020. The net book value of the property serving as collateral as of December 31, 2020 was $29.2 million. As of December 31, 2020, the Company was in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000011:notes:113]
E.SUN Bank Credit Facility

[0001375365-21-000011:notes:114]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan. Such Credit Facility provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. The term of the E.SUN Credit Facility expires on September 18, 2021.

[0001375365-21-000011:notes:115]
Generally, the interest for base rate loans made under the E.SUN Credit Facility is based upon an average interbank overnight call loan rate in the finance industry (such as LIBOR or TAIFX) plus a fixed margin, and is subject to occasional adjustment.  Interest for adjustable loan rate loans made under the E.SUN Credit Facility is based upon an average one-year fixed rate time saving deposit rate of a selected reference bank which shall be a well-known domestic bank in Taiwan, and is subject to occasional adjustment. The E.SUN Credit Facility has customary default provisions permitting E.SUN Bank to terminate or reduce the credit limit, shorten the credit period, or deem all liabilities due and payable, including in the event such Taiwan subsidiary of the Company has an overdue liability at another financial organization. There are no financial covenants associated with the E.SUN Credit Facility.
Terms for specific drawdown instruments issued under the E.SUN Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in Notifications and Confirmation of Credit Conditions negotiated with E.SUN Bank. A Notification and Confirmation of Credit Conditions agreement under the E.SUN Credit Facility was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) with a tenor of 120 days and with an interest rate calculated based on the higher of LIBOR plus 0.75% then divided by 0.946 or TAIFX plus 0.55% then divided by 0.946. As of December 31, 2020, no drawings had been made from the Import Loan.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-21-000011:notes:116]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2020 and 2019 were as follows (in thousands):

[0001375365-21-000011:notes:117]
|  |  | Three Months EndedDecember 31, | Six Months EndedDecember 31, |
|  |  | 2020 |  | 2019 | 2020 | 2019 | 2019 |
| Operating lease expense (including expense for lease agreements with related parties of $347 and $693 for the three and six months ended December 31, 2020, respectively, and $362 and $727 for the three and six months ended December 31, 2019, respectively) |  | $ | 1,947 |  |  | $ | 1,595 |  | $ | 3,947 |  |  | $ | 3,304 |  |
| Cash payments for operating leases (including payments to related parties of $347 and $693 for the three and six months ended December 31, 2020, respectively, and $380 and $737 for the three and six months ended December 31, 2019, respectively) |  | $ | 1,991 |  |  | $ | 1,570 |  | $ | 3,957 |  |  | $ | 3,415 |  |

[0001375365-21-000011:notes:118]
During the three and six months ended December 31, 2020 and 2019, respectively, the Company's costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable payments expensed in the three and six months ended December 31, 2020 were $0.4 million and $0.8 million, respectively. Variable payments expensed in the three months and six months ended December 31, 2019 were $0.4 million and $0.7 million, respectively.

[0001375365-21-000011:notes:119]
As of December 31, 2020, the weighted average remaining lease term for operating leases was 4.1 years and the weighted average discount rate was 3.5%. Future minimum lease payments under noncancelable operating lease arrangements as of December 31, 2020 were as follows (in thousands):

[0001375365-21-000011:notes:120]
| Fiscal Year: |  | Minimum lease payments |
| 2021 (remainder) |  | $ | 4,075 |  |
| 2022 |  | 6,899 |  |
| 2023 |  | 5,204 |  |
| 2024 |  | 4,370 |  |
| 2025 |  | 4,415 |  |
| 2026 and beyond |  | 1,044 |  |
| Total future lease payments |  | $ | 26,007 |  |
| Less: Imputed interest |  | (1,822) |  |
| Present value of operating lease liabilities |  | $ | 24,185 |  |

[0001375365-21-000011:notes:121]
As of December 31, 2020, commitments under short-term lease arrangements, and operating and financing leases that have not yet commenced were immaterial.

[0001375365-21-000011:notes:122]
The Company has entered into lease agreements with related parties.  See Note 8, "Related Party Transactions," for discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-21-000011:notes:123]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 28.8% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2020. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board and is an equity holder of Compuware. Charles Liang and Sara Liu do not own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock.

[0001375365-21-000011:notes:124]
Dealings with Ablecom

[0001375365-21-000011:notes:125]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-21-000011:notes:126]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 91.6% and 97.5% of the chassis included in the products sold by the Company during the three months ended December 31, 2020 and 2019, respectively, and 92.6% and 95.4% of the chassis included in the products sold by the Company during the six months ended December31, 2020 and 2019, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-21-000011:notes:127]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-21-000011:notes:128]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Ablecom were $25.4 million and $23.2 million at December 31, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-21-000011:notes:129]
Dealings with Compuware

[0001375365-21-000011:notes:130]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the

[0001375365-21-000011:notes:131]
responsibility to install the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-21-000011:notes:132]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-21-000011:notes:133]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-21-000011:notes:134]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-21-000011:notes:135]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding purchase orders from the Company to Compuware were $26.8 million and $45.7 million at December 31, 2020 and June 30, 2020, respectively, representing the maximum exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-21-000011:notes:136]
The Company’s results from transactions with Ablecom and Compuware for each of the three and six months ended December 31, 2020 and 2019, are as follows (in thousands):

[0001375365-21-000011:notes:137]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ablecom |  |  |  |  |  |  |  |
| Purchases (1) | $ | 24,580 |  |  | $ | 44,568 |  |  | $ | 50,903 |  |  | $ | 77,688 |  |
| Compuware |  |  |  |  |  |  |  |
| Net sales | $ | 5,572 |  |  | $ | 6,406 |  |  | $ | 18,871 |  |  | $ | 11,953 |  |
| Purchases (1) | 29,644 |  |  | 33,438 |  |  | 68,571 |  |  | 66,754 |  |

[0001375365-21-000011:notes:138]
(1) Includes principally purchases of inventory and other miscellaneous items.

[0001375365-21-000011:notes:139]
The Company's net sales to Ablecom were not material for the three and six months ended December 31, 2020 and 2019.

[0001375365-21-000011:notes:140]
The Company had the following balances related to transactions with Ablecom and Compuware as of December 31, 2020 and June 30, 2020 (in thousands):

[0001375365-21-000011:notes:141]
|  | December 31, 2020 |  | June 30, 2020 |
| Ablecom |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,099 |  |  | $ | 6,379 |  |
| Accounts payable and accrued liabilities (2) | 27,002 |  |  | 40,056 |  |
| Other long-term liabilities (3) | — |  |  | 513 |  |
| Compuware |  |  |  |
| Accounts receivable and other receivables (1) | $ | 6,767 |  |  | $ | 14,323 |  |
| Accounts payable and accrued liabilities (2) | 30,594 |  |  | 46,518 |  |
| Other long-term liabilities (3) | 28 |  |  | 186 |  |

[0001375365-21-000011:notes:142]
____________________________

[0001375365-21-000011:notes:143]
(1) Other receivables include receivables from vendors.

[0001375365-21-000011:notes:144]
(2) Includes current portion of operating lease liabilities.

[0001375365-21-000011:notes:145]
(3) Represents non-current portion of operating lease liabilities.

[0001375365-21-000011:notes:146]
See Note 1, "Summary of Significant Accounting Policies" for a discussion of the transactions and balances in the Company’s Corporate Venture.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-21-000011:notes:147]
Stock-based Compensation and Stockholders' Equity
Equity Incentive Plan

[0001375365-21-000011:notes:148]
[same as prior period, unchanged from 0001375365-20-000074:notes:138]

[0001375365-21-000011:notes:149]
As of December 31, 2020, the Company had 4,277,287 authorized shares available for future issuance under the 2020 Plan.

[0001375365-21-000011:notes:150]
Common Stock Repurchase and Retirement

[0001375365-21-000011:notes:151]
On August 9, 2020, the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $30.0 million at market prices. The program was effective until December 31, 2020 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended September 30, 2020, 1,142,294 shares of common stock were repurchased for $30.0 million and the program ended. Repurchased shares were recorded as treasury shares in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000011:notes:152]
On December 11, 2020, the Board approved the retirement of 2,475,419 shares of the Company's common stock, which were recorded as treasury stock in the Company's condensed consolidated balance sheet as of September 30, 2020.

[0001375365-21-000011:notes:153]
On October 31, 2020, the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $50.0 million at market prices. The program is effective until October 31, 2021 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended December 31, 2020, 1,580,207 shares of common stock were repurchased for $47.0 million. All these shares have been retired as of December 31, 2020.

[0001375365-21-000011:notes:154]
[same as prior period, unchanged from 0001375365-20-000074:notes:142]

[0001375365-21-000011:notes:155]
The Company's fair value of RSUs and PRSUs is based on the closing market price of the Company's common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing

[0001375365-21-000011:notes:156]
model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-21-000011:notes:157]
[same as prior period, unchanged from 0001375365-20-000074:notes:144]

[0001375365-21-000011:notes:158]
[same as prior period, unchanged from 0001375365-20-000074:notes:145]

[0001375365-21-000011:notes:159]
[same as prior period, unchanged from 0001375365-20-000074:notes:146]

[0001375365-21-000011:notes:160]
[same as prior period, unchanged from 0001375365-20-000074:notes:147]

[0001375365-21-000011:notes:161]
The fair value of stock option grants for the three and six months ended December 31, 2020 and 2019 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-21-000011:notes:162]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Risk-free interest rate | 0.45 | % |  | 1.72 | % |  | 0.27% - 0.45% |  | 1.58% - 1.72% |
| Expected term | 5.98 years |  | 6.27 years |  | 5.98 years |  | 6.27 years |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 50.34 | % |  | 49.74 | % |  | 50.34% - 50.43% |  | 49.74% - 50.04% |
| Weighted-average fair value | $ | 11.13 |  |  | $ | 10.30 |  |  | $ | 13.14 |  |  | $ | 9.14 |  |

[0001375365-21-000011:notes:163]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2020 and 2019 (in thousands):

[0001375365-21-000011:notes:164]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of sales | $ | 407 |  |  | $ | 384 |  |  | $ | 910 |  |  | $ | 779 |  |
| Research and development | 3,339 |  |  | 3,126 |  |  | 7,041 |  |  | 6,256 |  |
| Sales and marketing | 497 |  |  | 423 |  |  | 1,014 |  |  | 859 |  |
| General and administrative | 2,210 |  |  | 1,031 |  |  | 4,658 |  |  | 2,124 |  |
| Stock-based compensation expense before taxes | 6,453 |  |  | 4,964 |  |  | 13,623 |  |  | 10,018 |  |
| Income tax impact | (1,732) |  |  | (1,131) |  |  | (3,687) |  |  | (2,283) |  |
| Stock-based compensation expense, net | $ | 4,721 |  |  | $ | 3,833 |  |  | $ | 9,936 |  |  | $ | 7,735 |  |

[0001375365-21-000011:notes:165]
As of December 31, 2020, $7.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.43 years, $39.7 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.54 years and $0.3 million of unrecognized compensation cost related to unvested PRSUs is expected to be recognized over a period of 0.61 years.

[0001375365-21-000011:notes:166]
[same as prior period, unchanged from 0001375365-20-000074:notes:153]

[0001375365-21-000011:notes:167]
The following table summarizes stock option activity during the six months ended December 31, 2020 under all plans:

[0001375365-21-000011:notes:168]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2020 |  | 5,379,768 |  |  | $ | 19.38 |  |  |  |  |  |
| Granted |  | 312,970 |  |  | $ | 28.17 |  |  |  |  |  |
| Exercised |  | (683,613) |  |  | $ | 15.75 |  |  |  |  |  |
| Forfeited/Cancelled |  | (35,894) |  |  | $ | 24.41 |  |  |  |  |  |
| Balance as of December 31, 2020 |  | 4,973,231 |  |  | $ | 20.40 |  |  | 4.20 |  |  |
| Options vested and exercisable at December 31, 2020 |  | 4,189,436 |  |  | $ | 19.88 |  |  | 3.36 |  |  |

[0001375365-21-000011:notes:169]
[same as prior period, unchanged from 0001375365-20-000074:notes:156]

[0001375365-21-000011:notes:170]
[same as prior period, unchanged from 0001375365-20-000074:notes:157]

[0001375365-21-000011:notes:171]
In August 2017, the Compensation Committee granted two PRSU awards to the Company's Chief Executive Officer, both of which have both performance and service conditions. 50% of the PRSUs vested at June 30, 2018 when performance conditions were achieved, while the remainder vest in equal amounts over the following ten quarters if the Company's Chief Executive Officer continued to be employed during those ten quarters. As of December 31, 2020, the remaining 50% of the PRSUs had vested in accordance with the terms of the grant.

[0001375365-21-000011:notes:172]
[same as prior period, unchanged from 0001375365-20-000074:notes:159]

[0001375365-21-000011:notes:173]
The following table summarizes RSU and PRSU activity during the six months ended December 31, 2020 under all plans:

[0001375365-21-000011:notes:174]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | PRSUsOutstanding |  |  | WeightedAverageGrant-Date Fair Value per Share |
| Balance as of June 30, 2020 | 1,768,027 |  |  | $ | 20.08 |  |  | 42,000 |  | (1) |  | $ | 22.29 |  |
| Granted | 790,950 |  |  | $ | 27.90 |  |  | — |  |  |  | $ | — |  |
| Released | (398,536) |  |  | $ | 20.29 |  |  | (12,000) |  |  |  | $ | 27.10 |  |
| Forfeited | (102,115) |  |  | $ | 23.14 |  |  | — |  |  |  | $ | — |  |
| Balance as of December 31, 2020 | 2,058,326 |  |  | $ | 22.89 |  |  | 30,000 |  |  |  | $ | 20.37 |  |

[0001375365-21-000011:notes:175]
[same as prior period, unchanged from 0001375365-20-000074:notes:162]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-21-000011:notes:176]
Income Taxes
    The Company recorded a provision for income taxes of $5.1 million and $8.8 million for the three and six months ended December 31, 2020, respectively, and $2.1 million and $10.7 million for the three and six months ended December 31, 2019, respectively. The effective tax rate was 14.9% and 13.9% for the three and six months ended December 31, 2020, respectively, and 7.9% and 17.6% for the three and six months ended December 31, 2019, respectively. The effective tax rate for the three months ended December 31, 2020 is higher than that for the three months ended December 31, 2019, primarily due to release of uncertain tax positions after settlement of a Taiwan tax audit in 2019. The effective tax rate for the six months ended December 31, 2020 is lower than that for the six months ended December 31, 2019, primarily due to decrease in tax reserves for uncertain tax positions and an increase in tax benefit from employees stock based compensation.

[0001375365-21-000011:notes:177]
[same as prior period, unchanged from 0001375365-20-000074:notes:164]

[0001375365-21-000011:notes:178]
[same as prior period, unchanged from 0001375365-20-000074:notes:165]

[0001375365-21-000011:notes:179]
As of December 31, 2020, the Company had gross unrecognized tax benefits of $39.4 million, of which, $14.1 million if recognized, would affect the Company's effective tax rate. During the six months ended December 31, 2020, there was a $8.8 million increase in gross unrecognized tax benefits, primarily due to an uncertain tax position in a foreign jurisdiction. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of December 31, 2020, the Company had accrued $2.4 million of interest and penalties relating to unrecognized tax benefits.

[0001375365-21-000011:notes:180]
[same as prior period, unchanged from 0001375365-20-000074:notes:167]

[0001375365-21-000011:notes:181]
In October 2019, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2018 and proposed an adjustment resulting in additional tax liability of $1.6 million. The Company accepted the proposed adjustment in October 2019 and paid the $1.6 million tax liability in February 2020. In February 2020, the Taiwan tax authority completed its audit in Taiwan for fiscal year 2019 and proposed an adjustment resulting in an additional tax liability of $1.0 million. The Company accepted the proposed adjustment and paid the $1.0 million tax liability in February 2020. The impact of these adjustments on the income statement was offset by the release of previously unrecognized tax benefits related to the fiscal years audited in the periods in which the proposed adjustments were accepted.

[0001375365-21-000011:notes:182]
[same as prior period, unchanged from 0001375365-20-000074:notes:169]

[0001375365-21-000011:notes:183]
[same as prior period, unchanged from 0001375365-20-000074:notes:170]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-21-000011:notes:184]
Commitments and Contingencies
Litigation and Claims— On February 8, 2018, two putative class action complaints were filed against the Company, the Company's Chief Executive Officer, and the Company's former Chief Financial Officer in the U.S. District Court for the Northern District of California (Hessefort v. Super Micro Computer, Inc., et al., No. 18-cv-00838 and United Union of Roofers v. Super Micro Computer, Inc., et al., No. 18-cv-00850). The complaints contain similar allegations, claiming that the defendants violated Section 10(b) of the Securities Exchange Act due to alleged misrepresentations and/or omissions in public statements regarding recognition of revenue. The court subsequently appointed New York Hotel Trades Council & Hotel Association of New York City, Inc. Pension Fund as lead plaintiff. The lead plaintiff then filed an amended complaint naming the Company's Senior Vice President of Investor Relations as an additional defendant. On June 21, 2019, the lead plaintiff filed a further amended complaint naming the Company's former Senior Vice President of International Sales, Corporate Secretary, and Director as an additional defendant. On July 26, 2019, the Company filed a motion to dismiss the complaint. On March 23, 2020, the Court granted the Company’s motion to dismiss the complaint, with leave for lead plaintiff to file an amended complaint within 30 days. On April 22, 2020, lead plaintiff filed a further amended complaint. On June 15, 2020, the Company filed a motion to dismiss the further amended complaint, the hearing for which was calendared for September 23, 2020; however, the Court held a conference on September 15 to discuss how the Court could efficiently address the recent SEC settlement agreement.  The parties stipulated to allow plaintiffs to further amend the complaint solely to add allegations relating to the SEC settlement.  On October 14, 2020, plaintiffs filed a Fourth Amended Complaint.  On October 28, 2020, defendants filed a supplemental motion to dismiss.  The Court has taken the motion under submission. The Company believes the claims are without merit and intends to vigorously defend against the lawsuit.

[0001375365-21-000011:notes:185]
On October 27, 2020, certain current and former directors and officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of the State of California, County of Santa Clara (the “Court”), captioned Barry v. Liang, et al., 20-CV-372190 (the “Derivative Action”). The Company was also named as a nominal defendant. The complaint purports to allege claims for breaches of fiduciary duties, waste of corporate assets, and unjust enrichment arising out of allegations that the Company’s officers and directors caused the Company to issue false and misleading statements about recognition of revenue and the effectiveness of its internal controls, failed to adopt and implement effective internal controls, and failed to timely file various reports with the Securities and Exchange Commission. The plaintiffs seek unspecified compensatory damages and other equitable relief.  A case management conference has been set for late February 2021, and the matter is stayed until such time.

[0001375365-21-000011:notes:186]
On November 13, 2020, Build Group Inc. (“Build Group”) filed a complaint against the Company in the Superior Court for Santa Clara County, seeking damages of approximately $2 million.  Build Group served the complaint on the Company on December 1, 2020.  Build Group alleged that the Company breached the construction contract between the Company and Build Group by failing to approve or reject certain requests for change orders to the scope of work covered by the construction project in a timely manner, or at all. A substantial portion of the amounts covered by the change orders at issue related to delays in the construction project.  Build Group asserted that these delays were beyond its control and that therefore it was entitled to additional payments as a result of the delays in completion of the project.  The Company believed that it had meritorious defenses to Build Group’s claims, but nonetheless negotiated a settlement with Build Group. The settlement agreement resolving this dispute was executed effective January 19, 2021. As a result, the Company did not have to respond to the complaint. Per the settlement agreement, Build Group agreed to dismiss the entire action with prejudice once the Company complied with its obligations under the settlement agreement. The Company has complied with its obligations and Build Group has submitted the dismissal, which should be granted by the court in the near term. As of December 31, 2020, the Company recorded a liability of $1.6 million for the construction project expenses incurred pertaining to this matter.

[0001375365-21-000011:notes:187]
SEC Matter— The Company cooperated with the SEC in its investigation of marketing expenses that contained certain irregularities discovered by Company management, which irregularities were disclosed on August 31, 2015, and the Company cooperated with the SEC in its further investigation of the matters underlying the Company’s inability to timely file its Form 10-K for the fiscal year ended June 30, 2017 and concerning the publication of a false and widely discredited news article in October 2018 concerning the Company’s products. On August 25, 2020, to fully resolve all matters under investigation, the Company consented to entry of an Order Instituting Cease-and-Desist Proceedings Pursuant to Section 8A of the Securities Act of 1933 and Section 21C of the Securities Exchange Act of 1934, Making Findings, and Imposing a Cease-and-Desist Order (“Order”), as announced by the SEC. The Company admitted the SEC’s jurisdiction over the Company and the subject matter of the proceedings, but otherwise neither admitted nor denied the SEC’s findings, as described in the Order. The Company agreed to cease and desist from committing or causing any violations and any future violations of Sections

[0001375365-21-000011:notes:188]
17(a)(2) and (3) of the Securities Act and Sections 13(a), 13(b)(2)(A), and 13(b)(2)(B), of the Exchange Act and Rules 12b-20, 13a-1, 13a-11, and 13a-13 thereunder. The Company agreed and paid a civil money penalty of $17,500,000 during the three months ended September 30, 2020, which was recorded to general and administrative expense in the Company's condensed consolidated statement of operations. In addition, the Company’s Chief Executive Officer concluded a settlement with the SEC on August 25, 2020, as announced by the SEC. The Company’s Chief Executive Officer paid the Company the sum of $2,122,000 as reimbursement of profits from certain stock sales during the relevant period, pursuant to Section 304 of the Sarbanes-Oxley Act of 2002. The settlement amount was paid during the first quarter of fiscal 2021 and the Company recorded the payment as a credit to general and administrative expense.

[0001375365-21-000011:notes:189]
Other legal proceedings and indemnifications

[0001375365-21-000011:notes:190]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2020 and any prior periods.

[0001375365-21-000011:notes:191]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-21-000011:notes:192]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2020, these remaining noncancelable commitments were $248.3 million, including $52.3 million for related parties.

[0001375365-21-000011:notes:193]
Standby Letter of Credit— In October 2018, a $3.2 million letter of credit was issued under the 2018 Bank of America Credit Facility and in October 2019, the letter of credit amount was increased to $6.4 million. The standby letter of credit is cancellable upon written notice from the issuer. No amounts have been drawn under the standby letter of credit.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-21-000011:notes:194]
[same as prior period, unchanged from 0001375365-20-000074:notes:178]

[0001375365-21-000011:notes:195]
[same as prior period, unchanged from 0001375365-20-000074:notes:179]

[0001375365-21-000011:notes:196]
|  | December 31, |  | June 30, |
|  | 2020 |  | 2020 |
| Long-lived assets: |  |  |  |
| United States | $ | 180,769 |  |  | $ | 178,812 |  |
| Asia | 71,614 |  |  | 51,605 |  |
| Europe | 3,023 |  |  | 3,368 |  |
|  | $ | 255,406 |  |  | $ | 233,785 |  |

[0001375365-21-000011:notes:197]
[same as prior period, unchanged from 0001375365-20-000074:notes:181]


## us-gaap:SubsequentEventsTextBlock

[0001375365-21-000011:notes:198]
Subsequent EventOn January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $200.0 million at market price. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased.
