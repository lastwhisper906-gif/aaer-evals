# SMCI MD&A — 0001375365-21-000011


## mdna

[0001375365-21-000011:mdna:1]
[same as prior period, unchanged from 0001375365-20-000074:mdna:1]

[0001375365-21-000011:mdna:2]
The following discussion and analysis of the financial condition and results of our operations should be read in conjunction with our condensed consolidated financial statements and related footnotes included elsewhere in this Quarterly Report and included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2020 (the “2020 10-K”), which includes our condensed consolidated financial statements for the fiscal years ended June 30, 2020 and 2019.

[0001375365-21-000011:mdna:3]
[same as prior period, unchanged from 0001375365-20-000074:mdna:3]

[0001375365-21-000011:mdna:4]
[same as prior period, unchanged from 0001375365-20-000074:mdna:4]

[0001375365-21-000011:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. Our net income for the three months ended December 31, 2020 increased to $27.7 million from $23.7 million for the corresponding period in the prior year. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin and operating margin. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new microprocessors and storage technologies, and as a result, we monitor the introduction cycles of Nvidia Corporation, Intel Corporation, Advanced Micro Devices, Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-21-000011:mdna:6]
[same as prior period, unchanged from 0001375365-20-000074:mdna:6]

[0001375365-21-000011:mdna:7]
The global spread of the coronavirus (COVID-19) and the various attempts to contain it have created significant volatility, uncertainty and economic disruption for many businesses worldwide. In an effort to contain COVID-19 or slow its spread, governments around the world have enacted various measures, including orders that govern the operations of businesses, require masks be worn and define shelter in place and social distancing protocols. We are an essential critical infrastructure (information technology) business under the relevant federal, state and county regulations. Accordingly, in late March 2020, we responded to the directives from Santa Clara County and the State of California regarding instructions to combat the spread of COVID-19. Our first priority is the safety of our workforce and we have implemented numerous health precautions and work practices to be in compliance with the law and to operate in a safe manner.

[0001375365-21-000011:mdna:8]
We quickly transitioned certain of our indirect labor forces to work from home at the earlier phase of the pandemic and continued to operate our local assembly in Taiwan and, after an initial period of disruption, in the United States and Europe. We operate in the critical industry of IT infrastructure and we assessed our customer base to identify priority customers who operate in critical industries. We continued to see ongoing demand and do not have significant direct exposure to industries such as retail, oil and gas and hospitality, which have been impacted the greatest. As time passes, we may discover greater indirect exposure to distressed industries through our channel partners and OEM customers.

[0001375365-21-000011:mdna:9]
[same as prior period, unchanged from 0001375365-20-000074:mdna:9]

[0001375365-21-000011:mdna:10]
[same as prior period, unchanged from 0001375365-20-000074:mdna:10]

[0001375365-21-000011:mdna:11]
We monitor the credit profile and payment history of our customers to evaluate risk in specific industries or geographic areas where cash flow may be disrupted. While we believe that we are adequately capitalized, we actively manage our liquidity needs. In May 2020, we negotiated an extension of our credit facility with Bank of America to extend the maturity date to June 2021. In June 2020, we entered into a ten-year, non-revolving term loan facility with China Trust and Bank Corp ("CTBC Bank") to obtain financing for use in the expansion and renovation of the our Bade Manufacturing Facility located in Taiwan. In December 2020, our Taiwan subsidiary entered into a general credit agreement with E.SUN Bank in Taiwan. Such general credit agreement provides for the issuance of loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30 million. The term of such general credit agreement is until September 18, 2021.

[0001375365-21-000011:mdna:12]
[same as prior period, unchanged from 0001375365-20-000074:mdna:12]

[0001375365-21-000011:mdna:13]
[same as prior period, unchanged from 0001375365-20-000074:mdna:13]

[0001375365-21-000011:mdna:14]
The following is a summary of our financial highlights of the second quarter of fiscal year 2021:

[0001375365-21-000011:mdna:15]
•Net sales decreased by 4.7% in the three months ended December 31, 2020 as compared to the three months ended December 31, 2019.

[0001375365-21-000011:mdna:16]
•Gross margin increased to 16.4% in the three months ended December 31, 2020 from 15.9% in the three months ended December 31, 2019.

[0001375365-21-000011:mdna:17]
•Operating expenses decreased by 10.7% as compared to the three months ended December 31, 2019, and were equal to 11.9% and 12.7% of net sales in the three months ended December 31, 2020 and 2019, respectively.

[0001375365-21-000011:mdna:18]
•Effective tax rate increased from 7.9% in the three months ended December 31, 2019 to 14.9% in the three months ended December 31, 2020.

[0001375365-21-000011:mdna:19]
[same as prior period, unchanged from 0001375365-20-000074:mdna:19]

[0001375365-21-000011:mdna:20]
Our discussion and analysis of our financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with generally accepted accounting principles in the United States. The preparation of these condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses. We evaluate our estimates and assumptions on an ongoing basis, and base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for the judgments we make about the carrying value of assets and liabilities that are not readily apparent from other sources.  Because these estimates can vary depending on the situation, actual results may differ from these estimates.  Making estimates and judgments about future events is inherently unpredictable and is subject to significant uncertainties, some of which are beyond our control. Should any of these estimates and assumptions change or prove to have been incorrect, it could have a material impact on our results of operations, financial position and statement of cash flows.

[0001375365-21-000011:mdna:21]
There have been no material changes to our critical accounting policies and estimates as compared to those disclosed in our 2020 10-K. For a description of our critical accounting policies and estimates, see Part I, Item 1, Note 1, "Summary of Significant Accounting Policies" in our notes to condensed consolidated financial statements in this Quarterly Report.

[0001375365-21-000011:mdna:22]
[same as prior period, unchanged from 0001375365-20-000074:mdna:22]

[0001375365-21-000011:mdna:23]
[same as prior period, unchanged from 0001375365-20-000074:mdna:23]

[0001375365-21-000011:mdna:24]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2020 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 83.6 | % |  | 84.1 | % |  | 83.3 | % |  | 83.9 | % |
| Gross profit | 16.4 | % |  | 15.9 | % |  | 16.7 | % |  | 16.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6.4 | % |  | 6.4 | % |  | 6.8 | % |  | 6.3 | % |
| Sales and marketing | 2.5 | % |  | 2.5 | % |  | 2.6 | % |  | 2.5 | % |
| General and administrative | 3.0 | % |  | 3.8 | % |  | 3.1 | % |  | 3.8 | % |
| Total operating expenses | 11.9 | % |  | 12.7 | % |  | 12.4 | % |  | 12.5 | % |
| Income from operations | 4.5 | % |  | 3.2 | % |  | 4.3 | % |  | 3.6 | % |
| Other (expense) income, net | (0.3) | % |  | — | % |  | (0.2) | % |  | 0.1 | % |
| Interest expense | (0.1) | % |  | (0.1) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 4.1 | % |  | 3.1 | % |  | 4.0 | % |  | 3.6 | % |
| Income tax provision | (0.6) | % |  | (0.2) | % |  | (0.6) | % |  | (0.6) | % |
| Share of (loss) from equity investee, net of taxes | (0.2) | % |  | (0.1) | % |  | — | % |  | — | % |
| Net income | 3.3 | % |  | 2.7 | % |  | 3.4 | % |  | 3.0 | % |

[0001375365-21-000011:mdna:25]
[same as prior period, unchanged from 0001375365-20-000074:mdna:25]

[0001375365-21-000011:mdna:26]
[same as prior period, unchanged from 0001375365-20-000074:mdna:26]

[0001375365-21-000011:mdna:27]
[same as prior period, unchanged from 0001375365-20-000074:mdna:27]

[0001375365-21-000011:mdna:28]
The following table presents net sales by product type for the three and six months ended December 31, 2020 and 2019 (dollars in millions):

[0001375365-21-000011:mdna:29]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Server and storage systems | $ | 642.7 |  |  | $ | 672.7 |  |  | $ | (30.0) |  |  | (4.5) | % |  | $ | 1,260.5 |  |  | $ | 1,308.7 |  |  | $ | (48.2) |  |  | (3.7) | % |
| Percentage of total net sales | 77.4 | % |  | 77.2 | % |  |  |  |  |  | 79.1 | % |  | 78.3 | % |  |  |  |  |
| Subsystems and accessories | $ | 187.6 |  |  | $ | 198.2 |  |  | $ | (10.6) |  |  | (5.3) | % |  | $ | 332.1 |  |  | $ | 362.0 |  |  | $ | (29.9) |  |  | (8.3) | % |
| Percentage of total net sales | 22.6 | % |  | 22.8 | % |  |  |  |  |  | 20.9 | % |  | 21.7 | % |  |  |  |  |
| Total net sales | $ | 830.3 |  |  | $ | 870.9 |  |  | $ | (40.6) |  |  | (4.7) | % |  | $ | 1,592.6 |  |  | $ | 1,670.7 |  |  | $ | (78.1) |  |  | (4.7) | % |

[0001375365-21-000011:mdna:30]
[same as prior period, unchanged from 0001375365-20-000074:mdna:30]

[0001375365-21-000011:mdna:31]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:32]
The period-over-period decrease in net sales of our server and storage systems was due to a 17.1% decrease in the number of units of compute nodes sold offset by 16.0% increase in the average selling price. The decline in the number of units of compute nodes shipped was primarily due to fewer shipments of multinode systems compared to the same period last year.

[0001375365-21-000011:mdna:33]
The period-over-period decrease in net sales of our subsystems and accessories is primarily due to a decrease in the number of units of subsystems sold.

[0001375365-21-000011:mdna:34]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:35]
The period-over-period decrease in net sales of our server and storage systems was due to a 18.1% decrease in the number of units of compute nodes sold offset by 17.9% increase in average selling price. The decline in the number of units of compute nodes shipped was primarily due to fewer shipments of multinode systems compared to the same period last year.

[0001375365-21-000011:mdna:36]
The period-over-period decrease in net sales of our subsystems and accessories is primarily due to a decrease in the number of units of subsystems sold.

[0001375365-21-000011:mdna:37]
The following table presents net sales by geographic region for the three and six months ended December 31, 2020 and 2019 (dollars in millions):

[0001375365-21-000011:mdna:38]
|  | Three Months Ended December 31, |  | Change |  | Change |  | Six Months Ended December 31, |  | Change |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| United States | $ | 463.1 |  |  | $ | 527.4 |  |  | $ | (64.3) |  |  | (12.2) | % |  | $ | 959.2 |  |  | $ | 996.2 |  |  | $ | (37.0) |  |  | (3.7) | % |
| Percentage of total net sales | 55.8 | % |  | 60.6 | % |  |  |  |  |  | 60.2 | % |  | 59.6 | % |  |  |  |  |
| Asia | 161.4 |  |  | 165.7 |  |  | (4.3) |  |  | (2.6) | % |  | 288.1 |  |  | 327.4 |  |  | (39.3) |  |  | (12.0) | % |
| Percentage of total net sales | 19.4 | % |  | 19.0 | % |  |  |  |  |  | 18.1 | % |  | 19.6 | % |  |  |  |  |
| Europe | 154.8 |  |  | 147.6 |  |  | 7.2 |  |  | 4.9 | % |  | 266.9 |  |  | 275.6 |  |  | (8.7) |  |  | (3.2) | % |
| Percentage of total net sales | 18.6 | % |  | 16.9 | % |  |  |  |  |  | 16.8 | % |  | 16.5 | % |  |  |  |  |
| Others | 51.0 |  |  | 30.2 |  |  | 20.8 |  |  | 68.9 | % |  | 78.4 |  |  | 71.5 |  |  | 6.9 |  |  | 9.7 | % |
| Percentage of total net sales | 6.1 | % |  | 3.5 | % |  |  |  |  |  | 4.9 | % |  | 4.3 | % |  |  |  |  |
| Total net sales | $ | 830.3 |  |  | $ | 870.9 |  |  |  |  |  |  | $ | 1,592.6 |  |  | $ | 1,670.7 |  |  |  |  |  |

[0001375365-21-000011:mdna:39]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:40]
The period-over-period decrease in net sales in the United States for the three months ended December 30, 2020 and 2019 was primarily due to lower sales driven by lower unit volume. The period-over-period decrease in net sales in Asia was due primarily to decreased sales in Taiwan, Singapore and Korea and partially off-set by increased sales in China and Japan. The increase of net sales in Europe was primarily due to higher sales in France, Germany, the United Kingdom, and the Netherlands, partially offset by lower sales in Russia. The period-over-period increase in net sales in other countries was primarily due to increased sales in Brazil, Canada, South Africa and Middle East countries, partially offset by lower sales in Mexico.

[0001375365-21-000011:mdna:41]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:42]
The period-over-period decrease in net sales in the United States for the six months ended December 31, 2020 and 2019 was primarily due to lower sales driven by lower unit volume. The period-over-period decrease in net sales in Asia was due primarily to decreased sales in China, Taiwan, Korea, and India and partially off-set by increased sales in Singapore and Japan. The decrease of net sales in Europe was primarily due to lower sales in the United Kingdom, Germany, Russia, and the rest of Europe, partially offset by increased sales in France and the Netherlands. The period-over-period increase in net sales in other countries was primarily due to increased sales in Brazil, Canada, South Africa and Middle East countries, partially offset by lower sales in Mexico and Australia.

[0001375365-21-000011:mdna:43]
[same as prior period, unchanged from 0001375365-20-000074:mdna:36]

[0001375365-21-000011:mdna:44]
[same as prior period, unchanged from 0001375365-20-000074:mdna:37]

[0001375365-21-000011:mdna:45]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with final assembly and testing predominantly performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain of other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of components, particularly power supplies.

[0001375365-21-000011:mdna:46]
Cost of sales and gross margin for the three and six months ended December 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000011:mdna:47]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Cost of sales | $ | 694.2 |  |  | $ | 732.5 |  |  | $ | (38.3) |  |  | (5.2) | % |  | $ | 1,326.5 |  |  | $ | 1,401.4 |  |  | $ | (74.9) |  |  | (5.3) | % |
| Gross profit | $ | 136.1 |  |  | $ | 138.4 |  |  | $ | (2.3) |  |  | (1.7) | % |  | $ | 266.0 |  |  | $ | 269.3 |  |  | $ | (3.3) |  |  | (1.2) | % |
| Gross margin | 16.4 | % |  | 15.9 | % |  |  |  | 0.5 | % |  | 16.7 | % |  | 16.1 | % |  |  |  | 0.6 | % |

[0001375365-21-000011:mdna:48]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:49]
The period-over-period decrease in cost of sales was primarily attributed to a decrease of $21.5 million in costs of materials and contract manufacturing expenses primarily related to the decrease in net sales volume, a decrease of $13.2 million in overhead costs attributable primarily to a recovery of costs paid in prior periods, a decrease of excess and obsolete inventory charge of $3.3 million and a decrease of $1.9 million of warranty and repair costs, partially offset by service costs and freight charges.

[0001375365-21-000011:mdna:50]
[same as prior period, unchanged from 0001375365-20-000074:mdna:42]

[0001375365-21-000011:mdna:51]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:52]
The period-over-period decrease in cost of sales was primarily attributed to a decrease of $40.7 million in costs of materials and contract manufacturing expenses primarily related to the decrease in net sales volume, a decrease of $23.6 million in overhead costs attributable primarily to a recovery of costs paid in prior periods and a decrease of excess and obsolete inventory charge of $12.3 million, partially offset by service costs and freight charges.

[0001375365-21-000011:mdna:53]
The period-over-period increase in the gross margin percentage was primarily due to sales prices declining at a slower rate than the decline in the costs of components we purchased.

[0001375365-21-000011:mdna:54]
[same as prior period, unchanged from 0001375365-20-000074:mdna:43]

[0001375365-21-000011:mdna:55]
[same as prior period, unchanged from 0001375365-20-000074:mdna:44]

[0001375365-21-000011:mdna:56]
[same as prior period, unchanged from 0001375365-20-000074:mdna:45]

[0001375365-21-000011:mdna:57]
[same as prior period, unchanged from 0001375365-20-000074:mdna:46]

[0001375365-21-000011:mdna:58]
Operating expenses for the three and six months ended December 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000011:mdna:59]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Research and development | $ | 52.7 |  |  | $ | 55.6 |  |  | $ | (2.9) |  |  | (5.2) | % |  | $ | 107.5 |  |  | $ | 105.1 |  |  | $ | 2.4 |  |  | 2.3 | % |
| Percentage of total net sales | 6.4 | % |  | 6.4 | % |  |  |  |  |  | 6.8 | % |  | 6.3 | % |  |  |  |  |
| Sales and marketing | $ | 20.7 |  |  | $ | 22.0 |  |  | $ | (1.3) |  |  | (5.9) | % |  | $ | 41.0 |  |  | $ | 42.2 |  |  | $ | (1.2) |  |  | (2.8) | % |
| Percentage of total net sales | 2.5 | % |  | 2.5 | % |  |  |  |  |  | 2.6 | % |  | 2.5 | % |  |  |  |  |
| General and administrative | $ | 25.3 |  |  | $ | 33.0 |  |  | $ | (7.7) |  |  | (23.3) | % |  | $ | 49.6 |  |  | $ | 61.3 |  |  | $ | (11.7) |  |  | (19.1) | % |
| Percentage of total net sales | 3.0 | % |  | 3.9 | % |  |  |  |  |  | 3.1 | % |  | 3.7 | % |  |  |  |  |
| Total operating expenses | $ | 98.7 |  |  | $ | 110.6 |  |  | $ | (11.9) |  |  | (10.8) | % |  | $ | 198.2 |  |  | $ | 208.7 |  |  | $ | (10.5) |  |  | (5.0) | % |
| Percentage of total net sales | 11.9 | % |  | 12.7 | % |  |  |  |  |  | 12.4 | % |  | 12.5 | % |  |  |  |  |

[0001375365-21-000011:mdna:60]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:61]
Research and development expenses. The period-over-period decrease in research and development expenses was primarily due to an increase in research and development credits from certain suppliers and customers towards our development efforts of $4.3 million, a decrease of $1.9 million in costs mainly related to materials, supplies and equipment used in product development, and a decrease of $0.8 million of travel expenses as a result in a change in our operations in response to the COVID-19 pandemic, partially offset by an increase of $4.0 million in personnel expenses as a result of an increase in the number of personnel, mainly from the expansion of the Company's Taiwan subsidiary.

[0001375365-21-000011:mdna:62]
Sales and marketing expenses. The period-over-period sales and marketing expenses decreased primarily due to a $1.4 million decrease in expenses related to participation in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic, partially offset by increase in other sales and marketing expenses.

[0001375365-21-000011:mdna:63]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $11.4 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $1.1 million in travel expenses as a result in a change in our operations in response to the COVID-19 pandemic, and a decrease of $0.7 million in sales tax reserve and audit expense, offset by an increase of $6.5 million in compensation expense due to increased full time personnel and bonuses.

[0001375365-21-000011:mdna:64]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:65]
Research and development expenses. The period-over-period increase in research and development expenses was primarily due to an increase of $9.7 million in personnel expenses as a result of an increase in the number of personnel offset by an increase of $5.7 million in research and development credits from certain suppliers and customers towards our development efforts, a decrease of $1.3 million in travel expenses as a result in a change in our operations in response to the COVID-19 pandemic, and a decrease of $0.7 million in costs mainly related to materials, supplies and equipment used in product development.

[0001375365-21-000011:mdna:66]
Sales and marketing expenses. The period-over-period sales and marketing expenses decreased primarily due to a decrease of $2.0 million expenses related to participation in trade shows and business travel as a result in a change in our operations in response to the COVID-19 pandemic, partially offset by an increase of $0.8 million in other sales and marketing expenses.

[0001375365-21-000011:mdna:67]
General and administrative expenses. The period-over-period decrease in general and administrative expenses was primarily due to a decrease of $18.2 million in professional fees incurred to investigate, assess and remediate the causes that led to the delay in filing our periodic reports with the SEC and the associated restatement of certain of our previously issued financial statements, a decrease of $2.1 million in travel expenses as a result in a change in our operations in response to the COVID-19 pandemic, a decrease of $0.8 million in sales tax reserve and audit expense, and a decrease of $0.5 million in bad debt expenses, offset by an increase of $10.4 million in compensation expense due to increased full time personnel and bonuses.

[0001375365-21-000011:mdna:68]
[same as prior period, unchanged from 0001375365-20-000074:mdna:53]

[0001375365-21-000011:mdna:69]
[same as prior period, unchanged from 0001375365-20-000074:mdna:54]

[0001375365-21-000011:mdna:70]
[same as prior period, unchanged from 0001375365-20-000074:mdna:55]

[0001375365-21-000011:mdna:71]
Interest and other (expense) income, net for the three and six months ended December 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000011:mdna:72]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Other (expense) income, net | $ | (2.5) |  |  | $ | (0.4) |  |  | $ | (2.1) |  |  | 525.0 | % |  | $ | (3.4) |  |  | $ | 1.2 |  |  | $ | (4.6) |  |  | (383.3) | % |
| Interest expense | (0.6) |  |  | (0.6) |  |  | — |  |  | — | % |  | (1.2) |  |  | (1.1) |  |  | (0.1) |  |  | 9.1 | % |
| Interest and other (expense) income, net | $ | (3.1) |  |  | $ | (1.0) |  |  | $ | (2.1) |  |  | 210.0 | % |  | $ | (4.6) |  |  | $ | 0.1 |  |  | $ | (4.7) |  |  | (4,700.0) | % |

[0001375365-21-000011:mdna:73]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:74]
The change of $2.1 million in other (expense) income, net was attributable to an increase of $1.4 million in foreign exchange loss due to unfavorable foreign currency fluctuations, and a decrease of $0.7 million in interest income on our interest bearing deposits due primarily to lower yields on investments.

[0001375365-21-000011:mdna:75]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:76]
The change of $4.6 million in other (expense) income, net was attributable to an increase of $2.9 million in foreign exchange loss due to unfavorable foreign currency fluctuations, and a decrease of $1.7 million in interest income on our interest bearing deposits due primarily to lower yields on investments.

[0001375365-21-000011:mdna:77]
[same as prior period, unchanged from 0001375365-20-000074:mdna:59]

[0001375365-21-000011:mdna:78]
[same as prior period, unchanged from 0001375365-20-000074:mdna:60]

[0001375365-21-000011:mdna:79]
Provision for income taxes and effective tax rates for the three and six months ended December 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000011:mdna:80]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Income tax provision | $ | 5.1 |  |  | $ | 2.1 |  |  | $ | 3.0 |  |  | 142.9 | % |  | $ | 8.8 |  |  | $ | 10.7 |  |  | $ | (1.9) |  |  | (17.8) | % |
| Percentage of total net sales | 0.6 | % |  | 0.2 | % |  |  |  |  |  | 0.6 | % |  | 0.6 | % |  |  |  |  |
| Effective tax rate | 14.9 | % |  | 7.9 | % |  |  |  |  |  | 13.9 | % |  | 17.6 | % |  |  |  |  |

[0001375365-21-000011:mdna:81]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:82]
The income tax provision and effective tax rate for the three months ended December 31, 2020 was higher than that for the three months ended December 31, 2019 due to the release of tax reserves after the settlement of a Taiwan tax audit in 2019.

[0001375365-21-000011:mdna:83]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:84]
The income tax provision and effective tax rate for the six months ended December 31, 2020 was lower than that for the six months ended December 31, 2019, primarily due to decrease in tax reserves after the settlement of a Taiwan tax audit and increase in tax benefit from employees’ stock based compensation.

[0001375365-21-000011:mdna:85]
Share of (Loss) from Equity Investee, Net of Taxes

[0001375365-21-000011:mdna:86]
Share of (loss) from equity investee, net of taxes represents the Company’s share of loss from the Corporate Venture in which the Company has 30% ownership.

[0001375365-21-000011:mdna:87]
Share of (loss) from equity investee, net of taxes for the three and six months ended December 31, 2020 and 2019 are as follows (dollars in millions):

[0001375365-21-000011:mdna:88]
|  | Three Months EndedDecember 31, |  | Change | Six Months EndedDecember 31, |  | Change |
|  | 2020 |  | 2019 |  | $ |  | % |  | 2020 |  | 2019 |  | $ |  | % |
| Share of (loss) from equity investee, net of taxes | $ | (1.5) |  |  | $ | (1.0) |  |  | $ | (0.5) |  |  | 50.0% |  | $ | (0.1) |  |  | $ | — |  |  | $ | (0.1) |  |  | —% |
| Percentage of total net sales | (0.2) | % |  | (0.1) | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001375365-21-000011:mdna:89]
Comparison of Three Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:90]
The period-over-period increase of $0.5 million in share of (loss) from equity investee, net of taxes was primarily due to more net loss recognized by the Corporate Venture.

[0001375365-21-000011:mdna:91]
Comparison of Six Months Ended December 31, 2020 and 2019

[0001375365-21-000011:mdna:92]
The period-over-period increase of $0.1 million in share of (loss) from equity investee, net of taxes was primarily due to more net loss recognized by the Corporate Venture.

[0001375365-21-000011:mdna:93]
[same as prior period, unchanged from 0001375365-20-000074:mdna:64]

[0001375365-21-000011:mdna:94]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities, particularly in relation to the financing of real property acquisitions as well as working capital. Our cash and cash equivalents were $315.6 million and $210.5 million as of December 31, 2020 and June 30, 2020, respectively. Our cash in foreign locations was $141.5 million and $98.0 million as of December 31, 2020 and June 30, 2020, respectively.

[0001375365-21-000011:mdna:95]
[same as prior period, unchanged from 0001375365-20-000074:mdna:66]

[0001375365-21-000011:mdna:96]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses, continued remediation of the material weakness in the financial reporting, and maturing debt and interest payments for the twelve months following the issuance of these condensed consolidated financial statements. We expect to pay special performance bonuses of approximately $8.6 million to our CEO and certain members of the Board of Directors within the next two years when and if specified market and performance conditions are met. In addition, we made a settlement payment of $17.5 million to the SEC in connection with the conclusion of the investigations in August 2020.

[0001375365-21-000011:mdna:97]
On August 9, 2020, the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $30.0 million at market prices. The program was effective until December 31, 2020 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended September 30, 2020, 1,142,294 shares of common stock were repurchased for $30.0 million and the program ended.

[0001375365-21-000011:mdna:98]
On October 31, 2020, the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $50.0 million at market prices. The program is effective until October 31, 2021 or if earlier, until the maximum amount of common stock is repurchased. During the three months ended December 31, 2020, 1,580,207 shares of common stock were repurchased for $47.0 million. We repurchased 95,539 shares of our common stock for $3.0 million subsequent to December 31, 2020 and completed this share repurchase program on January 6, 2021.

[0001375365-21-000011:mdna:99]
On January 29, 2021, a duly authorized subcommittee of the Board approved a share repurchase program to repurchase shares of common stock for up to an aggregate of $200.0 million at market price. The program is effective until July 31, 2022 or if earlier, until the maximum amount of common stock is repurchased.

[0001375365-21-000011:mdna:100]
[same as prior period, unchanged from 0001375365-20-000074:mdna:69]

[0001375365-21-000011:mdna:101]
|  | Six Months EndedDecember 31, |  | Change |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Net cash provided by operating activities | $ | 183.8 |  |  | $ | 87.2 |  |  | $ | 96.6 |  |  |  |  |
| Net cash used in investing activities | $ | (25.6) |  |  | $ | (23.3) |  |  | $ | (2.3) |  |  |  |  |
| Net cash used in financing activities | $ | (53.7) |  |  | $ | (2.1) |  |  | $ | (51.6) |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 105.1 |  |  | $ | 61.9 |  |  | $ | 43.2 |  |  |  |  |

[0001375365-21-000011:mdna:102]
[same as prior period, unchanged from 0001375365-20-000074:mdna:71]

[0001375365-21-000011:mdna:103]
Net cash provided by operating activities increased by $96.6 million for the six months ended December 31, 2020 as compared to the six months ended December 31, 2019. The increase was due primarily to a $4.2 million increase in net income and an increase of cash provided by net working capital of $99.9 million driven by decreased accounts receivable as a result of increased collections, utilization of inventories and prepaid expenses and other current assets. Non-cash charges related to depreciation and amortization expense, stock-based compensation expense and unrealized losses on our foreign currency-denominated credit facilities increased $6.6 million. These increases were offset by a decrease of $12.5 million in the non-cash charges related to excess and obsolete inventories.

[0001375365-21-000011:mdna:104]
[same as prior period, unchanged from 0001375365-20-000074:mdna:73]

[0001375365-21-000011:mdna:105]
Net cash used in investing activities was $25.6 million and $23.3 million for the six months ended December 31, 2020 and 2019, respectively, as we continued to invest in expanding our manufacturing capacity and office space, including the expansion of our Green Computing Park in San Jose and Bade manufacturing facility in Taiwan.

[0001375365-21-000011:mdna:106]
[same as prior period, unchanged from 0001375365-20-000074:mdna:75]

[0001375365-21-000011:mdna:107]
Net cash used by financing activities for the six months ended December 31, 2020 was $53.7 million while net cash used in financing activities for the six months ended December 31, 2019 was $2.1 million. The change in cash flows from financing activities was primarily due to stock repurchases of $74.8 million offset by the increase in cash received from the exercise of stock options of $7.9 million net of taxes, $14.7 million of debt proceeds from draws on our CTBC credit and term loan facilities and $0.5 million decrease in debt repayment.

[0001375365-21-000011:mdna:108]
[same as prior period, unchanged from 0001375365-20-000074:mdna:77]

[0001375365-21-000011:mdna:109]
2018 Bank of America Credit Facility

[0001375365-21-000011:mdna:110]
In April 2018, we entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the "2018 Bank of America Credit Facility").  On May 12, 2020, the 2018 Bank of America Credit Facility was amended to, among other things, extend the maturity to June 30, 2021, release the real property as a collateral, modify certain payments and covenants provisions, specify that LIBOR cannot be less than 1% for purposes of determining interest rates, and increase the unused line fee from 0.25% per annum to 0.375% per annum. Interest shall accrue at LIBOR plus 2.00% on outstanding borrowings less than $125.0 million and LIBOR plus 2.25% on outstanding borrowings in excess of $125.0 million. As of December 31, 2020, we had no outstanding borrowings and we had a $6.4 million letter of credit outstanding under this facility. Our available borrowing capacity was $243.6 million, subject to the borrowing base limitation and compliance with other applicable terms.  In the event of default or if outstanding borrowings are in excess of $220.0 million, we are required to grant the lenders a continuing security interest in and lien upon all amounts credited to any of our deposit accounts. Interest accrued on any loans under the 2018 Bank of America Credit Facility is due on the first day of each month, and the loans are due and payable in full on the termination date of the 2018 Bank of America Credit Facility. Voluntary prepayments are permitted without early repayment fees or penalties. The 2018 Bank of America Credit Facility is secured by substantially all of Super Micro Computer’s assets, other than real property assets. In addition, we are not permitted to pay any dividends. Under the terms of the 2018 Bank of America Credit Facility agreement, we are required to maintain a certain fixed charge ratio and we have been in compliance with all covenants under the 2018 Bank of America Credit Facility.

[0001375365-21-000011:mdna:111]
[same as prior period, unchanged from 0001375365-20-000074:mdna:80]

[0001375365-21-000011:mdna:112]
2020 CTBC Credit Facility

[0001375365-21-000011:mdna:113]
In August 2020, we entered into a credit agreement with CTBC Bank in Taiwan that provides for term loans of up to $50.0 million (the "2020 CTBC Credit Facility") and expires in August 2021. During the three months ended December 31, 2020, we have not borrowed or repaid under the revolving line of credit. There were no outstanding borrowings under the 2020 CTBC Credit Facility revolving line of credit as of December 31, 2020. The total outstanding borrowings under the 2020 CTBC Credit Facility term loan were denominated in NTD and remeasured into U.S. dollars of $24.9 million at December 31, 2020. The amount available for future borrowing was $25.1 million as of December 31, 2020. The interest rate for these outstanding term loans was 0.73% per annum as of December 31, 2020.Term loans are secured by certain of our assets, including certain property, plant, and equipment. There are no financial covenants under the 2020 CTBC Credit Facility.

[0001375365-21-000011:mdna:114]
[same as prior period, unchanged from 0001375365-20-000074:mdna:83]

[0001375365-21-000011:mdna:115]
In May 2020, we entered into a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to obtain up to NTD 1.2 billion ($40.7 million in U.S. dollar equivalents) in financing for use in the expansion and renovation of our Bade Manufacturing Facility located in Taiwan. Draw downs on the 2020 CTBC Term Loan Facility are based on 80% of balances owed on commercial invoices from the contractor and are drawn according to the progress of the renovations. Borrowings under the 2020 CTBC Term Loan Facility are available through June 2022. We are required to pay against total outstanding principal and interest in equal monthly installments starting June 2023 and continuing through the maturity date of June 2030. The 2020 CTBC Term Loan Facility is secured by the Bade Manufacturing Facility, including any expansion. Fees paid to the lender as debt issuance costs were immaterial. We borrowed $8.6  million in the three months ended December 31, 2020 with a rate of 0.45% per annum. As of December 31, 2020, the amount outstanding under the 2020 CTBC Term Loan Facility was $20.6 million and the net book value of the property serving as collateral was $29.2 million. We have financial covenants requiring our current ratio, debt service coverage ratio, and financial debt ratio, to be maintained at certain levels. As of December 31, 2020, we have been in compliance with all financial covenants under the 2020 CTBC Term Loan Facility.

[0001375365-21-000011:mdna:116]
E.SUN Credit Facility

[0001375365-21-000011:mdna:117]
In December 2020, Super Micro Computer Inc, Taiwan, a Taiwan subsidiary of the Company entered into a General Credit Agreement (the “E.SUN Credit Facility”) with E.SUN Bank in Taiwan.  Such Credit Facility provides for the issuance of

[0001375365-21-000011:mdna:118]
loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments up to a credit limit of $30.0 million. Terms for specific drawdowns are set forth in separate Notification and Confirmation of Credit Conditions negotiated with E. SUN Bank. The term of the E.SUN Credit Facility is until September 18, 2021. There are no financial covenants associated with the E.SUN Credit Facility. A Notification and Confirmation agreement was entered into on December 2, 2020 for a $30.0 million import loan (the “Import Loan”) under the E. SUN Credit facility with a tenor of 120 days and with an interest rate calculated based on LIBOR or TAIFX plus a fixed margin. As of December 31, 2020, no drawings had been made from the Import Loan.

[0001375365-21-000011:mdna:119]
Refer to Part I, Item 1, Note 6, “Short-term and Long-term Debt,” in our notes to condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding debt.

[0001375365-21-000011:mdna:120]
[same as prior period, unchanged from 0001375365-20-000074:mdna:86]

[0001375365-21-000011:mdna:121]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our condensed consolidated financial statements, see Part I, Item 1, Note 1, “Summary of Significant Accounting Policies,” in our notes to condensed consolidated financial statements in this Quarterly Report on Form 10-Q.

[0001375365-21-000011:mdna:122]
[same as prior period, unchanged from 0001375365-20-000074:mdna:88]

[0001375365-21-000011:mdna:123]
[same as prior period, unchanged from 0001375365-20-000074:mdna:89]
