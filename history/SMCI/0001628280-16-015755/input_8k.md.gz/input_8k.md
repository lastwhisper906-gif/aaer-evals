# SMCI 8-K — 0001628280-16-014939 filed 2016-04-28

## item codes, every 8-K on or before 2016-05-06

- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2016-05-06

- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-014939:8k_2_02:1]
EX-99.1
2
exhibit991q3-2016.htm
PRESS RELEASE OF SUPER MICRO COMPUTER, INC.

[0001628280-16-014939:8k_2_02:2]
Exhibit

[0001628280-16-014939:8k_2_02:3]
Exhibit 99.1

[0001628280-16-014939:8k_2_02:4]
Super Micro Computer, Inc. Announces 3rd Quarter 2016 Financial Results

[0001628280-16-014939:8k_2_02:5]
SAN JOSE, Calif., April 28, 2016 (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ:SMCI), a global leader in high-performance, high-efficiency server, storage technology and green computing, today announced third quarter fiscal 2016 financial results for the quarter ended March 31, 2016. The final results are in line with the preliminary results announced by the Company on April 14, 2016.

[0001628280-16-014939:8k_2_02:6]
Fiscal 3rd Quarter Highlights

[0001628280-16-014939:8k_2_02:7]
| • | Quarterly net sales of $532.7 million, down 16.6% from the second quarter of fiscal year 2016 and up 13.1% from the same quarter of last year. |

[0001628280-16-014939:8k_2_02:8]
| • | GAAP net income of $16.7 million, down 52.0% from the second quarter of fiscal year 2016 and down 27.7% from the same quarter of last year. |

[0001628280-16-014939:8k_2_02:9]
| • | GAAP gross margin was 14.9%, down from 16.6% in the second quarter of fiscal year 2016 and down from 16.3% in the same quarter of last year. |

[0001628280-16-014939:8k_2_02:10]
| • | Server solutions accounted for 69.9% of net sales compared with 71.0% in the second quarter of fiscal year 2016 and 64.1% in the same quarter of last year. |

[0001628280-16-014939:8k_2_02:11]
Net sales for the third quarter ended March 31, 2016 totaled $532.7 million, down 16.6% from $639.0 million in the second quarter of fiscal year 2016. One customer accounted for 10.2% of net sales during the quarter ended March 31, 2016.

[0001628280-16-014939:8k_2_02:12]
GAAP net income for the third quarter of fiscal year 2016 was $16.7 million or $0.32 per diluted share, a decrease of 27.7% from net income of $23.1 million, or $0.44 per diluted share in the same period a year ago. Included in net income for the quarter is $3.9 million of stock-based compensation expense (pre-tax). Excluding this item and the related tax effect, non-GAAP net income for the third quarter was $19.0 million, or $0.36 per diluted share, compared to non-GAAP net income of $24.9 million, or $0.47 per diluted share, in the same quarter of the prior year. On a sequential basis, non-GAAP net income decreased from the second quarter of fiscal year 2016 by $19.0 million or $0.37 per diluted share.

[0001628280-16-014939:8k_2_02:13]
GAAP and Non-GAAP gross margin for the third quarter was 14.9% compared to 16.3% in the same period a year ago. GAAP gross margin for the second quarter of fiscal year 2016 was 16.6% and Non-GAAP gross margin for the second quarter of fiscal year 2016 was 16.7%.

[0001628280-16-014939:8k_2_02:14]
The GAAP income tax provision was $7.4 million or 30.7% of income before tax provision compared to $8.1 million or 26.1% in the same period a year ago and $14.1 million or 28.8% in the second quarter of fiscal year 2016. The effective tax rates for the second quarter of fiscal year 2016 and third quarter of fiscal year 2015 were lower primarily due to the reinstatement of U.S. federal research and development tax credits.

[0001628280-16-014939:8k_2_02:15]
The Company's cash and cash equivalents and short and long term investments at March 31, 2016 were $179.1 million compared to $98.1 million at June 30, 2015. Free cash flow for the nine months ended March 31, 2016 was $67.7 million, primarily due to an increase in the Company's cash provided by operating activities and partially offset by the cash used in the development and construction of improvements on the Company's properties.

[0001628280-16-014939:8k_2_02:16]
Business Outlook & Management Commentary

[0001628280-16-014939:8k_2_02:17]
The Company expects net sales of $580 million to $640 million for the fourth quarter of fiscal year 2016 ending June 30, 2016. The Company expects non-GAAP earnings per diluted share of approximately $0.46 to $0.58 for the fourth quarter.

[0001628280-16-014939:8k_2_02:18]
“As previously disclosed, in the seasonally weaker third quarter, softer market demand caused our results to be below our guidance. However, we continued to grow at an industry leading pace by growing 13.1% over last year and the third quarter marks the 27 straight quarter of year-over-year growth. This quarter, growth was led by our two strongest segments, Datacenter and Cloud as well as Storage,” said Charles Liang, Chairman and Chief Executive Officer. “As we look to the quarter ahead, Supermicro will again be first to market with the broadest array of server solutions built on Broadwell which was recently launched. In addition, we will continue to offer the industry’s most innovative solutions for the software defined storage market, including all flash, NVMe, hybrid and converged solutions.”

[0001628280-16-014939:8k_2_02:19]
It is currently expected that the outlook will not be updated until the Company’s next quarterly earnings announcement, notwithstanding subsequent developments. However, the Company may update the outlook or any portion thereof at any time. Such updates will take place only by way of a news release or other broadly disseminated disclosure available to all interested parties in accordance with Regulation FD.

[0001628280-16-014939:8k_2_02:20]
Conference Call Information

[0001628280-16-014939:8k_2_02:21]
Super Micro Computer will discuss these financial results in a conference call at 2:00 p.m. PT, today. To participate in the conference, please call 1-888-504-7963 (International callers dial 1-719-785-1765) 10 minutes prior. A recording of the conference will be available until 11:59 pm (Eastern Time) on Thursday, May 12, 2016, by dialing 1-877-870-5176 (International callers dial 1-858-384-5517) and entering replay PIN 1162246. The live web cast and recording of the call will be available on the Investor Relations section at www.supermicro.com two hours after the conference conclusion. They will remain available until the Company's next earnings call.

[0001628280-16-014939:8k_2_02:22]
Cautionary Statement Regarding Forward Looking Statements

[0001628280-16-014939:8k_2_02:23]
Use of Non-GAAP Financial Measures

[0001628280-16-014939:8k_2_02:24]
Non-GAAP gross margin discussed in this press release excludes stock-based compensation expense. Non-GAAP net income and net income per share discussed in this press release exclude stock-based compensation expense and the related tax effect of the applicable items. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool, and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, detailed reconciliations between the Company's GAAP and non-GAAP financial results is provided at the end of this press release. Investors are advised to carefully review and consider this information as well as the GAAP financial results that are disclosed in the Company's SEC filings.

[0001628280-16-014939:8k_2_02:25]
About Super Micro Computer, Inc.

[0001628280-16-014939:8k_2_02:26]
Supermicro®, a global leader in high-performance, high-efficiency server technology and innovation is a premier provider of end-to-end green computing solutions for Data Center, Cloud Computing, Enterprise IT, Hadoop/Big Data, HPC and Embedded Systems worldwide. Supermicro's advanced Server Building Block Solutions® offer a vast array of components for building energy-efficient, application-optimized, computing solutions. Architecture innovations include Twin, TwinPro, FatTwin™, Ultra Series, MicroCloud, MicroBlade, SuperBlade®, Simply Double, Double-sided Storage®, Battery Backup Power (BBP®) modules and WIO/UIO. Products include servers, blades, GPU systems, workstations, motherboards, chassis, power supplies, storage, networking, server management software and SuperRack® cabinets/accessories delivering unrivaled performance and value.

[0001628280-16-014939:8k_2_02:27]
Founded in 1993 and headquartered in San Jose, California, Supermicro is committed to protecting the environment through its "We Keep IT Green®" initiative. The Company has global logistics and operations centers in Silicon Valley (USA), the Netherlands (Europe) and its Science & Technology Park in Taiwan (Asia).

[0001628280-16-014939:8k_2_02:28]
Supermicro, FatTwin, TwinPro, SuperBlade, Double-Sided Storage, BBP, SuperRack, Building Block Solutions and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001628280-16-014939:8k_2_02:29]
All other brands, names and trademarks are the property of their respective owners.

[0001628280-16-014939:8k_2_02:30]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  |  | March 31, |  | June 30, |
|  |  |  |  | 2016 |  | 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 176,406 |  |  | $ | 95,442 |  |
|  | Accounts receivable, net | 285,705 |  |  | 322,594 |  |
|  | Inventory |  | 479,276 |  |  | 463,493 |  |
|  | Deferred income taxes – current | 17,895 |  |  | 17,863 |  |
|  | Prepaid income taxes | 14,913 |  |  | 7,507 |  |
|  | Prepaid expenses and other current assets | 9,416 |  |  | 7,516 |  |
|  |  | Total current assets | 983,611 |  |  | 914,415 |  |
| Long-term investments | 2,633 |  |  | 2,633 |  |
| Property, plant and equipment, net | 179,622 |  |  | 163,038 |  |
| Deferred income taxes – noncurrent |  | 7,089 |  |  | 4,497 |  |
| Other assets |  |  | 8,158 |  |  | 5,226 |  |
|  |  | Total assets | $ | 1,181,113 |  |  | $ | 1,089,809 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 277,279 |  |  | $ | 299,774 |  |
|  | Accrued liabilities |  | 54,132 |  |  | 46,743 |  |
|  | Income taxes payable |  | 9,291 |  |  | 14,111 |  |
|  | Short-term debt and current portion of long-term debt | 93,795 |  |  | 93,479 |  |
|  |  | Total current liabilities | 434,497 |  |  | 454,107 |  |
| Long term debt-net of current portion | — |  |  | 933 |  |
| Other long-term liabilities | 37,615 |  |  | 15,684 |  |
|  |  | Total liabilities | 472,112 |  |  | 470,724 |  |
| Stockholders' equity: |  |  |  |  |
|  | Common stock and additional paid-in capital | 271,950 |  |  | 247,081 |  |
|  | Treasury stock (at cost) | (2,030 | ) |  | (2,030 | ) |
|  | Accumulated other comprehensive loss | (92 | ) |  | (80 | ) |
|  | Retained earnings |  | 439,000 |  |  | 373,950 |  |
|  |  | Total Super Micro Computer Inc. stockholders' equity | 708,828 |  |  | 618,921 |  |
|  | Noncontrolling interest | 173 |  |  | 164 |  |
|  |  | Total stockholders' equity | 709,001 |  |  | 619,085 |  |
|  |  | Total liabilities and stockholders' equity | $ | 1,181,113 |  |  | $ | 1,089,809 |  |

[0001628280-16-014939:8k_2_02:31]
| SUPER MICRO COMPUTER, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 532,721 |  |  | $ | 471,225 |  |  | $ | 1,691,303 |  |  | $ | 1,417,561 |  |
| Cost of sales | 453,569 |  |  | 394,405 |  |  | 1,433,574 |  |  | 1,187,096 |  |
| Gross profit | 79,152 |  |  | 76,820 |  |  | 257,729 |  |  | 230,465 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 31,256 |  |  | 25,542 |  |  | 89,846 |  |  | 72,516 |  |
| Sales and marketing | 14,467 |  |  | 12,496 |  |  | 45,177 |  |  | 34,656 |  |
| General and administrative | 8,984 |  |  | 7,334 |  |  | 27,695 |  |  | 17,334 |  |
| Total operating expenses | 54,707 |  |  | 45,372 |  |  | 162,718 |  |  | 124,506 |  |
| Income from operations | 24,445 |  |  | 31,448 |  |  | 95,011 |  |  | 105,959 |  |
| Interest and other income, net | 20 |  |  | 21 |  |  | 131 |  |  | 92 |  |
| Interest expense | (417 | ) |  | (277 | ) |  | (1,141 | ) |  | (656 | ) |
| Income before income tax provision | 24,048 |  |  | 31,192 |  |  | 94,001 |  |  | 105,395 |  |
| Income tax provision | 7,386 |  |  | 8,136 |  |  | 28,951 |  |  | 30,234 |  |
| Net income | $ | 16,662 |  |  | $ | 23,056 |  |  | $ | 65,050 |  |  | $ | 75,161 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.49 |  |  | $ | 1.36 |  |  | $ | 1.63 |  |
| Diluted | $ | 0.32 |  |  | $ | 0.44 |  |  | $ | 1.26 |  |  | $ | 1.47 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 48,047 |  |  | 46,824 |  |  | 47,737 |  |  | 46,138 |  |
| Diluted | 52,238 |  |  | 52,008 |  |  | 51,637 |  |  | 51,102 |  |
| Stock-based compensation is included in the following cost and expense categories by period (in thousands): |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of sales | $ | 294 |  |  | $ | 222 |  |  | $ | 792 |  |  | $ | 651 |  |
| Research and development | 2,549 |  |  | 2,255 |  |  | 7,423 |  |  | 6,148 |  |
| Sales and marketing | 491 |  |  | 369 |  |  | 1,330 |  |  | 1,148 |  |
| General and administrative | 552 |  |  | 720 |  |  | 2,223 |  |  | 1,780 |  |

[0001628280-16-014939:8k_2_02:32]
| SUPER MICRO COMPUTER, INC |
| CONDENSED CONSOLIDATED CASH FLOW STATEMENTS |
| (In thousands) |
| (Unaudited) |
|  | Nine Months Ended March 31, |
|  | 2016 |  | 2015 |
| OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 65,050 |  |  | $ | 75,161 |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 9,538 |  |  | 5,930 |  |
| Stock-based compensation expense | 11,768 |  |  | 9,727 |  |
| Excess tax benefits from stock-based compensation | (2,506 | ) |  | (7,229 | ) |
| Allowance for doubtful accounts | 1,014 |  |  | 194 |  |
| Provision for inventory | 6,026 |  |  | 4,462 |  |
| Exchange gain | (1,492 | ) |  | (595 | ) |
| Deferred income taxes, net | (2,657 | ) |  | (4,197 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 35,875 |  |  | (9,017 | ) |
| Inventory | (21,809 | ) |  | (119,007 | ) |
| Prepaid expenses and other assets | (3,756 | ) |  | 675 |  |
| Accounts payable | (23,176 | ) |  | 38,712 |  |
| Income taxes payable, net | (8,583 | ) |  | 5,814 |  |
| Accrued liabilities | 5,701 |  |  | 6,748 |  |
| Other long-term liabilities | 21,833 |  |  | 1,686 |  |
| Net cash provided by operating activities | 92,826 |  |  | 9,064 |  |
| INVESTING ACTIVITIES: |  |  |  |
| Purchases of property, plant and equipment | (25,120 | ) |  | (24,637 | ) |
| Investment in a privately held company | — |  |  | (661 | ) |
| Restricted cash | (1,018 | ) |  | (418 | ) |
| Net cash used in investing activities | (26,138 | ) |  | (25,716 | ) |
| FINANCING ACTIVITIES: |  |  |  |
| Proceeds from debt | 24,100 |  |  | 36,400 |  |
| Repayment of debt | (23,700 | ) |  | (35,300 | ) |
| Proceeds from exercise of stock options | 10,661 |  |  | 21,071 |  |
| Excess tax benefits from stock-based compensation | 2,506 |  |  | 7,229 |  |
| Payment of obligations under capital leases | (133 | ) |  | (96 | ) |
| Advances under receivable financing arrangements | 835 |  |  | 669 |  |
| Minimum tax withholding paid on behalf of employees for restricted stock units | (1,108 | ) |  | — |  |
| Net cash provided by financing activities | 13,161 |  |  | 29,973 |  |
| Effect of exchange rate fluctuations on cash | 1,115 |  |  | (948 | ) |
| Net increase in cash and cash equivalents | 80,964 |  |  | 12,373 |  |
| Cash and cash equivalents at beginning of period | 95,442 |  |  | 96,872 |  |
| Cash and cash equivalents at end of period | 176,406 |  |  | 109,245 |  |
| Supplemental disclosure of cash flow information: |  |  |  |
| Cash paid for interest | 1,136 |  |  | 649 |  |
| Cash paid for taxes, net of refunds | 34,562 |  |  | 27,455 |  |
| Non-cash investing and financing activities: |  |  |  |
| Equipment purchased under capital leases | 299 |  |  | 428 |  |
| Accrued costs for property, plant and equipment purchases | 7,316 |  |  | 12,511 |  |

[0001628280-16-014939:8k_2_02:33]
| SUPER MICRO COMPUTER, INC |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP GROSS PROFIT | $ | 79,152 |  |  | $ | 76,820 |  |  | $ | 257,729 |  |  | $ | 230,465 |  |
|  | Add back stock-based compensation (a) | 294 |  |  | 222 |  |  | 792 |  |  | 651 |  |
| Non-GAAP GROSS PROFIT | $ | 79,446 |  |  | $ | 77,042 |  |  | $ | 258,521 |  |  | $ | 231,116 |  |
| GAAP GROSS MARGIN | 14.9 | % |  | 16.3 | % |  | 15.2 | % |  | 16.3 | % |
|  | Add back stock-based compensation (a) | 0.0 | % |  | 0.0 | % |  | 0.1 | % |  | 0.0 | % |
| Non-GAAP GROSS MARGIN | 14.9 | % |  | 16.3 | % |  | 15.3 | % |  | 16.3 | % |
| GAAP INCOME FROM OPERATIONS | $ | 24,445 |  |  | $ | 31,448 |  |  | $ | 95,011 |  |  | $ | 105,959 |  |
|  | Add back stock-based compensation (a) | 3,886 |  |  | 3,566 |  |  | 11,768 |  |  | 9,727 |  |
| Non-GAAP INCOME FROM OPERATIONS | $ | 28,331 |  |  | $ | 35,014 |  |  | $ | 106,779 |  |  | $ | 115,686 |  |
| GAAP NET INCOME | $ | 16,662 |  |  | $ | 23,056 |  |  | $ | 65,050 |  |  | $ | 75,161 |  |
|  | Add back stock-based compensation (a) | 3,886 |  |  | 3,566 |  |  | 11,768 |  |  | 9,727 |  |
|  | Add back adjustments to tax provision (b) | (1,554 | ) |  | (1,697 | ) |  | (3,341 | ) |  | (3,274 | ) |
| Non-GAAP NET INCOME | $ | 18,994 |  |  | $ | 24,925 |  |  | $ | 73,477 |  |  | $ | 81,614 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.35 |  |  | $ | 0.49 |  |  | $ | 1.36 |  |  | $ | 1.63 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.05 |  |  | 0.04 |  |  | 0.18 |  |  | 0.14 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 0.40 |  |  | $ | 0.53 |  |  | $ | 1.54 |  |  | $ | 1.77 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.32 |  |  | $ | 0.44 |  |  | $ | 1.26 |  |  | $ | 1.47 |  |
|  | Add back stock-based compensation and adjustments to tax provision (a) (b) | 0.04 |  |  | 0.03 |  |  | 0.14 |  |  | 0.11 |  |
| Non-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 0.36 |  |  | $ | 0.47 |  |  | $ | 1.40 |  |  | $ | 1.58 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |
|  | BASIC –GAAP | 48,047 |  |  | 46,824 |  |  | 47,737 |  |  | 46,138 |  |
|  | BASIC - Non-GAAP | 48,047 |  |  | 46,824 |  |  | 47,737 |  |  | 46,138 |  |
|  | DILUTED – GAAP | 52,238 |  |  | 52,008 |  |  | 51,637 |  |  | 51,102 |  |
|  | DILUTED - Non-GAAP | 53,119 |  |  | 52,680 |  |  | 52,494 |  |  | 51,670 |  |

[0001628280-16-014939:8k_2_02:34]
(a) Amortization of Financial Accounting Standards Board Accounting Standards Codification Topic 718 stock-based compensation for the three and nine months ended March 31, 2016 and 2015.

[0001628280-16-014939:8k_2_02:35]
(b) The provision of income taxes used in arriving at the non-GAAP net income was computed using an income tax rate of 32.0% and 30.5% for the three and nine months ended March 31, 2016, respectively, and 28.3% and 29.1% for the three and nine months ended March 31, 2015, respectively.

[0001628280-16-014939:8k_2_02:36]
SOURCE: Super Micro Computer, Inc.

[0001628280-16-014939:8k_2_02:37]
Super Micro Computer, Inc.

[0001628280-16-014939:8k_2_02:38]
Howard Hideshima, 408-503-8000

[0001628280-16-014939:8k_2_02:39]
SVP, Chief Financial Officer

[0001628280-16-014939:8k_2_02:40]
ir@supermicro.com

[0001628280-16-014939:8k_2_02:41]
or

[0001628280-16-014939:8k_2_02:42]
Perry G. Hayes

[0001628280-16-014939:8k_2_02:43]
SVP, Investor Relations

[0001628280-16-014939:8k_2_02:44]
ir@supermicro.com

[0001628280-16-014939:8k_2_02:45]
SMCI-F
