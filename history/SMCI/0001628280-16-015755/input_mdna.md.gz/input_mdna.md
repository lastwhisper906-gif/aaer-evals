# SMCI MD&A — 0001628280-16-015755


## mdna

[0001628280-16-015755:mdna:1]
[same as prior period, unchanged from 0001628280-16-010768:mdna:1]

[0001628280-16-015755:mdna:2]
[same as prior period, unchanged from 0001628280-16-010768:mdna:2]

[0001628280-16-015755:mdna:3]
We are a global leader in high performance, high efficiency server technology and innovation. We develop and provide end-to-end green computing solutions to the cloud computing, data center, enterprise IT, big data, HPC and embedded markets. Our solutions range from complete server, storage, blade and workstations to full racks, networking devices, server management software and technology support and services. Our net sales were $532.7 million and $1,691.3 million for the three and nine months ended March 31, 2016, respectively, and $471.2 million and $1,417.6 million for the three and nine months ended March 31, 2015, respectively. The increase in our net sales in the three and nine months ended March 31, 2016 compared with the three and nine months ended March 31, 2015 was primarily due to increased sales of our server systems optimized for OEM/direct customers and cloud/internet data center computing. Net sales of optimized servers were $372.4 million and $1,182.4 million for the three and nine months ended March 31, 2016, respectively, and $302.0 million and $859.8 million for the three and nine months ended March 31, 2015, respectively, and net sales of subsystems and accessories were $160.3 million and $508.9 million for the three and nine months ended March 31, 2016, respectively, and $169.3 million and $557.7 million for the three and nine months ended March 31, 2015, respectively. In the three and nine months ended March 31, 2016, we experienced strong growth in sales of our complete systems including ultra, data center optimized servers, storage servers and Twin family of servers. The percentage of our net sales represented by sales of complete server systems increased to 69.9% in both the three and nine months ended March 31, 2016 from 64.1% and 60.7% in the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. Our net income was $16.7 million and $65.1 million for the three and nine months ended March 31, 2016, respectively, and $23.1 million and $75.2 million for the three and nine months ended March 31, 2015, respectively. Our decrease in net income in the three months ended March 31, 2016 was primarily attributable to lower gross margins from sales of cloud/internet data center server systems and our subsystem and accessories, lower utilization of manufacturing capacity and higher operating expenses. Our decrease in net income in the nine months ended March 31, 2016 was mainly attributable to the recording of a $9.3 million out-of-period adjustment relating to extended warranty revenue in the three months ended September 30, 2015. This deferred revenue will be recognized through fiscal year 2019. The impact on net income from this out-of-period adjustment was $5.9 million pertaining to prior periods through June 30, 2015.

[0001628280-16-015755:mdna:5]
We sell our server systems and subsystems and accessories through our direct sales force as well as through distributors and OEMs. We derived 54.4% and 55.8% of our net sales from products sold to OEM/direct customers and 45.6% and 44.2% from products sold to distributors for the three and nine months ended March 31, 2016, respectively. We derived 53.9% and 49.7% of our net sales from products sold to OEM/director customers and 46.1% and 50.3% from products sold to distributors for the three and nine months ended March 31, 2015, respectively. Sales to SoftLayer, a division of IBM Corporation, represented 10.2% and 12.6% of our net sales in the three and nine months ended March 31, 2016, and represented 13.9% and 12.5% of our net sales in the three and nine months ended March 31, 2015. We derived 61.3% and 63.4% of our net sales from customers in the United States for the three and nine months ended March 31, 2016, respectively, and 58.1% and 56.7% for the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:mdna:6]
We perform the majority of our research and development efforts in-house. Research and development expenses represented 5.9% and 5.3% of our net sales for the three and nine months ended March 31, 2016, respectively, and 5.4% and 5.1% of our net sales for the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:mdna:7]
We use several suppliers and contract manufacturers to design and manufacture components in accordance with our specifications, with most final assembly and testing performed at our manufacturing facility in San Jose, California. During fiscal year 2016, we have continued to increase manufacturing and service operations in Taiwan and the Netherlands primarily

[0001628280-16-015755:mdna:8]
to support our Asian and European customers and we have improved our utilization of our overseas manufacturing capacity. One of our key suppliers is Ablecom, a related party, which supplies us with contract design and manufacturing support. For the three and nine months ended March 31, 2016, our purchases from Ablecom represented 12.2% and 13.0% of our cost of sales, respectively, compared to 14.7% and 14.3% of our cost of sales for the three and nine months ended March 31, 2015, respectively. Ablecom’s sales to us constitute a substantial majority of Ablecom’s net sales. We continue to maintain our manufacturing relationship with Ablecom in Asia in an effort to reduce our cost of sales. In addition to providing a larger volume of contract manufacturing services for us, Ablecom continues to warehouse for us a number of components and subassemblies manufactured by multiple suppliers prior to shipment to our facilities in the United States and Europe. We typically negotiate the price of products that we purchase from Ablecom on a quarterly basis; however, either party may re-negotiate the price of products with each order. As a result of our relationship with Ablecom, it is possible that Ablecom may in the future sell products to us at a price higher or lower than we could obtain from an unrelated third party supplier. This may result in our future reporting of gross profit as a percentage of net sales that is less than or in excess of what we might have obtained absent our relationship with Ablecom.

[0001628280-16-015755:mdna:9]
[same as prior period, unchanged from 0001628280-16-010768:mdna:9]

[0001628280-16-015755:mdna:10]
[same as prior period, unchanged from 0001628280-16-010768:mdna:10]

[0001628280-16-015755:mdna:11]
The following is a summary of other financial highlights of the third quarter of fiscal 2016:

[0001628280-16-015755:mdna:12]
| • | Net cash provided by operating activities was $92.8 million and $9.1 million during the nine months ended March 31, 2016 and 2015, respectively. Our cash and cash equivalents, together with our investments, were $179.1 million at the end of the third quarter of fiscal year 2016, compared with $98.1 million at the end of fiscal year 2015. The increase in our cash and cash equivalents, together with our investments at the end of the third quarter of fiscal year 2016 was primarily due to $92.8 million of cash provided by our operating activities and $0.4 million of borrowings, net of repayments offset in part by $25.1 million of purchases of property and equipment, of which $11.1 million was related to property and equipment installed at our Green Computing Park in San Jose, California, and $3.2 million was related to the implementation of a new ERP system for the U.S. headquarters and our subsidiaries. |

[0001628280-16-015755:mdna:13]
| • | Days sales outstanding in accounts receivable (“DSO”) at the end of the third quarter of fiscal year 2016 was 51 days, compared with 43 days at the end of fiscal year 2015. |

[0001628280-16-015755:mdna:14]
| • | Our inventory balance was $479.3 million at the end of the third quarter of fiscal year 2016, compared with $463.5 million at the end of fiscal year 2015. Days sales of inventory at the end of the third quarter of fiscal year 2016 was 97 days, compared with 83 days at the end of fiscal year 2015. The increase in our inventory was due to lower net sales in the third quarter of fiscal year 2016 as well as to support our anticipated level of growth in net sales in the fourth quarter of fiscal year 2016. |

[0001628280-16-015755:mdna:15]
| • | Our purchase commitments with contract manufacturers and suppliers were $341.6 million at the end of the third quarter of fiscal year 2016 and $378.3 million at the end of fiscal year 2015. Included in these non-cancellable commitments are hard disk drive purchase commitments totaling approximately $116.9 million, which have terms expiring through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments. |

[0001628280-16-015755:mdna:16]
[same as prior period, unchanged from 0001628280-16-010768:mdna:16]

[0001628280-16-015755:mdna:17]
22

[0001628280-16-015755:mdna:18]
[same as prior period, unchanged from 0001628280-16-010768:mdna:17]

[0001628280-16-015755:mdna:19]
[same as prior period, unchanged from 0001628280-16-010768:mdna:18]

[0001628280-16-015755:mdna:20]
[same as prior period, unchanged from 0001628280-16-010768:mdna:19]

[0001628280-16-015755:mdna:21]
[same as prior period, unchanged from 0001628280-16-010768:mdna:20]

[0001628280-16-015755:mdna:22]
[same as prior period, unchanged from 0001628280-16-010768:mdna:21]

[0001628280-16-015755:mdna:23]
[same as prior period, unchanged from 0001628280-16-010768:mdna:22]

[0001628280-16-015755:mdna:24]
[same as prior period, unchanged from 0001628280-16-010768:mdna:23]

[0001628280-16-015755:mdna:25]
[same as prior period, unchanged from 0001628280-16-010768:mdna:24]

[0001628280-16-015755:mdna:26]
[same as prior period, unchanged from 0001628280-16-010768:mdna:25]

[0001628280-16-015755:mdna:27]
[same as prior period, unchanged from 0001628280-16-010768:mdna:26]

[0001628280-16-015755:mdna:28]
[same as prior period, unchanged from 0001628280-16-010768:mdna:27]

[0001628280-16-015755:mdna:29]
[same as prior period, unchanged from 0001628280-16-010768:mdna:28]

[0001628280-16-015755:mdna:30]
[same as prior period, unchanged from 0001628280-16-010768:mdna:29]

[0001628280-16-015755:mdna:31]
In addition, certain customers have acceptance provisions and revenue is deferred until the customers provide the necessary acceptance. We have an immaterial amount of deferred revenue and costs related to shipments to customers pending acceptance as of March 31, 2016 and June 30, 2015.

[0001628280-16-015755:mdna:32]
Probability of collection is assessed on a customer-by-customer basis. Customers are subjected to a credit review process that evaluates the customers’ financial position and ability to pay. If it is determined from the outset of an arrangement that collection is not probable based upon the review process, the customers are required to pay cash in advance of shipment. We also make estimates of the uncollectibility of accounts receivables, analyzing accounts receivable and historical bad debts, customer concentration, customer-credit-worthiness, current economic trends and changes in customer payment terms to evaluate the adequacy of the allowance for doubtful accounts. On a quarterly basis, we evaluate aged items in the accounts receivable aging report and provide an allowance in an amount we deem adequate for doubtful accounts. Our provision for bad debt was $209,000 and $1,014,000 in the three and nine months ended March 31, 2016, respectively, and $281,000 and $194,000 in the three and nine months ended March 31, 2015, respectively. If a major customer's creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our reported operating expenses. We provide for price protection to certain distributors. We assess the market competition and product technology obsolescence, and make price adjustments based on our judgment. Upon each announcement of price reductions, the accrual for price protection is calculated based on our distributors’ inventory on hand. Such reserves are recorded as a reduction to revenue at the time we reduce the product prices.

[0001628280-16-015755:mdna:33]
[same as prior period, unchanged from 0001628280-16-010768:mdna:32]

[0001628280-16-015755:mdna:34]
Product warranties. We offer product warranties ranging from 15 to 39 months against any defective product. We accrue for estimated returns of defective products at the time revenue is recognized, based on historical warranty experience and recent trends. We monitor warranty obligations and may make revisions to our warranty reserve if actual costs of product repair and replacement are significantly higher or lower than estimated. Accruals for anticipated future warranty costs are

[0001628280-16-015755:mdna:35]
charged to cost of sales and included in accrued liabilities. The liability for product warranties was $7.1 million as of March 31, 2016, compared with $7.7 million as of June 30, 2015. The provision for warranty reserve was $3.7 million and $12.2 million in the three and nine months ended March 31, 2016, respectively, and $4.0 million and $10.9 million in the three and nine months ended March 31, 2015, respectively. The change in estimated liability for pre-existing warranties was ($0.5) million and $(2.3) million for the three and nine months ended March 31, 2016, respectively, and $(13,000) and $(0.3) million for the three and nine months ended March 31, 2015, respectively. The change in estimated liability for pre-existing warranties decreased due to our decrease in warranty claims in the three and nine months ended March 31, 2016. The provision for warranty reserve decreased $0.3 million and increased $1.3 million compared to the three and nine months ended March 31, 2015, respectively, primarily due to the increase in our net sales partially offset by our decrease in warranty claims. If in future periods, we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, we intend to adjust our estimates accordingly.

[0001628280-16-015755:mdna:36]
Inventory valuation. Inventory is valued at the lower of cost or market. We evaluate inventory on a quarterly basis for lower of cost or market and excess and obsolescence and, as necessary, write down the valuation of units based upon the number of units that are unlikely to be sold. This evaluation takes into account matters including expected demand, historical usage and sales, anticipated sales price, product obsolescence and other factors. If actual future demand for our products is less than currently forecasted, additional inventory adjustments may be required. Once a reserve is established, it is maintained until the product to which it relates is sold or scrapped. If a unit that has been written down is subsequently sold, the cost associated with the revenue from this unit is reduced to the extent of the write down, resulting in an increase in gross profit. We monitor the extent to which previously written down inventory is sold at amounts greater or less than carrying value, and based on this analysis, adjust our estimate for determining future write downs. If in future periods, we experience or anticipate a change in recovery rate compared with our historical experience, our gross margin would be affected. Our provision for inventory was $2.2 million and $6.0 million in the three and nine months ended March 31, 2016, respectively, and $0.3 million and $4.5 million in the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:mdna:37]
[same as prior period, unchanged from 0001628280-16-010768:mdna:36]

[0001628280-16-015755:mdna:38]
[same as prior period, unchanged from 0001628280-16-010768:mdna:37]

[0001628280-16-015755:mdna:39]
[same as prior period, unchanged from 0001628280-16-010768:mdna:38]

[0001628280-16-015755:mdna:40]
The expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on a combination of our peer group and our historical experience. The expected volatility is based on a combination of our implied and historical volatility. In addition, forfeitures of share-based awards are estimated at the time of grant and revised, if necessary, in subsequent periods if actual forfeitures differ from those estimates. We use historical data to estimate pre-vesting option and restricted stock unit forfeitures and record stock-based compensation expense only for those awards that are expected to vest.

[0001628280-16-015755:mdna:41]
Compensation expense for options and restricted stock units granted to employees was $3.9 million and $11.8 million for the three and nine months ended March 31, 2016, respectively, and $3.6 million and $9.7 million for the three and nine months ended March 31, 2015, respectively. As of March 31, 2016, the total unrecognized compensation cost, adjusted for estimated forfeitures, related to unvested stock options and restricted stock units to employees and non-employee members of our Board of Directors, was $35.6 million, which is expected to be recognized as an expense over a weighted-average period of approximately 2.31 years. See Note 2 of Notes to our Condensed Consolidated Financial Statements for additional information.

[0001628280-16-015755:mdna:42]
Variable interest entities. We have concluded that Ablecom and its subsidiaries ("Ablecom") is a variable interest entity in accordance with applicable accounting standards and guidance; however, we are not the primary beneficiary of Ablecom and therefore, we do not consolidate Ablecom. In performing our analysis, we considered our explicit arrangements with Ablecom including the supplier and distributor arrangements. Also, as a result of the substantial related party relationship between the two companies, we considered whether any implicit arrangements exist that would cause us to protect those related parties’ interests in Ablecom from suffering losses. We determined that no implicit arrangements exist with Ablecom or its shareholders. Such an arrangement would be inconsistent with the fiduciary duty that we have towards our stockholders who do not own shares in Ablecom.

[0001628280-16-015755:mdna:43]
In May 2012, we and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by us and Ablecom for our separately constructed manufacturing facilities. Each company contributed $168,000 and own 50% of the Management Company. Although the operations of the Management Company are independent of us, through governance rights, we have the ability to direct the Management Company's business strategies. Therefore, we have concluded that the Management Company is a variable interest entity of us as we are the primary beneficiary of the Management Company. As of March 31, 2016, the accounts of the Management Company have been consolidated with our accounts, and a noncontrolling interest has been recorded for Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2016, $13,000 and $9,000, respectively, of net income attribute to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statement of operations. In the three and nine months ended March 31, 2015, $4,000 and $(3,000), respectively, of net income (loss) attributable to Ablecom's interest was included in our general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-16-015755:mdna:44]
[same as prior period, unchanged from 0001628280-16-010768:mdna:44]

[0001628280-16-015755:mdna:45]
[same as prior period, unchanged from 0001628280-16-010768:mdna:45]

[0001628280-16-015755:mdna:46]
The following table presents net sales by product type for the three and nine months ended March 31, 2016 and 2015 (dollars in millions):

[0001628280-16-015755:mdna:47]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Server systems | $ | 372.4 |  |  | $ | 302.0 |  |  | $ | 70.4 |  |  | 23.3 | % |  | $ | 1,182.4 |  |  | $ | 859.8 |  |  | $ | 322.6 |  |  | 37.5 | % |
| Percentage of total net sales | 69.9 | % |  | 64.1 | % |  |  |  |  |  | 69.9 | % |  | 60.7 | % |  |  |  |  |
| Subsystems and accessories | 160.3 |  |  | 169.3 |  |  | (9 | ) |  | (5.3 | )% |  | 508.9 |  |  | 557.7 |  |  | (48.8 | ) |  | (8.8 | )% |
| Percentage of total net sales | 30.1 | % |  | 35.9 | % |  |  |  |  |  | 30.1 | % |  | 39.3 | % |  |  |  |  |
| Total net sales | $ | 532.7 |  |  | $ | 471.2 |  |  | $ | 61.5 |  |  | 13.1 | % |  | $ | 1,691.3 |  |  | $ | 1,417.6 |  |  | $ | 273.7 |  |  | 19.3 | % |

[0001628280-16-015755:mdna:48]
The following table presents unit sales and average selling price by product type for the three and nine months ended March 31, 2016 and 2015 (units in thousands):

[0001628280-16-015755:mdna:49]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| Server systems: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 85 |  |  | 77 |  |  | 10.4 | % |  | 273 |  |  | 227 |  |  | 20.3 | % |
| Average selling price | $ | 4,381 |  |  | $ | 3,921 |  |  | 11.7 | % |  | $ | 4,331 |  |  | $ | 3,788 |  |  | 14.3 | % |
| Subsystems and accessories: |  |  |  |  |  |  |  |  |  |  |  |
| Unit sales | 950 |  |  | 1,007 |  |  | (5.7 | )% |  | 2,960 |  |  | 3,416 |  |  | (13.3 | )% |
| Average selling price | $ | 169 |  |  | $ | 168 |  |  | 0.6 | % |  | $ | 172 |  |  | $ | 163 |  |  | 5.5 | % |

[0001628280-16-015755:mdna:50]
Comparison of Three Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:51]
The increase in our net sales in the three months ended March 31, 2016 compared with the three months ended March 31, 2015 was primarily due to continued increased sales of our products optimized for OEM/direct customers and cloud/internet data center computing who increasingly are purchasing complete server systems from us. The year-over-year growth in net sales of our server systems in the three months ended March 31, 2016 was due primarily to an increase in unit volumes of server systems and an increase in the average selling price of our server systems. The average selling prices of our server systems increased primarily due to higher sales of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, data center optimized servers, Twin family of servers and storage servers.

[0001628280-16-015755:mdna:52]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in the three months ended March 31, 2016 was primarily due to lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who are purchasing accessories from us and completing the final assembly themselves.

[0001628280-16-015755:mdna:53]
Comparison of Nine Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:54]
The increase in our net sales in the nine months ended March 31, 2016 compared with the nine months ended March 31, 2015 was primarily due to continued increased sales of our products optimized for OEM/direct customers and cloud/internet data center computing who increasingly are purchasing complete server systems from us offset in part by a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three prior fiscal year period ended June 30, 2015 and deferred in the three months ended September 30, 2015. The year-over-year growth in net sales of our server systems in the nine months ended March 31, 2016 was due primarily to an increase in unit volumes of server systems and to a lesser extent an increase in the average selling price of our server systems. The average selling prices of our server systems increased primarily due to higher sales of our complete server systems which offer higher density computing and more memory and hard disk drive capacity. The increase in the sales of these complete systems include our ultra, data center optimized servers, storage servers and Twin family of servers.

[0001628280-16-015755:mdna:55]
The year-over-year decrease in net sales and unit sales of our subsystems and accessories in the nine months ended March 31, 2016 was primarily due to lower sales of hard disk drives and memory bundled with our server solutions to our distributors and system integrators who are purchasing accessories from us and completing the final assembly themselves.

[0001628280-16-015755:mdna:56]
The following table presents the percentages of net sales from products sold to distributors and OEM/direct customers for the three and nine months ended March 31, 2016 and 2015:

[0001628280-16-015755:mdna:57]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| Distributors | 45.6 | % |  | 46.1 | % |  | (0.5 | )% |  | 44.2 | % |  | 50.3 | % |  | (6.1 | )% |
| OEMs and direct customers | 54.4 | % |  | 53.9 | % |  | 0.5 | % |  | 55.8 | % |  | 49.7 | % |  | 6.1 | % |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-015755:mdna:58]
The following table presents percentages of net sales by geographic region for the three and nine months ended March 31, 2016 and 2015:

[0001628280-16-015755:mdna:59]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | % |  | 2016 |  | 2015 |  | % |
| United States | 61.3 | % |  | 58.1 | % |  | 3.2 | % |  | 63.4 | % |  | 56.7 | % |  | 6.7 | % |
| Europe | 17.5 | % |  | 18.7 | % |  | (1.2 | )% |  | 17.4 | % |  | 19.0 | % |  | (1.6 | )% |
| Asia | 14.7 | % |  | 15.9 | % |  | (1.2 | )% |  | 14.3 | % |  | 17.1 | % |  | (2.8 | )% |
| Others | 6.5 | % |  | 7.3 | % |  | (0.8 | )% |  | 4.9 | % |  | 7.2 | % |  | (2.3 | )% |
| Total net sales | 100.0 | % |  | 100.0 | % |  |  |  | 100.0 | % |  | 100.0 | % |  |  |

[0001628280-16-015755:mdna:60]
[same as prior period, unchanged from 0001628280-16-010768:mdna:60]

[0001628280-16-015755:mdna:61]
Cost of sales and gross margin for the three and nine months ended March 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-015755:mdna:62]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Total cost of sales | $ | 453.6 |  |  | $ | 394.4 |  |  | $ | 59.2 |  |  | 15.0 | % |  | $ | 1,433.6 |  |  | $ | 1,187.1 |  |  | $ | 246.5 |  |  | 20.8 | % |
| Total gross profit | 79.2 |  |  | 76.8 |  |  | $ | 2.3 |  |  | 3.0 | % |  | 257.7 |  |  | 230.5 |  |  | $ | 27.3 |  |  | 11.8 | % |
| Total gross margin | 14.9 | % |  | 16.3 | % |  |  |  | (1.4 | )% |  | 15.2 | % |  | 16.3 | % |  |  |  | (1.1 | )% |

[0001628280-16-015755:mdna:63]
Comparison of Three Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:64]
The quarter-over-quarter increase in absolute dollars of cost of sales in the three months ended March 31, 2016 compared to the three months ended March 31, 2015 was primarily attributable to the increase in net sales. In the three months ended March 31, 2016, we recorded a $2.2 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $0.3 million, or 0.1% of net sales, in the three months ended March 31, 2015.

[0001628280-16-015755:mdna:65]
In the three months ended March 31, 2016, we recorded a $3.7 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to a $4.0 million expense, or 0.8% of net sales, in the three months ended March 31, 2015. The increase in the provision for warranty reserve was primarily due to higher net sales partially offset by the decrease in warranty claims in the three months ended March 31, 2016. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-015755:mdna:66]
Gross margin percentage was 14.9% and 16.3% for the three months ended March 31, 2016 and 2015, respectively. The decrease was mainly due to lower gross margins from sales of cloud/internet data center server systems and our subsystem and accessories and lower utilization of manufacturing capacity offset in part by higher sales of our complete server systems such as storage servers which have a higher gross margin.

[0001628280-16-015755:mdna:67]
Comparison of Nine Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:68]
The year-over-year increase in absolute dollars of cost of sales in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015 was primarily attributable to the increase in net sales. In the nine months ended March 31, 2016, we recorded a $6.0 million expense, net of recovery, or 0.4% of net sales, related to the inventory provision as compared to $4.5 million, or 0.3% of net sales, in the nine months ended March 31, 2015.

[0001628280-16-015755:mdna:69]
In the nine months ended March 31, 2016, we recorded a $12.2 million expense, or 0.7% of net sales, related to the provision for warranty reserve as compared to a $10.9 million expense, or 0.8% of net sales, in the nine months ended March 31, 2015. The increase in the provision for warranty reserve was primarily due to higher net sales partially offset by the decrease in warranty claims in the nine months ended March 31, 2016. If in future periods we experience or anticipate an increase or decrease in warranty claims as a result of new product introductions or change in unit volumes compared with our

[0001628280-16-015755:mdna:70]
historical experience, or if the cost of servicing warranty claims is greater or lesser than expected, our gross margin would be affected.

[0001628280-16-015755:mdna:71]
Gross margin percentage was 15.2% and 16.3% for the nine months ended March 31, 2016 and 2015, respectively. The year-over-year decrease in gross margins in the nine months ended March 31, 2016 was mainly due to a $9.3 million out-of-period adjustment relating to extended warranty revenue which was recognized in the three fiscal year period ended June 30, 2015. Gross margin percentage would have been 15.7% without this out-of-period adjustment.

[0001628280-16-015755:mdna:72]
[same as prior period, unchanged from 0001628280-16-010768:mdna:72]

[0001628280-16-015755:mdna:73]
Operating expenses for the three and nine months ended March 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-015755:mdna:74]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Research and development | $ | 31.3 |  |  | $ | 25.5 |  |  | $ | 5.7 |  |  | 22.4 | % |  | $ | 89.8 |  |  | $ | 72.5 |  |  | $ | 17.3 |  |  | 23.9 | % |
| Percentage of total net sales | 5.9 | % |  | 5.4 | % |  |  |  |  |  | 5.3 | % |  | 5.1 | % |  |  |  |  |
| Sales and marketing | 14.5 |  |  | 12.5 |  |  | 2.0 |  |  | 15.8 | % |  | 45.2 |  |  | 34.7 |  |  | 10.5 |  |  | 30.4 | % |
| Percentage of total net sales | 2.7 | % |  | 2.6 | % |  |  |  |  |  | 2.7 | % |  | 2.5 | % |  |  |  |  |
| General and administrative | 9.0 |  |  | 7.3 |  |  | 1.7 |  |  | 22.5 | % |  | 27.7 |  |  | 17.3 |  |  | 10.4 |  |  | 59.8 | % |
| Percentage of total net sales | 1.7 | % |  | 1.6 | % |  |  |  |  |  | 1.6 | % |  | 1.2 | % |  |  |  |  |
| Total operating expenses | $ | 54.7 |  |  | $ | 45.3 |  |  | $ | 9.3 |  |  | 20.6 | % |  | $ | 162.7 |  |  | $ | 124.5 |  |  | $ | 38.2 |  |  | 30.7 | % |
| Percentage of total net sales | 10.3 | % |  | 9.6 | % |  |  |  |  |  | 9.6 | % |  | 8.8 | % |  |  |  |  |

[0001628280-16-015755:mdna:75]
Comparison of Three Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:76]
Research and development expenses. Research and development expenses increased by $5.7 million, or 22.4% in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. Research and development expenses were 5.9% and 5.4% of net sales for the three months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $4.5 million in compensation and benefits including stock-based compensation expense and an increase of $1.2 million in development expenses for prototype materials.

[0001628280-16-015755:mdna:77]
Research and development expenses include stock-based compensation expense of $2.5 million and $2.3 million for the three months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:78]
[same as prior period, unchanged from 0001628280-16-010768:mdna:78]

[0001628280-16-015755:mdna:79]
Sales and marketing expenses. Sales and marketing expenses increased by $2.0 million, or 15.8% in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. Sales and marketing expenses were 2.7% and 2.6% of net sales for the three months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $2.2 million in compensation and benefits resulting primarily from growth in sales and marketing personnel, partially offset by a decrease of $0.6 million in advertising, marketing promotional and trade show expenses.

[0001628280-16-015755:mdna:80]
Sales and marketing expenses include stock-based compensation expense of $0.5 million and $0.4 million for the three months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:81]
General and administrative expenses. General and administrative expenses increased by $1.7 million, or 22.5% in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. General and administrative expenses were 1.7% and 1.6% of net sales for the three months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $1.8 million in compensation and benefits including stock-based compensation expense and an increase of $0.4 million in legal expenses, partially offset by an increase of $1.0 million in foreign currency transaction gain.

[0001628280-16-015755:mdna:82]
General and administrative expenses include stock-based compensation expense of $0.6 million and $0.7 million for the three months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:83]
Comparison of Nine Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:84]
Research and development expenses. Research and development expenses increased by $17.3 million, or 23.9% in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015. Research and development expenses were 5.3% and 5.1% of net sales for the nine months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was driven primarily by an increase of $13.6 million in compensation and benefits including stock-based compensation expense, a decrease of $2.1 million refund of value added taxes on research and development expenses and an increase of $1.7 million in development expenses for prototype materials.

[0001628280-16-015755:mdna:85]
Research and development expenses include stock-based compensation expense of $7.4 million and $6.1 million for the nine months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:86]
[same as prior period, unchanged from 0001628280-16-010768:mdna:87]

[0001628280-16-015755:mdna:87]
Sales and marketing expenses. Sales and marketing expenses increased by $10.5 million, or 30.4% in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015. Sales and marketing expenses were 2.7% and 2.5% of net sales for the nine months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $6.5 million in compensation and benefits resulting primarily from growth in sales and marketing personnel, an increase of $2.3 million in advertising, marketing promotional and trade show expenses and a decrease of $1.2 million in marketing co-op funding from certain suppliers.

[0001628280-16-015755:mdna:88]
Sales and marketing expenses include stock-based compensation expense of $1.3 million and $1.1 million for the nine months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:89]
General and administrative expenses. General and administrative expenses increased by $10.4 million, or 59.8% in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015. General and administrative expenses were 1.6% and 1.2% of net sales for the nine months ended March 31, 2016 and 2015, respectively. The increase in absolute dollars was primarily due to an increase of $5.7 million in compensation and benefits including stock-based compensation expense, an increase of $3.5 million in legal, audit and accounting expenses and an increase of $0.8 million in bad debt expenses, partially offset by an increase of $1.1 million in foreign currency transaction gain.

[0001628280-16-015755:mdna:90]
General and administrative expenses include stock-based compensation expense of $2.2 million and $1.8 million for the nine months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:91]
[same as prior period, unchanged from 0001628280-16-010768:mdna:92]

[0001628280-16-015755:mdna:92]
Interest and other expense, net for the three and nine months ended March 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-015755:mdna:93]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Interest and other income, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | N/M* |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | N/M* |  |
| Interest expense | (0.4 | ) |  | (0.3 | ) |  | (0.1 | ) |  | 50.5 | % |  | (1.1 | ) |  | (0.7 | ) |  | (0.5 | ) |  | 73.9 | % |
| Interest and other expense, net | $ | (0.4 | ) |  | $ | (0.3 | ) |  | $ | (0.1 | ) |  | 55.1 | % |  | $ | (1.0 | ) |  | $ | (0.6 | ) |  | $ | (0.4 | ) |  | 79.1 | % |

[0001628280-16-015755:mdna:94]
[same as prior period, unchanged from 0001628280-16-010768:mdna:95]

[0001628280-16-015755:mdna:95]
Comparison of Three Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:96]
Interest and other expense, net. Interest and other expense, net increased by $0.1 million in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. The increases were primarily due to higher interest expense on debt.

[0001628280-16-015755:mdna:97]
Comparison of Nine Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:98]
Interest and other expense, net. Interest and other expense, net increased by $0.4 million in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015. The increases were primarily due to higher interest expense on debt.

[0001628280-16-015755:mdna:99]
[same as prior period, unchanged from 0001628280-16-010768:mdna:100]

[0001628280-16-015755:mdna:100]
Provision for income taxes and effective tax rates for the three and nine months ended March 31, 2016 and 2015 are as follows (dollars in millions):

[0001628280-16-015755:mdna:101]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2016 |  | 2015 |  | $ |  | % |  | 2016 |  | 2015 |  | $ |  | % |
| Provision for income taxes | $ | 7.4 |  |  | $ | 8.1 |  |  | $ | (0.8 | ) |  | (9.2 | )% |  | $ | 29.0 |  |  | $ | 30.2 |  |  | $ | (1.3 | ) |  | (4.2 | )% |
| Percentage of total net sales | 1.4 | % |  | 1.7 | % |  |  |  |  |  | 1.7 | % |  | 2.1 | % |  |  |  |  |
| Effective tax rate | 30.7 | % |  | 26.1 | % |  |  |  |  |  | 30.8 | % |  | 28.7 | % |  |  |  |  |

[0001628280-16-015755:mdna:102]
Comparison of Three Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:103]
Provision for income taxes. Provision for income taxes decreased by $0.8 million, or 9.2% in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. The effective tax rate was 30.7% and 26.1% for the three months ended March 31, 2016 and 2015, respectively. The lower income tax provision for the three months ended March 31, 2016 was primarily attributable to our lower operating income. The effective tax rate for the three months ended March 31, 2016 was higher primarily due to lower benefits from disqualifying dispositions of incentive stock options and lower uncertain tax position releases from lapse of the applicable statute of limitations.

[0001628280-16-015755:mdna:104]
Comparison of Nine Months Ended March 31, 2016 and 2015

[0001628280-16-015755:mdna:105]
Provision for income taxes. Provision for income taxes decreased by $1.3 million, or 4.2% in the nine months ended March 31, 2016 compared to the nine months ended March 31, 2015. The effective tax rate was 30.8% and 28.7% for the nine months ended March 31, 2016 and 2015, respectively. The lower income tax provision for the nine months ended March 31, 2016 was primarily attributable to our lower operating income. The effective tax rate for the nine months ended March 31, 2016 was higher primarily due to lower benefits from disqualifying dispositions of incentive stock options and additional tax accruals related to foreign operations.

[0001628280-16-015755:mdna:106]
[same as prior period, unchanged from 0001628280-16-010768:mdna:107]

[0001628280-16-015755:mdna:107]
Since our inception, we have financed our growth primarily with funds generated from operations and from the proceeds of our initial public offering. In addition, we have utilized borrowing facilities, particularly in relation to the financing of real property acquisitions. Our cash and cash equivalents and short-term investments were $176.5 million and $95.5 million as of March 31, 2016 and June 30, 2015, respectively. Our cash in foreign locations was $49.9 million and $26.3 million at March 31, 2016 and June 30, 2015, respectively. It is management's intention to reinvest the undistributed foreign earnings indefinitely in foreign operations.

[0001628280-16-015755:mdna:108]
Operating Activities. Net cash provided by operating activities was $92.8 million and $9.1 million for the nine months ended March 31, 2016 and 2015, respectively.

[0001628280-16-015755:mdna:109]
Net cash provided by our operating activities for the nine months ended March 31, 2016 was primarily due to our net income of $65.1 million, a decrease in accounts receivable of $35.9 million, an increase in other long-term liabilities of $21.8 million, stock-based compensation expense of $11.8 million, depreciation expense of $9.5 million, an increase in accrued liabilities of $5.7 million, and provision for inventory of $6.0 million, which were partially offset by a decrease in accounts payable of $23.2 million, an increase in inventory of $21.8 million, a decrease in income tax payable of $8.6 million, an increase in prepaid expenses and other assets of $3.8 million and an increase in deferred income taxes assets of $2.7 million.

[0001628280-16-015755:mdna:110]
The decrease for the nine months ended March 31, 2016 in accounts receivable was primarily due to lower sales in the last month of the third quarter of fiscal year 2016 as compared to the last month of the fourth quarter of fiscal year 2015. The decrease for the nine months ended March 31, 2016 in accounts payable was due to lower purchases of inventory in the third quarter of fiscal year 2016. The increase for the nine months ended March 31, 2016 in inventory was primarily due to lower sales in the third quarter of fiscal year 2016. We anticipate that accounts receivable, inventory and accounts payable will increase to the extent we continue to grow our product lines and our business.

[0001628280-16-015755:mdna:111]
The increase for the nine months ended March 31, 2015 in accounts receivable was primarily due to an increase in our net sales late in the quarter ended March 31, 2015. The increase for the nine months ended March 31, 2015 in inventory and accounts payable was primarily due to higher purchases in anticipation of the growth of our business in our seasonally strong June quarter and was also impacted by the timing of deliveries as a result of the west coast port strike in February 2015.

[0001628280-16-015755:mdna:112]
Investing activities. Net cash used in our investing activities was $26.1 million and $25.7 million for the nine months ended March 31, 2016 and 2015, respectively. In the nine months ended March 31, 2016, of the net cash used in our investing activities, $25.1 million was related to the purchase of property, plant and equipment, of which $11.1 million was related to the property and equipment of manufacturing buildings at our Green Computing Park in San Jose, California, and $3.2 million was related to the implementation of a new ERP system for the U.S. headquarters and its subsidiaries. We plan to continue the development and construction of improvements to our properties through fiscal year 2017. We anticipate investing approximately $23.2 million through November 2016 to build the second manufacturing facility and remodel our office building. We plan to finance this development through our operating cash flows and additional borrowings from banks. In the nine months ended March 31, 2015, $24.6 million was related to the purchase of property, plant and equipment.

[0001628280-16-015755:mdna:113]
Financing activities. Net cash provided by our financing activities was $13.2 million and $30.0 million for the nine months ended March 31, 2016 and 2015, respectively. In the nine months ended March 31, 2016, we borrowed an additional $24.1 million under our revolving line of credit from Bank of America and CTBC Bank and repaid $23.7 million in loans. Further, we received $10.7 million related to the proceeds from the exercise of stock options in the nine months ended March 31, 2016.

[0001628280-16-015755:mdna:114]
In the nine months ended March 31, 2015, we received $21.1 million related to the proceeds from the exercise of stock options. Further, we borrowed an additional $36.4 million under our revolving line of credit from CTBC Bank and repaid $35.3 million in loans in the nine months ended March 31, 2015.

[0001628280-16-015755:mdna:115]
In the nine months ended March 31, 2016 and 2015, $2.5 million and $7.2 million was related to the excess tax benefits from stock-based compensation, respectively. We expect the net cash provided by financing activities will increase throughout fiscal year 2016 as we intend to obtain additional financing from banks for our working capital requirements.

[0001628280-16-015755:mdna:116]
We expect to experience continued growth in our working capital requirements and capital expenditures as we continue to expand our business. Our long-term future capital requirements will depend on many factors, including our level of revenues, the timing and extent of spending to support our product development efforts, the expansion of sales and marketing activities, the timing of our introductions of new products, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. We intend to fund this continued expansion through cash generated by operations and by drawing on the revolving credit facility or through other debt financing. However we cannot be certain whether such financing will be available on commercially reasonable or otherwise favorable terms or that such financing will be available at all. We anticipate that working capital and capital expenditures will constitute a material use of our cash resources. We have sufficient cash on hand to continue to operate for at least the next 12 months.

[0001628280-16-015755:mdna:117]
[same as prior period, unchanged from 0001628280-16-010768:mdna:120]

[0001628280-16-015755:mdna:118]
[same as prior period, unchanged from 0001628280-16-010768:mdna:121]

[0001628280-16-015755:mdna:119]
[same as prior period, unchanged from 0001628280-16-010768:mdna:122]

[0001628280-16-015755:mdna:120]
In June 2015, we entered into an amendment to our existing credit agreement with Bank of America, which provided for (i) a $65.0 million revolving line of credit facility and (ii) a five-year $14.0 million term loan facility. The term loan is secured by three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In April 2016, we extended the revolving line of credit to mature on May 31, 2016, and we are currently negotiating with Bank of America to renew the revolving line of credit.

[0001628280-16-015755:mdna:121]
The line of credit facility provided for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.44% at March 31, 2016. For borrowings denominated in Taiwanese dollars, the interest rate for the revolving line of credit is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-16-015755:mdna:122]
As of March 31, 2016 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $1.6 million and $3.7 million, respectively. The total outstanding borrowings under the Bank of America line of credit were $62.2 million and $59.7 million as of March 31, 2016 and June 30, 2015, respectively. The interest rates for these loans ranged from 1.00% to 1.94% per annum at March 31, 2016 and 0.79% to 1.68% per annum at June 30, 2015, respectively. As of March 31, 2016, the unused revolving line of credit under Bank of America was $2.8 million.

[0001628280-16-015755:mdna:123]
[same as prior period, unchanged from 0001628280-16-010768:mdna:126]

[0001628280-16-015755:mdna:124]
In November 2015, we entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NT$700.0 million or $22.0 million U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1.0 billion or $30.3 million U.S. dollar equivalent. In January 2016, we extended the revolving line of credit to mature on March 31, 2016.

[0001628280-16-015755:mdna:125]
The total outstanding borrowings under the CTBC Bank term loan was denominated in Taiwanese dollars and was translated into U.S. dollars of $20.3 million and $21.3 million as of March 31, 2016 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit was $9.7 million in U.S. dollars at March 31, 2016 and June 30, 2015. The interest rate for these loans were ranged from 0.92% and 1.06% at March 31, 2016 and 0.82% and 1.16% per annum at June 30, 2015.

[0001628280-16-015755:mdna:126]
In April 2016, we entered into a new credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NT700.0 million or $21.6 million U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NT100.0 million or $3.1 million U.S. dollar equivalent with a 0.5% annual fee, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40.0 million with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40.0 million. The credit agreement matures on March 31, 2017.

[0001628280-16-015755:mdna:127]
Covenant Compliance

[0001628280-16-015755:mdna:128]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-16-015755:mdna:129]
[same as prior period, unchanged from 0001628280-16-010768:mdna:131]

[0001628280-16-015755:mdna:130]
[same as prior period, unchanged from 0001628280-16-010768:mdna:132]

[0001628280-16-015755:mdna:131]
[same as prior period, unchanged from 0001628280-16-010768:mdna:133]

[0001628280-16-015755:mdna:132]
As of March 31, 2016, our total assets of $1,137.0 million collateralized the line of credit with Bank of America and were all of our assets except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of March 31, 2016, total assets collateralizing the term loan with Bank of America were $17.2 million. As of March 31, 2016, the Company was in compliance with all financial covenants associated with the term loan and line of credit with Bank of America.

[0001628280-16-015755:mdna:133]
As of March 31, 2016, the net book value of land and building located in Bade, Taiwan collateralizing the term loan with CTBC Bank was $26.9 million. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2016.

[0001628280-16-015755:mdna:134]
[same as prior period, unchanged from 0001628280-16-010768:mdna:136]

[0001628280-16-015755:mdna:135]
In the three and nine months ended March 31, 2016, we paid our contract manufacturers within 35 to 75 days of invoice and Ablecom between 34 to 88 days of invoice. Ablecom, a Taiwan corporation, is one of our major contract manufacturers and a related party. As of March 31, 2016 and June 30, 2015 amounts owed to Ablecom by us were approximately $45.4 million and $59.0 million, respectively.

[0001628280-16-015755:mdna:136]
[same as prior period, unchanged from 0001628280-16-010768:mdna:138]

[0001628280-16-015755:mdna:137]
As of March 31, 2016, we held $2.6 million of auction rate securities, net of unrealized losses, representing our interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; the auction rate security was rated AA2 at March 31, 2016. These auction rate preferred shares have no stated maturity date.

[0001628280-16-015755:mdna:138]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and were not saleable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2016, $2.6 million of these auction rate securities have been classified as long-term available-for-sale investments. Based on our assessment of fair value at March 31, 2016, we have recorded an accumulated unrealized loss of $0.1 million, net of deferred income taxes, on long-term auction rate securities. The unrealized loss was deemed to be temporary and has been recorded as a component of accumulated other comprehensive loss. In the three and nine months ended March 31, 2016 and 2015, there was no auction rate securities redeemed or sold.

[0001628280-16-015755:mdna:139]
[same as prior period, unchanged from 0001628280-16-010768:mdna:141]

[0001628280-16-015755:mdna:140]
The following table describes our contractual obligations as of March 31, 2016:

[0001628280-16-015755:mdna:141]
|  | Payments Due by Period |
|  | Less Than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More Than5 Years |  | Total |
|  | (in thousands) |
| Operating leases | $ | 4,291 |  |  | $ | 6,344 |  |  | $ | 4,593 |  |  | $ | 2,422 |  |  | $ | 17,650 |  |
| Capital leases, including interest | 265 |  |  | 449 |  |  | 174 |  |  | — |  |  | 888 |  |
| Debt, including interest (1) | 93,795 |  |  | — |  |  | — |  |  | — |  |  | 93,795 |  |
| Purchase commitments (2) | 341,559 |  |  | — |  |  | — |  |  | — |  |  | 341,559 |  |
| Total (3) | $ | 439,910 |  |  | $ | 6,793 |  |  | $ | 4,767 |  |  | $ | 2,422 |  |  | $ | 453,892 |  |

[0001628280-16-015755:mdna:142]
[same as prior period, unchanged from 0001628280-16-010768:mdna:144]

[0001628280-16-015755:mdna:143]
| (1) | Amount reflects total anticipated cash payments, including anticipated interest payments based on the interest rate at March 31, 2016. |

[0001628280-16-015755:mdna:144]
| (2) | Amount reflects total gross purchase commitments under our manufacturing arrangements with third-party contract manufacturers or vendors. Our purchase obligations included $116.9 million of hard disk drive purchase commitments |

[0001628280-16-015755:mdna:145]
at March 31, 2016, which will be paid through December 2016. See Note 10 of Notes to our Condensed Consolidated Financial Statements for a discussion of purchase commitments.

[0001628280-16-015755:mdna:146]
| (3) | The table above excludes liabilities for deferred service revenue of $29.5 million and unrecognized tax benefits and related interest and penalties accrual of $15.8 million. We have not provided a detailed estimate of the payment timing of unrecognized tax benefits due to the uncertainty of when the related tax settlements will become due. See Note 9 of Notes to our Condensed Consolidated Financial Statements for a discussion of income taxes. |

[0001628280-16-015755:mdna:147]
[same as prior period, unchanged from 0001628280-16-010768:mdna:148]

[0001628280-16-015755:mdna:148]
Recent Accounting Pronouncements

[0001628280-16-015755:mdna:149]
In May 2014, the FASB issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. These guidances can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for us on July 1, 2018. We are currently evaluating the timing of our adoption and the impact of adopting the new revenue guidance on our financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:mdna:150]
[same as prior period, unchanged from 0001628280-16-010768:mdna:151]

[0001628280-16-015755:mdna:151]
[same as prior period, unchanged from 0001628280-16-010768:mdna:152]

[0001628280-16-015755:mdna:152]
[same as prior period, unchanged from 0001628280-16-010768:mdna:153]

[0001628280-16-015755:mdna:153]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for us on July 1, 2018. Early adoption is permitted. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:mdna:154]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payments to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. We are currently evaluating the effect the guidance will have on our financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:mdna:155]
[same as prior period, unchanged from 0001628280-16-010768:mdna:154]

[0001628280-16-015755:mdna:156]
[same as prior period, unchanged from 0001628280-16-010768:mdna:155]
